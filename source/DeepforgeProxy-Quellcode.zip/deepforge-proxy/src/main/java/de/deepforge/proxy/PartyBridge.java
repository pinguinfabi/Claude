package de.deepforge.proxy;

import java.io.*;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.TimeUnit;
import net.md_5.bungee.api.config.ServerInfo;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.event.PluginMessageEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.api.plugin.Plugin;
import net.md_5.bungee.event.EventHandler;

/**
 * Network parties for Deepforge: reads the parties of PartyxFreundeSystem (same proxy) and sends
 * every party with a member on the Deepforge server to it, so a network party is also the party
 * for dungeons, shared mines and the camp. Read through reflection: no compile-time dependency,
 * and without PartyxFreundeSystem this bridge simply stays off.
 */
public final class PartyBridge implements Listener {
  static final String CHANNEL = "deepforge:party";

  private final Plugin plugin;
  private final java.util.function.Supplier<String> server;
  private Object service;
  private Method partyOf, leader, members;
  private byte[] last = new byte[0];
  private long lastSent;

  PartyBridge(Plugin plugin, java.util.function.Supplier<String> server) {
    this.plugin = plugin;
    this.server = server;
  }

  boolean start() {
    if (plugin.getProxy().getPluginManager().getPlugin("PartyxFreundeSystem") == null) return false;
    plugin.getProxy().registerChannel(CHANNEL);
    plugin.getProxy().getPluginManager().registerListener(plugin, this);
    plugin.getProxy().getScheduler().schedule(plugin, this::push, 2, 1, TimeUnit.SECONDS);
    return true;
  }

  /** Looks up the party service lazily: PartyxFreundeSystem may enable after us (or fail to). */
  private boolean resolve() {
    if (service != null) return true;
    Plugin pf = plugin.getProxy().getPluginManager().getPlugin("PartyxFreundeSystem");
    if (pf == null) return false;
    try {
      Object s = pf.getClass().getMethod("parties").invoke(pf);
      if (s == null) return false;
      partyOf = s.getClass().getMethod("partyOf", UUID.class);
      Class<?> party = partyOf.getReturnType();
      leader = party.getMethod("leader");
      members = party.getMethod("memberIds");
      service = s;
      plugin.getLogger().info("Netzwerk-Partys aus PartyxFreundeSystem verbunden.");
      return true;
    } catch (ReflectiveOperationException | RuntimeException e) {
      return false;
    }
  }

  /** Every second: the parties of everyone on Deepforge; sent when changed, else every 10 s. */
  private void push() {
    if (!resolve()) return;
    ServerInfo target = plugin.getProxy().getServerInfo(server.get());
    if (target == null || target.getPlayers().isEmpty()) return;
    Map<UUID, List<UUID>> parties = new LinkedHashMap<>();
    try {
      for (ProxiedPlayer p : target.getPlayers()) {
        Object party = partyOf.invoke(service, p.getUniqueId());
        if (party == null) continue;
        UUID lead = (UUID) leader.invoke(party);
        if (parties.containsKey(lead)) continue;
        @SuppressWarnings("unchecked")
        List<UUID> ids = new ArrayList<>((List<UUID>) members.invoke(party));
        ids.remove(lead);
        ids.add(0, lead);
        parties.put(lead, ids);
      }
    } catch (ReflectiveOperationException | RuntimeException e) {
      return;
    }
    byte[] data = encode(parties);
    long now = System.currentTimeMillis();
    if (Arrays.equals(data, last) && now - lastSent < 10_000) return;
    last = data;
    lastSent = now;
    target.sendData(CHANNEL, data, false);
  }

  static byte[] encode(Map<UUID, List<UUID>> parties) {
    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
    try (DataOutputStream out = new DataOutputStream(bytes)) {
      out.writeUTF("SNAPSHOT");
      out.writeInt(parties.size());
      for (List<UUID> ids : parties.values()) {
        out.writeInt(ids.size());
        for (UUID id : ids) out.writeUTF(id.toString());
      }
    } catch (IOException e) {
      throw new UncheckedIOException(e);
    }
    return bytes.toByteArray();
  }

  /** Players must never be able to fake party data: only the proxy speaks on this channel. */
  @EventHandler
  public void message(PluginMessageEvent e) {
    if (CHANNEL.equals(e.getTag()) && e.getSender() instanceof ProxiedPlayer) e.setCancelled(true);
  }
}
