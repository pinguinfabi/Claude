package de.deepforge.proxy;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.config.ServerInfo;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.event.ChatEvent;
import net.md_5.bungee.api.event.ServerConnectEvent;
import net.md_5.bungee.api.event.TabCompleteEvent;
import net.md_5.bungee.api.plugin.Command;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.api.plugin.Plugin;
import net.md_5.bungee.config.Configuration;
import net.md_5.bungee.config.ConfigurationProvider;
import net.md_5.bungee.config.YamlConfiguration;
import net.md_5.bungee.event.EventHandler;
import net.md_5.bungee.event.EventPriority;

/**
 * BungeeCord/Waterfall bridge: /deepforge (and configured aliases) sends a permitted player to the
 * Deepforge server. On that server the same command passes through to the Deepforge plugin, so
 * /df menu, /df daily … keep working there.
 */
public final class DeepforgeProxy extends Plugin implements Listener {
  private String server, permission;
  private Set<String> commands = Set.of();
  private boolean restrict;
  private Configuration messages;

  @Override
  public void onEnable() {
    reload();
    getProxy().getPluginManager().registerListener(this, this);
    getProxy().getPluginManager().registerCommand(this, new ReloadCommand());
    getLogger().info("Deepforge-Proxy bereit: /" + String.join(", /", commands) + " -> " + server);
    if (new PartyBridge(this, () -> server).start())
      getLogger().info("PartyxFreundeSystem erkannt: Netzwerk-Partys gehen an " + server + ".");
  }

  private void reload() {
    try {
      File dir = getDataFolder();
      if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create " + dir);
      File file = new File(dir, "config.yml");
      if (!file.exists())
        try (InputStream in = getResourceAsStream("config.yml")) {
          Files.copy(in, file.toPath());
        }
      Configuration c = ConfigurationProvider.getProvider(YamlConfiguration.class).load(file);
      server = c.getString("server", "deepforge");
      permission = c.getString("permission", "deepforge.join");
      restrict = c.getBoolean("restrict-server", false);
      Set<String> labels = new LinkedHashSet<>();
      for (String s : c.getStringList("commands")) labels.add(s.toLowerCase(Locale.ROOT).replace("/", ""));
      if (labels.isEmpty()) labels.add("deepforge");
      commands = labels;
      messages = c.getSection("messages");
    } catch (IOException e) {
      throw new UncheckedIOException("Deepforge-Proxy config.yml konnte nicht gelesen werden", e);
    }
  }

  private String msg(String key, String fallback) {
    String text = messages == null ? fallback : messages.getString(key, fallback);
    return ChatColor.translateAlternateColorCodes('&', text.replace("{server}", server));
  }

  private void tell(CommandSender to, String key, String fallback) {
    to.sendMessage(TextComponent.fromLegacy(msg(key, fallback)));
  }

  private boolean allowed(ProxiedPlayer p) {
    return permission == null || permission.isBlank() || p.hasPermission(permission);
  }

  /** Handles the command before the proxy forwards it, so it works on every server. */
  @EventHandler(priority = EventPriority.LOW)
  public void chat(ChatEvent e) {
    if (e.isCancelled() || !e.isCommand() || !(e.getSender() instanceof ProxiedPlayer p)) return;
    String label = e.getMessage().substring(1).split(" ", 2)[0].toLowerCase(Locale.ROOT);
    if (!commands.contains(label)) return;
    // Already on Deepforge: let the Deepforge plugin handle it (/df menu, /df daily …).
    if (p.getServer() != null && p.getServer().getInfo().getName().equalsIgnoreCase(server)) return;
    e.setCancelled(true);
    send(p);
  }

  private void send(ProxiedPlayer p) {
    if (!allowed(p)) {
      tell(p, "no-permission", "&cDu darfst Deepforge noch nicht betreten.");
      return;
    }
    ServerInfo target = getProxy().getServerInfo(server);
    if (target == null) {
      tell(p, "unknown-server", "&cDer Deepforge-Server ist gerade nicht eingerichtet.");
      getLogger().warning("Server '" + server + "' fehlt in der Proxy-config.yml (servers:).");
      return;
    }
    tell(p, "connecting", "&6Deepforge &7» Du wirst zu Deepforge verbunden …");
    p.connect(
        target,
        (ok, error) -> {
          if (!ok)
            tell(p, "failed", "&cDeepforge ist gerade nicht erreichbar. Versuch es gleich noch einmal.");
        },
        ServerConnectEvent.Reason.COMMAND);
  }

  /** Optional: nobody without the permission gets onto the Deepforge server by other ways. */
  @EventHandler
  public void connect(ServerConnectEvent e) {
    if (!restrict || e.isCancelled()) return;
    if (!e.getTarget().getName().equalsIgnoreCase(server) || allowed(e.getPlayer())) return;
    e.setCancelled(true);
    tell(e.getPlayer(), "no-permission", "&cDu darfst Deepforge noch nicht betreten.");
  }

  /** Suggests the command on servers where the proxy handles it. */
  @EventHandler
  public void tab(TabCompleteEvent e) {
    if (!(e.getSender() instanceof ProxiedPlayer p) || !e.getCursor().startsWith("/")) return;
    if (p.getServer() != null && p.getServer().getInfo().getName().equalsIgnoreCase(server)) return;
    String typed = e.getCursor().substring(1).toLowerCase(Locale.ROOT);
    if (typed.contains(" ") || !allowed(p)) return;
    for (String c : commands) if (c.startsWith(typed)) e.getSuggestions().add("/" + c);
  }

  private final class ReloadCommand extends Command {
    ReloadCommand() {
      super("deepforgeproxy", "deepforge.proxy.admin", "dfproxy");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
      reload();
      sender.sendMessage(
          TextComponent.fromLegacy(
              ChatColor.GOLD + "Deepforge-Proxy neu geladen: /" + String.join(", /", commands) + " -> " + server));
    }
  }
}
