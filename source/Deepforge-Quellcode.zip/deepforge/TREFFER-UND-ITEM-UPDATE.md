# Trefferfeedback und sichtbare Ausrüstungswerte

## Im Spiel

- Normale Monster erhalten echten Rückstoß mit kurzem Zurückweichen und kleinem Aufwärtsschub. Der Hammer stößt am stärksten, der Dolch am schwächsten. Die Verfolgung setzt nach 0,4 Sekunden wieder ein.
- Bosse haben mehr Standfestigkeit. Sie werden ebenfalls verschoben; bei gebrochener Haltung fällt der Rückstoß größer aus. Ihre Bewegung prüft feste Blöcke und Bodenkontakt.
- Eigene Monstermodelle leuchten bei Treffern 0,3 Sekunden rot auf und zucken mit Oberkörper und Kopf. Trefferpartikel und Klang begleiten den Schlag.
- Über dem Gegner steigt eine Schadenszahl auf und verblasst. Weiß: normaler Treffer; Gold: KRIT; Lila: RÜCKEN; Grau: BLOCK. Die Zahl zeigt tatsächlich verlorene Lebenspunkte, einschließlich gegnerischer Abwehr und begrenzt auf verbleibende Gesundheit.
- Jeder Spieler sieht seine eigenen Schadenszahlen. Anzeigen verschwinden nach 1,1 Sekunden; maximal 24 gleichzeitig pro Spieler. Beim Verlassen/Logout und Plugin-Stopp werden sie ebenfalls entfernt.

## Schwert und Bohrer

Inventar öffnen und mit der Maus über das Item fahren. Die Werte enthalten bereits die Boni der ausgerüsteten Gegenstände.

**Waffen:** Qualität, Seltenheit, Verbesserung, Schaden, Krit-Schaden, Krit-Chance, Treffer pro Sekunde, erwarteter Basis-DPS vor Abwehr, Haltungsschaden, Rückstoßstärke, Nahkampfreichweite, Fähigkeit, Fähigkeitsschaden, Ausdauerbedarf und Abklingzeit. Der Rückstoßwert ist eine Impulsstärke, keine garantierte Distanz in Blöcken. Paradefenster und Fähigkeitsboni berücksichtigen einzigartige Ausrüstung.

**Bohrer:** Werkzeugstufe, Abbaumultiplikator im aktuellen Gebiet, Überladung, Chance auf Zusatz-Erz, Reliktchance, Hitze pro Erzblock, Kühlung, Rucksackkapazität, aktiver Modus und Bergbaumodul. Werkzeuganzeige und Bergbaulogik verwenden dieselbe Werteberechnung. Die verbleibenden Rucksackplätze stehen weiterhin aktuell im HUD.

Die Tooltips werden beim Eintritt, Gebietswechsel und Änderungen über die Ausrüstungs-/Upgrade-Menüs erneuert. Irreführende Vanilla-Schwertattribute sind im Tooltip ausgeblendet.

## Handmodelle

Die Handtransformationen berücksichtigen die tatsächlichen Transformationen des installierten Minecraft-1.21.8-Clients: automatische Spiegelung der linken Hand, XYZ-Rotationsreihenfolge und zusätzliche Drehung des Gegenstands an der Spielerhand in dritter Person. Der Bohrer zeigt mit seiner Bohrspitze nach vorne; Schwerter und Stangenwaffen stehen aufrecht. Separate Größen und Positionen für beide Perspektiven verhindern die bisherige seitliche Außenansicht und das Verschwinden unter dem Bildschirmrand.

`Handmodell-Projektion.png` zeigt eine rechnerische Geometrievorschau der ruhenden Egoansicht bei 70° Sichtwinkel. Sie ist kein Screenshot aus dem NoRisk-Client. Andere Sichtwinkel, Client-Mods und tatsächliche Schlag-/Wechselanimationen müssen noch im Spiel visuell abgenommen werden.

## Installiert und geprüft

- 69 Java-Tests erfolgreich, einschließlich Überkill-Anzeige, Rückstoßstaffelung, Krit-/Rücken-/Blockkennzeichnung und Übereinstimmung von Tooltips und tatsächlichen Werten.
- Packprüfung: 233 JSON-Dateien, 67 PNG-Dateien; 35 zusätzliche Treffer-Modellvarianten. 28 Handtransformationen und Sichtfeldgrenzen der Egoansicht geprüft.
- Lokaler Paper-1.21.8-Test: drei Monstergrößen laufen über Schienen und werden anschließend per nativer Physik zurückgestoßen. Bossimpuls und Stopp vor einer festen Wand geprüft. Temporäre Testblöcke und Chunk-Haltevorgaben wiederhergestellt.
- 28 Rigs mit 196 Körperteilen, 112 Posen einschließlich Trefferzuständen, vier Schadensanzeigen und sechs Warnflächen erzeugt/entfernt; keine übrig gebliebenen Testentitäten.
- JAR und Pack installiert, Download und SHA-1 überprüft, Start und Diagnose ohne ERROR-Einträge. Gespeicherter Spielerstand bytegleich zum unmittelbar vor dem Update angelegten Backup.

Zum Testen erneut mit **localhost:25565** verbinden und das aktualisierte Server-Ressourcenpaket laden. Falls nötig `/df pack` aufrufen.
