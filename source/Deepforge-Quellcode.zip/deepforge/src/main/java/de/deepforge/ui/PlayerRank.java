package de.deepforge.ui;

import java.util.function.Predicate;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;

/** Same hierarchy/colors as the user's Varo Rank; permissions are resolved through Bukkit/LP. */
public enum PlayerRank {
  HOSTER(NamedTextColor.WHITE, 2100),
  ADMIN(NamedTextColor.DARK_RED, 2000),
  TEAMLEITUNG(NamedTextColor.RED, 1900),
  DEV(NamedTextColor.AQUA, 1800),
  SRMOD(NamedTextColor.BLUE, 1700),
  MOD(NamedTextColor.DARK_AQUA, 1600),
  HELPER(NamedTextColor.GREEN, 1500),
  BUILDER(NamedTextColor.YELLOW, 1400),
  MEDIA(NamedTextColor.LIGHT_PURPLE, 1300),
  VIP(NamedTextColor.GOLD, 1200),
  SUB(NamedTextColor.DARK_PURPLE, 1100),
  NONE(NamedTextColor.GRAY, 900);
  public final NamedTextColor color;
  public final int order;

  PlayerRank(NamedTextColor color, int order) {
    this.color = color;
    this.order = order;
  }

  public static PlayerRank resolve(boolean hoster, Predicate<String> permission) {
    if (hoster) return HOSTER;
    for (PlayerRank rank : values()) {
      if (rank == HOSTER || rank == NONE) continue;
      String key = rank.name().toLowerCase(java.util.Locale.ROOT);
      if (permission.test("network.rank." + key)
          || permission.test("varo." + key)
          || permission.test("deepforge.rank." + key)) return rank;
    }
    return NONE;
  }

  public Component playerName(String name) {
    Component prefix =
        this == NONE
            ? Component.empty()
            : Component.text(name() + " ", color).decorate(TextDecoration.BOLD);
    return prefix.append(Component.text(name, color).decoration(TextDecoration.BOLD, false));
  }
}
