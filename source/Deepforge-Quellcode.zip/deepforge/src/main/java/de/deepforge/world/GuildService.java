package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import de.deepforge.storage.Profiles;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

/** Guild storage, commands, guild chat and weekly task progress. */
public final class GuildService {
  private final DeepforgePlugin plugin;
  private final Profiles store;
  // Thread-safe snapshot for the async chat renderer.
  private final Map<UUID, String> tags = new ConcurrentHashMap<>();
  private final Set<String> dirty = new HashSet<>();

  public GuildService(DeepforgePlugin plugin, Profiles store) {
    this.plugin = plugin;
    this.store = store;
    Guilds.clear();
    for (Guilds.Guild g : store.guilds()) Guilds.register(g);
    refreshTags();
    Bukkit.getScheduler().runTaskTimer(plugin, this::flush, 1200, 1200);
  }

  public String tag(UUID player) {
    return tags.get(player);
  }

  private void refreshTags() {
    tags.clear();
    for (Guilds.Guild g : Guilds.all())
      for (String id : g.members.keySet()) tags.put(UUID.fromString(id), g.tag);
  }

  private void save(Guilds.Guild g) {
    if (Guilds.all().contains(g)) store.saveGuild(g);
    else store.deleteGuild(g.id);
    dirty.remove(g.id);
    refreshTags();
  }

  public void flush() {
    for (Guilds.Guild g : Guilds.all()) if (dirty.contains(g.id)) store.saveGuild(g);
    dirty.clear();
  }

  private List<Player> online(Guilds.Guild g) {
    List<Player> out = new ArrayList<>();
    for (String id : g.members.keySet()) {
      Player p = Bukkit.getPlayer(UUID.fromString(id));
      if (p != null) out.add(p);
    }
    return out;
  }

  public void say(Guilds.Guild g, String text) {
    for (Player p : online(g))
      p.sendMessage(
          Component.text("[" + g.tag + "] ", NamedTextColor.AQUA)
              .append(Component.text(text, NamedTextColor.GRAY)));
  }

  /** Activity from a member counts towards the guild's weekly tasks. */
  public void progress(Player player, Guilds.Task task, long amount) {
    Guilds.Guild g = Guilds.of(plugin.profile(player));
    if (g == null || amount <= 0) return;
    int done = Guilds.progress(g, task, amount, plugin.today());
    dirty.add(g.id);
    if (done < 0) return;
    save(g);
    say(
        g,
        "Wochenauftrag erfüllt: "
            + task.title
            + "! +600 Gilden-XP, +"
            + 10_000L * g.members.size()
            + " $ in die Kasse. Gildenlevel: "
            + Guilds.level(g));
    for (Player p : online(g)) p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, .7f, 1.1f);
  }

  public void chat(Player sender, String message) {
    Guilds.Guild g = Guilds.of(plugin.profile(sender));
    if (g == null) {
      plugin.tell(sender, "Du bist in keiner Gilde.");
      return;
    }
    for (Player p : online(g))
      p.sendMessage(
          Component.text("[" + g.tag + "] ", NamedTextColor.AQUA)
              .append(Component.text(sender.getName(), NamedTextColor.WHITE))
              .append(Component.text(" » ", NamedTextColor.DARK_GRAY))
              .append(Component.text(message, NamedTextColor.AQUA)));
  }

  /** Runs a guild action on the player's profile, saves both and reports the result. */
  private void act(Player player, java.util.function.Function<Profile, String> action) {
    String result = plugin.change(player, action);
    Guilds.Guild g = Guilds.of(plugin.profile(player));
    if (g != null) save(g);
    else refreshTags();
    for (Guilds.Guild other : new ArrayList<>(Guilds.all())) if (dirty.contains(other.id)) save(other);
    // Dissolved guilds are no longer registered; remove them from storage too.
    for (Guilds.Guild stored : store.guilds())
      if (Guilds.all().stream().noneMatch(x -> x.id.equals(stored.id))) store.deleteGuild(stored.id);
    if (result != null) plugin.items().refresh(player, plugin.profile(player));
  }

  public void command(Player player, String[] args) {
    Profile p = plugin.profile(player);
    Guilds.Guild g = Guilds.of(p);
    String sub = args.length < 2 ? "" : args[1].toLowerCase(Locale.ROOT);
    switch (sub) {
      case "" -> plugin.menus().open(player, g == null ? "guildnone" : "guild");
      case "gründen", "gruenden", "create" -> {
        if (args.length < 4) {
          plugin.tell(player, "Nutzung: /df gilde gründen <Kürzel> <Name …> · Kosten " + Guilds.FOUND_COST + " $");
          return;
        }
        String name = String.join(" ", Arrays.copyOfRange(args, 3, args.length));
        act(player, data -> Guilds.found(data, name, args[2], System.currentTimeMillis()));
      }
      case "einladen", "invite" -> {
        if (g == null || args.length < 3) {
          plugin.tell(player, "Nutzung: /df gilde einladen <Spieler>");
          return;
        }
        Player target = Bukkit.getPlayerExact(args[2]);
        if (target == null) {
          plugin.tell(player, "Der Spieler muss online sein.");
          return;
        }
        String result = Guilds.invite(g, p.id, target.getUniqueId().toString());
        plugin.tell(player, result);
        if (result.startsWith("Einladung")) {
          save(g);
          target.sendMessage(
              Component.text("Gildeneinladung » ", NamedTextColor.AQUA)
                  .append(Component.text(player.getName() + " lädt dich in „" + g.name + "“ [" + g.tag + "] ein. ", NamedTextColor.GRAY))
                  .append(
                      Component.text("[Annehmen]", NamedTextColor.GREEN)
                          .clickEvent(ClickEvent.runCommand("/df gilde annehmen " + g.tag))));
        }
      }
      case "annehmen", "join", "accept" -> {
        Guilds.Guild target = args.length < 3 ? null : Guilds.byTag(args[2]);
        if (target == null) {
          plugin.tell(player, "Nutzung: /df gilde annehmen <Kürzel>");
          return;
        }
        act(player, data -> Guilds.join(data, target));
        if (Guilds.of(plugin.profile(player)) == target) say(target, player.getName() + " ist der Gilde beigetreten!");
      }
      case "verlassen", "leave" -> act(player, Guilds::leave);
      case "entfernen", "kick", "befördern", "befoerdern", "promote", "degradieren", "demote" -> {
        if (g == null || args.length < 3) {
          plugin.tell(player, "Nutzung: /df gilde " + sub + " <Spieler>");
          return;
        }
        String target =
            g.names.entrySet().stream()
                .filter(e -> e.getValue().equalsIgnoreCase(args[2]))
                .map(Map.Entry::getKey)
                .findFirst()
                .orElse(null);
        if (target == null) {
          plugin.tell(player, "Kein Mitglied mit diesem Namen.");
          return;
        }
        String result =
            switch (sub) {
              case "entfernen", "kick" -> Guilds.kick(g, p.id, target);
              case "degradieren", "demote" -> Guilds.promote(g, p.id, target, false);
              default -> Guilds.promote(g, p.id, target, true);
            };
        plugin.tell(player, result);
        save(g);
      }
      case "einzahlen", "deposit" -> {
        long amount;
        try {
          amount = Long.parseLong(args.length < 3 ? "" : args[2].replace(".", ""));
        } catch (NumberFormatException e) {
          plugin.tell(player, "Nutzung: /df gilde einzahlen <Betrag>");
          return;
        }
        act(player, data -> Guilds.deposit(data, amount));
      }
      case "chat", "c" -> chat(player, String.join(" ", Arrays.copyOfRange(args, 2, args.length)));
      default -> plugin.tell(player, "Gilde: /df gilde [gründen|einladen|annehmen|verlassen|einzahlen|entfernen|befördern|degradieren|chat]");
    }
  }

  /** Menu actions: deposit shortcuts and building upgrades. */
  public void menuAction(Player player, String action) {
    Profile p = plugin.profile(player);
    Guilds.Guild g = Guilds.of(p);
    if (g == null) return;
    if (action.startsWith("guild:deposit:")) {
      long amount = Long.parseLong(action.substring(14));
      act(player, data -> Guilds.deposit(data, Math.min(amount, data.money)));
    } else if (action.startsWith("guild:build:")) {
      Guilds.Building b = Guilds.Building.valueOf(action.substring(12));
      String result = Guilds.build(g, p.id, b);
      plugin.tell(player, result);
      save(g);
      if (result.contains("ausgebaut")) {
        say(g, player.getName() + " hat " + b.title + " auf Stufe " + g.buildings[b.ordinal()] + " ausgebaut!");
        for (Player m : online(g)) plugin.combat().applyStats(m);
      }
    } else if (action.equals("guild:leave")) act(player, Guilds::leave);
  }
}
