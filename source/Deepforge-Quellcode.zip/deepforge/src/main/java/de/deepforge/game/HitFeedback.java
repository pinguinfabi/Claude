package de.deepforge.game;

import java.util.Locale;

public final class HitFeedback {
  public static double knockback(String style, boolean boss, boolean broken) {
    double strength =
        switch (style) {
          case "hammer" -> .62;
          case "spear" -> .46;
          case "dagger" -> .24;
          case "crossbow" -> .32;
          default -> .40;
        };
    return strength * (boss ? (broken ? .45 : .18) : 1);
  }

  public static double applied(double health, double damage) {
    return Math.min(Math.max(0, health), Math.max(0, damage));
  }

  public static String text(double damage, boolean crit, boolean backstab, boolean guarded) {
    return String.format(Locale.GERMAN, "−%.1f", damage)
        + (crit ? " ✦ KRIT" : "")
        + (backstab ? " RÜCKEN" : guarded ? " BLOCK" : "");
  }

  private HitFeedback() {}
}
