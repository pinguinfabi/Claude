package de.deepforge.game;

import java.util.*;

public final class EquipmentLore {
  private static String f(double n) {
    return String.format(Locale.GERMAN, "%.2f", n);
  }

  public static List<String> lines(String type, Profile p, int zone) {
    Gear.Stats s = Gear.stats(p);
    List<String> lines = new ArrayList<>();
    if (type.equals("sword")) {
      Gear.Item weapon = Gear.equipped(p, Gear.Slot.WEAPON);
      String style = weapon == null ? "sword" : weapon.style;
      lines.add(
          weapon == null
              ? "STARTWAFFE · Training " + p.sword
              : weapon.rarity.title + " · Qualität " + weapon.quality + " % · +" + weapon.level);
      lines.add("KAMPFWERTE · inklusive ausgerüsteter Boni");
      lines.add(
          "Schaden: "
              + f(RapidCombat.damage(s))
              + " LP | Krit: "
              + f(RapidCombat.damage(s) * s.critDamage())
              + " LP");
      lines.add("Ohne Schlagaufladung | Krit-Chance: " + f(s.crit() * 100) + " %");
      lines.add("Tempofaktor: " + f(s.speed() / 1.6) + "× · bereits im Trefferschaden");
      lines.add(
          "Ø DPS bei 4 Klicks/s: "
              + f(RapidCombat.damage(s) * 4 * (1 + s.crit() * (s.critDamage() - 1)))
              + " vor Gegnerabwehr");
      lines.add(
          "Haltungsschaden: "
              + f(RapidCombat.posture(s))
              + " | Rückstoß: "
              + f(HitFeedback.knockback(style, false, false)));
      lines.add("Nahkampfreichweite: " + (style.equals("spear") ? 4 : 3) + " Blöcke");
      double abilityMultiplier =
          (style.equals("hammer") ? 2.1 : 1.5)
              * (style.equals("hammer") && Gear.hasEffect(p, 4)
                  ? 1.35
                  : style.equals("spear") && Gear.hasEffect(p, 3) ? 1.4 : 1);
      lines.add(
          "Fähigkeit: "
              + switch (style) {
                case "hammer" -> "Schmettern · Radius 4 Blöcke";
                case "spear" -> "Durchstoß · 8 Blöcke";
                case "crossbow" -> "Bolzenstoß · 13 Blöcke";
                case "dagger" ->
                    "Klingenwirbel · Rückenbonus +"
                        + Math.round(WeaponRules.rearBonus(weapon) * 100)
                        + " %";
                default -> "Konterhieb · Radius 4 Blöcke";
              });
      lines.add("Fähigkeitsschaden: " + f(s.damage() * abilityMultiplier) + " LP vor Krit/Abwehr");
      if (style.equals("sword") || Gear.hasEffect(p, 5))
        lines.add("Paradefenster: " + (Gear.hasEffect(p, 5) ? "1,6" : "1,1") + " s");
      lines.add("35 Ausdauer · 6 s Abklingzeit | Ausweichen: 25 Ausdauer");
      if (weapon != null) {
        if (weapon.signature >= 0) lines.add(Gear.effect(weapon.signature));
        if (weapon.archetype >= 0) lines.add(AdventureGear.lore(weapon));
      }
      lines.add("Rechtsklick: Fähigkeit · Sneak+Rechtsklick: Ausweichen");
      lines.add("Ausrüstung und Beute: /df loot");
    } else if (type.equals("tool")) {
      ToolStats t = ToolStats.of(p, zone, false);
      Gear.Item module = Gear.equipped(p, Gear.Slot.TOOL);
      lines.add("BERGBAUWERTE · " + Zone.at(zone).title);
      lines.add("Werkzeugstufe: " + p.tool + " | Abbaumultiplikator: " + f(t.speed()) + "×");
      lines.add("Überladung: " + f(t.speed() * 2) + "× für 8 s · 45 s Abklingzeit");
      lines.add(
          "Zusätzliches Erz: "
              + f(t.extraOre() * 100)
              + " % | Reliktfund: "
              + f(t.relicChance() * 100)
              + " %");
      lines.add("Hitze pro Erzblock: " + f(t.heatPerOre()) + " / 100");
      lines.add("Kühlung in Ruhe: " + f(t.cooling()) + "/s | beim Abbauen: 0,50/s");
      lines.add("Rucksackkapazität: " + t.capacity() + " Erze");
      lines.add("Modus: " + new String[] {"Ertrag", "Tempo", "Reliktsuche"}[p.module]);
      lines.add(
          String.format(
              Locale.GERMAN,
              "Glück: %.1f× · %d %% Chance auf Verdopplung des Ertrags",
              OreYield.multiplier(p.oreLuck),
              p.oreLuck * 10));
      lines.add(
          "Ausrüstungsboni: +"
              + f(s.mining() * 100)
              + " % Tempo | +"
              + f(s.yield() * 100)
              + " % Extra-Erz");
      lines.add("Bergbaumodul: " + (module == null ? "Keines" : module.name + " +" + module.level));
      if (module != null && module.archetype >= 0) lines.add(AdventureGear.lore(module));
      lines.add("Rechtsklick: Überladung · Sneak+Rechtsklick: Scanner");
    } else lines.add("Rechtsklick: Betrieb, Werte, Ausrüstung und Jagdaufträge");
    if (!type.equals("book"))
      for (int set = 0; set < 3; set++) {
        int pieces = AdventureGear.setCount(p, set);
        if (pieces > 0)
          lines.add(
              "Set "
                  + AdventureGear.SETS[set]
                  + ": "
                  + pieces
                  + "/4 · "
                  + (pieces >= 4
                      ? "beide Boni aktiv"
                      : pieces >= 2 ? "2er-Bonus aktiv" : "noch kein Bonus"));
      }
    return lines;
  }

  private EquipmentLore() {}
}
