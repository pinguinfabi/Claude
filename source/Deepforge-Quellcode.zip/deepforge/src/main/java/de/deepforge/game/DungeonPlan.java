package de.deepforge.game;

import java.util.*;

/**
 * A generated dungeon: 5 to 7 rooms on a winding path of grid cells, connected by corridors with
 * bends and stairs, 1 to 2 optional side rooms, 2 to 3 puzzles out of eight and the waves spread
 * over the rooms. Everything follows from the seed; coordinates are local to the instance (x east,
 * z south, floor offsets in blocks). Pure logic, so layouts can be checked in tests.
 */
public final class DungeonPlan {
  public enum Shape {
    HALL,
    PILLARS,
    BRIDGE,
    CRYPT,
    ARENA,
    GAUNTLET,
    CHAMBER
  }

  public enum Role {
    START,
    COMBAT,
    PUZZLE,
    BOSS,
    SIDE
  }

  public enum Puzzle {
    RUNES("Runenfolge"),
    SEALS("Gruppensiegel"),
    LEVERS("Hebelrätsel"),
    PLATES("Plattenlauf"),
    LIGHT("Lichtstrahl"),
    TRAPS("Fallengang"),
    BELLS("Glockenmelodie"),
    MIMICS("Falsche Truhen");

    public final String title;

    Puzzle(String title) {
      this.title = title;
    }
  }

  public enum Side {
    CHALLENGE,
    PRISON,
    TREASURE
  }

  public enum Dir {
    N(0, -1),
    E(1, 0),
    S(0, 1),
    W(-1, 0);

    public final int dx, dz;

    Dir(int dx, int dz) {
      this.dx = dx;
      this.dz = dz;
    }

    public Dir opposite() {
      return values()[(ordinal() + 2) % 4];
    }

    public boolean alongX() {
      return dx != 0;
    }
  }

  /** What a block of the dungeon is; the world side turns this into real blocks. */
  public enum Paint {
    AIR,
    WALL,
    FLOOR,
    CEILING,
    PATH,
    STAIR_N,
    STAIR_E,
    STAIR_S,
    STAIR_W,
    LIGHT,
    ACCENT,
    PILLAR,
    PIT_FLOOR,
    DECOR,
    // 0.17.0 architecture: vaults, ribs, plinths and hanging lights.
    VAULT,
    RIB,
    TRIM,
    CHAIN,
    LANTERN,
    WEB,
    // 0.23.0: floor pattern in a colour that stands out from the floor.
    INLAY
  }

  public static final int CELL = 44, COLUMNS = 1, CORRIDOR_HEIGHT = 4, PIT_DEPTH = 4;

  public static final class Room {
    public final int index;
    public final int gx, gz, cx, cz, hw, hd, floor, height;
    public final Shape shape;
    public final Role role;
    public final Dir in;
    public Dir out, sideDoor;
    public int waves;
    public Puzzle puzzle;
    public Side side;
    // Side rooms: the main room they hang off; main rooms: index of their side room or -1.
    public int parent = -1, sideRoom = -1;
    // Main room that holds the key barrel for the treasure room.
    public boolean keyBarrel;

    Room(
        int index,
        int gx,
        int gz,
        int cx,
        int cz,
        int hw,
        int hd,
        int floor,
        int height,
        Shape shape,
        Role role,
        Dir in) {
      this.index = index;
      this.gx = gx;
      this.gz = gz;
      this.cx = cx;
      this.cz = cz;
      this.hw = hw;
      this.hd = hd;
      this.floor = floor;
      this.height = height;
      this.shape = shape;
      this.role = role;
      this.in = in;
    }

    public int doorX(Dir d) {
      return cx + d.dx * hw;
    }

    public int doorZ(Dir d) {
      return cz + d.dz * hd;
    }

    /** Interior (walkable area inside the walls). */
    public boolean inside(double x, double z) {
      return x >= cx - hw + 1 && x < cx + hw && z >= cz - hd + 1 && z < cz + hd;
    }

    public boolean box(int x, int z) {
      return Math.abs(x - cx) <= hw && Math.abs(z - cz) <= hd;
    }

    /** Solid filler outside the round arena. */
    boolean outsideArena(int x, int z) {
      if (shape != Shape.ARENA) return false;
      double r = Math.min(hw, hd) - .5;
      return (x - cx) * (x - cx) + (z - cz) * (z - cz) > r * r;
    }

    /** The pit of a bridge room: everything in the inner area except the cross of bridges. */
    public boolean pit(int x, int z) {
      if (shape != Shape.BRIDGE) return false;
      int dx = Math.abs(x - cx), dz = Math.abs(z - cz);
      return dx <= hw - 4 && dz <= hd - 4 && dx > 2 && dz > 2;
    }
  }

  /** One centerline block of a corridor. */
  public record Tile(int x, int z, int floor, Dir heading, boolean stair, boolean turn) {}

  public static final class Corridor {
    public final int index, from, to;
    public final List<Tile> tiles;

    Corridor(int index, int from, int to, List<Tile> tiles) {
      this.index = index;
      this.from = from;
      this.to = to;
      this.tiles = List.copyOf(tiles);
    }
  }

  public final long seed;
  public final List<Room> rooms = new ArrayList<>();
  public final List<Corridor> corridors = new ArrayList<>();
  // Number of rooms on the main path (rooms 0..mainRooms-1); side rooms follow.
  public final int mainRooms;
  private final Map<Long, int[]> corridorCells = new HashMap<>(); // interior: {corridor, floor, stairDir+1}
  private final Map<Long, Integer> corridorWalls = new HashMap<>(); // wall ring: floor
  public final int minX, maxX, minZ, maxZ;

  private static long key(int x, int z) {
    return ((long) x << 32) ^ (z & 0xffffffffL);
  }

  private DungeonPlan(long seed, int totalWaves, int level) {
    this.seed = seed;
    Random r = new Random(seed);
    int count = 5 + r.nextInt(3) + (level >= 15 && r.nextBoolean() ? 1 : 0);
    count = Math.min(count, 8);
    // Walk the grid: mostly north, sometimes sideways, never back onto a used cell.
    List<int[]> cells = new ArrayList<>();
    Set<Long> used = new HashSet<>();
    cells.add(new int[] {0, 0});
    used.add(key(0, 0));
    List<Dir> dirs = new ArrayList<>();
    while (cells.size() < count) {
      int[] at = cells.getLast();
      List<Dir> options = new ArrayList<>();
      for (Dir d : List.of(Dir.N, Dir.N, Dir.E, Dir.W)) {
        int gx = at[0] + d.dx, gz = at[1] - d.dz;
        if (Math.abs(gx) > COLUMNS || used.contains(key(gx, gz))) continue;
        // Never two sideways steps in a row: keeps the path from boxing itself in.
        if (d != Dir.N && !dirs.isEmpty() && dirs.getLast() != Dir.N) continue;
        options.add(d);
      }
      Dir d = options.isEmpty() ? Dir.N : options.get(r.nextInt(options.size()));
      int gx = at[0] + d.dx, gz = at[1] - d.dz;
      cells.add(new int[] {gx, gz});
      used.add(key(gx, gz));
      dirs.add(d);
    }
    mainRooms = count;

    // Tasks: 2 or 3 puzzles on the middle rooms, a gauntlet only where the path runs straight.
    List<Puzzle> pool = new ArrayList<>(List.of(Puzzle.values()));
    Collections.shuffle(pool, r);
    int puzzleCount = Math.min(count - 2, count >= 6 ? 3 : 2);
    List<Integer> middle = new ArrayList<>();
    for (int i = 1; i < count - 1; i++) middle.add(i);
    Collections.shuffle(middle, r);
    Puzzle[] puzzles = new Puzzle[count];
    for (int n = 0, placed = 0; n < middle.size() && placed < puzzleCount; n++) {
      int i = middle.get(n);
      boolean straight = dirs.get(i - 1) == dirs.get(i);
      Puzzle pick = null;
      for (Puzzle candidate : pool)
        if (candidate != Puzzle.TRAPS || straight) {
          pick = candidate;
          break;
        }
      if (pick == null) continue;
      pool.remove(pick);
      puzzles[i] = pick;
      placed++;
    }

    // Waves: one in the start room, the rest over the middle rooms (at most two each), the boss
    // wave and anything left in the boss room.
    int[] waves = new int[count];
    int left = Math.max(1, totalWaves - 1);
    waves[0] = 1;
    left--;
    List<Integer> order = new ArrayList<>();
    for (int i = 1; i < count - 1; i++) if (puzzles[i] == null) order.add(i);
    for (int i = 1; i < count - 1; i++)
      if (puzzles[i] != null && puzzles[i] != Puzzle.TRAPS) order.add(i);
    for (int pass = 0; pass < 2 && left > 0; pass++)
      for (int i : order)
        if (left > 0 && waves[i] < 2 && (pass == 1 || puzzles[i] == null)) {
          waves[i]++;
          left--;
        }
    waves[count - 1] = 1 + left;

    // Rooms.
    int floor = 0;
    for (int i = 0; i < count; i++) {
      int[] c = cells.get(i);
      Dir in = i == 0 ? null : dirs.get(i - 1).opposite();
      Role role =
          i == 0
              ? Role.START
              : i == count - 1 ? Role.BOSS : waves[i] > 0 ? Role.COMBAT : Role.PUZZLE;
      Shape shape;
      int hw, hd, height = 12;
      if (role == Role.BOSS) {
        shape = Shape.ARENA;
        hw = hd = 16;
      } else if (puzzles[i] == Puzzle.TRAPS) {
        shape = Shape.GAUNTLET;
        boolean alongX = dirs.get(i).alongX();
        hw = alongX ? 16 : 5;
        hd = alongX ? 5 : 16;
        height = 8;
      } else if (role == Role.START) {
        shape = Shape.HALL;
        hw = hd = 14;
      } else if (role == Role.COMBAT) {
        shape = List.of(Shape.HALL, Shape.PILLARS, Shape.CRYPT).get(r.nextInt(3));
        hw = 13 + r.nextInt(4);
        hd = 13 + r.nextInt(4);
        if (shape == Shape.CRYPT) height = 8;
      } else {
        shape = List.of(Shape.CHAMBER, Shape.BRIDGE, Shape.PILLARS).get(r.nextInt(3));
        hw = 12 + r.nextInt(3);
        hd = 12 + r.nextInt(3);
      }
      // Puzzles need a clear middle: no pit under them.
      if (puzzles[i] != null && shape == Shape.BRIDGE) shape = Shape.CHAMBER;
      if (i > 0) floor = Math.clamp(floor + r.nextInt(7) - 3, -3, 3);
      int jx = r.nextInt(5) - 2, jz = r.nextInt(5) - 2;
      Room room =
          new Room(
              i, c[0], c[1], c[0] * CELL + jx, -c[1] * CELL + jz, hw, hd, i == 0 ? 0 : floor,
              height, shape, role, in);
      room.waves = waves[i];
      room.puzzle = puzzles[i];
      if (i > 0) rooms.get(i - 1).out = dirs.get(i - 1);
      rooms.add(room);
    }

    // Side rooms: challenge, prison or treasure on free cells next to middle rooms.
    List<Side> sides = new ArrayList<>(List.of(Side.values()));
    Collections.shuffle(sides, r);
    int sideCount = 1 + r.nextInt(2);
    List<Integer> hosts = new ArrayList<>();
    for (int i = 0; i < count - 1; i++) hosts.add(i);
    Collections.shuffle(hosts, r);
    for (int host : hosts) {
      if (rooms.size() - count >= sideCount || sides.isEmpty()) break;
      Room main = rooms.get(host);
      if (main.shape == Shape.GAUNTLET) continue;
      List<Dir> free = new ArrayList<>();
      for (Dir d : Dir.values()) {
        if (d == main.in || d == main.out) continue;
        int gx = main.gx + d.dx, gz = main.gz - d.dz;
        if (Math.abs(gx) > COLUMNS || gz < -1 || used.contains(key(gx, gz))) continue;
        free.add(d);
      }
      if (free.isEmpty()) continue;
      Side side = sides.removeFirst();
      // The treasure needs a key from an earlier main room.
      if (side == Side.TREASURE && host == 0) {
        sides.add(side);
        continue;
      }
      Dir d = free.get(r.nextInt(free.size()));
      int gx = main.gx + d.dx, gz = main.gz - d.dz;
      used.add(key(gx, gz));
      Room room =
          new Room(
              rooms.size(),
              gx,
              gz,
              gx * CELL + d.dx * -8,
              -gz * CELL - d.dz * 8,
              9,
              9,
              main.floor,
              8,
              Shape.CHAMBER,
              Role.SIDE,
              d.opposite());
      room.side = side;
      room.parent = host;
      main.sideDoor = d;
      main.sideRoom = room.index;
      rooms.add(room);
      if (side == Side.TREASURE) rooms.get(r.nextInt(host)).keyBarrel = true;
    }

    // Corridors along the main path, then to the side rooms.
    for (int i = 0; i + 1 < count; i++) connect(rooms.get(i), rooms.get(i + 1), rooms.get(i).out, r);
    for (Room side : rooms.subList(count, rooms.size()))
      connect(rooms.get(side.parent), side, side.in.opposite(), r);

    int x0 = Integer.MAX_VALUE, x1 = Integer.MIN_VALUE, z0 = Integer.MAX_VALUE, z1 = Integer.MIN_VALUE;
    for (Room room : rooms) {
      x0 = Math.min(x0, room.cx - room.hw);
      x1 = Math.max(x1, room.cx + room.hw);
      z0 = Math.min(z0, room.cz - room.hd);
      z1 = Math.max(z1, room.cz + room.hd);
    }
    minX = x0;
    maxX = x1;
    minZ = z0;
    maxZ = z1;
  }

  public static DungeonPlan generate(long seed, int totalWaves, int level) {
    return new DungeonPlan(seed, totalWaves, level);
  }

  /** Tiefengang (0.9.3): one large arena, no corridors, no puzzles – the waves never stop. */
  public static DungeonPlan arena(long seed) {
    return new DungeonPlan(seed);
  }

  private DungeonPlan(long seed) {
    this.seed = seed;
    Room room = new Room(0, 0, 0, 0, 0, 16, 16, 0, 12, Shape.ARENA, Role.BOSS, null);
    room.waves = 1;
    rooms.add(room);
    mainRooms = 1;
    minX = -16;
    maxX = 16;
    minZ = -16;
    maxZ = 16;
  }

  /** Corridor from room a (door d) to room b (door opposite d) with bends and stairs. */
  private void connect(Room a, Room b, Dir d, Random r) {
    int sx = a.doorX(d), sz = a.doorZ(d);
    Dir back = d.opposite();
    int ex = b.doorX(back), ez = b.doorZ(back);
    // Distance between the two door walls along the heading, and the lateral offset.
    int along = d.alongX() ? (ex - sx) * d.dx : (ez - sz) * d.dz;
    int lateral0 = d.alongX() ? sz : sx, lateral1 = d.alongX() ? ez : ex;
    int rise = b.floor - a.floor;
    int steps = Math.abs(rise);
    // A detour to one side makes the corridor wind; it stays inside the gap between the rooms.
    int detour = along >= 12 && r.nextInt(3) > 0 ? (r.nextBoolean() ? 1 : -1) * (4 + r.nextInt(5)) : 0;
    int mid = (lateral0 + lateral1) / 2 + detour;
    int firstLeg = Math.max(2 + steps + 1, Math.min(along - 4, 3 + r.nextInt(Math.max(1, along / 3))));
    int secondLeg = Math.max(firstLeg + 2, along - 3 - r.nextInt(2));
    if (secondLeg >= along - 1) secondLeg = along - 2;
    if (detour == 0) secondLeg = firstLeg;
    List<Tile> tiles = new ArrayList<>();
    int floor = a.floor, lat = lateral0;
    Dir side0 = Dir.values()[0];
    for (int s = 0; s <= along; s++) {
      boolean stair = false;
      if (s >= 2 && s < 2 + steps) {
        floor += Integer.signum(rise);
        stair = rise > 0;
      }
      // Lateral shifts happen at the bends: at firstLeg to "mid", at secondLeg to the target.
      int target = s < firstLeg ? lateral0 : s < secondLeg ? mid : lateral1;
      while (lat != target) {
        int step = Integer.signum(target - lat);
        Dir sideways = d.alongX() ? (step > 0 ? Dir.S : Dir.N) : (step > 0 ? Dir.E : Dir.W);
        add(tiles, d, s, sx, sz, lat, floor, sideways, false, true);
        lat += step;
        side0 = sideways;
      }
      add(tiles, d, s, sx, sz, lat, floor, d, stair, false);
    }
    // A descending stair is the same block seen from the other side.
    List<Tile> fixed = new ArrayList<>();
    for (int i = 0; i < tiles.size(); i++) {
      Tile t = tiles.get(i);
      if (rise < 0 && i > 0 && tiles.get(i - 1).floor() > t.floor())
        fixed.set(i - 1, new Tile(tiles.get(i - 1).x(), tiles.get(i - 1).z(), tiles.get(i - 1).floor(), back, true, false));
      fixed.add(t);
    }
    Corridor c = new Corridor(corridors.size(), a.index, b.index, fixed);
    corridors.add(c);
    mark(c);
  }

  private static void add(
      List<Tile> tiles, Dir d, int s, int sx, int sz, int lat, int floor, Dir heading,
      boolean stair, boolean turn) {
    int x = d.alongX() ? sx + s * d.dx : lat, z = d.alongX() ? lat : sz + s * d.dz;
    if (!tiles.isEmpty() && tiles.getLast().x() == x && tiles.getLast().z() == z) return;
    tiles.add(new Tile(x, z, floor, heading, stair, turn));
  }

  private void mark(Corridor c) {
    for (Tile t : c.tiles) {
      int stair = t.stair() ? t.heading().ordinal() + 1 : 0;
      for (int a = -1; a <= 1; a++)
        for (int b = -1; b <= 1; b++) {
          // Straight tiles claim their own row only; bends claim the full 3x3 corner.
          boolean lane = t.turn() || (t.heading().alongX() ? a == 0 : b == 0);
          if (!lane) continue;
          corridorCells.putIfAbsent(key(t.x() + a, t.z() + b), new int[] {c.index, t.floor(), stair});
        }
    }
    for (Tile t : c.tiles)
      for (int a = -2; a <= 2; a++)
        for (int b = -2; b <= 2; b++) {
          long k = key(t.x() + a, t.z() + b);
          if (!corridorCells.containsKey(k)) corridorWalls.putIfAbsent(k, t.floor());
        }
    // Close gaps: a straight tile's diagonal neighbours next to a bend are interior too.
    for (Tile t : c.tiles)
      for (int a = -1; a <= 1; a++)
        for (int b = -1; b <= 1; b++) {
          long k = key(t.x() + a, t.z() + b);
          if (!corridorCells.containsKey(k)) corridorWalls.putIfAbsent(k, t.floor());
        }
  }

  /** Room whose box (walls included) contains the column, or null. */
  public Room roomAt(int x, int z) {
    for (Room room : rooms) if (room.box(x, z)) return room;
    return null;
  }

  /** Corridor index for an interior corridor column, else -1. */
  public int corridorAt(int x, int z) {
    int[] cell = corridorCells.get(key(x, z));
    return cell == null ? -1 : cell[0];
  }

  public int corridorFloor(int x, int z) {
    int[] cell = corridorCells.get(key(x, z));
    return cell == null ? Integer.MIN_VALUE : cell[1];
  }

  /** Walkable space: room interior or corridor, at a sensible height. */
  public boolean contains(double x, double y, double z) {
    int bx = (int) Math.floor(x), bz = (int) Math.floor(z);
    Room room = roomAt(bx, bz);
    if (room != null && room.inside(x, z))
      return y >= room.floor - 1 - (room.shape == Shape.BRIDGE ? PIT_DEPTH : 0)
          && y < room.floor + room.height;
    int[] cell = corridorCells.get(key(bx, bz));
    return cell != null && y >= cell[1] - 1 && y < cell[1] + CORRIDOR_HEIGHT + 1;
  }

  /**
   * What goes at a local block, or null when the dungeon does not touch it. Rooms win over
   * corridors; a corridor running into a room wall becomes its door.
   */
  public Paint paint(int x, int y, int z) {
    Room room = roomAt(x, z);
    if (room != null) return paintRoom(room, x, y, z);
    int[] cell = corridorCells.get(key(x, z));
    if (cell != null) {
      int f = cell[1];
      if (y < f - 1 || y > f + CORRIDOR_HEIGHT + 1) return null;
      if (y == f - 1) {
        if (cell[2] > 0) return Paint.values()[Paint.STAIR_N.ordinal() + cell[2] - 1];
        return Paint.PATH;
      }
      // Chamfered vault: the outer lanes lose their top row, so the gallery reads arched.
      if (y == f + CORRIDOR_HEIGHT - 1 && corridorEdge(x, z)) return Paint.VAULT;
      if (y < f + CORRIDOR_HEIGHT) return Paint.AIR;
      return Math.floorMod(x + z, 4) == 0 ? Paint.RIB : Paint.CEILING;
    }
    Integer wall = corridorWalls.get(key(x, z));
    if (wall != null && y >= wall - 2 && y <= wall + CORRIDOR_HEIGHT + 1) {
      if (y == wall + 2 && Math.floorMod(x + z, 6) == 0) return Paint.LIGHT;
      // Rib arches every four blocks along every gallery.
      if (Math.floorMod(x + z, 4) == 0 && y >= wall && y <= wall + CORRIDOR_HEIGHT) return Paint.RIB;
      return y == wall ? Paint.TRIM : Paint.WALL;
    }
    return null;
  }

  private boolean corridorEdge(int x, int z) {
    return !corridorCells.containsKey(key(x + 1, z))
        || !corridorCells.containsKey(key(x - 1, z))
        || !corridorCells.containsKey(key(x, z + 1))
        || !corridorCells.containsKey(key(x, z - 1));
  }

  /**
   * 0.17.0: dungeon architecture inside the unchanged floor plan (positions of waves, barrels and
   * puzzles stay valid). Pilasters every six blocks with pointed arches between them, a coved
   * vault, ribs across the ceiling, a plinth, a runner from door to door, chandeliers on chains and
   * cobwebs high in the corners. Nothing new below head height except the slim pilasters.
   */
  private Paint architecture(Room room, int x, int y, int z) {
    int f = room.floor, top = f + room.height, dx = x - room.cx, dz = z - room.cz;
    int dW = room.hw - Math.abs(dx), dD = room.hd - Math.abs(dz), d = Math.min(dW, dD);
    if (room.shape == Shape.ARENA) return null;
    int along = dW <= dD ? dz : dx;
    boolean doorLane = Math.abs(along) <= 2;
    int fromPilaster = Math.min(Math.floorMod(along - 3, 6), 6 - Math.floorMod(along - 3, 6));
    if (d == 1 && dW != dD && doorBehind(room, dx, dz, dW < dD)) {
      // 0.23.0: every door gets a portal – a lintel between its pilasters and a lamp above.
      if (Math.abs(along) <= 3 && y == f + CORRIDOR_HEIGHT) return Paint.TRIM;
      if (along == 0 && y == f + CORRIDOR_HEIGHT + 1) return Paint.LIGHT;
      if (Math.abs(along) == 1 && y == f + CORRIDOR_HEIGHT + 1) return Paint.ACCENT;
    }
    if (d == 1) {
      if (fromPilaster == 0 && !doorLane && y >= f && y < top)
        // Base and capital, so the pilasters read as columns and not as stripes.
        return y == f || y == top - 4 ? Paint.TRIM : Paint.PILLAR;
      if (y >= top - 2 - (fromPilaster <= 1 ? 1 : 0)) return Paint.VAULT;
    }
    if (d == 2 && y >= top - 1) return Paint.VAULT;
    if (dW == 2 && dD == 2 && y == top - 2) return Paint.WEB;
    if (y == top - 1 && d >= 3 && (Math.floorMod(dx, 6) == 3 || Math.floorMod(dz, 6) == 3)) return Paint.RIB;
    // Chandeliers: centre and the four quarter points, never over a door lane.
    int hx = room.hw / 2, hz = room.hd / 2;
    boolean hang =
        dx == 0 && dz == 0 && room.role != Role.BOSS
            || Math.abs(dx) == hx && Math.abs(dz) == hz && hx > 4 && hz > 4;
    if (hang && room.height >= 8 && y >= top - 3 && y < top) return Paint.CHAIN;
    if (hang && room.height >= 8 && y == top - 4) return Paint.LANTERN;
    return null;
  }

  /** Whether the wall right behind this spot (one block inside the wall) has a door. */
  private boolean doorBehind(Room room, int dx, int dz, boolean eastWest) {
    int wx = room.cx + (eastWest ? Integer.signum(dx) * room.hw : 0);
    int wz = room.cz + (eastWest ? 0 : Integer.signum(dz) * room.hd);
    return corridorCells.containsKey(key(wx, wz));
  }

  /**
   * 0.23.0 floor: a flagstone grid in line with the pilasters and a rhombus around the centre
   * medallion. Only the floor layer changes, everything stays walkable.
   */
  private static Paint floorPattern(Room room, int dx, int dz) {
    int r = Math.abs(dx) + Math.abs(dz);
    if (r == 5 || r == 6 && Math.min(room.hw, room.hd) >= 12) return Paint.INLAY;
    boolean gx = Math.floorMod(dx, 6) == 3, gz = Math.floorMod(dz, 6) == 3;
    if (gx && gz) return Paint.ACCENT;
    if (gx || gz) return Paint.INLAY;
    return Paint.FLOOR;
  }

  private Paint paintRoom(Room room, int x, int y, int z) {
    int f = room.floor, dx = x - room.cx, dz = z - room.cz;
    int bottom = f - 1 - (room.shape == Shape.BRIDGE ? PIT_DEPTH : 0);
    if (y < bottom || y > f + room.height) return null;
    boolean wall = Math.abs(dx) == room.hw || Math.abs(dz) == room.hd;
    if (wall) {
      int[] door = corridorCells.get(key(x, z));
      if (door != null && y >= f && y < f + CORRIDOR_HEIGHT) return Paint.AIR;
      if (door != null && y == f - 1) return Paint.PATH;
      if (y == f + 4 && Math.floorMod(Math.abs(dx) + Math.abs(dz), 6) == 0) return Paint.LIGHT;
      if (y == f) return Paint.TRIM;
      return y >= f + 2 && y <= f + 6 && Math.floorMod(dx + dz, 8) == 0 ? Paint.ACCENT : Paint.WALL;
    }
    if (y == f + room.height) return Paint.CEILING;
    if (room.outsideArena(x, z)) return y < f ? Paint.FLOOR : Paint.WALL;
    if (y >= f && !room.pit(x, z)) {
      Paint arch = architecture(room, x, y, z);
      if (arch != null) return arch;
    }
    if (room.pit(x, z)) {
      if (y == bottom) return Paint.PIT_FLOOR;
      return y < f + room.height ? Paint.AIR : Paint.CEILING;
    }
    if (y < f - 1) return null;
    if (y == f - 1) {
      if (Math.abs(dx) <= 1 && Math.abs(dz) <= 1) return Paint.ACCENT;
      if ((Math.abs(dx) == room.hw - 2 || Math.abs(dz) == room.hd - 2)
          && Math.abs(dx) <= room.hw - 2
          && Math.abs(dz) <= room.hd - 2) return Paint.ACCENT;
      // Runner from door to door.
      if (Math.abs(dx) <= 1 || Math.abs(dz) <= 1) return Paint.PATH;
      return floorPattern(room, dx, dz);
    }
    // Decoration only in the outer ring and never in front of a door.
    boolean ring = Math.abs(dx) >= room.hw - 4 || Math.abs(dz) >= room.hd - 4;
    boolean doorLane = Math.abs(dx) <= 2 || Math.abs(dz) <= 2;
    if (ring && !doorLane && room.role != Role.SIDE) {
      if (room.shape == Shape.PILLARS
          && Math.floorMod(dx, 6) == 0
          && Math.floorMod(dz, 6) == 0
          && y < f + room.height) return y == f || y == f + room.height - 4 ? Paint.TRIM : Paint.PILLAR;
      if (room.shape == Shape.HALL
          && (Math.abs(dx) == room.hw - 3 || Math.abs(dz) == room.hd - 3)
          && Math.floorMod(dx + dz, 8) == 0
          && y < f + room.height - 1) return y == f + 6 ? Paint.LIGHT : Paint.PILLAR;
      if (room.shape == Shape.CRYPT && y == f && Math.floorMod(dx * 3 + dz, 7) == 0)
        return Paint.DECOR;
    }
    return Paint.AIR;
  }

  /** Everything the builder has to visit, as boxes {x0, z0, y0, x1, z1, y1}. */
  public List<int[]> boxes() {
    List<int[]> out = new ArrayList<>();
    for (Room room : rooms)
      out.add(
          new int[] {
            room.cx - room.hw,
            room.cz - room.hd,
            room.floor - 1 - (room.shape == Shape.BRIDGE ? PIT_DEPTH : 0),
            room.cx + room.hw,
            room.cz + room.hd,
            room.floor + room.height
          });
    for (Corridor c : corridors) {
      int x0 = Integer.MAX_VALUE, x1 = Integer.MIN_VALUE, z0 = Integer.MAX_VALUE, z1 = Integer.MIN_VALUE;
      int y0 = Integer.MAX_VALUE, y1 = Integer.MIN_VALUE;
      for (Tile t : c.tiles) {
        x0 = Math.min(x0, t.x() - 2);
        x1 = Math.max(x1, t.x() + 2);
        z0 = Math.min(z0, t.z() - 2);
        z1 = Math.max(z1, t.z() + 2);
        y0 = Math.min(y0, t.floor() - 2);
        y1 = Math.max(y1, t.floor() + CORRIDOR_HEIGHT + 1);
      }
      out.add(new int[] {x0, z0, y0, x1, z1, y1});
    }
    return out;
  }

  public int volume() {
    int n = 0;
    for (int[] b : boxes()) n += (b[3] - b[0] + 1) * (b[4] - b[1] + 1) * (b[5] - b[2] + 1);
    return n;
  }

  public Room boss() {
    return rooms.get(mainRooms - 1);
  }

  public Corridor corridor(int from, int to) {
    for (Corridor c : corridors) if (c.from == from && c.to == to) return c;
    return null;
  }

  /** Minutes a party gets: more rooms, more time. */
  public int minutes() {
    return 20 + 6 * mainRooms;
  }
}
