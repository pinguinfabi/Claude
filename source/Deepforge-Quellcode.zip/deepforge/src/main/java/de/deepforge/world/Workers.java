package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import de.deepforge.ui.Menus;
import java.util.*;
import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.event.NPCRightClickEvent;
import net.citizensnpcs.api.npc.*;
import net.citizensnpcs.api.npc.NPC;
import net.citizensnpcs.api.trait.Trait;
import net.citizensnpcs.api.trait.trait.Equipment;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.inventory.ItemStack;

/** Physical worker shifts. Economic settlement remains the sole source of produced goods. */
public final class Workers implements Listener {
  private final DeepforgePlugin plugin;
  private final NPCRegistry registry;

  private static final class Actor {
    UUID owner;
    int index, zone, cycle, cursor, work;
    NPC npc;
    String state = "Zum Aufzug", status = "Zum Aufzug";
    List<Location> path = List.of();
    WorkerRoutes.Site site;
    long retry, arrived;
    Location last;
    int stuck, blocked;
  }

  private final Map<UUID, List<Actor>> actors = new HashMap<>();
  private final Map<Integer, List<WorkerRoutes.Site>> sites = new HashMap<>();
  private final Map<UUID, Set<Long>> routeChunks = new HashMap<>();
  private final Map<Long, Integer> chunkUsers = new HashMap<>();
  private long frame;

  public Workers(DeepforgePlugin plugin) {
    this.plugin = plugin;
    registry = CitizensAPI.createInMemoryNPCRegistry("deepforge-workers");
    Bukkit.getPluginManager().registerEvents(this, plugin);
    Bukkit.getScheduler().runTaskTimer(plugin, this::animate, 5, 5);
  }

  /** -2..2: spreads workers of different players in the shared camp. */
  private static int lane(UUID owner) {
    return Math.floorMod(owner.hashCode(), 5) - 2;
  }

  private List<WorkerRoutes.Site> sites(int zone) {
    return sites.computeIfAbsent(zone, z -> WorkerRoutes.sites(plugin.mines().blueprint(z)));
  }

  public String status(UUID owner, int index) {
    for (Actor a : actors.getOrDefault(owner, List.of())) if (a.index == index) return a.status;
    return "Offline-Abrechnung aktiv";
  }

  public void spawn(Player player) {
    remove(player.getUniqueId());
    Profile p = plugin.profile(player);
    List<Actor> list = new ArrayList<>();
    for (int i = 0; i < p.workers.size(); i++) {
      Profile.Worker w = p.workers.get(i);
      Actor a = new Actor();
      a.owner = player.getUniqueId();
      a.index = i;
      a.zone = w.zone;
      a.npc =
          registry.createNPC(
              EntityType.PLAYER, w.name + " · " + Menus.jobName(w.job) + " " + w.level);
      a.npc.setProtected(true);
      a.npc.data().setPersistent(NPC.Metadata.COLLIDABLE, false);
      a.npc
          .getNavigator()
          .getDefaultParameters()
          .speedModifier(.9f)
          .range(100)
          .distanceMargin(.35)
          .pathDistanceMargin(0)
          .pathfinderType(net.citizensnpcs.api.ai.PathfinderType.CITIZENS);
      applySkin(a.npc, i);
      Equipment eq = a.npc.getOrAddTrait(Equipment.class);
      hand(
          a,
          switch (w.job) {
            case MINER -> Material.IRON_PICKAXE;
            case SMELTER -> Material.IRON_INGOT;
            case LUMBERJACK -> Material.IRON_AXE;
            case TRADER -> Material.CHEST;
          });
      eq.set(
          Equipment.EquipmentSlot.HELMET,
          new ItemStack(w.level >= 3 ? Material.IRON_HELMET : Material.LEATHER_HELMET));
      eq.set(Equipment.EquipmentSlot.CHESTPLATE, new ItemStack(Material.LEATHER_CHESTPLATE));
      a.npc.spawn(plugin.mines().local(p, 2.5 + i, 201, 8.5 + lane(a.owner) * 1.2));
      if (w.job == Profile.Job.MINER)
        route(
            a,
            "Zum Aufzug",
            List.of(
                plugin.mines().local(p, .5, 201, 12.5), plugin.mines().local(p, .5, 201, 34.5)));
      else station(a, p, w);
      list.add(a);
    }
    actors.put(player.getUniqueId(), list);
  }

  private void hand(Actor a, Material material) {
    a.npc.getOrAddTrait(Equipment.class).set(Equipment.EquipmentSlot.HAND, new ItemStack(material));
  }

  private void route(Actor a, String state, List<Location> path) {
    retainRoute(a.owner, path);
    a.npc.getNavigator().cancelNavigation();
    a.state = state;
    a.status = state;
    a.path = path;
    a.cursor = 0;
    a.retry = 0;
    a.stuck = 0;
    a.blocked = 0;
    a.last = null;
    // A new route starts where the last one ended; snap onto its first block so the
    // pathfinder never has to make the short, often refused hop to the start point.
    if (!path.isEmpty() && a.npc.isSpawned()) {
      Location at = a.npc.getEntity().getLocation();
      Location first = path.getFirst();
      if (at.getWorld().equals(first.getWorld()) && at.distanceSquared(first) < 9)
        a.npc.teleport(first.clone().setDirection(at.getDirection()), TeleportCause.PLUGIN);
    }
  }

  /** Citizens NPCs otherwise stop when their owner leaves the village's simulation distance. */
  private void retainRoute(UUID owner, List<Location> path) {
    Set<Long> owned = routeChunks.computeIfAbsent(owner, key -> new HashSet<>());
    Location previous = null;
    for (Location point : path) {
      Location from = previous == null ? point : previous;
      int steps = Math.max(1, (int) Math.ceil(from.distance(point) / 8));
      for (int i = 0; i <= steps; i++) {
        Location sample =
            from.clone()
                .add(point.toVector().subtract(from.toVector()).multiply(i / (double) steps));
        Chunk chunk = sample.getChunk();
        long key = chunk.getChunkKey();
        if (owned.add(key)) {
          if (chunkUsers.merge(key, 1, Integer::sum) == 1) chunk.addPluginChunkTicket(plugin);
        }
      }
      previous = point;
    }
  }

  private void releaseRoute(UUID owner) {
    Set<Long> owned = routeChunks.remove(owner);
    if (owned == null) return;
    for (long key : owned) {
      int remaining = chunkUsers.getOrDefault(key, 1) - 1;
      if (remaining == 0) {
        chunkUsers.remove(key);
        plugin
            .mines()
            .world()
            .getChunkAt((int) key, (int) (key >> 32))
            .removePluginChunkTicket(plugin);
      } else chunkUsers.put(key, remaining);
    }
  }

  private boolean walk(Actor a) {
    Location at = a.npc.getEntity().getLocation();
    int previousCursor = a.cursor;
    while (a.cursor < a.path.size() && at.distanceSquared(a.path.get(a.cursor)) < .85) a.cursor++;
    if (a.cursor != previousCursor) {
      a.retry = 0;
      a.stuck = 0;
    }
    if (a.cursor >= a.path.size()) {
      a.npc.getNavigator().cancelNavigation();
      return true;
    }
    if (frame >= a.retry) {
      a.npc.getNavigator().setTarget(a.path.get(a.cursor));
      a.retry = frame + 40;
    }
    // Frames since the last reached waypoint. Waypoints are one block apart, so a walking NPC
    // reaches one every few frames; jittering against an edge must not count as progress.
    a.stuck += 5;
    if (a.stuck > 60) {
      // Route blocks are always walkable: after ~3 s without progress skip ahead instead of
      // standing still forever; repeated blockage skips further.
      a.blocked++;
      a.cursor = Math.min(a.path.size() - 1, a.cursor + Math.min(4, a.blocked));
      a.npc.getNavigator().cancelNavigation();
      a.npc.teleport(a.path.get(a.cursor), TeleportCause.PLUGIN);
      a.retry = 0;
      a.stuck = 0;
      a.last = null;
    }
    a.status = a.state;
    return false;
  }

  private Location point(Profile p, int zone, MineBlueprint.Point at) {
    return plugin.mines().mine(p, zone, at.x() + .5, at.h(), at.z() + .5);
  }

  private void ore(Actor a, Profile p) {
    List<WorkerRoutes.Site> options = sites(a.zone);
    a.site =
        options.get(
            Math.floorMod(a.index * 19 + a.cycle * 31 + lane(a.owner) * 7, options.size()));
    route(a, "Zur Erzader", a.site.path().stream().map(v -> point(p, a.zone, v)).toList());
    hand(a, Material.IRON_PICKAXE);
    a.work = 0;
  }

  private void station(Actor a, Profile p, Profile.Worker w) {
    Location target =
        w.job == Profile.Job.LUMBERJACK
            ? forestSpot(p, w, a.index)
            : w.job == Profile.Job.SMELTER
                ? plugin.mines().local(p, -22.5 + lane(a.owner) * 1.2, 201, 6.5)
                : plugin.mines().local(p, .5 + lane(a.owner) * 1.2, 201, -23.5);
    route(a, "Zur Arbeitsstation", List.of(plugin.mines().local(p, .5, 201, 8.5), target));
  }

  /** Next to a tree of the lumberjack's wood type; several lumberjacks use different trees. */
  private Location forestSpot(Profile p, Profile.Worker w, int index) {
    int species = Industry.woodType(p, w);
    List<ForestBlueprint.Tree> trees =
        ForestBlueprint.TREES.stream().filter(t -> t.species() == species).toList();
    if (trees.isEmpty()) return plugin.mines().local(p, .5, 201, 8.5);
    ForestBlueprint.Tree t = trees.get(index % trees.size());
    return plugin.mines().local(p, t.x() + 1.5, 201, t.z() + .5);
  }

  @SuppressWarnings("unchecked")
  private void applySkin(NPC npc, int index) {
    try {
      Class<? extends Trait> clazz =
          (Class<? extends Trait>) Class.forName("net.citizensnpcs.trait.SkinTrait");
      Trait trait = npc.getOrAddTrait(clazz);
      List<Map<?, ?>> signed = plugin.getConfig().getMapList("workers.signed-textures");
      if (index < signed.size()
          && signed.get(index).containsKey("value")
          && signed.get(index).containsKey("signature")) {
        Map<?, ?> skin = signed.get(index);
        clazz
            .getMethod("setSkinPersistent", String.class, String.class, String.class)
            .invoke(
                trait,
                "deepforge-" + index,
                skin.get("signature").toString(),
                skin.get("value").toString());
      } else {
        List<String> skins = plugin.getConfig().getStringList("workers.skins");
        if (!skins.isEmpty())
          clazz
              .getMethod("setSkinName", String.class)
              .invoke(trait, skins.get(index % skins.size()));
      }
    } catch (ReflectiveOperationException ex) {
      plugin.getLogger().warning("Citizens skin configuration unavailable: " + ex.getMessage());
    }
  }

  private void animate() {
    frame += 5;
    for (var entry : actors.entrySet()) {
      Player owner = Bukkit.getPlayer(entry.getKey());
      if (owner == null || !plugin.playing(owner)) continue;
      Profile p = plugin.profile(owner);
      for (Actor a : entry.getValue()) {
        if (!a.npc.isSpawned() || a.index >= p.workers.size()) continue;
        Profile.Worker w = p.workers.get(a.index);
        advance(a, p, w);
      }
    }
    if (probe != null) {
      try {
        advance(probe, probeProfile, probeProfile.workers.getFirst());
        if (probe.state.equals("Entlädt Erz")) {
          probeResult =
              "WORKERS OK: Citizens player walked village -> lift -> real ore, performed 12 swings"
                  + " and returned to mine depot; ticks="
                  + (frame - probeStart);
          finishProbe();
        } else if (frame - probeStart > 3600) {
          probeResult =
              "WORKERS FAILED: "
                  + probe.state
                  + " at "
                  + probe.npc.getEntity().getLocation()
                  + " target="
                  + (probe.cursor < probe.path.size() ? probe.path.get(probe.cursor) : "none");
          finishProbe();
        }
      } catch (RuntimeException ex) {
        probeResult = "WORKERS FAILED: " + ex;
        finishProbe();
      }
    }
  }

  private void advance(Actor a, Profile p, Profile.Worker w) {
    switch (a.state) {
      case "Zum Aufzug" -> {
        if (walk(a)) {
          a.state = "Aufzug fährt";
          a.arrived = frame;
          a.status = a.state;
        }
      }
      case "Aufzug fährt" -> {
        if (frame - a.arrived >= 30) {
          a.npc.teleport(plugin.mines().entrance(p, a.zone), TeleportCause.PLUGIN);
          ore(a, p);
        }
      }
      case "Zur Erzader" -> {
        if (walk(a)) {
          a.state = "Baut Erz ab";
          a.status = a.state;
          a.arrived = 0;
        }
      }
      case "Baut Erz ab" -> {
        String stopped = Industry.stopped(p, w);
        a.status = stopped.isEmpty() ? "Baut " + Zone.at(a.zone).oreName + " ab" : stopped;
        if (!stopped.isEmpty()) return;
        Location ore = point(p, a.zone, a.site.ore()).add(0, .5, 0);
        a.npc.faceLocation(ore);
        if (ore.getBlock().getType() != Material.NOTE_BLOCK) {
          // In the shared mine players take veins too: move on instead of idling.
          if (a.arrived == 0) a.arrived = frame;
          if (frame - a.arrived < 60) {
            a.status = "Ader abgebaut · sucht neue";
            return;
          }
          a.arrived = 0;
          a.cycle++;
          ore(a, p);
          return;
        }
        a.arrived = 0;
        if (frame % 10 == 0 && a.npc.getEntity() instanceof Player npc) {
          npc.swingMainHand();
          npc.getWorld()
              .spawnParticle(
                  Particle.BLOCK,
                  ore,
                  5,
                  .2,
                  .2,
                  .2,
                  .02,
                  MineWorld.wall(a.zone).createBlockData());
          npc.getWorld().playSound(ore, Sound.BLOCK_STONE_HIT, .35f, .8f);
          if (++a.work >= 12) {
            List<Location> back =
                new ArrayList<>(a.site.path().stream().map(v -> point(p, a.zone, v)).toList());
            Collections.reverse(back);
            hand(a, Material.RAW_IRON);
            route(a, "Zum Grubendepot", back);
          }
        }
      }
      case "Zum Grubendepot" -> {
        if (walk(a)) {
          a.state = "Entlädt Erz";
          a.arrived = frame;
          a.status = a.state;
        }
      }
      case "Entlädt Erz" -> {
        if (frame - a.arrived >= 30) {
          a.cycle++;
          ore(a, p);
        }
      }
      case "Zur Arbeitsstation" -> {
        if (walk(a)) {
          a.state = "Arbeitet";
          a.status = a.state;
        }
      }
      case "Arbeitet" -> {
        String stopped = Industry.stopped(p, w);
        a.status =
            stopped.isEmpty()
                ? switch (w.job) {
                  case SMELTER -> "Verarbeitet Erz";
                  case LUMBERJACK -> "Fällt " + Forestry.WOODS[Industry.woodType(p, w)];
                  default -> "Verkauft Waren";
                }
                : stopped;
        if (stopped.isEmpty() && frame % 20 == 0 && a.npc.getEntity() instanceof Player npc) {
          npc.swingMainHand();
          npc.getWorld()
              .spawnParticle(
                  w.job == Profile.Job.SMELTER
                      ? Particle.SMALL_FLAME
                      : w.job == Profile.Job.LUMBERJACK
                          ? Particle.COMPOSTER
                          : Particle.HAPPY_VILLAGER,
                  npc.getLocation().add(0, 1, 0),
                  3,
                  .2,
                  .3,
                  .2,
                  0);
        }
      }
      default -> throw new IllegalStateException("Unknown worker state");
    }
  }

  private Actor probe;
  private Profile probeProfile;
  private long probeStart;
  private String probeResult;

  public String verify(Profile saved) {
    if (probeResult != null) return probeResult;
    probeProfile = new Profile();
    probeProfile.plot = saved.plot;
    probeProfile.budget = 1000;
    probeProfile.fuel = 1000;
    probeProfile.workers.add(new Profile.Worker("Probe", Profile.Job.MINER, 0));
    Actor a = new Actor();
    a.owner = UUID.randomUUID();
    a.zone = 0;
    a.index = 0;
    try {
      retainRoute(a.owner, List.of(plugin.mines().local(probeProfile, 2.5, 201, 8.5)));
      a.npc = registry.createNPC(EntityType.PLAYER, "Deepforge Routentest");
      a.npc.setProtected(true);
      a.npc
          .getNavigator()
          .getDefaultParameters()
          .speedModifier(.9f)
          .range(100)
          .distanceMargin(.35)
          .pathDistanceMargin(0)
          .pathfinderType(net.citizensnpcs.api.ai.PathfinderType.CITIZENS);
      a.npc.spawn(plugin.mines().local(probeProfile, 2.5, 201, 8.5));
      hand(a, Material.IRON_PICKAXE);
      route(
          a,
          "Zum Aufzug",
          List.of(
              plugin.mines().local(probeProfile, .5, 201, 12.5),
              plugin.mines().local(probeProfile, .5, 201, 34.5)));
      probe = a;
      probeStart = frame;
      probeResult = "RUNNING";
    } catch (RuntimeException ex) {
      releaseRoute(a.owner);
      if (a.npc != null) a.npc.destroy();
      finishProbe();
      throw ex;
    }
    return probeResult;
  }

  private void finishProbe() {
    if (probe != null) {
      releaseRoute(probe.owner);
      probe.npc.destroy();
      probe = null;
    }
  }

  @EventHandler
  public void click(NPCRightClickEvent event) {
    for (Actor a : actors.getOrDefault(event.getClicker().getUniqueId(), List.of()))
      if (a.npc.equals(event.getNPC())) {
        plugin.menus().open(event.getClicker(), "worker/" + a.index);
        return;
      }
  }

  public void remove(UUID owner) {
    List<Actor> list = actors.remove(owner);
    if (list != null) list.forEach(a -> a.npc.destroy());
    releaseRoute(owner);
  }

  public void close() {
    finishProbe();
    new ArrayList<>(actors.keySet()).forEach(this::remove);
    CitizensAPI.removeNamedNPCRegistry("deepforge-workers");
  }
}
