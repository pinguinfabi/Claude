package de.deepforge.game;

import java.util.*;

/**
 * Meisterschaft: permanent mastery levels (separate from the seasonal Tiefenpass). Every level is
 * one talent point for three trees; each tree has four talents with three ranks and one key talent.
 */
public final class Talents {
  public static final int KEY_REQUIRES = 8;

  public enum Tree {
    KRIEGER("Krieger"),
    BERGMANN("Bergmann"),
    UNTERNEHMER("Unternehmer");
    public final String title;

    Tree(String title) {
      this.title = title;
    }
  }

  public enum Node {
    KLINGE(Tree.KRIEGER, "Klingenkunst", "+3 % Schaden", 3),
    ZAEHIGKEIT(Tree.KRIEGER, "Zähigkeit", "+5 Leben", 3),
    BOLLWERK(Tree.KRIEGER, "Bollwerk", "-3 % erlittener Schaden", 3),
    KOMBO(Tree.KRIEGER, "Kombo-Meister", "Kombo-Fenster +0,3 s", 3),
    BLUTRAUSCH(Tree.KRIEGER, "Blutrausch", "Jeder 10. Kombo-Treffer ist ein sicherer Krit", 1),
    BOHRER(Tree.BERGMANN, "Bohrmeister", "+4 % Abbautempo", 3),
    KUEHLUNG(Tree.BERGMANN, "Kühlsystem", "-6 % Bohrer-Hitze", 3),
    ADER(Tree.BERGMANN, "Adernsucher", "+5 % Chance auf doppeltes Erz", 3),
    RUNENGESPUER(Tree.BERGMANN, "Runengespür", "+1 % Runenfund bei Monstern", 3),
    ERZFLUT(Tree.BERGMANN, "Erzflut", "5 % Chance: ein Erzblock gibt dreifach", 1),
    HANDEL(Tree.UNTERNEHMER, "Handelsgeschick", "+3 % Verkaufspreis für Erz und Barren", 3),
    SPARFUCHS(Tree.UNTERNEHMER, "Sparfuchs", "-4 % Kosten für Grund-Upgrades", 3),
    HOLZKENNER(Tree.UNTERNEHMER, "Holzkenner", "+5 % Chance auf doppelte Holzernte", 3),
    WERTSCHOEPFER(Tree.UNTERNEHMER, "Wertschöpfer", "+15 % Staub beim Zerlegen", 3),
    MAGNAT(Tree.UNTERNEHMER, "Magnat", "+10 % auf jeden Verkauf von Erz und Barren", 1);
    public final Tree tree;
    public final String title, perRank;
    public final int max;

    Node(Tree tree, String title, String perRank, int max) {
      this.tree = tree;
      this.title = title;
      this.perRank = perRank;
      this.max = max;
    }

    public boolean key() {
      return max == 1;
    }
  }

  public static final int MAX_LEVEL =
      Arrays.stream(Node.values()).mapToInt(n -> n.max).sum();

  private Talents() {}

  private static Map<String, Integer> map(Profile p) {
    if (p.talents == null) p.talents = new HashMap<>();
    return p.talents;
  }

  /** XP to go from level n to n + 1. */
  public static long need(int level) {
    return 400 + 150L * level;
  }

  public static int level(Profile p) {
    int level = 0;
    long xp = p.talentXp;
    while (level < MAX_LEVEL && xp >= need(level)) xp -= need(level++);
    return level;
  }

  /** XP inside the current level and the XP it needs. */
  public static long[] progress(Profile p) {
    int level = 0;
    long xp = p.talentXp;
    while (level < MAX_LEVEL && xp >= need(level)) xp -= need(level++);
    return level >= MAX_LEVEL ? new long[] {0, 0} : new long[] {xp, need(level)};
  }

  /** Adds mastery XP; returns how many levels were gained. */
  public static int addXp(Profile p, long xp) {
    if (xp <= 0) return 0;
    int before = level(p);
    p.talentXp = Math.addExact(p.talentXp, xp);
    return level(p) - before;
  }

  public static int rank(Profile p, Node n) {
    return Math.max(0, Math.min(n.max, map(p).getOrDefault(n.name(), 0)));
  }

  public static int spent(Profile p) {
    int sum = 0;
    for (Node n : Node.values()) sum += rank(p, n);
    return sum;
  }

  public static int spent(Profile p, Tree tree) {
    int sum = 0;
    for (Node n : Node.values()) if (n.tree == tree) sum += rank(p, n);
    return sum;
  }

  public static int free(Profile p) {
    return Math.max(0, level(p) - spent(p));
  }

  public static String learn(Profile p, Node n) {
    if (rank(p, n) >= n.max) return n.title + " ist schon voll ausgebaut.";
    if (free(p) <= 0) return "Kein Talentpunkt frei – Meisterschafts-XP sammeln.";
    if (n.key() && spent(p, n.tree) < KEY_REQUIRES)
      return "Benötigt "
          + KEY_REQUIRES
          + " Punkte im Baum "
          + n.tree.title
          + " (du hast "
          + spent(p, n.tree)
          + ").";
    map(p).put(n.name(), rank(p, n) + 1);
    return n.title + " → Rang " + rank(p, n) + "/" + n.max + ": " + n.perRank + ".";
  }

  public static long resetCost(Profile p) {
    return 1000L * spent(p);
  }

  public static String reset(Profile p) {
    if (spent(p) == 0) return "Es sind noch keine Talente verteilt.";
    long cost = resetCost(p);
    if (p.money < cost) return "Benötigt " + cost + " $ zum Zurücksetzen.";
    p.money -= cost;
    map(p).clear();
    return "Talente zurückgesetzt. Alle " + level(p) + " Punkte sind wieder frei.";
  }

  // --- effects ---
  public static double damage(Profile p) {
    return 1 + .03 * rank(p, Node.KLINGE);
  }

  public static double health(Profile p) {
    return 5 * rank(p, Node.ZAEHIGKEIT);
  }

  public static double damageTaken(Profile p) {
    return 1 - .03 * rank(p, Node.BOLLWERK);
  }

  public static int comboWindow(Profile p) {
    return RapidCombat.COMBO_WINDOW_TICKS + 6 * rank(p, Node.KOMBO);
  }

  public static boolean bloodrush(Profile p) {
    return rank(p, Node.BLUTRAUSCH) > 0;
  }

  public static double mining(Profile p) {
    return 1 + .04 * rank(p, Node.BOHRER);
  }

  public static double heat(Profile p) {
    return 1 - .06 * rank(p, Node.KUEHLUNG);
  }

  public static double yield(Profile p) {
    return .05 * rank(p, Node.ADER);
  }

  public static double runeChance(Profile p) {
    return .01 * rank(p, Node.RUNENGESPUER);
  }

  public static double oreFlood(Profile p) {
    return rank(p, Node.ERZFLUT) > 0 ? .05 : 0;
  }

  public static double sale(Profile p) {
    return (1 + .03 * rank(p, Node.HANDEL)) * (rank(p, Node.MAGNAT) > 0 ? 1.1 : 1);
  }

  public static double upgradeCost(Profile p) {
    return 1 - .04 * rank(p, Node.SPARFUCHS);
  }

  public static double wood(Profile p) {
    return .05 * rank(p, Node.HOLZKENNER);
  }

  public static double dust(Profile p) {
    return 1 + .15 * rank(p, Node.WERTSCHOEPFER);
  }
}
