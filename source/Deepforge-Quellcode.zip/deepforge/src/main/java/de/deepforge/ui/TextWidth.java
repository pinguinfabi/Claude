package de.deepforge.ui;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Pixel widths of the vanilla 1.21.8 default font (read from the client's font sheets, see
 * font_widths.txt). Dialog text is centered line by line; to show a left-aligned block the wiki
 * wraps lines itself and pads every line to the same width.
 */
public final class TextWidth {
  private static final Map<Integer, Integer> WIDTHS = load();
  static final int UNKNOWN = 6;

  private TextWidth() {}

  private static Map<Integer, Integer> load() {
    Map<Integer, Integer> out = new HashMap<>();
    var in = TextWidth.class.getResourceAsStream("/font_widths.txt");
    if (in == null) return out;
    try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
      for (String line; (line = r.readLine()) != null; ) {
        if (line.isBlank() || line.startsWith("#")) continue;
        String[] p = line.trim().split(" ");
        out.put(Integer.parseInt(p[0]), Integer.parseInt(p[1]));
      }
    } catch (java.io.IOException e) {
      throw new IllegalStateException("font_widths.txt unreadable", e);
    }
    return out;
  }

  static boolean known(int codePoint) {
    return WIDTHS.containsKey(codePoint);
  }

  public static int of(String text) {
    int w = 0;
    for (int i = 0; i < text.length(); ) {
      int cp = text.codePointAt(i);
      w += WIDTHS.getOrDefault(cp, UNKNOWN);
      i += Character.charCount(cp);
    }
    return w;
  }

  /** Word wrap to at most {@code max} pixels; words longer than a line are split. */
  public static List<String> wrap(String text, int max) {
    List<String> lines = new ArrayList<>();
    for (String paragraph : text.split("\n", -1)) {
      StringBuilder line = new StringBuilder();
      for (String word : paragraph.split(" ")) {
        if (word.isEmpty()) continue;
        String candidate = line.isEmpty() ? word : line + " " + word;
        if (of(candidate) <= max) {
          line.setLength(0);
          line.append(candidate);
          continue;
        }
        if (!line.isEmpty()) lines.add(line.toString());
        line.setLength(0);
        while (of(word) > max) {
          int cut = 1;
          while (cut < word.length() && of(word.substring(0, cut + 1)) <= max) cut++;
          lines.add(word.substring(0, cut));
          word = word.substring(cut);
        }
        line.append(word);
      }
      lines.add(line.toString());
    }
    return lines;
  }
}
