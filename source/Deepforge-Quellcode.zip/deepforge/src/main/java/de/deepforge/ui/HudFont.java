package de.deepforge.ui;

import java.util.*;
import java.util.function.Consumer;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.ShadowColor;
import net.kyori.adventure.text.format.TextColor;

/**
 * Game HUD drawn with the resource pack font deepforge:hud (see resourcepack/build_pack.py):
 * own pixel letters, icons, segmented bars and dark panels. Every glyph has a fixed advance, so
 * panels can be sized to their content exactly.
 */
public final class HudFont {
  public static final Key FONT = Key.key("deepforge", "hud");
  // Same glyphs, drawn 28 px lower: the action-bar HUD, with room for messages above it.
  public static final Key FONT_LOW = Key.key("deepforge", "hud_low");
  static final String TEXT = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ$%/.:+-!x ÄÖÜ";
  // Wiki dialog: section bar (296 px wide) drawn behind entry titles.
  // Stored as two 148 px halves: font atlas pages are only 256 px wide.
  static final char WIKI_BAR = '\ue3c0', WIKI_BAR_2 = '\ue3c1';
  static final int WIKI_BAR_WIDTH = 297;
  static final int LETTER = 6, ICON = 10, SEGMENT = 4, PAD = 4, GAP = 3;

  public enum Icon {
    COIN,
    BAG,
    FLAME,
    HEART,
    BOLT,
    STAR,
    GEM,
    SWORD,
    CRYSTAL,
    CLOCK,
    UP,
    UP_RIGHT,
    RIGHT,
    DOWN_RIGHT,
    DOWN,
    DOWN_LEFT,
    LEFT,
    UP_LEFT,
    PICK,
    LOG,
    WORKER,
    CASTLE,
    SKULL,
    SCROLL;

    char glyph() {
      return (char) (0xE340 + ordinal());
    }
  }

  private static final char SEG_FULL = '', SEG_EMPTY = '';
  private static final char PANEL_LEFT = '', PANEL_RIGHT = '';
  private static final int[] PANEL_WIDTHS = {32, 16, 8, 4, 2, 1};

  private HudFont() {}

  static char letter(char c) {
    int i = TEXT.indexOf(c);
    if (i < 0) i = TEXT.indexOf(Character.toUpperCase(c));
    return i < 0 ? 0 : (char) (0xE300 + i);
  }

  /**
   * Text in the HUD pixel letters (upper case; ß becomes SS, unknown characters are dropped), for
   * headings in dialogs.
   */
  public static Component label(String text, TextColor color) {
    StringBuilder sb = new StringBuilder();
    for (char c : text.replace("ß", "SS").toUpperCase(java.util.Locale.GERMAN).toCharArray()) {
      char g = c == '&' ? letter('+') : c == '·' ? letter('-') : letter(c);
      if (g != 0) sb.append(g);
    }
    return Component.text(sb.toString(), color).font(FONT);
  }

  /** Width of {@link #label} in pixels. */
  public static int labelWidth(String text) {
    int n = 0;
    for (char c : text.replace("ß", "SS").toUpperCase(java.util.Locale.GERMAN).toCharArray())
      if ((c == '&' ? letter('+') : c == '·' ? letter('-') : letter(c)) != 0) n++;
    return n * LETTER;
  }

  /** Invisible space in the HUD font moving the cursor by {@code px} (for padding lines). */
  public static Component pad(int px) {
    return px == 0 ? Component.empty() : Component.text(space(px)).font(FONT);
  }

  /**
   * A section heading exactly {@code width} px wide: the wiki bar with the label on top of it. The
   * fixed width keeps it left-aligned with the padded text lines below (dialogs center each line).
   */
  public static Component section(String text, TextColor color, int width) {
    Component bar =
        Component.text(WIKI_BAR + space(-1) + WIKI_BAR_2 + space(-(WIKI_BAR_WIDTH - 7)), TextColor.color(0xFFFFFF))
            .font(FONT);
    int rest = width - 7 - labelWidth(text);
    return Component.empty().append(bar).append(label(text, color)).append(pad(Math.max(0, rest)));
  }

  /** Space glyphs that move the cursor by exactly {@code px} pixels (negative moves back). */
  static String space(int px) {
    StringBuilder sb = new StringBuilder();
    int left = Math.abs(px);
    for (int bit = 7; bit >= 0; bit--) {
      int step = 1 << bit;
      if (px > 0 && bit > 6) continue;
      while (left >= step) {
        sb.append((char) ((px < 0 ? 0xE380 : 0xE388) + bit));
        left -= step;
      }
    }
    return sb.toString();
  }

  /** Builds one HUD line and keeps track of its pixel width. */
  public static final class Line {
    private final List<Component> parts = new ArrayList<>();
    private int width;

    public int width() {
      return width;
    }

    private Line raw(String glyphs, TextColor color, int advance) {
      if (!glyphs.isEmpty()) parts.add(Component.text(glyphs, color));
      width += advance;
      return this;
    }

    public Line space(int px) {
      return raw(HudFont.space(px), NamedTextColor.WHITE, px);
    }

    public Line text(String text, TextColor color) {
      StringBuilder sb = new StringBuilder();
      int n = 0;
      for (char c : text.toCharArray()) {
        char g = letter(c);
        if (g == 0) continue;
        sb.append(g);
        n++;
      }
      return raw(sb.toString(), color, n * LETTER);
    }

    /**
     * Text padded to at least {@code chars} letters. The action bar is centred, so a value that
     * grows from "9%" to "10%" would shift the whole HUD sideways; fixed widths keep it still.
     */
    public Line text(String text, TextColor color, int chars) {
      int before = width;
      text(text, color);
      int missing = chars * LETTER - (width - before);
      return missing > 0 ? space(missing) : this;
    }

    public Line icon(Icon icon) {
      return raw(String.valueOf(icon.glyph()), NamedTextColor.WHITE, ICON);
    }

    /** Segmented bar; a segment lights up once its share of the value is reached. */
    public Line bar(double fraction, int segments, TextColor color) {
      int lit = (int) Math.round(Math.max(0, Math.min(1, fraction)) * segments);
      if (fraction > 0 && lit == 0) lit = 1;
      raw(String.valueOf(SEG_FULL).repeat(lit), color, lit * SEGMENT);
      return raw(String.valueOf(SEG_EMPTY).repeat(segments - lit), NamedTextColor.WHITE, (segments - lit) * SEGMENT);
    }

    /** A dark rounded panel exactly as wide as its content plus padding. */
    public Line chip(Consumer<Line> content) {
      Line inner = new Line();
      content.accept(inner);
      // Visible panel width; the content's last glyph already ends with one empty pixel.
      int total = inner.width + 2 * PAD - 1;
      StringBuilder panel = new StringBuilder();
      panel.append(PANEL_LEFT).append(HudFont.space(-1));
      int middle = total - 6;
      for (int w : PANEL_WIDTHS)
        while (middle >= w) {
          panel.append((char) (0xE372 + Integer.numberOfTrailingZeros(w)));
          panel.append(HudFont.space(-1));
          middle -= w;
        }
      panel.append(PANEL_RIGHT);
      // Panel: 3 + middle + 3 visible pixels plus one advance pixel = total + 1.
      raw(panel.toString(), NamedTextColor.WHITE, total + 1);
      space(-(total + 1) + PAD);
      parts.addAll(inner.parts);
      width += inner.width;
      return space(PAD - 1).space(GAP);
    }

    public Component build() {
      TextComponent.Builder b =
          Component.text().font(FONT_LOW).shadowColor(ShadowColor.none()).color(NamedTextColor.WHITE);
      parts.forEach(b::append);
      return b.build();
    }
  }

  public static String compact(long value) {
    long a = Math.abs(value);
    if (a >= 10_000_000) return (value / 1_000_000) + "M";
    if (a >= 1_000_000) return String.format(Locale.GERMANY, "%.2fM", value / 1e6).replace(',', '.');
    if (a >= 100_000) return (value / 1_000) + "K";
    return String.format(Locale.GERMANY, "%,d", value);
  }

  /** One HUD icon for mixing into normal text lines (sidebar). */
  public static Component icon(Icon icon) {
    return Component.text(icon.glyph() + space(3))
        .font(FONT)
        .shadowColor(ShadowColor.none())
        .color(NamedTextColor.WHITE);
  }

  // Colours used across the HUD.
  public static final TextColor GOLD = TextColor.color(0xFFD25A),
      LIGHT = TextColor.color(0xE8EDF2),
      DIM = TextColor.color(0x8C95A3),
      GREEN = TextColor.color(0x6BE06B),
      YELLOW = TextColor.color(0xFFC83C),
      RED = TextColor.color(0xFF5050),
      CYAN = TextColor.color(0x5AD2FF),
      ORANGE = TextColor.color(0xFF9632);

  static TextColor fill(double fraction) {
    return fraction >= .9 ? RED : fraction >= .65 ? YELLOW : GREEN;
  }

  /** Life is always on screen: the vanilla hearts are hidden by the resource pack. */
  static void health(Line line, double health, double maxHealth, int segments) {
    double hp = maxHealth <= 0 ? 0 : health / maxHealth;
    line.chip(
        l ->
            l.icon(Icon.HEART)
                .space(2)
                .bar(hp, segments, hp <= .3 ? RED : TextColor.color(0xE6464B))
                .space(3)
                .text(
                    (int) Math.ceil(health) + "/" + (int) Math.ceil(maxHealth),
                    hp <= .3 ? RED : LIGHT,
                    2 * String.valueOf((int) Math.ceil(maxHealth)).length() + 1));
  }

  /**
   * The HUD with a message above it (normal font at the usual action-bar height), both centred:
   * the HUD stays visible while messages show.
   */
  public static Component overlay(Line hud, Component notice, String plain) {
    // Exact vanilla widths: a guess that is off by a few pixels moves the HUD while a message shows.
    int w = hud.width(), n = TextWidth.of(plain);
    int before = -(w + n) / 2, after = -before - n;
    return hud.build()
        .append(Component.text(space(before)).font(FONT_LOW))
        .append(notice.font(Key.key("minecraft", "default")))
        .append(Component.text(space(after)).font(FONT_LOW));
  }

  public static Component mining(
      double health,
      double maxHealth,
      long money,
      long bagUsed,
      long bagCapacity,
      double heat,
      String veinDistance,
      Icon veinArrow) {
    return miningLine(health, maxHealth, money, bagUsed, bagCapacity, heat, veinDistance, veinArrow)
        .build();
  }

  public static Line miningLine(
      double health,
      double maxHealth,
      long money,
      long bagUsed,
      long bagCapacity,
      double heat,
      String veinDistance,
      Icon veinArrow) {
    double bag = bagCapacity <= 0 ? 1 : (double) bagUsed / bagCapacity;
    Line line = new Line();
    health(line, health, maxHealth, 5);
    line.chip(l -> l.icon(Icon.COIN).space(2).text(compact(money) + "$", GOLD));
    line.chip(
        l ->
            l.icon(Icon.BAG)
                .space(2)
                .bar(bag, 10, fill(bag))
                .space(3)
                .text(
                    bagUsed >= bagCapacity ? "VOLL" : bagUsed + "/" + bagCapacity,
                    bagUsed >= bagCapacity ? RED : LIGHT,
                    2 * String.valueOf(bagCapacity).length() + 1));
    line.chip(
        l ->
            l.icon(Icon.FLAME)
                .space(2)
                .bar(heat / 100, 10, fill(heat / 100))
                .space(3)
                .text((int) heat + "%", fill(heat / 100), 4));
    if (veinDistance != null)
      line.chip(
          l -> l.icon(Icon.GEM).space(2).text("ADER " + veinDistance, YELLOW, 9).space(2).icon(veinArrow));
    return line;
  }

  public static Component combat(
      double health,
      double maxHealth,
      double stamina,
      int abilitySeconds,
      int healing,
      int healingSeconds,
      int combo) {
    return combatLine(health, maxHealth, stamina, abilitySeconds, healing, healingSeconds, combo)
        .build();
  }

  public static Line combatLine(
      double health,
      double maxHealth,
      double stamina,
      int abilitySeconds,
      int healing,
      int healingSeconds,
      int combo) {
    Line line = new Line();
    health(line, health, maxHealth, 10);
    line.chip(l -> l.icon(Icon.BOLT).space(2).bar(stamina / 100, 10, CYAN));
    line.chip(
        l ->
            l.icon(Icon.STAR)
                .space(2)
                .text(abilitySeconds <= 0 ? "BEREIT" : abilitySeconds + "S", abilitySeconds <= 0 ? GREEN : DIM, 6));
    line.chip(
        l ->
            l.icon(Icon.CRYSTAL)
                .space(2)
                .text(
                    healing + (healingSeconds > 0 ? " " + healingSeconds + "S" : ""),
                    healing > 0 && healingSeconds <= 0 ? GREEN : DIM,
                    String.valueOf(healing).length() + 4));
    if (combo >= 2)
      line.chip(l -> l.icon(Icon.SWORD).space(2).text("x" + combo, combo >= 11 ? ORANGE : YELLOW, 3));
    return line;
  }

  public static Icon arrow(double yaw, double dx, double dz) {
    String a = Hud.arrow(yaw, dx, dz);
    return switch (a) {
      case "↗" -> Icon.UP_RIGHT;
      case "→" -> Icon.RIGHT;
      case "↘" -> Icon.DOWN_RIGHT;
      case "↓" -> Icon.DOWN;
      case "↙" -> Icon.DOWN_LEFT;
      case "←" -> Icon.LEFT;
      case "↖" -> Icon.UP_LEFT;
      default -> Icon.UP;
    };
  }
}
