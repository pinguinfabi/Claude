package de.deepforge.ui;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.Wiki;
import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/**
 * The in-game wiki as a real dialog window (Minecraft 1.21.6+): each page shows an intro, every
 * entry with its item icon (our resource-pack textures when the pack is active) and buttons to
 * the sub-pages. Navigation runs through /df wiki &lt;page&gt;.
 */
public final class WikiDialog {
  private final DeepforgePlugin plugin;

  public WikiDialog(DeepforgePlugin plugin) {
    this.plugin = plugin;
  }

  public void show(Player player, String id) {
    Wiki.Page page = Wiki.page(id == null || id.isBlank() ? "home" : id);
    player.closeInventory();
    player.showDialog(build(player, page));
  }

  // Deepforge palette: ember orange, light ember, soft text.
  private static final TextColor EMBER = TextColor.color(0xFF8A00),
      EMBER_LIGHT = TextColor.color(0xFFB547),
      TEXT = TextColor.color(0xE8E2DA),
      MUTED = TextColor.color(0xA69C94);

  private Dialog build(Player player, Wiki.Page page) {
    boolean pack = plugin.packApplied(player);
    List<DialogBody> body = new ArrayList<>();
    boolean home = page.parent() == null;
    // Start page: the big DEEPFORGE letters of the network style (18 px, two text lines tall).
    if (home && pack) body.add(DialogBody.plainMessage(NetzFont.logo().append(Component.text("\n ")), 200));
    if (!page.intro().isEmpty())
      body.add(DialogBody.plainMessage(Component.text(String.join("\n", page.intro()), MUTED), 360));
    for (Wiki.Entry e : page.entries()) {
      Component text =
          pack
              ? HudFont.section(e.title(), EMBER_LIGHT)
              : Component.text(e.title(), NamedTextColor.GOLD).decorate(TextDecoration.BOLD);
      for (String line : e.lines())
        if (!line.isBlank()) text = text.append(Component.newline()).append(Component.text(line, TEXT));
      body.add(
          DialogBody.item(icon(player, e.model(), e.material(), e.title()))
              .description(DialogBody.plainMessage(text, 300))
              .showDecorations(false)
              .showTooltip(false)
              .build());
    }
    List<ActionButton> buttons = new ArrayList<>();
    for (String child : page.children()) {
      Wiki.Page c = Wiki.page(child);
      buttons.add(
          ActionButton.builder(Component.text(c.title(), EMBER_LIGHT).append(Component.text(" ›", EMBER)))
              .tooltip(Component.text(c.intro().isEmpty() ? "Öffnen" : c.intro().getFirst()))
              .width(150)
              .action(DialogAction.staticAction(ClickEvent.runCommand("/df wiki " + child)))
              .build());
    }
    if (page.parent() != null && !page.parent().equals("home"))
      buttons.add(
          ActionButton.builder(Component.text("⌂ Wiki-Start", TEXT))
              .width(150)
              .action(DialogAction.staticAction(ClickEvent.runCommand("/df wiki home")))
              .build());
    ActionButton exit =
        page.parent() == null
            ? ActionButton.builder(Component.text("Schließen", TEXT)).width(200).build()
            : ActionButton.builder(Component.text("◀ Zurück: " + Wiki.page(page.parent()).title(), TEXT))
                .width(200)
                .action(DialogAction.staticAction(ClickEvent.runCommand("/df wiki " + page.parent())))
                .build();
    if (buttons.isEmpty())
      buttons.add(
          ActionButton.builder(Component.text("Schließen")).width(150).build());
    DialogBase base =
        DialogBase.builder(
                pack
                    ? home
                        ? HudFont.label("Wiki · alles erklärt", EMBER_LIGHT)
                        : HudFont.label("Deepforge-Wiki  ", EMBER).append(HudFont.label(page.title(), EMBER_LIGHT))
                    : Component.text("⛏ DEEPFORGE-WIKI · " + page.title(), NamedTextColor.GOLD))
            .externalTitle(Component.text("Wiki"))
            .canCloseWithEscape(true)
            .pause(false)
            .afterAction(DialogBase.DialogAfterAction.CLOSE)
            .body(body)
            .build();
    List<ActionButton> actions = List.copyOf(buttons);
    return Dialog.create(
        f -> f.empty().base(base).type(DialogType.multiAction(actions).columns(2).exitAction(exit).build()));
  }

  private ItemStack icon(Player player, String model, String material, String title) {
    Material base = Material.matchMaterial(material);
    if (base == null || !base.isItem()) base = Material.PAPER;
    return plugin.items().forViewer(plugin.items().model(base, model, title), player);
  }

  /** Wiki page that explains a menu page (for the help buttons). */
  public static String pageFor(String menu) {
    if (menu.startsWith("item/") || menu.startsWith("loot/") || menu.startsWith("preset")) return "gear";
    if (menu.startsWith("runes") || menu.startsWith("runesel/")) return "runes";
    if (menu.startsWith("pet") || menu.equals("eggs")) return "pets";
    if (menu.startsWith("worker/") || menu.startsWith("assignment/") || menu.startsWith("specialty/")) return "business";
    if (menu.startsWith("pass/")) return "progress";
    if (menu.startsWith("museum")) return "museum";
    return switch (menu) {
      case "mining", "storage", "smelt", "expeditions" -> "mining";
      case "travel" -> "mines";
      case "gear" -> "upgrades";
      case "combat", "character" -> "combat";
      case "codex", "boss" -> "bosses";
      case "reward" -> "dungeons";
      case "talents" -> "mastery";
      case "guild", "guildnone" -> "guilds";
      case "daily", "goals", "contracts", "research", "milestones", "trade" -> "progress";
      case "business", "crew", "factory", "drone" -> "business";
      case "forestry", "woodwork", "woodupgrades" -> "forest";
      case "top" -> "deep";
      case "prestige" -> "prestige";
      case "alchemy" -> "alchemy";
      case "museum" -> "museum";
      case "glanz" -> "shiny";
      default -> "home";
    };
  }
}
