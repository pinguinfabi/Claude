package de.deepforge.game;

import java.util.*;

/**
 * Prestige (0.12.0): after the Weltenkern boss the player may start over from the Eisenmine. Zone,
 * money, ore and the shop upgrades reset; gear, runes, companions, talents and everything earned
 * stay. Every prestige makes all enemies tougher (×1,35 life, ×1,25 damage) while new loot only
 * grows ×1,15 and ore pays +25 %. There is no cap – but at some point the bosses simply win. That
 * soft wall is the end game.
 */
public final class Prestige {
  private Prestige() {}

  public static final double HEALTH = 1.35, DAMAGE = 1.25, LOOT = 1.15, INCOME = .25;

  /** Tiefenglut talents: one Glut per rank, five ranks each. */
  public enum Node {
    ADER("Glutader", "+10 % Erz- und Barrenwert", "glut_ader", "GLOWSTONE_DUST"),
    KLINGE("Glutklinge", "+6 % Schaden", "glut_klinge", "NETHERITE_SWORD"),
    PANZER("Glutpanzer", "+6 % Leben", "glut_panzer", "NETHERITE_CHESTPLATE"),
    BOHRER("Glutbohrer", "+10 % Abbaukraft", "glut_bohrer", "NETHERITE_PICKAXE"),
    KAPITAL("Glutkapital", "Startgeld nach dem Prestige: 5.000 $ ×4 pro Rang", "glut_kapital", "GOLD_BLOCK");

    public final String title, effect, model, material;

    Node(String title, String effect, String model, String material) {
      this.title = title;
      this.effect = effect;
      this.model = model;
      this.material = material;
    }
  }

  public static final int MAX_RANK = 5;

  // ---- scaling ----

  public static double health(int prestige) {
    return Math.pow(HEALTH, Math.max(0, prestige));
  }

  public static double damage(int prestige) {
    return Math.pow(DAMAGE, Math.max(0, prestige));
  }

  public static double loot(int prestige) {
    return Math.pow(LOOT, Math.max(0, prestige));
  }

  /**
   * Money from fights (monsters, bosses, dungeons, Tiefengang): +25 % per prestige, so harder
   * enemies also pay more. Glutader only boosts ore.
   */
  public static double money(Profile p) {
    return 1 + INCOME * Math.max(0, p.prestige);
  }

  /** Ore and bar prices: +25 % per prestige, +10 % per Glutader rank. */
  public static double income(Profile p) {
    return (1 + INCOME * Math.max(0, p.prestige)) * (1 + .10 * rank(p, Node.ADER));
  }

  public static double damageBonus(Profile p) {
    return 1 + .06 * rank(p, Node.KLINGE);
  }

  public static double healthBonus(Profile p) {
    return 1 + .06 * rank(p, Node.PANZER);
  }

  public static double miningBonus(Profile p) {
    return 1 + .10 * rank(p, Node.BOHRER);
  }

  public static long startMoney(Profile p) {
    int r = rank(p, Node.KAPITAL);
    return r == 0 ? 250 : 5_000L * (long) Math.pow(4, r - 1);
  }

  // ---- Tiefenglut ----

  /** Glut earned by reaching prestige {@code n}: 1, and 2 on every fifth. */
  public static int glutFor(int n) {
    return n % 5 == 0 ? 2 : 1;
  }

  public static int rank(Profile p, Node n) {
    return p.prestigeNodes == null ? 0 : p.prestigeNodes.getOrDefault(n.name(), 0);
  }

  public static String learn(Profile p, Node n) {
    if (p.prestigeNodes == null) p.prestigeNodes = new HashMap<>();
    int r = rank(p, n);
    if (r >= MAX_RANK) return n.title + " ist schon auf Rang " + MAX_RANK + ".";
    if (p.glut < 1) return "Keine Tiefenglut. Du bekommst sie mit jedem Prestige.";
    p.glut--;
    p.prestigeNodes.put(n.name(), r + 1);
    return n.title + " Rang " + (r + 1) + ": " + n.effect + ".";
  }

  // ---- the prestige itself ----

  public static boolean ready(Profile p) {
    return p.zone >= Zone.LAST && p.bosses[Zone.LAST];
  }

  public static String requirement(Profile p) {
    if (p.zone < Zone.LAST)
      return "Schalte den " + Zone.at(Zone.LAST).title + " frei (Gebiet " + (p.zone + 1) + "/" + Zone.COUNT + ").";
    if (!p.bosses[Zone.LAST]) return "Besiege den Boss im " + Zone.at(Zone.LAST).title + ".";
    return "Bereit!";
  }

  /** Items the player already owns keep the prestige they were found in. */
  public static void stamp(Profile p) {
    for (Gear.Item i : p.gear)
      if (i.prestige < 0) {
        double f = loot(p.prestige);
        i.damage *= f;
        i.health *= f;
        i.defense *= f;
        i.prestige = p.prestige;
      }
  }

  public static String perform(Profile p) {
    if (!ready(p)) return "Noch nicht bereit: " + requirement(p);
    stamp(p);
    p.prestige++;
    int glut = glutFor(p.prestige);
    p.glut += glut;
    p.bestPrestige = Math.max(p.bestPrestige, p.prestige);
    p.zone = 0;
    p.money = startMoney(p);
    // Shop upgrades of the run reset; housing and furnace stay so hired workers keep their places.
    p.tool = p.sword = p.armor = 0;
    p.oreLuck = p.bagLevel = p.warehouse = 0;
    Arrays.fill(p.bag, 0);
    Arrays.fill(p.stock, 0);
    Arrays.fill(p.bars, 0);
    Arrays.fill(p.bosses, false);
    p.budget = 0;
    // Workers stay hired but go back to the Eisenmine with the player.
    for (Profile.Worker w : p.workers) if (w.job != Profile.Job.LUMBERJACK) w.zone = 0;
    return "PRESTIGE " + p.prestige + "! +" + glut + " Tiefenglut. Gegner ×" + fmt(health(p.prestige))
        + " Leben, ×" + fmt(damage(p.prestige)) + " Schaden · neue Beute ×" + fmt(loot(p.prestige))
        + " · Erz +" + Math.round(INCOME * p.prestige * 100) + " %.";
  }

  /** Stars for names: ★3, ✪ from 10 on. */
  public static String badge(int prestige) {
    if (prestige <= 0) return "";
    return (prestige >= 10 ? "✪" : "★") + prestige;
  }

  public static String fmt(double v) {
    return String.format(Locale.GERMAN, v >= 100 ? "%,.0f" : "%.2f", v);
  }
}
