package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import java.io.*;
import java.util.*;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.messaging.PluginMessageListener;

/**
 * Network parties (0.17.0): the Deepforge proxy plugin reads the parties of PartyxFreundeSystem
 * and sends them on this channel. Once a snapshot arrived, those are the parties for dungeons,
 * shared camp and mines; /df party create/invite/accept/leave point to /party.
 */
public final class NetworkParties implements PluginMessageListener {
  public static final String CHANNEL = "deepforge:party";

  private final DeepforgePlugin plugin;

  public NetworkParties(DeepforgePlugin plugin) {
    this.plugin = plugin;
  }

  public void register() {
    Bukkit.getMessenger().registerIncomingPluginChannel(plugin, CHANNEL, this);
  }

  @Override
  public void onPluginMessageReceived(String channel, Player via, byte[] data) {
    if (!CHANNEL.equals(channel)) return;
    List<List<UUID>> parties;
    try {
      parties = decode(data);
    } catch (IOException | IllegalArgumentException e) {
      return;
    }
    Runnable apply = () -> plugin.dungeons().parties().sync(parties, this::here);
    if (Bukkit.isPrimaryThread()) apply.run();
    else Bukkit.getScheduler().runTask(plugin, apply);
  }

  private boolean here(UUID id) {
    Player p = Bukkit.getPlayer(id);
    return p != null && plugin.playing(p);
  }

  /** "SNAPSHOT", party count, then per party: member count and UUIDs, leader first. */
  public static List<List<UUID>> decode(byte[] data) throws IOException {
    DataInputStream in = new DataInputStream(new ByteArrayInputStream(data));
    if (!"SNAPSHOT".equals(in.readUTF())) throw new IOException("unknown message");
    int n = in.readInt();
    if (n < 0 || n > 10_000) throw new IOException("bad size");
    List<List<UUID>> out = new ArrayList<>();
    for (int i = 0; i < n; i++) {
      int m = in.readInt();
      if (m < 1 || m > 1_000) throw new IOException("bad party");
      List<UUID> ids = new ArrayList<>();
      for (int j = 0; j < m; j++) ids.add(UUID.fromString(in.readUTF()));
      out.add(ids);
    }
    return out;
  }
}
