package de.deepforge.ui;

import de.deepforge.DeepforgePlugin;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

/**
 * Chat in the network style: rank tag, name in rank colour, "»", message. Players with the pack
 * see the rank tag glyph, everyone else the rank as bold text. Runs on the chat thread, so it only
 * reads the snapshots {@link ServerBoards} refreshes every second.
 */
public final class ChatFormat implements Listener {
  private final DeepforgePlugin plugin;
  private final ServerBoards boards;

  public ChatFormat(DeepforgePlugin plugin, ServerBoards boards) {
    this.plugin = plugin;
    this.boards = boards;
  }

  @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
  public void chat(AsyncChatEvent e) {
    if (!plugin.getConfig().getBoolean("display.chat", true)) return;
    Player source = e.getPlayer();
    PlayerRank rank = boards.knownRank(source.getUniqueId());
    e.renderer(
        (player, displayName, message, viewer) ->
            line(
                rank,
                player.getName(),
                message,
                viewer instanceof Player p && boards.glyphs(p.getUniqueId())));
  }

  public static Component line(PlayerRank rank, String name, Component message, boolean glyphs) {
    Component prefix =
        rank == PlayerRank.NONE
            ? Component.empty()
            : glyphs
                ? Component.text().append(NetzFont.rank(rank)).append(Component.text(" ")).build()
                : Component.text(rank.name() + " ", rank.color).decorate(TextDecoration.BOLD);
    return Component.text()
        .append(prefix)
        .append(Component.text(name, rank.color).decoration(TextDecoration.BOLD, false))
        .append(Component.text(" » ", NamedTextColor.DARK_GRAY))
        .append(message.colorIfAbsent(rank == PlayerRank.NONE ? NamedTextColor.GRAY : NamedTextColor.WHITE))
        .build();
  }
}
