package de.deepforge.world;

import java.util.*;

/** Additive eastern woodland, leaving existing buildings and all underground layers intact. */
public final class ForestBlueprint {
  public record Point(int x, int y, int z) {}

  public record Tree(int id, int species, int x, int z, int height) {}

  public static final List<Tree> TREES;
  // A new marker makes already built forests rebuild once with the larger grove layout.
  public static final String MARKER = "chiseled_resin_bricks";

  /**
   * 0.17.0: groves are gated by forest tier. Hedges of thicket separate them; the only way in is
   * the arch on the main path. Local x where each grove begins (oak from the entrance on).
   */
  public static final int[] GROVE_START = {64, 92, 107};

  /** Which grove a local x lies in (0 oak, 1 birch, 2 spruce), or -1 outside the woodland. */
  public static int grove(double x, double z) {
    if (x < 64 || x > 124 || z < -37 || z > 36) return -1;
    return x >= GROVE_START[2] ? 2 : x >= GROVE_START[1] ? 1 : 0;
  }

  static {
    // Three species groves between the paths, two trees per row, six rows. Crowns stay seven
    // blocks apart so harvesting one tree never touches another.
    List<Tree> trees = new ArrayList<>();
    int[] rows = {-24, -17, -10, 11, 18, 25};
    for (int species = 0; species < 3; species++)
      for (int row = 0; row < rows.length; row++)
        for (int pair = 0; pair < 2; pair++)
          trees.add(
              new Tree(
                  trees.size(),
                  species,
                  81 + species * 15 + pair * 7,
                  rows[row],
                  5 + species + (row + pair) % 2));
    TREES = List.copyOf(trees);
  }

  private final Map<Point, String> blocks = new LinkedHashMap<>();

  public Map<Point, String> blocks() {
    return Collections.unmodifiableMap(blocks);
  }

  private void put(int x, int y, int z, String s) {
    blocks.put(new Point(x, y, z), s);
  }

  private void box(int x1, int y1, int z1, int x2, int y2, int z2, String s) {
    for (int x = x1; x <= x2; x++)
      for (int z = z1; z <= z2; z++) for (int y = y1; y <= y2; y++) put(x, y, z, s);
  }

  public static String log(Tree t) {
    return new String[] {"oak_log", "birch_log", "spruce_log"}[t.species];
  }

  public static String leaves(Tree t) {
    return new String[] {"oak_leaves", "birch_leaves", "spruce_leaves"}[t.species]
        + "[persistent=true]";
  }

  public static Map<Point, String> crown(Tree t) {
    Map<Point, String> result = new LinkedHashMap<>();
    if (t.species == 2) {
      for (int dy = 2; dy <= t.height + 2; dy++) {
        int radius = Math.max(0, 3 - (dy - 2) / 2);
        for (int dx = -radius; dx <= radius; dx++)
          for (int dz = -radius; dz <= radius; dz++)
            if (Math.abs(dx) + Math.abs(dz) <= radius + 1 && (dx != 0 || dz != 0 || dy >= t.height))
              result.put(new Point(t.x + dx, 201 + dy, t.z + dz), leaves(t));
      }
      for (int y = 201; y <= 200 + t.height; y++) result.put(new Point(t.x, y, t.z), log(t));
      return result;
    }
    int spread = t.species == 1 ? 2 : 3;
    for (int dy = -2; dy <= (t.species == 1 ? 3 : 2); dy++)
      for (int dx = -spread; dx <= spread; dx++)
        for (int dz = -spread; dz <= spread; dz++)
          if (Math.abs(dx) + Math.abs(dz) <= 5 - Math.abs(dy) && !(dx == 0 && dz == 0 && dy <= 0))
            result.put(new Point(t.x + dx, 201 + t.height + dy, t.z + dz), leaves(t));
    for (int y = 201; y <= 200 + t.height; y++) result.put(new Point(t.x, y, t.z), log(t));
    return result;
  }

  public static ForestBlueprint create() {
    ForestBlueprint b = new ForestBlueprint();
    b.box(64, 201, -37, 124, 232, 36, "air");
    b.box(64, 197, -37, 124, 199, 36, "dirt");
    b.box(64, 200, -37, 124, 200, 36, "grass_block");
    for (int x = 36; x <= 121; x++)
      for (int z = -3; z <= 3; z++) {
        if (x < 64) b.box(x, 201, z, x, 232, z, "air");
        b.put(x, 200, z, Math.floorMod(x + z, 5) == 0 ? "coarse_dirt" : "gravel");
      }
    for (int x : new int[] {78, 121})
      for (int z = -33; z <= 32; z++)
        for (int dx = -1; dx <= 1; dx++)
          b.put(
              x + dx + (int) Math.round(Math.sin(z * .16)),
              200,
              z,
              Math.floorMod(x + z + dx, 5) == 0 ? "coarse_dirt" : "dirt_path");
    // Soft woodland edges replace the rectangular fence; playable paths stay at ground level.
    for (int x = 65; x <= 123; x++)
      for (int z = -36; z <= 35; z++) {
        int noise = Math.floorMod(x * 31 + z * 17, 29);
        boolean edge = x <= 66 || x >= 123 || z <= -35 || z >= 34;
        if (edge && noise < 19 && Math.abs(z) > 4) {
          b.put(x, 201, z, noise % 3 == 0 ? "mossy_cobblestone" : "moss_block");
          if (noise < 7) b.put(x, 202, z, "azalea_leaves[persistent=true]");
        }
        if (!edge
            && x > 79
            && Math.abs(z) > 5
            && noise < 4
            && b.blocks.get(new Point(x, 200, z)).equals("grass_block")) {
          b.put(x, 200, z, noise == 0 ? "podzol" : "moss_block");
          b.put(x, 201, z, noise == 0 ? "brown_mushroom" : "fern");
        }
      }
    b.box(64, 201, -3, 64, 203, 3, "air");
    for (int z : new int[] {-5, 5}) b.box(65, 201, z, 65, 205, z, "stripped_spruce_log");
    b.box(65, 206, -5, 65, 206, 5, "spruce_log[axis=z]");
    b.put(65, 205, -3, "lantern[hanging=true]");
    b.put(65, 205, 3, "lantern[hanging=true]");
    b.box(70, 200, 4, 72, 200, 11, "gravel");
    // The arches at 92 and 107 carry their own lanterns.
    for (int x : new int[] {69, 78, 121})
      for (int z : new int[] {-4, 4}) {
        b.box(x, 201, z, x, 203, z, "spruce_fence");
        b.put(x, 204, z, "lantern");
      }
    // Timber-framed sawmill with an open front and pitched roof.
    b.box(66, 200, 11, 77, 200, 26, "cobblestone");
    b.box(66, 201, 12, 76, 207, 25, "spruce_planks");
    b.box(67, 201, 13, 75, 206, 24, "air");
    for (int x : new int[] {66, 76})
      for (int z : new int[] {12, 25}) b.box(x, 201, z, x, 208, z, "stripped_spruce_log");
    b.box(69, 201, 12, 73, 204, 12, "air");
    for (int x : new int[] {66, 76}) b.box(x, 203, 16, x, 205, 20, "glass_pane");
    b.box(66, 205, 12, 76, 205, 12, "spruce_log[axis=x]");
    b.box(66, 207, 12, 76, 207, 25, "spruce_planks");
    for (int x = 65; x <= 77; x++) {
      int roof = 215 - Math.abs(x - 71);
      for (int z = 10; z <= 27; z++) {
        b.put(
            x,
            roof,
            z,
            x == 71
                ? "dark_oak_slab"
                : "dark_oak_stairs[facing=" + (x < 71 ? "east" : "west") + "]");
        if ((z == 12 || z == 25) && x >= 66 && x <= 76)
          b.box(x, 208, z, x, roof - 1, z, "spruce_planks");
      }
    }
    b.put(69, 201, 18, "stonecutter[facing=north]");
    b.put(73, 201, 18, "barrel[facing=up]");
    b.put(71, 201, 10, "cartography_table");
    b.put(71, 206, 16, "lantern[hanging=true]");
    b.box(67, 201, -17, 72, 201, -15, "spruce_log[axis=x]");
    b.box(68, 202, -17, 71, 202, -15, "spruce_log[axis=x]");
    b.box(74, 201, -16, 74, 207, -16, "stripped_spruce_log");
    b.box(69, 208, -16, 74, 208, -16, "spruce_log[axis=x]");
    b.box(70, 204, -16, 70, 207, -16, "chain[axis=y]");
    // Shallow spring pool, stony banks and a small footbridge beside the log yard.
    for (int x = 67; x <= 76; x++)
      for (int z = -30; z <= -21; z++) {
        double r = Math.pow((x - 71.5) / 4.5, 2) + Math.pow((z + 25.5) / 4.5, 2);
        if (r < .72) {
          b.put(x, 199, z, "clay");
          b.put(x, 200, z, "water[level=0]");
          if ((x + z) % 5 == 0) b.put(x, 201, z, "lily_pad");
        } else if (r < 1.18) b.put(x, 200, z, (x + z) % 3 == 0 ? "mossy_cobblestone" : "gravel");
      }
    b.box(70, 201, -30, 72, 201, -21, "spruce_slab[type=bottom]");
    for (int z : new int[] {-30, -21}) {
      b.box(69, 201, z, 69, 202, z, "spruce_fence");
      b.put(69, 203, z, "lantern");
    }
    // Tall backdrop conifers frame the working groves without sharing harvest blocks.
    for (int x : new int[] {69, 82, 96, 109, 120}) {
      b.backdropTree(x, -34, 9 + Math.floorMod(x, 4));
      b.backdropTree(x, 33, 8 + Math.floorMod(x, 5));
    }
    b.box(67, 201, 22, 69, 201, 23, "spruce_log[axis=x]");
    b.put(74, 201, 23, "crafting_table");
    b.put(75, 201, 23, "barrel[facing=north]");
    b.put(74, 202, 23, "lantern");
    b.box(67, 201, 7, 68, 201, 9, "oak_log[axis=z]");
    b.put(74, 201, 8, "spruce_stairs[facing=south]");
    b.put(75, 201, 8, "spruce_stairs[facing=south]");
    for (int x : new int[] {68, 74}) {
      b.box(x, 201, 10, x, 203, 10, "spruce_fence");
      b.put(x, 204, 10, "lantern");
    }
    b.wildwood();
    for (Tree t : TREES) {
      // Always leave a clear approach around the base, even after decorating the undergrowth.
      b.box(t.x - 1, 201, t.z - 1, t.x + 1, 202, t.z + 1, "air");
      b.put(t.x, 200, t.z, "rooted_dirt");
      b.blocks.putAll(crown(t));
    }
    b.put(100, 196, 0, MARKER);
    return b;
  }

  private void backdropTree(int x, int z, int height) {
    box(x, 201, z, x, 200 + height, z, "spruce_log");
    for (int dy = 4; dy <= height + 2; dy++) {
      int radius = Math.min(3, Math.max(0, (height + 2 - dy) / 2));
      for (int dx = -radius; dx <= radius; dx++)
        for (int dz = -radius; dz <= radius; dz++)
          if ((dx != 0 || dz != 0 || dy > height) && Math.abs(dx) + Math.abs(dz) <= radius + 1)
            put(x + dx, 201 + dy, z + dz, "spruce_leaves[persistent=true]");
    }
    put(x, 200, z, "podzol");
  }

  // ---- 0.17.0: from a lawn to a real forest ----
  private static int noise(int x, int z, int salt) {
    int h = x * 374761393 + z * 668265263 + salt * 1274126177;
    h = (h ^ (h >>> 13)) * 1274126177;
    return (h ^ (h >>> 16)) & Integer.MAX_VALUE;
  }

  /** Buildings, the yard, the pool and the entrance keep their space. */
  private static boolean reserved(int x, int z) {
    return x <= 79 && z >= 7 && z <= 28
        || x <= 77 && z >= -20 && z <= -12
        || x <= 78 && z >= -32 && z <= -19
        || x <= 70 && Math.abs(z) <= 8;
  }

  private boolean pathAt(int x, int z) {
    String g = blocks.get(new Point(x, 200, z));
    return g != null && (g.equals("gravel") || g.equals("dirt_path") || g.equals("coarse_dirt") && Math.abs(z) <= 3);
  }

  private void wildwood() {
    // Forest floor instead of lawn.
    for (int x = 65; x <= 123; x++)
      for (int z = -36; z <= 35; z++) {
        Point g = new Point(x, 200, z);
        if (!"grass_block".equals(blocks.get(g))) continue;
        int n = noise(x, z, 3) % 100, grove = grove(x, z);
        String floor =
            n < (grove == 2 ? 30 : 14) ? "podzol" : n < 24 ? "coarse_dirt" : n < 32 ? "moss_block" : n < 36 ? "rooted_dirt" : "grass_block";
        put(x, 200, z, floor);
      }
    // Narrow paths through the middle of each grove.
    for (int cx : new int[] {84, 99, 114})
      for (int z = -33; z <= 32; z++) {
        int x = cx + (int) Math.round(Math.sin(z * .19 + cx));
        for (int dx = 0; dx <= 1; dx++) put(x + dx, 200, z, noise(x + dx, z, 5) % 4 == 0 ? "coarse_dirt" : "dirt_path");
      }
    // Thicket hedges between the groves: two to three blocks of leaves on roots, open only at the arch.
    for (int hx : GROVE_START)
      if (hx > 64)
        for (int z = -36; z <= 35; z++) {
          if (Math.abs(z) <= 4) continue;
          for (int dx = -1; dx <= 0; dx++) {
            int x = hx + dx;
            put(x, 200, z, "rooted_dirt");
            int h = 2 + noise(x, z, 7) % 2;
            for (int y = 201; y < 201 + h; y++)
              put(x, y, z, (noise(x, z + y, 9) % 4 == 0 ? "flowering_azalea_leaves" : hx == 92 ? "oak_leaves" : "spruce_leaves") + "[persistent=true]");
          }
        }
    // Gate arches on the main path into the birch and spruce groves.
    for (int hx : new int[] {92, 107}) {
      for (int z : new int[] {-5, 5}) {
        box(hx, 201, z, hx, 207, z, "stripped_dark_oak_log");
        put(hx, 208, z, "dark_oak_slab");
      }
      box(hx, 207, -4, hx, 207, 4, "dark_oak_log[axis=z]");
      for (int z : new int[] {-3, 3}) {
        put(hx, 206, z, "chain[axis=y]");
        put(hx, 205, z, "lantern[hanging=true]");
      }
      put(hx, 208, 0, "carved_pumpkin[facing=west]");
    }
    // Decorative trees everywhere the groves and paths leave room.
    List<int[]> spots = new ArrayList<>();
    for (int x = 66; x <= 123; x += 3)
      for (int z = -35; z <= 34; z += 3) {
        int tx = x + noise(x, z, 11) % 3 - 1, tz = z + noise(x, z, 13) % 3 - 1;
        // Crowns reach three blocks out: trunks stay that far inside the woodland.
        if (tx < 66 || tx > 120 || tz < -33 || tz > 32 || reserved(tx, tz)) continue;
        if (Math.abs(tz) <= 5) continue;
        boolean clear = true;
        // Between four harvest trees there is just room for one more (crowns may touch).
        for (Tree t : TREES) if (Math.hypot(t.x() - tx, t.z() - tz) < 4.5) clear = false;
        for (int dx = -1; dx <= 1 && clear; dx++)
          for (int dz = -1; dz <= 1 && clear; dz++) if (pathAt(tx + dx, tz + dz)) clear = false;
        for (int[] o : spots) if (Math.hypot(o[0] - tx, o[1] - tz) < 3.2) clear = false;
        for (int hx : new int[] {92, 107}) if (tx >= hx - 3 && tx <= hx + 1) clear = false;
        if (clear) spots.add(new int[] {tx, tz});
      }
    int k = 0;
    for (int[] sp : spots) {
      int x = sp[0], z = sp[1], g = grove(x, z), roll = noise(x, z, 17) % 10;
      if (roll < 7) {
        int height = 7 + noise(x, z, 19) % 5;
        if (g == 2 || roll == 0) backdropTree(x, z, height + 2);
        else decoTree(x, z, height, g == 1 && roll != 1 ? "birch" : roll == 2 ? "dark_oak" : "oak");
      } else if (roll == 7) fallenLog(x, z, g == 1 ? "birch_log" : g == 2 ? "spruce_log" : "oak_log", k++);
      else if (roll == 8) boulder(x, z);
      else stump(x, z, g == 1 ? "birch_log" : g == 2 ? "spruce_log" : "oak_log");
    }
    // Undergrowth.
    for (int x = 65; x <= 123; x++)
      for (int z = -36; z <= 35; z++) {
        String floor = blocks.get(new Point(x, 200, z));
        if (floor == null || floor.equals("gravel") || floor.equals("dirt_path") || floor.equals("water[level=0]")) continue;
        if (blocks.containsKey(new Point(x, 201, z)) && !blocks.get(new Point(x, 201, z)).equals("air")) continue;
        if (reserved(x, z) && x <= 70) continue;
        int n = noise(x, z, 23) % 100, g = grove(x, z);
        String plant =
            n < 9 ? "short_grass"
                : n < 13 ? "fern"
                : n < 15 ? "bush"
                : n < 16 ? "firefly_bush"
                : n < 17 ? (g == 2 ? "sweet_berry_bush[age=3]" : "lily_of_the_valley")
                : n < 18 ? (n % 2 == 0 ? "brown_mushroom" : "red_mushroom")
                : n < 23 ? "leaf_litter[facing=" + new String[] {"north", "east", "south", "west"}[noise(x, z, 29) % 4] + ",segment_amount=" + (1 + noise(x, z, 31) % 4) + "]"
                : n < 24 && g == 1 ? "cornflower"
                : null;
        if (plant != null) put(x, 201, z, plant);
      }
  }

  private void decoTree(int x, int z, int height, String wood) {
    String log = wood + "_log", leaves = wood + "_leaves[persistent=true]";
    put(x, 200, z, "rooted_dirt");
    box(x, 201, z, x, 200 + height, z, log);
    int spread = wood.equals("birch") ? 2 : 3;
    for (int dy = -2; dy <= 2; dy++)
      for (int dx = -spread; dx <= spread; dx++)
        for (int dz = -spread; dz <= spread; dz++)
          if (Math.abs(dx) + Math.abs(dz) <= 5 - Math.abs(dy) && !(dx == 0 && dz == 0 && dy <= 0)
              && noise(x + dx, z + dz + dy, 37) % 7 != 0)
            put(x + dx, 201 + height + dy, z + dz, leaves);
    if (wood.equals("dark_oak"))
      for (int[] r : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) put(x + r[0], 201, z + r[1], "dark_oak_wood");
  }

  private void fallenLog(int x, int z, String log, int k) {
    boolean alongX = k % 2 == 0;
    for (int i = -2; i <= 2; i++) {
      int lx = alongX ? x + i : x, lz = alongX ? z : z + i;
      if (pathAt(lx, lz) || reserved(lx, lz)) continue;
      put(lx, 201, lz, log + "[axis=" + (alongX ? "x" : "z") + "]");
      if (noise(lx, lz, 41) % 3 == 0) put(lx, 202, lz, "moss_carpet");
      else if (noise(lx, lz, 43) % 4 == 0) put(lx, 202, lz, "brown_mushroom");
    }
  }

  private void boulder(int x, int z) {
    for (int dx = 0; dx <= 1; dx++)
      for (int dz = 0; dz <= 1; dz++) {
        put(x + dx, 201, z + dz, noise(x + dx, z + dz, 47) % 2 == 0 ? "mossy_cobblestone" : "andesite");
        if (noise(x + dx, z + dz, 53) % 3 == 0) put(x + dx, 202, z + dz, "moss_carpet");
      }
    put(x, 202, z, "mossy_cobblestone");
  }

  private void stump(int x, int z, String log) {
    box(x, 201, z, x, 201 + noise(x, z, 59) % 2, z, log);
    put(x, 203, z, noise(x, z, 61) % 2 == 0 ? "red_mushroom" : "moss_carpet");
  }
}
