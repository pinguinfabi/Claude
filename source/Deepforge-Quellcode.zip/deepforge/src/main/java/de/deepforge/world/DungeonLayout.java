package de.deepforge.world;

import org.bukkit.Material;

/** Three walkable chambers connected by two gated, vaulted galleries. Local floor is y=-1. */
public final class DungeonLayout {
  private DungeonLayout() {}

  public static final int WIDTH = 69, LENGTH = 145, HEIGHT = 15;
  public static final int SIZE = WIDTH * LENGTH * HEIGHT;

  public static int roomZ(int room) {
    return -52 * room;
  }

  public static String name(int room) {
    return new String[] {"Halle der Runen", "Siegelgalerie", "Herz des Gewölbes"}[room];
  }

  public static boolean contains(double x, double y, double z) {
    return x > -48 && x < 20 && z > -124 && z < 20 && y >= -1 && y < 14;
  }

  public static boolean arrived(int room, double x, double z) {
    double local = z - roomZ(room);
    return Math.abs(x) < 14 && local >= -18 && local <= 12;
  }

  public static int nextRoom(int clearedWave) {
    return clearedWave >= 4 ? 2 : 1;
  }

  public static boolean accessible(int room, boolean travelling, double z) {
    return z < roomZ(room) + 20 && z > roomZ(travelling ? Math.min(2, room + 1) : room) - 20;
  }

  public static Material material(int zone, int x, int y, int z) {
    int room = z >= -26 ? 0 : z >= -78 ? 1 : 2;
    int local = z - roomZ(room);
    Material accent =
        switch (zone) {
          case 1 -> Material.AMETHYST_BLOCK;
          case 2 -> Material.MOSS_BLOCK;
          case 3 -> Material.PRISMARINE_BRICKS;
          case 4 -> Material.POLISHED_BLACKSTONE;
          case 5 -> Material.WAXED_CUT_COPPER;
          case 6 -> Material.CRYING_OBSIDIAN;
          default -> Material.POLISHED_ANDESITE;
        };
    Material wall =
        room == 0
            ? Material.STONE_BRICKS
            : room == 1 ? Material.DEEPSLATE_BRICKS : Material.POLISHED_BLACKSTONE_BRICKS;
    Material floor =
        room == 0
            ? Material.POLISHED_ANDESITE
            : room == 1 ? Material.DEEPSLATE_TILES : Material.POLISHED_BLACKSTONE;
    if (x < -20) {
      if (x >= -28 && Math.abs(local) <= 3) {
        if (y == -1) return floor;
        return Math.abs(local) == 3 || y >= 5 ? wall : Material.AIR;
      }
      if (x <= -28 && Math.abs(local) <= 10) {
        if (y == -1) return floor;
        if (x == -48
            || Math.abs(local) == 10
            || y >= 8
            || x == -28 && (Math.abs(local) > 2 || y >= 5))
          return y == 4 && Math.floorMod(x + local, 5) == 0 ? Material.SEA_LANTERN : wall;
        if (y == 0 && x == -38 && local == -3)
          return room == 0
              ? Material.RED_GLAZED_TERRACOTTA
              : room == 1 ? Material.LODESTONE : Material.CHEST;
        if (y == 0 && x == -38 && local == 3 && room == 0) return Material.PURPLE_GLAZED_TERRACOTTA;
        if (room == 1 && (x == -42 || Math.abs(local) == 5) && x <= -42 && y < 4)
          return Material.IRON_BARS;
        return Material.AIR;
      }
      return Material.AIR;
    }
    if (Math.abs(local) > 20) {
      if (Math.abs(x) > 5) return Material.AIR;
      if (y == -1)
        return Math.abs(x) <= 1 ? Material.WAXED_OXIDIZED_CUT_COPPER : Material.STONE_BRICKS;
      if (Math.abs(x) == 5 || y >= 7)
        return y == 4 && Math.floorMod(z, 4) == 0 ? Material.SEA_LANTERN : wall;
      if (y == 5 && Math.abs(x) == 3 && Math.floorMod(z, 4) == 0) return Material.SOUL_LANTERN;
      return Material.AIR;
    }
    if (y == -1) {
      if (Math.abs(x) <= 1) return Material.WAXED_OXIDIZED_CUT_COPPER;
      if ((Math.abs(x) == 12 && Math.abs(local) <= 12)
          || (Math.abs(local) == 12 && Math.abs(x) <= 12)) return accent;
      return Math.floorMod(x * 31 + z, 11) == 0 ? Material.CRACKED_STONE_BRICKS : floor;
    }
    boolean edge = Math.abs(x) == 20 || Math.abs(local) == 20;
    if (edge || y == 13) {
      if (x == -20 && Math.abs(local) <= 2 && y < 5) return Material.IRON_BARS;
      boolean passage =
          Math.abs(x) <= 3 && y < 5 && ((local == -20 && room < 2) || (local == 20 && room > 0));
      if (passage) return Material.IRON_BARS;
      if (y >= 3
          && y <= 7
          && (Math.abs(x) == 20 ? Math.floorMod(local, 8) == 0 : Math.floorMod(x, 8) == 0))
        return y == 5 ? Material.SEA_LANTERN : accent;
      return wall;
    }
    if (x < -15 && Math.abs(local) <= 2 && y < 5) return Material.AIR;
    // Protected side alcove for downed players, away from the path between chambers.
    if (x == 15 && y <= 4) return y == 0 ? Material.CHISELED_STONE_BRICKS : Material.TINTED_GLASS;
    if (Math.abs(x) == 13 && Math.floorMod(local, 8) == 0 && y < 10)
      return y == 7
          ? Material.SHROOMLIGHT
          : room == 1 ? Material.WAXED_CUT_COPPER : Material.POLISHED_BASALT;
    // Raised arches and suspended lights keep the floor traversable.
    if (Math.floorMod(local, 8) == 0 && y == 11 - Math.abs(x) / 5) return wall;
    if (Math.abs(x) == 8 && Math.floorMod(local, 8) == 0 && y >= 5 && y < 9)
      return y == 5 ? Material.SOUL_LANTERN : Material.CHAIN;
    if (room == 2 && Math.abs(x) >= 17 && Math.abs(local) < 12 && y == 0)
      return Material.AMETHYST_BLOCK;
    if (room == 0 && Math.abs(x) >= 17 && Math.floorMod(local, 5) == 0 && y < 2)
      return Material.BOOKSHELF;
    if (room == 1 && Math.abs(x) >= 17 && Math.floorMod(local, 5) == 0 && y < 2)
      return Material.CHISELED_TUFF_BRICKS;
    return Material.AIR;
  }
}
