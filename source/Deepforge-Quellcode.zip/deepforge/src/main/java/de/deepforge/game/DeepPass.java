package de.deepforge.game;

import java.time.LocalDate;
import java.util.*;
import java.util.random.RandomGenerator;

/**
 * Tiefenpass: a 28-day season with 30 reward tiers. Everything a player already does (ore,
 * monsters, dungeons, dailies, trees, contracts) earns pass XP. Free for everyone.
 */
public final class DeepPass {
  public static final int TIERS = 30, SEASON_DAYS = 28, BONUS_XP = 1500;
  public static final long XP_ORE = 1, XP_TREE = 8, XP_KILL = 4, XP_PUZZLE = 25, XP_CHAMPION = 30;
  public static final long XP_CONTRACT = 40, XP_BOSS = 60, XP_DAILY = 80, XP_DUNGEON = 200;

  public enum Kind {
    MONEY("Geld"),
    DUST("Schmiedestaub"),
    HEAL("Lebenssplitter"),
    RELIC("Relikt"),
    NOTES("Forschungsnotizen"),
    GEAR("Ausrüstung");
    public final String title;

    Kind(String title) {
      this.title = title;
    }
  }

  public record Reward(Kind kind, int amount, Gear.Rarity rarity) {}

  private static final Reward[] REWARDS = new Reward[TIERS + 1];

  static {
    Object[][] table = {
      {Kind.MONEY, 1}, {Kind.HEAL, 2}, {Kind.DUST, 5}, {Kind.MONEY, 1}, {Kind.RELIC, 1},
      {Kind.NOTES, 3}, {Kind.HEAL, 3}, {Kind.MONEY, 1}, {Kind.DUST, 8}, {Kind.GEAR, Gear.Rarity.RARE},
      {Kind.MONEY, 1}, {Kind.HEAL, 3}, {Kind.DUST, 10}, {Kind.NOTES, 5}, {Kind.RELIC, 1},
      {Kind.MONEY, 1}, {Kind.HEAL, 4}, {Kind.DUST, 12}, {Kind.MONEY, 1}, {Kind.GEAR, Gear.Rarity.EPIC},
      {Kind.MONEY, 1}, {Kind.NOTES, 8}, {Kind.DUST, 15}, {Kind.HEAL, 4}, {Kind.RELIC, 2},
      {Kind.MONEY, 1}, {Kind.DUST, 20}, {Kind.MONEY, 1}, {Kind.HEAL, 6}, {Kind.GEAR, Gear.Rarity.LEGENDARY}
    };
    for (int t = 1; t <= TIERS; t++) {
      Object[] row = table[t - 1];
      REWARDS[t] =
          row[1] instanceof Gear.Rarity r
              ? new Reward((Kind) row[0], 1, r)
              : new Reward((Kind) row[0], (Integer) row[1], null);
    }
  }

  private DeepPass() {}

  public static int season(LocalDate today) {
    return (int) Math.floorDiv(today.toEpochDay(), SEASON_DAYS) - 739;
  }

  public static int daysLeft(LocalDate today) {
    return SEASON_DAYS - (int) Math.floorMod(today.toEpochDay(), SEASON_DAYS);
  }

  /** A new season starts everyone from zero; returns true when the profile was reset. */
  public static boolean ensure(Profile p, LocalDate today) {
    if (p.passClaimed == null) p.passClaimed = new HashSet<>();
    int season = season(today);
    if (p.passSeason == season) return false;
    p.passSeason = season;
    p.passXp = 0;
    p.passBonus = 0;
    p.passClaimed.clear();
    return true;
  }

  /** XP needed to go from tier t-1 to tier t. */
  public static long need(int tier) {
    return 300 + 30L * tier;
  }

  public static long total(int tier) {
    long sum = 0;
    for (int t = 1; t <= Math.min(tier, TIERS); t++) sum += need(t);
    return sum;
  }

  public static int tier(Profile p) {
    int t = 0;
    while (t < TIERS && p.passXp >= total(t + 1)) t++;
    return t;
  }

  /** XP gathered inside the current tier and the XP that tier needs (bonus tiers after 30). */
  public static long[] progress(Profile p) {
    int t = tier(p);
    if (t >= TIERS) return new long[] {(p.passXp - total(TIERS)) % BONUS_XP, BONUS_XP};
    return new long[] {p.passXp - total(t), need(t + 1)};
  }

  public static int bonusEarned(Profile p) {
    return tier(p) < TIERS ? 0 : (int) ((p.passXp - total(TIERS)) / BONUS_XP);
  }

  /** Adds XP; returns how many tiers (bonus tiers included) were reached by it. */
  public static int add(Profile p, long xp, LocalDate today) {
    ensure(p, today);
    if (xp <= 0) return 0;
    int before = tier(p) + bonusEarned(p);
    p.passXp = Math.addExact(p.passXp, xp);
    return tier(p) + bonusEarned(p) - before;
  }

  public static Reward reward(int tier) {
    return REWARDS[tier];
  }

  public static long money(Profile p, int tier) {
    return (400 + 60L * tier) * (1 + Math.max(0, p.zone));
  }

  public static String describe(Profile p, int tier) {
    Reward r = reward(tier);
    return switch (r.kind()) {
      case MONEY -> String.format(Locale.GERMAN, "%,d $", money(p, tier));
      case GEAR -> r.rarity().title + "e Ausrüstung (dein bestes Gebiet)";
      default -> r.amount() + " " + r.kind().title;
    };
  }

  public static boolean claimable(Profile p, int tier) {
    return tier >= 1 && tier <= tier(p) && !p.passClaimed.contains(tier);
  }

  public static int claimableCount(Profile p) {
    int n = 0;
    for (int t = 1; t <= tier(p); t++) if (!p.passClaimed.contains(t)) n++;
    return n + Math.max(0, bonusEarned(p) - p.passBonus);
  }

  public static String claim(Profile p, int tier, RandomGenerator r) {
    if (p.passClaimed == null) p.passClaimed = new HashSet<>();
    if (tier < 1 || tier > TIERS) return "Unbekannte Stufe.";
    if (p.passClaimed.contains(tier)) return "Schon abgeholt.";
    if (tier > tier(p)) return "Benötigt Tiefenpass-Stufe " + tier + ".";
    Reward reward = reward(tier);
    switch (reward.kind()) {
      case MONEY -> {
        p.money += money(p, tier);
        p.lifetimeRevenue += money(p, tier);
      }
      case DUST -> p.dust += reward.amount();
      case HEAL -> {
        int added = Healing.grant(p, reward.amount());
        // A full healing stock turns the rest into dust instead of wasting it.
        p.dust += (reward.amount() - added) * 2L;
      }
      case RELIC -> p.relics += reward.amount();
      case NOTES -> p.researchNotes += reward.amount();
      case GEAR -> {
        Gear.Item item = Gear.roll(Math.max(0, p.zone), reward.rarity(), r);
        p.gear.add(item);
        p.discovered.add(item.slot.name() + "/" + item.rarity.name());
      }
    }
    p.passClaimed.add(tier);
    return "Tiefenpass Stufe " + tier + ": " + describe(p, tier) + " erhalten!";
  }

  /** Bonus tiers after 30: 10 dust and 2 healing shards each. */
  public static String claimBonus(Profile p) {
    int open = bonusEarned(p) - p.passBonus;
    if (open <= 0) return "Keine Bonusstufe offen.";
    p.passBonus += open;
    p.dust += 10L * open;
    int added = Healing.grant(p, 2 * open);
    p.dust += (2L * open - added) * 2;
    return open + " Bonusstufe" + (open == 1 ? "" : "n") + ": +" + 10 * open + " Schmiedestaub und Lebenssplitter.";
  }

  public static String claimAll(Profile p, RandomGenerator r) {
    int n = 0;
    for (int t = 1; t <= tier(p); t++)
      if (!p.passClaimed.contains(t)) {
        claim(p, t, r);
        n++;
      }
    boolean bonus = bonusEarned(p) > p.passBonus;
    if (bonus) claimBonus(p);
    if (n == 0 && !bonus) return "Keine Belohnung offen – weiter Erfahrung sammeln.";
    return n + " Tiefenpass-Belohnung" + (n == 1 ? "" : "en") + (bonus ? " + Bonus" : "") + " abgeholt!";
  }
}
