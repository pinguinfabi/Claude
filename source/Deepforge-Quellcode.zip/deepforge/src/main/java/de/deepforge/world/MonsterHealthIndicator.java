package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.MonsterHealth;
import java.util.*;
import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/** Non-interactive, owner/party-only plate that is explicitly destroyed with its monster. */
final class MonsterHealthIndicator implements AutoCloseable {
  private final DeepforgePlugin plugin;
  private final Collection<UUID> viewers;
  private final Map<UUID, Integer> shown = new HashMap<>();
  private final TextDisplay display;
  private Component last;

  MonsterHealthIndicator(
      DeepforgePlugin plugin, Location at, Collection<UUID> viewers, boolean boss) {
    this.plugin = plugin;
    this.viewers = viewers;
    display =
        at.getWorld()
            .spawn(
                at,
                TextDisplay.class,
                e -> {
                  e.setPersistent(false);
                  e.setInvulnerable(true);
                  e.setVisibleByDefault(false);
                  e.setBillboard(Display.Billboard.CENTER);
                  e.setAlignment(TextDisplay.TextAlignment.CENTER);
                  e.setSeeThrough(false);
                  e.setShadowed(true);
                  e.setDefaultBackground(false);
                  e.setBackgroundColor(Color.fromARGB(150, 12, 17, 22));
                  e.setLineWidth(360);
                  e.setViewRange(.5f);
                  e.setTeleportDuration(2);
                  e.setBrightness(new Display.Brightness(15, 15));
                  e.setTransformation(
                      new Transformation(
                          new Vector3f(),
                          new Quaternionf(),
                          new Vector3f(boss ? .85f : .75f),
                          new Quaternionf()));
                });
  }

  void update(Location root, double height, String name, double hp, double max, boolean boss) {
    if (!display.isValid()) return;
    Component text = MonsterHealth.text(name, hp, max, boss);
    if (!text.equals(last)) {
      display.text(text);
      last = text;
    }
    Location target = root.clone().add(0, height, 0);
    target.setYaw(0);
    target.setPitch(0);
    if (!display.getWorld().equals(target.getWorld())
        || display.getLocation().distanceSquared(target) > .0001) display.teleport(target);
    for (UUID id : new ArrayList<>(shown.keySet()))
      if (!viewers.contains(id) || Bukkit.getPlayer(id) == null) {
        Player player = Bukkit.getPlayer(id);
        if (player != null) player.hideEntity(plugin, display);
        shown.remove(id);
      }
    for (UUID id : viewers) {
      Player p = Bukkit.getPlayer(id);
      if (p != null && !Objects.equals(shown.get(id), p.getEntityId())) {
        p.showEntity(plugin, display);
        shown.put(id, p.getEntityId());
      }
    }
  }

  TextDisplay entity() {
    return display;
  }

  @Override
  public void close() {
    display.remove();
    shown.clear();
  }
}
