package de.deepforge.world;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;

/**
 * Spectator mode for dungeon watchers and the admin mode. The gamemode and position before
 * entering are stored on the player itself, so a crash or restart never leaves anyone stuck in
 * spectator mode: the next join restores them.
 */
public final class SpectatorState {
  private SpectatorState() {}

  private static final NamespacedKey KEY = new NamespacedKey("deepforge", "spectator_return");

  public static boolean active(Player p) {
    return p.getPersistentDataContainer().has(KEY, PersistentDataType.STRING);
  }

  /** Saves the current state once and switches to spectator mode. */
  public static void enter(Player p) {
    if (!active(p)) {
      Location l = p.getLocation();
      p.getPersistentDataContainer()
          .set(
              KEY,
              PersistentDataType.STRING,
              String.join(
                  ";",
                  p.getGameMode().name(),
                  l.getWorld().getName(),
                  Double.toString(l.getX()),
                  Double.toString(l.getY()),
                  Double.toString(l.getZ()),
                  Float.toString(l.getYaw()),
                  Float.toString(l.getPitch())));
    }
    p.setGameMode(GameMode.SPECTATOR);
  }

  /** Restores the saved gamemode and position; false when nothing was saved. */
  public static boolean restore(Player p) {
    String saved = p.getPersistentDataContainer().get(KEY, PersistentDataType.STRING);
    if (saved == null) return false;
    p.getPersistentDataContainer().remove(KEY);
    String[] v = saved.split(";");
    GameMode mode = GameMode.SURVIVAL;
    try {
      mode = GameMode.valueOf(v[0]);
    } catch (IllegalArgumentException ignored) {
      // Unknown value: survival is the safe default.
    }
    // Never hand spectator mode back, even if it was stored by accident.
    p.setGameMode(mode == GameMode.SPECTATOR ? GameMode.SURVIVAL : mode);
    World world = v.length >= 7 ? Bukkit.getWorld(v[1]) : null;
    if (world != null)
      try {
        p.teleport(
            new Location(
                world,
                Double.parseDouble(v[2]),
                Double.parseDouble(v[3]),
                Double.parseDouble(v[4]),
                Float.parseFloat(v[5]),
                Float.parseFloat(v[6])));
      } catch (NumberFormatException ignored) {
        // Keep the current position.
      }
    return true;
  }
}
