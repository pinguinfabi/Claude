package de.deepforge.game;

import java.text.NumberFormat;
import java.util.*;
import java.util.random.RandomGenerator;

/**
 * Runes (6 kinds × 5 tiers) go into gear sockets. Three equal runes forge one of the next tier.
 * A rune code is kind * 5 + (tier - 1); the profile keeps one counter per code.
 */
public final class Runes {
  public static final int TIERS = 5, CODES = 30, COMBINE = 3;

  /**
   * 0.9.3: runes are much rarer. Chances per source: normal mine monster 0,3 %, champion 25 %,
   * mine boss 35 %, dungeon win 30 %, Tiefengang boss Ebene 40 %, Urboss 2 guaranteed.
   */
  public static final double MONSTER = .003, CHAMPION = .25, BOSS = .35, DUNGEON = .30, DEEP_BOSS = .40;
  public static final String[] ROMAN = {"I", "II", "III", "IV", "V"};

  public enum Kind {
    KRAFT("Kraftrune", "Schaden"),
    STEIN("Steinrune", "Rüstung"),
    LEBEN("Lebensrune", "Leben"),
    WIND("Windrune", "Angriffstempo"),
    GLUECK("Glücksrune", "Krit-Chance"),
    TIEFE("Tiefenrune", "Abbautempo");
    public final String title, stat;

    Kind(String title, String stat) {
      this.title = title;
      this.stat = stat;
    }
  }

  private Runes() {}

  public static int code(Kind kind, int tier) {
    return kind.ordinal() * TIERS + Math.max(1, Math.min(TIERS, tier)) - 1;
  }

  public static Kind kind(int code) {
    return Kind.values()[code / TIERS];
  }

  public static int tier(int code) {
    return code % TIERS + 1;
  }

  public static String name(int code) {
    return kind(code).title + " " + ROMAN[tier(code) - 1];
  }

  /**
   * 0.9.3: every rune adds straight onto the base stats (Grundwerte). Kraft, Stein and Leben add
   * flat points that grow with the zone of the item they sit in (+15 % per zone), so a rune in
   * Weltenkern gear is worth 3,4× the same rune in Eisenmine gear. Wind, Glück and Tiefe add
   * fixed points of tempo, crit chance and mining speed.
   */
  public static double value(int code, int zone) {
    int t = tier(code);
    double z = 1 + Math.max(0, zone) * .15;
    return switch (kind(code)) {
      case KRAFT -> 2 * t * z;
      case STEIN -> 4 * t * z;
      case LEBEN -> 4 * t * z;
      case WIND -> .04 * t;
      case GLUECK -> .015 * t;
      case TIEFE -> .03 * t;
    };
  }

  /** Value in gear of the first mine (for the rune bag). */
  public static double value(int code) {
    return value(code, 0);
  }

  public static double value(int code, Gear.Item host) {
    return value(code, host == null ? 0 : host.zone);
  }

  public static String effect(int code) {
    String base = effect(code, 0);
    return switch (kind(code)) {
      case KRAFT, STEIN, LEBEN ->
          base + " (Eisenmine) bis " + effect(code, Zone.LAST) + " (Weltenkern-Ausrüstung)";
      default -> base;
    };
  }

  public static String effect(int code, Gear.Item host) {
    return effect(code, host == null ? 0 : host.zone);
  }

  public static String effect(int code, int zone) {
    double v = value(code, zone);
    NumberFormat nf = NumberFormat.getNumberInstance(Locale.GERMANY);
    nf.setMaximumFractionDigits(1);
    return switch (kind(code)) {
      case KRAFT -> "+" + nf.format(v) + " Schaden";
      case STEIN -> "+" + nf.format(v) + " Rüstung";
      case LEBEN -> "+" + nf.format(v) + " Leben";
      case WIND -> "+" + nf.format(v / 1.6 * 100) + " % Angriffstempo";
      case GLUECK -> "+" + nf.format(v * 100) + " % Krit-Chance";
      case TIEFE -> "+" + nf.format(v * 100) + " % Abbautempo";
    };
  }

  /** What the runes in one item add to its stats. */
  public static double itemBonus(Gear.Item i, Kind kind) {
    double sum = 0;
    for (int code : sockets(i)) if (code >= 0 && kind(code) == kind) sum += value(code, i);
    return sum;
  }

  static void ensure(Profile p) {
    if (p.runes == null || p.runes.length != CODES) p.runes = Arrays.copyOf(p.runes == null ? new long[0] : p.runes, CODES);
  }

  public static long count(Profile p, int code) {
    ensure(p);
    return p.runes[code];
  }

  public static long total(Profile p) {
    ensure(p);
    return Arrays.stream(p.runes).sum();
  }

  /** Tier found in a zone: I in the first mine up to IV in the last, sometimes one higher. */
  public static int dropTier(int zone, RandomGenerator r) {
    int tier = 1 + Math.max(0, zone) / 2 + (r.nextDouble() < .2 ? 1 : 0);
    return Math.min(TIERS, tier);
  }

  public static int drop(Profile p, int zone, RandomGenerator r) {
    ensure(p);
    int code = code(Kind.values()[r.nextInt(Kind.values().length)], dropTier(zone, r));
    p.runes[code]++;
    return code;
  }

  /** Three equal runes and some dust become one rune of the next tier. */
  public static String combine(Profile p, int code) {
    ensure(p);
    if (code < 0 || code >= CODES) return "Unbekannte Rune.";
    if (tier(code) >= TIERS) return "Stufe V ist die höchste Rune.";
    long dust = 5L * tier(code);
    if (p.runes[code] < COMBINE)
      return "Benötigt " + COMBINE + "× " + name(code) + " (du hast " + p.runes[code] + ").";
    if (p.dust < dust) return "Benötigt " + dust + " Schmiedestaub.";
    p.runes[code] -= COMBINE;
    p.dust -= dust;
    p.runes[code + 1]++;
    return "Runenschmiede: 3× " + name(code) + " → " + name(code + 1) + "!";
  }

  public static int maxSockets(Gear.Item i) {
    return i.rarity.ordinal() >= Gear.Rarity.EPIC.ordinal() ? 2 : 1;
  }

  /** Sockets of an item: -1 = empty. Old items have none until a socket is drilled. */
  public static int[] sockets(Gear.Item i) {
    if (i.runeSockets == null) i.runeSockets = new int[0];
    return i.runeSockets;
  }

  public static long drillMoney(Gear.Item i) {
    return Math.round(1500L * Math.max(i.zone + 1, Economy.scale(i.zone)) * (sockets(i).length + 1));
  }

  public static long drillDust(Gear.Item i) {
    return 10L * (sockets(i).length + 1);
  }

  public static String drill(Profile p, String id) {
    Gear.Item i = Gear.find(p, id);
    if (i == null) return "Gegenstand nicht gefunden.";
    int[] s = sockets(i);
    if (s.length >= maxSockets(i))
      return "Maximal " + maxSockets(i) + " Sockel für " + i.rarity.title + "e Gegenstände.";
    long money = drillMoney(i), dust = drillDust(i);
    if (p.money < money || p.dust < dust)
      return "Benötigt " + money + " $ und " + dust + " Schmiedestaub.";
    p.money -= money;
    p.dust -= dust;
    i.runeSockets = Arrays.copyOf(s, s.length + 1);
    i.runeSockets[s.length] = -1;
    return "Sockel gebohrt! " + i.name + " hat jetzt " + i.runeSockets.length + " Sockel.";
  }

  public static String insert(Profile p, String id, int socket, int code) {
    ensure(p);
    Gear.Item i = Gear.find(p, id);
    if (i == null) return "Gegenstand nicht gefunden.";
    int[] s = sockets(i);
    if (socket < 0 || socket >= s.length) return "Diesen Sockel gibt es nicht.";
    if (s[socket] >= 0) return "Der Sockel ist schon belegt – erst die Rune herausnehmen.";
    if (code < 0 || code >= CODES || p.runes[code] <= 0) return "Diese Rune hast du nicht.";
    p.runes[code]--;
    s[socket] = code;
    return name(code) + " eingesetzt: " + effect(code) + ".";
  }

  public static long removeDust(int code) {
    return 3L * tier(code);
  }

  public static String remove(Profile p, String id, int socket) {
    ensure(p);
    Gear.Item i = Gear.find(p, id);
    if (i == null) return "Gegenstand nicht gefunden.";
    int[] s = sockets(i);
    if (socket < 0 || socket >= s.length || s[socket] < 0) return "In diesem Sockel ist keine Rune.";
    long dust = removeDust(s[socket]);
    if (p.dust < dust) return "Benötigt " + dust + " Schmiedestaub zum Herauslösen.";
    p.dust -= dust;
    p.runes[s[socket]]++;
    String name = name(s[socket]);
    s[socket] = -1;
    return name + " herausgelöst und zurück im Runenbeutel.";
  }

  /** Kraft, Stein and Leben: only the six strongest runes of a kind count (0.9.3). */
  public static final int COUNTED = 6;

  /** Most a percentage rune kind can add in total, however many sockets are filled (0.8.5). */
  public static double cap(Kind kind) {
    return switch (kind) {
      case WIND -> .20;
      case GLUECK -> .10;
      case TIEFE -> .30;
      default -> Double.MAX_VALUE;
    };
  }

  /** Summed rune bonus of one kind over all equipped items: added to the base stat. */
  public static double bonus(Profile p, Set<String> equipped, Kind kind) {
    List<Double> values = new ArrayList<>();
    for (Gear.Item i : p.gear)
      if (equipped.contains(i.id) && i.runeSockets != null)
        for (int code : i.runeSockets) if (code >= 0 && kind(code) == kind) values.add(value(code, i));
    values.sort(Comparator.reverseOrder());
    double sum = 0;
    int counted = 0;
    for (double v : values) {
      if (cap(kind) == Double.MAX_VALUE && counted >= COUNTED) break;
      sum += v;
      counted++;
    }
    return Math.min(cap(kind), sum);
  }
}
