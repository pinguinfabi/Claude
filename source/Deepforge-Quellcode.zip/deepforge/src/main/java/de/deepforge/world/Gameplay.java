package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import de.deepforge.ui.Menus;
import java.util.*;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.*;

public final class Gameplay implements Listener {
  private final DeepforgePlugin plugin;
  private final NamespacedKey ownerKey, zoneKey, bossKey;

  private static final class Mining {
    Block block;
    double progress;
    long swing;

    Mining(Block b, long t) {
      block = b;
      swing = t;
    }
  }

  private record Regrow(Block block, int zone, long at) {}

  /** A rich vein event: one glowing ore block per mine level and plot, shared by its miners. */
  private record Vein(Block block, int zone, int plot, long expires) {}

  private final Map<String, Vein> veins = new HashMap<>();
  // Alerts already shown per player, so each hint appears once per crossing.
  private final Map<UUID, EnumSet<Alert>> alerts = new HashMap<>();
  private final Map<UUID, Long> hazardWarned = new HashMap<>();

  private enum Alert {
    HOT,
    OVERHEATED,
    BAG,
    FULL,
    BOOST_OVER,
    BOOST_READY
  }
  private long nextVein = System.currentTimeMillis() + 60_000;

  private final Map<UUID, Mining> mining = new HashMap<>();
  private final Map<Location, Regrow> regrows = new HashMap<>();
  private final Map<UUID, Double> heat = new HashMap<>();
  private final Map<UUID, Long> boost = new HashMap<>(),
      cooldown = new HashMap<>(),
      scans = new HashMap<>();
  private long tick;

  public Gameplay(DeepforgePlugin plugin) {
    this.plugin = plugin;
    ownerKey = new NamespacedKey(plugin, "mob_owner");
    zoneKey = new NamespacedKey(plugin, "mob_zone");
    bossKey = new NamespacedKey(plugin, "boss");
    Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 2, 2);
  }

  public double heat(Player p) {
    return heat.getOrDefault(p.getUniqueId(), 0d);
  }

  @EventHandler(ignoreCancelled = true)
  public void damageBlock(BlockDamageEvent e) {
    if (!plugin.inWorld(e.getPlayer())) return;
    if (plugin.forestry().canChop(e.getPlayer(), e.getBlock())) return;
    if (!canMine(e.getPlayer(), e.getBlock())) {
      e.setCancelled(true);
      String reason = blocked(e.getPlayer(), e.getBlock());
      if (reason != null) plugin.notice(e.getPlayer(), reason, NamedTextColor.RED);
      return;
    }
    start(e.getPlayer(), e.getBlock());
  }

  private boolean canMine(Player player, Block block) {
    if (!plugin.playing(player)
        || !plugin.items().kind(player.getInventory().getItemInMainHand()).equals("tool"))
      return false;
    Profile p = plugin.profile(player);
    int z = plugin.mines().zoneAt(p, block.getLocation());
    return z >= 0
        && z <= p.zone
        && plugin.mines().orePosition(p, block.getLocation())
        && block.getType() == Material.NOTE_BLOCK
        && p.tool >= Zone.at(z).toolRequired
        && p.bagUsed() < p.bagCapacity()
        && heat(player) < 100;
  }

  /** Small one-time hints so players are never surprised by heat, a full bag or the boost. */
  private void alerts(Player player, long now) {
    UUID id = player.getUniqueId();
    EnumSet<Alert> shown = alerts.computeIfAbsent(id, k -> EnumSet.noneOf(Alert.class));
    boolean drill = plugin.items().kind(player.getInventory().getItemInMainHand()).equals("tool");
    double h = heat(player);
    if (h >= 80 && h < 100 && drill && shown.add(Alert.HOT)) {
      plugin.notice(player, "Bohrer heiß (" + (int) h + " %) – kurz pausieren!", NamedTextColor.GOLD);
      player.playSound(player.getLocation(), Sound.BLOCK_FIRE_EXTINGUISH, .4f, 1.6f);
    } else if (h < 60) shown.remove(Alert.HOT);
    if (h < 40 && shown.remove(Alert.OVERHEATED)) {
      plugin.notice(player, "Bohrer abgekühlt – weiter abbauen!", NamedTextColor.GREEN);
      player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, .5f, 1.4f);
    }
    Profile p = plugin.profile(player);
    double bag = p.bagCapacity() == 0 ? 1 : (double) p.bagUsed() / p.bagCapacity();
    if (bag >= .9 && bag < 1 && shown.add(Alert.BAG))
      plugin.notice(
          player,
          "Rucksack fast voll (" + p.bagUsed() + "/" + p.bagCapacity() + ") – bald einlagern.",
          NamedTextColor.YELLOW);
    else if (bag < .8) shown.remove(Alert.BAG);
    if (bag >= 1 && shown.add(Alert.FULL))
      player.sendMessage(
          net.kyori.adventure.text.Component.text("Deepforge » ", NamedTextColor.GOLD)
              .append(net.kyori.adventure.text.Component.text("Rucksack voll! ", NamedTextColor.RED))
              .append(
                  net.kyori.adventure.text.Component.text("[Lager öffnen & einlagern]", NamedTextColor.AQUA)
                      .clickEvent(net.kyori.adventure.text.event.ClickEvent.runCommand("/df lager"))
                      .hoverEvent(
                          net.kyori.adventure.text.event.HoverEvent.showText(
                              net.kyori.adventure.text.Component.text("Öffnet das Lager – einlagern geht von überall")))));
    else if (bag < 1) shown.remove(Alert.FULL);
    Long boosted = boost.get(id);
    if (boosted != null && boosted <= now && shown.add(Alert.BOOST_OVER))
      plugin.notice(player, "Überladung beendet – du baust einfach normal weiter.", NamedTextColor.GRAY);
    Long ready = cooldown.get(id);
    if (ready != null && ready <= now && drill && shown.add(Alert.BOOST_READY)) {
      plugin.notice(player, "⚡ Überladung wieder bereit – Rechtsklick mit dem Bohrer", NamedTextColor.AQUA);
      player.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, .4f, 1.8f);
    }
  }

  /** Why an ore vein cannot be mined right now, or null when it is not an ore at all. */
  private String blocked(Player player, Block block) {
    if (!plugin.playing(player) || block.getType() != Material.NOTE_BLOCK) return null;
    Profile p = plugin.profile(player);
    int z = plugin.mines().zoneAt(p, block.getLocation());
    if (z < 0 || !plugin.mines().orePosition(p, block.getLocation())) return null;
    if (!plugin.items().kind(player.getInventory().getItemInMainHand()).equals("tool"))
      return "Erz abbauen: Dampfbohrer in die Hand nehmen.";
    if (z > p.zone) return "Dieses Gebiet ist noch gesperrt.";
    if (p.tool < Zone.at(z).toolRequired)
      return "Bohrer-Stufe " + Zone.at(z).toolRequired + " nötig (du hast " + p.tool + ").";
    if (p.bagUsed() >= p.bagCapacity())
      return "Rucksack voll! /df lager – einlagern geht von überall.";
    if (heat(player) >= 100) return "Bohrer überhitzt – kurz abkühlen lassen.";
    return null;
  }

  private void start(Player player, Block block) {
    if (!plugin.playing(player)
        || !plugin.items().kind(player.getInventory().getItemInMainHand()).equals("tool")) return;
    Profile p = plugin.profile(player);
    int z = plugin.mines().zoneAt(p, block.getLocation());
    if (z < 0
        || z > p.zone
        || !plugin.mines().orePosition(p, block.getLocation())
        || block.getType() != Material.NOTE_BLOCK) return;
    if (p.tool < Zone.at(z).toolRequired) {
      plugin.tell(player, "Benötigt Werkzeugstufe " + Zone.at(z).toolRequired + ".");
      return;
    }
    if (p.bagUsed() >= p.bagCapacity()) {
      plugin.tell(player, "Rucksack voll! Am Lager einlagern oder verkaufen.");
      return;
    }
    Mining existing = mining.get(player.getUniqueId());
    if (existing == null || !existing.block.equals(block)) {
      stopMining(player);
      mining.put(player.getUniqueId(), new Mining(block, tick));
    }
  }

  @EventHandler
  public void abort(BlockDamageAbortEvent e) {
    stopMining(e.getPlayer());
  }

  @EventHandler
  public void swing(PlayerAnimationEvent e) {
    Mining m = mining.get(e.getPlayer().getUniqueId());
    if (m != null) m.swing = tick;
  }

  private void stopMining(Player p) {
    mining.remove(p.getUniqueId());
  }

  private void tick() {
    tick += 2;
    long now = System.currentTimeMillis();
    for (Player player : plugin.mines().world().getPlayers()) {
      if (!plugin.playing(player)) continue;
      UUID id = player.getUniqueId();
      Mining m = mining.get(id);
      heat.compute(
          id,
          (k, v) ->
              Math.max(
                  0,
                  (v == null ? 0 : v)
                      - (m == null ? (7 + plugin.profile(player).research[1]) * .1 : 0.05)));
      if (m != null) {
        Block looking = player.getTargetBlockExact(6);
        if (looking == null
            || !looking.equals(m.block)
            || m.block.getType() != Material.NOTE_BLOCK
            || tick - m.swing > 16
            || !plugin.items().kind(player.getInventory().getItemInMainHand()).equals("tool")) {
          stopMining(player);
          continue;
        }
        if (heat(player) >= 100) {
          stopMining(player);
          plugin.tell(player, "Bohrer überhitzt. Kurz abkühlen lassen.");
          alerts.computeIfAbsent(id, k -> EnumSet.noneOf(Alert.class)).add(Alert.OVERHEATED);
          continue;
        }
      }
      if (tick % 10 == 0) alerts(player, now);
      Profile active = plugin.profile(player);
      int activeZone = Math.max(0, plugin.mines().zoneAt(active, player.getLocation()));
      float speed =
          (float) ToolStats.of(active, activeZone, boost.getOrDefault(id, 0L) > now).speed();
      plugin.items().miningSpeed(player, speed);
      // Dungeon watchers and admins in admin mode may be anywhere.
      if (tick % 20 == 0 && (plugin.dungeons().watching(player) || plugin.admin().inMode(player)))
        continue;
      if (tick % 20 == 0) {
        Profile p = plugin.profile(player);
        int z = plugin.mines().zoneAt(p, player.getLocation());
        if (!plugin.dungeons().active(player)
            && (player.getY() < 0 || !plugin.mines().owns(p, player.getLocation()))) {
          plugin.goHome(player);
          continue;
        }
        if (z > p.zone) {
          plugin.goHome(player);
          continue;
        }
        player.setFoodLevel(20);
        if (z >= 0) {
          if (plugin.getConfig().getBoolean("mining.night-vision", false))
            player.addPotionEffect(
                new PotionEffect(PotionEffectType.NIGHT_VISION, 260, 0, false, false));
          int needed = Zone.hazardArmor(z);
          if (needed > 0 && p.armor < needed && tick % 100 == 0) {
            player.damage(1);
            // Say why, at most once a minute, so the damage never looks like a bug.
            if (now - hazardWarned.getOrDefault(id, 0L) > 60_000) {
              hazardWarned.put(id, now);
              plugin.tell(
                  player,
                  Zone.at(z).hazard()
                      + " kostet dich alle 5 Sekunden 1 Leben. Schutz: Schutztraining Stufe "
                      + needed
                      + " (du hast "
                      + p.armor
                      + ") – Menü → Kampf & Ausrüstung → Grundwaffe & Schutz verbessern.");
            }
          }
          if (z == 4) heat.compute(id, (k, v) -> Math.min(95, (v == null ? 0 : v) + .5));
          if (tick % 200 == 0) plugin.combat().regular(player, z);
        }
      }
    }
    if (tick % 20 == 0) veins(now);
    if (tick % 20 == 0) {
      Iterator<Regrow> it = regrows.values().iterator();
      while (it.hasNext()) {
        Regrow r = it.next();
        if (r.at > now) continue;
        if (r.block.getType() == Material.BEDROCK)
          r.block.setBlockData(MineWorld.oreData(r.zone), false);
        it.remove();
      }
    }
  }

  private List<Player> miners(int plot, int zone) {
    List<Player> out = new ArrayList<>();
    for (Player player : plugin.mines().world().getPlayers()) {
      if (!plugin.playing(player) || plugin.dungeons().active(player)) continue;
      Profile p = plugin.profile(player);
      if (plugin.plot(p) == plot && plugin.mines().zoneAt(p, player.getLocation()) == zone)
        out.add(player);
    }
    return out;
  }

  private void veins(long now) {
    Iterator<Vein> it = veins.values().iterator();
    while (it.hasNext()) {
      Vein v = it.next();
      if (v.block.getType() != Material.NOTE_BLOCK || v.expires <= now) {
        if (v.expires <= now)
          for (Player player : miners(v.plot, v.zone))
            plugin.tell(player, "Die reiche Ader ist versiegt. Die nächste kommt bestimmt.");
        it.remove();
        continue;
      }
      Location at = v.block.getLocation().add(.5, .5, .5);
      World w = at.getWorld();
      w.spawnParticle(Particle.WAX_ON, at, 10, .45, .45, .45, 0);
      for (int y = 1; y <= 6; y++)
        w.spawnParticle(Particle.END_ROD, at.clone().add(0, y * .8, 0), 1, .05, .1, .05, 0);
    }
    long every = Math.max(30, plugin.getConfig().getLong("events.rich-vein-seconds", 240)) * 1000;
    if (now < nextVein) return;
    nextVein = now + every;
    // One candidate per occupied mine level; a random one gets the vein.
    Map<String, Player> groups = new LinkedHashMap<>();
    for (Player player : plugin.mines().world().getPlayers()) {
      if (!plugin.playing(player) || plugin.dungeons().active(player)) continue;
      Profile p = plugin.profile(player);
      int zone = plugin.mines().zoneAt(p, player.getLocation());
      if (zone >= 0) groups.putIfAbsent(plugin.plot(p) + ":" + zone, player);
    }
    groups.keySet().removeAll(veins.keySet());
    if (groups.isEmpty()) return;
    List<String> keys = new ArrayList<>(groups.keySet());
    String key = keys.get(java.util.concurrent.ThreadLocalRandom.current().nextInt(keys.size()));
    Player finder = groups.get(key);
    Profile p = plugin.profile(finder);
    int zone = plugin.mines().zoneAt(p, finder.getLocation());
    List<Block> ores = new ArrayList<>();
    for (MineBlueprint.Point at : plugin.mines().blueprint(zone).ores()) {
      Block b =
          plugin.mines().local(p, at.x(), plugin.mines().floor(zone) + at.h(), at.z()).getBlock();
      if (b.getType() == Material.NOTE_BLOCK) ores.add(b);
    }
    if (ores.isEmpty()) return;
    Block block = ores.get(java.util.concurrent.ThreadLocalRandom.current().nextInt(ores.size()));
    long seconds = plugin.getConfig().getLong("events.rich-vein-duration", 120);
    veins.put(key, new Vein(block, zone, plugin.plot(p), now + seconds * 1000));
    for (Player player : miners(plugin.plot(p), zone)) {
      plugin.tell(
          player,
          "✦ REICHE ADER in "
              + Zone.at(zone).title
              + "! 4× Erz und Schmiedestaub für den Ersten. Folge der Lichtsäule ("
              + seconds
              + " s).");
      player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1, 1.4f);
    }
  }

  /** The rich vein on the player's mine level, or null. */
  public Location veinTarget(Player player) {
    if (veins.isEmpty() || !plugin.playing(player)) return null;
    Profile p = plugin.profile(player);
    int zone = plugin.mines().zoneAt(p, player.getLocation());
    Vein v = veins.get(plugin.plot(p) + ":" + zone);
    return v == null ? null : v.block.getLocation().add(.5, .5, .5);
  }

  /** Direction hint for the text action bar, or null when no rich vein is waiting nearby. */
  public String veinHint(Player player) {
    Location at = veinTarget(player);
    if (at == null) return null;
    Location me = player.getLocation();
    return "Reiche Ader "
        + (int) Math.round(at.distance(me))
        + " m "
        + de.deepforge.ui.Hud.arrow(me.getYaw(), at.getX() - me.getX(), at.getZ() - me.getZ());
  }

  private void rewardOre(Player player, Block block, int z) {
    if (z < 0) return;
    Profile p = plugin.profile(player);
    if (p.bagUsed() >= p.bagCapacity()) return;
    ToolStats tool = ToolStats.of(p, z, false);
    long amount = OreYield.roll(p, tool.extraOre(), Math.random(), Math.random());
    if (AdventureGear.has(p, 3)) {
      boolean vein = false;
      for (org.bukkit.block.BlockFace face :
          new org.bukkit.block.BlockFace[] {
            org.bukkit.block.BlockFace.NORTH,
            org.bukkit.block.BlockFace.SOUTH,
            org.bukkit.block.BlockFace.EAST,
            org.bukkit.block.BlockFace.WEST,
            org.bukkit.block.BlockFace.UP,
            org.bukkit.block.BlockFace.DOWN
          }) if (block.getRelative(face).getBlockData().equals(block.getBlockData())) vein = true;
      if (vein && Math.random() < .25) amount++;
    }
    Vein vein = null;
    for (Vein v : veins.values()) if (v.block.equals(block)) vein = v;
    long veinDust = 0;
    if (vein != null) {
      amount *= 4;
      veinDust = 1 + z / 2;
      p.dust += veinDust;
      p.richVeins++;
    }
    amount = Math.min(amount, p.bagCapacity() - p.bagUsed());
    p.bag[z] += amount;
    p.mined += amount;
    p.collected[z] += amount;
    boolean relic = Math.random() < tool.relicChance();
    if (relic) p.relics++;
    if (!plugin.commit(player, p)) return;
    block.setType(Material.BEDROCK, false);
    regrows.put(
        block.getLocation(),
        new Regrow(
            block,
            z,
            System.currentTimeMillis()
                + plugin.getConfig().getLong("mining.respawn-seconds", 25) * 1000));
    heat.merge(player.getUniqueId(), tool.heatPerOre(), Double::sum);
    player.playSound(block.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_BREAK, .4f, 1.2f);
    block
        .getWorld()
        .spawnParticle(
            Particle.BLOCK, block.getLocation().add(.5, .5, .5), 12, MineWorld.oreData(z));
    if (relic) plugin.tell(player, "Seltener Fund: +1 Relikt!");
    if (vein != null) {
      final Vein found = vein;
      veins.values().removeIf(v -> v == found);
      for (Player other : miners(found.plot, found.zone))
        plugin.tell(
            other,
            other.equals(player)
                ? "✦ Reiche Ader abgebaut: +" + amount + " " + Zone.at(z).oreName + ", +" + veinDust + " Schmiedestaub!"
                : player.getName() + " hat die reiche Ader abgebaut.");
      player.playSound(block.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, .7f, 1.5f);
      block.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, block.getLocation().add(.5, .8, .5), 30, .3, .4, .3, .3);
    }
    if (amount > 1) {
      player.sendActionBar(
          net.kyori.adventure.text.Component.text(
              "BONUS · +" + amount + " " + Zone.at(z).oreName,
              net.kyori.adventure.text.format.NamedTextColor.GREEN));
      player.spawnParticle(
          Particle.HAPPY_VILLAGER, block.getLocation().add(.5, .8, .5), 4, .25, .25, .25, 0);
    }
  }

  public void restoreOres(Profile p, int zone) {
    for (MineBlueprint.Point at : plugin.mines().blueprint(zone).ores()) {
      Block b =
          plugin.mines().local(p, at.x(), plugin.mines().floor(zone) + at.h(), at.z()).getBlock();
      if (b.getType() == Material.BEDROCK && !regrows.containsKey(b.getLocation()))
        b.setBlockData(MineWorld.oreData(zone), false);
    }
  }

  @EventHandler
  public void interact(PlayerInteractEvent e) {
    Player player = e.getPlayer();
    if (!plugin.inWorld(player) || e.getHand() != EquipmentSlot.HAND) return;
    if (plugin.playing(player)
        && plugin.forestry().station(plugin.profile(player), e.getClickedBlock())) return;
    if (plugin.dungeons().active(player) && e.isCancelled()) return;
    if (e.getAction() == org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) {
      e.setCancelled(true);
      if (!plugin.playing(player)) return;
      String station =
          plugin.mines().station(plugin.profile(player), e.getClickedBlock().getLocation());
      if (station != null) {
        if (station.equals("home")) plugin.goHome(player);
        else if (station.equals("boss")) plugin.menus().open(player, "boss");
        else if (station.equals("dungeon"))
          plugin.dungeons().open(player, plugin.profile(player).zone);
        else plugin.menus().open(player, station);
        return;
      }
    }
    if (!e.getAction().isRightClick() || !plugin.playing(player)) return;
    String kind = plugin.items().kind(player.getInventory().getItemInMainHand());
    if (kind.equals("book")) {
      e.setCancelled(true);
      plugin.menus().open(player, "main");
    }
    if (kind.equals("tool")) {
      e.setCancelled(true);
      UUID id = player.getUniqueId();
      long now = System.currentTimeMillis();
      if (player.isSneaking()) {
        if (scans.getOrDefault(id, 0L) > now) return;
        scans.put(id, now + 15_000);
        Profile p = plugin.profile(player);
        int z = plugin.mines().zoneAt(p, player.getLocation());
        if (z < 0) return;
        plugin.mines().blueprint(z).ores().stream()
            .map(
                at ->
                    plugin
                        .mines()
                        .local(p, at.x() + .5, plugin.mines().floor(z) + at.h() + .5, at.z() + .5))
            .filter(
                at ->
                    at.getBlock().getType() == Material.NOTE_BLOCK
                        && at.distanceSquared(player.getLocation()) < 24 * 24)
            .sorted(Comparator.comparingDouble(at -> at.distanceSquared(player.getLocation())))
            .limit(16)
            .forEach(at -> at.getWorld().spawnParticle(Particle.END_ROD, at, 4, .2, .2, .2, 0));
        plugin.tell(
            player,
            "Scanner: nahe "
                + Zone.at(z).oreName
                + "-Adern markiert. Folge den Gleisen zur hinteren Bosskammer.");
      } else if (cooldown.getOrDefault(id, 0L) <= now) {
        cooldown.put(id, now + 45_000);
        boost.put(id, now + 8_000);
        EnumSet<Alert> shown = alerts.get(id);
        if (shown != null) {
          shown.remove(Alert.BOOST_OVER);
          shown.remove(Alert.BOOST_READY);
        }
        plugin.tell(player, "Überladung: 8 Sekunden doppelte Abbaugeschwindigkeit!");
      } else
        plugin.tell(
            player, "Überladung bereit in " + (cooldown.get(id) - now) / 1000 + " Sekunden.");
    }
  }

  @EventHandler(ignoreCancelled = true)
  public void hurt(EntityDamageEvent e) {
    if (e.getEntity() instanceof Player player && plugin.playing(player)) {
      if (e.getCause() == EntityDamageEvent.DamageCause.VOID) {
        e.setCancelled(true);
        plugin.goHome(player);
      } else e.setDamage(e.getDamage() * (1 - Gear.stats(plugin.profile(player)).reduction()));
    }
  }

  @EventHandler
  public void death(PlayerDeathEvent e) {
    if (plugin.dungeons().active(e.getEntity())) return;
    if (plugin.playing(e.getEntity())) {
      e.setKeepInventory(true);
      e.getDrops().clear();
      e.setKeepLevel(true);
      e.setDroppedExp(0);
      Profile p = plugin.profile(e.getEntity());
      for (int i = 0; i < 7; i++) p.bag[i] = p.bag[i] * 9 / 10;
      plugin.commit(e.getEntity(), p);
      plugin.tell(
          e.getEntity(),
          "Du verlierst 10 % der ungesicherten Erze. Dein Geld und Lager bleiben erhalten.");
    }
  }

  @EventHandler
  public void respawn(PlayerRespawnEvent e) {
    if (plugin.inWorld(e.getPlayer())) {
      Location dungeon = plugin.dungeons().respawnLocation(e.getPlayer());
      e.setRespawnLocation(
          dungeon == null ? plugin.mines().home(plugin.profile(e.getPlayer())) : dungeon);
      Bukkit.getScheduler()
          .runTask(
              plugin, () -> plugin.items().refresh(e.getPlayer(), plugin.profile(e.getPlayer())));
    }
  }

  @EventHandler
  public void target(EntityTargetLivingEntityEvent e) {
    String owner =
        e.getEntity().getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING);
    if (owner != null
        && e.getTarget() != null
        && !e.getTarget().getUniqueId().toString().equals(owner)) e.setCancelled(true);
  }

  @EventHandler
  public void breakBlock(BlockBreakEvent e) {
    if (!plugin.mines().contains(e.getBlock().getLocation())) return;
    if (plugin.playing(e.getPlayer())
        && plugin.forestry().tree(plugin.profile(e.getPlayer()), e.getBlock()) != null) return;
    e.setCancelled(true);
    e.setDropItems(false);
    if (canMine(e.getPlayer(), e.getBlock())) {
      stopMining(e.getPlayer());
      rewardOre(
          e.getPlayer(),
          e.getBlock(),
          plugin.mines().zoneAt(plugin.profile(e.getPlayer()), e.getBlock().getLocation()));
    } else if (plugin.playing(e.getPlayer())) {
      // Action bar instead of chat: holding the button must not flood the chat.
      String reason = blocked(e.getPlayer(), e.getBlock());
      plugin.notice(
          e.getPlayer(),
          reason != null ? reason : "Nur Erzadern lassen sich abbauen.",
          NamedTextColor.RED);
    }
  }

  @EventHandler
  public void place(BlockPlaceEvent e) {
    if (plugin.mines().contains(e.getBlock().getLocation())) e.setCancelled(true);
  }

  @EventHandler
  public void physics(BlockPhysicsEvent e) {
    if (plugin.mines().contains(e.getBlock().getLocation())
        && e.getBlock().getType() == Material.NOTE_BLOCK) e.setCancelled(true);
  }

  @EventHandler
  public void note(NotePlayEvent e) {
    if (plugin.mines().contains(e.getBlock().getLocation())) e.setCancelled(true);
  }

  @EventHandler
  public void explode(EntityExplodeEvent e) {
    if (plugin.mines().contains(e.getLocation())) {
      e.blockList().clear();
      e.setCancelled(true);
    }
  }

  @EventHandler
  public void blockExplode(BlockExplodeEvent e) {
    if (plugin.mines().contains(e.getBlock().getLocation())) e.setCancelled(true);
  }

  @EventHandler
  public void bucket(PlayerBucketEmptyEvent e) {
    if (plugin.inWorld(e.getPlayer())) e.setCancelled(true);
  }

  @EventHandler
  public void fill(PlayerBucketFillEvent e) {
    if (plugin.inWorld(e.getPlayer())) e.setCancelled(true);
  }

  @EventHandler
  public void drop(PlayerDropItemEvent e) {
    if (!plugin.items().kind(e.getItemDrop().getItemStack()).isEmpty()) e.setCancelled(true);
  }

  @EventHandler
  public void inventory(InventoryClickEvent e) {
    if (!(e.getWhoClicked() instanceof Player player)
        || !plugin.inWorld(player)
        || e.getView().getTopInventory().getHolder() instanceof Menus.Screen) return;
    if (e.getView().getTopInventory().getType() != InventoryType.CRAFTING) e.setCancelled(true);
    if (e.getSlotType() == InventoryType.SlotType.CRAFTING
        && (!plugin.items().kind(e.getCurrentItem()).isEmpty()
            || !plugin.items().kind(e.getCursor()).isEmpty())) e.setCancelled(true);
  }

  @EventHandler
  public void drag(InventoryDragEvent e) {
    if (e.getWhoClicked() instanceof Player player
        && plugin.inWorld(player)
        && !plugin.items().kind(e.getOldCursor()).isEmpty()
        && e.getRawSlots().stream().anyMatch(s -> s < e.getView().getTopInventory().getSize()))
      e.setCancelled(true);
  }

  @EventHandler
  public void changedWorld(PlayerChangedWorldEvent e) {
    if (e.getFrom().equals(plugin.mines().world())) plugin.items().resetMiningSpeed(e.getPlayer());
  }

  @EventHandler
  public void teleport(PlayerTeleportEvent e) {
    if (e.getTo() != null
        && plugin.mines().contains(e.getTo())
        && (e.getCause() == PlayerTeleportEvent.TeleportCause.ENDER_PEARL
            || e.getCause() == PlayerTeleportEvent.TeleportCause.CHORUS_FRUIT))
      e.setCancelled(true);
  }

  public void clear(Player p) {
    stopMining(p);
    if (plugin.drones() != null) plugin.drones().remove(p);
    plugin.items().resetMiningSpeed(p);
    plugin.combat().clear(p, true);
    for (Entity e : plugin.mines().world().getEntities())
      if (p.getUniqueId()
          .toString()
          .equals(e.getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING)))
        e.remove();
    heat.remove(p.getUniqueId());
    boost.remove(p.getUniqueId());
    cooldown.remove(p.getUniqueId());
    scans.remove(p.getUniqueId());
    alerts.remove(p.getUniqueId());
  }

  public void close() {}
}
