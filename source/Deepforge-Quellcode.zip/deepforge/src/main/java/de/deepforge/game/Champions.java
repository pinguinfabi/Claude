package de.deepforge.game;

import java.util.*;
import java.util.random.RandomGenerator;

/** Rare elite mine monsters with one or two traits; they hit harder, last longer and drop runes. */
public final class Champions {
  public static final double CHANCE = .08, HUNT_CHANCE = .32;

  public enum Affix {
    GEPANZERT("Gepanzert", "nimmt 40 % weniger Schaden", 0x9AA4B1),
    RASEND("Rasend", "schneller, greift öfter an", 0xFFB23F),
    VAMPIR("Vampir", "heilt sich bei jedem Treffer an dir", 0xB0203A),
    BRENNEND("Brennend", "+50 % Schaden, setzt dich in Brand", 0xFF5A1F),
    FROSTIG("Frostig", "verlangsamt dich bei Berührung", 0x7FD8FF),
    RIESE("Riese", "doppeltes Leben", 0x5CD65C);
    public final String title, effect;
    public final int color;

    Affix(String title, String effect, int color) {
      this.title = title;
      this.effect = effect;
      this.color = color;
    }
  }

  private Champions() {}

  /** One trait in the upper mines, from the fourth mine on often two. */
  public static List<Affix> roll(int zone, RandomGenerator r) {
    List<Affix> pool = new ArrayList<>(List.of(Affix.values()));
    List<Affix> out = new ArrayList<>();
    int count = zone >= 3 && r.nextDouble() < .5 + zone * .05 ? 2 : 1;
    for (int i = 0; i < count; i++) out.add(pool.remove(r.nextInt(pool.size())));
    return out;
  }

  public static double health(List<Affix> affixes) {
    return 2.5 * (affixes.contains(Affix.RIESE) ? 2 : 1);
  }

  public static double damageTaken(List<Affix> affixes) {
    return affixes.contains(Affix.GEPANZERT) ? .6 : 1;
  }

  /** Damage multiplier on everything the champion deals. */
  public static double damage(List<Affix> affixes) {
    return 1.35 * (affixes.contains(Affix.BRENNEND) ? 1.5 : 1);
  }

  /** Ticks between contact hits (normal monsters: 28). */
  public static int touchCooldown(List<Affix> affixes) {
    return affixes.contains(Affix.RASEND) ? 16 : 28;
  }

  public static double speed(List<Affix> affixes, double base) {
    return base * (affixes.contains(Affix.RASEND) ? 1.35 : 1.1);
  }

  /** Share of the damage dealt that a vampire heals back (of its own maximum life). */
  public static double lifesteal(List<Affix> affixes) {
    return affixes.contains(Affix.VAMPIR) ? .06 : 0;
  }

  public static String name(List<Affix> affixes, String base) {
    StringBuilder b = new StringBuilder("✦ ");
    for (Affix a : affixes) b.append(a.title).append(' ');
    return b.append(base).toString();
  }

  public static String describe(List<Affix> affixes) {
    StringJoiner j = new StringJoiner(" · ");
    for (Affix a : affixes) j.add(a.title + ": " + a.effect);
    return j.toString();
  }

  public static long cash(int zone) {
    return Math.round(120L * (zone + 1) * Zone.deepFactor(zone));
  }
}
