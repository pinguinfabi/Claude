package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import java.util.*;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Vector;

public final class CombatEngine implements Listener, AutoCloseable {
  /**
   * Sets health, clamped to the player's current max health attribute. Deepforge life can be above
   * 20 while the attribute still says 20 (right after joining, before the stats are applied), and
   * Paper throws for values above the attribute (0.16.1).
   */
  public static void setHealth(Player p, double value) {
    var max = p.getAttribute(Attribute.MAX_HEALTH);
    double cap = max == null ? 20 : max.getValue();
    p.setHealth(Math.max(0, Math.min(cap, value)));
  }

  private final DeepforgePlugin plugin;
  private final NamespacedKey ownerKey, originalKey;
  private final Map<UUID, Actor> actors = new HashMap<>();
  private final Map<UUID, Actor> bosses = new HashMap<>();
  private final Map<UUID, Double> stamina = new HashMap<>();
  private final Map<UUID, Long> ability = new HashMap<>(),
      dodge = new HashMap<>(),
      invincible = new HashMap<>(),
      parry = new HashMap<>(),
      lastHit = new HashMap<>(),
      lastHurt = new HashMap<>(),
      comboAt = new HashMap<>();
  private final Map<UUID, Integer> combo = new HashMap<>();
  private final Map<UUID, double[]> originals = new HashMap<>();
  private final List<Entity> lootDisplays = new ArrayList<>();

  private record DamagePopup(UUID owner, TextDisplay display, long born) {}

  private final List<DamagePopup> damagePopups = new ArrayList<>();
  private final Random random = new Random();
  private long tick;
  private RailProbe railProbe;

  public String verifyRails() {
    if (railProbe == null) railProbe = new RailProbe(plugin);
    return railProbe.result();
  }

  private static final class Actor {
    Mob entity;
    UUID owner;
    int zone, mode, kind, sequence;
    // The owner: the only player who sees, hits and is hit by this monster.
    final Set<UUID> fighters = new LinkedHashSet<>();
    boolean boss, ended, summoned;
    double hp, max, posture;
    long next, resolve, broken, born, hazardEnd, nextTouch;
    long recoilUntil;
    final BossPressure pressure = new BossPressure();
    Location sweepOrigin;
    Vector impulse = new Vector();
    Location origin, hazard;
    Vector direction;
    BossRules.Attack attack;
    BossBar bar;
    MonsterRig rig;
    MonsterHealthIndicator health;
    String receipt = UUID.randomUUID().toString();
    // Champion traits; empty for ordinary monsters.
    List<Champions.Affix> affixes = List.of();
    // The rare Urboss (Weltenkern, Albtraum): triple life, +50 % damage, may drop a Sternenstein.
    boolean urboss;
    // Glänzend (0.15.0): double life, golden sparkle, escapes at fleeAt.
    boolean shiny;
    long fleeAt;

    boolean champion() {
      return !affixes.isEmpty();
    }
  }

  public CombatEngine(DeepforgePlugin plugin) {
    this.plugin = plugin;
    ownerKey = new NamespacedKey(plugin, "combat_actor");
    originalKey = new NamespacedKey(plugin, "original_combat_attributes");
    for (Entity e : plugin.mines().world().getEntities())
      if (e.getPersistentDataContainer().has(ownerKey)) e.remove();
    Bukkit.getPluginManager().registerEvents(this, plugin);
    Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 2, 2);
  }

  public boolean fighting(Player p) {
    return bosses.containsKey(p.getUniqueId())
        || plugin.dungeons() != null && plugin.dungeons().active(p);
  }

  public String hud(Player p) {
    long cool = Math.max(0, ability.getOrDefault(p.getUniqueId(), 0L) - tick);
    return "Leben "
        + (int) Math.ceil(p.getHealth())
        + "/"
        + (int) Math.ceil(Gear.stats(plugin.profile(p)).health())
        + "  |  Ausdauer "
        + (int) (double) stamina.getOrDefault(p.getUniqueId(), 100.)
        + "  |  Fähigkeit "
        + (cool == 0 ? "bereit" : (cool + 19) / 20 + "s")
        + (combo(p) >= 2 ? "  |  Kombo x" + combo(p) : "");
  }

  public double stamina(Player p) {
    return stamina.getOrDefault(p.getUniqueId(), 100.);
  }

  public int abilitySeconds(Player p) {
    long cool = Math.max(0, ability.getOrDefault(p.getUniqueId(), 0L) - tick);
    return (int) ((cool + 19) / 20);
  }

  /** Current hit chain; drops to zero once the combo window has passed. */
  public int combo(Player p) {
    UUID id = p.getUniqueId();
    if (tick - comboAt.getOrDefault(id, -1000L) > Talents.comboWindow(plugin.profile(p))) return 0;
    return combo.getOrDefault(id, 0);
  }

  /** Extends the hit chain (mine and dungeon alike) and returns its damage multiplier. */
  public double comboHit(Player p) {
    UUID id = p.getUniqueId();
    int chain =
        RapidCombat.nextCombo(
            combo(p), comboAt.getOrDefault(id, -1000L), tick, Talents.comboWindow(plugin.profile(p)));
    combo.put(id, chain);
    comboAt.put(id, tick);
    if (chain == 5 || chain == 11 || chain % 25 == 0)
      p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, .6f, chain >= 11 ? 1.6f : 1.2f);
    if (chain == 11)
      plugin.notice(
          p, "KOMBO x11 · +30 % Schaden, weiter so!", net.kyori.adventure.text.format.NamedTextColor.AQUA);
    Profile data = plugin.profile(p);
    data.bestCombo = Math.max(data.bestCombo, chain);
    return RapidCombat.comboMultiplier(chain);
  }

  private void breakCombo(UUID id) {
    combo.remove(id);
    comboAt.remove(id);
  }

  public void applyStats(Player p) {
    originals.computeIfAbsent(
        p.getUniqueId(),
        id -> {
          String saved = p.getPersistentDataContainer().get(originalKey, PersistentDataType.STRING);
          if (saved != null) {
            String[] values = saved.split(",");
            if (values.length == 3)
              return new double[] {
                Double.parseDouble(values[0]),
                Double.parseDouble(values[1]),
                Double.parseDouble(values[2])
              };
          }
          double[] values = {
            p.getAttribute(Attribute.MAX_HEALTH).getBaseValue(),
            p.getAttribute(Attribute.ATTACK_SPEED).getBaseValue(),
            p.getAttribute(Attribute.ENTITY_INTERACTION_RANGE).getBaseValue()
          };
          p.getPersistentDataContainer()
              .set(
                  originalKey,
                  PersistentDataType.STRING,
                  values[0] + "," + values[1] + "," + values[2]);
          return values;
        });
    Gear.Stats s = Gear.stats(plugin.profile(p));
    p.getAttribute(Attribute.MAX_HEALTH).setBaseValue(s.health());
    if (p.getHealth() > s.health()) p.setHealth(s.health());
    p.getAttribute(Attribute.ATTACK_SPEED).setBaseValue(16);
    Gear.Item item = Gear.equipped(plugin.profile(p), Gear.Slot.WEAPON);
    p.getAttribute(Attribute.ENTITY_INTERACTION_RANGE)
        .setBaseValue(item != null && item.style.equals("spear") ? 4 : 3);
  }

  private Actor spawn(Player player, int zone, boolean boss, int mode, int kind, Location loc) {
    Actor a = new Actor();
    a.owner = player.getUniqueId();
    a.fighters.add(a.owner);
    a.zone = zone;
    a.boss = boss;
    a.mode = mode;
    a.kind = kind;
    a.born = tick;
    a.next = tick + 45;
    a.max =
        (boss ? RapidCombat.bossHealth(zone, mode) : MonsterScaling.health(zone, kind))
            * Prestige.health(plugin.profile(player).prestige);
    a.hp = a.max;
    a.entity =
        loc.getWorld()
            .spawn(
                loc,
                Husk.class,
                false,
                e -> {
                  e.setAdult();
                  e.setPersistent(false);
                  e.setRemoveWhenFarAway(false);
                  e.setSilent(true);
                  e.setCanPickupItems(false);
                  e.getEquipment().clear();
                  e.setAI(!boss);
                  RailNavigation.allowRails(e);
                  e.setShouldBurnInDay(false);
                  e.getAttribute(Attribute.MOVEMENT_SPEED).setBaseValue(kind == 0 ? .27 : .21);
                  e.getAttribute(Attribute.SCALE).setBaseValue(boss ? 1.65 : kind == 0 ? .7 : 1.0);
                  e.getPersistentDataContainer()
                      .set(ownerKey, PersistentDataType.STRING, a.owner.toString());
                  e.customName(
                      Component.text(
                          boss
                              ? BossRules.NAMES[zone]
                              : new String[] {"Erzkrabbler", "Panzerwächter", "Spaltenwerfer"}
                                  [kind],
                          boss ? NamedTextColor.GOLD : NamedTextColor.RED));
                  e.setCustomNameVisible(false);
                  if (!boss) e.setTarget(player);
                  if (plugin.mines().shared()) {
                    // Personal monster in the shared mine: only its owner sees and bumps it.
                    e.setVisibleByDefault(false);
                    e.setCollidable(false);
                  }
                });
    if (plugin.mines().shared()) player.showEntity(plugin, a.entity);
    if (boss) {
      a.bar =
          BossBar.bossBar(
              Component.text(BossRules.NAMES[zone]),
              1,
              BossBar.Color.RED,
              BossBar.Overlay.NOTCHED_10);
      player.showBossBar(a.bar);
      bosses.put(a.owner, a);
    }
    a.health = new MonsterHealthIndicator(plugin, loc, a.fighters, boss);
    health(a);
    actors.put(a.entity.getUniqueId(), a);
    return a;
  }

  private void health(Actor a) {
    if (a.health != null)
      a.health.update(
          a.entity.getLocation(),
          a.rig == null ? a.entity.getHeight() + .45 : a.rig.labelHeight(),
          a.boss
              ? BossRules.NAMES[a.zone]
              : a.shiny
                  ? (a.champion() ? "✦ " : "") + Shinies.name(a.kind)
              : a.champion()
                  ? Champions.name(
                      a.affixes, new String[] {"Erzkrabbler", "Panzerwächter", "Spaltenwerfer"}[a.kind])
                  : new String[] {"Erzkrabbler", "Panzerwächter", "Spaltenwerfer"}[a.kind],
          a.hp,
          a.max,
          a.boss || a.champion() || a.shiny);
  }

  public void regular(Player p, int zone) {
    if (fighting(p)
        || actors.values().stream().filter(a -> a.owner.equals(p.getUniqueId())).count()
            >= MonsterScaling.MAX_MONSTERS)
      return;
    List<MineBlueprint.Point> route =
        plugin.mines().blueprint(zone).route().stream()
            .filter(at -> at.z() > 50 && at.z() < 77)
            .toList();
    var at = route.get(random.nextInt(route.size()));
    Location l =
        plugin
            .mines()
            .mine(plugin.profile(p), zone, at.x() + .5, 1, at.z() + .5);
    if (l.distanceSquared(p.getLocation()) < 9 || !l.getBlock().isPassable()) return;
    Actor a = spawn(p, zone, false, 0, random.nextInt(3), l);
    double chance =
        plugin.events().active(WorldEvents.Kind.CHAMPIONJAGD)
            ? Champions.HUNT_CHANCE
            : Champions.CHANCE;
    if (random.nextDouble() < chance) champion(a, p);
    if (random.nextDouble() < Shinies.chance(plugin.profile(p))) shiny(a, p);
  }

  /** Admin test: a shiny monster right next to the player in the current mine. */
  public String debugShiny(Player p) {
    int zone = plugin.mines().zoneAt(plugin.profile(p), p.getLocation());
    if (zone < 0) return "Nur in einer Mine möglich.";
    Location at = p.getLocation().add(p.getLocation().getDirection().setY(0).normalize().multiply(3));
    if (!at.getBlock().isPassable()) at = p.getLocation();
    shiny(spawn(p, zone, false, 0, random.nextInt(3), at), p);
    return "Glänzendes Monster erschaffen.";
  }

  private void shiny(Actor a, Player p) {
    a.shiny = true;
    a.max *= Shinies.HEALTH;
    a.hp = a.max;
    a.fleeAt = tick + Shinies.FLEE_TICKS;
    a.entity.setGlowing(true);
    if (a.rig != null) a.rig.glow(Color.fromRGB(255, 215, 60));
    health(a);
    p.showTitle(
        net.kyori.adventure.title.Title.title(
            Component.text("✧ GLÄNZEND! ✧", NamedTextColor.GOLD),
            Component.text(Shinies.name(a.kind).substring(2) + " – schnell, er flieht in 30 s!", NamedTextColor.YELLOW)));
    p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1, 1.8f);
    p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, .5f, 2f);
  }

  /** Admin test: a champion right next to the player in the current mine. */
  public String debugChampion(Player p) {
    int zone = plugin.mines().zoneAt(plugin.profile(p), p.getLocation());
    if (zone < 0) return "Nur in einer Mine möglich.";
    Location at = p.getLocation().add(p.getLocation().getDirection().setY(0).normalize().multiply(3));
    if (!at.getBlock().isPassable()) at = p.getLocation();
    champion(spawn(p, zone, false, 0, random.nextInt(3), at), p);
    return "Champion erschaffen.";
  }

  private final Set<UUID> forceUrboss = new HashSet<>();

  /** Admin test: after this player's next Weltenkern Albtraum boss the Urboss rises for sure. */
  public String debugUrboss(Player p) {
    forceUrboss.add(p.getUniqueId());
    return "Testmodus: nach deinem nächsten Albtraum-Boss im Weltenkern erwacht sicher der Urboss.";
  }

  /** Admin test: the Urboss appears right now in the mine the player stands in. */
  public String debugUrbossNow(Player p) {
    Profile data = plugin.profile(p);
    int zone = plugin.mines().zoneAt(data, p.getLocation());
    if (zone < 0) return "Nur in einer Mine möglich.";
    if (fighting(p)) return "Du kämpfst schon.";
    applyStats(p);
    p.teleport(plugin.mines().mine(data, zone, 2.5, 1, 78.5));
    stamina.put(p.getUniqueId(), 100.);
    urboss(spawn(p, zone, true, 2, 1, plugin.mines().arena(data, zone)), p);
    return "Urboss erschaffen (Gebiet " + (zone + 1) + ").";
  }

  private void urboss(Actor a, Player p) {
    a.urboss = true;
    a.max *= 3;
    a.hp = a.max;
    var scale = a.entity.getAttribute(Attribute.SCALE);
    scale.setBaseValue(scale.getBaseValue() * 1.3);
    a.entity.setGlowing(true);
    if (a.bar != null) {
      a.bar.color(BossBar.Color.PURPLE);
      a.bar.name(Component.text("☠ URBOSS · " + BossRules.NAMES[a.zone], NamedTextColor.DARK_PURPLE));
    }
    health(a);
    p.showTitle(
        net.kyori.adventure.title.Title.title(
            Component.text("☠ DER URBOSS ERWACHT", NamedTextColor.DARK_PURPLE),
            Component.text("Dreifaches Leben · +50 % Schaden · riesige Beute · 2 % Sternenstein", NamedTextColor.GRAY)));
    p.playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, .8f, .7f);
    for (Player other : Bukkit.getOnlinePlayers())
      if (other != p && plugin.playing(other))
        plugin.tell(other, "☠ " + p.getName() + " ist auf den Urboss im Weltenkern getroffen!");
  }

  /** Turns a fresh ordinary monster into a champion with one or two traits. */
  private void champion(Actor a, Player p) {
    a.affixes = Champions.roll(a.zone, random);
    a.max *= Champions.health(a.affixes);
    a.hp = a.max;
    var speed = a.entity.getAttribute(Attribute.MOVEMENT_SPEED);
    speed.setBaseValue(Champions.speed(a.affixes, speed.getBaseValue()));
    var scale = a.entity.getAttribute(Attribute.SCALE);
    scale.setBaseValue(scale.getBaseValue() * (a.affixes.contains(Champions.Affix.RIESE) ? 1.4 : 1.15));
    a.entity.setGlowing(true);
    health(a);
    String base = new String[] {"Erzkrabbler", "Panzerwächter", "Spaltenwerfer"}[a.kind];
    p.sendMessage(
        Component.text("✦ CHAMPION » ", NamedTextColor.LIGHT_PURPLE)
            .append(Component.text(Champions.name(a.affixes, base).substring(2), NamedTextColor.GOLD))
            .append(Component.text(" – " + Champions.describe(a.affixes), NamedTextColor.GRAY)));
    p.playSound(p.getLocation(), Sound.ENTITY_EVOKER_PREPARE_SUMMON, .7f, 1.2f);
  }

  public void start(Player p, int mode) {
    Profile data = plugin.profile(p);
    int z = plugin.mines().zoneAt(data, p.getLocation());
    if (!BossRules.unlocked(data, z, mode)) {
      plugin.tell(p, "Gebiet/Schwierigkeit noch gesperrt. Gewinne zuerst die vorherige Stufe.");
      return;
    }
    if (fighting(p)) {
      plugin.tell(p, "Dein Bosskampf läuft bereits.");
      return;
    }
    clear(p, false);
    p.closeInventory();
    applyStats(p);
    p.teleport(plugin.mines().mine(data, z, 2.5, 1, 78.5));
    setHealth(p, Gear.stats(data).health());
    stamina.put(p.getUniqueId(), 100.);
    spawn(p, z, true, mode, 1, plugin.mines().arena(data, z));
    plugin.tell(
        p,
        "Bosskampf: "
            + new String[] {"Normal", "Veteran", "Alptraum"}[mode]
            + (plugin.mines().shared() ? " · dein persönlicher Boss" : "")
            + ". Warnflächen meiden; Rechtsklick = Fähigkeit, Sneak+Rechtsklick = Ausweichen.");
  }

  private List<Player> fighters(Actor a) {
    return a.fighters.stream().map(Bukkit::getPlayer).filter(Objects::nonNull).toList();
  }

  private void say(Actor a, String text) {
    fighters(a).forEach(f -> plugin.tell(f, text));
  }

  private void tick() {
    tick += 2;
    for (var it = damagePopups.iterator(); it.hasNext(); ) {
      var popup = it.next();
      long age = tick - popup.born;
      if (age >= 22 || !popup.display.isValid()) {
        popup.display.remove();
        it.remove();
        continue;
      }
      popup.display.teleport(popup.display.getLocation().add(0, .045, 0));
      if (age > 12) popup.display.setTextOpacity((byte) Math.max(0, 255 - (age - 12) * 25));
    }
    for (Player p : plugin.mines().world().getPlayers())
      if (plugin.playing(p)) {
        stamina.compute(p.getUniqueId(), (k, v) -> Math.min(100, (v == null ? 100 : v) + 1.2));
        if (tick % 20 == 0) {
          applyStats(p);
          if (!p.isDead()
              && tick - lastHurt.getOrDefault(p.getUniqueId(), -1000L) > 100
              && !fighting(p))
            setHealth(p, Math.min(Gear.stats(plugin.profile(p)).health(), p.getHealth() + .5));
        }
      }
    for (Actor a : new ArrayList<>(actors.values())) {
      if (a.ended) continue;
      Player p = Bukkit.getPlayer(a.owner);
      if (p == null
          || !plugin.playing(p)
          || p.isDead()
          || !a.entity.isValid()
          || plugin.mines().zoneAt(plugin.profile(p), p.getLocation()) != a.zone) {
        end(a);
        continue;
      }
      if (plugin.packApplied(p) && a.rig == null) {
        a.rig =
            new MonsterRig(
                plugin,
                a.entity.getLocation(),
                a.zone,
                a.boss,
                a.kind,
                plugin.mines().shared() ? a.fighters : null);
        a.entity.setInvisible(true);
        if (a.shiny) a.rig.glow(Color.fromRGB(255, 215, 60));
        else if (a.champion()) a.rig.glow(Color.fromRGB(a.affixes.getFirst().color));
      }
      if (a.shiny) {
        Location at = a.entity.getLocation().add(0, 1, 0);
        if (tick % 4 == 0) at.getWorld().spawnParticle(Particle.WAX_ON, at, 3, .4, .6, .4, 0);
        if (tick % 20 == 0) at.getWorld().spawnParticle(Particle.END_ROD, at, 2, .3, .5, .3, .01);
        if (tick >= a.fleeAt) {
          at.getWorld().spawnParticle(Particle.CLOUD, at, 20, .4, .6, .4, .05);
          at.getWorld().playSound(at, Sound.ENTITY_ENDERMAN_TELEPORT, .8f, 1.4f);
          plugin.tell(p, "✧ " + Shinies.name(a.kind).substring(2) + " ist entwischt … nächstes Mal schneller!");
          end(a);
          continue;
        }
        if (tick % 200 == 0 && a.fleeAt - tick <= 200)
          p.sendActionBar(Component.text("✧ Noch " + (a.fleeAt - tick) / 20 + " s, dann flieht er!", NamedTextColor.GOLD));
      }
      if (a.champion() && tick % 10 == 0)
        for (Champions.Affix affix : a.affixes)
          fx(
              a,
              Particle.DUST,
              a.entity.getLocation().add(0, 1, 0),
              4,
              .45,
              .6,
              .45,
              0,
              new Particle.DustOptions(Color.fromRGB(affix.color), 1.3f));
      if (a.rig != null && tick % 20 == 0) a.rig.showTo(a.fighters);
      if (!a.boss && !a.entity.isAware() && tick >= a.recoilUntil) a.entity.setAware(true);
      health(a);
      if (a.boss && a.impulse.lengthSquared() > .0001) {
        if (!KnockbackMotion.push(a.entity, a.impulse.clone().multiply(2))) a.impulse.zero();
        else a.impulse.multiply(.62);
      }
      if (a.boss) {
        Location arena = plugin.mines().arena(plugin.profile(p), a.zone);
        if (p.getLocation().distanceSquared(arena) > 19 * 19
            || tick - a.born > 1200L * RapidCombat.BOSS_TIME_MINUTES) {
          plugin.tell(p, "Bosskampf beendet: Arena verlassen oder Zeit abgelaufen.");
          end(a);
          continue;
        }
        int phase = BossRules.phase(a.hp, a.max);
        a.bar.progress((float) Math.clamp(a.hp / a.max, 0, 1));
        a.bar.name(
            Component.text(
                BossRules.NAMES[a.zone]
                    + " · "
                    + (int) a.hp
                    + " LP · Phase "
                    + phase
                    + " · "
                    + (a.broken > tick
                        ? "KERN OFFEN"
                        : a.resolve > tick
                            ? attackName(a.attack)
                            : !RapidCombat.canBuildPosture(tick, a.broken)
                                ? "STANDFEST"
                                : "Haltung " + (int) a.posture + "/100")));
        if (rearCounter(a, p)) {
          a.next = Math.max(a.next, tick + 20);
        } else if (a.broken > tick) {
          a.resolve = 0;
          a.next = Math.max(a.next, a.broken + 20);
        } else if (a.resolve > 0) {
          if (tick >= a.resolve) {
            resolve(a, p, phase);
            a.resolve = 0;
            a.next = tick + Math.max(12, 36 - phase * 6 - a.mode * 4);
          } else warning(a);
        } else if (tick >= a.next) prepare(a, p, phase);
        else if (tick >= a.recoilUntil) move(a, p);
        if (a.hazard != null && tick < a.hazardEnd) {
          circle(a, a.hazard, 2.8, Color.LIME);
          if (tick % 20 == 0)
            for (Player f : fighters(a))
              if (f.getLocation().distanceSquared(a.hazard) < 8) hurt(f, MonsterScaling.hazard(a.zone), a);
        }
      } else {
        if (a.kind == 2 && tick >= a.next) {
          if (a.resolve == 0) {
            prepare(a, p, 1);
            a.attack = BossRules.Attack.BEAM;
          } else if (tick >= a.resolve) {
            resolve(a, p, 1);
            a.resolve = 0;
            a.next = tick + 80;
          } else warning(a);
        }
        if (a.entity.getLocation().distanceSquared(p.getLocation()) < 3
            && tick >= a.nextTouch
            && a.entity.hasLineOfSight(p)) {
          hurt(p, MonsterScaling.touch(a.zone), a);
          a.nextTouch =
              tick + (a.champion() ? Champions.touchCooldown(a.affixes) : MonsterScaling.TOUCH_COOLDOWN);
        }
      }
      if (a.rig != null)
        a.rig.animate(
            a.entity.getLocation(),
            tick,
            a.resolve > tick || a.sweepOrigin != null,
            a.broken > tick,
            a.entity.getVelocity().lengthSquared() > .001
                || a.boss && a.resolve == 0 && a.sweepOrigin == null);
    }
  }

  private boolean rearCounter(Actor a, Player p) {
    BossPressure.Step step = a.pressure.step(tick, a.broken <= tick && a.resolve == 0);
    if (step == BossPressure.Step.NONE) return false;
    a.impulse.zero();
    if (step == BossPressure.Step.START) {
      a.sweepOrigin = a.entity.getLocation().clone();
      say(a, "RUNDUMSCHLAG! Raus aus dem roten Kreis – auch hinter dem Boss!");
      for (Player f : fighters(a)) f.playSound(a.sweepOrigin, Sound.BLOCK_NOTE_BLOCK_BASS, 1, .5f);
    }
    a.bar.name(
        Component.text(BossRules.NAMES[a.zone] + " · RUNDUMSCHLAG – ABSTAND!", NamedTextColor.RED));
    circle(a, a.sweepOrigin, BossPressure.RADIUS, Color.RED);
    if (step == BossPressure.Step.STRIKE) {
      for (Player f : fighters(a)) {
        Vector d = f.getLocation().toVector().subtract(a.sweepOrigin.toVector());
        if (BossPressure.inSweep(d.getX(), d.getY(), d.getZ()) && a.entity.hasLineOfSight(f))
          hurt(f, MonsterScaling.sweep(a.zone, a.mode), a);
      }
      fx(a, Particle.SWEEP_ATTACK, a.sweepOrigin.clone().add(0, 1, 0), 14, 2, .4, 2, 0, null);
      for (Player f : fighters(a))
        f.playSound(a.sweepOrigin, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1, .6f);
      a.sweepOrigin = null;
    }
    return true;
  }

  private void move(Actor a, Player p) {
    Location l = a.entity.getLocation();
    Vector d = p.getLocation().toVector().subtract(l.toVector()).setY(0);
    if (d.lengthSquared() < .01) return;
    l.setDirection(d);
    if (d.lengthSquared() > 5) {
      Location next = l.clone().add(d.normalize().multiply(.095 + a.mode * .012));
      if (next.getBlock().isPassable()
          && next.clone().add(0, 1, 0).getBlock().isPassable()
          && !next.clone().add(0, -1, 0).getBlock().isPassable()) l = next;
    }
    a.entity.teleport(l);
  }

  private void prepare(Actor a, Player p, int phase) {
    a.attack = a.boss ? BossRules.attack(a.zone, a.sequence++) : BossRules.Attack.BEAM;
    a.origin =
        (a.attack == BossRules.Attack.IMPACT || a.attack == BossRules.Attack.SPORES
                ? p.getLocation()
                : a.entity.getLocation())
            .clone();
    a.origin.setY(plugin.mines().floor(a.zone) + 1.08);
    a.direction = p.getLocation().toVector().subtract(a.entity.getLocation().toVector()).setY(0);
    if (a.direction.lengthSquared() < .01) a.direction = new Vector(0, 0, 1);
    else a.direction.normalize();
    a.entity.setRotation(a.entity.getLocation().setDirection(a.direction).getYaw(), 0);
    a.resolve = tick + Math.max(20, 42 - phase * 5 - a.mode * 3);
    for (Player f : a.boss ? fighters(a) : List.of(p))
      f.playSound(a.origin, Sound.BLOCK_NOTE_BLOCK_BASS, .9f, .7f);
    if (a.boss && phase >= 2 && a.sequence % 4 == 0) {
      for (int n = 0; n < Math.min(3, phase - 1 + a.mode); n++)
        if (actors.values().stream().filter(v -> v.owner.equals(a.owner)).count() < 5)
          spawn(
                      p,
                      a.zone,
                      false,
                      a.mode,
                      0,
                      plugin
                          .mines()
                          .arena(plugin.profile(p), a.zone)
                          .add(n % 2 == 0 ? 3 : -3, 0, -3))
                  .summoned =
              true;
    }
  }

  private static String attackName(BossRules.Attack attack) {
    return switch (attack) {
      case CONE -> "ARMSCHLAG";
      case RING -> "SPRINGEN: STAMPFWELLE";
      case BEAM -> "STRAHL: SEITLICH AUSWEICHEN";
      case IMPACT -> "EINSCHLAG: FLÄCHE VERLASSEN";
      case SPORES -> "SPORENFELD";
      case RUNES -> "RUNEN: IN DIE FREIE GASSE";
    };
  }

  private void circle(Actor a, Location at, double r, Color color) {
    for (int i = 0; i < 32; i++) {
      double angle = i * Math.PI / 16;
      dust(a, at.clone().add(Math.cos(angle) * r, .05, Math.sin(angle) * r), color);
    }
  }

  private void dust(Actor a, Location at, Color c) {
    fx(a, Particle.DUST, at, 1, 0, 0, 0, 0, new Particle.DustOptions(c, 1.2f));
  }

  /** Effects of personal monsters are drawn only for their fighters in the shared mine. */
  private <T> void fx(
      Actor a, Particle type, Location at, int count, double dx, double dy, double dz, double speed,
      T data) {
    if (!plugin.mines().shared()) {
      at.getWorld().spawnParticle(type, at, count, dx, dy, dz, speed, data);
      return;
    }
    for (Player f : fighters(a)) f.spawnParticle(type, at, count, dx, dy, dz, speed, data);
  }

  private void warning(Actor a) {
    Color c = a.zone == 1 ? Color.FUCHSIA : a.zone == 2 ? Color.LIME : Color.ORANGE;
    switch (a.attack) {
      case IMPACT, SPORES -> circle(a, a.origin, 2.8, c);
      case RING -> {
        circle(a, a.origin, 2, c);
        circle(a, a.origin, 6, c);
      }
      case BEAM, RUNES -> {
        Vector side = new Vector(-a.direction.getZ(), 0, a.direction.getX());
        boolean runes = a.attack == BossRules.Attack.RUNES;
        if (runes) circle(a, a.origin, 10, c);
        for (int i = runes ? -10 : 0; i <= (runes ? 10 : 13); i++)
          for (int sign : new int[] {-1, 1})
            dust(
                a,
                a.origin
                    .clone()
                    .add(a.direction.clone().multiply(i))
                    .add(side.clone().multiply(sign * (runes ? 1.8 : 1.2))),
                runes ? Color.LIME : c);
      }
      case CONE -> {
        double center = Math.atan2(a.direction.getZ(), a.direction.getX()), spread = Math.acos(.55);
        for (int i = -10; i <= 10; i++)
          dust(
              a,
              a.origin
                  .clone()
                  .add(
                      6 * Math.cos(center + i * spread / 10),
                      .05,
                      6 * Math.sin(center + i * spread / 10)),
              c);
        for (int i = 0; i < 6; i++)
          for (int sign : new int[] {-1, 1})
            dust(
                a,
                a.origin
                    .clone()
                    .add(
                        i * Math.cos(center + sign * spread),
                        .05,
                        i * Math.sin(center + sign * spread)),
                c);
      }
    }
  }

  private void resolve(Actor a, Player p, int phase) {
    List<Player> targets = a.boss ? fighters(a) : List.of(p);
    for (Player t : targets) {
      Location l = t.getLocation();
      boolean airborne = l.getY() > plugin.mines().floor(a.zone) + 1.65;
      if (!BossRules.hit(
          a.attack,
          l.getX() - a.origin.getX(),
          l.getZ() - a.origin.getZ(),
          a.direction.getX(),
          a.direction.getZ(),
          airborne)) continue;
      hurt(
          t,
          MonsterScaling.attack(a.boss, a.zone, a.mode)
              * (a.attack == BossRules.Attack.IMPACT ? 1.35 : 1),
          a);
      if (a.zone == 3) {
        Vector pull = a.entity.getLocation().toVector().subtract(l.toVector()).setY(0);
        if (pull.lengthSquared() > .1) t.setVelocity(pull.normalize().multiply(.55).setY(.2));
      }
    }
    fx(a, Particle.EXPLOSION, a.origin.clone().add(0, .6, 0), 2, .8, .2, .8, 0, null);
    for (Player t : targets)
      t.playSound(
          a.origin,
          a.zone == 1 ? Sound.BLOCK_AMETHYST_BLOCK_BREAK : Sound.ENTITY_IRON_GOLEM_ATTACK,
          .9f,
          .7f);
    if (a.attack == BossRules.Attack.SPORES) {
      a.hazard = a.origin.clone();
      a.hazardEnd = tick + 100;
    }
    if (a.boss && a.zone == 6 && phase >= 2) {
      Location dest =
          plugin.mines().arena(plugin.profile(p), a.zone).add(a.sequence % 2 == 0 ? 5 : -5, 0, -2);
      if (dest.getBlock().isPassable() && dest.clone().add(0, 1, 0).getBlock().isPassable())
        a.entity.teleport(dest);
    }
  }

  private boolean starring;

  /** Sternenschlag: a star falls on the target and hits every enemy within 3.5 blocks. */
  public void starStrike(Player p, Location at, double damage) {
    if (starring
        || !StarStones.starWeapon(plugin.profile(p))
        || random.nextDouble() >= StarStones.STRIKE_CHANCE) return;
    starring = true;
    try {
      World w = at.getWorld();
      for (int y = 0; y < 8; y++) w.spawnParticle(Particle.END_ROD, at.clone().add(0, 8 - y, 0), 2, .05, .05, .05, 0);
      w.spawnParticle(Particle.FIREWORK, at.clone().add(0, .5, 0), 40, 1.2, .3, 1.2, .1);
      w.playSound(at, Sound.ITEM_TRIDENT_THUNDER, .6f, 1.6f);
      w.playSound(at, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1, .8f);
      for (AbilityTarget t : abilityTargets(p))
        if (t.entity().isValid() && t.entity().getLocation().distanceSquared(at) <= 12.25) t.hit().accept(damage);
    } finally {
      starring = false;
    }
  }

  /** Sternenschild: star-forged armour may block a hit completely. */
  private boolean starShield(Player p) {
    double chance = StarStones.shieldChance(plugin.profile(p));
    if (chance <= 0 || random.nextDouble() >= chance) return false;
    lastHurt.put(p.getUniqueId(), tick);
    p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1, 0), 25, .5, .8, .5, .08);
    p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1, 1.8f);
    plugin.notice(p, "✦ Sternenschild: Treffer abgewehrt!", NamedTextColor.GOLD);
    return true;
  }

  private void hurt(Player p, double damage, Actor source) {
    UUID id = p.getUniqueId();
    damage *= Prestige.damage(plugin.profile(p).prestige);
    if (p.isDead()
        || invincible.getOrDefault(id, 0L) > tick
        || tick - lastHurt.getOrDefault(id, -100L) < 10) return;
    if (starShield(p)) return;
    if (parry.getOrDefault(id, 0L) > tick) {
      if (RapidCombat.canBuildPosture(tick, source.broken) && source.sweepOrigin == null)
        source.posture += 35;
      parry.remove(id);
      p.playSound(p.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1, 1.2f);
      return;
    }
    Profile data = plugin.profile(p);
    Gear.Stats stats = Gear.stats(data);
    if (source.urboss) damage *= 1.5;
    if (source.champion()) {
      damage *= Champions.damage(source.affixes);
      if (source.affixes.contains(Champions.Affix.BRENNEND)) p.setFireTicks(40);
      if (source.affixes.contains(Champions.Affix.FROSTIG))
        p.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.SLOWNESS, 50, 1, false, true));
      if (source.affixes.contains(Champions.Affix.VAMPIR)) {
        source.hp = Math.min(source.max, source.hp + source.max * Champions.lifesteal(source.affixes));
        health(source);
      }
    }
    double amount =
        damage
            * (1 - stats.reduction())
            * Talents.damageTaken(data)
            * (1 - Alchemy.bonus(data, Alchemy.Potion.SCHUTZ));
    if (source.zone == 2 && Gear.hasEffect(data, 2)) amount *= .65;
    lastHurt.put(id, tick);
    breakCombo(id);
    p.setHealth(Math.max(0, p.getHealth() - amount));
    p.playHurtAnimation(0);
    p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_HURT, .7f, 1);
  }

  /** Admin test: no damage from monsters and bosses (toggle). */
  public String debugGod(Player p) {
    UUID id = p.getUniqueId();
    if (invincible.getOrDefault(id, 0L) == Long.MAX_VALUE) {
      invincible.remove(id);
      return "Testmodus: Unverwundbarkeit aus.";
    }
    invincible.put(id, Long.MAX_VALUE);
    return "Testmodus: unverwundbar (nochmal /df admin gott zum Ausschalten).";
  }

  /** Dungeons share dodge, parry, armor and hurt protection with the existing combat system. */
  /** Applies a dungeon hit; returns the damage actually taken (0 when blocked or immune). */
  public double dungeonDamage(Player p, double damage, Runnable defeated) {
    UUID id = p.getUniqueId();
    if (p.isDead()
        || invincible.getOrDefault(id, 0L) > tick
        || tick - lastHurt.getOrDefault(id, -100L) < 10) return 0;
    if (starShield(p)) return 0;
    if (parry.getOrDefault(id, 0L) > tick) {
      parry.remove(id);
      p.playSound(p.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1, 1.2f);
      return 0;
    }
    double amount =
        damage
            * (1 - Gear.stats(plugin.profile(p)).reduction())
            * Talents.damageTaken(plugin.profile(p))
            * (1 - Alchemy.bonus(plugin.profile(p), Alchemy.Potion.SCHUTZ));
    lastHurt.put(id, tick);
    breakCombo(id);
    double taken = Math.min(amount, p.getHealth());
    if (amount >= p.getHealth()) defeated.run();
    else p.setHealth(p.getHealth() - amount);
    p.playHurtAnimation(0);
    p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_HURT, .7f, 1);
    return taken;
  }

  @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
  public void damage(EntityDamageByEntityEvent e) {
    Actor target = actors.get(e.getEntity().getUniqueId()),
        source = actors.get(e.getDamager().getUniqueId());
    if (source != null) {
      e.setCancelled(true);
      return;
    }
    if (e.getEntity() instanceof Player victim && plugin.inWorld(victim)) {
      Entity damager = e.getDamager();
      if (damager instanceof Player
          || damager instanceof Projectile projectile
              && projectile.getShooter() instanceof Player) {
        e.setCancelled(true);
        return;
      }
    }
    if (target == null) return;
    e.setCancelled(true);
    if (!(e.getDamager() instanceof Player p)
        || !target.fighters.contains(p.getUniqueId())
        || !plugin.playing(p)) return;
    if (!plugin.items().kind(p.getInventory().getItemInMainHand()).equals("sword")) return;
    Gear.Stats stats = Gear.stats(plugin.profile(p));
    long serverTick = Bukkit.getCurrentTick();
    if (lastHit.getOrDefault(p.getUniqueId(), -1L) == serverTick) return;
    if (p.getLocation().distanceSquared(target.entity.getLocation()) > 30) return;
    lastHit.put(p.getUniqueId(), serverTick);
    hit(target, p, RapidCombat.damage(stats), true);
  }

  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  public void environment(EntityDamageEvent e) {
    if (actors.containsKey(e.getEntity().getUniqueId())) e.setCancelled(true);
  }

  private void hit(Actor a, Player p, double damage, boolean posture) {
    hit(a, p, damage, posture, true);
  }

  private void hit(Actor a, Player p, double damage, boolean posture, boolean procAllowed) {
    if (a.ended) return;
    ArtifactCombat.Proc proc =
        procAllowed
            ? plugin.adventure().hit(p, a.entity.getUniqueId())
            : new ArtifactCombat.Proc(false, false);
    boolean fractured = plugin.adventure().fractured(a.entity.getUniqueId());
    Gear.Stats stats = Gear.stats(plugin.profile(p));
    boolean critical = random.nextDouble() < stats.crit();
    Gear.Item weapon = Gear.equipped(plugin.profile(p), Gear.Slot.WEAPON);
    String style = weapon == null ? "sword" : weapon.style;
    Vector delta = p.getLocation().toVector().subtract(a.entity.getLocation().toVector());
    Vector facing = a.entity.getLocation().getDirection();
    double alignment = WeaponRules.facing(delta.getX(), delta.getZ(), facing.getX(), facing.getZ());
    if (a.boss && a.broken <= tick)
      a.pressure.hit(tick, alignment, delta.clone().setY(0).lengthSquared());
    boolean guarded =
        a.boss && a.broken <= tick
            || !a.boss && a.kind == 1 && alignment >= .3 && a.resolve <= tick;
    damage *=
        WeaponRules.multiplier(
            style,
            WeaponRules.rearBonus(weapon),
            !a.boss && a.kind == 1,
            a.resolve > tick || fractured,
            alignment);
    if (!a.boss && fractured) damage *= 1.15;
    if (style.equals("dagger") && alignment <= -.5)
      p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, .7f, 1.4f);
    if (procAllowed) damage *= comboHit(p);
    damage *= abilityBuff(p);
    if (!critical && procAllowed && Talents.bloodrush(plugin.profile(p)) && combo(p) % 10 == 0)
      critical = true;
    if (critical) damage *= stats.critDamage();
    if (a.boss) {
      if (a.broken > tick) damage *= 1.35;
      else {
        damage *= fractured ? .85 : .55;
        if (posture && RapidCombat.canBuildPosture(tick, a.broken) && a.sweepOrigin == null)
          a.posture +=
              RapidCombat.posture(stats)
                  * (Gear.hasEffect(plugin.profile(p), 0)
                          && dodge.getOrDefault(p.getUniqueId(), -100L) + 25 > tick
                      ? 1.5
                      : 1);
      }
      if (a.posture >= 100
          && RapidCombat.canBuildPosture(tick, a.broken)
          && a.sweepOrigin == null) {
        a.posture = 0;
        a.broken = tick + 90;
        a.resolve = 0;
        say(a, "Schutz gebrochen! Der Kern ist offen.");
      }
    }
    if (a.champion()) damage *= Champions.damageTaken(a.affixes);
    double applied = HitFeedback.applied(a.hp, damage);
    boolean backstab = style.equals("dagger") && alignment <= -.5;
    a.hp = Math.max(0, a.hp - damage);
    health(a);
    a.entity.playHurtAnimation(0);
    if (a.rig != null) a.rig.hurt(tick);
    showDamage(
        p,
        a.entity.getLocation().add(0, a.boss ? 3.25 : 2, 0),
        applied,
        critical,
        backstab,
        guarded);
    if (procAllowed) starStrike(p, a.entity.getLocation(), damage);
    if (a.hp > 0) {
      Vector away = a.entity.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
      if (away.lengthSquared() < .001) away = p.getLocation().getDirection().setY(0);
      if (away.lengthSquared() > .001 && tick >= a.recoilUntil + 8 && a.sweepOrigin == null) {
        away.normalize().multiply(HitFeedback.knockback(style, a.boss, a.broken > tick));
        a.recoilUntil = tick + (a.boss ? 2 : 8);
        if (a.boss) a.impulse = away;
        else {
          a.entity.getPathfinder().stopPathfinding();
          a.entity.setAware(false);
          a.entity.setVelocity(away.setY(style.equals("hammer") ? .24 : .17));
        }
      }
    }
    fx(
        a,
        critical ? Particle.CRIT : Particle.BLOCK,
        a.entity.getLocation().add(0, 1, 0),
        8,
        .3,
        .4,
        .3,
        1,
        critical ? null : Material.STONE.createBlockData());
    p.playSound(a.entity.getLocation(), Sound.ENTITY_IRON_GOLEM_HURT, .45f, critical ? 1.5f : .9f);
    if (proc.lightning()) {
      Location origin = a.entity.getLocation().add(0, 1, 0);
      for (Actor other :
          actors.values().stream()
              .filter(
                  v ->
                      v != a
                          && !v.ended
                          && v.fighters.contains(p.getUniqueId())
                          && v.entity.getLocation().distanceSquared(origin) < 36
                          && a.entity.hasLineOfSight(v.entity))
              .limit(3)
              .toList()) {
        plugin.adventure().arc(p, origin, other.entity.getLocation().add(0, 1, 0));
        hit(other, p, plugin.adventure().arcDamage(p), false, false);
      }
    }
    if (proc.fracture()) plugin.tell(p, "Runenhammer: Panzer für 4 Sekunden gebrochen!");
    if (a.hp <= 0) victory(a, p);
  }

  private void victory(Actor a, Player p) {
    if (a.ended) return;
    Location at = a.entity.getLocation();
    List<Player> winners = a.boss ? fighters(a) : List.of(p);
    end(a);
    if (a.summoned) return;
    if (a.boss)
      for (Actor other : new ArrayList<>(actors.values()))
        if (winners.stream().anyMatch(w -> w.getUniqueId().equals(other.owner))) end(other);
    for (Player w : winners) reward(a, w, at);
    // After the Albtraum boss of the Weltenkern falls, the Urboss may rise (1 %): an extra fight.
    if (a.boss
        && !a.urboss
        && StarStones.urbossPossible(a.zone, a.mode)
        && (forceUrboss.remove(p.getUniqueId()) || random.nextDouble() < StarStones.URBOSS_CHANCE)) {
      int zone = a.zone, mode = a.mode;
      p.showTitle(
          net.kyori.adventure.title.Title.title(
              Component.text("Der Boden bebt …", NamedTextColor.DARK_PURPLE),
              Component.text("Etwas Uraltes erwacht in der Tiefe", NamedTextColor.GRAY)));
      p.playSound(p.getLocation(), Sound.ENTITY_WARDEN_EMERGE, 1, .6f);
      Bukkit.getScheduler()
          .runTaskLater(
              plugin,
              () -> {
                if (!p.isOnline() || p.isDead() || fighting(p)) return;
                Profile data = plugin.profile(p);
                if (plugin.mines().zoneAt(data, p.getLocation()) != zone) return;
                applyStats(p);
                p.teleport(plugin.mines().mine(data, zone, 2.5, 1, 78.5));
                setHealth(p, Gear.stats(data).health());
                stamina.put(p.getUniqueId(), 100.);
                urboss(spawn(p, zone, true, mode, 1, plugin.mines().arena(data, zone)), p);
              },
              100);
    }
  }

  private void reward(Actor a, Player p, Location at) {
    plugin.adventure().kill(p, at);
    Profile data = plugin.profile(p);
    boolean flood = plugin.events().active(WorldEvents.Kind.MONSTERFLUT);
    List<Gear.Item> loot = new ArrayList<>();
    long cash = 0;
    List<Integer> runes = new ArrayList<>();
    Shinies.Loot shinyLoot = null;
    if (a.boss) {
      loot.addAll(Gear.bossLoot(data, a.receipt, a.zone, a.mode, random));
      Alchemy.gain(data, Alchemy.Ingredient.ESSENZ, 5);
      if (random.nextDouble() < Runes.BOSS) runes.add(Runes.drop(data, a.zone, random));
      if (a.urboss) {
        // The good stuff: a second boss loot, a guaranteed legendary (20 % mythic) piece, more runes.
        loot.addAll(Gear.bossLoot(data, a.receipt + "/urboss", a.zone, a.mode, random));
        Gear.Item prize =
            Gear.roll(a.zone, random.nextDouble() < .2 ? Gear.Rarity.MYTHIC : Gear.Rarity.LEGENDARY, random);
        prize.name = "Ur-" + prize.name;
        data.gear.add(prize);
        data.discovered.add(prize.slot.name() + "/" + prize.rarity.name());
        loot.add(prize);
        for (int n = 0; n < 2; n++) runes.add(Runes.drop(data, a.zone, random));
        data.dust += 150;
        long bonus = 250_000;
        data.money += bonus;
        data.lifetimeRevenue += bonus;
      }
    } else {
      data.kills++;
      Gear.huntKill(data, a.zone);
      if (a.shiny) shinyLoot = Shinies.reward(data, a.zone, a.kind, random);
      if (a.champion()) Alchemy.gain(data, Alchemy.Ingredient.ESSENZ, 3);
      else if (random.nextDouble() < Alchemy.ESSENCE_CHANCE) Alchemy.gain(data, Alchemy.Ingredient.ESSENZ, 1);
      cash = Math.round(30L * (a.zone + 1) * Prestige.money(data));
      data.money += cash;
      data.lifetimeRevenue += cash;
      data.monsterParts[a.zone] += 1 + a.kind;
      if (a.champion()) {
        long bonus = Math.round(Champions.cash(a.zone) * Prestige.money(data));
        cash += bonus;
        data.money += bonus;
        data.lifetimeRevenue += bonus;
        data.champions++;
        if (random.nextDouble() < Runes.CHAMPION) runes.add(Runes.drop(data, a.zone, random));
      } else if (random.nextDouble() < Runes.MONSTER + Talents.runeChance(data))
        runes.add(Runes.drop(data, a.zone, random));
      if (random.nextDouble() < (a.champion() ? .5 : flood ? .28 : .14)) {
        Gear.Item item =
            Gear.roll(
                a.zone,
                a.champion()
                    ? random.nextDouble() < .25 ? Gear.Rarity.EPIC : Gear.Rarity.RARE
                    : random.nextDouble() < .2 ? Gear.Rarity.RARE : Gear.Rarity.UNCOMMON,
                random);
        data.gear.add(item);
        data.discovered.add(item.slot.name() + "/" + item.rarity.name());
        loot.add(item);
      }
    }
    data.bestCombo = Math.max(data.bestCombo, combo(p));
    int healingDrop =
        (a.boss || random.nextDouble() < (flood ? .20 : .10)) ? Healing.grant(data, a.boss ? 2 : 1) : 0;
    plugin.passXp(
        p, a.boss ? DeepPass.XP_BOSS : a.champion() ? DeepPass.XP_CHAMPION : DeepPass.XP_KILL);
    Companions.Egg egg =
        Companions.maybeDrop(
            data,
            a.urboss
                ? Companions.BOSS * 3
                : a.boss ? Companions.BOSS : a.champion() ? Companions.CHAMPION : Companions.MONSTER,
            random,
            System.currentTimeMillis());
    boolean star = a.urboss && StarStones.maybeDrop(data, random);
    if (a.urboss) data.urbossKills++;
    if (!plugin.commit(p, data)) return;
    if (egg != null) plugin.pets().found(p, egg);
    if (star) plugin.starFound(p);
    if (!a.boss) plugin.guilds().progress(p, Guilds.Task.MONSTER, 1);
    if (a.champion()) plugin.guilds().progress(p, Guilds.Task.CHAMPIONS, 1);
    plugin.pets().victory(p);
    if (healingDrop > 0) plugin.healing().announce(p, healingDrop);
    if (shinyLoot != null) {
      p.showTitle(
          net.kyori.adventure.title.Title.title(
              Component.text("✧ GLANZFANG! ✧", NamedTextColor.GOLD),
              Component.text(
                  shinyLoot.firstOfKind() ? "Neu im Glanzbuch · " + Shinies.dex(data) + "/" + Shinies.dexSize() : "+" + shinyLoot.shards() + " Glanzsplitter",
                  NamedTextColor.YELLOW)));
      p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, .8f, 1.5f);
      plugin.tell(p, "✧ GLANZFANG · " + String.join(" · ", shinyLoot.lines()) + " · /df glanz");
      if (shinyLoot.item() != null && data.gear.contains(shinyLoot.item())) showLoot(p, at, shinyLoot.item());
      for (Player other : Bukkit.getOnlinePlayers())
        if (other != p && plugin.playing(other))
          plugin.tell(other, "✧ " + p.getName() + " hat einen " + Shinies.name(a.kind).substring(2) + " gefangen!");
    }
    for (int code : runes)
      plugin.tell(p, "RUNE · " + Runes.name(code) + " (" + Runes.effect(code) + ") · /df runen");
    if (!runes.isEmpty()) p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_RESONATE, .8f, 1.3f);
    if (a.champion())
      plugin.notice(
          p,
          "Champion besiegt · +" + cash + " $ · " + runes.size() + (runes.size() == 1 ? " Rune" : " Runen"),
          net.kyori.adventure.text.format.NamedTextColor.LIGHT_PURPLE);
    else if (!a.boss)
      plugin.notice(
          p,
          "Besiegt · +" + cash + " $ · +" + (1 + a.kind) + " Monsterteile",
          net.kyori.adventure.text.format.NamedTextColor.GREEN);
    if (a.boss)
      p.showTitle(
          net.kyori.adventure.title.Title.title(
              net.kyori.adventure.text.Component.text(
                  "BOSS BESIEGT", net.kyori.adventure.text.format.NamedTextColor.GOLD),
              net.kyori.adventure.text.Component.text(
                  loot.isEmpty()
                      ? "Bossfragmente gutgeschrieben"
                      : loot.size() + (loot.size() == 1 ? " neuer Gegenstand" : " neue Gegenstände") + " · /df loot",
                  net.kyori.adventure.text.format.NamedTextColor.YELLOW)));
    if (a.boss)
      plugin.tell(
          p,
          "Boss besiegt! +"
              + (500 + a.zone * 350) * (a.mode + 1)
              + " $, +"
              + (2 + a.mode)
              + " Bossfragmente. Beute: /df loot");
    for (Gear.Item i : loot) {
      plugin.tell(
          p, "BEUTE · " + i.rarity.title + " · " + i.name + " — dauerhaft im Beutel gespeichert.");
      showLoot(p, at, i);
    }
    p.playSound(at, Sound.ENTITY_PLAYER_LEVELUP, .8f, a.boss ? .7f : 1.3f);
  }

  /** Drone turret: hits the nearest monster fighting this player; returns where it hit. */
  public Location droneShot(Player p, double damage) {
    Actor best = null;
    double bestDistance = 144;
    for (Actor a : actors.values()) {
      if (a.ended || !a.fighters.contains(p.getUniqueId()) || !a.entity.isValid()) continue;
      double d = a.entity.getLocation().distanceSquared(p.getLocation());
      if (d < bestDistance) {
        bestDistance = d;
        best = a;
      }
    }
    if (best == null) return null;
    Location at = best.entity.getLocation().add(0, 1, 0);
    hit(best, p, damage, false, false);
    return at;
  }

  public void showDamage(
      Player player, Location at, double damage, boolean crit, boolean backstab, boolean guarded) {
    if (damagePopups.stream().filter(v -> v.owner.equals(player.getUniqueId())).count() >= 24) {
      DamagePopup old =
          damagePopups.stream()
              .filter(v -> v.owner.equals(player.getUniqueId()))
              .findFirst()
              .orElseThrow();
      old.display.remove();
      damagePopups.remove(old);
    }
    TextDisplay display =
        createDamageDisplay(
            at.clone().add(random.nextDouble() * .5 - .25, 0, random.nextDouble() * .5 - .25),
            damage,
            crit,
            backstab,
            guarded);
    player.showEntity(plugin, display);
    damagePopups.add(new DamagePopup(player.getUniqueId(), display, tick));
  }

  private TextDisplay createDamageDisplay(
      Location at, double damage, boolean crit, boolean backstab, boolean guarded) {
    NamedTextColor color =
        crit
            ? NamedTextColor.GOLD
            : backstab
                ? NamedTextColor.LIGHT_PURPLE
                : guarded ? NamedTextColor.GRAY : NamedTextColor.WHITE;
    return at.getWorld()
        .spawn(
            at,
            TextDisplay.class,
            e -> {
              e.text(
                  Component.text(HitFeedback.text(damage, crit, backstab, guarded), color)
                      .decorate(net.kyori.adventure.text.format.TextDecoration.BOLD));
              e.setPersistent(false);
              e.setInvulnerable(true);
              e.setBillboard(Display.Billboard.CENTER);
              e.setShadowed(true);
              e.setSeeThrough(false);
              e.setBackgroundColor(Color.fromARGB(70, 12, 16, 22));
              e.setBrightness(new Display.Brightness(15, 15));
              e.setViewRange(.6f);
              e.setTeleportDuration(2);
              e.setVisibleByDefault(false);
            });
  }

  private void showLoot(Player p, Location at, Gear.Item item) {
    if (!plugin.packApplied(p)) return;
    ItemDisplay display =
        at.getWorld()
            .spawn(
                at.clone().add(0, 1, 0),
                ItemDisplay.class,
                e -> {
                  e.setItemStack(plugin.items().model(Material.PAPER, item.model(), item.name));
                  e.setPersistent(false);
                  e.setBillboard(Display.Billboard.CENTER);
                  e.setBrightness(new Display.Brightness(15, 15));
                  if (plugin.mines().shared()) e.setVisibleByDefault(false);
                });
    if (plugin.mines().shared()) p.showEntity(plugin, display);
    lootDisplays.add(display);
    Bukkit.getScheduler()
        .runTaskLater(
            plugin,
            () -> {
              display.remove();
              lootDisplays.remove(display);
            },
            100);
  }

  @EventHandler
  public void interact(PlayerInteractEvent e) {
    Player p = e.getPlayer();
    if (plugin.forestry() != null
        && plugin.playing(p)
        && plugin.forestry().station(plugin.profile(p), e.getClickedBlock())) return;
    if (plugin.dungeons() != null && plugin.dungeons().shrineBlock(p, e.getClickedBlock())) return;
    if (plugin.dungeons() != null && plugin.dungeons().down(p)) return;
    if (e.getHand() != EquipmentSlot.HAND
        || !e.getAction().isRightClick()
        || !plugin.playing(p)
        || !plugin.items().kind(p.getInventory().getItemInMainHand()).equals("sword")) return;
    if (e.getClickedBlock() != null
        && plugin.mines().station(plugin.profile(p), e.getClickedBlock().getLocation()) != null)
      return;
    e.setCancelled(true);
    UUID id = p.getUniqueId();
    double energy = stamina.getOrDefault(id, 100.);
    if (p.isSneaking()) {
      if (dodge.getOrDefault(id, 0L) > tick || energy < 25) return;
      Vector v = p.getLocation().getDirection().setY(0);
      if (v.lengthSquared() < .01) return;
      p.setVelocity(v.normalize().multiply(.85).setY(.2));
      stamina.put(id, energy - 25);
      dodge.put(id, tick + 35);
      invincible.put(id, tick + 7);
      Profile learner = plugin.profile(p);
      learner.dodges++;
      plugin.commit(p, learner);
      return;
    }
    if (ability.getOrDefault(id, 0L) > tick || energy < 35) return;
    Gear.Item weapon = Gear.equipped(plugin.profile(p), Gear.Slot.WEAPON);
    WeaponAbilities.Ability skill = WeaponAbilities.of(weapon);
    stamina.put(id, energy - 35);
    ability.put(id, tick + WeaponAbilities.cooldown(weapon));
    String style = weapon == null ? "sword" : weapon.style;
    if (style.equals("sword") || Gear.hasEffect(plugin.profile(p), 5))
      parry.put(
          id,
          tick
              + (skill == WeaponAbilities.Ability.KONTER ? 40 : 22)
              + (Gear.hasEffect(plugin.profile(p), 5) ? 10 : 0));
    Vector facing = p.getLocation().getDirection().setY(0);
    if (facing.lengthSquared() < .01) facing = new Vector(0, 0, 1);
    else facing.normalize();
    if (Gear.hasEffect(plugin.profile(p), 6)) dash(p, facing, 8);
    useAbility(p, weapon, skill, facing, 1);
    if (WeaponAbilities.echo(weapon)) {
      Vector echoFacing = facing.clone();
      Bukkit.getScheduler()
          .runTaskLater(
              plugin,
              () -> {
                if (p.isOnline() && !p.isDead()) useAbility(p, weapon, skill, echoFacing, .5);
              },
              10);
    }
  }

  /** Short dash forward along free floor; returns how far the player moved. */
  private double dash(Player p, Vector facing, int steps) {
    Location start = p.getLocation(), destination = start;
    for (int step = 1; step <= steps; step++) {
      Location next = start.clone().add(facing.clone().multiply(step * .4));
      if (!next.getBlock().isPassable()
          || !next.clone().add(0, 1, 0).getBlock().isPassable()
          || next.clone().add(0, -1, 0).getBlock().isPassable()) break;
      destination = next;
    }
    p.teleport(destination);
    invincible.put(p.getUniqueId(), tick + 7);
    return destination.distance(start);
  }

  /** Enemies of this player right now: own mine monsters and dungeon enemies. */
  private List<AbilityTarget> abilityTargets(Player p) {
    List<AbilityTarget> out = new ArrayList<>();
    for (Actor a : new ArrayList<>(actors.values()))
      if (!a.ended && a.fighters.contains(p.getUniqueId()))
        out.add(new AbilityTarget(a.entity, damage -> hit(a, p, damage, true)));
    out.addAll(plugin.dungeons().abilityTargets(p));
    return out;
  }

  private final Map<UUID, Long> poisonUntil = new HashMap<>();

  /** Giftklinge: +35 % on every hit while active. */
  public double abilityBuff(Player p) {
    return poisonUntil.getOrDefault(p.getUniqueId(), 0L) > tick ? 1.35 : 1;
  }

  private void useAbility(
      Player p, Gear.Item weapon, WeaponAbilities.Ability skill, Vector facing, double scale) {
    Profile data = plugin.profile(p);
    double base = Gear.stats(data).damage() * skill.multiplier * WeaponAbilities.power(weapon) * scale;
    if (weapon != null && weapon.style.equals("spear") && Gear.hasEffect(data, 3)) base *= 1.4;
    if (weapon != null && weapon.style.equals("hammer") && Gear.hasEffect(data, 4)) base *= 1.35;
    Location eye = p.getLocation().add(0, 1, 0);
    World w = p.getWorld();
    List<AbilityTarget> targets = abilityTargets(p);
    List<AbilityTarget> struck = new ArrayList<>();
    java.util.function.BiPredicate<AbilityTarget, Double> near =
        (t, r) -> t.entity().getLocation().distanceSquared(p.getLocation()) <= r * r;
    java.util.function.BiPredicate<AbilityTarget, double[]> cone =
        (t, spec) -> {
          Vector d = t.entity().getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
          double len = d.length();
          return len <= spec[0] && (len < .1 || d.normalize().dot(facing) >= spec[1]);
        };
    switch (skill) {
      case WIRBEL -> {
        for (AbilityTarget t : targets) if (near.test(t, 4.0)) struck.add(t);
        for (int i = 0; i < 12; i++) {
          double angle = i * Math.PI / 6;
          w.spawnParticle(Particle.SWEEP_ATTACK, eye.clone().add(Math.cos(angle) * 2.5, 0, Math.sin(angle) * 2.5), 1);
        }
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1, .8f);
      }
      case STURMSCHNITT -> {
        Location from = p.getLocation();
        double moved = dash(p, facing, 12);
        for (AbilityTarget t : targets) {
          Vector d = t.entity().getLocation().toVector().subtract(from.toVector()).setY(0);
          double along = d.dot(facing);
          if (along >= -1 && along <= moved + 1.5 && d.clone().subtract(facing.clone().multiply(along)).length() < 2)
            struck.add(t);
        }
        w.spawnParticle(Particle.SWEEP_ATTACK, from.clone().add(0, 1, 0).add(facing.clone().multiply(moved / 2)), 6, moved / 3, .2, moved / 3, 0);
        p.playSound(p.getLocation(), Sound.ENTITY_BREEZE_WIND_BURST, .8f, 1.3f);
      }
      case KONTER -> {
        for (AbilityTarget t : targets) if (cone.test(t, new double[] {3.5, .5})) struck.add(t);
        w.spawnParticle(Particle.CRIT, eye.clone().add(facing.clone().multiply(1.5)), 20, .5, .3, .5, .2);
        p.playSound(p.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1, 1.4f);
        plugin.tell(p, "Konterhaltung: 2 Sekunden Parade bereit.");
      }
      case ERDBEBEN -> {
        for (AbilityTarget t : targets)
          if (near.test(t, 5.0)) {
            struck.add(t);
            t.entity().addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.SLOWNESS, 60, 2, false, false));
          }
        w.spawnParticle(Particle.BLOCK, p.getLocation(), 60, 2.5, .1, 2.5, 0, Material.STONE.createBlockData());
        w.spawnParticle(Particle.EXPLOSION, p.getLocation(), 2, 1, 0, 1, 0);
        p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, .7f, .6f);
      }
      case SCHMETTERSCHLAG -> {
        for (AbilityTarget t : targets) if (cone.test(t, new double[] {4, .7})) struck.add(t);
        w.spawnParticle(Particle.EXPLOSION, eye.clone().add(facing.clone().multiply(2)), 1);
        p.playSound(p.getLocation(), Sound.ENTITY_IRON_GOLEM_ATTACK, 1, .6f);
      }
      case SCHATTENSCHRITT -> {
        AbilityTarget victim =
            targets.stream()
                .filter(t -> near.test(t, 10.0))
                .min(Comparator.comparingDouble(t -> t.entity().getLocation().distanceSquared(p.getLocation())))
                .orElse(null);
        if (victim != null) {
          Location behind = victim.entity().getLocation().clone();
          Vector look = behind.getDirection().setY(0);
          if (look.lengthSquared() < .01) look = facing.clone();
          behind.subtract(look.normalize().multiply(1.3));
          behind.setDirection(victim.entity().getLocation().toVector().subtract(behind.toVector()));
          if (behind.getBlock().isPassable() && behind.clone().add(0, 1, 0).getBlock().isPassable()) {
            w.spawnParticle(Particle.LARGE_SMOKE, p.getLocation().add(0, 1, 0), 15, .3, .5, .3, 0);
            p.teleport(behind);
            invincible.put(p.getUniqueId(), tick + 7);
          }
          struck.add(victim);
          p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, .7f, 1.5f);
        }
      }
      case GIFTKLINGE -> {
        poisonUntil.put(p.getUniqueId(), tick + 120);
        w.spawnParticle(Particle.ITEM_SLIME, eye, 20, .4, .4, .4, 0);
        p.playSound(p.getLocation(), Sound.ENTITY_SPIDER_AMBIENT, .7f, 1.4f);
        plugin.tell(p, "Giftklinge: 6 Sekunden +35 % Schaden.");
      }
      case DURCHBOHREN -> {
        for (AbilityTarget t : targets) if (cone.test(t, new double[] {8, .8})) struck.add(t);
        for (int i = 1; i <= 8; i++) w.spawnParticle(Particle.CRIT, eye.clone().add(facing.clone().multiply(i)), 2, 0, 0, 0, 0);
        p.playSound(p.getLocation(), Sound.ITEM_TRIDENT_THROW, 1, 1.1f);
      }
      case SPEERWURF -> {
        for (AbilityTarget t : targets)
          if (cone.test(t, new double[] {13, .93})) {
            struck.add(t);
            Vector pull = p.getLocation().toVector().subtract(t.entity().getLocation().toVector()).setY(0);
            if (pull.lengthSquared() > 4) t.entity().setVelocity(pull.normalize().multiply(.9).setY(.25));
          }
        for (int i = 1; i <= 13; i++) w.spawnParticle(Particle.ELECTRIC_SPARK, eye.clone().add(facing.clone().multiply(i)), 2, 0, 0, 0, 0);
        p.playSound(p.getLocation(), Sound.ITEM_TRIDENT_RIPTIDE_1, 1, 1.2f);
      }
      case SALVE -> {
        for (AbilityTarget t : targets) if (cone.test(t, new double[] {12, .85})) struck.add(t);
        for (double side : new double[] {-.25, 0, .25}) {
          Vector dir = facing.clone().add(new Vector(-facing.getZ(), 0, facing.getX()).multiply(side)).normalize();
          for (int i = 1; i <= 12; i += 2) w.spawnParticle(Particle.CRIT, eye.clone().add(dir.clone().multiply(i)), 1, 0, 0, 0, 0);
        }
        p.playSound(p.getLocation(), Sound.ITEM_CROSSBOW_SHOOT, 1, 1.2f);
      }
      case EXPLOSIVBOLZEN -> {
        AbilityTarget first =
            targets.stream()
                .filter(t -> cone.test(t, new double[] {14, .9}))
                .min(Comparator.comparingDouble(t -> t.entity().getLocation().distanceSquared(p.getLocation())))
                .orElse(null);
        if (first != null) {
          Location blast = first.entity().getLocation();
          for (AbilityTarget t : targets) if (t.entity().getLocation().distanceSquared(blast) <= 9) struck.add(t);
          w.spawnParticle(Particle.EXPLOSION_EMITTER, blast, 1);
          w.playSound(blast, Sound.ENTITY_GENERIC_EXPLODE, 1, 1.1f);
        }
        p.playSound(p.getLocation(), Sound.ITEM_CROSSBOW_SHOOT, 1, .8f);
      }
    }
    for (AbilityTarget t : struck) if (t.entity().isValid() && p.hasLineOfSight(t.entity())) t.hit().accept(base);
    double heal = Math.min(.12, WeaponAbilities.healPerHit(weapon) * struck.size());
    if (heal > 0 && !p.isDead()) {
      double max = p.getAttribute(Attribute.MAX_HEALTH).getValue();
      setHealth(p, Math.min(max, p.getHealth() + max * heal));
    }
  }

  @EventHandler
  public void target(EntityTargetLivingEntityEvent e) {
    Actor a = actors.get(e.getEntity().getUniqueId());
    if (a != null && e.getTarget() != null && !e.getTarget().getUniqueId().equals(a.owner))
      e.setCancelled(true);
  }

  @EventHandler
  public void died(PlayerDeathEvent e) {
    clear(e.getEntity(), false);
  }

  private void end(Actor a) {
    if (a.ended) return;
    a.ended = true;
    actors.remove(a.entity.getUniqueId());
    if (a.boss) {
      for (UUID id : a.fighters) {
        bosses.remove(id, a);
        Player p = Bukkit.getPlayer(id);
        if (p != null) p.hideBossBar(a.bar);
      }
      for (Actor add : new ArrayList<>(actors.values()))
        if (add.summoned && a.fighters.contains(add.owner)) end(add);
    }
    if (a.rig != null) a.rig.close();
    if (a.health != null) a.health.close();
    a.entity.remove();
  }

  public void clear(Player p, boolean restore) {
    breakCombo(p.getUniqueId());
    damagePopups.removeIf(
        v -> {
          if (v.owner.equals(p.getUniqueId())) {
            v.display.remove();
            return true;
          }
          return false;
        });
    for (Actor a : new ArrayList<>(actors.values())) if (a.owner.equals(p.getUniqueId())) end(a);
    if (restore) {
      double[] original = originals.remove(p.getUniqueId());
      if (original != null) {
        p.getAttribute(Attribute.MAX_HEALTH).setBaseValue(original[0]);
        if (p.getHealth() > p.getAttribute(Attribute.MAX_HEALTH).getValue())
          p.setHealth(p.getAttribute(Attribute.MAX_HEALTH).getValue());
        p.getAttribute(Attribute.ATTACK_SPEED).setBaseValue(original[1]);
        p.getAttribute(Attribute.ENTITY_INTERACTION_RANGE).setBaseValue(original[2]);
        p.getPersistentDataContainer().remove(originalKey);
      }
      for (Map<?, ?> m : List.of(stamina, ability, dodge, invincible, parry, lastHit, lastHurt))
        m.remove(p.getUniqueId());
    }
  }

  public int activeCount() {
    return actors.size();
  }

  /** Console-only smoke test: uses temporary entities, never changes player profiles or blocks. */
  public String verifyModels() {
    World world = plugin.mines().world();
    Location origin = world.getSpawnLocation().clone().add(0, 40, 0);
    int checked = 0;
    Set<UUID> baseline = new HashSet<>();
    world.getEntities().forEach(e -> baseline.add(e.getUniqueId()));
    try {
      for (int zone = 0; zone < Zone.COUNT; zone++)
        for (int kind = -1; kind < 3; kind++)
          try (MonsterRig rig =
              new MonsterRig(plugin, origin, zone, kind == -1, Math.max(0, kind))) {
            rig.hurt(0);
            for (int pose = 0; pose < 4; pose++)
              rig.animate(origin, pose * 10, pose == 1, pose == 2, pose == 3);
            long count =
                world.getEntities().stream()
                    .filter(e -> !baseline.contains(e.getUniqueId()) && e instanceof ItemDisplay)
                    .count();
            if (count != 7)
              throw new IllegalStateException("Expected seven rig bones, got " + count);
            checked++;
          }
      for (int variant = 0; variant < 4; variant++) {
        TextDisplay display =
            createDamageDisplay(origin, 12.5, variant == 1, variant == 2, variant == 3);
        try {
          if (display.isVisibleByDefault() || display.text().equals(Component.empty()))
            throw new IllegalStateException("Invalid damage display");
          display.teleport(origin.clone().add(0, .4, 0));
          display.setTextOpacity((byte) 80);
        } finally {
          display.remove();
        }
      }
      for (BossRules.Attack attack : BossRules.Attack.values()) {
        Actor a = new Actor();
        a.origin = origin;
        a.direction = new Vector(0, 0, 1);
        a.attack = attack;
        warning(a);
      }
      TextDisplay removed;
      try (MonsterHealthIndicator health =
          new MonsterHealthIndicator(plugin, origin, List.of(), true)) {
        removed = health.entity();
        for (double hp : new double[] {100, 45, 10, 70, 0}) {
          health.update(origin, 4, "Prüfwächter", hp, 100, true);
          if (!removed.text().equals(MonsterHealth.text("Prüfwächter", hp, 100, true))
              || removed.isVisibleByDefault()
              || removed.isSeeThrough()) throw new IllegalStateException("Invalid health plate");
        }
        health.update(origin.clone().add(2, 0, 1), 4, "Prüfwächter", 50, 100, true);
        if (removed.getLocation().distanceSquared(origin.clone().add(2, 4, 1)) > .001)
          throw new IllegalStateException("Health plate did not follow");
      }
      if (removed.isValid()) throw new IllegalStateException("Health plate leaked");
      for (Entity e : world.getEntities())
        if (!baseline.contains(e.getUniqueId()))
          throw new IllegalStateException("Diagnostic entity not removed");
      return "DEEPFORGE COMBAT OK: "
          + checked
          + " rigs, 196 bones, 112 poses including hit flashes, 4 damage labels, health plates:"
          + " damage/heal/move/cleanup, 6 telegraphs; zero leaked entities; active="
          + activeCount();
    } finally {
      for (Entity e : world.getEntities()) if (!baseline.contains(e.getUniqueId())) e.remove();
    }
  }

  @Override
  public void close() {
    damagePopups.forEach(v -> v.display.remove());
    damagePopups.clear();
    if (railProbe != null) railProbe.close();
    for (Actor a : new ArrayList<>(actors.values())) end(a);
    for (UUID id : new ArrayList<>(originals.keySet())) {
      Player p = Bukkit.getPlayer(id);
      if (p != null) clear(p, true);
    }
    lootDisplays.forEach(Entity::remove);
    lootDisplays.clear();
  }
}
