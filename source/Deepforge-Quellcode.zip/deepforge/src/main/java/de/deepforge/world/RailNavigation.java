package de.deepforge.world;

import java.lang.reflect.Method;
import org.bukkit.entity.Mob;

/** Version-gated adapter for Paper 1.21.8; normal collision/pathfinding remains in Minecraft. */
final class RailNavigation {
  private static final Class<?> PATH_TYPE;
  private static final Method SET, GET;
  private static final Object RAIL, UNPASSABLE_RAIL;

  static {
    try {
      PATH_TYPE = Class.forName("net.minecraft.world.level.pathfinder.PathType");
      Class<?> mob = Class.forName("net.minecraft.world.entity.Mob");
      SET = mob.getMethod("setPathfindingMalus", PATH_TYPE, float.class);
      GET = mob.getMethod("getPathfindingMalus", PATH_TYPE);
      RAIL = PATH_TYPE.getField("RAIL").get(null);
      UNPASSABLE_RAIL = PATH_TYPE.getField("UNPASSABLE_RAIL").get(null);
    } catch (ReflectiveOperationException e) {
      throw new IllegalStateException("Paper 1.21.8 rail navigation adapter unavailable", e);
    }
  }

  static void allowRails(Mob mob) {
    try {
      Object handle = mob.getClass().getMethod("getHandle").invoke(mob);
      SET.invoke(handle, RAIL, 0f);
      SET.invoke(handle, UNPASSABLE_RAIL, 0f);
      if (((Number) GET.invoke(handle, UNPASSABLE_RAIL)).floatValue() != 0)
        throw new IllegalStateException("Rail cost did not apply");
    } catch (ReflectiveOperationException e) {
      throw new IllegalStateException("Cannot enable monster rail crossing", e);
    }
  }

  private RailNavigation() {}
}
