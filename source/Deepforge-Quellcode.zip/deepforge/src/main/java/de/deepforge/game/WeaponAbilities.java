package de.deepforge.game;

import java.util.*;

/**
 * Right-click abilities: every weapon type has several, each weapon keeps one for good (chosen by
 * its id). Rarity and quality set the power; epic and better heal, legendary recharges faster,
 * mythic strikes a second time.
 */
public final class WeaponAbilities {
  public enum Ability {
    WIRBEL("sword", "Klingenwirbel", "trifft alle Gegner im Umkreis von 4 Blöcken", 1.5, 120),
    STURMSCHNITT("sword", "Sturmschnitt", "springt 5 Blöcke vor und schneidet alles auf dem Weg", 1.8, 140),
    KONTER("sword", "Konterhaltung", "lange Parade und Hieb nach vorn", 1.3, 110),
    ERDBEBEN("hammer", "Erdbeben", "Schockwelle (5 Blöcke), Gegner werden langsam", 1.7, 160),
    SCHMETTERSCHLAG("hammer", "Schmetterschlag", "gewaltiger Hieb nach vorn", 3.0, 150),
    SCHATTENSCHRITT("dagger", "Schattenschritt", "springt hinter den nächsten Gegner, sicherer Rückenstich", 2.5, 130),
    GIFTKLINGE("dagger", "Giftklinge", "6 Sekunden lang +35 % Schaden", 0, 200),
    DURCHBOHREN("spear", "Durchbohren", "Stoß in einer Linie (8 Blöcke)", 1.8, 120),
    SPEERWURF("spear", "Speerwurf", "weiter Wurf (13 Blöcke), zieht Gegner heran", 1.6, 150),
    SALVE("crossbow", "Salve", "Bolzenfächer nach vorn (12 Blöcke)", 1.3, 120),
    EXPLOSIVBOLZEN("crossbow", "Explosivbolzen", "Explosion am ersten Ziel (Radius 3)", 2.0, 160);
    public final String style, title, effect;
    public final double multiplier;
    public final int cooldown;

    Ability(String style, String title, String effect, double multiplier, int cooldown) {
      this.style = style;
      this.title = title;
      this.effect = effect;
      this.multiplier = multiplier;
      this.cooldown = cooldown;
    }
  }

  private WeaponAbilities() {}

  public static List<Ability> of(String style) {
    List<Ability> out = new ArrayList<>();
    for (Ability a : Ability.values()) if (a.style.equals(style)) out.add(a);
    return out.isEmpty() ? List.of(Ability.WIRBEL) : out;
  }

  /** The weapon's own ability: fixed by its id, so it never changes. No weapon: Klingenwirbel. */
  public static Ability of(Gear.Item weapon) {
    if (weapon == null) return Ability.WIRBEL;
    List<Ability> options = of(weapon.style);
    return options.get(Math.floorMod(weapon.id.hashCode(), options.size()));
  }

  /** 0.8 (ungewöhnlich) to 1.6 (mythisch), times quality 80–100 %. */
  public static double power(Gear.Item weapon) {
    if (weapon == null) return .7;
    return (.6 + .2 * (weapon.rarity.ordinal() + 1)) * weapon.quality / 100.0;
  }

  public static int cooldown(Gear.Item weapon) {
    Ability a = of(weapon);
    boolean fast = weapon != null && weapon.rarity.ordinal() >= Gear.Rarity.LEGENDARY.ordinal();
    return (int) Math.round(a.cooldown * (fast ? .75 : 1));
  }

  /** Epic and better heal 4 % life per enemy hit (at most 12 %). */
  public static double healPerHit(Gear.Item weapon) {
    return weapon != null && weapon.rarity.ordinal() >= Gear.Rarity.EPIC.ordinal() ? .04 : 0;
  }

  /** Mythic weapons strike a second time half a second later at half strength. */
  public static boolean echo(Gear.Item weapon) {
    return weapon != null && weapon.rarity == Gear.Rarity.MYTHIC;
  }

  public static String lore(Gear.Item weapon) {
    Ability a = of(weapon);
    StringBuilder b =
        new StringBuilder("Rechtsklick: ")
            .append(a.title)
            .append(" – ")
            .append(a.effect)
            .append(String.format(Locale.GERMAN, " · Stärke %.0f %%", power(weapon) * 100))
            .append(String.format(Locale.GERMAN, " · %.1f s", cooldown(weapon) / 20.0));
    if (healPerHit(weapon) > 0) b.append(" · heilt pro Treffer");
    if (echo(weapon)) b.append(" · Echo-Schlag");
    return b.toString();
  }
}
