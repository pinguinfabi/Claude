package de.deepforge.game;

import java.text.NumberFormat;
import java.util.*;

/**
 * Vault chests: after a won dungeon run each player may buy up to three extra loot chests for
 * that run. Prices double with every chest and start well above what the run paid out, so money
 * buys a little more luck, never a shortcut.
 */
public final class LootChests {
  private LootChests() {}

  public static final int MAX = 3;

  /** Price of the next chest: 2×, 4×, 8× the run's coin reward. */
  public static long price(Profile p) {
    return DungeonRules.coins(p.chestZone, p.chestMode, Math.max(1, p.chestLevel))
        * (2L << Math.min(MAX, p.chestBought));
  }

  public static boolean available(Profile p) {
    return p.chestRun != null && !p.chestRun.isBlank() && p.chestBought < MAX;
  }

  /** Called inside the run reward: offers chests for this run, replacing older offers. */
  static void offer(Profile p, UUID run, int zone, int mode, int level) {
    p.chestRun = run.toString();
    p.chestZone = zone;
    p.chestMode = mode;
    p.chestLevel = level;
    p.chestBought = 0;
  }

  public static String buy(Profile p) {
    if (p.chestRun == null || p.chestRun.isBlank())
      return "Gewölbekisten gibt es nur nach einem gewonnenen Dungeon.";
    if (p.chestBought >= MAX)
      return "Für diesen Lauf hast du schon alle " + MAX + " Kisten geöffnet.";
    long price = price(p);
    if (p.money < price)
      return "Die Kiste kostet " + n(price) + " $ – dir fehlen " + n(price - p.money) + " $.";
    p.money -= price;
    // Seeded per run, player and chest: reconnecting cannot re-roll a chest.
    Random r =
        new Random(
            UUID.fromString(p.chestRun).getMostSignificantBits()
                ^ p.id.hashCode()
                ^ (p.chestBought + 1) * 0x9E3779B97F4A7C15L);
    p.chestBought++;
    int chance = r.nextInt(1000);
    int level = Math.max(1, p.chestLevel);
    Gear.Rarity rarity =
        chance < DungeonRules.mythicThreshold(p.chestMode, level)
            ? Gear.Rarity.MYTHIC
            : chance < DungeonRules.legendaryThreshold(p.chestMode, level)
                ? Gear.Rarity.LEGENDARY
                : chance < DungeonRules.epicThreshold(p.chestMode, level)
                    ? Gear.Rarity.EPIC
                    : Gear.Rarity.RARE;
    Gear.Item loot = Gear.roll(p.chestZone, rarity, r);
    loot.dungeonRank = level;
    double growth = 1 + .075 * (level - 1);
    loot.damage *= growth;
    loot.health *= growth;
    loot.defense *= growth;
    loot.name = "Gewölbekiste L" + level + ": " + loot.name;
    long dust = 5L + p.chestZone * 3L;
    p.dust += dust;
    p.discovered.add(loot.slot.name() + "/" + loot.rarity.name());
    if (p.gear.size() < 120) p.gear.add(loot);
    else p.dust += 40L * (rarity.ordinal() + 1);
    return "Gewölbekiste geöffnet: "
        + RewardDiff.item(loot)
        + " · +"
        + dust
        + " Schmiedestaub."
        + (p.chestBought < MAX
            ? " Nächste Kiste: " + n(price(p)) + " $ (" + (MAX - p.chestBought) + " übrig)."
            : " Alle Kisten dieses Laufs geöffnet.");
  }

  private static String n(long v) {
    return NumberFormat.getIntegerInstance(Locale.GERMANY).format(v);
  }
}
