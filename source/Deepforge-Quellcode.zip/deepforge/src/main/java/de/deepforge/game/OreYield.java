package de.deepforge.game;

public final class OreYield {
  private OreYield() {}

  public static double multiplier(int level) {
    return 1 + Math.clamp(level, 0, 10) * .1;
  }

  public static double doubleChance(Profile p, double gearYield) {
    return (p.module == 0 ? .35 : 0) + gearYield;
  }

  public static int roll(Profile p, double doubleChance, double doubleRoll, double tripleRoll) {
    return (doubleRoll < doubleChance ? 2 : 1)
        * (tripleRoll < Math.clamp(p.oreLuck, 0, 10) * .1 ? 2 : 1);
  }
}
