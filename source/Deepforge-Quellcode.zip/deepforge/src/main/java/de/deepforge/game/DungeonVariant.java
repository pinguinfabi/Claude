package de.deepforge.game;

import java.util.*;

/**
 * The three dungeons. All share the route (three halls, two puzzles, final boss) but each has its
 * own look, its own hazard during the fights, its own bosses and a loot focus.
 */
public enum DungeonVariant {
  GEWOELBE(
      "Runengewölbe",
      "Der Klassiker: Runenrätsel, Siegel und Endboss.",
      "Keine Zusatzgefahr",
      "Beute: alle Ausrüstungsteile",
      new String[] {"Halle der Runen", "Siegelgalerie", "Herz des Gewölbes"},
      new String[] {
        "Eisenkoloss", "Kristallkönigin", "Sporenmutter", "Tiefenwächter", "Glutfürst",
        "Reliktwächter", "Leerenherz"
      },
      EnumSet.noneOf(Gear.Slot.class)),
  GLUTSCHMIEDE(
      "Glutschmiede",
      "Eine verlassene Zwergenesse voller Schlacke.",
      "Glutadern: Der Boden bricht an markierten Stellen auf – raus aus dem Glühen!",
      "Beute: bevorzugt Waffen und Nebenhand · +15 % Geld",
      new String[] {"Schlackenhalle", "Ambossgalerie", "Herz der Esse"},
      new String[] {
        "Schlackenkoloss", "Glasbläserin", "Aschenmutter", "Magmawächter", "Essenfürst",
        "Ambossherz", "Sonnenschlund"
      },
      EnumSet.of(Gear.Slot.WEAPON, Gear.Slot.OFFHAND)),
  FROSTKRYPTA(
      "Frostkrypta",
      "Eine vereiste Gruft, in der die Kälte an dir nagt.",
      "Eiseskälte: Frost sammelt sich an – wärm dich an den Glutbecken auf!",
      "Beute: bevorzugt Rüstung · +1 Lebenssplitter",
      new String[] {"Eisvorhalle", "Gruft der Stille", "Thron des Winters"},
      new String[] {
        "Reifkoloss", "Eiskönigin", "Frostmutter", "Gletscherwächter", "Kältefürst",
        "Reliktfrost", "Winterherz"
      },
      EnumSet.of(Gear.Slot.HELMET, Gear.Slot.CHEST, Gear.Slot.LEGS, Gear.Slot.BOOTS));

  public final String title, flavor, hazard, loot;
  private final String[] rooms, bosses;
  private final Set<Gear.Slot> focus;

  DungeonVariant(
      String title,
      String flavor,
      String hazard,
      String loot,
      String[] rooms,
      String[] bosses,
      Set<Gear.Slot> focus) {
    this.title = title;
    this.flavor = flavor;
    this.hazard = hazard;
    this.loot = loot;
    this.rooms = rooms;
    this.bosses = bosses;
    this.focus = focus;
  }

  public static DungeonVariant of(int index) {
    DungeonVariant[] all = values();
    return all[Math.floorMod(index, all.length)];
  }

  public String room(int room) {
    return rooms[Math.clamp(room, 0, 2)];
  }

  public String boss(int zone) {
    return bosses[Math.floorMod(zone, 7)];
  }

  public boolean focus(Gear.Slot slot) {
    return focus.contains(slot);
  }

  // ---- unlocks ----

  /** Glutschmiede after any dungeon win, Frostkrypta after a Glutschmiede win. */
  public boolean unlocked(Profile p) {
    return switch (this) {
      case GEWOELBE -> true;
      case GLUTSCHMIEDE -> Arrays.stream(p.dungeonWins).sum() > 0;
      case FROSTKRYPTA -> wins(p, GLUTSCHMIEDE) > 0;
    };
  }

  public String requirement() {
    return switch (this) {
      case GEWOELBE -> "";
      case GLUTSCHMIEDE -> "Freischalten: einen beliebigen Dungeon gewinnen";
      case FROSTKRYPTA -> "Freischalten: die Glutschmiede einmal gewinnen";
    };
  }

  public static int wins(Profile p, DungeonVariant v) {
    return p.variantWins == null || p.variantWins.length <= v.ordinal()
        ? 0
        : p.variantWins[v.ordinal()];
  }

  // ---- rewards ----

  public long coins(long base) {
    return this == GLUTSCHMIEDE ? Math.round(base * 1.15) : base;
  }

  /** Extra reward on top of the shared dungeon reward. */
  void bonus(Profile p) {
    if (p.variantWins == null || p.variantWins.length < values().length)
      p.variantWins = Arrays.copyOf(p.variantWins == null ? new int[0] : p.variantWins, 3);
    p.variantWins[ordinal()]++;
    switch (this) {
      case GLUTSCHMIEDE -> p.dust += 25;
      case FROSTKRYPTA -> {
        Healing.grant(p, 1);
        p.researchNotes += 3;
      }
      default -> {}
    }
  }

  // ---- Glutschmiede: erupting floor ----

  public static final int ERUPT_WARNING = 32;
  public static final double ERUPT_RADIUS = 2.5;

  /** Ticks between two eruptions; faster on harder modes and higher levels, never below 5 s. */
  public static int eruptionInterval(int mode, int level) {
    return Math.max(100, 180 - mode * 20 - Math.min(40, level));
  }

  /** How many spots erupt at once: one on every player plus extra ones on harder modes. */
  public static int eruptions(int players, int mode) {
    return Math.max(1, players) + 1 + mode;
  }

  public static boolean inEruption(double dx, double dz) {
    return dx * dx + dz * dz <= ERUPT_RADIUS * ERUPT_RADIUS;
  }

  // ---- Frostkrypta: cold stacks ----

  public static final int FROST_MAX = 10, FROST_SLOW = 6, FROST_AFTER_FREEZE = 5;
  public static final double BRAZIER_RADIUS = 3.5;

  /** One frost check: warm up at a brazier, otherwise the cold creeps in. */
  public static int frost(int stacks, boolean nearBrazier) {
    if (nearBrazier) return Math.max(0, stacks - 4);
    return Math.min(FROST_MAX, stacks + 1);
  }

  /** Ticks between two frost checks; Veteran and Albtraum get cold faster. */
  public static int frostInterval(int mode) {
    return 40 - Math.clamp(mode, 0, 2) * 5;
  }

  public static boolean frozen(int stacks) {
    return stacks >= FROST_MAX;
  }
}
