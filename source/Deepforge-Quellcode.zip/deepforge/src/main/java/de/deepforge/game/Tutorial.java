package de.deepforge.game;

import java.util.Arrays;

public final class Tutorial {
  private Tutorial() {}

  public static final String[] TITLES = {
    "Baue 15 Erze ab",
    "Lagere 10 Erze ein",
    "Baue deine erste Schmelze",
    "Schmelze einen Barren",
    "Verkaufe einen Barren",
    "Verbessere deinen Bohrer",
    "Übe den Ausweichschritt",
    "Benutze einen Lebenssplitter",
    "Besiege den ersten Minenboss",
    "Stelle deinen ersten Arbeiter ein",
    "Löse das Runenrätsel im Dungeon",
    "Schließe einen Dungeon ab"
  };
  public static final String[] HELP = {
    "Am Minenaufzug die Eisenmine betreten. Mit dem Bohrer Erzadern abbauen.",
    "Am Lager oder in der Schmelze: Erz einlagern. Zehn Erze reichen für fünf Barren.",
    "Schmelze → Ausbau → Schmelze Stufe 1 kaufen. Die ersten Lernprämien finanzieren sie.",
    "Schmelze → Brennstoff kaufen → Schmelzen. Je Barren: zwei Erze und ein Brennstoff.",
    "Am Markt Waren verkaufen. Achte darauf, dass mindestens ein Barren im Lager liegt.",
    "Werkbank → Bohrer verbessern. Mehr Tempo und stärkere Gebiete werden möglich.",
    "Waffe halten, schleichen und rechtsklicken. Nutze den Schritt gegen rote Angriffswarnungen.",
    "Bei fehlendem Leben den grünen Kristall rechtsklicken oder /df heal eingeben.",
    "Am Altar hinten in der Eisenmine den Steinwächter herausfordern. Ausweichen und Heilung"
        + " nutzen.",
    "Mannschaft → Bergarbeiter einstellen. Danach Brennstoff und Betriebsbudget bereitstellen.",
    "Gewölbeingang hinter dem Markt: Nach Welle 2 die Farben merken und die Runenwand anklicken.",
    "Runenrätsel öffnet Tor 1, gemeinsame Bodenplatten Tor 2. Bei roten Kreisen Abstand halten;"
        + " Schreine geben einen Segen."
  };

  public static String title(Profile p) {
    return p.tutorialStep >= TITLES.length ? "Ausbildung abgeschlossen" : TITLES[p.tutorialStep];
  }

  public static String help(Profile p) {
    return p.tutorialStep >= HELP.length
        ? "Eigene Ziele im Abenteuerbuch wählen."
        : HELP[p.tutorialStep];
  }

  private static boolean done(Profile p) {
    return switch (p.tutorialStep) {
      case 0 -> p.mined >= 15;
      case 1 -> p.depositedOre >= 10 || p.manualSmelted > 0;
      case 2 -> p.furnace > 0;
      case 3 -> p.manualSmelted > 0;
      case 4 -> p.soldBars > 0;
      case 5 -> p.tool > 0;
      case 6 -> p.dodges > 0;
      case 7 -> p.healsUsed > 0;
      case 8 -> p.bosses[0];
      case 9 -> !p.workers.isEmpty();
      case 10 -> p.discovered.contains("tutorial/runes");
      case 11 -> Arrays.stream(p.dungeonWins).sum() > 0;
      default -> false;
    };
  }

  public static int advance(Profile p) {
    int count = 0;
    if (p.tutorialPaused) return 0;
    while (done(p)) {
      long coins = p.tutorialStep < 2 ? 650 : p.tutorialStep == 8 ? 1000 : 100;
      p.money = Math.addExact(p.money, coins);
      if (p.tutorialStep == 2) p.fuel += 10;
      if (p.tutorialStep == 6) Healing.grant(p, 1);
      p.tutorialStep++;
      count++;
    }
    return count;
  }

  public static String skip(Profile p) {
    if (p.tutorialStep < TITLES.length) p.tutorialStep++;
    return "Schritt ohne Lernprämie übersprungen. " + title(p);
  }
}
