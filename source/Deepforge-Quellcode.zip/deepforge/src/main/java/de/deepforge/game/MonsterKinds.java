package de.deepforge.game;

import java.util.random.RandomGenerator;

/**
 * Monster types of the mines and the forest (0.21.0: five instead of three). Each type fights
 * differently, so a group of monsters asks for more than hitting the closest one:
 *
 * <ul>
 *   <li>0 Krabbler – small and fast, hits on contact
 *   <li>1 Wächter – armoured front, only the back and flanks take full damage
 *   <li>2 Werfer – stays back and fires a telegraphed beam
 *   <li>3 Sprengling – runs at you, glows red and bursts: step out of the circle or kill it first
 *   <li>4 Springer – keeps its distance and pounces onto a marked spot
 * </ul>
 */
public final class MonsterKinds {
  private MonsterKinds() {}

  public static final int COUNT = 5, CLASSIC = 3;

  public static final String[] MINE = {
    "Erzkrabbler", "Panzerwächter", "Spaltenwerfer", "Sprengling", "Felsspringer"
  };
  public static final String[] FOREST = {
    "Moosling", "Borkenwächter", "Dornenwerfer", "Sporenbovist", "Rankenluchs"
  };

  public static String name(int kind, boolean forest) {
    String[] names = forest ? FOREST : MINE;
    return names[Math.floorMod(kind, names.length)];
  }

  /** Short line for the wiki and the first sighting: how to beat it. */
  public static final String[] TIP = {
    "schnell und klein – trifft bei Berührung",
    "gepanzerte Front – von hinten oder der Seite schlagen",
    "bleibt auf Abstand und schießt einen Strahl – seitlich ausweichen",
    "rennt heran und platzt nach kurzem Glühen – raus aus dem roten Kreis oder vorher erledigen",
    "markiert einen Fleck und springt darauf – weg von der Markierung"
  };

  /** Mine of first appearance: the bomber from mine 2, the pouncer from mine 3. */
  public static int firstZone(int kind) {
    return kind == 3 ? 1 : kind == 4 ? 2 : 0;
  }

  /**
   * Picks a type for a new monster. The three classic types stay the most common; the new ones
   * join once their mine is reached (forest: birch grove = 1, spruce grove = 2, like mine rank).
   */
  public static int roll(int zone, RandomGenerator r) {
    int pool = zone >= firstZone(4) ? COUNT : zone >= firstZone(3) ? 4 : CLASSIC;
    if (pool == CLASSIC) return r.nextInt(CLASSIC);
    // classic types 3 parts each, new types 2 parts each
    int roll = r.nextInt(3 * CLASSIC + 2 * (pool - CLASSIC));
    return roll < 3 * CLASSIC ? roll / 3 : CLASSIC + (roll - 3 * CLASSIC) / 2;
  }

  public static double health(int kind) {
    return switch (kind) {
      case 1 -> 1.8;
      case 3 -> .6;
      case 4 -> 1.2;
      default -> 1;
    };
  }

  public static double speed(int kind) {
    return switch (kind) {
      case 0 -> .27;
      case 3 -> .3;
      case 4 -> .23;
      default -> .21;
    };
  }

  /** Hitbox scale of the (invisible) mob. */
  public static double hitbox(int kind) {
    return switch (kind) {
      case 0 -> .7;
      case 3 -> .75;
      default -> 1;
    };
  }

  /** Model proportions: width, height, overall scale. */
  public static float[] shape(int kind) {
    return switch (kind) {
      case 0 -> new float[] {.92f, 1, .52f};
      case 1 -> new float[] {1.15f, 1, .72f};
      case 2 -> new float[] {.92f, 1.1f, .62f};
      case 3 -> new float[] {1.3f, .78f, .56f};
      default -> new float[] {.82f, 1.22f, .64f};
    };
  }

  /** Monster parts per kill. */
  public static int parts(int kind) {
    return new int[] {1, 2, 3, 1, 2}[Math.floorMod(kind, COUNT)];
  }

  // ---- Sprengling ----
  public static final double BURST_TRIGGER = 2.6, BURST_RADIUS = 3.2;
  public static final int BURST_FUSE = 30;

  /** Burst damage as a multiple of a contact hit. */
  public static final double BURST_DAMAGE = 2.0;

  public static boolean burstHits(double dx, double dz) {
    return dx * dx + dz * dz <= BURST_RADIUS * BURST_RADIUS;
  }

  // ---- Springer ----
  public static final double POUNCE_RADIUS = 2.2, POUNCE_MIN = 3, POUNCE_MAX = 11;
  public static final int POUNCE_WARNING = 26, POUNCE_EVERY = 70;
  public static final double POUNCE_DAMAGE = 1.7;

  /** It only pounces from a few blocks away – up close it just bites. */
  public static boolean canPounce(double distance) {
    return distance >= POUNCE_MIN && distance <= POUNCE_MAX;
  }

  public static boolean pounceHits(double dx, double dz) {
    return dx * dx + dz * dz <= POUNCE_RADIUS * POUNCE_RADIUS;
  }
}
