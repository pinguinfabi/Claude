package de.deepforge.game;

import java.util.*;

/** Player stats for the character page, computed by the same functions the game uses. */
public final class CharacterSheet {
  public static String f(double n) {
    return String.format(Locale.GERMAN, "%.1f", n);
  }

  public static String styleName(String style) {
    return switch (style) {
      case "hammer" -> "Hammer";
      case "dagger" -> "Dolch";
      case "spear" -> "Speer";
      case "crossbow" -> "Armbrust";
      default -> "Schwert";
    };
  }

  public static double hit(Profile p) {
    return RapidCombat.damage(Gear.stats(p));
  }

  public static double averageDps(Profile p) {
    Gear.Stats s = Gear.stats(p);
    return RapidCombat.damage(s) * 4 * (1 + s.crit() * (s.critDamage() - 1));
  }

  public static List<String> combat(Profile p) {
    Gear.Stats s = Gear.stats(p);
    Gear.Item weapon = Gear.equipped(p, Gear.Slot.WEAPON);
    String style = weapon == null ? "sword" : weapon.style;
    List<String> lines = new ArrayList<>();
    lines.add(
        "Trefferschaden: "
            + f(hit(p))
            + " LP  (Grundschaden "
            + f(s.damage())
            + " × 0,65 × Tempo "
            + f(s.speed() / 1.6)
            + ")");
    lines.add(
        "Krit-Chance: "
            + f(s.crit() * 100)
            + " % (ab 100 % trifft jeder Schlag kritisch)  ·  Krit-Schaden: "
            + f(s.critDamage() * 100)
            + " %");
    lines.add("Ø Schaden/s bei 4 Klicks: " + f(averageDps(p)) + " LP vor Gegnerabwehr");
    lines.add(
        "Leben: "
            + f(s.health())
            + "  ·  Rüstung: "
            + f(s.defense())
            + "  ·  Schadensreduktion: "
            + f(s.reduction() * 100)
            + " %");
    lines.add("Haltungsschaden: " + f(RapidCombat.posture(s)) + " pro Treffer gegen Bosse");
    String runes = runes(p);
    if (!runes.isEmpty()) lines.add(runes);
    lines.add(
        "Waffe: "
            + (weapon == null ? "Startwaffe" : weapon.name)
            + " · "
            + styleName(style)
            + " · Reichweite "
            + (style.equals("spear") ? 4 : 3)
            + " Blöcke");
    if (style.equals("dagger"))
      lines.add(
          "Rückenbonus: +"
              + Math.round(WeaponRules.rearBonus(weapon) * 100)
              + " % bei Treffern von hinten (nur Dolche, steigt mit Seltenheit)");
    lines.add(
        "Fähigkeit: "
            + f(s.damage() * (style.equals("hammer") ? 2.1 : 1.5))
            + " LP · 35 Ausdauer · 6 s Abklingzeit");
    return lines;
  }

  /** Everything the socketed runes add, already contained in the values above (0.9.3). */
  public static String runes(Profile p) {
    Set<String> ids = new HashSet<>(p.equipped.values());
    List<String> parts = new ArrayList<>();
    double kraft = Runes.bonus(p, ids, Runes.Kind.KRAFT),
        stein = Runes.bonus(p, ids, Runes.Kind.STEIN),
        leben = Runes.bonus(p, ids, Runes.Kind.LEBEN),
        wind = Runes.bonus(p, ids, Runes.Kind.WIND),
        glueck = Runes.bonus(p, ids, Runes.Kind.GLUECK),
        tiefe = Runes.bonus(p, ids, Runes.Kind.TIEFE);
    if (kraft > 0) parts.add("+" + f(kraft) + " Grundschaden");
    if (stein > 0) parts.add("+" + f(stein) + " Rüstung");
    if (leben > 0) parts.add("+" + f(leben) + " Leben");
    if (wind > 0) parts.add("+" + f(wind / 1.6 * 100) + " % Tempo");
    if (glueck > 0) parts.add("+" + f(glueck * 100) + " % Krit");
    if (tiefe > 0) parts.add("+" + f(tiefe * 100) + " % Abbau");
    return parts.isEmpty() ? "" : "Runen (schon oben eingerechnet): " + String.join(" · ", parts);
  }

  public static List<String> mining(Profile p) {
    int zone = Math.clamp(p.zone, 0, Zone.LAST);
    ToolStats t = ToolStats.of(p, zone, false);
    return List.of(
        "Werkzeugstufe: " + p.tool + "  ·  Modus: " + new String[] {"Ertrag", "Tempo", "Reliktsuche"}[p.module],
        "Abbautempo in " + Zone.at(zone).title + ": " + f(t.speed()) + "×",
        "Extra-Erz-Chance: " + f(t.extraOre() * 100) + " %  ·  Reliktfund: " + f(t.relicChance() * 100) + " %",
        "Hitze je Erz: " + f(t.heatPerOre()) + "  ·  Kühlung: " + f(t.cooling()) + "/s",
        "Rucksack: " + p.bagUsed() + " / " + p.bagCapacity() + " Erze",
        "Brennstoff sparen: " + f(Gear.stats(p).efficiency() * 100) + " %");
  }

  public static List<String> resources(Profile p) {
    List<String> lines = new ArrayList<>();
    lines.add("Geld: " + p.money + " $  ·  Schmiedestaub: " + p.dust);
    lines.add("Relikte: " + p.relics + "  ·  Forschungsunterlagen: " + p.researchNotes);
    lines.add("Heilsplitter: " + p.healingCharges + " / " + Healing.capacity(p));
    lines.add("Lager: " + p.stockUsed() + " / " + p.stockCapacity() + "  ·  Brennstoff: " + p.fuel);
    lines.add("Betriebsbudget: " + p.budget + " $");
    for (int z = 0; z <= Math.clamp(p.zone, 0, Zone.LAST); z++)
      lines.add(
          Zone.at(z).title
              + ": "
              + p.bossTokens[z]
              + " Bossfragmente · "
              + p.monsterParts[z]
              + " "
              + Gear.MATERIALS[z]);
    lines.add("Staub gibt es beim Zerlegen, für Jagdaufträge, von Bergarbeitern und Meilensteinen.");
    return lines;
  }

  public static List<String> progress(Profile p) {
    long bosses = 0;
    for (boolean b : p.bosses) if (b) bosses++;
    long milestones = p.milestones.size();
    return List.of(
        "Gebiet: " + (p.zone + 1) + " / " + Zone.COUNT + "  ·  Bosse besiegt: " + bosses + " / " + Zone.COUNT,
        "Dungeonlevel je Gebiet: "
            + String.join(
                " / ",
                java.util.stream.IntStream.rangeClosed(0, p.zone)
                    .mapToObj(z -> Integer.toString(DungeonRules.level(p, z)))
                    .toList()),
        "Gegner besiegt: " + p.kills + "  ·  Erz abgebaut: " + p.mined,
        "Bäume gefällt: " + p.woodTrees + "  ·  Barren geschmolzen: " + p.manualSmelted,
        "Forschung: " + Arrays.stream(p.research).sum() + " / 25 Stufen",
        "Meilensteine: "
            + milestones
            + " / "
            + Milestones.GOALS.size() * 3
            + (Milestones.claimableCount(p) > 0
                ? "  ·  " + Milestones.claimableCount(p) + " abholbar!"
                : ""));
  }

  private CharacterSheet() {}
}
