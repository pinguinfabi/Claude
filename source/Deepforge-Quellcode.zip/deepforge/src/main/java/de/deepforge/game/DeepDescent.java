package de.deepforge.game;

import java.time.*;
import java.time.temporal.IsoFields;
import java.util.Random;

/**
 * Tiefengang (0.9.3): an endless descent through one arena. Every Ebene has two waves (three
 * from Ebene 10), every fifth Ebene ends with a boss. The enemies never stop growing, so every
 * run ends – the question is only how deep. Rewards are paid per Ebene; the deepest Ebene of the
 * week goes onto the weekly leaderboard.
 */
public final class DeepDescent {
  private DeepDescent() {}

  /** Unlocked with the first dungeon win. */
  public static boolean unlocked(Profile p) {
    return java.util.Arrays.stream(p.dungeonWins).sum() > 0;
  }

  public static boolean bossFloor(int floor) {
    return floor % 5 == 0;
  }

  public static int waves(int floor) {
    return floor >= 10 ? 3 : 2;
  }

  /** Dungeon level the enemies of an Ebene use (+2 per Ebene). */
  public static int level(int floor) {
    return 1 + (Math.max(1, floor) - 1) * 2;
  }

  /** Extra pressure on top of the dungeon level: +6 % life and +4 % damage per Ebene. */
  public static double health(int floor) {
    return Math.pow(1.06, Math.max(0, floor - 1));
  }

  public static double damage(int floor) {
    return Math.pow(1.04, Math.max(0, floor - 1));
  }

  /** Name of an Ebene's depth band; it changes the arena's stone every five Ebenen. */
  public static int band(int floor) {
    return Math.floorMod((Math.max(1, floor) - 1) / 5, Zone.COUNT);
  }

  /** Enemy zone of an Ebene: everyone starts in the Eisenmine, every five Ebenen one mine deeper. */
  public static int zone(int floor) {
    return Math.min(Zone.LAST, (Math.max(1, floor) - 1) / 5);
  }

  public static String bandName(int floor) {
    return Zone.at(band(floor)).title;
  }

  /** Coins for a cleared Ebene: a third of a dungeon win at that level, more on boss Ebenen. */
  public static long coins(int zone, int floor) {
    long base = DungeonRules.coins(zone, 0, level(floor)) / 3;
    return bossFloor(floor) ? base * 3 : base;
  }

  /** Reward for one cleared Ebene; returns the chat lines. Boss Ebenen also give gear. */
  public static java.util.List<String> reward(Profile p, int zone, int floor, Random r) {
    java.util.List<String> lines = new java.util.ArrayList<>();
    long coins = Math.round(coins(zone, floor) * Prestige.money(p));
    p.money = Math.addExact(p.money, coins);
    p.lifetimeRevenue = Math.addExact(p.lifetimeRevenue, coins);
    long dust = 3L + floor / 2;
    p.dust += dust;
    lines.add("+" + coins + " $ · +" + dust + " Schmiedestaub");
    if (bossFloor(floor)) {
      int roll = r.nextInt(1000), level = level(floor);
      Gear.Rarity rarity =
          roll < DungeonRules.mythicThreshold(1, level)
              ? Gear.Rarity.MYTHIC
              : roll < DungeonRules.legendaryThreshold(1, level)
                  ? Gear.Rarity.LEGENDARY
                  : roll < DungeonRules.epicThreshold(1, level) ? Gear.Rarity.EPIC : Gear.Rarity.RARE;
      Gear.Item loot = Gear.roll(zone, rarity, r);
      double growth = DungeonRules.lootGrowth(level);
      loot.damage *= growth;
      loot.health *= growth;
      loot.defense *= growth;
      loot.dungeonRank = level;
      loot.name = "Tiefengang E" + floor + ": " + loot.name;
      p.discovered.add(loot.slot.name() + "/" + loot.rarity.name());
      if (p.gear.size() < 120) p.gear.add(loot);
      else p.dust += 40L * (rarity.ordinal() + 1);
      lines.add(RewardDiff.item(loot));
      if (r.nextDouble() < Runes.DEEP_BOSS) {
        Runes.drop(p, Math.min(6, zone + floor / 10), r);
        lines.add("+1 Rune");
      }
    }
    return lines;
  }

  // ---- records & weekly board ----

  /** ISO year*100 + week, e.g. 202640. */
  public static int week(long millis) {
    LocalDate d = Instant.ofEpochMilli(millis).atZone(ZoneId.of("Europe/Berlin")).toLocalDate();
    return d.get(IsoFields.WEEK_BASED_YEAR) * 100 + d.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR);
  }

  public static int currentWeek() {
    return week(System.currentTimeMillis());
  }

  /** Records a cleared Ebene; true when it is a new personal weekly best. */
  public static boolean record(Profile p, int floor, int week) {
    if (p.deepWeek != week) {
      p.deepWeek = week;
      p.deepWeekBest = 0;
    }
    p.deepBest = Math.max(p.deepBest, floor);
    if (floor <= p.deepWeekBest) return false;
    p.deepWeekBest = floor;
    return true;
  }

  public static int weekBest(Profile p, int week) {
    return p.deepWeek == week ? p.deepWeekBest : 0;
  }
}
