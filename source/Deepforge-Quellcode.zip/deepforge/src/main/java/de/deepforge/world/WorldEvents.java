package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.entity.Player;

/** Server-wide timed events: every player on the server profits at the same time. */
public final class WorldEvents {
  public enum Kind {
    GOLDRAUSCH("Goldrausch", "Erz und Barren verkaufen sich für +50 %", BossBar.Color.YELLOW),
    ERZRAUSCH("Erzrausch", "50 % Chance auf ein Extra-Erz pro Block", BossBar.Color.BLUE),
    MONSTERFLUT("Monsterflut", "Minenmonster: doppelte Beute- und Heilsplitter-Chance", BossBar.Color.RED),
    TIEFENFIEBER("Tiefenfieber", "Doppelte Tiefenpass-XP für alles", BossBar.Color.PURPLE),
    CHAMPIONJAGD("Championjagd", "Viermal so viele Champions in den Minen", BossBar.Color.PINK);
    public final String title, effect;
    final BossBar.Color color;

    Kind(String title, String effect, BossBar.Color color) {
      this.title = title;
      this.effect = effect;
      this.color = color;
    }
  }

  private final DeepforgePlugin plugin;
  private final BossBar bar =
      BossBar.bossBar(Component.empty(), 1, BossBar.Color.YELLOW, BossBar.Overlay.NOTCHED_10);
  private final Set<UUID> viewers = new HashSet<>();
  private Kind active, last;
  private long startedAt, endsAt, nextAt;

  public WorldEvents(DeepforgePlugin plugin) {
    this.plugin = plugin;
    nextAt = System.currentTimeMillis() + minutes("world-interval-minutes", 45) * 60_000L / 2;
    Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 40, 20);
  }

  private int minutes(String key, int fallback) {
    return Math.max(1, plugin.getConfig().getInt("events." + key, fallback));
  }

  public boolean active(Kind kind) {
    return active == kind && System.currentTimeMillis() < endsAt;
  }

  public Kind current() {
    return active;
  }

  /** Multiplier on ore and bar sales. */
  public double saleBoost() {
    return active(Kind.GOLDRAUSCH) ? 1.5 : 1;
  }

  public long minutesLeft() {
    return Math.max(0, (endsAt - System.currentTimeMillis() + 59_999) / 60_000);
  }

  public long minutesUntilNext() {
    return Math.max(0, (nextAt - System.currentTimeMillis() + 59_999) / 60_000);
  }

  /** One line for menus: what runs now or when the next event comes. */
  public String status() {
    if (active != null)
      return active.title + " läuft noch " + minutesLeft() + " Min.: " + active.effect;
    if (!plugin.getConfig().getBoolean("events.world-events", true))
      return "Weltereignisse sind auf diesem Server aus.";
    return "Nächstes Weltereignis in etwa " + minutesUntilNext() + " Min.";
  }

  public String start(Kind kind, int minutes) {
    if (active != null) end(false);
    active = kind;
    startedAt = System.currentTimeMillis();
    endsAt = startedAt + Math.max(1, minutes) * 60_000L;
    bar.color(kind.color);
    update();
    for (Player p : Bukkit.getOnlinePlayers()) {
      if (!plugin.playing(p)) continue;
      p.showTitle(
          Title.title(
              Component.text("WELTEREIGNIS: " + kind.title.toUpperCase(Locale.ROOT), NamedTextColor.GOLD),
              Component.text(kind.effect, NamedTextColor.YELLOW)));
      p.playSound(p.getLocation(), Sound.EVENT_RAID_HORN, .5f, 1.3f);
      plugin.tell(p, "Weltereignis „" + kind.title + "“ für " + minutes + " Minuten: " + kind.effect + "!");
    }
    return kind.title + " gestartet (" + minutes + " Min.).";
  }

  public String stop() {
    if (active == null) return "Kein Weltereignis aktiv.";
    end(true);
    return "Weltereignis beendet.";
  }

  private void end(boolean announce) {
    Kind ended = active;
    last = active;
    active = null;
    nextAt = System.currentTimeMillis() + minutes("world-interval-minutes", 45) * 60_000L;
    for (UUID id : viewers) {
      Player p = Bukkit.getPlayer(id);
      if (p != null) p.hideBossBar(bar);
    }
    viewers.clear();
    if (announce && ended != null)
      for (Player p : Bukkit.getOnlinePlayers())
        if (plugin.playing(p))
          plugin.tell(
              p,
              "Weltereignis „" + ended.title + "“ vorbei. Das nächste kommt in etwa "
                  + minutesUntilNext() + " Minuten.");
  }

  private void update() {
    long now = System.currentTimeMillis();
    long left = Math.max(0, endsAt - now);
    bar.name(
        Component.text("✦ " + active.title + " ✦ ", NamedTextColor.GOLD)
            .append(Component.text(active.effect, NamedTextColor.YELLOW))
            .append(
                Component.text(
                    String.format(Locale.ROOT, "  %d:%02d", left / 60_000, left / 1000 % 60),
                    NamedTextColor.GRAY)));
    bar.progress((float) Math.max(0, Math.min(1, left / (double) Math.max(1, endsAt - startedAt))));
  }

  private void tick() {
    long now = System.currentTimeMillis();
    if (active != null) {
      if (now >= endsAt) {
        end(true);
        return;
      }
      update();
      Set<UUID> present = new HashSet<>();
      for (Player p : Bukkit.getOnlinePlayers())
        if (plugin.playing(p)) {
          present.add(p.getUniqueId());
          if (viewers.add(p.getUniqueId())) p.showBossBar(bar);
        }
      for (Iterator<UUID> it = viewers.iterator(); it.hasNext(); ) {
        UUID id = it.next();
        if (present.contains(id)) continue;
        Player p = Bukkit.getPlayer(id);
        if (p != null) p.hideBossBar(bar);
        it.remove();
      }
      return;
    }
    if (!plugin.getConfig().getBoolean("events.world-events", true) || now < nextAt) return;
    long players = Bukkit.getOnlinePlayers().stream().filter(plugin::playing).count();
    if (players < plugin.getConfig().getInt("events.world-min-players", 1)) {
      nextAt = now + 60_000;
      return;
    }
    List<Kind> choices = new ArrayList<>(List.of(Kind.values()));
    if (last != null && choices.size() > 1) choices.remove(last);
    start(
        choices.get(ThreadLocalRandom.current().nextInt(choices.size())),
        minutes("world-duration-minutes", 10));
  }

  public void shutdown() {
    for (UUID id : viewers) {
      Player p = Bukkit.getPlayer(id);
      if (p != null) p.hideBossBar(bar);
    }
    viewers.clear();
  }
}
