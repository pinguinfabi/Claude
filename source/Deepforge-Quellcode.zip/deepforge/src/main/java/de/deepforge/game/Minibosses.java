package de.deepforge.game;

import java.util.*;

/**
 * Wächter (0.11.0): minibosses that guard one or two rooms of every dungeon. Each one has a rule
 * the group has to work out – plain damage alone does not beat them. They appear with the last
 * wave of their room and drop a Wächtertruhe.
 */
public final class Minibosses {
  public enum Kind {
    SHIELD(
        "Schildträger",
        "Nur von hinten verwundbar – einer lenkt ab, die anderen umrunden ihn!",
        "Der Schild fängt alles vorne ab. Schläge treffen nur von hinten (seitlich hinter ihm)."),
    CALLER(
        "Beschwörer",
        "Unverwundbar, solange seine Diener leben – erst die Diener!",
        "Ruft immer wieder Diener. Solange einer lebt, ist er immun (blauer Ring)."),
    TWINS(
        "Zwillinge",
        "Beide innerhalb von 5 Sekunden besiegen – sonst steht der andere wieder auf!",
        "Zwei Wächter. Fällt einer, muss der zweite in 5 s folgen – sonst ersteht der erste mit"
            + " halbem Leben."),
    MIRROR(
        "Spiegelritter",
        "Leuchtet er weiß, wirft er jeden Schlag zurück – dann Finger weg!",
        "Alle paar Sekunden leuchtet er. Wer dann zuschlägt, bekommt den Schaden selbst ab."),
    CHAIN(
        "Kettenbrecher",
        "Ihr seid an ihn gekettet – mehr als 7 Blöcke weg tut weh!",
        "Jeder Spieler hängt an einer Kette. Wer weiter als 7 Blöcke weg ist, nimmt jede Sekunde"
            + " Schaden."),
    ROOT(
        "Wurzelhexe",
        "Dornenboden! Wenn es grün leuchtet: rauf auf eine Insel!",
        "Lässt regelmäßig Dornen aus dem ganzen Boden brechen. Sicher ist nur, wer auf einer der"
            + " grünen Inseln steht.");

    public final String title, hint, wiki;

    Kind(String title, String hint, String wiki) {
      this.title = title;
      this.hint = hint;
      this.wiki = wiki;
    }
  }

  /** Share of the room's boss health a guardian has (twins: each). */
  public static final double HEALTH = .35, TWIN_HEALTH = .22;

  /** Guardians hit 60 % harder than normal enemies. */
  public static final double DAMAGE = 1.6;

  /** Ticks the second twin has after the first fell (5 s). */
  public static final int TWIN_WINDOW = 100;

  public static final double TWIN_REVIVE = .5;

  /** Kettenbrecher: free range before the chain hurts. */
  public static final double TETHER = 7;

  /** Wurzelhexe: radius of a safe island. */
  public static final double ISLAND = 2.5;

  /** Beschwörer: time between summons once the old minions are dead. */
  public static final int CALL_EVERY = 300;

  private Minibosses() {}

  /** Normal: one guarded room, Veteran and Albtraum: two. */
  public static int count(int mode) {
    return mode <= 0 ? 1 : 2;
  }

  /**
   * Which main rooms get a guardian: rooms with waves, never the first (warm-up) and never the boss
   * room. Deterministic per run.
   */
  public static List<Integer> rooms(List<Integer> fightRooms, int bossRoom, int mode, long seed) {
    List<Integer> pool = new ArrayList<>();
    for (int i : fightRooms) if (i > 0 && i != bossRoom) pool.add(i);
    Collections.shuffle(pool, new Random(seed ^ 0x5EEDL));
    List<Integer> out = new ArrayList<>(pool.subList(0, Math.min(count(mode), pool.size())));
    Collections.sort(out);
    return out;
  }

  /** Guardian of a room; two rooms of one run never share a kind. */
  public static Kind kind(long seed, int order) {
    List<Kind> all = new ArrayList<>(List.of(Kind.values()));
    Collections.shuffle(all, new Random(seed ^ 0xC0FFEEL));
    return all.get(Math.floorMod(order, all.size()));
  }

  /**
   * Schildträger: {@code alignment} is the cosine between "guardian → player" and the guardian's
   * facing (1 in front, −1 right behind). Only the back half counts, with a small grace zone.
   */
  public static boolean behind(double alignment) {
    return alignment <= -.25;
  }

  /** Spiegelritter: the mirror is up for part of every cycle; longer on harder modes. */
  public static boolean mirrored(long ticksSinceSpawn, int mode) {
    if (ticksSinceSpawn < 80) return false;
    long t = (ticksSinceSpawn - 80) % mirrorCycle(mode);
    return t < mirrorTime(mode);
  }

  public static int mirrorCycle(int mode) {
    return 200 - 20 * mode;
  }

  public static int mirrorTime(int mode) {
    return 50 + 15 * mode;
  }

  /** Reflected damage per blocked swing, as a multiple of a normal enemy hit. */
  public static double reflect(int mode) {
    return 1.5 + mode;
  }

  public static boolean tethered(double distance) {
    return distance > TETHER;
  }

  /** Wurzelhexe: time between eruptions and the green warning before them. */
  public static int rootCycle(int mode) {
    return 240 - 30 * mode;
  }

  public static int rootWarning(int mode) {
    return 60 - 10 * mode;
  }

  /** Islands per eruption: enough for the group, fewer on harder modes (players must share). */
  public static int islands(int players, int mode) {
    return Math.max(1, Math.max(3 - mode, (players + 1) / 2));
  }

  public static boolean onIsland(double x, double z, List<double[]> islands) {
    for (double[] i : islands) {
      double dx = x - i[0], dz = z - i[1];
      if (dx * dx + dz * dz <= ISLAND * ISLAND) return true;
    }
    return false;
  }

  /** Beschwörer: minions per call. */
  public static int minions(int mode, int players) {
    return 2 + mode + Math.max(0, players - 2) / 2;
  }

  /** Twins: the fallen one stands up again when the window runs out. */
  public static boolean revive(long fellAt, long now) {
    return fellAt >= 0 && now - fellAt >= TWIN_WINDOW;
  }

  /**
   * Wächtertruhe for one player: a quarter of the dungeon's coins, Schmiedestaub and one item
   * (at least rare). Returns the lines to show.
   */
  public static List<String> chest(
      Profile p, int zone, int mode, int level, Kind kind, java.util.random.RandomGenerator r) {
    List<String> out = new ArrayList<>();
    long coins = DungeonRules.coins(zone, mode, level) / 4;
    long dust = 10 + 5L * mode + zone;
    p.money += coins;
    p.lifetimeRevenue += coins;
    p.dust += dust;
    int chance = r.nextInt(1000);
    Gear.Rarity rarity =
        chance < DungeonRules.mythicThreshold(mode, level)
            ? Gear.Rarity.MYTHIC
            : chance < DungeonRules.legendaryThreshold(mode, level)
                ? Gear.Rarity.LEGENDARY
                : chance < DungeonRules.epicThreshold(mode, level)
                    ? Gear.Rarity.EPIC
                    : Gear.Rarity.RARE;
    Gear.Item loot = Gear.roll(zone, rarity, r);
    loot.dungeonRank = level;
    double growth = DungeonRules.lootGrowth(level);
    loot.damage *= growth;
    loot.health *= growth;
    loot.defense *= growth;
    loot.name = kind.title + ": " + loot.name;
    p.discovered.add(loot.slot.name() + "/" + loot.rarity.name());
    if (p.gear.size() < 120) {
      p.gear.add(loot);
      out.add(RewardDiff.item(loot));
    } else {
      long extra = 40L * (rarity.ordinal() + 1);
      p.dust += extra;
      out.add("Beutel voll – " + extra + " Schmiedestaub statt Gegenstand");
    }
    out.add("+" + String.format(Locale.GERMAN, "%,d", coins) + " $");
    out.add("+" + dust + " Schmiedestaub");
    return out;
  }
}
