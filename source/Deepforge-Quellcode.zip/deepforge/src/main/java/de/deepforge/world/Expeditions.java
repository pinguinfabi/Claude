package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import java.util.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/** Clickable discoveries live in real side tunnels. No new terrain generation is necessary. */
public final class Expeditions implements Listener, AutoCloseable {
  private record Cache(UUID owner, int id, List<Entity> entities) {}

  private final DeepforgePlugin plugin;
  private final Map<UUID, Cache> clicks = new HashMap<>();
  private final Map<Integer, List<WorkerRoutes.Site>> locations = new HashMap<>();

  public Expeditions(DeepforgePlugin plugin) {
    this.plugin = plugin;
    Bukkit.getPluginManager().registerEvents(this, plugin);
  }

  public static List<WorkerRoutes.Site> locations(MineBlueprint plan) {
    List<WorkerRoutes.Site> choices = new ArrayList<>(WorkerRoutes.sites(plan)),
        found = new ArrayList<>();
    for (int[] target : new int[][] {{-26, 49}, {26, 65}, {-23, 72}}) {
      var best =
          choices.stream()
              .min(
                  Comparator.comparingDouble(
                      s -> Math.hypot(s.stand().x() - target[0], s.stand().z() - target[1])))
              .orElseThrow();
      found.add(best);
      choices.removeIf(
          s -> Math.hypot(s.stand().x() - best.stand().x(), s.stand().z() - best.stand().z()) < 6);
    }
    return List.copyOf(found);
  }

  public void show(Player player, int zone) {
    clear(player.getUniqueId());
    Profile p = plugin.profile(player);
    spawn(p, player.getUniqueId(), zone);
  }

  private void spawn(Profile p, UUID owner, int zone) {
    List<WorkerRoutes.Site> sites =
        locations.computeIfAbsent(zone, z -> locations(plugin.mines().blueprint(z)));
    for (int n = 0; n < 3; n++) {
      int id = zone * 3 + n;
      if (p.expeditions[id]) continue;
      var point = sites.get(n).stand();
      Location at =
          plugin.mines().local(p, point.x() + .5, plugin.mines().floor(zone) + 1, point.z() + .5);
      List<Entity> entities = new ArrayList<>();
      try {
        entities.add(
            at.getWorld()
                .spawn(
                    at,
                    ItemDisplay.class,
                    e -> {
                      e.setItemStack(plugin.items().model(Material.PAPER, "crate", "Fundkiste"));
                      e.setPersistent(false);
                      e.setTransformation(
                          new Transformation(
                              new Vector3f(0, .4f, 0),
                              new Quaternionf(),
                              new Vector3f(.8f),
                              new Quaternionf()));
                    }));
        entities.add(
            at.getWorld()
                .spawn(
                    at.clone().add(0, 1.35, 0),
                    TextDisplay.class,
                    e -> {
                      e.text(
                          Component.text(
                              "VERSCHOLLENE VORRÄTE\nRechtsklick · Forschungsfund",
                              NamedTextColor.AQUA));
                      e.setBillboard(Display.Billboard.CENTER);
                      e.setShadowed(true);
                      e.setPersistent(false);
                      e.setViewRange(.3f);
                    }));
        Interaction hit =
            at.getWorld()
                .spawn(
                    at,
                    Interaction.class,
                    e -> {
                      e.setInteractionWidth(1);
                      e.setInteractionHeight(1);
                      e.setResponsive(true);
                      e.setPersistent(false);
                    });
        entities.add(hit);
        // Shared mine: other players neither see nor click this player's finds.
        for (Entity e : entities) plugin.mines().personal(p, e);
        clicks.put(hit.getUniqueId(), new Cache(owner, id, entities));
      } catch (RuntimeException ex) {
        entities.forEach(Entity::remove);
        throw ex;
      }
    }
  }

  @EventHandler
  public void click(PlayerInteractEntityEvent event) {
    Cache cache = clicks.get(event.getRightClicked().getUniqueId());
    if (cache == null) return;
    event.setCancelled(true);
    Player player = event.getPlayer();
    if (event.getHand() != EquipmentSlot.HAND
        || !cache.owner.equals(player.getUniqueId())
        || !plugin.playing(player)
        || plugin.combat().fighting(player)
        || player.getLocation().distanceSquared(event.getRightClicked().getLocation()) > 25) return;
    Profile p = plugin.profile(player);
    String text = Industry.discover(p, cache.id);
    if (!plugin.commit(player, p)) return;
    player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1, 1.2f);
    player
        .getWorld()
        .spawnParticle(
            Particle.HAPPY_VILLAGER,
            event.getRightClicked().getLocation().add(0, .7, 0),
            15,
            .4,
            .3,
            .4,
            0);
    plugin.tell(player, text);
    cache.entities.forEach(Entity::remove);
    clicks.remove(event.getRightClicked().getUniqueId());
  }

  public void clear(UUID owner) {
    clicks
        .entrySet()
        .removeIf(
            e -> {
              if (e.getValue().owner.equals(owner)) {
                e.getValue().entities.forEach(Entity::remove);
                return true;
              }
              return false;
            });
  }

  private String verification;
  private final Set<Chunk> verificationChunks = new HashSet<>();

  public String verify(Profile saved) {
    if (verification != null) return verification;
    verification = "RUNNING";
    for (int zone = 0; zone < 7; zone++)
      for (var site : locations(plugin.mines().blueprint(zone))) {
        Chunk chunk =
            plugin
                .mines()
                .local(saved, site.stand().x(), plugin.mines().floor(zone) + 1, site.stand().z())
                .getChunk();
        if (!chunk.isForceLoaded()) {
          chunk.setForceLoaded(true);
          verificationChunks.add(chunk);
        }
      }
    Bukkit.getScheduler()
        .runTaskLater(
            plugin,
            () -> {
              try {
                verification = verifyLoaded(saved);
              } catch (RuntimeException ex) {
                verification = "EXPEDITIONS FAILED: " + ex;
              } finally {
                verificationChunks.forEach(c -> c.setForceLoaded(false));
                verificationChunks.clear();
              }
            },
            20);
    return verification;
  }

  private String verifyLoaded(Profile saved) {
    Profile p = new Profile();
    p.plot = saved.plot;
    UUID owner = UUID.randomUUID();
    int count = 0;
    try {
      for (int zone = 0; zone < 7; zone++) {
        spawn(p, owner, zone);
        for (Cache c : clicks.values())
          if (c.owner.equals(owner)) {
            if (c.entities.size() != 3 || c.entities.stream().anyMatch(e -> !e.isValid()))
              throw new IllegalStateException("Invalid cache entities");
            Location at = c.entities.getLast().getLocation();
            if (!at.getBlock().isPassable() || !at.clone().add(0, 1, 0).getBlock().isPassable())
              throw new IllegalStateException("Cache in solid blocks");
            count++;
          }
        clear(owner);
      }
      return "EXPEDITIONS OK: "
          + count
          + " reachable caches, 63 model/label/interaction entities created and removed; no rewards"
          + " issued";
    } finally {
      clear(owner);
    }
  }

  @Override
  public void close() {
    verificationChunks.forEach(c -> c.setForceLoaded(false));
    verificationChunks.clear();
    clicks.values().forEach(c -> c.entities.forEach(Entity::remove));
    clicks.clear();
  }
}
