package de.deepforge.game;

import java.util.*;

/** Shared deterministic scaling and once-per-run personal rewards. */
public final class DungeonRules {
  private DungeonRules() {}

  public static final int TIME_MINUTES = 30;
  public static final int TIME_TICKS = TIME_MINUTES * 1200;

  public static final String[] MODES = {"Normal", "Veteran", "Albtraum"};
  public static final String[] CONDITIONS = {"Rudel", "Raserei", "Elitepatrouille", "Runensturm"};

  public static int level(Profile p) {
    if (p.dungeonLevel == 0)
      p.dungeonLevel = Math.toIntExact(1L + Arrays.stream(p.dungeonWins).asLongStream().sum());
    if (p.dungeonLevel < 1) throw new IllegalStateException("Invalid dungeon level");
    return p.dungeonLevel;
  }

  /**
   * Dungeon level of one zone: every zone has its own level, +1 per win there. Older saves start
   * at 1 + the wins already recorded in that zone.
   */
  public static int level(Profile p, int zone) {
    if (zone < 0 || zone > 6) throw new IllegalArgumentException();
    if (p.zoneLevels == null || p.zoneLevels.length < 7)
      p.zoneLevels = Arrays.copyOf(p.zoneLevels == null ? new int[0] : p.zoneLevels, 7);
    if (p.zoneLevels[zone] <= 0)
      p.zoneLevels[zone] =
          1 + p.dungeonWins[zone * 3] + p.dungeonWins[zone * 3 + 1] + p.dungeonWins[zone * 3 + 2];
    return p.zoneLevels[zone];
  }

  /** Highest zone level, shown where only one number fits. */
  public static int bestLevel(Profile p) {
    int best = 1;
    for (int z = 0; z < 7; z++) best = Math.max(best, level(p, z));
    return best;
  }

  public static int groupLevel(Collection<Profile> party, int zone) {
    if (party.isEmpty() || party.size() > 4) throw new IllegalArgumentException();
    return party.stream().mapToInt(p -> level(p, zone)).max().orElseThrow();
  }

  public static int groupLevel(Collection<Profile> party) {
    if (party.isEmpty() || party.size() > 4) throw new IllegalArgumentException();
    return party.stream().mapToInt(DungeonRules::level).max().orElseThrow();
  }

  public static int waves(int level) {
    return 5 + Math.min(3, (level - 1) / 10);
  }

  public static int condition(int level) {
    return level == 1 ? -1 : Math.floorMod(level - 2, CONDITIONS.length);
  }

  public static String conditionName(int level) {
    return level == 1 ? "Erste Expedition" : CONDITIONS[condition(level)];
  }

  public static int activeLimit(int players) {
    return 6 + players * 2;
  }

  public static int count(int wave, int players, int level) {
    if (level < 1 || wave < 1 || wave > waves(level) || players < 1 || players > 4)
      throw new IllegalArgumentException();
    int extra = Math.min(18, (level - 1) / 3) + (condition(level) == 0 ? 2 + players : 0);
    return wave == waves(level) ? 1 + players + Math.min(8, extra / 2) : 2 + wave + players + extra;
  }

  public static boolean elite(int level, int ordinal) {
    if (level < 3) return false;
    int interval = condition(level) == 2 ? 3 : Math.max(3, 7 - level / 10);
    return ordinal % interval == 0;
  }

  public static int kind(int level, int wave, int ordinal, long seed) {
    return Math.floorMod(seed + wave + ordinal, level >= 4 ? 4 : 3);
  }

  public static double health(int zone, int mode, int players, int wave, boolean boss, int level) {
    // x1.15: a little more life everywhere (0.7.1).
    return health(zone, mode, players, wave, boss) * (1 + .10 * (level - 1)) * 1.15;
  }

  public static double damage(int zone, int mode, boolean boss, int level, int players) {
    return damage(zone, mode, boss)
        * (1 + .025 * (level - 1))
        * (1 + .06 * (players - 1));
  }

  public static int recovery(int level, boolean enraged) {
    return Math.max(
        26, (enraged ? 40 : 70) - Math.min(18, level / 3) - (condition(level) == 1 ? 10 : 0));
  }

  public static int warning(int level, boolean enraged) {
    return Math.max(22, (enraged ? 30 : 38) - Math.min(8, level / 5));
  }

  public static long coins(int zone, int mode, int level) {
    return Math.round(coins(zone, mode) * (1 + .12 * (level - 1)));
  }

  public static int mythicThreshold(int mode, int level) {
    return 5 + mode * 5 + Math.min(25, (level - 1) / 4);
  }

  public static int legendaryThreshold(int mode, int level) {
    return 55 + mode * 35 + (int) Math.min(100L, (level - 1) * 2L);
  }

  public static int epicThreshold(int mode, int level) {
    return Math.min(850, 300 + mode * 100 + (int) Math.min(200L, (level - 1) * 4L));
  }

  public static int count(int wave, int players) {
    if (wave < 1 || wave > 5 || players < 1 || players > 4) throw new IllegalArgumentException();
    return wave == 5 ? 1 + players : 2 + wave + players;
  }

  public static double health(int zone, int mode, int players, int wave, boolean boss) {
    return (boss ? 500 + zone * 180 : 22 + zone * 9 + wave * 6)
        * (boss ? 12 : 4)
        * (1 + mode * .55)
        * (1 + (players - 1) * .85);
  }

  public static double damage(int zone, int mode, boolean boss) {
    // Deeper zones hit much harder (+30 % per zone), matching the mine monsters.
    return (boss ? 6 : 2.5) * MonsterScaling.bossDamage(zone) * (1 + mode * .35);
  }

  public static long coins(int zone, int mode) {
    return (600L + zone * 450L) * (mode + 1);
  }

  public static List<Integer> sequence(UUID run, int puzzle) {
    Random r = new Random(run.getMostSignificantBits() ^ run.getLeastSignificantBits() ^ puzzle);
    List<Integer> order = new ArrayList<>(List.of(0, 1, 2, 3));
    Collections.shuffle(order, r);
    return List.copyOf(order.subList(0, 3));
  }

  public static boolean reward(Profile p, UUID run, int zone, int mode, long ticks) {
    return reward(p, run, zone, mode, ticks, level(p));
  }

  public static boolean reward(Profile p, UUID run, int zone, int mode, long ticks, int runLevel) {
    return reward(p, run, zone, mode, ticks, runLevel, 0);
  }

  public static boolean reward(
      Profile p, UUID run, int zone, int mode, long ticks, int runLevel, int optionalFlags) {
    return reward(p, run, zone, mode, ticks, runLevel, optionalFlags, EnumSet.noneOf(Gear.Slot.class));
  }

  /**
   * {@code taken} holds the equipment slots other party members already received from this run;
   * each member gets a different kind of item, and the chosen slot is added to the set.
   */
  public static boolean reward(
      Profile p,
      UUID run,
      int zone,
      int mode,
      long ticks,
      int runLevel,
      int optionalFlags,
      Set<Gear.Slot> taken) {
    return reward(p, run, zone, mode, ticks, runLevel, optionalFlags, taken, DungeonVariant.GEWOELBE);
  }

  /** As above for one of the three dungeons: loot focus, coin bonus and the dungeon's extra. */
  public static boolean reward(
      Profile p,
      UUID run,
      int zone,
      int mode,
      long ticks,
      int runLevel,
      int optionalFlags,
      Set<Gear.Slot> taken,
      DungeonVariant variant) {
    if (zone < 0 || zone > 6 || mode < 0 || mode > 2 || ticks < 0 || runLevel < 1)
      throw new IllegalArgumentException();
    String receipt = run.toString();
    if (p.dungeonReceipts.contains(receipt)) return false;
    if (optionalFlags < 0 || optionalFlags > 15 || (optionalFlags & 3) == 3)
      throw new IllegalArgumentException();
    Random r =
        new Random(run.getMostSignificantBits() ^ UUID.fromString(p.id).getLeastSignificantBits());
    int chance = r.nextInt(1000);
    Gear.Rarity rarity =
        chance < mythicThreshold(mode, runLevel)
            ? Gear.Rarity.MYTHIC
            : chance < legendaryThreshold(mode, runLevel)
                ? Gear.Rarity.LEGENDARY
                : chance < epicThreshold(mode, runLevel) ? Gear.Rarity.EPIC : Gear.Rarity.RARE;
    Gear.Item loot = Gear.roll(zone, rarity, r);
    // Prefer the dungeon's focus slots that nobody in the party got yet, then any free slot.
    for (int tries = 0;
        (taken.contains(loot.slot) || variant.focus(loot.slot) != focusable(variant, taken))
            && tries < 60;
        tries++) loot = Gear.roll(zone, rarity, r);
    for (int tries = 0; taken.contains(loot.slot) && tries < 40; tries++)
      loot = Gear.roll(zone, rarity, r);
    taken.add(loot.slot);
    loot.dungeonRank = runLevel;
    // 0.8.5: +6 % per level up to level 31, then +2 % – loot no longer outgrows every enemy.
    double growth = 1 + .06 * Math.min(runLevel - 1, 30) + .02 * Math.max(0, runLevel - 31);
    loot.damage *= growth;
    loot.health *= growth;
    loot.defense *= growth;
    double utilityGrowth = 1 + .015 * Math.sqrt(runLevel - 1);
    loot.mining *= utilityGrowth;
    loot.yield *= utilityGrowth;
    loot.efficiency *= utilityGrowth;
    loot.name = "Gewölbe L" + runLevel + ": " + loot.name;
    p.discovered.add(loot.slot.name() + "/" + loot.rarity.name());
    if (p.gear.size() < 120) p.gear.add(loot);
    else p.dust += 40L * (rarity.ordinal() + 1);
    long coins = variant.coins(coins(zone, mode, runLevel));
    p.money = Math.addExact(p.money, coins);
    p.lifetimeRevenue = Math.addExact(p.lifetimeRevenue, coins);
    variant.bonus(p);
    p.dust += 20L + zone * 10L + mode * 20L;
    p.researchNotes += 3L + mode * 2L;
    p.monsterParts[zone] += 8L + mode * 4L;
    p.researchNotes += (runLevel - 1) / 5;
    p.dust += (runLevel - 1) * 2L;
    Healing.grant(p, 2);
    AdventureRewards.apply(p, run, zone, runLevel, optionalFlags);
    // One rune per win; higher dungeon levels find higher tiers. Own seed: other rolls stay equal.
    Runes.drop(
        p,
        Math.min(6, zone + runLevel / 10 + mode),
        new Random(run.getLeastSignificantBits() ^ UUID.fromString(p.id).getMostSignificantBits()));
    LootChests.offer(p, run, zone, mode, runLevel);
    p.dungeonLevel = Math.addExact(level(p), 1);
    p.zoneLevels[zone] = Math.addExact(level(p, zone), 1);
    int i = zone * 3 + mode;
    p.dungeonWins[i]++;
    Tutorial.advance(p);
    if (p.dungeonBestTicks[i] == 0 || ticks < p.dungeonBestTicks[i]) p.dungeonBestTicks[i] = ticks;
    p.dungeonReceipts.add(receipt);
    // Completed runs cannot be resumed; keep a bounded history across restarts.
    if (p.dungeonReceipts.size() > 256) p.dungeonReceipts.removeFirst();
    return true;
  }

  /** True while at least one of the dungeon's focus slots is still free for this party. */
  private static boolean focusable(DungeonVariant variant, Set<Gear.Slot> taken) {
    for (Gear.Slot slot : Gear.Slot.values())
      if (variant.focus(slot) && !taken.contains(slot)) return true;
    return false;
  }
}
