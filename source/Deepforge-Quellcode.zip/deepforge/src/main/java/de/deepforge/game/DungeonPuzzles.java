package de.deepforge.game;

import java.util.*;

/** Rules of the dungeon puzzles without any world code: generation, moves and solutions. */
public final class DungeonPuzzles {
  private DungeonPuzzles() {}

  /** Five lamps; every lever flips its lamp and both neighbours. All lamps lit = solved. */
  public static final class Levers {
    public static final int COUNT = 5;
    public final boolean[] lit = new boolean[COUNT];

    public Levers(Random r) {
      Arrays.fill(lit, true);
      // Scrambling with real lever pulls keeps the puzzle solvable.
      int pulls = 3 + r.nextInt(2);
      Set<Integer> chosen = new LinkedHashSet<>();
      while (chosen.size() < pulls) chosen.add(r.nextInt(COUNT));
      for (int i : chosen) pull(i);
      if (solved()) pull(COUNT / 2);
    }

    public void pull(int i) {
      for (int k = i - 1; k <= i + 1; k++) if (k >= 0 && k < COUNT) lit[k] = !lit[k];
    }

    public boolean solved() {
      for (boolean b : lit) if (!b) return false;
      return true;
    }
  }

  /**
   * A light beam enters a 5x5 grid from the west. Mirrors reflect it ('/' or '\'); it must leave
   * the grid at the crystal. Cells are (x, z) with z growing south.
   */
  public static final class Light {
    public static final int N = 5;
    public final int sourceZ;
    // Cell index (z * N + x) -> true for '/', false for '\'.
    public final Map<Integer, Boolean> mirrors = new LinkedHashMap<>();
    public final int targetX, targetZ;
    private final Map<Integer, Boolean> solution = new HashMap<>();

    public Light(Random r) {
      Light made = null;
      for (int attempt = 0; made == null; attempt++) made = attempt(r);
      sourceZ = made.sourceZ;
      targetX = made.targetX;
      targetZ = made.targetZ;
      mirrors.putAll(made.mirrors);
      solution.putAll(made.solution);
    }

    private Light(int sourceZ, int targetX, int targetZ) {
      this.sourceZ = sourceZ;
      this.targetX = targetX;
      this.targetZ = targetZ;
    }

    private static Light attempt(Random r) {
      int source = r.nextInt(N);
      int x = 0, z = source, dx = 1, dz = 0;
      Set<Integer> visited = new HashSet<>();
      Map<Integer, Boolean> path = new LinkedHashMap<>();
      int turns = 2 + r.nextInt(2);
      while (x >= 0 && x < N && z >= 0 && z < N) {
        int cell = z * N + x;
        if (!visited.add(cell)) return null;
        if (path.size() < turns && r.nextInt(3) == 0) {
          // Turn left or right when there is room to travel on.
          List<int[]> ways = new ArrayList<>();
          for (int[] d : new int[][] {{-dz, -dx}, {dz, dx}}) {
            int nx = x + d[0], nz = z + d[1];
            if (nx >= 0 && nx < N && nz >= 0 && nz < N && !visited.contains(nz * N + nx))
              ways.add(d);
          }
          if (!ways.isEmpty()) {
            int[] d = ways.get(r.nextInt(ways.size()));
            // '/' turns (dx,dz) into (-dz,-dx); '\' into (dz,dx).
            path.put(cell, d[0] == -dz && d[1] == -dx);
            dx = d[0];
            dz = d[1];
          }
        }
        x += dx;
        z += dz;
      }
      if (path.size() < 2) return null;
      Light l = new Light(source, x, z);
      l.solution.putAll(path);
      l.mirrors.putAll(path);
      List<Integer> free = new ArrayList<>();
      for (int c = 0; c < N * N; c++) if (!visited.contains(c)) free.add(c);
      Collections.shuffle(free, r);
      for (int i = 0; i < Math.min(2, free.size()); i++) l.mirrors.put(free.get(i), r.nextBoolean());
      for (int c : new ArrayList<>(l.mirrors.keySet())) l.mirrors.put(c, r.nextBoolean());
      if (l.solved()) {
        int first = path.keySet().iterator().next();
        l.mirrors.put(first, !l.mirrors.get(first));
      }
      return l;
    }

    public void rotate(int cell) {
      mirrors.computeIfPresent(cell, (k, v) -> !v);
    }

    /** Cells the beam passes (inside the grid), then the exit position outside it. */
    public List<int[]> beam() {
      List<int[]> out = new ArrayList<>();
      int x = 0, z = sourceZ, dx = 1, dz = 0;
      for (int steps = 0; steps < 60 && x >= 0 && x < N && z >= 0 && z < N; steps++) {
        out.add(new int[] {x, z});
        Boolean slash = mirrors.get(z * N + x);
        if (slash != null) {
          int ndx = slash ? -dz : dz, ndz = slash ? -dx : dx;
          dx = ndx;
          dz = ndz;
        }
        x += dx;
        z += dz;
      }
      out.add(new int[] {x, z});
      return out;
    }

    public boolean solved() {
      int[] exit = beam().getLast();
      return exit[0] == targetX && exit[1] == targetZ;
    }

    public Map<Integer, Boolean> solution() {
      return Collections.unmodifiableMap(solution);
    }
  }

  /** Nine plates; the glowing one must be stepped on before its time runs out. */
  public static final class Plates {
    public final int[] order;
    public int step;
    public final int window;

    public Plates(Random r, int level) {
      order = new int[5 + Math.min(3, level / 8)];
      for (int i = 0; i < order.length; i++) {
        int next;
        do next = r.nextInt(9);
        while (i > 0 && next == order[i - 1]);
        order[i] = next;
      }
      window = Math.max(30, 70 - level);
    }

    public int current() {
      return order[step];
    }

    /** True when the whole run of plates is done. */
    public boolean stepOn(int plate) {
      if (plate != current()) return false;
      step++;
      return step >= order.length;
    }
  }

  /** Four bells; the melody must be played back in order. */
  public static final class Bells {
    public static final float[] PITCH = {.7f, .9f, 1.15f, 1.5f};
    public final int[] melody;
    public int step;

    public Bells(Random r, int level) {
      melody = new int[4 + Math.min(2, level / 10)];
      for (int i = 0; i < melody.length; i++) melody[i] = r.nextInt(PITCH.length);
    }

    /** 1 = right note, 2 = melody complete, 0 = wrong (starts over). */
    public int ring(int bell) {
      if (melody[step] != bell) {
        step = 0;
        return 0;
      }
      step++;
      return step >= melody.length ? 2 : 1;
    }
  }

  /** Five chests; one holds the key, the others are mimics. */
  public static final class Mimics {
    public static final int COUNT = 5;
    public final int key;
    public final boolean[] opened = new boolean[COUNT];

    public Mimics(Random r) {
      key = r.nextInt(COUNT);
    }
  }

  /** Trap corridor: stripes across the room, neighbours alternate so there is always a gap. */
  public static final class Traps {
    public static final int PERIOD = 50, WARN = 20, ACTIVE = 30;

    /** 0 safe, 1 warning, 2 active. */
    public static int state(int stripe, long tick) {
      long t = Math.floorMod(tick + stripe * (PERIOD / 2L), PERIOD);
      return t < WARN ? 0 : t < ACTIVE ? 1 : 2;
    }

    public static int stripes(int length) {
      return Math.max(2, (length - 8) / 4);
    }
  }
}
