package de.deepforge.world;

import java.util.*;

/** Reachable ground-level mining faces; paths never enter the boss arena or cut through rock. */
public final class WorkerRoutes {
  public record Site(MineBlueprint.Point ore, List<MineBlueprint.Point> path) {
    public MineBlueprint.Point stand() {
      return path.getLast();
    }
  }

  public static List<Site> sites(MineBlueprint b) {
    int start = MineBlueprint.index(0, 1, 35);
    Map<Integer, Integer> previous = new LinkedHashMap<>();
    ArrayDeque<Integer> queue = new ArrayDeque<>();
    previous.put(start, start);
    queue.add(start);
    while (!queue.isEmpty()) {
      int key = queue.remove();
      var at = MineBlueprint.point(key);
      for (int[] d : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
        int x = at.x() + d[0], z = at.z() + d[1];
        if (z > 75
            || !clear(b.at(x, 1, z))
            || !clear(b.at(x, 2, z))
            || b.at(x, 0, z).startsWith("water")
            || b.at(x, 0, z).startsWith("lava")
            || clear(b.at(x, 0, z))
            || b.at(x, 0, z).equals("outside")) continue;
        int next = MineBlueprint.index(x, 1, z);
        if (previous.putIfAbsent(next, key) == null) queue.add(next);
      }
    }
    List<Site> sites = new ArrayList<>();
    Set<Integer> used = new HashSet<>();
    for (var ore : b.ores()) {
      if (ore.h() < 1 || ore.h() > 3 || ore.z() < 43 || ore.z() > 72) continue;
      for (int[] d : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
        int x = ore.x() + d[0], z = ore.z() + d[1];
        if (!MineBlueprint.inside(x, 1, z)) continue;
        int key = MineBlueprint.index(x, 1, z);
        if (!previous.containsKey(key) || !used.add(key)) continue;
        List<MineBlueprint.Point> path = new ArrayList<>();
        int current = key;
        while (current != start) {
          path.add(MineBlueprint.point(current));
          current = previous.get(current);
        }
        path.add(MineBlueprint.point(start));
        Collections.reverse(path);
        sites.add(new Site(ore, List.copyOf(path)));
        break;
      }
    }
    if (sites.size() < 6) throw new IllegalStateException("Not enough accessible worker faces");
    return List.copyOf(sites);
  }

  private static boolean clear(String state) {
    return state.equals("air") || state.startsWith("rail[") || state.startsWith("cave_vines");
  }

  private WorkerRoutes() {}
}
