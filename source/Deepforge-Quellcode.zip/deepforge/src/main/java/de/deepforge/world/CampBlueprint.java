package de.deepforge.world;

import java.util.*;

/** Original, deterministic block architecture. Coordinates are relative to the owner's plot. */
public final class CampBlueprint {
  public record Station(String id, String title, int x, int z, String block) {}

  public static final List<Station> STATIONS =
      List.of(
          new Station("gear", "WERKBANK", -22, -8, "smithing_table"),
          new Station("storage", "LAGER", 22, -8, "barrel[facing=up]"),
          new Station("factory", "SCHMELZE", -23, 8, "blast_furnace[facing=north,lit=true]"),
          new Station("crew", "MANNSCHAFT", 23, 9, "bell[attachment=floor,facing=north]"),
          new Station("travel", "MINENAUFZUG", 0, 36, "lectern[facing=north]"),
          new Station("trade", "HANDEL", 0, -25, "cartography_table"),
          new Station("dungeon", "RUNENGEWÖLBE", 0, -52, "lectern[facing=south]"));
  private final LinkedHashMap<Integer, String> blocks = new LinkedHashMap<>();

  public Map<Integer, String> blocks() {
    return Collections.unmodifiableMap(blocks);
  }

  public static int key(int x, int y, int z) {
    return ((x + 128) << 18) | (y << 9) | (z + 128);
  }

  public static int x(int key) {
    return (key >>> 18) - 128;
  }

  public static int y(int key) {
    return (key >>> 9) & 511;
  }

  public static int z(int key) {
    return (key & 511) - 128;
  }

  public String at(int x, int y, int z) {
    return blocks.getOrDefault(key(x, y, z), "air");
  }

  private void put(int x, int y, int z, String state) {
    blocks.put(key(x, y, z), state);
  }

  private void box(int x1, int y1, int z1, int x2, int y2, int z2, String state) {
    for (int x = x1; x <= x2; x++)
      for (int z = z1; z <= z2; z++) for (int y = y1; y <= y2; y++) put(x, y, z, state);
  }

  private static int noise(int x, int z, int salt) {
    int h = x * 374761393 + z * 668265263 + salt * 1274126177;
    h = (h ^ (h >>> 13)) * 1274126177;
    return (h ^ (h >>> 16)) & Integer.MAX_VALUE;
  }

  private static String stone(int x, int z) {
    return switch (noise(x, z, 7) % 9) {
      case 0, 1 -> "mossy_cobblestone";
      case 2, 3 -> "andesite";
      case 4 -> "stone_bricks";
      default -> "cobblestone";
    };
  }

  public static CampBlueprint create() {
    CampBlueprint b = new CampBlueprint();
    b.terrain();
    b.roads();
    b.architecture();
    b.village();
    b.landscape();
    b.entrance();
    for (Station s : STATIONS) {
      b.box(s.x - 1, 200, s.z - 1, s.x + 1, 200, s.z + 1, "polished_andesite");
      b.put(s.x, 201, s.z, s.block);
    }
    return b;
  }

  public static CampBlueprint dungeonEntrance() {
    CampBlueprint b = new CampBlueprint();
    b.entrance();
    return b;
  }

  private void entrance() {
    // An additive surface migration, independent of the existing houses and underground mines.
    box(-13, 201, -67, 13, 230, -43, "air");
    box(-3, 201, -43, 3, 205, -36, "air");
    path(new double[][] {{0, -36}, {0, -46}, {0, -52}}, 2.4);
    box(-12, 200, -66, 12, 200, -44, "stone_bricks");
    box(-8, 201, -63, 8, 211, -55, "deepslate_bricks");
    box(-6, 201, -62, 6, 209, -55, "air");
    box(-8, 212, -64, 8, 212, -54, "deepslate_tile_slab");
    box(-7, 213, -63, 7, 213, -55, "waxed_oxidized_cut_copper_slab");
    for (int x = -9; x <= 9; x++) {
      int roof = 212 + 9 - Math.abs(x);
      for (int z = -65; z <= -53; z++) {
        if (z == -64 || z == -54) box(x, 211, z, x, roof - 1, z, "deepslate_tiles");
        put(
            x,
            roof,
            z,
            x == 0
                ? "waxed_oxidized_cut_copper_slab"
                : "waxed_oxidized_cut_copper_stairs[facing=" + (x < 0 ? "east" : "west") + "]");
      }
    }
    box(-1, 213, -54, 1, 216, -54, "purple_stained_glass");
    box(-1, 213, -55, 1, 216, -55, "sea_lantern");
    for (int x : new int[] {-8, -4, 4, 8}) {
      box(x, 201, -55, x, 210, -54, "polished_basalt");
      put(x, 211, -54, "chiseled_deepslate");
      put(x, 203, -53, "soul_lantern");
    }
    box(-3, 208, -55, 3, 209, -54, "chiseled_stone_bricks");
    box(-2, 210, -55, 2, 210, -54, "amethyst_block");
    box(-3, 202, -62, 3, 208, -62, "tinted_glass");
    box(-3, 202, -63, 3, 208, -63, "sea_lantern");
    box(-2, 203, -62, 2, 207, -62, "purple_stained_glass");
    for (int z = -65; z <= -45; z += 5)
      for (int x : new int[] {-11, 11}) {
        box(x, 201, z, x, 202, z, "mossy_stone_brick_wall");
        put(x, 203, z, "soul_lantern");
      }
    for (int z = -61; z <= -45; z++)
      for (int x = -1; x <= 1; x++) put(x, 200, z, "polished_blackstone");
    for (int x : new int[] {-6, 6}) {
      box(x - 1, 201, -49, x + 1, 201, -48, "dark_oak_slab");
      put(x, 201, -58, "barrel");
      put(x, 202, -58, "flower_pot");
    }
    put(0, 201, -52, "lectern[facing=south]");
  }

  private int ground(int x, int z) {
    double edge = Math.max(Math.abs(x) / 82.0, Math.abs(z - 8) / 94.0);
    double ridge = Math.max(0, (z - 47) / 48.0);
    double west = Math.max(0, (-x - 56) / 28.0);
    double east = Math.max(0, (x - 48) / 36.0);
    return 200
        + (int)
            (ridge * (12 + 11 * Math.pow(Math.sin(x * .057 + 1.2), 2))
                + west * (8 + 9 * Math.pow(Math.cos(z * .069), 2))
                + east * (6 + 10 * Math.pow(Math.sin(z * .063), 2))
                + Math.max(0, edge - .88) * 9);
  }

  private void terrain() {
    // Replace the old camp surface only. Underground ore rooms and all player data survive.
    box(-29, 201, -29, 29, 208, 29, "air");
    for (int x = -86; x <= 86; x++)
      for (int z = -80; z <= 102; z++) {
        int y = ground(x, z);
        int bottom = 192 + (noise(x, z, 2) % 3);
        for (int h = bottom; h <= y; h++) {
          String material = h == y ? "grass_block" : h >= y - 2 ? "dirt" : stone(x + h, z);
          if (y > 213 && h >= y - 2 && noise(x, z, 9) % 5 != 0) material = stone(x + h, z);
          put(x, h, z, material);
        }
        // Irregular exposed rock below the island rim, hiding the former paper-thin platform.
        if (Math.abs(x) > 83 || z < -77 || z > 99)
          for (int h = 188 + noise(x, z, 4) % 6; h < bottom; h++) put(x, h, z, "stone");
      }
    // A shallow stream with fixed banks. Bridges below provide dry routes across it.
    for (int z = -51; z <= 51; z++) {
      int cx = -43 + (int) Math.round(3 * Math.sin(z * .07));
      for (int x = cx - 2; x <= cx + 2; x++) {
        put(x, 198, z, noise(x, z, 2) % 2 == 0 ? "gravel" : "clay");
        put(x, 199, z, "water[level=0]");
        put(x, 200, z, "air");
      }
      put(cx - 3, 200, z, "mossy_cobblestone");
      put(cx + 3, 200, z, "mossy_cobblestone");
    }
  }

  private void path(double[][] points, double radius) {
    for (int i = 1; i < points.length; i++) {
      double ax = points[i - 1][0], az = points[i - 1][1], bx = points[i][0], bz = points[i][1];
      int steps = (int) Math.ceil(Math.hypot(bx - ax, bz - az) * 2);
      for (int n = 0; n <= steps; n++) {
        double cx = ax + (bx - ax) * n / Math.max(1, steps),
            cz = az + (bz - az) * n / Math.max(1, steps);
        for (int x = (int) Math.floor(cx - radius - 1); x <= cx + radius + 1; x++)
          for (int z = (int) Math.floor(cz - radius - 1); z <= cz + radius + 1; z++) {
            double d = Math.hypot(x - cx, z - cz);
            if (d <= radius + (noise(x, z, 3) % 4) * .13) {
              put(
                  x,
                  200,
                  z,
                  switch (noise(x, z, 19) % 12) {
                    case 0, 1 -> "gravel";
                    case 2 -> "coarse_dirt";
                    case 3, 4 -> "cobblestone";
                    case 5 -> "mossy_cobblestone";
                    default -> "andesite";
                  });
            } else if (d <= radius + .8
                && at(x, 200, z).equals("grass_block")
                && noise(x, z, 2) % 3 == 0) put(x, 200, z, "mossy_stone_bricks");
          }
      }
    }
  }

  private void roads() {
    for (int x = -10; x <= 10; x++)
      for (int z = -10; z <= 10; z++)
        if (x * x + z * z < 105)
          put(x, 200, z, (x * x + z * z > 80) ? "stone_bricks" : stone(x, z));
    path(new double[][] {{0, -36}, {-2, -20}, {0, -8}, {0, 7}, {-2, 19}, {0, 38}}, 2.4);
    path(
        new double[][] {{-36, -6}, {-22, -6}, {-10, -3}, {0, 0}, {12, -4}, {23, -6}, {39, -4}},
        2.2);
    path(new double[][] {{-32, 9}, {-22, 6}, {-11, 7}, {-2, 16}, {10, 9}, {23, 7}, {39, 10}}, 2.1);
    path(new double[][] {{-22, -6}, {-36, -8}, {-44, -13}, {-55, -18}}, 1.7);
    path(
        new double[][] {
          {23, -6}, {38, -5}, {40, -16}, {38, -32}, {21, -35}, {2, -36}, {-16, -36}, {-35, -32},
          {-36, -8}, {-35, 8}, {-36, 32}, {-20, 38}, {0, 38}, {20, 38}, {38, 32}, {39, 10}
        },
        1.6);
    path(new double[][] {{-10, 7}, {-10, 19}, {-9, 26}, {-3, 30}}, 1.8);
    for (int x = -51; x <= -38; x++) {
      box(x, 200, -15, x, 200, -11, "spruce_planks");
      for (int z : new int[] {-15, -11}) put(x, 201, z, "spruce_fence[east=true,west=true]");
      if (x % 4 == 0)
        for (int z : new int[] {-15, -11}) {
          box(x, 198, z, x, 201, z, "stripped_spruce_log");
          put(x, 202, z, "lantern");
        }
    }
  }

  private void house(
      int x1, int z1, int x2, int z2, boolean north, String plaster, String roof, boolean loft) {
    box(x1 - 1, 200, z1 - 1, x2 + 1, 200, z2 + 1, "stone_bricks");
    box(x1, 201, z1, x2, 218, z2, "air");
    box(x1 + 1, 200, z1 + 1, x2 - 1, 200, z2 - 1, "spruce_planks");
    int eave = loft ? 209 : 207, mid = (x1 + x2) / 2;
    for (int x = x1; x <= x2; x++)
      for (int z = z1; z <= z2; z++) {
        if (x != x1 && x != x2 && z != z1 && z != z2) continue;
        for (int y = 201; y <= eave; y++) {
          boolean post =
              (x == x1 || x == x2) ? (z - z1) % 4 == 0 || z == z2 : (x - x1) % 4 == 0 || x == x2;
          String mat =
              y == 201
                  ? stone(x, z)
                  : post
                      ? "stripped_spruce_log"
                      : y == 205 || y == eave ? "dark_oak_wood" : plaster;
          if (!post && (y == 203 || (loft && y == 207))) mat = "glass";
          put(x, y, z, mat);
        }
      }
    if (loft) {
      box(x1 + 1, 205, z1 + 1, x2 - 1, 205, z2 - 1, "spruce_planks");
      for (int i = 0; i < 5; i++) {
        int zz = z1 + 2 + i;
        box(x1 + 1, 201, zz, x1 + 2, 201 + i, zz, "spruce_planks");
        for (int xx = x1 + 1; xx <= x1 + 2; xx++)
          put(xx, 201 + i, zz, "spruce_stairs[facing=south]");
        box(x1 + 1, 202 + i, zz, x1 + 2, 208, zz, "air");
      }
      for (int z = z1 + 2; z <= z1 + 6; z++)
        put(x1 + 3, 206, z, "spruce_fence[north=true,south=true]");
      box(x1 + 1, 206, z1 + 7, x1 + 2, 208, z1 + 8, "air");
    }
    // Full projecting gable roof: paired correctly oriented stair slopes and ridge caps.
    for (int x = x1 - 1; x <= x2 + 1; x++) {
      int rise = Math.min(x - (x1 - 1), (x2 + 1) - x), y = eave + 1 + rise;
      String facing = x < mid ? "east" : "west";
      for (int z = z1 - 2; z <= z2 + 2; z++) {
        put(x, y, z, x == mid ? roof + "_slab" : roof + "_stairs[facing=" + facing + "]");
        if (z == z1 - 2 || z == z2 + 2)
          put(x, y - 1, z, "dark_oak_stairs[facing=" + facing + ",half=top]");
      }
      if (x >= x1 && x <= x2)
        for (int z : new int[] {z1, z2})
          for (int yy = eave + 1; yy < y; yy++)
            put(x, yy, z, x == mid ? "stripped_spruce_log" : plaster);
    }
    for (int z : new int[] {z1, z2}) {
      box(mid - 1, eave + 1, z, mid + 1, eave + 3, z, "glass");
      box(mid, eave + 1, z, mid, eave + 3, z, "stripped_spruce_log");
      put(mid, eave + 4, z, "dark_oak_wood");
    }
    int front = north ? z1 : z2, dir = north ? -1 : 1;
    box(mid - 1, 201, front, mid + 1, 203, front, "air");
    box(mid - 2, 204, front + dir, mid + 2, 204, front + dir, "dark_oak_log[axis=x]");
    for (int x : new int[] {mid - 3, mid + 3}) {
      box(x, 201, front + dir * 3, x, 204, front + dir * 3, "stripped_spruce_log");
      put(x, 203, front + dir * 2, "lantern[hanging=true]");
    }
    for (int x = mid - 4; x <= mid + 4; x++)
      for (int d = 1; d <= 4; d++)
        put(
            x,
            206 - d / 2,
            front + dir * d,
            roof + "_stairs[facing=" + (north ? "south" : "north") + "]");
    // Shutters and flower boxes make the facade read at both street and close-up distance.
    for (int x : new int[] {x1 + 2, x2 - 2}) {
      put(
          x,
          202,
          front + dir,
          "spruce_trapdoor[facing=" + (north ? "north" : "south") + ",open=true]");
      put(x, 203, front + dir, "potted_fern");
      put(
          x - 1,
          203,
          front + dir,
          "dark_oak_trapdoor[facing=" + (north ? "north" : "south") + ",open=true]");
    }
    for (int z = z1 + 3; z < z2; z += 5) {
      put(mid, 204, z, "lantern[hanging=true]");
      if (loft) put(mid, 208, z, "lantern[hanging=true]");
    }
  }

  private void architecture() {
    house(-31, -28, -15, -13, false, "calcite", "deepslate_tile", true);
    house(15, -29, 31, -13, false, "spruce_planks", "dark_oak", true);
    house(-32, 13, -16, 29, true, "stone_bricks", "waxed_weathered_cut_copper", false);
    house(15, 14, 31, 30, true, "smooth_sandstone", "spruce", true);
    dormer(-15, -21, "calcite", "deepslate_tile");
    dormer(31, 22, "smooth_sandstone", "spruce");
    smithy();
    warehouse();
    foundry();
    lodge();
    market();
    headframe();
    // 0.17.0: the old well gave way to the fountain on the square (see plaza()).
    cart(35, -23);
    for (int[] p :
        new int[][] {
          {-10, -13},
          {10, -14},
          {-10, 12},
          {10, 14},
          {-5, 26},
          {7, 29},
          {-34, -4},
          {35, -5},
          {-34, 33},
          {34, 34},
          {-5, -35},
          {7, -35}
        }) lamp(p[0], p[1]);
    for (int z = -20; z <= -14; z += 3) {
      put(-12, 201, z, "barrel[facing=up]");
      put(-12, 202, z, "potted_azalea_bush");
    }
  }

  private void chimney(int x, int z, int top) {
    box(x, 201, z, x + 2, top, z + 2, "bricks");
    box(x + 1, 204, z + 1, x + 1, top, z + 1, "air");
    box(x - 1, top - 1, z - 1, x + 3, top - 1, z + 3, "brick_slab[type=top]");
    put(x + 1, top, z + 1, "campfire[lit=true]");
    for (int xx = x; xx <= x + 2; xx++)
      for (int zz = z; zz <= z + 2; zz++) put(xx, top + 2, zz, "brick_slab");
  }

  private void dormer(int wallX, int centerZ, String plaster, String roof) {
    // Projecting window bay breaks the long roof plane; the room opens into the loft.
    box(wallX - 3, 210, centerZ - 2, wallX, 214, centerZ + 2, plaster);
    box(wallX - 3, 210, centerZ - 1, wallX - 1, 214, centerZ + 1, "air");
    box(wallX, 212, centerZ - 1, wallX, 213, centerZ + 1, "glass");
    for (int z : new int[] {centerZ - 2, centerZ + 2})
      box(wallX, 210, z, wallX, 214, z, "stripped_spruce_log");
    box(wallX, 214, centerZ - 2, wallX, 214, centerZ + 2, "dark_oak_log[axis=z]");
    for (int z = centerZ - 3; z <= centerZ + 3; z++) {
      int y = 215 + 3 - Math.abs(z - centerZ);
      for (int x = wallX - 4; x <= wallX + 1; x++)
        put(
            x,
            y,
            z,
            z == centerZ
                ? roof + "_slab"
                : roof + "_stairs[facing=" + (z < centerZ ? "south" : "north") + "]");
      if (Math.abs(z - centerZ) < 3)
        box(wallX, 215, z, wallX, y - 1, z, z == centerZ ? "stripped_spruce_log" : plaster);
    }
  }

  private void smithy() {
    chimney(-30, -25, 220);
    // Open forge lean-to, visible from the main square.
    box(-33, 200, -10, -16, 200, -5, "cobbled_deepslate");
    for (int x : new int[] {-33, -16}) box(x, 201, -6, x, 205, -6, "stripped_spruce_log");
    for (int x = -34; x <= -15; x++)
      for (int z = -11; z <= -5; z++) put(x, 206 + (z < -8 ? 1 : 0), z, "deepslate_tile_slab");
    box(-31, 201, -11, -27, 203, -9, "stone_bricks");
    box(-30, 201, -9, -28, 202, -9, "air");
    for (int x = -30; x <= -28; x++) {
      put(x, 201, -10, "magma_block");
      put(x, 202, -10, "campfire[lit=true]");
    }
    box(-30, 204, -10, -28, 204, -9, "polished_blackstone_bricks");
    put(-26, 201, -7, "anvil[facing=east]");
    put(-29, 201, -6, "grindstone[face=floor,facing=south]");
    put(-18, 201, -7, "water_cauldron[level=3]");
    box(-26, 201, -25, -24, 201, -24, "smithing_table");
    for (int x = -25; x <= -19; x += 2) put(x, 201, -26, "barrel[facing=south]");
    put(-18, 201, -23, "anvil");
    put(-17, 201, -17, "crafting_table");
    for (int x = -27; x <= -19; x += 4) {
      put(x, 206, -25, "barrel");
      put(x, 207, -25, "potted_dead_bush");
    }
  }

  private void warehouse() {
    for (int x = 24; x <= 29; x += 2)
      for (int z = -26; z <= -17; z += 3) {
        box(x, 201, z, x + 1, 202, z + 1, "barrel[facing=south]");
        if (z % 2 == 0) put(x, 203, z, "hay_block");
      }
    box(19, 206, -26, 25, 207, -24, "hay_block");
    for (int z = -24; z <= -17; z += 3) put(29, 206, z, "barrel[facing=west]");
    box(18, 200, -12, 30, 200, -7, "spruce_planks");
    for (int x : new int[] {18, 30}) {
      box(x, 201, -9, x, 204, -9, "stripped_spruce_log");
      put(x, 205, -9, "lantern");
    }
    // Timber crane with iron pivot, braced boom, chain and suspended crate.
    box(36, 200, -14, 38, 200, -12, "stone_bricks");
    box(37, 201, -13, 37, 211, -13, "dark_oak_log");
    box(31, 210, -13, 40, 210, -13, "dark_oak_log[axis=x]");
    put(37, 209, -13, "iron_block");
    for (int i = 1; i <= 4; i++) put(37 - i, 210 - i, -13, "dark_oak_stairs[facing=west]");
    box(31, 205, -13, 31, 209, -13, "chain[axis=y]");
    put(31, 204, -13, "barrel[facing=up]");
  }

  private void foundry() {
    chimney(-31, 25, 223);
    chimney(-18, 25, 217);
    box(-29, 201, 24, -20, 203, 26, "polished_deepslate");
    for (int x = -28; x <= -20; x += 2) {
      put(x, 201, 23, "blast_furnace[facing=north,lit=true]");
      put(x, 202, 24, "magma_block");
    }
    box(-28, 201, 16, -27, 201, 20, "polished_andesite");
    put(-28, 202, 17, "anvil");
    put(-28, 202, 20, "stonecutter[facing=east]");
    box(-31, 201, 10, -28, 202, 11, "coal_block");
    for (int x = -31; x <= -28; x++) put(x, 203, 10, "blackstone_slab");
    put(-18, 201, 9, "water_cauldron[level=3]");
    // Workers mine a rock face overlooking the southern path.
    for (int x = -12; x <= -6; x++)
      for (int z = 23; z <= 26; z++)
        for (int y = 201; y <= 203 + noise(x, z, 6) % 3; y++)
          put(x, y, z, noise(x + y, z, 8) % 4 == 0 ? "iron_ore" : stone(x + y, z));
    for (int x = -12; x <= -6; x++) put(x, 201, 23, "iron_ore");
    for (int z = 13; z <= 25; z++) put(-14, 201, z, "rail[shape=north_south]");
    box(-15, 200, 13, -13, 200, 25, "gravel");
    put(-14, 202, 17, "chest[facing=east]");
  }

  private void lodge() {
    box(21, 201, 21, 26, 201, 22, "spruce_fence[east=true,west=true]");
    box(21, 202, 21, 26, 202, 22, "spruce_pressure_plate");
    for (int x = 21; x <= 26; x += 2) {
      put(x, 201, 20, "spruce_stairs[facing=south]");
      put(x, 201, 23, "spruce_stairs[facing=north]");
    }
    box(28, 201, 25, 30, 202, 28, "bookshelf");
    put(28, 203, 25, "potted_fern");
    for (int x = 20; x <= 28; x += 3) {
      put(x, 206, 26, "red_bed[facing=south,part=foot]");
      put(x, 206, 27, "red_bed[facing=south,part=head]");
      put(x, 206, 24, "barrel[facing=up]");
    }
    // Upper balcony, framed with hand-connected railings.
    box(20, 205, 11, 28, 205, 13, "spruce_planks");
    for (int x = 20; x <= 28; x++) put(x, 206, 11, "spruce_fence[east=true,west=true]");
    box(22, 206, 14, 24, 208, 14, "air");
    for (int x : new int[] {20, 28}) box(x, 201, 11, x, 205, 11, "stripped_spruce_log");
    put(18, 201, 17, "smoker[facing=south,lit=true]");
    put(19, 201, 17, "barrel");
    put(19, 202, 17, "potted_red_tulip");
    for (int x = 18; x <= 28; x++) put(x, 201, 32, "oak_leaves[persistent=true]");
  }

  private void market() {
    for (int cx : new int[] {-6, 6}) {
      box(cx - 3, 200, -30, cx + 3, 200, -24, "spruce_planks");
      for (int x : new int[] {cx - 3, cx + 3})
        for (int z : new int[] {-30, -24})
          box(x, 201, z, x, 204, z, "spruce_fence[north=true,south=true]");
      for (int x = cx - 4; x <= cx + 4; x++)
        for (int z = -31; z <= -23; z++)
          put(x, 205 + (z < -28 ? 1 : 0), z, (x % 2 == 0 ? "white" : "orange") + "_wool");
      box(cx - 2, 201, -25, cx + 2, 201, -25, "barrel[facing=south]");
      put(cx - 2, 202, -25, "melon");
      put(cx, 202, -25, "potted_fern");
      put(cx + 2, 202, -25, "pumpkin");
      put(cx, 204, -27, "lantern[hanging=true]");
      box(cx - 2, 201, -29, cx + 2, 202, -29, "bookshelf");
    }
    box(-2, 200, -30, 2, 200, -23, "stone_bricks");
  }

  private void headframe() {
    // Heavy stone gate and timber headframe, the village's main silhouette.
    box(-9, 200, 32, 9, 200, 46, "stone_bricks");
    for (int x : new int[] {-7, 7})
      for (int z : new int[] {34, 44}) {
        box(x - 1, 201, z - 1, x + 1, 204, z + 1, "deepslate_bricks");
        box(x, 205, z, x, 224, z, "dark_oak_log");
        for (int y : new int[] {208, 214, 221}) put(x, y, z, "iron_block");
      }
    for (int y : new int[] {210, 217, 223}) {
      box(-7, y, 34, 7, y, 34, "dark_oak_log[axis=x]");
      box(-7, y, 44, 7, y, 44, "dark_oak_log[axis=x]");
      box(-7, y, 34, -7, y, 44, "dark_oak_log[axis=z]");
      box(7, y, 34, 7, y, 44, "dark_oak_log[axis=z]");
    }
    for (int i = 0; i < 6; i++)
      for (int x : new int[] {-7, 7}) put(x, 211 + i, 35 + i, "stripped_spruce_wood");
    for (int x = -9; x <= 9; x++)
      for (int z = 32; z <= 46; z++)
        put(
            x,
            225 + (9 - Math.abs(x)) / 2,
            z,
            "deepslate_tile_stairs[facing=" + (x < 0 ? "east" : "west") + "]");
    // Hoist wheel as an eight-sided ring, with spokes and a gold axle.
    for (int x = -4; x <= 4; x++)
      for (int y = 215; y <= 223; y++) {
        int d = x * x + (y - 219) * (y - 219);
        if (d >= 10 && d <= 20) put(x, y, 33, "polished_blackstone");
        else if (x == 0 || y == 219) put(x, y, 33, "dark_oak_wood");
      }
    put(0, 219, 32, "gold_block");
    box(-2, 207, 40, -2, 222, 40, "chain[axis=y]");
    box(2, 207, 40, 2, 222, 40, "chain[axis=y]");
    box(-4, 201, 38, 4, 201, 43, "dark_oak_slab[type=top]");
    // Surface lift remains decorative; the lectern opens the real zone selector.
    for (int x = -4; x <= 4; x++) put(x, 202, 43, "iron_bars[east=true,west=true]");
    for (int x : new int[] {-4, 4})
      for (int z = 38; z <= 43; z++) put(x, 202, z, "iron_bars[north=true,south=true]");
    for (int x : new int[] {-5, 5}) put(x, 209, 34, "lantern[hanging=true]");
    for (int x = -5; x <= 5; x++)
      for (int z = 45; z <= 49; z++)
        for (int y = 201; y <= 205 + noise(x, z, 7) % 3; y++) put(x, y, z, stone(x + y, z));
    box(-2, 201, 44, 2, 204, 47, "air");
    box(-2, 204, 46, 2, 204, 46, "dark_oak_log[axis=x]");
    box(-2, 201, 48, 2, 203, 48, "deepslate_bricks");
  }

  private void cart(int x, int z) {
    box(x - 1, 201, z - 2, x + 1, 201, z + 2, "spruce_slab[type=top]");
    box(x - 1, 202, z - 2, x + 1, 202, z + 2, "hay_block");
    for (int xx : new int[] {x - 2, x + 2})
      for (int zz : new int[] {z - 2, z + 2}) put(xx, 201, zz, "dark_oak_log[axis=x]");
    box(x, 201, z + 3, x, 201, z + 5, "spruce_fence[north=true,south=true]");
  }

  private void lamp(int x, int z) {
    put(x, 201, z, "stone_bricks");
    box(x, 202, z, x, 204, z, "spruce_fence[north=true,south=true]");
    box(x, 205, z, x + 1, 205, z, "dark_oak_log[axis=x]");
    put(x + 1, 204, z, "lantern[hanging=true]");
    put(x, 206, z, "dark_oak_slab");
  }

  private void pine(int x, int z, int height) {
    int floor = ground(x, z);
    box(x, floor + 1, z, x, floor + height, z, "spruce_log");
    for (int h = 3; h <= height + 1; h++) {
      int r = Math.max(0, (height - h + 2) / 3);
      if (h % 2 == 0) r = Math.max(0, r - 1);
      for (int dx = -r; dx <= r; dx++)
        for (int dz = -r; dz <= r; dz++)
          if ((dx != 0 || dz != 0 || h > height) && Math.abs(dx) + Math.abs(dz) <= r + 1)
            put(x + dx, floor + h, z + dz, "spruce_leaves[persistent=true]");
    }
  }

  private void landscape() {
    for (int x = -76; x <= 76; x += 9)
      for (int z = -69; z <= 91; z += 10) {
        int xx = x + noise(x, z, 3) % 5, zz = z + noise(x, z, 5) % 5;
        if ((Math.abs(xx) > 49 || zz < -43 || zz > 55) && noise(x, z, 8) % 4 != 0 && !cleared(xx, zz))
          pine(xx, zz, 9 + noise(x, z, 9) % 8);
      }
    for (int[] p :
        new int[][] {{-36, -36}, {36, -37}, {-38, 36}, {38, 38}, {13, 36}, {-17, 37}, {-36, 19}})
      pine(p[0], p[1], 10);
    for (int x = -78; x <= 78; x++)
      for (int z = -73; z <= 96; z++) {
        int y = ground(x, z);
        if (!at(x, y, z).equals("grass_block") || !at(x, y + 1, z).equals("air")) continue;
        int n = noise(x, z, 31) % 95;
        if (n < 5) put(x, y + 1, z, "short_grass");
        else if (n == 6) put(x, y + 1, z, "fern");
        else if (n == 7) put(x, y + 1, z, "poppy");
        else if (n == 8) put(x, y + 1, z, "azure_bluet");
        else if (n == 9 && (Math.abs(x) > 40 || z > 52 || z < -39))
          put(x, y + 1, z, "mossy_cobblestone_slab");
      }
    // Log piles, garden planters, bushes and lit entrance markers around the actual buildings.
    box(-35, 201, -26, -34, 201, -19, "spruce_log[axis=z]");
    box(-35, 202, -25, -35, 202, -20, "spruce_log[axis=z]");
    for (int cx : new int[] {-12, 12})
      for (int cz : new int[] {-17, 18}) {
        box(cx - 1, 200, cz - 1, cx + 1, 200, cz + 1, "mossy_stone_bricks");
        put(cx, 201, cz, "azalea_leaves[persistent=true]");
        put(cx - 1, 201, cz, "flowering_azalea");
        put(cx + 1, 201, cz, "azalea");
      }
    for (int z = -8; z <= 5; z++)
      for (int x : new int[] {-37, 38})
        if (z % 4 != 0) put(x, 201, z, "spruce_fence[north=true,south=true]");
  }

  // ---- 0.17.0: a real village around the camp ----
  // Clearings the forest keeps free: the cottage lane (south-east) and the fields (south-west).
  private static final int[][] CLEARINGS = {{12, -78, 50, -38}, {-58, -78, -15, -38}, {-62, -50, -36, -32}};

  private static boolean cleared(int x, int z) {
    for (int[] c : CLEARINGS) if (x >= c[0] - 4 && x <= c[2] + 4 && z >= c[1] - 4 && z <= c[3] + 4) return true;
    return false;
  }

  private void village() {
    // Existing camps are rebuilt in place: old pines in the new clearings must go.
    for (int[] c : CLEARINGS)
      for (int x = c[0]; x <= c[2]; x++)
        for (int z = c[1]; z <= c[3]; z++) box(x, ground(x, z) + 1, z, x, 232, z, "air");
    plaza();
    // Cottage lane: a gently curving gravel street with houses on both sides.
    path(new double[][] {{21, -35}, {25, -44}, {26, -54}, {24, -64}, {26, -74}}, 1.9);
    String[][] styles = {
      {"spruce_planks", "calcite", "spruce", "dark_oak"},
      {"cobblestone", "white_terracotta", "dark_oak", "spruce"},
      {"stone_bricks", "spruce_planks", "deepslate_tile", "dark_oak"},
      {"mud_bricks", "birch_planks", "spruce", "stripped_birch"},
      {"cobblestone", "stripped_oak_wood", "mangrove", "dark_oak"},
      {"bricks", "calcite", "deepslate_tile", "spruce"}
    };
    // West side: fronts on the lane, backs towards the vault gate (no garden there).
    int[][] lots = {{20, -52, 1}, {20, -63, 1}, {20, -74, 1}, {30, -46, 3}, {30, -57, 3}, {30, -68, 3}};
    for (int i = 0; i < lots.length; i++) cottage(lots[i][0], lots[i][1], lots[i][2], styles[i], i, lots[i][2] == 3);
    for (int[] p : new int[][] {{22, -40}, {28, -50}, {22, -60}, {28, -70}}) lamp(p[0], p[1]);
    // Fields by the stream: wheat, carrots and potatoes, watered by channels, with a barn.
    field(-37, -66, -28, -48, "wheat[age=7]");
    field(-26, -66, -19, -55, "carrots[age=7]");
    field(-26, -52, -19, -44, "potatoes[age=7]");
    barn(-36, -77);
    path(new double[][] {{-16, -36}, {-17, -50}, {-23, -70}, {-30, -73}}, 1.5);
    watermill(-44, -44);
    cart(-15, -60);
    for (int[] p : new int[][] {{-17, -42}, {-18, -62}}) lamp(p[0], p[1]);
  }

  /** The village square: patterned paving, a fountain, benches, flower beds and a notice board. */
  private void plaza() {
    for (int x = -10; x <= 10; x++)
      for (int z = -10; z <= 10; z++) {
        int d = x * x + z * z;
        if (d >= 105) continue;
        String paving =
            d > 80 ? "stone_bricks" : d > 64 ? "polished_andesite" : (x + z) % 2 == 0 ? "stone_bricks" : "polished_andesite";
        if (Math.abs(x) == Math.abs(z) && d < 64) paving = "chiseled_stone_bricks";
        put(x, 200, z, paving);
      }
    // Fountain north of the spawn, which stays free at (0, -6).
    int fx = 0, fz = 3;
    for (int x = fx - 3; x <= fx + 3; x++)
      for (int z = fz - 3; z <= fz + 3; z++) {
        int d = Math.max(Math.abs(x - fx), Math.abs(z - fz));
        if (d == 3) put(x, 201, z, "stone_brick_wall");
        else if (d <= 2) {
          put(x, 200, z, "water[level=0]");
          put(x, 199, z, "stone_bricks");
        }
      }
    box(fx, 200, fz, fx, 203, fz, "stone_bricks");
    put(fx, 204, fz, "chiseled_stone_bricks");
    put(fx, 205, fz, "water[level=0]");
    for (int[] d : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) put(fx + d[0], 203, fz + d[1], "stone_brick_slab");
    // Benches facing the fountain and flower beds between them.
    for (int[] b : new int[][] {{-6, 3, 0}, {6, 3, 1}, {0, 9, 2}})
      for (int i = -1; i <= 1; i++) {
        int x = b[2] == 2 ? b[0] + i : b[0], z = b[2] == 2 ? b[1] : b[1] + i;
        put(x, 201, z, "spruce_stairs[facing=" + (b[2] == 0 ? "west" : b[2] == 1 ? "east" : "south") + "]");
      }
    for (int[] f : new int[][] {{-6, -2}, {6, -2}, {-5, 8}, {5, 8}}) {
      put(f[0], 200, f[1], "rooted_dirt");
      put(f[0], 201, f[1], noise(f[0], f[1], 23) % 2 == 0 ? "rose_bush[half=lower]" : "lilac[half=lower]");
      put(f[0], 202, f[1], noise(f[0], f[1], 23) % 2 == 0 ? "rose_bush[half=upper]" : "lilac[half=upper]");
    }
    // Notice board (quests and news), lamp posts at the corners of the square.
    box(-9, 201, -3, -9, 203, -3, "spruce_fence[north=true,south=true]");
    box(-9, 201, 1, -9, 203, 1, "spruce_fence[north=true,south=true]");
    box(-9, 204, -3, -9, 204, 1, "spruce_slab");
    for (int z = -2; z <= 0; z++) put(-9, 203, z, "spruce_trapdoor[facing=east,open=true]");
    for (int[] l : new int[][] {{-8, -8}, {8, -8}, {-8, 8}, {8, 8}}) lamp(l[0], l[1]);
  }

  // Local building frame: front faces local north (v = 0); r turns it clockwise by 90°.
  private void lput(int ox, int oz, int r, int u, int y, int v, String state) {
    int x, z;
    switch (r) {
      case 1 -> { x = -v; z = u; }
      case 2 -> { x = -u; z = -v; }
      case 3 -> { x = v; z = -u; }
      default -> { x = u; z = v; }
    }
    put(ox + x, y, oz + z, turn(state, r));
  }

  private void lbox(int ox, int oz, int r, int u1, int y1, int v1, int u2, int y2, int v2, String state) {
    for (int u = Math.min(u1, u2); u <= Math.max(u1, u2); u++)
      for (int v = Math.min(v1, v2); v <= Math.max(v1, v2); v++)
        for (int y = y1; y <= y2; y++) lput(ox, oz, r, u, y, v, state);
  }

  private static final String[] COMPASS = {"north", "east", "south", "west"};

  /** Rotates facing=…, axis=… and the side flags of fences by r quarter turns. */
  static String turn(String state, int r) {
    if (r == 0 || !state.contains("[")) return state;
    String name = state.substring(0, state.indexOf('[')), props = state.substring(state.indexOf('[') + 1, state.length() - 1);
    List<String> out = new ArrayList<>();
    for (String kv : props.split(",")) {
      String[] p = kv.split("=");
      String k = p[0], v = p[1];
      int i = Arrays.asList(COMPASS).indexOf(v);
      if (k.equals("facing") && i >= 0) v = COMPASS[(i + r) % 4];
      else if (k.equals("axis") && r % 2 == 1 && !v.equals("y")) v = v.equals("x") ? "z" : "x";
      else {
        int j = Arrays.asList(COMPASS).indexOf(k);
        if (j >= 0) k = COMPASS[(j + r) % 4];
      }
      out.add(k + "=" + v);
    }
    out.sort(null);
    return name + "[" + String.join(",", out) + "]";
  }

  /**
   * A half-timbered cottage (7 wide, 9 deep): stone plinth, log frame, a jettied upper floor, a
   * steep gable roof with overhang, chimney, shutters, flower boxes, a door with lantern and a
   * fenced kitchen garden behind. style = {plinth, infill, roof wood, beams}.
   */
  private void cottage(int ox, int oz, int r, String[] style, int seed, boolean garden) {
    int W = 7, D = 9;
    String plinth = style[0], infill = style[1], roof = style[2], beam = style[3];
    String log = beam.startsWith("stripped") ? beam + "_log" : beam + "_log";
    if (beam.equals("stripped_birch")) log = "stripped_birch_log";
    // clear and found
    lbox(ox, oz, r, -2, 201, -3, W + 1, 216, garden ? D + 6 : D + 2, "air");
    lbox(ox, oz, r, -1, 200, -1, W, 200, D, "cobblestone");
    lbox(ox, oz, r, 0, 200, 0, W - 1, 200, D - 1, "spruce_planks");
    for (int u = 0; u < W; u++)
      for (int v = 0; v < D; v++) {
        boolean edgeU = u == 0 || u == W - 1, edgeV = v == 0 || v == D - 1;
        if (!edgeU && !edgeV) continue;
        boolean corner = edgeU && edgeV;
        // ground floor 201..204
        for (int y = 201; y <= 204; y++) {
          String m = y == 201 ? plinth : corner || (edgeV && u == W / 2) ? log : infill;
          if (!corner && y >= 202 && y <= 203 && (edgeU ? v % 3 == 1 : (u == 1 || u == W - 2))) m = "glass_pane[" + (edgeU ? "north=true,south=true" : "east=true,west=true") + "]";
          lput(ox, oz, r, u, y, v, m);
        }
      }
    // jettied upper floor 205..207, one block out at front and back
    lbox(ox, oz, r, 0, 205, -1, W - 1, 205, D, beam.equals("stripped_birch") ? "birch_planks" : "dark_oak_planks");
    for (int u = 0; u < W; u++)
      for (int v = -1; v <= D; v++) {
        boolean edgeU = u == 0 || u == W - 1, edgeV = v == -1 || v == D;
        if (!edgeU && !edgeV) continue;
        for (int y = 206; y <= 207; y++) {
          boolean post = (edgeU && (v == -1 || v == D || v == D / 2)) || (edgeV && (u == 0 || u == W - 1 || u == W / 2));
          String m = post ? log : infill;
          if (!post && y == 206 && (edgeV ? u != W / 2 : v % 3 == 1)) m = "glass_pane[" + (edgeU ? "north=true,south=true" : "east=true,west=true") + "]";
          lput(ox, oz, r, u, y, v, m);
        }
      }
    // braces under the jetty
    for (int u : new int[] {0, W - 1}) {
      lput(ox, oz, r, u, 204, -1, roof + "_stairs[facing=south,half=top]");
      lput(ox, oz, r, u, 204, D, roof + "_stairs[facing=north,half=top]");
    }
    // steep gable roof along the depth, ridge over the middle, overhanging two blocks
    for (int u = -1; u <= W; u++) {
      int rise = Math.min(u + 1, W - u), y = 208 + rise;
      for (int v = -2; v <= D + 1; v++) {
        String st = u == W / 2 ? roof + "_slab[type=bottom]" : roof + "_stairs[facing=" + (u < W / 2 ? "east" : "west") + "]";
        lput(ox, oz, r, u, y, v, st);
        if (u != W / 2 && u > -1 && u < W) lput(ox, oz, r, u, y - 1, v, roof.equals("deepslate_tile") ? "deepslate_tiles" : roof + "_planks");
      }
      // gable walls
      if (u >= 0 && u < W)
        for (int v : new int[] {-1, D})
          for (int yy = 208; yy < y - (u == W / 2 ? 0 : 1); yy++) lput(ox, oz, r, u, yy, v, u == W / 2 ? log : infill);
    }
    lput(ox, oz, r, W / 2, 209, -1, "glass_pane[east=true,west=true]");
    lbox(ox, oz, r, 0, 208, 0, W - 1, 208, D - 1, "air");
    // chimney at the back gable
    lbox(ox, oz, r, W - 2, 201, D + 1, W - 1, 214, D + 1, "cobblestone");
    lput(ox, oz, r, W - 2, 215, D + 1, "campfire[lit=true]");
    lput(ox, oz, r, W - 1, 215, D + 1, "cobblestone_wall");
    // front door, porch lantern, step and shutters with flower boxes
    lbox(ox, oz, r, W / 2, 201, 0, W / 2, 202, 0, "air");
    lput(ox, oz, r, W / 2, 202, 0, "spruce_door[facing=north,half=upper,hinge=left]");
    lput(ox, oz, r, W / 2, 201, 0, "spruce_door[facing=north,half=lower,hinge=left]");
    lput(ox, oz, r, W / 2, 200, -1, "stone_brick_stairs[facing=south]");
    lput(ox, oz, r, W / 2 - 1, 203, -1, "lantern[hanging=false]");
    for (int u : new int[] {1, W - 2}) {
      lput(ox, oz, r, u - (u == 1 ? 1 : -1) * 0, 201, -1, "spruce_trapdoor[facing=north,half=top,open=false]");
      lput(ox, oz, r, u, 201, -1, "spruce_trapdoor[facing=north,half=top,open=false]");
      lput(ox, oz, r, u, 202, -1, seed % 2 == 0 ? "potted_red_tulip" : "potted_cornflower");
    }
    // interior: bed, table, barrel, lantern
    lput(ox, oz, r, 1, 201, D - 2, "red_bed[facing=south,part=foot]");
    lput(ox, oz, r, 1, 201, D - 1 - 0, "white_wool");
    lput(ox, oz, r, W - 2, 201, D - 2, "barrel[facing=up]");
    lput(ox, oz, r, W - 2, 201, 3, "crafting_table");
    lput(ox, oz, r, W / 2, 204, D / 2, "lantern[hanging=true]");
    // kitchen garden behind, fenced
    if (!garden) {
      lput(ox, oz, r, -1, 201, 2, "composter");
      lput(ox, oz, r, -1, 201, 4, "barrel[facing=up]");
      return;
    }
    for (int u = -1; u <= W; u++)
      for (int v = D + 2; v <= D + 6; v++) {
        boolean edge = u == -1 || u == W || v == D + 6;
        if (edge) lput(ox, oz, r, u, 201, v, "spruce_fence[" + (u == -1 || u == W ? "north=true,south=true" : "east=true,west=true") + "]");
        else if (v > D + 2) {
          lput(ox, oz, r, u, 200, v, (u + v) % 3 == 0 ? "water[level=0]" : "farmland[moisture=7]");
          if ((u + v) % 3 != 0) lput(ox, oz, r, u, 201, v, (seed + u) % 3 == 0 ? "carrots[age=7]" : (seed + u) % 3 == 1 ? "beetroots[age=3]" : "potatoes[age=7]");
        }
      }
    lput(ox, oz, r, -1, 201, D + 2, "composter");
    lput(ox, oz, r, W, 201, D + 2, "hay_block");
  }

  /** A fenced field with water channels every fourth row and a scarecrow. */
  private void field(int x1, int z1, int x2, int z2, String crop) {
    for (int x = x1 - 1; x <= x2 + 1; x++)
      for (int z = z1 - 1; z <= z2 + 1; z++) {
        if (x == x1 - 1 || x == x2 + 1 || z == z1 - 1 || z == z2 + 1) {
          put(x, 200, z, "coarse_dirt");
          put(x, 201, z, x == x1 - 1 || x == x2 + 1 ? "oak_fence[north=true,south=true]" : "oak_fence[east=true,west=true]");
          continue;
        }
        boolean channel = (x - x1) % 4 == 3;
        put(x, 200, z, channel ? "water[level=0]" : "farmland[moisture=7]");
        put(x, 201, z, channel ? "air" : crop);
      }
    put((x1 + x2) / 2, 201, z1 - 1, "oak_fence_gate[facing=north]");
    int sx = x1 + 1, sz = (z1 + z2) / 2;
    box(sx, 201, sz, sx, 203, sz, "oak_fence");
    put(sx, 202, sz, "hay_block");
    put(sx, 204, sz, "carved_pumpkin[facing=east]");
    put(sx - 0, 201, sz, "oak_fence");
  }

  private void barn(int x, int z) {
    // Simple timber barn with a hay loft and stacked bales.
    box(x, 200, z, x + 10, 200, z + 6, "spruce_planks");
    for (int xx = x; xx <= x + 10; xx++)
      for (int zz = z; zz <= z + 6; zz++) {
        boolean edge = xx == x || xx == x + 10 || zz == z || zz == z + 6;
        if (!edge) continue;
        boolean post = (xx - x) % 5 == 0 && (zz == z || zz == z + 6) || (zz - z) % 6 == 0 && (xx == x || xx == x + 10);
        box(xx, 201, zz, xx, 205, zz, post ? "dark_oak_log" : "spruce_planks");
      }
    box(x + 4, 201, z + 6, x + 6, 204, z + 6, "air");
    for (int xx = x - 1; xx <= x + 11; xx++)
      for (int zz = z - 1; zz <= z + 7; zz++) {
        int rise = Math.min(zz - (z - 1), (z + 7) - zz);
        put(xx, 206 + rise, zz, zz == z + 3 ? "dark_oak_slab" : "dark_oak_stairs[facing=" + (zz < z + 3 ? "south" : "north") + "]");
      }
    box(x + 1, 201, z + 1, x + 3, 202, z + 3, "hay_block");
    box(x + 7, 201, z + 1, x + 9, 201, z + 2, "hay_block");
    put(x + 8, 201, z + 4, "composter");
  }

  /** Water mill on the stream: stone base, timber mill house and a big wooden wheel in the water. */
  private void watermill(int x, int z) {
    box(x + 4, 200, z - 3, x + 10, 200, z + 3, "cobblestone");
    for (int xx = x + 4; xx <= x + 10; xx++)
      for (int zz = z - 3; zz <= z + 3; zz++) {
        boolean edge = xx == x + 4 || xx == x + 10 || zz == z - 3 || zz == z + 3;
        if (!edge) continue;
        boolean post = (xx == x + 4 || xx == x + 10) && (zz == z - 3 || zz == z + 3);
        box(xx, 201, zz, xx, 202, zz, post ? "spruce_log" : "cobblestone");
        box(xx, 203, zz, xx, 205, zz, post ? "spruce_log" : (zz == z && xx == x + 10 ? "glass_pane[north=true,south=true]" : "spruce_planks"));
      }
    box(x + 10, 201, z, x + 10, 202, z, "air");
    for (int xx = x + 3; xx <= x + 11; xx++)
      for (int zz = z - 4; zz <= z + 4; zz++) {
        int rise = Math.min(zz - (z - 4), (z + 4) - zz);
        put(xx, 206 + rise, zz, zz == z ? "spruce_slab" : "spruce_stairs[facing=" + (zz < z ? "south" : "north") + "]");
      }
    // Wheel: a ring of planks and spokes, standing in the stream next to the house.
    int wx = x + 3;
    for (int dz = -4; dz <= 4; dz++)
      for (int dy = -4; dy <= 4; dy++) {
        int d = dz * dz + dy * dy;
        String m = d >= 12 && d <= 20 ? "stripped_spruce_wood" : (dz == 0 || dy == 0) && d < 12 ? "spruce_fence" : null;
        if (m != null) put(wx, 201 + dy, z + dz, m);
      }
    put(wx, 201, z, "spruce_log[axis=x]");
    put(wx + 1, 201, z, "spruce_log[axis=x]");
  }
}
