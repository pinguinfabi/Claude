package de.deepforge.game;

import java.util.*;

/**
 * Dungeon boss attacks: which attacks a boss uses per zone and phase, how long each is
 * telegraphed, how hard it hits and the exact hit geometry. All positions are relative (x/z in
 * blocks, angles in radians), all times are server ticks.
 */
public final class BossPatterns {
  private BossPatterns() {}

  public enum Attack {
    SLAM("Stampfer", "Raus aus dem roten Kreis!", 1.0, false),
    BEAM("Runenstrahl", "Seitlich aus der Linie!", 1.0, false),
    SHOCKWAVE("Schockwelle", "Durch die Lücke, springen oder rollen!", .9, true),
    LEAP("Sprungangriff", "Er springt auf dich – weg vom Ziel!", 1.4, true),
    SPIN("Kreisstrahl", "Vor dem Strahl herlaufen oder durchrollen!", 1.1, true),
    SHARDS("Splitterregen", "Weg von den markierten Stellen!", .8, false),
    VORTEX("Sog", "Gegen den Sog anlaufen – gleich explodiert er!", 1.5, true),
    SAFE("Runensturm", "In das grüne Feld – sonst trifft es dich!", 1.6, true);

    public final String title, hint;
    public final double damage;
    // Big attacks leave the boss exhausted and count for the flawless bonus.
    public final boolean big;

    Attack(String title, String hint, double damage, boolean big) {
      this.title = title;
      this.hint = hint;
      this.damage = damage;
      this.big = big;
    }
  }

  public static final String[] BOSS_NAMES = {
    "Eisenkoloss", "Kristallkönigin", "Sporenmutter", "Tiefenwächter", "Glutfürst", "Reliktwächter",
    "Leerenherz"
  };

  /** Each zone has its own signature trio; SLAM and BEAM are the fillers every boss knows. */
  private static final Attack[][] SIGNATURE = {
    {Attack.SHOCKWAVE, Attack.LEAP, Attack.SAFE},
    {Attack.SHARDS, Attack.SAFE, Attack.SPIN},
    {Attack.VORTEX, Attack.SHARDS, Attack.LEAP},
    {Attack.SHOCKWAVE, Attack.SAFE, Attack.VORTEX},
    {Attack.SPIN, Attack.LEAP, Attack.SHARDS},
    {Attack.SAFE, Attack.SHOCKWAVE, Attack.SPIN},
    {Attack.VORTEX, Attack.SPIN, Attack.LEAP}
  };

  /**
   * Signature set for a zone in one of the dungeons: the Glutschmiede and Frostkrypta bosses of a
   * zone fight with a different trio than the Runengewölbe boss.
   */
  public static int kitIndex(int zone, int variant) {
    return Math.floorMod(zone + variant * 3, 7);
  }

  public static int phase(double hp, double max) {
    return hp <= max / 3 ? 2 : hp <= max * 2 / 3 ? 1 : 0;
  }

  /** Attack rotation: phase 0 knows one signature move, phase 1 two, phase 2 all three. */
  public static List<Attack> kit(int zone, int phase) {
    Attack[] sig = SIGNATURE[Math.floorMod(zone, 7)];
    List<Attack> out = new ArrayList<>(List.of(Attack.SLAM, sig[0], Attack.BEAM));
    if (phase >= 1) out.add(sig[1]);
    if (phase >= 2) out.add(sig[2]);
    return List.copyOf(out);
  }

  /** The n-th attack of the fight: rotation with a deterministic shuffle per cycle. */
  public static Attack next(int zone, int phase, int n, long seed) {
    List<Attack> kit = new ArrayList<>(kit(zone, phase));
    Collections.shuffle(kit, new Random(seed * 31 + n / kit.size() + phase * 997L));
    return kit.get(n % kit.size());
  }

  /** Warning time before the attack lands; faster in later phases and levels, never below 1 s. */
  public static int warning(Attack a, int phase, int level, boolean enraged) {
    int base =
        switch (a) {
          case SLAM, BEAM -> 34;
          case SHARDS -> 30;
          case LEAP -> 38;
          case SHOCKWAVE, SPIN -> 32;
          case VORTEX -> 26;
          case SAFE -> 56;
        };
    base -= phase * 4 + Math.min(6, level / 5);
    if (enraged) base -= 6;
    return Math.max(20, base);
  }

  /** How long the attack stays dangerous after the warning (0 = one instant hit). */
  public static int active(Attack a) {
    return switch (a) {
      case SHOCKWAVE -> 40;
      case SPIN -> 60;
      case VORTEX -> 40;
      default -> 0;
    };
  }

  /** Pause after the attack; big attacks leave a longer weak spot. */
  public static int recovery(Attack a, int phase, int level, boolean enraged) {
    int base = (a.big ? 46 : 26) - phase * 4 - Math.min(8, level / 4);
    return Math.max(14, enraged ? base / 2 : base);
  }

  public static int exhausted(Attack a) {
    return a.big ? 60 : 0;
  }

  public static final double EXHAUSTED_BONUS = 1.75, ENRAGE_DAMAGE = 1.4;
  public static final int PHASE_SHIELD = 50, ENRAGE_AFTER = 20 * 60 * 4;
  public static final double ARENA = 12.5;

  public static double damage(Attack a, double base, boolean enraged) {
    return base * a.damage * (enraged ? ENRAGE_DAMAGE : 1);
  }

  // ---- hit geometry ----

  public static boolean slam(double dx, double dz, double radius) {
    return dx * dx + dz * dz <= radius * radius;
  }

  /** Straight beam from the origin along (dirX, dirZ), unit length. */
  public static boolean beam(double dx, double dz, double dirX, double dirZ, double length, double halfWidth) {
    double along = dx * dirX + dz * dirZ;
    double side = Math.abs(dx * dirZ - dz * dirX);
    return along >= 0 && along <= length && side <= halfWidth;
  }

  public static final double WAVE_SPEED = .3, WAVE_THICKNESS = .9, WAVE_GAP = Math.toRadians(40);

  public static double waveRadius(int ticksSinceStart) {
    return 1.5 + ticksSinceStart * WAVE_SPEED;
  }

  /** Expanding ring with one gap; airborne players (jumping) are not hit. */
  public static boolean shockwave(
      double dx, double dz, int ticksSinceStart, double gapAngle, boolean airborne) {
    if (airborne) return false;
    double dist = Math.sqrt(dx * dx + dz * dz);
    if (Math.abs(dist - waveRadius(ticksSinceStart)) > WAVE_THICKNESS) return false;
    return angleBetween(Math.atan2(dz, dx), gapAngle) > WAVE_GAP / 2;
  }

  public static final double SPIN_LENGTH = 13, SPIN_HALF_WIDTH = .9;

  /** One full turn over the active time; direction +1 counter-clockwise, -1 clockwise. */
  public static double spinAngle(double start, int ticksSinceStart, int direction) {
    return start + direction * 2 * Math.PI * ticksSinceStart / active(Attack.SPIN);
  }

  public static boolean spin(double dx, double dz, double angle) {
    return beam(dx, dz, Math.cos(angle), Math.sin(angle), SPIN_LENGTH, SPIN_HALF_WIDTH);
  }

  public static final double SHARD_RADIUS = 1.8, LEAP_RADIUS = 4.5, VORTEX_RADIUS = 5.5;

  /** Shard impacts: two per player around them plus a few random ones, inside the arena. */
  public static List<double[]> shards(List<double[]> players, int count, long seed) {
    Random r = new Random(seed);
    List<double[]> out = new ArrayList<>();
    for (double[] p : players) {
      out.add(clampToArena(p[0], p[1]));
      double a = r.nextDouble() * Math.PI * 2;
      out.add(clampToArena(p[0] + Math.cos(a) * 3, p[1] + Math.sin(a) * 3));
    }
    while (out.size() < count) {
      double a = r.nextDouble() * Math.PI * 2, d = r.nextDouble() * (ARENA - 2);
      out.add(new double[] {Math.cos(a) * d, Math.sin(a) * d});
    }
    return out;
  }

  public static boolean shard(double dx, double dz) {
    return slam(dx, dz, SHARD_RADIUS);
  }

  /** Pull impulse toward the boss per tick; walking (≈0.22 blocks/tick) still escapes. */
  public static final double VORTEX_PULL = .06;

  public static boolean vortexBlast(double dx, double dz) {
    return slam(dx, dz, VORTEX_RADIUS);
  }

  /** Safe field radius grows a little with the party so everyone fits. */
  public static double safeRadius(int players) {
    return 2.4 + .5 * (Math.max(1, players) - 1);
  }

  /** Safe zone position: on the far side of the arena from the boss, rotated per cast. */
  public static double[] safeSpot(double bossX, double bossZ, int cast) {
    double away = Math.atan2(-bossZ, -bossX);
    if (bossX * bossX + bossZ * bossZ < 1) away = cast * 1.3;
    double a = away + (cast % 3 - 1) * .6;
    return new double[] {Math.cos(a) * 7.5, Math.sin(a) * 7.5};
  }

  public static boolean safeZoneHit(double dx, double dz, double safeX, double safeZ, int players) {
    return !slam(dx - safeX, dz - safeZ, safeRadius(players));
  }

  private static double[] clampToArena(double x, double z) {
    double d = Math.sqrt(x * x + z * z), max = ARENA - 1;
    return d <= max ? new double[] {x, z} : new double[] {x / d * max, z / d * max};
  }

  static double angleBetween(double a, double b) {
    double d = Math.abs((a - b) % (2 * Math.PI));
    return d > Math.PI ? 2 * Math.PI - d : d;
  }
}
