package de.deepforge.game;

import java.util.*;

/**
 * Dungeon boss attacks: which attacks a boss uses per zone and phase, how long each is
 * telegraphed, how hard it hits and the exact hit geometry. All positions are relative (x/z in
 * blocks, angles in radians), all times are server ticks.
 */
public final class BossPatterns {
  private BossPatterns() {}

  public enum Attack {
    SLAM("Stampfer", "Raus aus dem roten Kreis!", 1.0, false),
    BEAM("Runenstrahl", "Seitlich aus der Linie!", 1.0, false),
    SHOCKWAVE("Schockwelle", "Durch die Lücke, springen oder rollen!", .9, true),
    LEAP("Sprungangriff", "Er springt auf dich – weg vom Ziel!", 1.4, true),
    SPIN("Kreisstrahl", "Vor dem Strahl herlaufen oder durchrollen!", 1.1, true),
    SHARDS("Splitterregen", "Weg von den markierten Stellen!", .8, false),
    VORTEX("Sog", "Gegen den Sog anlaufen – gleich explodiert er!", 1.5, true),
    SAFE("Runensturm", "In das grüne Feld – sonst trifft es dich!", 1.6, true),
    // 0.11.0: new attacks – Normal meets one of them in the last phase, Albtraum all of them.
    METEOR("Meteoritenhagel", "Bleib in Bewegung – die Einschläge folgen dir!", .75, false),
    RIFT("Erdspalten", "Die Risse bleiben offen – nicht darauf stehen!", .6, false),
    CHAIN("Blitzkette", "Verteilt euch – der Blitz springt über!", 1.0, true),
    MARK("Todesmarke", "Markiert: weg von allen anderen und vom Boss!", 1.3, true),
    SUMMON("Schildphase", "Besiegt die Diener – so lange ist er unverwundbar!", 0, false);

    public final String title, hint;
    public final double damage;
    // Big attacks leave the boss exhausted and count for the flawless bonus.
    public final boolean big;

    Attack(String title, String hint, double damage, boolean big) {
      this.title = title;
      this.hint = hint;
      this.damage = damage;
      this.big = big;
    }
  }

  public static final String[] BOSS_NAMES = {
    "Eisenkoloss", "Kristallkönigin", "Sporenmutter", "Tiefenwächter", "Glutfürst", "Reliktwächter",
    "Leerenherz"
  };

  /** Each zone has its own signature trio; SLAM and BEAM are the fillers every boss knows. */
  private static final Attack[][] SIGNATURE = {
    {Attack.SHOCKWAVE, Attack.LEAP, Attack.SAFE},
    {Attack.SHARDS, Attack.SAFE, Attack.SPIN},
    {Attack.VORTEX, Attack.SHARDS, Attack.LEAP},
    {Attack.SHOCKWAVE, Attack.SAFE, Attack.VORTEX},
    {Attack.SPIN, Attack.LEAP, Attack.SHARDS},
    {Attack.SAFE, Attack.SHOCKWAVE, Attack.SPIN},
    {Attack.VORTEX, Attack.SPIN, Attack.LEAP}
  };

  /**
   * Signature set for a zone in one of the dungeons: the Glutschmiede and Frostkrypta bosses of a
   * zone fight with a different trio than the Runengewölbe boss.
   */
  public static int kitIndex(int zone, int variant) {
    return Math.floorMod(zone + variant * 3, 7);
  }

  public static int phase(double hp, double max) {
    return hp <= max / 3 ? 2 : hp <= max * 2 / 3 ? 1 : 0;
  }

  /** Attack rotation: phase 0 knows one signature move, phase 1 two, phase 2 all three. */
  public static List<Attack> kit(int zone, int phase) {
    Attack[] sig = SIGNATURE[Math.floorMod(zone, 7)];
    List<Attack> out = new ArrayList<>(List.of(Attack.SLAM, sig[0], Attack.BEAM));
    if (phase >= 1) out.add(sig[1]);
    if (phase >= 2) out.add(sig[2]);
    return List.copyOf(out);
  }

  /**
   * 0.11.0: the kit on a difficulty. Normal adds the Meteoritenhagel in the last phase; Veteran
   * adds Erdspalten from phase 2 and Blitzkette in phase 3; Albtraum knows every new attack.
   */
  public static List<Attack> kit(int zone, int phase, int mode) {
    List<Attack> out = new ArrayList<>(kit(zone, phase));
    if (mode <= 0) {
      if (phase >= 2) out.add(Attack.METEOR);
    } else if (mode == 1) {
      if (phase >= 1) out.add(Attack.RIFT);
      if (phase >= 2) out.addAll(List.of(Attack.METEOR, Attack.CHAIN));
    } else {
      out.add(Attack.METEOR);
      if (phase >= 1) out.addAll(List.of(Attack.RIFT, Attack.MARK));
      if (phase >= 2) out.addAll(List.of(Attack.CHAIN, Attack.SUMMON));
    }
    return List.copyOf(out);
  }

  public static Attack next(int zone, int phase, int mode, int n, long seed) {
    List<Attack> kit = new ArrayList<>(kit(zone, phase, mode));
    Collections.shuffle(kit, new Random(seed * 31 + n / kit.size() + phase * 997L + mode * 7919L));
    return kit.get(n % kit.size());
  }

  /** The n-th attack of the fight: rotation with a deterministic shuffle per cycle. */
  public static Attack next(int zone, int phase, int n, long seed) {
    List<Attack> kit = new ArrayList<>(kit(zone, phase));
    Collections.shuffle(kit, new Random(seed * 31 + n / kit.size() + phase * 997L));
    return kit.get(n % kit.size());
  }

  /** Warning time before the attack lands; faster in later phases and levels, never below 1 s. */
  public static int warning(Attack a, int phase, int level, boolean enraged) {
    int base =
        switch (a) {
          case SLAM, BEAM -> 34;
          case SHARDS -> 30;
          case LEAP -> 38;
          case SHOCKWAVE, SPIN -> 32;
          case VORTEX -> 26;
          case SAFE -> 56;
          case METEOR -> 26;
          case RIFT -> 36;
          case CHAIN -> 40;
          case MARK -> 80;
          case SUMMON -> 30;
        };
    base -= phase * 4 + Math.min(6, level / 5);
    if (enraged) base -= 6;
    return Math.max(20, base);
  }

  /** Warning time on a difficulty: Veteran ×0,78, Albtraum ×0,58 (at least 16 / 13 ticks). */
  public static int warning(Attack a, int phase, int level, boolean enraged, int mode) {
    int w = warning(a, phase, level, enraged);
    if (mode <= 0) return w;
    int floor = a == Attack.MARK ? 50 : mode == 1 ? 16 : 13; // the marked player needs time to run
    return Math.max(floor, (int) Math.round(w * (mode == 1 ? .78 : .58)));
  }

  /** Extra boss attack damage per difficulty on top of the dungeon damage: ×1 / ×1,2 / ×1,6. */
  public static double modeDamage(int mode) {
    return mode <= 0 ? 1 : mode == 1 ? 1.2 : 1.6;
  }

  /** Chance that an attack is chained straight into the next one (Veteran 35 %, Albtraum 60 %). */
  public static double comboChance(int mode) {
    return mode <= 0 ? 0 : mode == 1 ? .35 : .6;
  }

  /** Longest chain of attacks without a pause: 1 / 2 / 3. */
  public static int maxCombo(int mode) {
    return 1 + Math.clamp(mode, 0, 2);
  }

  /** Enrage after 6 / 5 / 4 minutes; on Albtraum the damage then grows by 20 % every 30 s. */
  public static int enrageAfter(int mode) {
    return 20 * 60 * (6 - Math.clamp(mode, 0, 2));
  }

  public static double enrageStacks(int mode, long ticksSinceEnrage) {
    return mode >= 2 ? 1 + .2 * (ticksSinceEnrage / 600) : 1;
  }

  /** Veteran/Albtraum last phase: the arena edge burns and closes in down to this radius. */
  public static double shrinkRadius(int mode, long ticksInPhase) {
    if (mode <= 0) return ARENA + 5;
    double min = mode == 1 ? 9 : 7;
    return Math.max(min, ARENA + 1 - ticksInPhase / 20.0 * (mode == 1 ? .05 : .1));
  }

  // ---- 0.11.0 geometry ----

  public static final double METEOR_RADIUS = 2.2, CHAIN_RANGE = 5, MARK_RADIUS = 5, RIFT_HALF_WIDTH = 1;
  public static final int METEOR_VOLLEYS = 3, METEOR_EVERY = 16, RIFT_TICKS = 200, SUMMON_MAX = 400;

  /** Players reached by a lightning chain that starts at index {@code first}. */
  public static Set<Integer> chain(List<double[]> players, int first) {
    Set<Integer> hit = new LinkedHashSet<>();
    if (first < 0 || first >= players.size()) return hit;
    ArrayDeque<Integer> queue = new ArrayDeque<>(List.of(first));
    hit.add(first);
    while (!queue.isEmpty()) {
      double[] a = players.get(queue.poll());
      for (int i = 0; i < players.size(); i++)
        if (!hit.contains(i) && slam(players.get(i)[0] - a[0], players.get(i)[1] - a[1], CHAIN_RANGE)) {
          hit.add(i);
          queue.add(i);
        }
    }
    return hit;
  }

  /** A rift: a line through the arena centre at the given angle (both directions). */
  public static boolean rift(double dx, double dz, double angle) {
    double c = Math.cos(angle), s = Math.sin(angle);
    return Math.abs(dx * s - dz * c) <= RIFT_HALF_WIDTH && Math.abs(dx * c + dz * s) <= ARENA;
  }

  /** How long the attack stays dangerous after the warning (0 = one instant hit). */
  public static int active(Attack a) {
    return switch (a) {
      case SHOCKWAVE -> 40;
      case SPIN -> 60;
      case VORTEX -> 40;
      default -> 0;
    };
  }

  /** Pause after the attack; big attacks leave a longer weak spot. */
  public static int recovery(Attack a, int phase, int level, boolean enraged) {
    int base = (a.big ? 46 : 26) - phase * 4 - Math.min(8, level / 4);
    return Math.max(14, enraged ? base / 2 : base);
  }

  public static int exhausted(Attack a) {
    return a.big ? 60 : 0;
  }

  public static final double EXHAUSTED_BONUS = 1.75, ENRAGE_DAMAGE = 1.4;
  public static final int PHASE_SHIELD = 50, ENRAGE_AFTER = 20 * 60 * 4;
  public static final double ARENA = 12.5;

  public static double damage(Attack a, double base, boolean enraged) {
    return base * a.damage * (enraged ? ENRAGE_DAMAGE : 1);
  }

  // ---- hit geometry ----

  public static boolean slam(double dx, double dz, double radius) {
    return dx * dx + dz * dz <= radius * radius;
  }

  /** Straight beam from the origin along (dirX, dirZ), unit length. */
  public static boolean beam(double dx, double dz, double dirX, double dirZ, double length, double halfWidth) {
    double along = dx * dirX + dz * dirZ;
    double side = Math.abs(dx * dirZ - dz * dirX);
    return along >= 0 && along <= length && side <= halfWidth;
  }

  public static final double WAVE_SPEED = .3, WAVE_THICKNESS = .9, WAVE_GAP = Math.toRadians(40);

  public static double waveRadius(int ticksSinceStart) {
    return 1.5 + ticksSinceStart * WAVE_SPEED;
  }

  /** Expanding ring with one gap; airborne players (jumping) are not hit. */
  public static boolean shockwave(
      double dx, double dz, int ticksSinceStart, double gapAngle, boolean airborne) {
    if (airborne) return false;
    double dist = Math.sqrt(dx * dx + dz * dz);
    if (Math.abs(dist - waveRadius(ticksSinceStart)) > WAVE_THICKNESS) return false;
    return angleBetween(Math.atan2(dz, dx), gapAngle) > WAVE_GAP / 2;
  }

  public static final double SPIN_LENGTH = 13, SPIN_HALF_WIDTH = .9;

  /** One full turn over the active time; direction +1 counter-clockwise, -1 clockwise. */
  public static double spinAngle(double start, int ticksSinceStart, int direction) {
    return start + direction * 2 * Math.PI * ticksSinceStart / active(Attack.SPIN);
  }

  public static boolean spin(double dx, double dz, double angle) {
    return beam(dx, dz, Math.cos(angle), Math.sin(angle), SPIN_LENGTH, SPIN_HALF_WIDTH);
  }

  public static final double SHARD_RADIUS = 1.8, LEAP_RADIUS = 4.5, VORTEX_RADIUS = 5.5;

  /** Shard impacts: two per player around them plus a few random ones, inside the arena. */
  public static List<double[]> shards(List<double[]> players, int count, long seed) {
    Random r = new Random(seed);
    List<double[]> out = new ArrayList<>();
    for (double[] p : players) {
      out.add(clampToArena(p[0], p[1]));
      double a = r.nextDouble() * Math.PI * 2;
      out.add(clampToArena(p[0] + Math.cos(a) * 3, p[1] + Math.sin(a) * 3));
    }
    while (out.size() < count) {
      double a = r.nextDouble() * Math.PI * 2, d = r.nextDouble() * (ARENA - 2);
      out.add(new double[] {Math.cos(a) * d, Math.sin(a) * d});
    }
    return out;
  }

  public static boolean shard(double dx, double dz) {
    return slam(dx, dz, SHARD_RADIUS);
  }

  /** Pull impulse toward the boss per tick; walking (≈0.22 blocks/tick) still escapes. */
  public static final double VORTEX_PULL = .06;

  public static boolean vortexBlast(double dx, double dz) {
    return slam(dx, dz, VORTEX_RADIUS);
  }

  /** Safe field radius grows a little with the party so everyone fits. */
  public static double safeRadius(int players) {
    return 2.4 + .5 * (Math.max(1, players) - 1);
  }

  /** Safe zone position: on the far side of the arena from the boss, rotated per cast. */
  public static double[] safeSpot(double bossX, double bossZ, int cast) {
    double away = Math.atan2(-bossZ, -bossX);
    if (bossX * bossX + bossZ * bossZ < 1) away = cast * 1.3;
    double a = away + (cast % 3 - 1) * .6;
    return new double[] {Math.cos(a) * 7.5, Math.sin(a) * 7.5};
  }

  public static boolean safeZoneHit(double dx, double dz, double safeX, double safeZ, int players) {
    return !slam(dx - safeX, dz - safeZ, safeRadius(players));
  }

  private static double[] clampToArena(double x, double z) {
    double d = Math.sqrt(x * x + z * z), max = ARENA - 1;
    return d <= max ? new double[] {x, z} : new double[] {x / d * max, z / d * max};
  }

  static double angleBetween(double a, double b) {
    double d = Math.abs((a - b) % (2 * Math.PI));
    return d > Math.PI ? 2 * Math.PI - d : d;
  }

  /** Albtraum: no healing items in the boss's last phase. */
  public static boolean healLock(int mode) {
    return mode >= 2;
  }
}
