package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import java.util.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.scheduler.BukkitTask;

public final class ForestryWorld implements Listener, AutoCloseable {
  private final DeepforgePlugin plugin;
  private final ForestBlueprint plan = ForestBlueprint.create();
  private final Map<String, org.bukkit.block.data.BlockData> palette = new HashMap<>();
  private final Map<Integer, Build> builds = new LinkedHashMap<>();
  private final Set<Integer> ready = new HashSet<>();
  private final Map<String, Regrow> regrows = new HashMap<>();
  private final Map<Integer, List<Entity>> labels = new HashMap<>();
  private final BukkitTask task;
  private long tick;

  private record Build(
      Profile p, Iterator<Map.Entry<ForestBlueprint.Point, String>> iterator, Set<Long> chunks) {}

  private record Regrow(Profile p, ForestBlueprint.Tree tree, long at) {}

  public ForestryWorld(DeepforgePlugin plugin) {
    this.plugin = plugin;
    Bukkit.getPluginManager().registerEvents(this, plugin);
    task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 2, 2);
  }

  private Block block(Profile p, ForestBlueprint.Point pos) {
    return plugin.mines().local(p, pos.x(), pos.y(), pos.z()).getBlock();
  }

  private String key(Profile p, ForestBlueprint.Tree t) {
    return plugin.plot(p) + "/" + t.id();
  }

  public void ensure(Profile p) {
    if (ready.contains(plugin.plot(p)) || builds.containsKey(plugin.plot(p))) return;
    if (plugin.mines().local(p, 100, 196, 0).getBlock().getType()
        == Material.matchMaterial(ForestBlueprint.MARKER)) {
      ready.add(plugin.plot(p));
      restore(p);
      return;
    }
    builds.put(plugin.plot(p), new Build(p, plan.blocks().entrySet().iterator(), new HashSet<>()));
  }

  private void put(Profile p, ForestBlueprint.Point pos, String state) {
    block(p, pos).setBlockData(palette.computeIfAbsent(state, Bukkit::createBlockData), false);
  }

  private void plant(Profile p, ForestBlueprint.Tree t) {
    ForestBlueprint.crown(t).forEach((pos, state) -> put(p, pos, state));
  }

  private void restore(Profile p) {
    for (var t : ForestBlueprint.TREES) if (!regrows.containsKey(key(p, t))) plant(p, t);
  }

  public ForestBlueprint.Tree tree(Profile p, Block b) {
    if (!ready.contains(plugin.plot(p)) || !plugin.mines().contains(b.getLocation())) return null;
    int x = b.getX() - plugin.mines().ox(p), z = b.getZ() - plugin.mines().oz(p);
    return ForestBlueprint.TREES.stream()
        .filter(t -> t.x() == x && t.z() == z && b.getY() >= 201 && b.getY() <= 200 + t.height())
        .findFirst()
        .orElse(null);
  }

  public boolean canChop(Player p, Block b) {
    if (!plugin.playing(p)
        || !plugin.items().kind(p.getInventory().getItemInMainHand()).equals("axe")) return false;
    Profile data = plugin.profile(p);
    var t = tree(data, b);
    return t != null
        && t.species() <= data.forestTier
        && !regrows.containsKey(key(data, t))
        && b.getType() == Material.matchMaterial(ForestBlueprint.log(t))
        && Forestry.capacity(data) - Forestry.used(data) >= 2 * (6 + t.species() * 2);
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void fell(BlockBreakEvent e) {
    Player p = e.getPlayer();
    if (!plugin.playing(p)) return;
    Profile data = plugin.profile(p);
    var t = tree(data, e.getBlock());
    if (t == null) return;
    e.setCancelled(true);
    e.setDropItems(false);
    e.setExpToDrop(0);
    if (!canChop(p, e.getBlock())
        || p.getGameMode() != GameMode.SURVIVAL
        || p.getEyeLocation().distanceSquared(e.getBlock().getLocation().add(.5, .5, .5)) > 36)
      return;
    int resin = data.resin;
    long amount = Forestry.harvest(data, t.species(), Math.random(), Math.random());
    if (amount <= 0) return;
    if (!plugin.commit(p, data)) return;
    ForestBlueprint.crown(t).keySet().forEach(pos -> block(data, pos).setType(Material.AIR, false));
    put(data, new ForestBlueprint.Point(t.x(), 201, t.z()), "oak_slab[type=bottom]");
    regrows.put(
        key(data, t),
        new Regrow(data, t, System.currentTimeMillis() + 45000 + t.species() * 15000));
    p.playSound(e.getBlock().getLocation(), Sound.BLOCK_WOOD_BREAK, 1, .65f);
    p.spawnParticle(
        Particle.BLOCK,
        e.getBlock().getLocation().add(.5, 1, .5),
        30,
        .7,
        1,
        .7,
        Material.matchMaterial(ForestBlueprint.log(t)).createBlockData());
    plugin.tell(
        p,
        "+"
            + amount
            + " "
            + Forestry.WOODS[t.species()]
            + (amount > 6 + t.species() * 2 ? " · DOPPELERNTE!" : "")
            + (data.resin > resin ? " · +1 seltenes Harz!" : ""));
  }

  @EventHandler(priority = EventPriority.LOW)
  public void interact(PlayerInteractEvent e) {
    Player p = e.getPlayer();
    if (!plugin.playing(p) || e.getHand() != EquipmentSlot.HAND || e.getClickedBlock() == null)
      return;
    Profile data = plugin.profile(p);
    Block b = e.getClickedBlock();
    if (e.getAction().isRightClick() && station(data, b)) {
      e.setCancelled(true);
      plugin.menus().open(p, "forestry");
      return;
    }
    var t = tree(data, b);
    if (t != null && e.getAction().isLeftClick() && !canChop(p, b))
      plugin.tell(
          p,
          t.species() > data.forestTier
              ? "Diesen Hain zuerst am Sägewerk freischalten."
              : "Forstaxt halten und genug Holzlagerplatz freimachen. Stümpfe wachsen nach.");
  }

  public boolean station(Profile p, Block b) {
    if (b == null || !plugin.mines().contains(b.getLocation())) return false;
    int x = b.getX() - plugin.mines().ox(p), z = b.getZ() - plugin.mines().oz(p);
    return b.getY() == 201 && (x == 71 && z == 10 || x == 69 && z == 18 || x == 73 && z == 18);
  }

  private void label(Profile p, double x, double y, double z, String text, List<Entity> result) {
    result.add(
        plugin
            .mines()
            .world()
            .spawn(
                plugin.mines().local(p, x, y, z),
                TextDisplay.class,
                e -> {
                  e.text(Component.text(text, NamedTextColor.GOLD));
                  e.setBillboard(Display.Billboard.CENTER);
                  e.setPersistent(false);
                }));
  }

  private void decorate(Profile p) {
    labels.getOrDefault(plugin.plot(p), List.of()).forEach(Entity::remove);
    List<Entity> result = new ArrayList<>();
    labels.put(plugin.plot(p), result);
    label(p, 71.5, 205, 10.5, "SÄGEWERK · Rechtsklick\nAxt · Holz · Bretter · Aufträge", result);
    label(p, 47.5, 204, 0.5, "HOLZFÄLLER →\nDem Kiesweg folgen", result);
    for (int i = 0; i < 3; i++)
      label(
          p,
          ForestBlueprint.TREES.get(i * 4).x(),
          204,
          ForestBlueprint.TREES.get(i * 4).z() + 2,
          Forestry.WOODS[i]
              + (i <= p.forestTier ? " · Forstbäume fällen" : " · am Sägewerk freischalten"),
          result);
  }

  private void tick() {
    tick += 2;
    if (!builds.isEmpty()) {
      Build b = builds.values().iterator().next();
      for (int n = 0; n < 1800 && b.iterator.hasNext(); n++) {
        var e = b.iterator.next();
        var chunk = block(b.p, e.getKey()).getChunk();
        if (b.chunks.add(chunk.getChunkKey())) chunk.addPluginChunkTicket(plugin);
        put(b.p, e.getKey(), e.getValue());
      }
      if (!b.iterator.hasNext()) {
        builds.remove(plugin.plot(b.p));
        ready.add(plugin.plot(b.p));
        decorate(b.p);
        for (long k : b.chunks)
          plugin
              .mines()
              .world()
              .getChunkAt((int) k, (int) (k >> 32))
              .removePluginChunkTicket(plugin);
      }
    }
    if (tick % 20 != 0) return;
    for (Player p : plugin.mines().world().getPlayers())
      if (plugin.playing(p)) {
        Profile data = plugin.profile(p);
        ensure(data);
        if (ready.contains(plugin.plot(data))
            && p.getY() > 190
            && p.getX() - plugin.mines().ox(data) > 35
            && tick % 100 == 0) decorate(data);
        if (plugin.items().kind(p.getInventory().getItemInMainHand()).equals("axe"))
          plugin.items().axeSpeed(p, Forestry.speed(data));
      }
    var it = regrows.values().iterator();
    while (it.hasNext()) {
      Regrow r = it.next();
      if (r.at > System.currentTimeMillis()) continue;
      var l = plugin.mines().local(r.p, r.tree.x(), 201, r.tree.z());
      if (!l.getWorld().isChunkLoaded(l.getBlockX() >> 4, l.getBlockZ() >> 4)) continue;
      plant(r.p, r.tree);
      it.remove();
    }
  }

  public String verify(List<Profile> profiles) {
    for (Profile p : profiles) ensure(p);
    if (!builds.isEmpty()) return "RUNNING: woodland construction";
    int checked = 0;
    for (Profile p : profiles) {
      for (var t : ForestBlueprint.TREES) {
        if (!regrows.containsKey(key(p, t))
            && block(p, new ForestBlueprint.Point(t.x(), 201, t.z())).getType()
                != Material.matchMaterial(ForestBlueprint.log(t))) return "FAILED: tree " + t.id();
        checked++;
      }
      if (plugin.mines().local(p, 71, 201, 10).getBlock().getType() != Material.CARTOGRAPHY_TABLE)
        return "FAILED: sawmill";
      if (plugin.mines().local(p, 73, 200, -25).getBlock().getType() != Material.WATER
          || plugin.mines().local(p, 65, 206, 0).getBlock().getType() != Material.SPRUCE_LOG
          || plugin.mines().local(p, 74, 207, -16).getBlock().getType()
              != Material.STRIPPED_SPRUCE_LOG) return "FAILED: woodland scenery";
      for (int x = 36; x <= 120; x++)
        if (!plugin.mines().local(p, x, 201, 0).getBlock().isPassable()
            || !plugin.mines().local(p, x, 202, 0).getBlock().isPassable())
          return "FAILED: road " + x;
      var t = ForestBlueprint.TREES.getFirst();
      if (!regrows.containsKey(key(p, t))) {
        block(p, new ForestBlueprint.Point(t.x(), 201, t.z())).setType(Material.AIR, false);
        plant(p, t);
        if (block(p, new ForestBlueprint.Point(t.x(), 201, t.z())).getType() != Material.OAK_LOG)
          return "FAILED: replant";
      }
    }
    return "OK: "
        + checked
        + " harvest trees, 3 species, sawmill, walkable road, replant, pond, timber arch, log"
        + " crane; no player rewards";
  }

  @Override
  public void close() {
    task.cancel();
    labels.values().forEach(list -> list.forEach(Entity::remove));
    for (Build b : builds.values())
      for (long k : b.chunks)
        plugin.mines().world().getChunkAt((int) k, (int) (k >> 32)).removePluginChunkTicket(plugin);
  }
}
