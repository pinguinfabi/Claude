package de.deepforge.game;

import java.time.LocalDate;
import java.util.*;
import java.util.function.ToLongFunction;

/**
 * Three daily tasks per player. Each task counts the growth of a counter the game already keeps
 * since the task was handed out, so nothing else in the game has to report to it.
 */
public final class Dailies {
  public record Task(String id, String title, String unit, ToLongFunction<Profile> counter) {}

  public static final List<Task> TASKS =
      List.of(
          new Task("ore", "Erz abbauen", "Erz selbst abgebaut", p -> p.mined),
          new Task("kills", "Monster besiegen", "Gegner besiegt", p -> p.kills),
          new Task("trees", "Bäume fällen", "Bäume gefällt", p -> p.woodTrees),
          new Task("deposit", "Erz einlagern", "Erz ins Lager gebracht", p -> p.depositedOre),
          new Task("smelt", "Barren schmelzen", "Barren selbst geschmolzen", p -> p.manualSmelted),
          new Task("trade", "Barren verkaufen", "Barren am Markt verkauft", p -> p.soldBars),
          new Task("dodge", "Ausweichen", "Ausweichrollen im Kampf", p -> p.dodges),
          new Task(
              "dungeon",
              "Gewölbe bezwingen",
              "Dungeon-Siege",
              p -> Arrays.stream(p.dungeonWins).asLongStream().sum()));

  public static final int COUNT = 3;

  public static Task task(String id) {
    return TASKS.stream().filter(t -> t.id.equals(id)).findFirst().orElse(null);
  }

  /** Tasks this player can already do; the pool grows with their progress. */
  static List<Task> eligible(Profile p) {
    List<Task> out = new ArrayList<>();
    for (Task t : TASKS) {
      boolean ok =
          switch (t.id) {
            case "smelt", "trade" -> p.furnace > 0;
            case "dodge" -> p.kills >= 10;
            case "dungeon" -> t.counter.applyAsLong(p) > 0;
            case "trees" -> p.woodTrees > 0 || p.axe > 0;
            default -> true;
          };
      if (ok) out.add(t);
    }
    return out;
  }

  public static long target(Profile p, String id) {
    int z = Math.max(0, p.zone);
    return switch (id) {
      case "ore" -> 120 + 40L * z;
      case "kills" -> 12 + 4L * z;
      case "trees" -> 10 + 5L * p.forestTier;
      case "deposit" -> 150 + 50L * z;
      case "smelt" -> 40 + 20L * z;
      case "trade" -> 30 + 15L * z;
      case "dodge" -> 15;
      case "dungeon" -> 1;
      default -> 1;
    };
  }

  public static long money(Profile p) {
    return Math.round(250L * (Math.max(0, p.zone) + 1) * Zone.deepFactor(p.zone));
  }

  /** Bonus for finishing all three; grows with the streak up to seven days. */
  public static long bonusMoney(Profile p, int streak) {
    return 400L * (Math.max(0, p.zone) + 1) * Math.max(1, Math.min(7, streak));
  }

  /** Hands out today's tasks once per day. Returns true when the profile changed. */
  public static boolean ensure(Profile p, LocalDate today) {
    String date = today.toString();
    if (date.equals(p.dailyDate)
        && p.dailyTasks.size() == COUNT
        && p.dailyTasks.stream().allMatch(id -> task(id) != null)) return false;
    List<Task> pool = eligible(p);
    Random rng = new Random(Objects.hash(p.id, date));
    Collections.shuffle(pool, rng);
    // Always keep something to do in the mine: ore when it is not drawn already.
    if (pool.stream().limit(COUNT).noneMatch(t -> t.id.equals("ore") || t.id.equals("kills"))) {
      pool.remove(task("ore"));
      pool.add(0, task("ore"));
    }
    p.dailyDate = date;
    p.dailyTasks = new ArrayList<>();
    p.dailyBase = new long[COUNT];
    p.dailyTarget = new long[COUNT];
    p.dailyClaimed = new boolean[COUNT];
    p.dailyBonusClaimed = false;
    for (int i = 0; i < COUNT; i++) {
      Task t = pool.get(i);
      p.dailyTasks.add(t.id);
      p.dailyBase[i] = t.counter.applyAsLong(p);
      p.dailyTarget[i] = target(p, t.id);
    }
    return true;
  }

  public static long progress(Profile p, int i) {
    Task t = task(p.dailyTasks.get(i));
    if (t == null) return 0;
    return Math.max(0, Math.min(p.dailyTarget[i], t.counter.applyAsLong(p) - p.dailyBase[i]));
  }

  public static boolean done(Profile p, int i) {
    return progress(p, i) >= p.dailyTarget[i];
  }

  public static int readyCount(Profile p) {
    if (p.dailyTasks.size() != COUNT) return 0;
    int n = 0;
    for (int i = 0; i < COUNT; i++) if (!p.dailyClaimed[i] && done(p, i)) n++;
    return n;
  }

  public static int claimedCount(Profile p) {
    int n = 0;
    for (boolean b : p.dailyClaimed) if (b) n++;
    return n;
  }

  public static String claim(Profile p, int i, LocalDate today) {
    ensure(p, today);
    if (i < 0 || i >= COUNT) return "Unbekannter Tagesauftrag.";
    if (p.dailyClaimed[i]) return "Diesen Tagesauftrag hast du heute schon abgeschlossen.";
    Task t = task(p.dailyTasks.get(i));
    if (!done(p, i))
      return "Es fehlen " + (p.dailyTarget[i] - progress(p, i)) + " für „" + t.title + "“.";
    p.dailyClaimed[i] = true;
    long money = money(p);
    p.money += money;
    p.lifetimeRevenue += money;
    p.dust += 1;
    String msg = "Tagesauftrag „" + t.title + "“ erledigt: +" + money + " $, +1 Schmiedestaub.";
    if (claimedCount(p) == COUNT && !p.dailyBonusClaimed) {
      p.dailyBonusClaimed = true;
      p.dailyStreak =
          today.minusDays(1).toString().equals(p.dailyStreakDate) ? p.dailyStreak + 1 : 1;
      p.dailyStreakDate = today.toString();
      p.dailyBestStreak = Math.max(p.dailyBestStreak, p.dailyStreak);
      long bonus = bonusMoney(p, p.dailyStreak);
      p.money += bonus;
      p.lifetimeRevenue += bonus;
      p.dust += 2;
      p.relics += 1;
      p.researchNotes += 1;
      msg +=
          " ALLE DREI geschafft! Serie "
              + p.dailyStreak
              + " Tag"
              + (p.dailyStreak == 1 ? "" : "e")
              + ": +"
              + bonus
              + " $, +2 Staub, +1 Relikt, +1 Unterlage.";
    }
    return msg;
  }

  /** Streak that still counts today: broken when yesterday was not finished. */
  public static int liveStreak(Profile p, LocalDate today) {
    if (today.toString().equals(p.dailyStreakDate)
        || today.minusDays(1).toString().equals(p.dailyStreakDate)) return p.dailyStreak;
    return 0;
  }

  private Dailies() {}
}
