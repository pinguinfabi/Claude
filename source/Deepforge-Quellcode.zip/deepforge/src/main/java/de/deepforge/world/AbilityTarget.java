package de.deepforge.world;

import java.util.function.DoubleConsumer;
import org.bukkit.entity.LivingEntity;

/** An enemy a weapon ability can hit, in the mines or in a dungeon. */
record AbilityTarget(LivingEntity entity, DoubleConsumer hit) {}
