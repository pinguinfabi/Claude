package de.deepforge.storage;

import com.google.gson.Gson;
import de.deepforge.game.DungeonRules;
import de.deepforge.game.Gear;
import de.deepforge.game.Profile;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/** All calls are main-thread confined. A committed row includes its settlement timestamp. */
public final class Profiles implements AutoCloseable {
  private final Connection db;
  private final Gson gson = new Gson();
  private final Map<UUID, Profile> cache = new HashMap<>();

  public Profiles(Path file) throws Exception {
    Files.createDirectories(file.getParent());
    Class.forName("org.sqlite.JDBC");
    db = DriverManager.getConnection("jdbc:sqlite:" + file.toAbsolutePath());
    try (Statement st = db.createStatement()) {
      st.execute("PRAGMA journal_mode=WAL");
      st.execute("PRAGMA synchronous=FULL");
      st.execute("PRAGMA busy_timeout=5000");
      st.execute(
          "CREATE TABLE IF NOT EXISTS profiles (id TEXT PRIMARY KEY, plot INTEGER UNIQUE NOT NULL,"
              + " data TEXT NOT NULL)");
    }
  }

  public Profile get(UUID id, String name, long starter) {
    if (cache.containsKey(id)) return cache.get(id);
    try (PreparedStatement st = db.prepareStatement("SELECT data FROM profiles WHERE id=?")) {
      st.setString(1, id.toString());
      try (ResultSet rs = st.executeQuery()) {
        if (rs.next()) {
          Profile p = gson.fromJson(rs.getString(1), Profile.class);
          validate(p);
          p.name = name;
          cache.put(id, p);
          return p;
        }
      }
      Profile p = new Profile();
      p.id = id.toString();
      p.name = name;
      p.money = starter;
      p.lastSettled = System.currentTimeMillis();
      try (Statement s = db.createStatement();
          ResultSet rs = s.executeQuery("SELECT COALESCE(MAX(plot),-1)+1 FROM profiles")) {
        rs.next();
        p.plot = rs.getInt(1);
      }
      save(p);
      cache.put(id, p);
      return p;
    } catch (SQLException e) {
      throw new IllegalStateException("Spielerstand konnte nicht geladen werden", e);
    }
  }

  /** Read-only snapshots for world-layout migration; does not settle or modify player balances. */
  public List<Profile> saved() {
    List<Profile> result = new ArrayList<>();
    try (Statement st = db.createStatement();
        ResultSet rs = st.executeQuery("SELECT data FROM profiles ORDER BY plot")) {
      while (rs.next()) {
        Profile p = gson.fromJson(rs.getString(1), Profile.class);
        validate(p);
        result.add(p);
      }
      return result;
    } catch (SQLException e) {
      throw new IllegalStateException("Could not read saved plots", e);
    }
  }

  public void save(Profile p) {
    validate(p);
    try (PreparedStatement st =
        db.prepareStatement(
            "INSERT INTO profiles(id,plot,data) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET"
                + " data=excluded.data")) {
      st.setString(1, p.id);
      st.setInt(2, p.plot);
      st.setString(3, gson.toJson(p));
      st.executeUpdate();
    } catch (SQLException e) {
      cache.remove(UUID.fromString(p.id));
      throw new IllegalStateException("Speichern fehlgeschlagen; Aktion angehalten", e);
    }
  }

  /**
   * Reward copies commit together; a failed transaction cannot leak mutated balances into cache.
   */
  public Map<String, de.deepforge.game.RewardDiff> rewardDungeon(
      List<UUID> ids, UUID run, int zone, int mode, long ticks) {
    return rewardDungeon(ids, run, zone, mode, ticks, 1);
  }

  public Map<String, de.deepforge.game.RewardDiff> rewardDungeon(
      List<UUID> ids, UUID run, int zone, int mode, long ticks, int level) {
    return rewardDungeon(ids, run, zone, mode, ticks, level, 0);
  }

  /** Returns what each rewarded player gained, keyed by profile id. */
  public Map<String, de.deepforge.game.RewardDiff> rewardDungeon(
      List<UUID> ids, UUID run, int zone, int mode, long ticks, int level, int optionalFlags) {
    List<Profile> copies = new ArrayList<>();
    Map<String, de.deepforge.game.RewardDiff> gains = new LinkedHashMap<>();
    // Party members receive different kinds of equipment from the same run.
    Set<Gear.Slot> taken = EnumSet.noneOf(Gear.Slot.class);
    for (UUID id : new LinkedHashSet<>(ids)) {
      Profile original = cache.get(id);
      if (original == null) {
        original =
            saved().stream().filter(p -> p.id.equals(id.toString())).findFirst().orElseThrow();
      }
      Profile copy = gson.fromJson(gson.toJson(original), Profile.class);
      if (DungeonRules.reward(copy, run, zone, mode, ticks, level, optionalFlags, taken)) {
        validate(copy);
        copies.add(copy);
        gains.put(copy.id, de.deepforge.game.RewardDiff.between(original, copy));
      }
    }
    try {
      db.setAutoCommit(false);
      for (Profile copy : copies) save(copy);
      db.commit();
      for (Profile copy : copies) cache.put(UUID.fromString(copy.id), copy);
      return gains;
    } catch (SQLException | RuntimeException ex) {
      try {
        db.rollback();
      } catch (SQLException suppressed) {
        ex.addSuppressed(suppressed);
      }
      throw new IllegalStateException("Dungeon reward transaction failed", ex);
    } finally {
      try {
        db.setAutoCommit(true);
      } catch (SQLException ex) {
        throw new IllegalStateException(ex);
      }
    }
  }

  private void validate(Profile p) {
    if (p == null
        || (p.schema != 1 && p.schema != 2)
        || p.id == null
        || p.zone < 0
        || p.zone > 6
        || p.money < 0
        || p.budget < 0
        || p.fuel < 0
        || p.bag == null
        || p.bag.length != 7
        || p.stock.length != 7
        || p.bars.length != 7)
      throw new IllegalStateException(
          "Ungültiger Spielerstand; Wiederherstellung aus Backup erforderlich");
    Gear.migrate(p);
    if (p.wood == null) p.wood = new long[3];
    if (p.planks == null) p.planks = new long[3];
    if (p.wood.length != 3
        || p.planks.length != 3
        || p.oreLuck < 0
        || p.oreLuck > 10
        || p.axe < 0
        || p.axe > 10
        || p.woodLuck < 0
        || p.woodLuck > 10
        || p.woodStorage < 0
        || p.woodStorage > 10
        || p.sawmill < 0
        || p.sawmill > 3
        || p.forestTier < 0
        || p.forestTier > 2
        || p.resin < 0
        || p.woodOrders < 0
        || p.woodChopped < 0
        || p.woodTrees < 0
        || Arrays.stream(p.wood).anyMatch(v -> v < 0)
        || Arrays.stream(p.planks).anyMatch(v -> v < 0))
      throw new IllegalStateException("Invalid forestry progress");
    if (p.artifactCollection == null) p.artifactCollection = new HashSet<>();
    if (p.milestones == null) p.milestones = new HashSet<>();
    if (p.seenGear == null) p.seenGear = new HashSet<>();
    if (p.hudStyle < 0 || p.hudStyle > 2) p.hudStyle = 0;
    if (p.droneLevel < 0 || p.droneLevel > de.deepforge.game.DroneRules.MAX_LEVEL)
      throw new IllegalStateException("Invalid drone level");
    if (p.droneModule < 0 || p.droneModule > 2) p.droneModule = 0;
    if (!de.deepforge.game.DroneRules.skinUnlocked(Math.max(1, p.droneLevel), p.droneSkin)) p.droneSkin = 0;
    Set<String> owned = new HashSet<>();
    for (Gear.Item item : p.gear) owned.add(item.id);
    if (!p.gearSeenInit) {
      // Saves from before the "new" marker: everything already owned counts as seen.
      p.seenGear = new HashSet<>(owned);
      p.gearSeenInit = true;
    }
    p.seenGear.retainAll(owned);
    if (p.dailyDate == null) p.dailyDate = "";
    if (p.dailyStreakDate == null) p.dailyStreakDate = "";
    if (p.dailyTasks == null
        || p.dailyBase == null
        || p.dailyTarget == null
        || p.dailyClaimed == null
        || p.dailyBase.length != 3
        || p.dailyTarget.length != 3
        || p.dailyClaimed.length != 3
        || p.dailyTasks.size() > 3) {
      // Unreadable daily state is not worth losing a save over; hand out new tasks.
      p.dailyDate = "";
      p.dailyTasks = new ArrayList<>();
      p.dailyBase = new long[3];
      p.dailyTarget = new long[3];
      p.dailyClaimed = new boolean[3];
    }
    if (p.dailyStreak < 0 || p.dailyBestStreak < 0 || p.richVeins < 0 || p.bestCombo < 0)
      throw new IllegalStateException("Invalid daily progress");
    if (p.tutorialStep < 0
        || p.tutorialStep > de.deepforge.game.Tutorial.TITLES.length
        || p.manualSmelted < 0
        || p.soldBars < 0
        || p.depositedOre < 0
        || p.dodges < 0
        || p.healsUsed < 0
        || p.adventureRescues < 0
        || p.adventureChallenges < 0
        || p.adventureTreasures < 0
        || p.artifactCollection.stream().anyMatch(i -> i < 0 || i > 3))
      throw new IllegalStateException("Invalid adventure progress");
    if (p.dungeonWins == null) p.dungeonWins = new int[21];
    if (p.dungeonBestTicks == null) p.dungeonBestTicks = new long[21];
    if (p.dungeonReceipts == null) p.dungeonReceipts = new ArrayList<>();
    if (p.dungeonWins.length != 21
        || p.dungeonBestTicks.length != 21
        || p.dungeonReceipts.size() > 256)
      throw new IllegalStateException("Invalid dungeon profile");
    for (int value : p.dungeonWins)
      if (value < 0) throw new IllegalStateException("Invalid dungeon wins");
    for (long value : p.dungeonBestTicks)
      if (value < 0) throw new IllegalStateException("Invalid dungeon time");
    DungeonRules.level(p);
    if (p.healingCharges < 0
        || p.healingCharges > de.deepforge.game.Healing.CAPACITY
        || p.healingReadyAt < 0) throw new IllegalStateException("Invalid healing inventory");
    if (p.research == null) p.research = new int[5];
    if (p.contracts == null) p.contracts = new int[3];
    if (p.collectionTiers == null) p.collectionTiers = new int[7];
    if (p.expeditions == null) p.expeditions = new boolean[21];
    if (p.research.length != 5
        || p.contracts.length != 3
        || p.collectionTiers.length != 7
        || p.expeditions.length != 21
        || p.researchNotes < 0) throw new IllegalStateException("Invalid industry profile");
    for (int v : p.research)
      if (v < 0 || v > 5) throw new IllegalStateException("Invalid research level");
    for (int v : p.collectionTiers)
      if (v < 0 || v > 3) throw new IllegalStateException("Invalid collection tier");
    for (int v : p.contracts)
      if (v < 0) throw new IllegalStateException("Invalid contract sequence");
    for (Profile.Worker w : p.workers)
      if (w == null
          || w.job == null
          || w.zone < 0
          || w.zone > p.zone
          || w.level < 1
          || w.level > 5
          || w.specialization < 0
          || w.specialization > 2
          || w.workMinutes < 0) throw new IllegalStateException("Invalid worker assignment");
    if (p.bossTokens.length != 7
        || p.monsterParts.length != 7
        || p.bossWins.length != 21
        || p.dryStreak.length != 7
        || p.huntKills.length != 7
        || p.huntsCompleted.length != 7
        || p.dust < 0) throw new IllegalStateException("Invalid equipment profile");
    Set<String> ids = new HashSet<>();
    for (Gear.Item item : p.gear) {
      if (item == null
          || item.id == null
          || !ids.add(item.id)
          || item.name == null
          || item.slot == null
          || item.rarity == null
          || item.zone < 0
          || item.zone > 6
          || item.level < 0
          || item.level > 10
          || item.dungeonRank < 0
          || item.archetype < -1
          || item.archetype > 3
          || item.adventureSet < -1
          || item.adventureSet > 2
          || item.signature < -1
          || item.signature > 6
          || item.quality < 80
          || item.quality > 100
          || !Arrays.asList(Gear.WEAPONS).contains(item.style))
        throw new IllegalStateException("Invalid or duplicated equipment");
      for (double value :
          new double[] {
            item.damage,
            item.health,
            item.defense,
            item.crit,
            item.haste,
            item.stagger,
            item.mining,
            item.yield,
            item.efficiency
          })
        if (!Double.isFinite(value) || value < 0)
          throw new IllegalStateException("Invalid equipment stats");
    }
    for (var slot : p.equipped.entrySet()) {
      Gear.Item item = Gear.find(p, slot.getValue());
      if (item == null || !item.slot.name().equals(slot.getKey()))
        throw new IllegalStateException("Invalid equipped item");
    }
    for (long value : p.bossTokens)
      if (value < 0) throw new IllegalStateException("Negative fragments");
    for (long value : p.monsterParts)
      if (value < 0) throw new IllegalStateException("Negative monster parts");
    for (long[] a : List.of(p.bag, p.stock, p.bars, p.huntKills, p.huntsCompleted))
      for (long v : a) if (v < 0) throw new IllegalStateException("Negativer Lagerbestand");
  }

  public void evict(UUID id) {
    cache.remove(id);
  }

  @Override
  public void close() throws SQLException {
    db.close();
  }
}
