package de.deepforge.ui;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.ShadowColor;
import net.kyori.adventure.text.format.TextColor;

/**
 * Pinguin Netzwerk glyphs (resource pack font deepforge:netz): the same rank tags, status tags,
 * icons, bars and panels as the network's lobby, plus the DEEPFORGE logo and panel header. Only
 * used for players with the verified Deepforge pack; everyone else gets {@link NetworkTheme} text.
 */
public final class NetzFont {
  private NetzFont() {}

  public static final Key FONT = Key.key("deepforge", "netz");

  public enum Icon {
    SWORD('\ue000'),
    CLOCK('\ue001'),
    SHIELD('\ue002'),
    TEAM('\ue003'),
    BOLT('\ue004'),
    FLASK('\ue005'),
    ZONE('\ue006'),
    HEART('\ue007'),
    SKULL('\ue008'),
    CROWN('\ue009'),
    TWITCH('\ue00a'),
    PLAYER('\ue00b'),
    STAR('\ue00c'),
    NETZWERK('\ue07d');

    final char glyph;

    Icon(char glyph) {
      this.glyph = glyph;
    }
  }

  public enum Tag {
    INGAME('\ue020'),
    LOBBY('\ue01d'),
    SPEC('\ue023'),
    SUPPORT('\ue024');

    final char glyph;

    Tag(char glyph) {
      this.glyph = glyph;
    }
  }

  static final char LOGO = '\ue080', HEADER = '\ue081', DIVIDER = '\ue07a';
  // bar_red/green/yellow/orange_00..20, 21 steps each, in the network pack's order.
  private static final char BAR_RED = '\ue025', BAR_GREEN = '\ue03a', BAR_YELLOW = '\ue04f';
  private static final char BAR_ORANGE = '\ue064';

  private static Component glyphs(String text) {
    // Glyphs carry their own colours; white keeps them untinted, no shadow keeps them crisp.
    return Component.text(text, NamedTextColor.WHITE)
        .font(FONT)
        .shadowColor(ShadowColor.none());
  }

  /** Icon plus a normal space; the space must stay in the default font (netz has none). */
  public static Component icon(Icon icon) {
    return Component.text().append(glyphs(String.valueOf(icon.glyph))).append(Component.text(" ")).build();
  }

  public static Component tag(Tag tag) {
    return glyphs(String.valueOf(tag.glyph));
  }

  /** Big orange DEEPFORGE logo for the tab list header. */
  public static Component logo() {
    return glyphs(String.valueOf(LOGO));
  }

  /** "◆ DEEPFORGE ◆ / PINGUIN NETZWERK" panel for the sidebar title. */
  public static Component header() {
    return glyphs(String.valueOf(HEADER));
  }

  /** Thin orange divider line, 132 pixels wide. */
  public static Component divider() {
    return glyphs(String.valueOf(DIVIDER));
  }

  /** Rank tag like the lobby (coloured box with the rank name); empty for normal players. */
  public static Component rank(PlayerRank rank) {
    char c =
        switch (rank) {
          case HOSTER -> '\ue012';
          case ADMIN -> '\ue013';
          case TEAMLEITUNG -> '\ue014';
          case DEV -> '\ue015';
          case SRMOD -> '\ue016';
          case MOD -> '\ue017';
          case HELPER -> '\ue018';
          case BUILDER -> '\ue019';
          case MEDIA -> '\ue01a';
          case VIP -> '\ue01b';
          case SUB -> '\ue01c';
          case NONE -> 0;
        };
    return c == 0 ? Component.empty() : glyphs(String.valueOf(c));
  }

  /** 21-step progress bar: green, then yellow past 60 %, orange past 80 %, red when full. */
  public static Component bar(double fraction) {
    double f = Math.max(0, Math.min(1, fraction));
    int step = (int) Math.round(f * 20);
    char base = f >= 1 ? BAR_RED : f >= .8 ? BAR_ORANGE : f >= .6 ? BAR_YELLOW : BAR_GREEN;
    return glyphs(String.valueOf((char) (base + step)));
  }

  /** Name colour for the tag's rank, same as the text fallback. */
  public static TextColor nameColor(PlayerRank rank) {
    return rank == PlayerRank.NONE ? NamedTextColor.WHITE : rank.color;
  }
}
