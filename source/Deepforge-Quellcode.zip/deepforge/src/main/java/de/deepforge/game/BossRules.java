package de.deepforge.game;

import java.util.*;

/** Pure attack geometry and mode rules shared by combat and regression tests. */
public final class BossRules {
  public enum Attack {
    CONE,
    RING,
    BEAM,
    IMPACT,
    SPORES,
    RUNES,
    // 0.21.0: every mine boss learns two of these in its later phases.
    CHARGE,
    CROSS,
    NOVA,
    FALL
  }

  /** Name shown in the boss bar while the attack is telegraphed. */
  public static String title(Attack a) {
    return switch (a) {
      case CONE -> "ARMSCHLAG";
      case RING -> "SPRINGEN: STAMPFWELLE";
      case BEAM -> "STRAHL: SEITLICH AUSWEICHEN";
      case IMPACT -> "EINSCHLAG: FLÄCHE VERLASSEN";
      case SPORES -> "SPORENFELD";
      case RUNES -> "RUNEN: IN DIE FREIE GASSE";
      case CHARGE -> "STURMANGRIFF: AUS DER BAHN";
      case CROSS -> "KREUZSTRAHL: IN DIE ECKE";
      case NOVA -> "NOVA: GANZ NAH RAN!";
      case FALL -> "FELSREGEN: IN BEWEGUNG BLEIBEN";
    };
  }

  public static final String[] NAMES = {
    "Steinwächter",
    "Kristallkönigin",
    "Sporenhüter",
    "Tiefenwächter",
    "Magmakönig",
    "Runenwächter",
    "Leerenfürst",
    "Kernkoloss",
    "Spiegelhexe",
    "Giftmutter",
    "Sturmtitan",
    "Knochendrache",
    "Ätherwächter",
    "Schattenfürst",
    "Sternenkönig",
    "Urzeitbestie",
    "Weltenschlinger"
  };

  public static int phase(double health, double max) {
    return health / max > .7 ? 1 : health / max > .35 ? 2 : 3;
  }

  public static boolean unlocked(Profile p, int z, int mode) {
    return z >= 0
        && z <= p.zone
        && mode >= 0
        && mode <= 2
        && (mode == 0 || p.bossWins[z * 3 + mode - 1] > 0);
  }

  public static Attack attack(int zone, int sequence) {
    Attack[][] patterns = {
      {Attack.CONE, Attack.RING, Attack.IMPACT},
      {Attack.BEAM, Attack.IMPACT, Attack.RING},
      {Attack.SPORES, Attack.CONE, Attack.IMPACT},
      {Attack.BEAM, Attack.RING, Attack.CONE},
      {Attack.IMPACT, Attack.RING, Attack.BEAM},
      {Attack.RUNES, Attack.BEAM, Attack.CONE},
      {Attack.IMPACT, Attack.BEAM, Attack.RUNES}
    };
    return patterns[Math.floorMod(zone, patterns.length)][Math.floorMod(sequence, 3)];
  }

  /** Second-phase and third-phase move of each of the 17 mine bosses. */
  private static final Attack[][] SIGNATURE = {
    {Attack.CHARGE, Attack.NOVA}, // Steinwächter
    {Attack.CROSS, Attack.FALL}, // Kristallkönigin
    {Attack.NOVA, Attack.CHARGE}, // Sporenhüter
    {Attack.CHARGE, Attack.CROSS}, // Tiefenwächter
    {Attack.FALL, Attack.NOVA}, // Magmakönig
    {Attack.CROSS, Attack.CHARGE}, // Runenwächter
    {Attack.NOVA, Attack.CROSS}, // Leerenfürst
    {Attack.CHARGE, Attack.FALL}, // Kernkoloss
    {Attack.CROSS, Attack.NOVA}, // Spiegelhexe
    {Attack.NOVA, Attack.FALL}, // Giftmutter
    {Attack.CHARGE, Attack.CROSS}, // Sturmtitan
    {Attack.FALL, Attack.CHARGE}, // Knochendrache
    {Attack.CROSS, Attack.FALL}, // Ätherwächter
    {Attack.NOVA, Attack.CHARGE}, // Schattenfürst
    {Attack.FALL, Attack.CROSS}, // Sternenkönig
    {Attack.CHARGE, Attack.NOVA}, // Urzeitbestie
    {Attack.CROSS, Attack.NOVA} // Weltenschlinger
  };

  /**
   * 0.21.0 attack kit of a mine boss: phase 1 knows two moves, phase 2 adds the third zone move
   * and its first signature, phase 3 the second signature. Veteran adds the Felsregen in phase 3,
   * Albtraum already in phase 2.
   */
  public static List<Attack> kit(int zone, int phase, int mode) {
    Set<Attack> out = new LinkedHashSet<>();
    for (int step = 0; step < (phase >= 2 ? 3 : 2); step++) out.add(attack(zone, step));
    Attack[] sig = SIGNATURE[Math.floorMod(zone, SIGNATURE.length)];
    if (phase >= 2) out.add(sig[0]);
    if (phase >= 3) out.add(sig[1]);
    if (mode >= 2 && phase >= 2 || mode == 1 && phase >= 3) out.add(Attack.FALL);
    return List.copyOf(out);
  }

  /** The n-th attack: the kit in a fresh shuffled order every round, never twice in a row. */
  public static Attack next(int zone, int phase, int mode, int n, long seed) {
    List<Attack> kit = kit(zone, phase, mode);
    return order(kit, n / kit.size(), seed + phase * 131L).get(n % kit.size());
  }

  private static List<Attack> order(List<Attack> kit, int round, long seed) {
    Attack previous = null;
    List<Attack> out = null;
    for (int r = 0; r <= round; r++) {
      out = new ArrayList<>(kit);
      Collections.shuffle(out, new Random(seed * 31 + r * 7919L));
      if (out.size() > 1 && out.getFirst() == previous) Collections.swap(out, 0, 1);
      previous = out.getLast();
    }
    return out;
  }

  /** Phase change: the boss roars, is untouchable for a moment and pushes everyone back. */
  public static final int PHASE_SHIELD = 40;
  public static final double PHASE_PUSH = 6;

  public static String phaseLine(int phase) {
    return phase == 2
        ? "PHASE 2 – er wird wütend und lernt neue Angriffe!"
        : "PHASE 3 – letzte Phase: alles, was er hat!";
  }

  // ---- 0.21.0 geometry ----
  public static final double CHARGE_LENGTH = 12, CHARGE_HALF_WIDTH = 1.5;
  public static final double CROSS_LENGTH = 11, CROSS_HALF_WIDTH = 1.1;
  public static final double NOVA_SAFE = 3.5, NOVA_RADIUS = 13;
  public static final double FALL_RADIUS = 2.2;
  public static final int FALL_ROCKS = 6;

  /** Felsregen: one rock on every fighter plus a few around the arena centre. */
  public static List<double[]> rocks(List<double[]> players, long seed) {
    Random r = new Random(seed);
    List<double[]> out = new ArrayList<>();
    for (double[] p : players) out.add(new double[] {p[0], p[1]});
    while (out.size() < FALL_ROCKS + players.size() - 1) {
      double a = r.nextDouble() * Math.PI * 2, d = 2 + r.nextDouble() * 7;
      out.add(new double[] {Math.cos(a) * d, Math.sin(a) * d});
    }
    return out;
  }

  public static boolean hit(
      Attack attack, double dx, double dz, double fx, double fz, boolean airborne) {
    double length = Math.hypot(dx, dz),
        forward = dx * fx + dz * fz,
        side = Math.abs(dx * fz - dz * fx);
    return switch (attack) {
      case CONE -> length <= 6 && (length < .3 || forward / length >= .55);
      case RING -> length >= 2 && length <= 6 && !airborne;
      case BEAM -> forward >= 0 && forward <= 13 && side <= 1.2;
      case IMPACT, SPORES -> length <= 2.8;
      case RUNES -> length <= 10 && side > 1.8;
      case CHARGE -> forward >= 0 && forward <= CHARGE_LENGTH && side <= CHARGE_HALF_WIDTH;
      case CROSS ->
          Math.abs(forward) <= CROSS_LENGTH && side <= CROSS_HALF_WIDTH
              || side <= CROSS_LENGTH && Math.abs(forward) <= CROSS_HALF_WIDTH;
      case NOVA -> length > NOVA_SAFE && length <= NOVA_RADIUS;
      case FALL -> length <= FALL_RADIUS;
    };
  }

  private BossRules() {}
}
