package de.deepforge.game;

/** Pure attack geometry and mode rules shared by combat and regression tests. */
public final class BossRules {
  public enum Attack {
    CONE,
    RING,
    BEAM,
    IMPACT,
    SPORES,
    RUNES
  }

  public static final String[] NAMES = {
    "Steinwächter",
    "Kristallkönigin",
    "Sporenhüter",
    "Tiefenwächter",
    "Magmakönig",
    "Runenwächter",
    "Leerenfürst",
    "Kernkoloss",
    "Spiegelhexe",
    "Giftmutter",
    "Sturmtitan",
    "Knochendrache",
    "Ätherwächter",
    "Schattenfürst",
    "Sternenkönig",
    "Urzeitbestie",
    "Weltenschlinger"
  };

  public static int phase(double health, double max) {
    return health / max > .7 ? 1 : health / max > .35 ? 2 : 3;
  }

  public static boolean unlocked(Profile p, int z, int mode) {
    return z >= 0
        && z <= p.zone
        && mode >= 0
        && mode <= 2
        && (mode == 0 || p.bossWins[z * 3 + mode - 1] > 0);
  }

  public static Attack attack(int zone, int sequence) {
    Attack[][] patterns = {
      {Attack.CONE, Attack.RING, Attack.IMPACT},
      {Attack.BEAM, Attack.IMPACT, Attack.RING},
      {Attack.SPORES, Attack.CONE, Attack.IMPACT},
      {Attack.BEAM, Attack.RING, Attack.CONE},
      {Attack.IMPACT, Attack.RING, Attack.BEAM},
      {Attack.RUNES, Attack.BEAM, Attack.CONE},
      {Attack.IMPACT, Attack.BEAM, Attack.RUNES}
    };
    return patterns[Math.floorMod(zone, patterns.length)][Math.floorMod(sequence, 3)];
  }

  public static boolean hit(
      Attack attack, double dx, double dz, double fx, double fz, boolean airborne) {
    double length = Math.hypot(dx, dz),
        forward = dx * fx + dz * fz,
        side = Math.abs(dx * fz - dz * fx);
    return switch (attack) {
      case CONE -> length <= 6 && (length < .3 || forward / length >= .55);
      case RING -> length >= 2 && length <= 6 && !airborne;
      case BEAM -> forward >= 0 && forward <= 13 && side <= 1.2;
      case IMPACT, SPORES -> length <= 2.8;
      case RUNES -> length <= 10 && side > 1.8;
    };
  }

  private BossRules() {}
}
