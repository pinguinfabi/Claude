package de.deepforge.game;

/** The steam drone companion "Funke": costs, levels, modules and skins. */
public final class DroneRules {
  private DroneRules() {}

  public static final int MAX_LEVEL = 10;
  public static final long BUILD_MONEY = 5000;
  public static final String[] MODULES = {"Sammler", "Geschütz", "Sanitäter"};
  public static final String[] MODULE_INFO = {
    "Findet im Bergwerk regelmäßig Erz für deinen Rucksack",
    "Schießt Dampfbolzen auf Gegner in deiner Nähe",
    "Heilt dich, wenn dein Leben unter 70 % fällt"
  };
  public static final String[] SKINS = {"Messing", "Kupfer", "Kristall", "Glut"};
  public static final int[] SKIN_LEVEL = {1, 3, 6, 10};

  public static long upgradeMoney(int level) {
    return Math.round(2500 * Math.pow(level, 1.6));
  }

  /** 0.22.0: upgrades grow with the player's mine. */
  public static long upgradeMoney(Profile p, int level) {
    return Math.round(upgradeMoney(level) * Economy.lateScale(p.zone));
  }

  public static long upgradeDust(int level) {
    return 8L * level;
  }

  public static int upgradeRelics(int level) {
    return level >= 5 ? level / 3 : 0;
  }

  /** Seconds between ore finds of the collector. */
  public static int collectorSeconds(int level) {
    return Math.max(12, 42 - level * 3);
  }

  /** Ore per find; the last level adds a bonus ore so level 10 is worth buying. */
  public static int collectorOre(int level) {
    return 1 + level / 3 + (level >= MAX_LEVEL ? 1 : 0);
  }

  /** Ticks between turret shots and the share of the owner's hit damage per shot. */
  public static int turretTicks(int level) {
    return Math.max(14, 34 - 2 * level);
  }

  public static double turretShare(int level) {
    return .25 + .04 * level;
  }

  public static int medicSeconds(int level) {
    return Math.max(8, 22 - level);
  }

  public static double medicHeal(int level) {
    return 1.5 + .35 * level;
  }

  public static boolean skinUnlocked(int level, int skin) {
    return skin >= 0 && skin < SKINS.length && level >= SKIN_LEVEL[skin];
  }

  public static String effect(int module, int level) {
    return switch (module) {
      case 0 -> "Alle " + collectorSeconds(level) + " s +" + collectorOre(level) + " Erz";
      case 1 ->
          "Alle " + String.format(java.util.Locale.GERMANY, "%.1f", turretTicks(level) / 20.0)
              + " s ein Bolzen (" + Math.round(turretShare(level) * 100) + " % deines Trefferschadens)";
      default ->
          "Alle " + medicSeconds(level) + " s +" + String.format(java.util.Locale.GERMANY, "%.1f", medicHeal(level)) + " LP unter 70 % Leben";
    };
  }

  public static String build(Profile p) {
    if (p.droneLevel > 0) return "Funke ist schon gebaut.";
    if (p.money < BUILD_MONEY) return "Dir fehlen " + (BUILD_MONEY - p.money) + " $ für Funke.";
    p.money -= BUILD_MONEY;
    p.droneLevel = 1;
    p.droneModule = 0;
    p.droneSkin = 0;
    p.droneHidden = false;
    return "Funke ist gebaut! Deine Dampfdrohne folgt dir ab jetzt. /df drohne";
  }

  public static String upgrade(Profile p) {
    if (p.droneLevel <= 0) return "Zuerst Funke bauen.";
    if (p.droneLevel >= MAX_LEVEL) return "Funke ist bereits auf Höchststufe.";
    int l = p.droneLevel;
    long money = upgradeMoney(p, l), dust = upgradeDust(l);
    int relics = upgradeRelics(l);
    java.util.List<String> missing = new java.util.ArrayList<>();
    if (p.money < money) missing.add((money - p.money) + " $");
    if (p.dust < dust) missing.add((dust - p.dust) + " Schmiedestaub");
    if (p.relics < relics) missing.add((relics - p.relics) + " Relikte");
    if (!missing.isEmpty()) return "Für Stufe " + (l + 1) + " fehlen " + String.join(", ", missing) + ".";
    p.money -= money;
    p.dust -= dust;
    p.relics -= relics;
    p.droneLevel++;
    String skin = "";
    for (int s = 0; s < SKINS.length; s++)
      if (SKIN_LEVEL[s] == p.droneLevel) skin = " Neues Aussehen: " + SKINS[s] + "!";
    return "Funke ist jetzt Stufe " + p.droneLevel + ". " + effect(p.droneModule, p.droneLevel) + "." + skin;
  }

  public static String module(Profile p, int module) {
    if (p.droneLevel <= 0) return "Zuerst Funke bauen.";
    if (module < 0 || module >= MODULES.length) return "Unbekanntes Modul.";
    p.droneModule = module;
    return "Funke nutzt jetzt das Modul " + MODULES[module] + ": " + effect(module, p.droneLevel) + ".";
  }

  public static String skin(Profile p, int skin) {
    if (p.droneLevel <= 0) return "Zuerst Funke bauen.";
    if (!skinUnlocked(p.droneLevel, skin))
      return skin >= 0 && skin < SKINS.length
          ? "„" + SKINS[skin] + "“ gibt es ab Funke-Stufe " + SKIN_LEVEL[skin] + "."
          : "Unbekanntes Aussehen.";
    p.droneSkin = skin;
    return "Funke trägt jetzt " + SKINS[skin] + ".";
  }

  public static String toggle(Profile p) {
    if (p.droneLevel <= 0) return "Zuerst Funke bauen.";
    p.droneHidden = !p.droneHidden;
    return p.droneHidden ? "Funke ruht in der Werkstatt." : "Funke begleitet dich wieder.";
  }
}
