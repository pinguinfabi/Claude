package de.deepforge.game;

/** Rear hits queue a telegraphed counter, without adding a cooldown to player attacks. */
public final class BossPressure {
  public static final double RADIUS = 4.5;
  public static final int WARNING_TICKS = 28;

  public enum Step {
    NONE,
    START,
    WARNING,
    STRIKE
  }

  private int hits;
  private long lastHit = -1000, readyAt, resolveAt;

  public void hit(long tick, double facing, double distanceSquared) {
    if (facing > -.35 || distanceSquared > 30 || tick < readyAt || resolveAt != 0) return;
    if (tick - lastHit > 60) hits = 0;
    hits = Math.min(3, hits + 1);
    lastHit = tick;
  }

  public Step step(long tick, boolean canStart) {
    if (resolveAt != 0) {
      if (tick < resolveAt) return Step.WARNING;
      resolveAt = 0;
      readyAt = tick + 140;
      return Step.STRIKE;
    }
    if (tick - lastHit > 60) hits = 0;
    if (!canStart || hits < 3 || tick < readyAt) return Step.NONE;
    hits = 0;
    resolveAt = tick + WARNING_TICKS;
    return Step.START;
  }

  public static boolean inSweep(double dx, double dy, double dz) {
    return Math.abs(dy) <= 3 && dx * dx + dz * dz <= RADIUS * RADIUS;
  }
}
