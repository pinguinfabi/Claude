package de.deepforge.game;

/** Persistent progression with no wall-clock resets or repeatable discovery rewards. */
public final class Industry {
  public static final String[] RESEARCH = {
    "Bohrtechnik", "Kühlkreislauf", "Arbeiterschulung", "Handelsnetz", "Logistik"
  };
  public static final String[] EFFECT = {
    "+8 % Abbaugeschwindigkeit/Stufe",
    "+1 Kühlung/s; -0,4 Hitze/Erz pro Stufe",
    "+1 Ware/Arbeiter und Minute pro Stufe",
    "+5 % Auftrags- und Händlererlös/Stufe",
    "+240 Lagerplätze; +1 Offline-Stunde/Stufe"
  };
  public static final long[] COLLECTION = {500, 2000, 10000};

  public record Contract(int kind, int sequence, int zone, long amount, long money, int notes) {}

  public static long researchCost(Profile p, int track) {
    return 1500L * (p.research[track] + 1) * (p.research[track] + 1);
  }

  public static int noteCost(Profile p, int track) {
    return 3 + p.research[track] * 2;
  }

  public static String research(Profile p, int track) {
    if (track < 0 || track >= RESEARCH.length) return "Unbekannte Forschung.";
    int level = p.research[track];
    if (level >= 5) return "Forschung abgeschlossen.";
    if (p.tool < level) return "Benötigt Werkzeugstufe " + level + ".";
    long cost = researchCost(p, track);
    int notes = noteCost(p, track), bars = 4 * (level + 1);
    if (p.money < cost || p.researchNotes < notes || p.bars[0] < bars)
      return "Benötigt " + cost + " $, " + notes + " Unterlagen und " + bars + " Eisenbarren.";
    p.money -= cost;
    p.researchNotes -= notes;
    p.bars[0] -= bars;
    p.research[track]++;
    return RESEARCH[track] + " auf Stufe " + p.research[track] + " erforscht.";
  }

  public static Contract contract(Profile p, int kind) {
    if (kind < 0 || kind > 2) throw new IllegalArgumentException("contract");
    int seq = p.contracts[kind], zone = seq % (p.zone + 1);
    long amount = (kind == 0 ? 48 : kind == 1 ? 16 : 8) * (1 + seq % 4);
    long value =
        kind == 0 ? Zone.at(zone).orePrice : kind == 1 ? Zone.at(zone).barPrice : 60L * (zone + 1);
    long money = Math.round(amount * value * (kind == 2 ? 1.25 : 1.75) * (1 + p.research[3] * .05));
    return new Contract(kind, seq, zone, amount, money, 2 + seq % 3);
  }

  public static String fulfill(Profile p, int kind, int expectedSequence) {
    Contract c = contract(p, kind);
    if (c.sequence() != expectedSequence) return "Auftrag bereits erledigt. Tafel neu öffnen.";
    long available =
        kind == 0
            ? p.bag[c.zone()] + p.stock[c.zone()]
            : kind == 1 ? p.bars[c.zone()] : p.monsterParts[c.zone()];
    if (available < c.amount())
      return "Es fehlen " + (c.amount() - available) + " Einheiten für diesen Auftrag.";
    if (kind == 0) {
      long bag = Math.min(c.amount(), p.bag[c.zone()]);
      p.bag[c.zone()] -= bag;
      p.stock[c.zone()] -= c.amount() - bag;
    } else if (kind == 1) p.bars[c.zone()] -= c.amount();
    else p.monsterParts[c.zone()] -= c.amount();
    p.money += c.money();
    p.lifetimeRevenue += c.money();
    p.researchNotes += c.notes();
    p.contracts[kind]++;
    p.orders++;
    if (p.orders % 5 == 0) p.relics++;
    return "Auftrag geliefert: +" + c.money() + " $ und +" + c.notes() + " Forschungsunterlagen.";
  }

  public static String discover(Profile p, int id) {
    if (id < 0 || id >= 21 || id / 3 > p.zone) return "Gebiet gesperrt.";
    if (p.expeditions[id]) return "Fundstelle bereits geborgen.";
    p.expeditions[id] = true;
    p.researchNotes += 3;
    p.dust += 2 + id / 3;
    long cash = 250L * (id / 3 + 1);
    p.money += cash;
    p.lifetimeRevenue += cash;
    if (p.expeditions[id / 3 * 3] && p.expeditions[id / 3 * 3 + 1] && p.expeditions[id / 3 * 3 + 2])
      p.relics++;
    return "Fund geborgen: +"
        + cash
        + " $, +3 Unterlagen, +"
        + (2 + id / 3)
        + " Staub. Drei Funde im Gebiet: +1 Relikt.";
  }

  public static int collectionTier(Profile p, int zone) {
    return Math.max(p.collectionTiers[zone], p.collectionClaimed[zone] ? 1 : 0);
  }

  public static String collection(Profile p, int zone) {
    if (zone < 0 || zone > p.zone) return "Gebiet gesperrt.";
    int tier = collectionTier(p, zone);
    if (tier >= 3) return "Sammlung vollständig gemeistert.";
    if (p.collected[zone] < COLLECTION[tier])
      return "Sammle selbst " + COLLECTION[tier] + " Erze dieses Gebiets.";
    p.collectionTiers[zone] = tier + 1;
    p.collectionClaimed[zone] = true;
    p.relics += 3 + tier * 2;
    p.researchNotes += tier * 3;
    return "Sammlungsrang "
        + (tier + 1)
        + ": +"
        + (3 + tier * 2)
        + " Relikte und +"
        + (tier * 3)
        + " Unterlagen.";
  }

  public static String stopped(Profile p, Profile.Worker w) {
    if (w.paused) return "Pausiert";
    if (p.budget < wage(w)) return "Betriebsbudget fehlt";
    if (w.job != Profile.Job.TRADER && p.fuel < 1) return "Brennstoff fehlt";
    if (w.job == Profile.Job.MINER && p.stockUsed() >= p.stockCapacity()) return "Lager voll";
    if (w.job == Profile.Job.SMELTER && (p.furnace == 0 || p.stock[w.zone] < 2))
      return "Wartet auf Schmelze/Erz";
    if (w.job == Profile.Job.TRADER && p.stock[w.zone] + p.bars[w.zone] == 0)
      return "Wartet auf Ware";
    return "";
  }

  public static long wage(Profile.Worker w) {
    return Math.max(1, 2 + w.level - (w.specialization == 2 ? 1 : 0));
  }

  private Industry() {}
}
