package de.deepforge.game;

/** Persistent progression with no wall-clock resets or repeatable discovery rewards. */
public final class Industry {
  public static final String[] RESEARCH = {
    "Bohrtechnik", "Kühlkreislauf", "Arbeiterschulung", "Handelsnetz", "Logistik"
  };
  public static final String[] EFFECT = {
    "+8 % Abbaugeschwindigkeit/Stufe",
    "+1 Kühlung/s; -0,4 Hitze/Erz pro Stufe",
    "+0,25 Waren/Arbeiter und Minute pro Stufe",
    "+5 % Auftrags- und Händlererlös/Stufe",
    "+240 Lagerplätze; +1 Offline-Stunde/Stufe"
  };
  public static final long[] COLLECTION = {500, 2000, 10000};

  public record Contract(int kind, int sequence, int zone, long amount, long money, int notes) {}

  public static long researchCost(Profile p, int track) {
    return Economy.grown(1500, p.research[track], 2);
  }

  public static int noteCost(Profile p, int track) {
    return 3 + p.research[track] * 2;
  }

  public static String research(Profile p, int track) {
    if (track < 0 || track >= RESEARCH.length) return "Unbekannte Forschung.";
    int level = p.research[track];
    if (level >= 5) return "Forschung abgeschlossen.";
    if (p.tool < level) return "Benötigt Werkzeugstufe " + level + ".";
    long cost = researchCost(p, track);
    int notes = noteCost(p, track), bars = 4 * (level + 1);
    if (p.money < cost || p.researchNotes < notes || p.bars[0] < bars)
      return "Benötigt " + cost + " $, " + notes + " Unterlagen und " + bars + " Eisenbarren.";
    p.money -= cost;
    p.researchNotes -= notes;
    p.bars[0] -= bars;
    p.research[track]++;
    return RESEARCH[track]
        + " auf Stufe "
        + p.research[track]
        + " erforscht · jetzt "
        + researchTotal(p, track)
        + ".";
  }

  /** What all researched levels of a track currently give, in player terms. */
  public static String researchTotal(Profile p, int track) {
    int level = p.research[track];
    return switch (track) {
      case 0 -> "+" + level * 8 + " % Abbautempo";
      case 1 ->
          "+"
              + level
              + " Kühlung/s, "
              + String.format(java.util.Locale.GERMAN, "%.1f", level * .4)
              + " weniger Hitze je Erz";
      case 2 -> String.format(java.util.Locale.GERMAN, "+%.2f Waren je Arbeiter und Minute", level * .25);
      case 3 -> "+" + level * 5 + " % Auftrags- und Händlererlös";
      case 4 -> "+" + level * 240 + " Lagerplätze, +" + level + " Offline-Stunden";
      default -> "";
    };
  }

  public static Contract contract(Profile p, int kind) {
    if (kind < 0 || kind > 2) throw new IllegalArgumentException("contract");
    int seq = p.contracts[kind], zone = seq % (p.zone + 1);
    long amount = (kind == 0 ? 48 : kind == 1 ? 16 : 8) * (1 + seq % 4);
    long value =
        kind == 0 ? Zone.at(zone).orePrice : kind == 1 ? Zone.at(zone).barPrice : 60L * (zone + 1);
    long money = Math.round(amount * value * (kind == 2 ? 1.25 : 1.75) * (1 + p.research[3] * .05));
    return new Contract(kind, seq, zone, amount, money, 2 + seq % 3);
  }

  public static String fulfill(Profile p, int kind, int expectedSequence) {
    Contract c = contract(p, kind);
    if (c.sequence() != expectedSequence) return "Auftrag bereits erledigt. Tafel neu öffnen.";
    long available =
        kind == 0
            ? p.bag[c.zone()] + p.stock[c.zone()]
            : kind == 1 ? p.bars[c.zone()] : p.monsterParts[c.zone()];
    if (available < c.amount())
      return "Es fehlen " + (c.amount() - available) + " Einheiten für diesen Auftrag.";
    if (kind == 0) {
      long bag = Math.min(c.amount(), p.bag[c.zone()]);
      p.bag[c.zone()] -= bag;
      p.stock[c.zone()] -= c.amount() - bag;
    } else if (kind == 1) p.bars[c.zone()] -= c.amount();
    else p.monsterParts[c.zone()] -= c.amount();
    p.money += c.money();
    p.lifetimeRevenue += c.money();
    p.researchNotes += c.notes();
    p.contracts[kind]++;
    p.orders++;
    if (p.orders % 5 == 0) p.relics++;
    return "Auftrag geliefert: +" + c.money() + " $ und +" + c.notes() + " Forschungsunterlagen.";
  }

  /** 0.22.3: a hidden find pays a few minutes of the mine's income (before: 250 $ × mine). */
  public static long findCash(int zone) {
    return Math.round(250L * Math.max(zone + 1, 2 * Economy.scale(zone)));
  }

  public static String discover(Profile p, int id) {
    if (id < 0 || id >= Zone.COUNT * 3 || id / 3 > p.zone) return "Gebiet gesperrt.";
    if (p.expeditions[id]) return "Fundstelle bereits geborgen.";
    p.expeditions[id] = true;
    p.researchNotes += 3;
    p.dust += 2 + id / 3;
    long cash = findCash(id / 3);
    p.money += cash;
    p.lifetimeRevenue += cash;
    if (p.expeditions[id / 3 * 3] && p.expeditions[id / 3 * 3 + 1] && p.expeditions[id / 3 * 3 + 2])
      p.relics++;
    return "Fund geborgen: +"
        + cash
        + " $, +3 Unterlagen, +"
        + (2 + id / 3)
        + " Staub. Drei Funde im Gebiet: +1 Relikt.";
  }

  public static int collectionTier(Profile p, int zone) {
    return Math.max(p.collectionTiers[zone], p.collectionClaimed[zone] ? 1 : 0);
  }

  public static String collection(Profile p, int zone) {
    if (zone < 0 || zone > p.zone) return "Gebiet gesperrt.";
    int tier = collectionTier(p, zone);
    if (tier >= 3) return "Sammlung vollständig gemeistert.";
    if (p.collected[zone] < COLLECTION[tier])
      return "Sammle selbst " + COLLECTION[tier] + " Erze dieses Gebiets.";
    p.collectionTiers[zone] = tier + 1;
    p.collectionClaimed[zone] = true;
    p.relics += 3 + tier * 2;
    p.researchNotes += tier * 3;
    return "Sammlungsrang "
        + (tier + 1)
        + ": +"
        + (3 + tier * 2)
        + " Relikte und +"
        + (tier * 3)
        + " Unterlagen.";
  }

  /** Workers need breaks: after 50 minutes on shift they rest for 10. */
  public static final int SHIFT_MINUTES = 50, BREAK_MINUTES = 10;

  /** What the player can do about a stop reason; "" when nothing is needed (a break). */
  public static String fix(String reason) {
    if (reason.startsWith("Betriebsbudget")) return "Betrieb → Budget aufladen oder „Löhne automatisch zahlen“ einschalten";
    if (reason.startsWith("Brennstoff")) return "Betrieb → Brennstoff kaufen";
    if (reason.equals("Lager voll")) return "Erz verkaufen, Händler einstellen oder das Lager ausbauen";
    if (reason.equals("Holzlager voll")) return "Holz verkaufen oder das Holzlager ausbauen";
    if (reason.equals("Pausiert")) return "im Arbeiter-Menü fortsetzen";
    if (reason.startsWith("Wartet auf Schmelze")) return "Schmelze bauen oder mehr Erz fördern";
    if (reason.startsWith("Wartet auf Ware")) return "Erz oder Barren ins Lager bringen";
    return "";
  }

  public static String stopped(Profile p, Profile.Worker w) {
    if (w.paused) return "Pausiert";
    if (w.rest > 0) return "Macht Pause (" + w.rest + " Min.)";
    if (p.budget < wage(w) && !(p.autoBudget && p.money >= wage(w))) return "Betriebsbudget fehlt";
    if (usesFuel(w.job) && p.fuel < 1 && !(p.autoBudget && p.money >= 60)) return "Brennstoff fehlt";
    if (w.job == Profile.Job.LUMBERJACK && Forestry.used(p) >= Forestry.capacity(p))
      return "Holzlager voll";
    if (w.job == Profile.Job.MINER && p.stockUsed() >= p.stockCapacity()) return "Lager voll";
    if (w.job == Profile.Job.SMELTER && (p.furnace == 0 || p.stock[w.zone] < 2))
      return "Wartet auf Schmelze/Erz";
    if (w.job == Profile.Job.TRADER && p.stock[w.zone] + sellableBars(p, w.zone) == 0)
      return "Wartet auf Ware";
    // What the last production minute ran into (e.g. the budget for the full wage).
    return w.blocked == null ? "" : w.blocked;
  }

  /** Bars the next research and the open bar contract still need stay in storage. */
  public static long barReserve(Profile p, int zone) {
    long reserve = 0;
    if (zone == 0)
      for (int level : p.research) if (level < 5) reserve = Math.max(reserve, 4L * (level + 1));
    Contract bars = contract(p, 1);
    if (bars.zone() == zone) reserve += bars.amount();
    return reserve;
  }

  public static long sellableBars(Profile p, int zone) {
    return Math.max(0, p.bars[zone] - barReserve(p, zone));
  }

  /** Traders and lumberjacks need no fuel; miners and smelters burn one per worked minute. */
  public static boolean usesFuel(Profile.Job job) {
    return job == Profile.Job.MINER || job == Profile.Job.SMELTER;
  }

  /** Wood type a lumberjack chops, limited to the types the forest has unlocked. */
  public static int woodType(Profile p, Profile.Worker w) {
    return Math.clamp(w.zone, 0, Math.clamp(p.forestTier, 0, Forestry.WOODS.length - 1));
  }

  /**
   * Goods per minute, fractional (carried over between minutes): a fresh worker 0.5, a fully
   * trained specialist with maxed research about 3.5. Was 2 to 10 whole units before 0.8.1.
   */
  public static double rate(Profile p, Profile.Worker w) {
    return .5 + .35 * (Math.max(1, w.level) - 1) + (w.specialization == 1 ? .4 : 0) + .25 * p.research[2];
  }

  /** Share of the value of their goods that workers take as wage on top of the base wage. */
  public static final double WAGE_SHARE = .20, TRADER_SHARE = .10;

  /** Full wage for one minute's goods: base wage plus a share of what the goods are worth. */
  public static long wage(Profile.Worker w, long value) {
    double share = w.job == Profile.Job.TRADER ? TRADER_SHARE : WAGE_SHARE;
    if (w.specialization == 2) share *= .75;
    return wage(w) + Math.round(Math.max(0, value) * share);
  }

  public static long unitsPerMinute(Profile p, Profile.Worker w) {
    return Math.round(rate(p, w));
  }

  /** Market value a worker handles per hour at full supply, before wages and fuel. */
  public static long hourlyValue(Profile p, Profile.Worker w) {
    Zone z = Zone.at(Math.clamp(w.zone, 0, p.zone));
    long units = Math.round(rate(p, w) * 60);
    return switch (w.job) {
      case MINER -> units * z.orePrice;
      case SMELTER -> units * Math.max(0, z.barPrice - 2 * z.orePrice);
      case TRADER -> units * z.orePrice + 10 * z.barPrice;
      case LUMBERJACK -> units * Forestry.PRICES[woodType(p, w)];
    };
  }

  public static final int DUST_EVERY = 45, RELIC_EVERY = 240, NOTE_EVERY = 60, BONUS_EVERY = 60;
  public static final int RESIN_EVERY = 90;

  /** Deterministic finds by worked minutes, so online and offline shifts give the same. */
  public static String workerFind(Profile p, Profile.Worker w) {
    long m = w.workMinutes;
    if (m <= 0) return "";
    switch (w.job) {
      case MINER -> {
        if (m % RELIC_EVERY == 0) {
          p.relics++;
          return "relic";
        }
        if (m % DUST_EVERY == 0) {
          p.dust++;
          return "dust";
        }
      }
      case SMELTER -> {
        if (m % NOTE_EVERY == 0) {
          p.researchNotes++;
          return "note";
        }
      }
      case LUMBERJACK -> {
        if (m % RESIN_EVERY == 0) {
          p.resin++;
          return "resin";
        }
      }
      case TRADER -> {
        if (m % BONUS_EVERY == 0) {
          long bonus = 10 * Zone.at(Math.clamp(w.zone, 0, p.zone)).barPrice;
          p.money += bonus;
          p.lifetimeRevenue += bonus;
          return "bonus:" + bonus;
        }
      }
    }
    return "";
  }

  public static String nextFind(Profile.Worker w) {
    long m = w.workMinutes;
    return switch (w.job) {
      case MINER ->
          "Nächster Fund: Staub in "
              + (DUST_EVERY - m % DUST_EVERY)
              + " Min. · Relikt in "
              + (RELIC_EVERY - m % RELIC_EVERY)
              + " Min.";
      case SMELTER -> "Nächste Forschungsunterlage in " + (NOTE_EVERY - m % NOTE_EVERY) + " Min.";
      case TRADER -> "Nächster Handelsbonus in " + (BONUS_EVERY - m % BONUS_EVERY) + " Min.";
      case LUMBERJACK -> "Nächstes Harz in " + (RESIN_EVERY - m % RESIN_EVERY) + " Min.";
    };
  }

  public static long wage(Profile.Worker w) {
    return Math.max(1, 2 + w.level - (w.specialization == 2 ? 1 : 0));
  }

  public static String barName(int zone) {
    String ore = Zone.at(zone).oreName;
    return ore.substring(0, ore.length() - 3) + "barren";
  }

  /** Manual smelting of a chosen ore: 2 stored ore and 1 fuel per bar. */
  public static String smelt(
      Profile p, int zone, long max, java.util.function.DoubleSupplier random) {
    if (zone < 0 || zone > Zone.LAST) return "Unbekannte Erzart.";
    if (zone > p.zone) return "Dieses Gebiet ist noch gesperrt.";
    if (p.furnace == 0) return "Baue zuerst eine Schmelze (Betrieb).";
    String ore = Zone.at(zone).oreName;
    if (p.stock[zone] < 2)
      return "Zu wenig "
          + ore
          + " im Lager ("
          + p.stock[zone]
          + "). Erz aus dem Rucksack zuerst einlagern.";
    if (p.fuel < 1) return "Kein Brennstoff. Im Betrieb nachkaufen.";
    long n = Math.min(Math.max(1, max), Math.min(p.stock[zone] / 2, p.fuel));
    p.stock[zone] -= n * 2;
    p.bars[zone] += n;
    p.manualSmelted += n;
    p.fuel -= n;
    double saving = Gear.stats(p).efficiency();
    long saved = 0;
    for (long i = 0; i < n; i++) if (random.getAsDouble() < saving) saved++;
    p.fuel += saved;
    return n
        + " "
        + barName(zone)
        + " geschmolzen"
        + (saved > 0 ? " · " + saved + " Brennstoff gespart" : "")
        + ". Bestand: "
        + p.bars[zone]
        + " "
        + barName(zone)
        + ".";
  }

  private Industry() {}
}
