package de.deepforge.world;

import de.deepforge.game.BossPatterns;
import de.deepforge.game.BossPatterns.Attack;
import java.time.Duration;
import java.util.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.util.Vector;

/**
 * One dungeon boss fight: three phases, telegraphed attacks from {@link BossPatterns}, a shield
 * during phase changes, weak spots after big attacks and an enrage timer.
 */
final class BossBrain {
  /** What the boss needs from its dungeon run. */
  interface Arena {
    List<Player> living();

    void hurt(Player p, double damage);

    void say(String text);

    /** Arena centre on the floor. */
    Location center();

    double baseDamage();

    int zone();

    int level();

    long seed();

    /** Called shortly before an attack lands on a player who is standing in it. */
    void danger(Player p, Attack attack);
  }

  private final Arena arena;
  private final Mob boss;
  private final long started;
  private int phase, cast;
  private boolean enraged;
  private Attack attack;
  private long landAt, nextAt, shieldUntil, exhaustedUntil;
  private Location target, secondary, safe;
  private Vector direction;
  private double spinStart, gap;
  private int spinDir = 1;
  private List<Location> shards = List.of();
  private final Set<UUID> hitThisAttack = new HashSet<>(), warned = new HashSet<>();
  private final Set<Attack> introduced = EnumSet.noneOf(Attack.class);
  // Players hit by any big attack; the others earn the flawless bonus.
  final Set<UUID> struck = new HashSet<>();

  BossBrain(Arena arena, Mob boss, long now) {
    this.arena = arena;
    this.boss = boss;
    started = now;
    nextAt = now + 60;
  }

  boolean immune(long now) {
    return now < shieldUntil;
  }

  boolean exhausted(long now) {
    return now < exhaustedUntil;
  }

  double damageTaken(long now) {
    return exhausted(now) ? BossPatterns.EXHAUSTED_BONUS : 1;
  }

  /** While casting the boss stands still. */
  boolean busy() {
    return attack != null;
  }

  String name() {
    return BossPatterns.BOSS_NAMES[Math.floorMod(arena.zone(), 7)];
  }

  String status(long now) {
    return name()
        + " · Phase "
        + (phase + 1)
        + "/3"
        + (immune(now) ? " · IMMUN" : exhausted(now) ? " · SCHWACHSTELLE!" : "")
        + (enraged ? " · WÜTEND" : "");
  }

  void tick(long now, double hp, double max) {
    int nextPhase = BossPatterns.phase(hp, max);
    if (nextPhase > phase) phaseChange(now, nextPhase);
    if (!enraged && now - started > BossPatterns.ENRAGE_AFTER) {
      enraged = true;
      arena.say(name() + " wird WÜTEND! Schneller und härter – jetzt schnell besiegen!");
      boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_RAVAGER_ROAR, 1.2f, .7f);
    }
    Location at = boss.getLocation();
    if (immune(now)) ring(at, 1.8, Color.fromRGB(120, 200, 255), 16, 1.2);
    if (exhausted(now) && now % 6 == 0)
      at.getWorld().spawnParticle(Particle.WAX_OFF, at.clone().add(0, 3.2, 0), 4, .4, .2, .4, 0);
    if (attack == null) {
      if (now >= nextAt && !immune(now)) begin(now);
      return;
    }
    if (now < landAt) {
      telegraph(now);
      if (landAt - now <= 10) warnDanger(now);
      return;
    }
    if (resolve(now)) finish(now);
  }

  private void phaseChange(long now, int next) {
    phase = next;
    attack = null;
    secondary = null;
    shieldUntil = now + BossPatterns.PHASE_SHIELD;
    nextAt = shieldUntil;
    Location at = boss.getLocation();
    arena.say(
        name()
            + (phase == 1
                ? " wird wütender – neue Angriffe! (Phase 2/3)"
                : " entfesselt alles – doppelte Angriffe! (Phase 3/3)"));
    at.getWorld().playSound(at, Sound.ENTITY_RAVAGER_ROAR, 1.3f, .6f);
    at.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, at.clone().add(0, 1, 0), 1);
    for (Player p : arena.living()) {
      Vector away = p.getLocation().toVector().subtract(at.toVector()).setY(0);
      if (away.lengthSquared() < 16 && away.lengthSquared() > .01)
        p.setVelocity(away.normalize().multiply(1.1).setY(.4));
      title(p, "PHASE " + (phase + 1), name() + " ist kurz immun", NamedTextColor.DARK_RED);
    }
  }

  private void begin(long now) {
    List<Player> players = arena.living();
    if (players.isEmpty()) return;
    attack = BossPatterns.next(arena.zone(), phase, cast, arena.seed());
    Player focus = players.get(cast % players.size());
    cast++;
    landAt = now + BossPatterns.warning(attack, phase, arena.level(), enraged);
    hitThisAttack.clear();
    warned.clear();
    Location at = boss.getLocation();
    Location center = arena.center();
    target = focus.getLocation().clone();
    direction = target.toVector().subtract(at.toVector()).setY(0);
    direction = direction.lengthSquared() < .01 ? new Vector(0, 0, 1) : direction.normalize();
    secondary = null;
    switch (attack) {
      case SHOCKWAVE -> gap = ThreadLocalRandomHolder.next() * Math.PI * 2;
      case SPIN -> {
        spinStart = Math.atan2(direction.getZ(), direction.getX());
        spinDir = ThreadLocalRandomHolder.next() < .5 ? 1 : -1;
      }
      case SHARDS -> {
        List<double[]> rel = new ArrayList<>();
        for (Player p : players)
          rel.add(new double[] {p.getX() - center.getX(), p.getZ() - center.getZ()});
        List<Location> out = new ArrayList<>();
        for (double[] s :
            BossPatterns.shards(rel, 4 + 2 * players.size() + phase * 2, arena.seed() + cast))
          out.add(center.clone().add(s[0], 0, s[1]));
        shards = out;
      }
      case SAFE -> {
        double[] s =
            BossPatterns.safeSpot(at.getX() - center.getX(), at.getZ() - center.getZ(), cast);
        safe = center.clone().add(s[0], 0, s[1]);
      }
      case LEAP -> target = clamp(target);
      default -> {}
    }
    // Final phase: big attacks come with a stomp on another player.
    if (phase == 2 && attack.big && players.size() > 0) {
      Player other = players.get((cast + 1) % players.size());
      secondary = other.getLocation().clone();
    }
    boss.setRotation(at.clone().setDirection(direction).getYaw(), 0);
    at.getWorld().playSound(at, Sound.BLOCK_NOTE_BLOCK_BASS, 1.2f, attack.big ? .5f : .8f);
    // Big attacks always get a title; small ones only the first time they appear.
    if (attack.big || introduced.add(attack))
      for (Player p : players)
        title(
            p,
            "⚠ " + attack.title,
            attack.hint,
            attack.big ? NamedTextColor.RED : NamedTextColor.GOLD);
  }

  private double progress(long now) {
    int total = BossPatterns.warning(attack, phase, arena.level(), enraged);
    return 1 - Math.max(0, landAt - now) / (double) total;
  }

  private void telegraph(long now) {
    double t = progress(now);
    Location at = boss.getLocation();
    switch (attack) {
      case SLAM -> filled(target, 4, t, Color.RED);
      case BEAM -> line(at, direction, 18, t, Color.ORANGE);
      case SHOCKWAVE -> {
        ring(at, BossPatterns.waveRadius(0), Color.RED, 20, 1.3);
        double a = gap;
        for (double d = 1.5; d < BossPatterns.ARENA; d += 1)
          dust(at.clone().add(Math.cos(a) * d, .2, Math.sin(a) * d), Color.LIME, 1.4f);
      }
      case LEAP -> {
        filled(target, BossPatterns.LEAP_RADIUS, t, Color.RED);
        dust(target.clone().add(0, 2.5 - 2 * t, 0), Color.RED, 2f);
      }
      case SPIN -> {
        line(at, new Vector(Math.cos(spinStart), 0, Math.sin(spinStart)), 13, t, Color.fromRGB(255, 90, 40));
        for (int i = 1; i <= 4; i++) {
          double a = spinStart + spinDir * i * .25;
          dust(at.clone().add(Math.cos(a) * 3, .3, Math.sin(a) * 3), Color.YELLOW, 1f);
        }
      }
      case SHARDS -> shards.forEach(s -> filled(s, BossPatterns.SHARD_RADIUS, t, Color.fromRGB(200, 120, 255)));
      case VORTEX -> {
        filled(at, BossPatterns.VORTEX_RADIUS, t, Color.PURPLE);
        at.getWorld().spawnParticle(Particle.PORTAL, at.clone().add(0, 1, 0), 12, 2, .5, 2, .6);
      }
      case SAFE -> {
        ring(safe, BossPatterns.safeRadius(arena.living().size()), Color.LIME, 22, 1.6);
        if (now % 4 == 0)
          for (int i = 0; i < 18; i++) {
            double a = ThreadLocalRandomHolder.next() * Math.PI * 2;
            double d = ThreadLocalRandomHolder.next() * BossPatterns.ARENA;
            Location l = arena.center().clone().add(Math.cos(a) * d, .2, Math.sin(a) * d);
            if (l.distanceSquared(safe) > Math.pow(BossPatterns.safeRadius(arena.living().size()), 2))
              dust(l, Color.RED, 1.3f);
          }
      }
    }
    if (secondary != null) filled(secondary, 2.7, t, Color.RED);
  }

  /** The drone (and a sound) warns players who are standing where the attack will land. */
  private void warnDanger(long now) {
    for (Player p : arena.living())
      if (!warned.contains(p.getUniqueId()) && wouldHit(p, landAt)) {
        warned.add(p.getUniqueId());
        arena.danger(p, attack);
      }
  }

  private boolean wouldHit(Player p, long when) {
    Location at = boss.getLocation();
    double dx = p.getX() - at.getX(), dz = p.getZ() - at.getZ();
    return switch (attack) {
      case SLAM -> BossPatterns.slam(p.getX() - target.getX(), p.getZ() - target.getZ(), 4);
      case BEAM -> BossPatterns.beam(dx, dz, direction.getX(), direction.getZ(), 18, 1.2);
      case LEAP ->
          BossPatterns.slam(p.getX() - target.getX(), p.getZ() - target.getZ(), BossPatterns.LEAP_RADIUS);
      case SHARDS ->
          shards.stream().anyMatch(s -> BossPatterns.shard(p.getX() - s.getX(), p.getZ() - s.getZ()));
      case VORTEX -> BossPatterns.vortexBlast(dx, dz);
      case SAFE ->
          BossPatterns.safeZoneHit(
              p.getX() - safe.getX(), p.getZ() - safe.getZ(), 0, 0, arena.living().size());
      case SPIN -> BossPatterns.spin(dx, dz, spinStart);
      case SHOCKWAVE -> Math.sqrt(dx * dx + dz * dz) < 3;
    };
  }

  /** Returns true once the attack is over. */
  private boolean resolve(long now) {
    int t = (int) (now - landAt);
    Location at = boss.getLocation();
    double damage = BossPatterns.damage(attack, arena.baseDamage(), enraged);
    if (t == 0 && secondary != null) {
      for (Player p : arena.living())
        if (BossPatterns.slam(p.getX() - secondary.getX(), p.getZ() - secondary.getZ(), 2.7))
          hit(p, damage * .7, false);
      burst(secondary, 2.7);
      secondary = null;
    }
    switch (attack) {
      case SLAM -> {
        for (Player p : arena.living())
          if (BossPatterns.slam(p.getX() - target.getX(), p.getZ() - target.getZ(), 4))
            hit(p, damage, false);
        burst(target, 4);
        return true;
      }
      case BEAM -> {
        for (Player p : arena.living())
          if (BossPatterns.beam(
                  p.getX() - at.getX(), p.getZ() - at.getZ(), direction.getX(), direction.getZ(), 18, 1.2)
              && p.hasLineOfSight(boss)) hit(p, damage, false);
        for (int i = 0; i < 18; i++)
          at.getWorld()
              .spawnParticle(Particle.FLAME, at.clone().add(direction.clone().multiply(i)).add(0, 1, 0), 2, .1, .1, .1, 0);
        at.getWorld().playSound(at, Sound.ENTITY_BLAZE_SHOOT, 1, .6f);
        return true;
      }
      case LEAP -> {
        boss.teleport(target.clone().setDirection(direction));
        for (Player p : arena.living()) {
          Vector away = p.getLocation().toVector().subtract(target.toVector()).setY(0);
          if (BossPatterns.slam(away.getX(), away.getZ(), BossPatterns.LEAP_RADIUS)) {
            hit(p, damage, true);
            if (away.lengthSquared() > .01) p.setVelocity(away.normalize().multiply(.9).setY(.45));
          }
        }
        burst(target, BossPatterns.LEAP_RADIUS);
        at.getWorld().playSound(target, Sound.ENTITY_GENERIC_EXPLODE, 1, .7f);
        return true;
      }
      case SHARDS -> {
        for (Player p : arena.living())
          if (shards.stream().anyMatch(s -> BossPatterns.shard(p.getX() - s.getX(), p.getZ() - s.getZ())))
            hit(p, damage, false);
        for (Location s : shards) {
          s.getWorld().spawnParticle(Particle.END_ROD, s.clone().add(0, 2.5, 0), 6, .2, 1, .2, .05);
          burst(s, BossPatterns.SHARD_RADIUS);
        }
        at.getWorld().playSound(at, Sound.BLOCK_AMETHYST_CLUSTER_BREAK, 1, .8f);
        return true;
      }
      case SAFE -> {
        int n = arena.living().size();
        for (Player p : arena.living())
          if (BossPatterns.safeZoneHit(p.getX() - safe.getX(), p.getZ() - safe.getZ(), 0, 0, n))
            hit(p, damage, true);
        at.getWorld().spawnParticle(Particle.EXPLOSION, arena.center().clone().add(0, 1, 0), 30, 7, .5, 7, 0);
        at.getWorld().playSound(at, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1, .8f);
        return true;
      }
      case SHOCKWAVE -> {
        double r = BossPatterns.waveRadius(t);
        ring(at, r, Color.RED, (int) (r * 5), 1.6);
        if (t % 6 == 0) at.getWorld().playSound(at, Sound.BLOCK_BASALT_BREAK, .8f, .6f);
        for (Player p : arena.living())
          if (BossPatterns.shockwave(p.getX() - at.getX(), p.getZ() - at.getZ(), t, gap, !p.isOnGround()))
            hit(p, damage, true);
        return t >= BossPatterns.active(Attack.SHOCKWAVE);
      }
      case SPIN -> {
        double angle = BossPatterns.spinAngle(spinStart, t, spinDir);
        Vector dir = new Vector(Math.cos(angle), 0, Math.sin(angle));
        for (int i = 1; i < 13; i++)
          at.getWorld()
              .spawnParticle(Particle.FLAME, at.clone().add(dir.clone().multiply(i)).add(0, 1, 0), 1, .05, .05, .05, 0);
        for (Player p : arena.living())
          if (BossPatterns.spin(p.getX() - at.getX(), p.getZ() - at.getZ(), angle)) hit(p, damage, true);
        if (t % 8 == 0) at.getWorld().playSound(at, Sound.ENTITY_BLAZE_BURN, 1, .7f);
        return t >= BossPatterns.active(Attack.SPIN);
      }
      case VORTEX -> {
        int active = BossPatterns.active(Attack.VORTEX);
        if (t < active) {
          for (Player p : arena.living()) {
            Vector pull = at.toVector().subtract(p.getLocation().toVector()).setY(0);
            if (pull.lengthSquared() > 1 && pull.lengthSquared() < 225)
              p.setVelocity(p.getVelocity().add(pull.normalize().multiply(BossPatterns.VORTEX_PULL * 2)));
          }
          at.getWorld().spawnParticle(Particle.REVERSE_PORTAL, at.clone().add(0, 1, 0), 20, 4, .5, 4, .1);
          ring(at, BossPatterns.VORTEX_RADIUS, Color.PURPLE, 22, 1.4);
          return false;
        }
        for (Player p : arena.living())
          if (BossPatterns.vortexBlast(p.getX() - at.getX(), p.getZ() - at.getZ())) hit(p, damage, true);
        at.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, at.clone().add(0, 1, 0), 1);
        at.getWorld().playSound(at, Sound.ENTITY_GENERIC_EXPLODE, 1.2f, .5f);
        return true;
      }
    }
    return true;
  }

  private void finish(long now) {
    int exhausted = BossPatterns.exhausted(attack);
    if (exhausted > 0) {
      exhaustedUntil = now + exhausted;
      for (Player p : arena.living())
        title(p, "SCHWACHSTELLE!", name() + " ist erschöpft – jetzt zuschlagen!", NamedTextColor.GREEN);
      boss.getWorld().playSound(boss.getLocation(), Sound.BLOCK_ANVIL_LAND, .6f, 1.6f);
    }
    nextAt = now + BossPatterns.recovery(attack, phase, arena.level(), enraged) + exhausted;
    attack = null;
  }

  private void hit(Player p, double damage, boolean big) {
    if (!hitThisAttack.add(p.getUniqueId())) return;
    if (big) struck.add(p.getUniqueId());
    arena.hurt(p, damage);
  }

  private Location clamp(Location l) {
    Location c = arena.center();
    Vector d = l.toVector().subtract(c.toVector()).setY(0);
    double max = BossPatterns.ARENA - 2;
    if (d.length() > max) d = d.normalize().multiply(max);
    return c.clone().add(d).setDirection(new Vector(0, 0, 1));
  }

  // ---- visuals ----

  private static void dust(Location l, Color c, float size) {
    l.getWorld().spawnParticle(Particle.DUST, l, 1, 0, 0, 0, 0, new Particle.DustOptions(c, size));
  }

  private static void ring(Location center, double radius, Color c, int points, double size) {
    for (int i = 0; i < points; i++) {
      double a = i * Math.PI * 2 / points;
      dust(center.clone().add(Math.cos(a) * radius, .2, Math.sin(a) * radius), c, (float) size);
    }
  }

  /** Outline plus an inner ring that grows until the attack lands. */
  private static void filled(Location center, double radius, double progress, Color c) {
    ring(center, radius, c, (int) Math.max(12, radius * 6), 1.3);
    ring(center, Math.max(.3, radius * progress), c, (int) Math.max(8, radius * 4), .9);
  }

  private static void line(Location from, Vector dir, int length, double progress, Color c) {
    for (int i = 1; i < length; i++) {
      Location l = from.clone().add(dir.clone().multiply(i)).add(0, .3, 0);
      dust(l, i <= length * progress ? c : Color.fromRGB(90, 30, 20), i <= length * progress ? 1.4f : .8f);
    }
  }

  private static void burst(Location center, double radius) {
    center.getWorld().spawnParticle(Particle.EXPLOSION, center.clone().add(0, .5, 0), 3, radius / 3, .2, radius / 3, 0);
    center.getWorld().spawnParticle(Particle.BLOCK, center.clone().add(0, .3, 0), 30, radius / 2, .1, radius / 2, Material.STONE.createBlockData());
  }

  private static void title(Player p, String big, String small, NamedTextColor color) {
    p.showTitle(
        Title.title(
            Component.text(big, color),
            Component.text(small, NamedTextColor.WHITE),
            Title.Times.times(Duration.ofMillis(80), Duration.ofMillis(900), Duration.ofMillis(250))));
  }

  /** Visual randomness only; gameplay decisions use the seeded pattern rotation. */
  private static final class ThreadLocalRandomHolder {
    static double next() {
      return java.util.concurrent.ThreadLocalRandom.current().nextDouble();
    }
  }
}
