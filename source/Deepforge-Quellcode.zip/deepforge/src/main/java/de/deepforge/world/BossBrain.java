package de.deepforge.world;

import de.deepforge.game.BossPatterns;
import de.deepforge.game.BossPatterns.Attack;
import java.time.Duration;
import java.util.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.util.Vector;

/**
 * One dungeon boss fight: three phases, telegraphed attacks from {@link BossPatterns}, a shield
 * during phase changes, weak spots after big attacks and an enrage timer.
 *
 * <p>0.11.0: the difficulty decides a lot more – shorter warnings, harder hits, chained attacks
 * (combos), five new attacks, growing enrage on Albtraum and a burning arena edge in the last
 * phase on Veteran and Albtraum.
 */
final class BossBrain {
  /** What the boss needs from its dungeon run. */
  interface Arena {
    List<Player> living();

    /** Returns the damage actually taken (0 when dodged or protected). */
    double hurt(Player p, double damage);

    void say(String text);

    /** Arena centre on the floor. */
    Location center();

    double baseDamage();

    int zone();

    /** Dungeon index (see DungeonVariant); decides the boss name and attack mix. */
    default int variant() {
      return 0;
    }

    int level();

    long seed();

    /** Called shortly before an attack lands on a player who is standing in it. */
    void danger(Player p, Attack attack);

    /** 0 Normal, 1 Veteran, 2 Albtraum. */
    default int mode() {
      return 0;
    }

    /** Schildphase: calls {@code count} minions into the arena. */
    default void summon(int count) {}

    /** Minions from the last summon still alive. */
    default int summonsAlive() {
      return 0;
    }

    /** Which attack hit whom, for the statistics in the victory hall. */
    default void record(Player p, Attack attack) {}
  }

  /** A rift across the arena that stays dangerous for a while. */
  private record Rift(double angle, long until) {}

  private final Arena arena;
  private final Mob boss;
  private final long started;
  private int phase, cast, combo, meteorVolley;
  private boolean enraged;
  private Attack attack;
  private long landAt, nextAt, shieldUntil, exhaustedUntil, enragedAt, phaseAt, summonUntil;
  private Location target, secondary, safe;
  private Vector direction;
  private double spinStart, gap;
  private int spinDir = 1;
  private UUID marked;
  private List<Location> shards = List.of(), meteors = List.of();
  private final List<Rift> rifts = new ArrayList<>();
  private final Map<UUID, Long> riftHits = new HashMap<>(), edgeHits = new HashMap<>();
  private final Set<UUID> hitThisAttack = new HashSet<>(), warned = new HashSet<>();
  private final Set<Attack> introduced = EnumSet.noneOf(Attack.class);
  // Players hit by any big attack; the others earn the flawless bonus.
  final Set<UUID> struck = new HashSet<>();

  BossBrain(Arena arena, Mob boss, long now) {
    this.arena = arena;
    this.boss = boss;
    started = now;
    nextAt = now + 60;
  }

  boolean immune(long now) {
    return now < shieldUntil;
  }

  boolean exhausted(long now) {
    return now < exhaustedUntil;
  }

  double damageTaken(long now) {
    return exhausted(now) ? BossPatterns.EXHAUSTED_BONUS : 1;
  }

  /** 0, 1 or 2; Albtraum locks healing shards in the last phase. */
  int phase() {
    return phase;
  }

  /** While casting the boss stands still. */
  boolean busy() {
    return attack != null;
  }

  String name() {
    return de.deepforge.game.DungeonVariant.of(arena.variant()).boss(arena.zone());
  }

  String status(long now) {
    return name()
        + " · Phase "
        + (phase + 1)
        + "/3"
        + (summonUntil > 0
            ? " · SCHILD (" + arena.summonsAlive() + " Diener)"
            : immune(now) ? " · IMMUN" : exhausted(now) ? " · SCHWACHSTELLE!" : "")
        + (enraged ? " · WÜTEND" + (arena.mode() >= 2 ? " ×" + String.format(Locale.GERMAN, "%.1f", stacks(now)) : "") : "");
  }

  void tick(long now, double hp, double max) {
    int nextPhase = BossPatterns.phase(hp, max);
    if (nextPhase > phase) phaseChange(now, nextPhase);
    if (!enraged && now - started > BossPatterns.enrageAfter(arena.mode())) {
      enraged = true;
      enragedAt = now;
      arena.say(
          name()
              + " wird WÜTEND! Schneller und härter"
              + (arena.mode() >= 2 ? " – und alle 30 Sekunden noch stärker!" : " – jetzt schnell besiegen!"));
      boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_RAVAGER_ROAR, 1.2f, .7f);
    }
    if (summonUntil > 0 && (arena.summonsAlive() == 0 || now >= summonUntil)) {
      summonUntil = 0;
      shieldUntil = now;
      arena.say("Der Schild von " + name() + " bricht – jetzt zuschlagen!");
      boss.getWorld().playSound(boss.getLocation(), Sound.BLOCK_GLASS_BREAK, 1.2f, .6f);
    }
    tickRifts(now);
    tickEdge(now);
    Location at = boss.getLocation();
    if (immune(now)) ring(at, 1.8, Color.fromRGB(120, 200, 255), 16, 1.2);
    if (exhausted(now) && now % 6 == 0)
      at.getWorld().spawnParticle(Particle.WAX_OFF, at.clone().add(0, 3.2, 0), 4, .4, .2, .4, 0);
    if (attack == null) {
      if (now >= nextAt && (!immune(now) || summonUntil > 0)) begin(now);
      return;
    }
    if (now < landAt) {
      telegraph(now);
      if (landAt - now <= 10) warnDanger(now);
      return;
    }
    if (resolve(now)) finish(now);
  }

  private void phaseChange(long now, int next) {
    phase = next;
    phaseAt = now;
    attack = null;
    secondary = null;
    marked = null;
    combo = 0;
    shieldUntil = now + BossPatterns.PHASE_SHIELD;
    nextAt = shieldUntil;
    Location at = boss.getLocation();
    arena.say(
        name()
            + (phase == 1
                ? " wird wütender – neue Angriffe! (Phase 2/3)"
                : " entfesselt alles – doppelte Angriffe! (Phase 3/3)")
            + (phase == 2 && arena.mode() >= 1 ? " Der Rand der Arena beginnt zu brennen!" : "")
            + (phase == 2 && arena.mode() >= 2 ? " Keine Heilung mehr!" : ""));
    at.getWorld().playSound(at, Sound.ENTITY_RAVAGER_ROAR, 1.3f, .6f);
    at.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, at.clone().add(0, 1, 0), 1);
    for (Player p : arena.living()) {
      Vector away = p.getLocation().toVector().subtract(at.toVector()).setY(0);
      if (away.lengthSquared() < 16 && away.lengthSquared() > .01)
        p.setVelocity(away.normalize().multiply(1.1).setY(.4));
      title(p, "PHASE " + (phase + 1), name() + " ist kurz immun", NamedTextColor.DARK_RED);
    }
  }

  private void begin(long now) {
    List<Player> players = arena.living();
    if (players.isEmpty()) return;
    attack =
        BossPatterns.next(
            BossPatterns.kitIndex(arena.zone(), arena.variant()), phase, arena.mode(), cast, arena.seed());
    // A shield phase while one is still running would stack forever.
    if (attack == Attack.SUMMON && summonUntil > 0) attack = Attack.SLAM;
    Player focus = players.get(cast % players.size());
    cast++;
    landAt = now + BossPatterns.warning(attack, phase, arena.level(), enraged, arena.mode());
    hitThisAttack.clear();
    warned.clear();
    Location at = boss.getLocation();
    Location center = arena.center();
    target = focus.getLocation().clone();
    direction = target.toVector().subtract(at.toVector()).setY(0);
    direction = direction.lengthSquared() < .01 ? new Vector(0, 0, 1) : direction.normalize();
    secondary = null;
    switch (attack) {
      case SHOCKWAVE -> gap = ThreadLocalRandomHolder.next() * Math.PI * 2;
      case SPIN -> {
        spinStart = Math.atan2(direction.getZ(), direction.getX());
        spinDir = ThreadLocalRandomHolder.next() < .5 ? 1 : -1;
      }
      case SHARDS -> {
        List<double[]> rel = new ArrayList<>();
        for (Player p : players)
          rel.add(new double[] {p.getX() - center.getX(), p.getZ() - center.getZ()});
        List<Location> out = new ArrayList<>();
        for (double[] s :
            BossPatterns.shards(rel, 4 + 2 * players.size() + phase * 2, arena.seed() + cast))
          out.add(center.clone().add(s[0], 0, s[1]));
        shards = out;
      }
      case SAFE -> {
        double[] s =
            BossPatterns.safeSpot(at.getX() - center.getX(), at.getZ() - center.getZ(), cast);
        safe = center.clone().add(s[0], 0, s[1]);
      }
      case LEAP -> target = clamp(target);
      case METEOR -> {
        meteorVolley = 0;
        meteors = players.stream().map(p -> p.getLocation().clone()).toList();
      }
      case MARK -> marked = focus.getUniqueId();
      case RIFT -> gap = ThreadLocalRandomHolder.next() * Math.PI;
      default -> {}
    }
    // Final phase: big attacks come with a stomp on another player.
    if (phase == 2 && attack.big && players.size() > 0) {
      Player other = players.get((cast + 1) % players.size());
      secondary = other.getLocation().clone();
    }
    boss.setRotation(at.clone().setDirection(direction).getYaw(), 0);
    at.getWorld().playSound(at, Sound.BLOCK_NOTE_BLOCK_BASS, 1.2f, attack.big ? .5f : .8f);
    // Big attacks always get a title; small ones only the first time they appear.
    if (attack.big || introduced.add(attack))
      for (Player p : players)
        title(
            p,
            (combo > 0 ? "KOMBO! " : "⚠ ") + attack.title,
            attack == Attack.MARK && !p.getUniqueId().equals(marked) ? focus.getName() + " ist markiert – weg von ihm!" : attack.hint,
            attack.big ? NamedTextColor.RED : NamedTextColor.GOLD);
  }

  private double progress(long now) {
    int total = BossPatterns.warning(attack, phase, arena.level(), enraged, arena.mode());
    return 1 - Math.max(0, landAt - now) / (double) total;
  }

  private void telegraph(long now) {
    double t = progress(now);
    Location at = boss.getLocation();
    switch (attack) {
      case SLAM -> filled(target, 4, t, Color.RED);
      case BEAM -> line(at, direction, 18, t, Color.ORANGE);
      case SHOCKWAVE -> {
        ring(at, BossPatterns.waveRadius(0), Color.RED, 20, 1.3);
        double a = gap;
        for (double d = 1.5; d < BossPatterns.ARENA; d += 1)
          dust(at.clone().add(Math.cos(a) * d, .2, Math.sin(a) * d), Color.LIME, 1.4f);
      }
      case LEAP -> {
        filled(target, BossPatterns.LEAP_RADIUS, t, Color.RED);
        dust(target.clone().add(0, 2.5 - 2 * t, 0), Color.RED, 2f);
      }
      case SPIN -> {
        line(at, new Vector(Math.cos(spinStart), 0, Math.sin(spinStart)), 13, t, Color.fromRGB(255, 90, 40));
        for (int i = 1; i <= 4; i++) {
          double a = spinStart + spinDir * i * .25;
          dust(at.clone().add(Math.cos(a) * 3, .3, Math.sin(a) * 3), Color.YELLOW, 1f);
        }
      }
      case SHARDS -> shards.forEach(s -> filled(s, BossPatterns.SHARD_RADIUS, t, Color.fromRGB(200, 120, 255)));
      case VORTEX -> {
        filled(at, BossPatterns.VORTEX_RADIUS, t, Color.PURPLE);
        at.getWorld().spawnParticle(Particle.PORTAL, at.clone().add(0, 1, 0), 12, 2, .5, 2, .6);
      }
      case SAFE -> {
        ring(safe, BossPatterns.safeRadius(arena.living().size()), Color.LIME, 22, 1.6);
        if (now % 4 == 0)
          for (int i = 0; i < 18; i++) {
            double a = ThreadLocalRandomHolder.next() * Math.PI * 2;
            double d = ThreadLocalRandomHolder.next() * BossPatterns.ARENA;
            Location l = arena.center().clone().add(Math.cos(a) * d, .2, Math.sin(a) * d);
            if (l.distanceSquared(safe) > Math.pow(BossPatterns.safeRadius(arena.living().size()), 2))
              dust(l, Color.RED, 1.3f);
          }
      }
      case METEOR -> {
        meteors.forEach(m -> filled(m, BossPatterns.METEOR_RADIUS, t, Color.fromRGB(255, 140, 0)));
        meteors.forEach(m -> dust(m.clone().add(0, 6 - 5 * t, 0), Color.ORANGE, 2.2f));
      }
      case RIFT -> {
        Location c = arena.center();
        for (int k = 0; k < 3; k++) {
          double a = gap + k * Math.PI / 3;
          for (double d = -BossPatterns.ARENA; d <= BossPatterns.ARENA; d += 1.5)
            dust(c.clone().add(Math.cos(a) * d, .2, Math.sin(a) * d), t > .6 ? Color.RED : Color.ORANGE, 1.2f);
        }
      }
      case CHAIN -> {
        for (Player p : arena.living()) {
          ring(p.getLocation(), BossPatterns.CHAIN_RANGE, Color.fromRGB(140, 200, 255), 18, .9);
          if (now % 4 == 0)
            p.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, p.getLocation().add(0, 1, 0), 6, .3, .5, .3, .05);
        }
      }
      case MARK -> {
        Player m = markedPlayer();
        if (m != null) {
          filled(m.getLocation(), BossPatterns.MARK_RADIUS, t, Color.fromRGB(170, 40, 255));
          m.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, m.getLocation().add(0, 2.3, 0), 3, .1, .1, .1, 0);
        }
      }
      case SUMMON -> ring(at, 3 + 3 * t, Color.fromRGB(120, 200, 255), 24, 1.4);
    }
    if (secondary != null) filled(secondary, 2.7, t, Color.RED);
  }

  /** The drone (and a sound) warns players who are standing where the attack will land. */
  private void warnDanger(long now) {
    for (Player p : arena.living())
      if (!warned.contains(p.getUniqueId()) && wouldHit(p, landAt)) {
        warned.add(p.getUniqueId());
        arena.danger(p, attack);
      }
  }

  private boolean wouldHit(Player p, long when) {
    Location at = boss.getLocation();
    double dx = p.getX() - at.getX(), dz = p.getZ() - at.getZ();
    return switch (attack) {
      case SLAM -> BossPatterns.slam(p.getX() - target.getX(), p.getZ() - target.getZ(), 4);
      case BEAM -> BossPatterns.beam(dx, dz, direction.getX(), direction.getZ(), 18, 1.2);
      case LEAP ->
          BossPatterns.slam(p.getX() - target.getX(), p.getZ() - target.getZ(), BossPatterns.LEAP_RADIUS);
      case SHARDS ->
          shards.stream().anyMatch(s -> BossPatterns.shard(p.getX() - s.getX(), p.getZ() - s.getZ()));
      case VORTEX -> BossPatterns.vortexBlast(dx, dz);
      case SAFE ->
          BossPatterns.safeZoneHit(
              p.getX() - safe.getX(), p.getZ() - safe.getZ(), 0, 0, arena.living().size());
      case SPIN -> BossPatterns.spin(dx, dz, spinStart);
      case SHOCKWAVE -> Math.sqrt(dx * dx + dz * dz) < 3;
      case METEOR ->
          meteors.stream()
              .anyMatch(m -> BossPatterns.slam(p.getX() - m.getX(), p.getZ() - m.getZ(), BossPatterns.METEOR_RADIUS));
      case RIFT -> {
        Location c = arena.center();
        boolean on = false;
        for (int k = 0; k < 3; k++) on |= BossPatterns.rift(p.getX() - c.getX(), p.getZ() - c.getZ(), gap + k * Math.PI / 3);
        yield on;
      }
      case CHAIN -> arena.living().size() > 1 || BossPatterns.slam(dx, dz, 6);
      case MARK -> {
        Player m = markedPlayer();
        yield m != null
            && (m == p
                ? BossPatterns.slam(dx, dz, 6)
                : BossPatterns.slam(p.getX() - m.getX(), p.getZ() - m.getZ(), BossPatterns.MARK_RADIUS));
      }
      case SUMMON -> false;
    };
  }

  /** Returns true once the attack is over. */
  private boolean resolve(long now) {
    int t = (int) (now - landAt);
    Location at = boss.getLocation();
    double damage = BossPatterns.damage(attack, arena.baseDamage(), enraged) * stacks(now);
    if (t == 0 && secondary != null) {
      for (Player p : arena.living())
        if (BossPatterns.slam(p.getX() - secondary.getX(), p.getZ() - secondary.getZ(), 2.7))
          hit(p, damage * .7, false);
      burst(secondary, 2.7);
      secondary = null;
    }
    switch (attack) {
      case SLAM -> {
        for (Player p : arena.living())
          if (BossPatterns.slam(p.getX() - target.getX(), p.getZ() - target.getZ(), 4))
            hit(p, damage, false);
        burst(target, 4);
        return true;
      }
      case BEAM -> {
        for (Player p : arena.living())
          if (BossPatterns.beam(
                  p.getX() - at.getX(), p.getZ() - at.getZ(), direction.getX(), direction.getZ(), 18, 1.2)
              && p.hasLineOfSight(boss)) hit(p, damage, false);
        for (int i = 0; i < 18; i++)
          at.getWorld()
              .spawnParticle(Particle.FLAME, at.clone().add(direction.clone().multiply(i)).add(0, 1, 0), 2, .1, .1, .1, 0);
        at.getWorld().playSound(at, Sound.ENTITY_BLAZE_SHOOT, 1, .6f);
        return true;
      }
      case LEAP -> {
        boss.teleport(target.clone().setDirection(direction));
        for (Player p : arena.living()) {
          Vector away = p.getLocation().toVector().subtract(target.toVector()).setY(0);
          if (BossPatterns.slam(away.getX(), away.getZ(), BossPatterns.LEAP_RADIUS)) {
            hit(p, damage, true);
            if (away.lengthSquared() > .01) p.setVelocity(away.normalize().multiply(.9).setY(.45));
          }
        }
        burst(target, BossPatterns.LEAP_RADIUS);
        at.getWorld().playSound(target, Sound.ENTITY_GENERIC_EXPLODE, 1, .7f);
        return true;
      }
      case SHARDS -> {
        for (Player p : arena.living())
          if (shards.stream().anyMatch(s -> BossPatterns.shard(p.getX() - s.getX(), p.getZ() - s.getZ())))
            hit(p, damage, false);
        for (Location s : shards) {
          s.getWorld().spawnParticle(Particle.END_ROD, s.clone().add(0, 2.5, 0), 6, .2, 1, .2, .05);
          burst(s, BossPatterns.SHARD_RADIUS);
        }
        at.getWorld().playSound(at, Sound.BLOCK_AMETHYST_CLUSTER_BREAK, 1, .8f);
        return true;
      }
      case SAFE -> {
        int n = arena.living().size();
        for (Player p : arena.living())
          if (BossPatterns.safeZoneHit(p.getX() - safe.getX(), p.getZ() - safe.getZ(), 0, 0, n))
            hit(p, damage, true);
        at.getWorld().spawnParticle(Particle.EXPLOSION, arena.center().clone().add(0, 1, 0), 30, 7, .5, 7, 0);
        at.getWorld().playSound(at, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1, .8f);
        return true;
      }
      case SHOCKWAVE -> {
        double r = BossPatterns.waveRadius(t);
        ring(at, r, Color.RED, (int) (r * 5), 1.6);
        if (t % 6 == 0) at.getWorld().playSound(at, Sound.BLOCK_BASALT_BREAK, .8f, .6f);
        for (Player p : arena.living())
          if (BossPatterns.shockwave(p.getX() - at.getX(), p.getZ() - at.getZ(), t, gap, !p.isOnGround()))
            hit(p, damage, true);
        return t >= BossPatterns.active(Attack.SHOCKWAVE);
      }
      case SPIN -> {
        double angle = BossPatterns.spinAngle(spinStart, t, spinDir);
        Vector dir = new Vector(Math.cos(angle), 0, Math.sin(angle));
        for (int i = 1; i < 13; i++)
          at.getWorld()
              .spawnParticle(Particle.FLAME, at.clone().add(dir.clone().multiply(i)).add(0, 1, 0), 1, .05, .05, .05, 0);
        for (Player p : arena.living())
          if (BossPatterns.spin(p.getX() - at.getX(), p.getZ() - at.getZ(), angle)) hit(p, damage, true);
        if (t % 8 == 0) at.getWorld().playSound(at, Sound.ENTITY_BLAZE_BURN, 1, .7f);
        return t >= BossPatterns.active(Attack.SPIN);
      }
      case VORTEX -> {
        int active = BossPatterns.active(Attack.VORTEX);
        if (t < active) {
          for (Player p : arena.living()) {
            Vector pull = at.toVector().subtract(p.getLocation().toVector()).setY(0);
            if (pull.lengthSquared() > 1 && pull.lengthSquared() < 225)
              p.setVelocity(p.getVelocity().add(pull.normalize().multiply(BossPatterns.VORTEX_PULL * 2)));
          }
          at.getWorld().spawnParticle(Particle.REVERSE_PORTAL, at.clone().add(0, 1, 0), 20, 4, .5, 4, .1);
          ring(at, BossPatterns.VORTEX_RADIUS, Color.PURPLE, 22, 1.4);
          return false;
        }
        for (Player p : arena.living())
          if (BossPatterns.vortexBlast(p.getX() - at.getX(), p.getZ() - at.getZ())) hit(p, damage, true);
        at.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, at.clone().add(0, 1, 0), 1);
        at.getWorld().playSound(at, Sound.ENTITY_GENERIC_EXPLODE, 1.2f, .5f);
        return true;
      }
      case METEOR -> {
        // Three volleys; each new volley aims where the players are now.
        int local = t - meteorVolley * BossPatterns.METEOR_EVERY;
        if (local == 0) {
          for (Location m : meteors) {
            for (Player p : arena.living())
              if (BossPatterns.slam(p.getX() - m.getX(), p.getZ() - m.getZ(), BossPatterns.METEOR_RADIUS))
                hitAgain(p, damage);
            burst(m, BossPatterns.METEOR_RADIUS);
            m.getWorld().playSound(m, Sound.ENTITY_GENERIC_EXPLODE, .8f, 1.2f);
          }
          meteorVolley++;
          if (meteorVolley >= BossPatterns.METEOR_VOLLEYS) return true;
          meteors = arena.living().stream().map(p -> p.getLocation().clone()).toList();
          return false;
        }
        double tt = local / (double) BossPatterns.METEOR_EVERY;
        meteors.forEach(m -> filled(m, BossPatterns.METEOR_RADIUS, 1 + tt, Color.fromRGB(255, 140, 0)));
        return false;
      }
      case RIFT -> {
        for (int k = 0; k < 3; k++) rifts.add(new Rift(gap + k * Math.PI / 3, now + BossPatterns.RIFT_TICKS));
        at.getWorld().playSound(at, Sound.BLOCK_DEEPSLATE_BREAK, 1.2f, .5f);
        tickRifts(now);
        return true;
      }
      case CHAIN -> {
        List<Player> living = arena.living();
        List<double[]> pos = living.stream().map(p -> new double[] {p.getX(), p.getZ()}).toList();
        int first = Math.max(0, living.indexOf(living.stream().filter(p -> p.getLocation().distanceSquared(target) < 36).findFirst().orElse(living.isEmpty() ? null : living.getFirst())));
        if (living.size() == 1) {
          // Solo: the bolt strikes where you stood when it was called.
          Player p = living.getFirst();
          if (BossPatterns.slam(p.getX() - target.getX(), p.getZ() - target.getZ(), 3)) hit(p, damage, true);
          target.getWorld().strikeLightningEffect(target);
          return true;
        }
        for (int i : BossPatterns.chain(pos, first)) {
          Player p = living.get(i);
          hit(p, damage, true);
          p.getWorld().strikeLightningEffect(p.getLocation());
        }
        return true;
      }
      case MARK -> {
        Player m = markedPlayer();
        if (m != null) {
          for (Player p : arena.living()) {
            boolean close =
                p == m
                    ? p.getLocation().distanceSquared(at) < 36
                    : BossPatterns.slam(p.getX() - m.getX(), p.getZ() - m.getZ(), BossPatterns.MARK_RADIUS);
            if (close) hit(p, damage, true);
          }
          burst(m.getLocation(), BossPatterns.MARK_RADIUS);
          m.getWorld().playSound(m.getLocation(), Sound.ENTITY_WITHER_BREAK_BLOCK, 1, .8f);
        }
        marked = null;
        return true;
      }
      case SUMMON -> {
        int count = 2 + arena.living().size();
        arena.summon(count);
        summonUntil = now + BossPatterns.SUMMON_MAX;
        shieldUntil = summonUntil;
        arena.say(name() + " hüllt sich in einen Schild und ruft " + count + " Diener – besiegt sie!");
        at.getWorld().playSound(at, Sound.ENTITY_EVOKER_PREPARE_SUMMON, 1.2f, .8f);
        return true;
      }
    }
    return true;
  }

  private void finish(long now) {
    int exhausted = BossPatterns.exhausted(attack);
    Attack done = attack;
    attack = null;
    // Veteran/Albtraum: sometimes the next attack follows at once – a combo.
    if (exhausted == 0
        && combo + 1 < BossPatterns.maxCombo(arena.mode())
        && ThreadLocalRandomHolder.next() < BossPatterns.comboChance(arena.mode())) {
      combo++;
      nextAt = now + 6;
      return;
    }
    combo = 0;
    if (exhausted > 0) {
      exhaustedUntil = now + exhausted;
      for (Player p : arena.living())
        title(p, "SCHWACHSTELLE!", name() + " ist erschöpft – jetzt zuschlagen!", NamedTextColor.GREEN);
      boss.getWorld().playSound(boss.getLocation(), Sound.BLOCK_ANVIL_LAND, .6f, 1.6f);
    }
    nextAt = now + BossPatterns.recovery(done, phase, arena.level(), enraged) + exhausted;
  }

  private void hit(Player p, double damage, boolean big) {
    if (!hitThisAttack.add(p.getUniqueId())) return;
    if (big) struck.add(p.getUniqueId());
    if (arena.hurt(p, damage) > 0) arena.record(p, attack);
  }

  /** Meteor volleys may hit the same player once per volley. */
  private void hitAgain(Player p, double damage) {
    if (arena.hurt(p, damage) > 0) arena.record(p, attack);
  }

  private Player markedPlayer() {
    if (marked == null) return null;
    for (Player p : arena.living()) if (p.getUniqueId().equals(marked)) return p;
    return null;
  }

  /** Rifts stay open for a while and burn whoever stands on them. */
  private void tickRifts(long now) {
    rifts.removeIf(r -> now >= r.until());
    if (rifts.isEmpty()) return;
    Location c = arena.center();
    for (Rift r : rifts) {
      if (now % 4 == 0)
        for (double d = -BossPatterns.ARENA; d <= BossPatterns.ARENA; d += 1.2)
          c.getWorld()
              .spawnParticle(
                  Particle.FLAME,
                  c.clone().add(Math.cos(r.angle()) * d, .2, Math.sin(r.angle()) * d),
                  1, .15, 0, .15, 0);
      for (Player p : arena.living())
        if (BossPatterns.rift(p.getX() - c.getX(), p.getZ() - c.getZ(), r.angle())
            && now - riftHits.getOrDefault(p.getUniqueId(), -100L) >= 20) {
          riftHits.put(p.getUniqueId(), now);
          if (arena.hurt(p, BossPatterns.damage(Attack.RIFT, arena.baseDamage(), enraged) * stacks(now)) > 0)
            arena.record(p, Attack.RIFT);
          p.setFireTicks(30);
        }
    }
  }

  /** Veteran/Albtraum last phase: the burning edge closes in. */
  private void tickEdge(long now) {
    if (phase < 2 || arena.mode() <= 0) return;
    double radius = BossPatterns.shrinkRadius(arena.mode(), now - phaseAt);
    if (radius >= BossPatterns.ARENA + 1) return;
    Location c = arena.center();
    if (now % 6 == 0) ring(c, radius, Color.fromRGB(255, 80, 20), (int) (radius * 6), 1.6);
    for (Player p : arena.living()) {
      double dx = p.getX() - c.getX(), dz = p.getZ() - c.getZ();
      if (dx * dx + dz * dz > radius * radius
          && now - edgeHits.getOrDefault(p.getUniqueId(), -100L) >= 20) {
        edgeHits.put(p.getUniqueId(), now);
        arena.hurt(p, arena.baseDamage() * .35);
        p.setFireTicks(20);
      }
    }
  }

  private double stacks(long now) {
    return enraged ? BossPatterns.enrageStacks(arena.mode(), now - enragedAt) : 1;
  }

  private Location clamp(Location l) {
    Location c = arena.center();
    Vector d = l.toVector().subtract(c.toVector()).setY(0);
    double max = BossPatterns.ARENA - 2;
    if (d.length() > max) d = d.normalize().multiply(max);
    return c.clone().add(d).setDirection(new Vector(0, 0, 1));
  }

  // ---- visuals ----

  private static void dust(Location l, Color c, float size) {
    l.getWorld().spawnParticle(Particle.DUST, l, 1, 0, 0, 0, 0, new Particle.DustOptions(c, size));
  }

  private static void ring(Location center, double radius, Color c, int points, double size) {
    for (int i = 0; i < points; i++) {
      double a = i * Math.PI * 2 / points;
      dust(center.clone().add(Math.cos(a) * radius, .2, Math.sin(a) * radius), c, (float) size);
    }
  }

  /** Outline plus an inner ring that grows until the attack lands. */
  private static void filled(Location center, double radius, double progress, Color c) {
    ring(center, radius, c, (int) Math.max(12, radius * 6), 1.3);
    ring(center, Math.max(.3, radius * Math.min(1, progress)), c, (int) Math.max(8, radius * 4), .9);
  }

  private static void line(Location from, Vector dir, int length, double progress, Color c) {
    for (int i = 1; i < length; i++) {
      Location l = from.clone().add(dir.clone().multiply(i)).add(0, .3, 0);
      dust(l, i <= length * progress ? c : Color.fromRGB(90, 30, 20), i <= length * progress ? 1.4f : .8f);
    }
  }

  private static void burst(Location center, double radius) {
    center.getWorld().spawnParticle(Particle.EXPLOSION, center.clone().add(0, .5, 0), 3, radius / 3, .2, radius / 3, 0);
    center.getWorld().spawnParticle(Particle.BLOCK, center.clone().add(0, .3, 0), 30, radius / 2, .1, radius / 2, Material.STONE.createBlockData());
  }

  private static void title(Player p, String big, String small, NamedTextColor color) {
    p.showTitle(
        Title.title(
            Component.text(big, color),
            Component.text(small, NamedTextColor.WHITE),
            Title.Times.times(Duration.ofMillis(80), Duration.ofMillis(900), Duration.ofMillis(250))));
  }

  /** Visual randomness only; gameplay decisions use the seeded pattern rotation. */
  private static final class ThreadLocalRandomHolder {
    static double next() {
      return java.util.concurrent.ThreadLocalRandom.current().nextDouble();
    }
  }
}
