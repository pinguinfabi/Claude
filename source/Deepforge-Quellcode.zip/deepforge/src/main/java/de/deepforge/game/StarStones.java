package de.deepforge.game;

import java.util.random.RandomGenerator;

/**
 * Sternenstein: only the Urboss drops it (2 %). The Urboss rises with 1 % after the Weltenkern (last mine)
 * boss was beaten on Albtraum – an extra fight, not a replacement. Used on gear: 10 % it becomes +11 (one step above the maximum,
 * "sternengeschmiedet"), 90 % it shatters.
 */
public final class StarStones {
  public static final double DROP = .02, SUCCESS = .10;
  /** Normal upgrades stop at +10; a Sternenstein lifts an item one step beyond: +11. */
  public static final int MAX_ENHANCE = 10, LEVEL = MAX_ENHANCE + 1, BOSS_ZONE = Zone.LAST, URBOSS_MODE = 2;
  public static final double URBOSS_CHANCE = .01;

  /** Sternenschlag: a star-forged weapon calls down a star on 12 % of its hits. */
  public static final double STRIKE_CHANCE = .12;

  public static boolean starWeapon(Profile p) {
    Gear.Item w = Gear.equipped(p, Gear.Slot.WEAPON);
    return w != null && w.level >= LEVEL;
  }

  /** Sternenschild: every other star-forged piece worn blocks 4 % of hits outright (max 20 %). */
  public static double shieldChance(Profile p) {
    int pieces = 0;
    for (Gear.Item i : p.gear)
      if (i.level >= LEVEL && i.slot != Gear.Slot.WEAPON && p.equipped.containsValue(i.id)) pieces++;
    return Math.min(.2, .04 * pieces);
  }

  public static boolean urbossPossible(int zone, int mode) {
    return zone == BOSS_ZONE && mode == URBOSS_MODE;
  }

  private StarStones() {}

  public static boolean maybeDrop(Profile p, RandomGenerator r) {
    if (r.nextDouble() >= DROP) return false;
    p.starStones++;
    return true;
  }

  public static String use(Profile p, String id, RandomGenerator r) {
    Gear.Item i = Gear.find(p, id);
    if (i == null) return "Gegenstand nicht gefunden.";
    if (p.starStones <= 0) return "Kein Sternenstein – nur der seltene Urboss (Weltenkern, Albtraum) lässt einen fallen.";
    if (i.level >= LEVEL) return "Dieser Gegenstand ist schon +" + i.level + ".";
    p.starStones--;
    if (r.nextDouble() < SUCCESS) {
      i.level = LEVEL;
      return "✦ ERFOLG! " + i.name + " ist jetzt +" + LEVEL + "!";
    }
    p.gear.remove(i);
    p.equipped.values().remove(i.id);
    if (p.gearPresets != null)
      for (GearPresets.Preset preset : p.gearPresets)
        if (preset != null && preset.items != null) preset.items.values().remove(i.id);
    p.seenGear.remove(i.id);
    return "ZERBROCHEN! " + i.name + " ist beim Sternenstein zersprungen.";
  }
}
