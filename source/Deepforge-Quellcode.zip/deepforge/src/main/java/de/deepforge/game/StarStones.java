package de.deepforge.game;

import java.util.random.RandomGenerator;

/**
 * Sternenstein: a 2 % drop, only from the strongest boss (the Leerenbruch mine boss). Used on a
 * piece of gear it makes it +12 with a 10 % chance – in the other 90 % the piece shatters.
 */
public final class StarStones {
  public static final double DROP = .02, SUCCESS = .10;
  public static final int LEVEL = 12, BOSS_ZONE = 6;

  private StarStones() {}

  public static boolean maybeDrop(Profile p, RandomGenerator r) {
    if (r.nextDouble() >= DROP) return false;
    p.starStones++;
    return true;
  }

  public static String use(Profile p, String id, RandomGenerator r) {
    Gear.Item i = Gear.find(p, id);
    if (i == null) return "Gegenstand nicht gefunden.";
    if (p.starStones <= 0) return "Kein Sternenstein – nur der Boss im Leerenbruch lässt selten einen fallen.";
    if (i.level >= LEVEL) return "Dieser Gegenstand ist schon +" + i.level + ".";
    p.starStones--;
    if (r.nextDouble() < SUCCESS) {
      i.level = LEVEL;
      return "✦ ERFOLG! " + i.name + " ist jetzt +" + LEVEL + "!";
    }
    p.gear.remove(i);
    p.equipped.values().remove(i.id);
    if (p.gearPresets != null)
      for (GearPresets.Preset preset : p.gearPresets)
        if (preset != null && preset.items != null) preset.items.values().remove(i.id);
    p.seenGear.remove(i.id);
    return "ZERBROCHEN! " + i.name + " ist beim Sternenstein zersprungen.";
  }
}
