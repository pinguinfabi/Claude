package de.deepforge.ui;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import de.deepforge.world.Dungeons;
import de.deepforge.world.SpectatorState;
import java.util.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

/**
 * Moderation for players with deepforge.admin: online players (inspect, visit, unstuck, remove
 * from a dungeon, adjust money), running dungeons (watch, close) and an admin mode that flies
 * through walls in spectator mode. Every action is written to the server log.
 */
public final class AdminMenu implements Listener {
  public static final String PERMISSION = "deepforge.admin";
  private static final int[] HEADS = {
    10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39,
    40, 41, 42, 43
  };

  private final DeepforgePlugin plugin;
  private final Set<UUID> mode = new HashSet<>();

  public AdminMenu(DeepforgePlugin plugin) {
    this.plugin = plugin;
    Bukkit.getPluginManager().registerEvents(this, plugin);
  }

  private static final class Screen implements InventoryHolder {
    Inventory inventory;
    UUID owner, target;
    String page;
    final Map<Integer, String> actions = new HashMap<>();

    public Inventory getInventory() {
      return inventory;
    }
  }

  // ---- admin mode ----

  public boolean inMode(Player p) {
    return mode.contains(p.getUniqueId()) && SpectatorState.active(p);
  }

  public void toggleMode(Player p) {
    if (inMode(p)) {
      leaveMode(p);
      plugin.tell(p, "Admin-Modus aus – zurück an deiner alten Position.");
      return;
    }
    if (plugin.dungeons().active(p)) {
      plugin.tell(p, "Zuerst den eigenen Dungeon verlassen.");
      return;
    }
    if (plugin.dungeons().watching(p)) plugin.dungeons().stopWatching(p, null);
    mode.add(p.getUniqueId());
    SpectatorState.enter(p);
    log(p, "Admin-Modus an", null);
    plugin.tell(
        p,
        "Admin-Modus an: Zuschauermodus, frei fliegen, durch Wände. /df admin mode beendet ihn"
            + " und bringt dich zurück.");
  }

  /** Ends the admin mode if it is on; safe to call for anyone. */
  public void leaveMode(Player p) {
    if (!mode.remove(p.getUniqueId())) return;
    if (SpectatorState.active(p) && !plugin.dungeons().watching(p)) SpectatorState.restore(p);
    log(p, "Admin-Modus aus", null);
  }

  public void close() {
    for (UUID id : new ArrayList<>(mode)) {
      Player p = Bukkit.getPlayer(id);
      if (p != null) leaveMode(p);
    }
    mode.clear();
  }

  // ---- pages ----

  public void open(Player p) {
    open(p, "main", null);
  }

  private void open(Player p, String page, UUID target) {
    if (!p.hasPermission(PERMISSION)) {
      plugin.tell(p, "Keine Berechtigung.");
      return;
    }
    Screen s = new Screen();
    s.owner = p.getUniqueId();
    s.page = page;
    s.target = target;
    String title =
        switch (page) {
          case "player" -> "ADMIN · SPIELER";
          case "dungeons" -> "ADMIN · DUNGEONS";
          default -> "ADMIN · MODERATION";
        };
    s.inventory = Bukkit.createInventory(s, 54, plugin.menus().styledTitle(p, title));
    switch (page) {
      case "player" -> player(p, s);
      case "dungeons" -> dungeons(s);
      default -> main(p, s);
    }
    button(s, 49, Material.BARRIER, "Schließen", "close");
    if (!page.equals("main")) button(s, 45, Material.ARROW, "Zurück", "main");
    p.openInventory(s.inventory);
  }

  private void main(Player p, Screen s) {
    List<Player> online =
        Bukkit.getOnlinePlayers().stream()
            .map(x -> (Player) x)
            .sorted(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER))
            .toList();
    int running = plugin.dungeons().overview().size();
    button(
        s,
        4,
        Material.BOOK,
        "Moderation",
        null,
        "Online: " + online.size() + " · Laufende Dungeons: " + running,
        "Spieler anklicken: ansehen, besuchen, Unstuck, Geld",
        "Alle Aktionen landen im Server-Log.");
    for (int i = 0; i < online.size() && i < HEADS.length; i++) {
      Player t = online.get(i);
      s.inventory.setItem(HEADS[i], head(t, summary(t)));
      s.actions.put(HEADS[i], "player:" + t.getUniqueId());
    }
    button(
        s,
        46,
        inMode(p) ? Material.LIME_DYE : Material.GRAY_DYE,
        "Admin-Modus: " + (inMode(p) ? "AN" : "AUS"),
        "mode",
        "Zuschauermodus: fliegen, durch Wände, unsichtbar für Gegner",
        "Beim Ausschalten zurück an die alte Position");
    button(
        s,
        48,
        Material.ENDER_EYE,
        "Laufende Dungeons (" + running + ")",
        "dungeons",
        "Zuschauen oder festgefahrene Läufe beenden");
    button(s, 50, Material.CLOCK, "Aktualisieren", "main");
  }

  private List<String> summary(Player t) {
    List<String> lines = new ArrayList<>();
    if (!plugin.playing(t)) {
      lines.add("Nicht in Deepforge");
      return lines;
    }
    Profile d = plugin.profile(t);
    lines.add("Geld: " + Hud.money(d.money) + " · Gebiet " + (d.zone + 1));
    lines.add(
        "Dungeonlevel "
            + Math.max(1, d.dungeonLevel)
            + " · Siege "
            + Arrays.stream(d.dungeonWins).sum());
    lines.add("Beutel: " + d.gear.size() + "/120 · Arbeiter: " + d.workers.size());
    if (plugin.dungeons().active(t)) lines.add("Gerade im Dungeon");
    if (plugin.dungeons().watching(t)) lines.add("Schaut gerade einem Dungeon zu");
    if (t.getGameMode() != GameMode.SURVIVAL) lines.add("Spielmodus: " + t.getGameMode());
    return lines;
  }

  private void player(Player admin, Screen s) {
    Player t = s.target == null ? null : Bukkit.getPlayer(s.target);
    if (t == null) {
      button(s, 22, Material.GRAY_DYE, "Spieler ist offline", null);
      return;
    }
    s.inventory.setItem(4, head(t, summary(t)));
    button(
        s,
        19,
        Material.ENDER_PEARL,
        plugin.dungeons().active(t) ? "Dungeon zuschauen" : "Hinfliegen (Admin-Modus)",
        "goto",
        plugin.dungeons().active(t)
            ? "Zuschauermodus im Dungeon von " + t.getName()
            : "Schaltet den Admin-Modus ein und bringt dich hin");
    button(
        s,
        21,
        Material.RED_BED,
        "Nach Hause schicken (Unstuck)",
        "home",
        "Bringt den Spieler zu seiner Mine",
        "Im Dungeon: verlässt den Lauf ohne Beute");
    button(
        s,
        23,
        Material.IRON_DOOR,
        "Aus Dungeon & Party entfernen",
        "kick",
        "Lauf verlassen, Party verlassen, Zuschauen beenden");
    button(
        s,
        25,
        Material.CHEST,
        "Werkzeuge neu ausgeben",
        "kit",
        "Repariert fehlende oder kaputte Deepforge-Items");
    long[] steps = {-10_000, -1_000, 1_000, 10_000};
    int[] slots = {29, 30, 32, 33};
    for (int i = 0; i < steps.length; i++)
      button(
          s,
          slots[i],
          steps[i] < 0 ? Material.REDSTONE : Material.EMERALD,
          (steps[i] < 0 ? "−" : "+") + Hud.money(Math.abs(steps[i])),
          "money:" + steps[i],
          steps[i] < 0 ? "Geld abziehen (nie unter 0)" : "Geld gutschreiben",
          "Der Spieler bekommt eine Nachricht");
  }

  private void dungeons(Screen s) {
    List<Dungeons.RunInfo> runs = plugin.dungeons().overview();
    if (runs.isEmpty()) {
      button(s, 22, Material.GRAY_DYE, "Gerade läuft kein Dungeon", null);
      return;
    }
    for (int i = 0; i < runs.size() && i < 4; i++) {
      Dungeons.RunInfo r = runs.get(i);
      int row = 10 + i * 9;
      button(s, row, Material.BOOK, r.title(), null, r.lines().toArray(String[]::new));
      button(s, row + 2, Material.ENDER_EYE, "Zuschauen", "watch:" + r.slot());
      button(
          s,
          row + 4,
          Material.BARRIER,
          "Lauf beenden (ohne Beute)",
          "end:" + r.slot(),
          "Für festgefahrene oder missbrauchte Läufe",
          "Shift-Klick zum Bestätigen");
    }
  }

  // ---- clicks ----

  @EventHandler
  public void click(InventoryClickEvent e) {
    if (!(e.getView().getTopInventory().getHolder() instanceof Screen s)) return;
    e.setCancelled(true);
    if (!(e.getWhoClicked() instanceof Player p) || !p.getUniqueId().equals(s.owner)) return;
    String action = s.actions.get(e.getRawSlot());
    if (action == null) return;
    boolean shift = e.isShiftClick();
    // Teleports and new windows are deferred until after the click event.
    Bukkit.getScheduler()
        .runTask(
            plugin,
            () -> {
              if (!p.isOnline()) return;
              if (!p.hasPermission(PERMISSION)) {
                p.closeInventory();
                return;
              }
              try {
                act(p, s, action, shift);
              } catch (IllegalArgumentException ex) {
                plugin.tell(p, ex.getMessage());
              }
            });
  }

  @EventHandler
  public void drag(InventoryDragEvent e) {
    if (e.getView().getTopInventory().getHolder() instanceof Screen) e.setCancelled(true);
  }

  private void act(Player p, Screen s, String action, boolean shift) {
    if (action.equals("close")) {
      p.closeInventory();
      return;
    }
    if (action.equals("main") || action.equals("dungeons")) {
      open(p, action, null);
      return;
    }
    if (action.equals("mode")) {
      toggleMode(p);
      open(p, "main", null);
      return;
    }
    if (action.startsWith("player:")) {
      open(p, "player", UUID.fromString(action.substring(7)));
      return;
    }
    if (action.startsWith("watch:")) {
      leaveMode(p);
      plugin.dungeons().watchSlot(p, Integer.parseInt(action.substring(6)));
      log(p, "schaut Dungeon " + action.substring(6) + " zu", null);
      return;
    }
    if (action.startsWith("end:")) {
      if (!shift) {
        plugin.tell(p, "Zum Beenden Shift-Klick verwenden.");
        return;
      }
      plugin.dungeons().closeRun(Integer.parseInt(action.substring(4)), "einem Admin");
      log(p, "hat Dungeon " + action.substring(4) + " beendet", null);
      open(p, "dungeons", null);
      return;
    }
    Player t = s.target == null ? null : Bukkit.getPlayer(s.target);
    if (t == null) {
      plugin.tell(p, "Der Spieler ist nicht mehr online.");
      open(p, "main", null);
      return;
    }
    switch (action) {
      case "goto" -> {
        if (plugin.dungeons().active(t)) {
          leaveMode(p);
          plugin.dungeons().spectate(p, t.getName());
        } else {
          if (!inMode(p)) toggleMode(p);
          if (!inMode(p)) return;
          p.closeInventory();
          p.teleport(t.getLocation());
        }
        log(p, "besucht", t);
        return;
      }
      case "home" -> {
        if (plugin.dungeons().watching(t)) plugin.dungeons().stopWatching(t, null);
        if (plugin.playing(t)) plugin.goHome(t);
        plugin.tell(t, "Ein Admin hat dich zu deiner Mine gebracht.");
        log(p, "Unstuck/nach Hause", t);
      }
      case "kick" -> {
        if (plugin.dungeons().watching(t)) plugin.dungeons().stopWatching(t, "Zuschauen beendet.");
        if (plugin.dungeons().active(t)) plugin.dungeons().withdraw(t);
        plugin.dungeons().parties().leave(t.getUniqueId());
        plugin.tell(t, "Ein Admin hat dich aus Dungeon und Party genommen.");
        log(p, "aus Dungeon/Party entfernt", t);
      }
      case "kit" -> {
        if (!plugin.playing(t)) throw new IllegalArgumentException("Nicht in Deepforge.");
        plugin.items().refresh(t, plugin.profile(t));
        plugin.tell(t, "Deine Deepforge-Werkzeuge wurden neu ausgegeben.");
        log(p, "Werkzeuge neu ausgegeben", t);
      }
      default -> {
        if (!action.startsWith("money:")) return;
        if (!plugin.playing(t)) throw new IllegalArgumentException("Nicht in Deepforge.");
        long delta = Long.parseLong(action.substring(6));
        long[] result = new long[1];
        plugin.change(
            t,
            d -> {
              long before = d.money;
              d.money = Math.max(0, Math.addExact(d.money, delta));
              result[0] = d.money - before;
              return "Ein Admin hat dein Guthaben angepasst: "
                  + (result[0] >= 0 ? "+" : "−")
                  + Hud.money(Math.abs(result[0]))
                  + ".";
            });
        log(p, "Geld " + result[0], t);
      }
    }
    open(p, "player", t.getUniqueId());
  }

  // ---- helpers ----

  private void log(Player admin, String what, Player target) {
    plugin
        .getLogger()
        .info(
            "[Admin] "
                + admin.getName()
                + ": "
                + what
                + (target == null ? "" : " -> " + target.getName()));
  }

  private ItemStack head(Player t, List<String> lore) {
    ItemStack item = new ItemStack(Material.PLAYER_HEAD);
    SkullMeta meta = (SkullMeta) item.getItemMeta();
    meta.setOwningPlayer(t);
    meta.displayName(
        Component.text(t.getName(), NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false));
    meta.lore(
        lore.stream()
            .map(
                l ->
                    (Component)
                        Component.text(l, NamedTextColor.GRAY)
                            .decoration(TextDecoration.ITALIC, false))
            .toList());
    item.setItemMeta(meta);
    return item;
  }

  private void button(
      Screen s, int slot, Material material, String name, String action, String... lore) {
    ItemStack item = new ItemStack(material);
    var meta = item.getItemMeta();
    meta.displayName(
        Component.text(name, NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false));
    meta.lore(
        Arrays.stream(lore)
            .map(
                l ->
                    (Component)
                        Component.text(l, NamedTextColor.GRAY)
                            .decoration(TextDecoration.ITALIC, false))
            .toList());
    item.setItemMeta(meta);
    s.inventory.setItem(slot, item);
    if (action != null) s.actions.put(slot, action);
  }
}
