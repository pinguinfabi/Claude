package de.deepforge.game;

import java.util.*;

/** Long-term goals with one-time rewards; progress reads the counters the game already keeps. */
public final class Milestones {
  public record Goal(String id, String title, String unit, long[] targets) {}

  public static final List<Goal> GOALS =
      List.of(
          new Goal("ore", "Bergmann", "Erz selbst abgebaut", new long[] {100, 1000, 10000}),
          new Goal("kills", "Monsterjäger", "Gegner besiegt", new long[] {25, 250, 2500}),
          new Goal("bosses", "Bossbezwinger", "Gebietsbosse besiegt", new long[] {1, 3, 7}),
          new Goal("trees", "Holzfäller", "Bäume gefällt", new long[] {25, 250, 1500}),
          new Goal("smelt", "Schmelzmeister", "Barren selbst geschmolzen", new long[] {50, 500, 5000}),
          new Goal("trade", "Marktprofi", "Barren am Markt verkauft", new long[] {50, 500, 5000}),
          new Goal("dungeons", "Gewölbegänger", "Dungeon-Siege", new long[] {1, 10, 50}),
          new Goal(
              "crew", "Unternehmer", "Arbeitsminuten deiner Mannschaft", new long[] {600, 6000, 60000}),
          new Goal("research", "Forscher", "Forschungsstufen", new long[] {3, 12, 25}));

  public static final long[] MONEY = {1000, 8000, 40000};
  public static final int[] DUST = {3, 8, 20}, RELICS = {0, 1, 3}, NOTES = {1, 3, 8};

  public static long progress(Profile p, String id) {
    return switch (id) {
      case "ore" -> p.mined;
      case "kills" -> p.kills;
      case "bosses" -> count(p.bosses);
      case "trees" -> p.woodTrees;
      case "smelt" -> p.manualSmelted;
      case "trade" -> p.soldBars;
      case "dungeons" -> Arrays.stream(p.dungeonWins).asLongStream().sum();
      case "crew" -> p.workers.stream().mapToLong(w -> w.workMinutes).sum();
      case "research" -> Arrays.stream(p.research).asLongStream().sum();
      default -> 0;
    };
  }

  private static long count(boolean[] values) {
    long n = 0;
    for (boolean v : values) if (v) n++;
    return n;
  }

  public static Goal goal(String id) {
    return GOALS.stream().filter(g -> g.id.equals(id)).findFirst().orElse(null);
  }

  /** Tiers already claimed, 0..3. */
  public static int claimed(Profile p, String id) {
    int tier = 0;
    while (tier < 3 && p.milestones.contains(id + ":" + tier)) tier++;
    return tier;
  }

  public static boolean claimable(Profile p, Goal g) {
    int tier = claimed(p, g.id);
    return tier < 3 && progress(p, g.id) >= g.targets[tier];
  }

  public static long claimableCount(Profile p) {
    return GOALS.stream().filter(g -> claimable(p, g)).count();
  }

  public static String reward(int tier) {
    return MONEY[tier]
        + " $, "
        + DUST[tier]
        + " Schmiedestaub"
        + (RELICS[tier] > 0 ? ", " + RELICS[tier] + " Relikt" + (RELICS[tier] > 1 ? "e" : "") : "")
        + ", "
        + NOTES[tier]
        + " Unterlage"
        + (NOTES[tier] > 1 ? "n" : "");
  }

  public static String claim(Profile p, String id) {
    Goal g = goal(id);
    if (g == null) return "Unbekannter Meilenstein.";
    int tier = claimed(p, id);
    if (tier >= 3) return "Meilenstein bereits vollständig abgeschlossen.";
    long have = progress(p, id);
    if (have < g.targets[tier])
      return "Es fehlen "
          + (g.targets[tier] - have)
          + " für "
          + g.title
          + " Stufe "
          + (tier + 1)
          + " ("
          + g.unit
          + ").";
    p.milestones.add(id + ":" + tier);
    p.money += MONEY[tier];
    p.lifetimeRevenue += MONEY[tier];
    p.dust += DUST[tier];
    p.relics += RELICS[tier];
    p.researchNotes += NOTES[tier];
    return "Meilenstein " + g.title + " Stufe " + (tier + 1) + " abgeschlossen: +" + reward(tier) + ".";
  }

  private Milestones() {}
}
