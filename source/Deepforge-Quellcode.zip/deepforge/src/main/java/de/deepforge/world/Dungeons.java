package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import de.deepforge.ui.Hud;
import java.util.*;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

/**
 * Bounded, private cooperative instances in the plugin-owned world. All state runs on the main
 * thread.
 */
public final class Dungeons implements Listener, AutoCloseable {
  private final DeepforgePlugin plugin;
  private final PartyBook parties = new PartyBook();
  private final Map<UUID, Run> membership = new HashMap<>();
  private final Map<Integer, Run> runs = new HashMap<>();
  private final Map<UUID, Enemy> enemies = new HashMap<>();
  private final Map<UUID, Long> clicks = new HashMap<>();
  private final Map<UUID, Run> watching = new HashMap<>();
  private final Random random = new Random();
  private final BukkitTask task;
  private long tick;
  private String verification = "Noch nicht gestartet";
  private static final Material[] RUNES = {
    Material.RED_CONCRETE, Material.BLUE_CONCRETE, Material.LIME_CONCRETE, Material.YELLOW_CONCRETE
  };
  private static final String[] NAMES = {"Rot", "Blau", "Grün", "Gelb"};

  private enum Stage {
    BUILDING,
    COUNTDOWN,
    WAVE,
    TRAVEL,
    SIDE,
    PUZZLE,
    COMPLETE
  }

  private static final class Run {
    final UUID id = UUID.randomUUID();
    final int slot, zone, mode, x, level, totalWaves;
    final DungeonVariant variant;
    // Glutschmiede: spots that erupt at eruptLand; Frostkrypta: frost stacks and warm braziers.
    final List<Location> eruptSpots = new ArrayList<>();
    long eruptNext, eruptLand;
    final Map<UUID, Integer> frost = new HashMap<>();
    final List<Location> braziers = new ArrayList<>();
    long frostNext;
    // Players watching this run in spectator mode.
    final Set<UUID> watchers = new LinkedHashSet<>();
    // Players currently taking part; follows leaves and disconnects during the run.
    int size;
    final LinkedHashSet<UUID> members;
    final Map<UUID, Long> disconnected = new HashMap<>();
    final Set<UUID> down = new HashSet<>();
    final Map<UUID, Integer> healingDrops = new HashMap<>();
    final DungeonBlessings blessings = new DungeonBlessings();
    final Set<Long> chunks = new HashSet<>();
    final List<Enemy> mobs = new ArrayList<>();
    final List<Entity> decorations = new ArrayList<>();
    final BossBar bar =
        BossBar.bossBar(
            Component.text("Gewölbe wird vorbereitet"),
            1,
            BossBar.Color.PURPLE,
            BossBar.Overlay.PROGRESS);
    Stage stage = Stage.BUILDING;
    long deadline, started, sealTicks;
    int room, cursor, wave, memoryStep, mistakes, pending, spawned, reinforcements;
    int optionalFlags, pendingOptional, diagnosticExtra;
    boolean challengeAttempted, key;
    // Generated layout, build progress and per-room state.
    DungeonPlan plan;
    List<int[]> boxes = List.of();
    int boxIndex, roomWave;
    long boxCursor, timeTicks;
    boolean[] branchOpen = new boolean[0];
    final Map<Integer, Object> puzzleStates = new HashMap<>();
    // Blocks players can click: puzzle parts and optional side-room objects.
    final Map<org.bukkit.block.Block, String> clickables = new HashMap<>();
    final Map<Integer, ItemDisplay> mirrors = new HashMap<>();
    final Map<UUID, Long> trapHits = new HashMap<>();
    long puzzleStarted, plateDeadline;
    boolean mimicKey;
    final Set<Integer> shrinesBuilt = new HashSet<>();
    // Room whose blessing can be chosen right now, and its shrine blocks (index = blessing).
    int shrineRoom = -1;
    final List<org.bukkit.block.Block> shrines = new ArrayList<>();
    Villager captive;
    boolean diagnostic, ended;
    boolean diagnosticValid = true, diagnosticElite, diagnosticBoss;
    int diagnosticChecked;
    final Set<Integer> diagnosticKinds = new HashSet<>();
    List<Integer> sequence = List.of();
    // Players hit by a big boss attack; everyone else earns the flawless bonus.
    final Set<UUID> bossStruck = new HashSet<>();
    boolean bossFought;

    Run(int slot, int zone, int mode, List<UUID> ids) {
      this(slot, zone, mode, ids, 1);
    }

    Run(int slot, int zone, int mode, List<UUID> ids, int level) {
      this(slot, zone, mode, ids, level, DungeonVariant.GEWOELBE);
    }

    Run(int slot, int zone, int mode, List<UUID> ids, int level, DungeonVariant variant) {
      this.variant = variant;
      this.slot = slot;
      this.zone = zone;
      this.mode = mode;
      this.level = level;
      totalWaves = DungeonRules.waves(level);
      plan =
          DungeonPlan.generate(
              id.getMostSignificantBits() ^ id.getLeastSignificantBits(), totalWaves, level);
      boxes = plan.boxes();
      timeTicks = plan.minutes() * 1200L;
      branchOpen = new boolean[plan.rooms.size()];
      size = Math.max(1, ids.size());
      x = -512 - slot * 128;
      members = new LinkedHashSet<>(ids);
    }
  }

  private static final class Enemy {
    Run run;
    // Room the enemy belongs to; it never leaves it.
    int room;
    Mob mob;
    MonsterRig rig;
    MonsterHealthIndicator health;
    int kind;
    boolean boss, elite;
    double hp, max;
    long attackAt, resolveAt, recoilAt;
    final BossPressure pressure = new BossPressure();
    Location sweepOrigin;
    int spell;
    Location marker, secondary;
    Vector direction;
    BossBrain brain;
  }

  public Dungeons(DeepforgePlugin plugin) {
    this.plugin = plugin;
    Bukkit.getPluginManager().registerEvents(this, plugin);
    task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1, 2);
  }

  public boolean active(Player p) {
    return membership.containsKey(p.getUniqueId());
  }

  public PartyBook parties() {
    return parties;
  }

  public boolean down(Player p) {
    Run r = membership.get(p.getUniqueId());
    return r != null && r.down.contains(p.getUniqueId());
  }

  public boolean shrineBlock(Player p, org.bukkit.block.Block block) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || block == null) return false;
    if (r.clickables.containsKey(block)) return true;
    if (r.stage != Stage.TRAVEL) return false;
    for (int i = 0; i < 3; i++) if (block.equals(at(r, -8 + i * 8, 0, -10).getBlock())) return true;
    return false;
  }

  private DungeonPlan.Room room(Run r) {
    return r.plan.rooms.get(r.room);
  }

  /** Relative to the current room: centre of the floor, y = 0 is where players stand. */
  private Location at(Run r, double x, double y, double z) {
    return in(r, room(r), x, y, z);
  }

  private Location in(Run r, DungeonPlan.Room room, double x, double y, double z) {
    return worldAt(r, room.cx + x, room.floor + y, room.cz + z);
  }

  private Location worldAt(Run r, double x, double y, double z) {
    return new Location(plugin.mines().world(), r.x + x + .5, 65 + y, -512 + z + .5, 180, 0);
  }

  public boolean contains(Player p) {
    Run r = membership.get(p.getUniqueId());
    return r != null && inside(r, p.getLocation());
  }

  private boolean inside(Run r, Location l) {
    return l.getWorld().equals(plugin.mines().world())
        && r.plan != null
        && r.plan.contains(l.getX() - r.x, l.getY() - 65, l.getZ() + 512);
  }

  /** Inside the walls of a room, at least {@code margin} blocks away from them. */
  private boolean inRoom(Run r, DungeonPlan.Room room, Location l, double margin) {
    double x = l.getX() - r.x - room.cx - .5, z = l.getZ() + 512 - room.cz - .5;
    return Math.abs(x) <= room.hw - .5 - margin && Math.abs(z) <= room.hd - .5 - margin;
  }

  private String roomName(Run r, DungeonPlan.Room room) {
    return switch (room.role) {
      case START -> r.variant.room(0);
      case BOSS -> r.variant.room(2);
      case SIDE ->
          switch (room.side) {
            case CHALLENGE -> "Prüfungskammer";
            case PRISON -> "Zellentrakt";
            case TREASURE -> "Schatzkammer";
          };
      default ->
          (switch (r.variant) {
                case GEWOELBE -> "Runen";
                case GLUTSCHMIEDE -> "Schlacken";
                case FROSTKRYPTA -> "Eis";
              })
              + switch (room.shape) {
                case PILLARS -> "säulenhalle";
                case BRIDGE -> "brücke";
                case CRYPT -> "gruft";
                case GAUNTLET -> "gang";
                case CHAMBER -> "kammer";
                case ARENA -> "arena";
                default -> "halle";
              };
    };
  }

  private List<Player> online(Run r) {
    return r.members.stream()
        .map(Bukkit::getPlayer)
        .filter(Objects::nonNull)
        .filter(Player::isOnline)
        .toList();
  }

  private List<Player> living(Run r) {
    return online(r).stream()
        .filter(
            p ->
                !r.down.contains(p.getUniqueId())
                    && plugin.playing(p)
                    && !p.isDead()
                    && inside(r, p.getLocation()))
        .toList();
  }

  private void say(Run r, String text) {
    online(r).forEach(p -> plugin.tell(p, text));
    for (UUID id : r.watchers) {
      Player w = Bukkit.getPlayer(id);
      if (w != null) plugin.tell(w, "[Zuschauer] " + text);
    }
  }

  private void partySay(PartyBook.Party party, String text) {
    for (UUID id : party.members) {
      Player p = Bukkit.getPlayer(id);
      if (p != null) plugin.tell(p, text);
    }
  }

  public void command(Player p, String[] args) {
    if (!plugin.playing(p)) {
      plugin.tell(p, "Zuerst /df start.");
      return;
    }
    try {
      if (args[0].equalsIgnoreCase("dungeon")) {
        if (args.length > 2 && args[1].equalsIgnoreCase("segen")) {
          Run r = membership.get(p.getUniqueId());
          int choice = Integer.parseInt(args[2]) - 1;
          if (r == null) plugin.tell(p, "Du bist in keinem Dungeon.");
          else if (choice < 0 || choice > 2) plugin.tell(p, "Segen 1 = Kraft, 2 = Schutz, 3 = Quelle.");
          else bless(r, p, choice);
          return;
        }
        if (args.length > 1 && args[1].equalsIgnoreCase("hint")) {
          Run r = membership.get(p.getUniqueId());
          if (r != null && r.stage == Stage.PUZZLE) replayPuzzle(r);
          return;
        }
        if (args.length > 1 && args[1].equalsIgnoreCase("leave")) {
          if (watching(p)) stopWatching(p, "Zuschauen beendet.");
          else withdraw(p);
          return;
        }
        if (args.length > 1
            && Set.of("zuschauen", "spectate", "watch").contains(args[1].toLowerCase(Locale.ROOT))) {
          spectate(p, args.length > 2 ? args[2] : null);
          return;
        }
        if (args.length > 1 && args[1].equalsIgnoreCase("start")) {
          int mode = args.length > 2 ? Integer.parseInt(args[2]) - 1 : 0;
          int zone = args.length > 3 ? Integer.parseInt(args[3]) - 1 : commonZone(p);
          int variant = args.length > 4 ? Integer.parseInt(args[4]) - 1 : 0;
          if (variant < 0 || variant >= DungeonVariant.values().length)
            throw new IllegalArgumentException(
                "Dungeon 1 = Runengewölbe, 2 = Glutschmiede, 3 = Frostkrypta.");
          start(p, zone, mode, DungeonVariant.of(variant));
          return;
        }
        open(p, commonZone(p), lastVariant(p));
        return;
      }
      String action = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "status";
      UUID id = p.getUniqueId();
      if (active(p) && !action.equals("status"))
        throw new IllegalArgumentException(
            "Während des Laufs ist die Party fest. /df dungeon leave zum Aussteigen.");
      switch (action) {
        case "create" -> {
          parties.create(id);
          plugin.tell(p, "Party erstellt. /df party invite <Spieler> · maximal 4 Spieler.");
        }
        case "invite" -> {
          Player guest = args.length > 2 ? Bukkit.getPlayerExact(args[2]) : null;
          if (guest == null || !plugin.playing(guest) || active(guest))
            throw new IllegalArgumentException("Der Spieler muss online und in Deepforge sein.");
          parties.invite(id, guest.getUniqueId(), System.currentTimeMillis());
          plugin.tell(
              guest,
              p.getName() + " lädt dich ins Gewölbe ein. /df party accept (60 Sekunden gültig).");
          plugin.tell(p, "Einladung an " + guest.getName() + " gesendet.");
        }
        case "accept" -> {
          // An invitation is invalidated when its leader starts a run.
          PartyBook.Party joined = parties.accept(id, System.currentTimeMillis());
          if (joined.members.stream().anyMatch(membership::containsKey)) {
            parties.leave(id);
            throw new IllegalArgumentException("Die Gruppe ist schon im Dungeon.");
          }
          partySay(
              joined, p.getName() + " ist beigetreten. Alle bestätigen neu mit /df party ready.");
        }
        case "ready" -> {
          boolean ready = parties.ready(id);
          partySay(
              parties.get(id), p.getName() + (ready ? " ist bereit." : " ist nicht mehr bereit."));
        }
        case "leave" -> {
          parties.leave(id);
          plugin.tell(p, "Party verlassen.");
        }
        default -> {
          PartyBook.Party party = parties.get(id);
          if (party == null)
            plugin.tell(
                p, "/df party create · invite <Name> · accept · ready · leave. Solo: /df dungeon.");
          else {
            plugin.tell(p, "Party: " + party.members.size() + "/4 · Leiter: " + name(party.leader));
            for (UUID member : party.members)
              plugin.tell(
                  p, name(member) + (party.ready.contains(member) ? " · Bereit" : " · Wartet"));
          }
        }
      }
    } catch (IllegalArgumentException e) {
      plugin.tell(p, DeepforgePlugin.readable(e, e.getMessage() == null ? "Ungültige Eingabe." : e.getMessage()));
    }
  }

  private String name(UUID id) {
    Player p = Bukkit.getPlayer(id);
    return p == null ? "Offline" : p.getName();
  }

  private int commonZone(Player p) {
    PartyBook.Party party = parties.get(p.getUniqueId());
    int zone = plugin.profile(p).zone;
    if (party != null)
      for (UUID id : party.members) {
        Player m = Bukkit.getPlayer(id);
        if (m != null) zone = Math.min(zone, plugin.profile(m).zone);
      }
    return zone;
  }

  private int previewLevel(Player p, int zone) {
    PartyBook.Party party = parties.get(p.getUniqueId());
    List<Profile> profiles = new ArrayList<>();
    profiles.add(plugin.profile(p));
    if (party != null)
      for (UUID id : party.members) {
        Player member = Bukkit.getPlayer(id);
        if (member != null && !id.equals(p.getUniqueId())) profiles.add(plugin.profile(member));
      }
    return DungeonRules.groupLevel(profiles, zone);
  }

  private static final class Menu implements InventoryHolder {
    Inventory inventory;
    int zone;
    DungeonVariant variant = DungeonVariant.GEWOELBE;
    UUID owner;

    public Inventory getInventory() {
      return inventory;
    }
  }

  private ItemStack icon(Material material, String title, String... lore) {
    String model =
        switch (material) {
          case LIME_DYE -> "relic";
          case PLAYER_HEAD -> "gear_helmet";
          case OAK_DOOR, BARRIER -> "close";
          case IRON_SWORD -> "weapon_sword";
          case DIAMOND_SWORD -> "weapon_spear";
          case NETHERITE_SWORD -> "weapon_hammer";
          case ARROW -> "back";
          case AMETHYST_SHARD -> "healing_crystal";
          case CHEST -> "crate";
          case CLOCK -> "clock";
          default -> "handbook";
        };
    return icon(material, model, false, title, lore);
  }

  /** Menu button; {@code model == null} keeps the vanilla item, {@code glint} marks the choice. */
  private ItemStack icon(
      Material material, String model, boolean glint, String title, String... lore) {
    ItemStack item = plugin.items().button(material, model == null ? "handbook" : model, title, lore);
    org.bukkit.inventory.meta.ItemMeta meta = item.getItemMeta();
    if (model == null) meta.setItemModel(null);
    if (glint) meta.setEnchantmentGlintOverride(true);
    item.setItemMeta(meta);
    return item;
  }

  // Last dungeon picked in the menu, so reopening shows the same one.
  private final Map<UUID, DungeonVariant> picked = new HashMap<>();

  private DungeonVariant lastVariant(Player p) {
    Run r = membership.get(p.getUniqueId());
    return r != null ? r.variant : picked.getOrDefault(p.getUniqueId(), DungeonVariant.GEWOELBE);
  }

  /** Every party member (or the player alone) has this dungeon unlocked. */
  private boolean unlockedForAll(Player p, DungeonVariant v) {
    if (!v.unlocked(plugin.profile(p))) return false;
    PartyBook.Party party = parties.get(p.getUniqueId());
    if (party != null)
      for (UUID id : party.members) {
        Player m = Bukkit.getPlayer(id);
        if (m != null && !v.unlocked(plugin.profile(m))) return false;
      }
    return true;
  }

  public void open(Player p, int zone) {
    open(p, zone, lastVariant(p));
  }

  /** Members whose progress blocks {@code mode} in {@code zone}, with the reason. */
  private List<String> missing(Player p, int zone, int mode) {
    List<String> out = new ArrayList<>();
    PartyBook.Party party = parties.get(p.getUniqueId());
    List<UUID> ids = party == null ? List.of(p.getUniqueId()) : List.copyOf(party.members);
    for (UUID id : ids) {
      Player member = Bukkit.getPlayer(id);
      if (member == null) {
        out.add(name(id) + " (offline)");
        continue;
      }
      Profile data = plugin.profile(member);
      if (data.zone < zone) out.add(member.getName() + " (Gebiet fehlt)");
      else if (mode > 0 && data.dungeonWins[zone * 3 + mode - 1] == 0)
        out.add(member.getName() + " (" + DungeonRules.MODES[mode - 1] + "-Sieg fehlt)");
    }
    return out;
  }

  // Menu layout: one row per step, labels in the left column.
  private static final int ROW_DUNGEON = 9, ROW_ZONE = 18, ROW_MODE = 27, ROW_PARTY = 36;
  private static final Material[] VARIANT_ICONS = {
    Material.CHISELED_STONE_BRICKS, Material.MAGMA_BLOCK, Material.PACKED_ICE
  };

  public void open(Player p, int zone, DungeonVariant variant) {
    boolean inRun = active(p);
    Menu m = new Menu();
    m.zone = Math.clamp(zone, 0, commonZone(p));
    int level = inRun ? membership.get(p.getUniqueId()).level : previewLevel(p, m.zone);
    m.variant = unlockedForAll(p, variant) ? variant : DungeonVariant.GEWOELBE;
    picked.put(p.getUniqueId(), m.variant);
    m.owner = p.getUniqueId();
    m.inventory =
        Bukkit.createInventory(m, 54, plugin.menus().styledTitle(p, "DUNGEON · LEVEL " + level));
    PartyBook.Party party = parties.get(p.getUniqueId());
    int size = party == null ? 1 : party.members.size();
    Inventory inv = m.inventory;

    // Summary of the current choice.
    inv.setItem(
        4,
        icon(
            VARIANT_ICONS[m.variant.ordinal()],
            null,
            true,
            m.variant.title + " · " + Zone.at(m.zone).title,
            "Endboss: " + m.variant.boss(m.zone),
            m.variant.hazard,
            m.variant.loot,
            "5–8 Räume · " + DungeonRules.waves(level) + " Wellen · 2–3 Rätsel · jedes Mal neu",
            "Bedingung: " + DungeonRules.conditionName(level),
            "Dein Level in diesem Gebiet: " + DungeonRules.level(plugin.profile(p), m.zone),
            party != null ? "Gruppenlevel = höchstes Level der Party in diesem Gebiet" : ""));

    // 1 · Dungeon
    inv.setItem(ROW_DUNGEON, icon(Material.PAPER, "handbook", false, "① Dungeon wählen"));
    for (DungeonVariant v : DungeonVariant.values()) {
      boolean open = unlockedForAll(p, v), chosen = v == m.variant;
      inv.setItem(
          ROW_DUNGEON + 2 + v.ordinal() * 2,
          icon(
              open ? VARIANT_ICONS[v.ordinal()] : Material.BARRIER,
              open ? null : "close",
              chosen,
              (chosen ? "▶ " : "") + v.title + (open ? "" : " · gesperrt"),
              v.flavor,
              v.hazard,
              v.loot,
              "Deine Siege hier: " + DungeonVariant.wins(plugin.profile(p), v),
              chosen
                  ? "✔ Ausgewählt"
                  : open
                      ? "Klick: auswählen"
                      : "✖ " + v.requirement() + (party != null ? " (alle in der Party)" : "")));
    }

    // 2 · Gebiet
    int unlocked = commonZone(p);
    inv.setItem(ROW_ZONE, icon(Material.PAPER, "handbook", false, "② Gebiet wählen"));
    inv.setItem(
        ROW_ZONE + 2,
        m.zone > 0
            ? icon(Material.ARROW, "back", false, "◀ " + Zone.at(m.zone - 1).title)
            : icon(Material.GRAY_DYE, null, false, "Erstes Gebiet"));
    inv.setItem(
        ROW_ZONE + 4,
        icon(
            Material.RAW_IRON,
            "ore_" + Zone.at(m.zone).key,
            true,
            "Gebiet " + (m.zone + 1) + ": " + Zone.at(m.zone).title,
            "Dein Dungeonlevel hier: " + DungeonRules.level(plugin.profile(p), m.zone),
            "Wählbar: Gebiet 1 bis " + (unlocked + 1),
            party != null
                ? "Die Party kann nur Gebiete wählen, die alle freigeschaltet haben."
                : "Neue Gebiete schaltest du im Aufzug frei."));
    inv.setItem(
        ROW_ZONE + 6,
        m.zone < unlocked
            ? icon(Material.ARROW, "next", false, Zone.at(m.zone + 1).title + " ▶")
            : icon(
                Material.GRAY_DYE,
                null,
                false,
                m.zone < 6 ? "Gebiet " + (m.zone + 2) + " gesperrt" : "Letztes Gebiet",
                m.zone < 6
                    ? "Zuerst im Aufzug freischalten" + (party != null ? " (alle in der Party)" : "")
                    : ""));

    // 3 · Schwierigkeit & Start
    inv.setItem(ROW_MODE, icon(Material.PAPER, "handbook", false, "③ Schwierigkeit & Start"));
    boolean leader = party == null || party.leader.equals(p.getUniqueId());
    boolean allReady = party == null || party.ready.containsAll(party.members);
    for (int mode = 0; mode < 3; mode++) {
      List<String> blocked = missing(p, m.zone, mode);
      String state =
          inRun
              ? "Ihr seid schon im Dungeon."
              : !blocked.isEmpty()
                  ? "✖ Gesperrt – fehlt bei: " + String.join(", ", blocked)
                  : !allReady
                      ? "✖ Noch nicht alle bereit (" + party.ready.size() + "/" + size + ")"
                      : !leader ? "✖ Nur der Partyleiter kann starten" : "✔ Klick: jetzt starten!";
      List<String> lore = new ArrayList<>();
      lore.add(
          m.variant.coins(DungeonRules.coins(m.zone, mode, level))
              + " $ pro Person · Boss "
              + (int) DungeonRules.health(m.zone, mode, size, DungeonRules.waves(level), true, level)
              + " LP");
      lore.add(
          "Mythisch "
              + DungeonRules.mythicThreshold(mode, level) / 10.
              + " % · Legendär "
              + (DungeonRules.legendaryThreshold(mode, level)
                      - DungeonRules.mythicThreshold(mode, level))
                  / 10.
              + " %");
      if (mode > 0) lore.add("Braucht: " + DungeonRules.MODES[mode - 1] + "-Sieg in diesem Gebiet (alle)");
      lore.add(state);
      Material weapon =
          mode == 0 ? Material.IRON_SWORD : mode == 1 ? Material.DIAMOND_SWORD : Material.NETHERITE_SWORD;
      boolean ready = state.startsWith("✔");
      inv.setItem(
          ROW_MODE + 2 + mode * 2,
          icon(
              blocked.isEmpty() ? weapon : Material.BARRIER,
              blocked.isEmpty()
                  ? mode == 0 ? "weapon_sword" : mode == 1 ? "weapon_spear" : "weapon_hammer"
                  : "close",
              ready,
              DungeonRules.MODES[mode] + (blocked.isEmpty() ? "" : " · gesperrt"),
              lore.toArray(String[]::new)));
    }

    // 4 · Party
    inv.setItem(ROW_PARTY, icon(Material.PAPER, "handbook", false, "④ Party"));
    List<String> members = new ArrayList<>();
    if (party == null) members.add("Solo – du spielst allein");
    else
      for (UUID id : party.members)
        members.add(
            (party.ready.contains(id) ? "✔ " : "✖ ")
                + name(id)
                + (id.equals(party.leader) ? " (Leiter)" : ""));
    members.add("Einladen: /df party invite <Name>");
    members.add("Bis zu 4 Spieler · Gruppenlevel = höchstes Level");
    inv.setItem(
        ROW_PARTY + 2,
        icon(
            Material.PLAYER_HEAD,
            "gear_helmet",
            false,
            party == null ? "Keine Party" : "Party " + party.ready.size() + "/" + size + " bereit",
            members.toArray(String[]::new)));
    boolean meReady = party != null && party.ready.contains(p.getUniqueId());
    inv.setItem(
        ROW_PARTY + 4,
        icon(
            meReady ? Material.LIME_DYE : Material.GRAY_DYE,
            meReady ? "relic" : null,
            meReady,
            meReady ? "✔ Du bist bereit" : "Bereit melden",
            party == null ? "Solo: einfach eine Schwierigkeit anklicken" : "Klick: umschalten"));
    inv.setItem(
        ROW_PARTY + 6,
        icon(
            Material.OAK_DOOR,
            "close",
            false,
            inRun ? "Dungeon verlassen" : "Party verlassen",
            inRun ? "Du verlierst die Abschlussbeute dieses Laufs" : ""));
    long others = runs.values().stream().filter(r -> !r.members.contains(p.getUniqueId())).count();
    inv.setItem(
        ROW_PARTY + 8,
        icon(
            Material.ENDER_EYE,
            null,
            false,
            watching(p) ? "Nächsten Dungeon ansehen" : "Zuschauen",
            others == 0 ? "Gerade läuft kein anderer Dungeon" : others + " laufen gerade",
            "Beenden: /df dungeon leave"));

    // Bottom bar
    inv.setItem(45, icon(Material.ARROW, "Zurück: Kampf & Ausrüstung"));
    inv.setItem(47, icon(Material.BOOK, "Hauptmenü"));
    inv.setItem(49, icon(Material.BARRIER, "Schließen"));
    inv.setItem(
        51,
        icon(
            Material.CHEST,
            "So läuft ein Dungeon",
            "Jeder Lauf baut einen neuen Grundriss: 5–8 Räume",
            "Verwinkelte Gänge, Treppen, Nebenräume",
            "2–3 Rätsel aus 8: Runen, Siegel, Hebel, Platten,",
            "Lichtstrahl, Fallengang, Glocken, falsche Truhen",
            "Am Ende: " + m.variant.room(2) + " mit dem Endboss",
            "Optional: Prüfung, Rettung, Schatzkammer (Schlüssel im Fass)",
            "Niederlage: alle gleichzeitig besiegt",
            "Jedes Gebiet hat sein eigenes Level: Sieg = +1 dort",
            "Beute: /df loot · Kisten nach dem Sieg: /df reward"));
    inv.setItem(
        53,
        icon(
            Material.AMETHYST_SHARD,
            "Heilen · " + plugin.profile(p).healingCharges + " Splitter",
            "Klick: heilen · 4 LP + 35 % Leben · 20 s Pause",
            "Rechtsklick: 1 nachkaufen · " + Healing.price(plugin.profile(p)) + " $",
            "Shift-Klick: auffüllen bis 12"));
    plugin.items().forViewer(m.inventory, p);
    p.openInventory(m.inventory);
  }

  @EventHandler
  public void click(InventoryClickEvent e) {
    if (!(e.getView().getTopInventory().getHolder() instanceof Menu m)) return;
    e.setCancelled(true);
    if (!(e.getWhoClicked() instanceof Player p) || !m.owner.equals(p.getUniqueId())) return;
    int slot = e.getRawSlot();
    if (slot == 53) {
      if (e.getClick() == ClickType.DOUBLE_CLICK) return;
      int buy = e.isShiftClick() ? Healing.CAPACITY : e.isRightClick() ? 1 : 0;
      Bukkit.getScheduler().runTask(plugin, () -> {
        if (!p.isOnline()) return;
        if (buy == 0) {
          p.closeInventory();
          plugin.healing().use(p);
        } else {
          plugin.healing().buy(p, buy);
          open(p, m.zone, m.variant);
        }
      });
      return;
    }
    // Opening another inventory inside the click event is unreliable; act one tick later.
    Bukkit.getScheduler().runTask(plugin, () -> {
      if (p.isOnline()) menuClick(p, m, slot);
    });
  }

  private void menuClick(Player p, Menu m, int slot) {
    try {
      if (slot == 49) p.closeInventory();
      else if (slot == 45 || slot == 47) plugin.menus().open(p, slot == 45 ? "combat" : "main");
      else if (slot == ROW_PARTY + 4) {
        if (active(p)) throw new IllegalArgumentException("Die Gruppe ist bereits im Dungeon.");
        if (parties.get(p.getUniqueId()) == null) parties.create(p.getUniqueId());
        parties.ready(p.getUniqueId());
        open(p, m.zone, m.variant);
      } else if (slot == ROW_PARTY + 6) {
        p.closeInventory();
        if (active(p)) withdraw(p);
        else parties.leave(p.getUniqueId());
      } else if (slot == ROW_PARTY + 8) spectate(p, null);
      else if (slot == ROW_ZONE + 2 || slot == ROW_ZONE + 6) {
        int next = m.zone + (slot == ROW_ZONE + 2 ? -1 : 1);
        if (next < 0 || next > commonZone(p)) {
          p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, .6f, 1);
          plugin.tell(
              p,
              next < 0
                  ? "Das ist bereits das erste Gebiet."
                  : "Gebiet " + (next + 1) + " ist noch nicht freigeschaltet"
                      + (parties.get(p.getUniqueId()) != null ? " (für alle in der Party)." : "."));
        } else {
          p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, .6f, 1.2f);
          open(p, next, m.variant);
        }
      } else if (slot >= ROW_DUNGEON + 2 && slot <= ROW_DUNGEON + 6 && slot % 2 == 1) {
        DungeonVariant v = DungeonVariant.of((slot - ROW_DUNGEON - 2) / 2);
        if (!unlockedForAll(p, v)) {
          p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, .6f, 1);
          plugin.tell(p, v.title + " ist noch gesperrt. " + v.requirement() + ".");
        } else {
          p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, .6f, 1.2f);
          open(p, m.zone, v);
        }
      } else if (slot == ROW_MODE + 2 || slot == ROW_MODE + 4 || slot == ROW_MODE + 6)
        start(p, m.zone, (slot - ROW_MODE - 2) / 2, m.variant);
    } catch (IllegalArgumentException ex) {
      p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, .6f, 1);
      plugin.tell(p, ex.getMessage());
    }
  }

  @EventHandler
  public void drag(InventoryDragEvent e) {
    if (e.getView().getTopInventory().getHolder() instanceof Menu) e.setCancelled(true);
  }

  private void start(Player leader, int zone, int mode, DungeonVariant variant) {
    if (zone < 0 || zone > 6 || mode < 0 || mode > 2)
      throw new IllegalArgumentException("/df dungeon start <1..3 Schwierigkeit> <1..7 Gebiet>");
    if (parties.get(leader.getUniqueId()) == null) {
      parties.create(leader.getUniqueId());
      parties.ready(leader.getUniqueId());
    }
    // Alone in a party (e.g. from the last run): starting is being ready.
    PartyBook.Party own = parties.get(leader.getUniqueId());
    if (own.members.size() == 1) own.ready.add(leader.getUniqueId());
    List<UUID> roster = parties.roster(leader.getUniqueId());
    for (UUID id : roster) {
      Player p = Bukkit.getPlayer(id);
      if (p == null
          || !plugin.playing(p)
          || p.isDead()
          || p.getGameMode() != GameMode.SURVIVAL
          || plugin.combat().fighting(p))
        throw new IllegalArgumentException(
            "Alle müssen online, im Überlebensmodus und außerhalb eines Kampfes sein.");
      Profile data = plugin.profile(p);
      if (data.zone < zone || mode > 0 && data.dungeonWins[zone * 3 + mode - 1] == 0)
        throw new IllegalArgumentException(
            p.getName() + " hat Gebiet oder Schwierigkeit noch nicht freigeschaltet.");
      if (!variant.unlocked(data))
        throw new IllegalArgumentException(
            p.getName()
                + " hat "
                + variant.title
                + " noch nicht freigeschaltet. "
                + variant.requirement()
                + ".");
    }
    int slot = 0;
    while (runs.containsKey(slot)) slot++;
    if (slot >= 4)
      throw new IllegalArgumentException("Alle vier Gewölbe sind belegt. Bitte kurz warten.");
    int level =
        DungeonRules.groupLevel(
            roster.stream().map(Bukkit::getPlayer).map(plugin::profile).toList(), zone);
    Run r = new Run(slot, zone, mode, roster, level, variant);
    r.started = tick;
    runs.put(slot, r);
    for (UUID id : roster) {
      Player p = Bukkit.getPlayer(id);
      plugin.combat().clear(p, false);
      p.closeInventory();
      membership.put(id, r);
      p.showBossBar(r.bar);
      plugin.autoPreset(p, GearPresets.AUTO_DUNGEON);
    }
    parties.get(leader.getUniqueId()).ready.clear();
    say(
        r,
        r.variant.title + " wird aufgebaut. Gruppe: "
            + roster.size()
            + " · "
            + DungeonRules.MODES[mode]
            + " · Level "
            + level
            + " · "
            + DungeonRules.conditionName(level)
            + ".");
  }

  private void tick() {
    tick += 2;
    if (tick % 20 == 0) keepWatchers();
    for (Run r : new ArrayList<>(runs.values())) {
      try {
        step(r);
        leash(r);
        followRigs(r);
      } catch (RuntimeException ex) {
        plugin.getLogger().log(java.util.logging.Level.SEVERE, "Dungeon instance failed", ex);
        finish(r, false, "Gewölbe wegen eines Fehlers geschlossen; dein Inventar bleibt erhalten.");
        if (r.diagnostic) verification = "FAILED: " + ex.getMessage();
      }
    }
  }

  /**
   * Keeps every monster model on its mob. Enemies are only driven during fights; in puzzles,
   * while walking or when nobody is standing, a pushed mob used to leave its bones behind.
   */
  private void followRigs(Run r) {
    if (r.ended) return;
    for (Enemy e : r.mobs)
      if (e.rig != null && e.mob.isValid() && !e.rig.animatedAt(tick))
        e.rig.animate(
            e.mob.getLocation(), tick, false, false, e.mob.getVelocity().lengthSquared() > .001);
  }

  /** Half size of the area a boss may use: the hall is 40x40, walls and alcoves stay off-limits. */
  static final double BOSS_AREA = 17;

  /**
   * The boss never leaves its hall: players could otherwise lure it into the gallery or the
   * downed alcove and fight it from safety. Pushed or walked out, it is set back at the edge.
   */
  private void leash(Run r) {
    if (r.ended || r.plan == null) return;
    for (Enemy e : r.mobs) {
      if (!e.mob.isValid()) continue;
      DungeonPlan.Room room = r.plan.rooms.get(e.room);
      Location l = e.mob.getLocation();
      double x = l.getX() - r.x - room.cx - .5, z = l.getZ() + 512 - room.cz - .5;
      double limitX = room.hw - 2, limitZ = room.hd - 2;
      double cx = Math.clamp(x, -limitX, limitX), cz = Math.clamp(z, -limitZ, limitZ);
      if (room.shape == DungeonPlan.Shape.ARENA) {
        double radius = Math.min(room.hw, room.hd) - 2.5, d = Math.hypot(x, z);
        if (d > radius) {
          cx = x * radius / d;
          cz = z * radius / d;
        }
      }
      boolean fell = l.getY() < 65 + room.floor - 1.2;
      if (cx == x && cz == z && !fell && l.getY() < 65 + room.floor + room.height) continue;
      Location back = fell ? in(r, room, 0, 0, 0) : in(r, room, cx, 0, cz);
      back.setYaw(l.getYaw());
      e.mob.teleport(back);
      e.mob.setVelocity(new Vector());
    }
  }

  /** Enemy health keeps its percentage when the party shrinks or grows mid-run. */
  private void resize(Run r) {
    int now =
        Math.max(
            1,
            (int)
                r.members.stream()
                    .filter(id -> !r.disconnected.containsKey(id) && Bukkit.getPlayer(id) != null)
                    .count());
    if (now == r.size) return;
    double ratio = RapidCombat.partyHealth(now) / RapidCombat.partyHealth(r.size);
    for (Enemy e : r.mobs) {
      e.max *= ratio;
      e.hp *= ratio;
    }
    say(
        r,
        "Gewölbe passt sich an: "
            + now
            + " Spieler – Gegner werden "
            + (now < r.size ? "schwächer." : "stärker."));
    r.size = now;
  }

  private void step(Run r) {
    if (r.stage == Stage.BUILDING) {
      build(r);
      return;
    }
    if (r.diagnostic) {
      diagnose(r);
      return;
    }
    resize(r);
    hazard(r);
    for (UUID id : new ArrayList<>(r.members)) {
      Player p = Bukkit.getPlayer(id);
      if (p == null) {
        r.disconnected.putIfAbsent(id, tick);
        if (tick - r.disconnected.get(id) > 1200) remove(r, id);
      } else if (r.disconnected.containsKey(id)) {
        if (tick - r.disconnected.get(id) > 1200) {
          remove(r, id);
          p.hideBossBar(r.bar);
          plugin.goHome(p);
        }
      } else if (!plugin.playing(p)) {
        remove(r, id);
        p.hideBossBar(r.bar);
      } else if (!inside(r, p.getLocation())) p.teleport(checkpoint(r, r.down.contains(id)));
      else if (!r.down.contains(id)) {
        // Fell into the pit of a bridge room: back to the entrance with a scratch.
        DungeonPlan.Room room = room(r);
        if (room.shape == DungeonPlan.Shape.BRIDGE
            && p.getY() < 65 + room.floor - 1.5
            && inRoom(r, room, p.getLocation(), 0)) {
          p.teleport(checkpoint(r, false));
          hurt(r, p, DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * .5);
          plugin.tell(p, "In den Abgrund gestürzt! Bleib auf den Brücken.");
        }
      }
    }
    if (r.members.isEmpty()) {
      finish(r, false, "Gruppe aufgelöst.");
      return;
    }
    if (tick - r.started > r.timeTicks) {
      finish(r, false, "Zeitlimit erreicht. Neuer Versuch im Dungeonmenü.");
      return;
    }
    if (r.members.stream().allMatch(r.down::contains)) {
      finish(r, false, "Die Gruppe wurde besiegt. Eure Ausrüstung bleibt erhalten.");
      return;
    }
    if (living(r).isEmpty()) return;
    switch (r.stage) {
      case TRAVEL -> {
        DungeonPlan.Room next =
            r.room + 1 < r.plan.mainRooms ? r.plan.rooms.get(r.room + 1) : null;
        if (next != null
            && living(r).stream().allMatch(p -> inRoom(r, next, p.getLocation(), 1.5)))
          enterNextRoom(r);
        else if (next != null && tick % 20 == 0) circle(entrance(r, next), 2, Color.AQUA);
      }
      case COUNTDOWN -> {
        if (tick >= r.deadline) beginWave(r);
      }
      case SIDE -> {
        for (Enemy e : new ArrayList<>(r.mobs)) enemyTick(e);
        if (r.mobs.isEmpty()) completeChallenge(r);
      }
      case WAVE -> {
        for (Enemy e : new ArrayList<>(r.mobs)) enemyTick(e);
        refill(r);
        if (r.mobs.isEmpty() && r.pending == 0) waveDone(r);
      }
      case PUZZLE -> {
        for (Enemy e : new ArrayList<>(r.mobs)) enemyTick(e);
        puzzleTick(r);
      }
      default -> {}
    }
    if (tick % 20 == 0 && !r.ended) updateBar(r);
  }

  private void waveDone(Run r) {
    revive(r);
    if (r.wave >= r.totalWaves) {
      finish(r, true, r.variant.title + " bezwungen!");
      return;
    }
    r.roomWave++;
    DungeonPlan.Room room = room(r);
    if (r.roomWave < room.waves) countdown(r);
    else if (room.puzzle != null) startPuzzle(r);
    else travel(r);
  }

  private void updateBar(Run r) {
    DungeonPlan.Room room = room(r);
    String label =
        switch (r.stage) {
          case TRAVEL ->
              r.room + 1 < r.plan.mainRooms
                  ? "Tor offen: weiter in "
                      + roomName(r, r.plan.rooms.get(r.room + 1))
                      + (room.sideRoom >= 0 && r.branchOpen[r.room] ? " · Nebenraum offen" : "")
                  : "";
          case SIDE -> "Optionale Prüfung · " + r.mobs.size() + " Elitegegner";
          case PUZZLE -> puzzleLabel(r);
          case COUNTDOWN -> "Nächste Welle in " + Math.max(0, (r.deadline - tick) / 20) + " s";
          default ->
              r.mobs.stream()
                  .filter(m -> m.brain != null)
                  .findFirst()
                  .map(m -> m.brain.status(tick))
                  .orElse(
                      "Welle "
                          + r.wave
                          + "/"
                          + r.totalWaves
                          + " · Gegner "
                          + r.mobs.size()
                          + " +"
                          + r.pending);
        };
    r.bar.name(
        Component.text(
            roomName(r, room)
                + " · Raum "
                + (r.room + 1)
                + "/"
                + r.plan.mainRooms
                + " · L"
                + r.level
                + " · "
                + label
                + " · "
                + Math.max(0, (r.timeTicks - tick + r.started) / 1200)
                + " Min"));
    r.bar.progress(
        (float)
            Math.clamp(
                (r.room + (r.stage == Stage.TRAVEL ? 1 : .5)) / (double) r.plan.mainRooms, 0, 1));
  }

  private final Map<String, org.bukkit.block.data.BlockData> blockCache = new HashMap<>();

  private org.bukkit.block.data.BlockData block(Run r, DungeonPlan.Paint paint, int x, int y, int z) {
    DungeonPlan.Room room = r.plan.roomAt(x, z);
    int style = room == null ? 0 : room.role == DungeonPlan.Role.BOSS ? 2 : room.index % 3;
    boolean crack = Math.floorMod(x * 31 + y * 17 + z * 7, 13) == 0;
    Material base =
        switch (paint) {
          case AIR -> Material.AIR;
          case WALL, CEILING ->
              crack
                  ? Material.CRACKED_STONE_BRICKS
                  : new Material[] {
                        Material.STONE_BRICKS,
                        Material.DEEPSLATE_BRICKS,
                        Material.POLISHED_BLACKSTONE_BRICKS
                      }
                      [style];
          case FLOOR ->
              crack
                  ? Material.CRACKED_STONE_BRICKS
                  : new Material[] {
                        Material.POLISHED_ANDESITE,
                        Material.DEEPSLATE_TILES,
                        Material.POLISHED_BLACKSTONE
                      }
                      [style];
          case PATH ->
              Math.floorMod(x + z, 4) == 0
                  ? Material.CHISELED_STONE_BRICKS
                  : Material.DEEPSLATE_TILES;
          case STAIR_N, STAIR_E, STAIR_S, STAIR_W -> Material.STONE_BRICK_STAIRS;
          case LIGHT -> Material.SEA_LANTERN;
          case ACCENT -> DungeonLayout.accent(r.zone);
          case PILLAR -> Material.POLISHED_BASALT;
          case DECOR -> Material.CHISELED_TUFF_BRICKS;
          case PIT_FLOOR ->
              switch (r.variant) {
                case GLUTSCHMIEDE -> Material.MAGMA_BLOCK;
                case FROSTKRYPTA -> Material.BLUE_ICE;
                default -> Material.SOUL_SOIL;
              };
        };
    Material material = DungeonLayout.remap(r.variant, base);
    String facing =
        switch (paint) {
          case STAIR_N -> "north";
          case STAIR_E -> "east";
          case STAIR_S -> "south";
          case STAIR_W -> "west";
          default -> null;
        };
    String key = material.name() + (facing == null ? "" : ":" + facing);
    return blockCache.computeIfAbsent(
        key,
        k ->
            facing == null
                ? material.createBlockData()
                : Bukkit.createBlockData(
                    material, data -> ((org.bukkit.block.data.Directional) data).setFacing(org.bukkit.block.BlockFace.valueOf(facing.toUpperCase(Locale.ROOT)))));
  }

  private void build(Run r) {
    int budget = 1600;
    while (budget > 0 && r.boxIndex < r.boxes.size()) {
      int[] b = r.boxes.get(r.boxIndex);
      int w = b[3] - b[0] + 1, d = b[4] - b[1] + 1, h = b[5] - b[2] + 1;
      long total = (long) w * d * h;
      for (; budget > 0 && r.boxCursor < total; budget--, r.boxCursor++) {
        int x = b[0] + (int) (r.boxCursor % w);
        int z = b[1] + (int) (r.boxCursor / w % d);
        int y = b[2] + (int) (r.boxCursor / ((long) w * d));
        DungeonPlan.Paint paint = r.plan.paint(x, y, z);
        if (paint == null) continue;
        int bx = r.x + x, bz = -512 + z;
        long chunkKey = ((long) (bz >> 4) << 32) | ((bx >> 4) & 0xffffffffL);
        if (r.chunks.add(chunkKey))
          plugin.mines().world().getChunkAt(bx >> 4, bz >> 4).addPluginChunkTicket(plugin);
        plugin
            .mines()
            .world()
            .getBlockAt(bx, 65 + y, bz)
            .setBlockData(block(r, paint, x, y, z), false);
      }
      if (r.boxCursor >= total) {
        r.boxIndex++;
        r.boxCursor = 0;
      }
    }
    if (r.boxIndex < r.boxes.size()) return;
    furnish(r);
    if (r.diagnostic) {
      r.stage = Stage.COUNTDOWN;
      return;
    }
    for (Player p : online(r)) {
      if (!plugin.playing(p)) continue;
      p.teleport(checkpoint(r, false));
      plugin.combat().applyStats(p);
      p.setHealth(Gear.stats(plugin.profile(p)).health());
      p.setFoodLevel(20);
    }
    say(
        r,
        r.variant.title
            + ": "
            + r.plan.mainRooms
            + " Räume · "
            + r.plan.rooms.stream().filter(x -> x.puzzle != null).count()
            + " Rätsel"
            + (r.plan.rooms.size() > r.plan.mainRooms ? " · Nebenräume zu entdecken" : "")
            + ". Rote Kreise und orange Strahlen kündigen Angriffe an. Ausweichen: Sneak +"
            + " Rechtsklick mit Waffe. /df dungeon leave beendet deinen Lauf.");
    startRoom(r);
  }

  /** Gates, labels, puzzles, side rooms, braziers: everything after the raw blocks. */
  private void furnish(Run r) {
    for (DungeonPlan.Room room : r.plan.rooms) {
      if (room.role != DungeonPlan.Role.SIDE) {
        if (room.in != null) gate(r, room, room.in, false);
        if (room.out != null) gate(r, room, room.out, false);
        if (room.sideDoor != null) gate(r, room, room.sideDoor, false);
      }
      DungeonPlan.Dir entry = room.in == null ? DungeonPlan.Dir.S : room.in;
      label(
          r,
          room,
          entry.dx * (room.hw - 2),
          Math.min(4, room.height - 2),
          entry.dz * (room.hd - 2),
          roomName(r, room)
              + (room.puzzle != null ? "\nRätsel: " + room.puzzle.title : "")
              + (room.role == DungeonPlan.Role.BOSS ? "\nEndboss: " + r.variant.boss(r.zone) : ""),
          NamedTextColor.GOLD);
      if (room.puzzle != null) setupPuzzle(r, room);
      if (room.keyBarrel) {
        org.bukkit.block.Block barrel = in(r, room, -(room.hw - 2), 0, -(room.hd - 2)).getBlock();
        barrel.setType(Material.BARREL, false);
        r.clickables.put(barrel, "key");
        label(r, room, -(room.hw - 2), 1.6, -(room.hd - 2), "Verstaubtes Fass · untersuchen", NamedTextColor.GOLD);
      }
      if (room.role == DungeonPlan.Role.SIDE) setupSide(r, room);
      if (r.variant == DungeonVariant.FROSTKRYPTA
          && room.role != DungeonPlan.Role.SIDE
          && room.shape != DungeonPlan.Shape.GAUNTLET) {
        int o = Math.min(room.hw, room.hd) - (room.shape == DungeonPlan.Shape.ARENA ? 6 : 4);
        for (int side = -1; side <= 1; side += 2) {
          Location at = in(r, room, side * o, 0, -side * o);
          at.getBlock().setType(Material.POLISHED_BLACKSTONE_WALL, false);
          at.clone().add(0, 1, 0).getBlock().setType(Material.CAMPFIRE, false);
          r.braziers.add(at);
          if (side < 0) label(r, room, side * o, 2.6, -side * o, "GLUTBECKEN\nHier aufwärmen", NamedTextColor.GOLD);
        }
      }
    }
  }

  private void label(
      Run r, DungeonPlan.Room room, double x, double y, double z, String text, NamedTextColor color) {
    r.decorations.add(
        plugin
            .mines()
            .world()
            .spawn(
                in(r, room, x, y, z),
                TextDisplay.class,
                d -> {
                  d.text(Component.text(text, color));
                  d.setBillboard(Display.Billboard.CENTER);
                  d.setPersistent(false);
                }));
  }

  /** Room entrance point (inside, in front of the entry door). */
  private Location entrance(Run r, DungeonPlan.Room room) {
    DungeonPlan.Dir entry = room.in == null ? DungeonPlan.Dir.S : room.in;
    return in(r, room, entry.dx * (room.hw - 3), .1, entry.dz * (room.hd - 3));
  }

  private Location checkpoint(Run r, boolean down) {
    DungeonPlan.Room room = room(r);
    if (down) return standable(at(r, room.hw - 2, 0, 0));
    Location l = entrance(r, room);
    l.setY(65 + room.floor);
    return standable(l);
  }

  /**
   * Moves a spot up until feet and head are free. The boss hall has a raised amethyst floor in the
   * viewing alcove; downed players used to be placed inside it.
   */
  private static Location standable(Location l) {
    Location at = l.clone();
    for (int i = 0; i < 6; i++) {
      if (at.getBlock().isPassable() && at.clone().add(0, 1, 0).getBlock().isPassable()) return at;
      at.add(0, 1, 0);
    }
    return l;
  }

  private void gate(Run r, DungeonPlan.Room room, DungeonPlan.Dir d, boolean open) {
    int x = room.doorX(d), z = room.doorZ(d);
    for (int lateral = -1; lateral <= 1; lateral++)
      for (int y = 0; y < 4; y++)
        worldAt(r, x + (d.alongX() ? 0 : lateral), room.floor + y, z + (d.alongX() ? lateral : 0))
            .getBlock()
            .setType(open ? Material.AIR : Material.IRON_BARS, false);
    Location at = worldAt(r, x, room.floor + 1, z);
    at.getWorld().playSound(at, Sound.BLOCK_IRON_DOOR_OPEN, 1, .6f);
  }

  private void travel(Run r) {
    r.stage = Stage.TRAVEL;
    DungeonPlan.Room room = room(r);
    if (room.out != null) {
      gate(r, room, room.out, true);
      DungeonPlan.Room next = r.plan.rooms.get(r.room + 1);
      gate(r, next, next.in, true);
    }
    if (room.sideRoom >= 0 && !r.branchOpen[r.room]) sideGate(r, true);
    if (room.waves == 0 || !r.shrinesBuilt.add(r.room)) {
      say(r, "Das Tor ist offen! Geht gemeinsam weiter.");
      return;
    }
    r.shrineRoom = r.room;
    r.shrines.clear();
    List<Location> spots = shrineSpots(r, room);
    Material[] stones = {
      Material.RED_GLAZED_TERRACOTTA, Material.BLUE_GLAZED_TERRACOTTA, Material.LIME_GLAZED_TERRACOTTA
    };
    for (int i = 0; i < spots.size(); i++) {
      org.bukkit.block.Block shrine = spots.get(i).getBlock();
      shrine.setType(stones[i], false);
      r.shrines.add(shrine);
      final String title = BLESSINGS[i];
      r.decorations.add(
          plugin
              .mines()
              .world()
              .spawn(
                  spots.get(i).clone().add(.5, 2, .5),
                  TextDisplay.class,
                  display -> {
                    display.text(
                        Component.text(
                            title + "\nEin Segen pro Raum · Rechtsklick", NamedTextColor.AQUA));
                    display.setBillboard(Display.Billboard.CENTER);
                    display.setPersistent(false);
                  }));
    }
    say(
        r,
        "Das Tor ist offen! Geht gemeinsam weiter."
            + (room.sideRoom >= 0 ? " Ein Nebenraum ist jetzt auch offen." : ""));
    for (Player member : online(r)) offerBlessing(r, member);
  }

  static final String[] BLESSINGS = {
    "KRAFT · +8% Schaden", "SCHUTZ · -8% erlittener Schaden", "QUELLE · 35% Leben heilen"
  };

  /** Three free floor spots along a wall without a door, or none (the chat buttons still work). */
  private List<Location> shrineSpots(Run r, DungeonPlan.Room room) {
    for (int inset = 2; inset <= 5; inset++)
      for (int spacing : new int[] {6, 4, 3})
        for (DungeonPlan.Dir d : DungeonPlan.Dir.values()) {
          if (d == room.in || d == room.out || d == room.sideDoor) continue;
          int depth = (d.alongX() ? room.hw : room.hd) - inset;
          int half = (d.alongX() ? room.hd : room.hw) - 2;
          if (depth < 2 || half < spacing) continue;
          List<Location> spots = new ArrayList<>();
          for (int k = -1; k <= 1; k++) {
            int x = room.cx + d.dx * depth + (d.alongX() ? 0 : k * spacing);
            int z = room.cz + d.dz * depth + (d.alongX() ? k * spacing : 0);
            org.bukkit.block.Block b = worldAt(r, x, room.floor, z).getBlock();
            if (!b.getType().isAir()
                || !b.getRelative(0, 1, 0).getType().isAir()
                || !b.getRelative(0, -1, 0).getType().isSolid()) break;
            spots.add(b.getLocation());
          }
          if (spots.size() == 3) return spots;
        }
    return List.of();
  }

  /** Clickable blessing choice in chat, so a blessing can always be picked. */
  private void offerBlessing(Run r, Player p) {
    if (r.shrineRoom < 0 || r.blessings.chosen(p.getUniqueId(), r.shrineRoom)) return;
    Component line = Component.text("Segen wählen » ", NamedTextColor.AQUA);
    NamedTextColor[] colors = {NamedTextColor.RED, NamedTextColor.BLUE, NamedTextColor.GREEN};
    for (int i = 0; i < 3; i++)
      line =
          line.append(
                  Component.text("[" + BLESSINGS[i] + "]", colors[i])
                      .clickEvent(
                          net.kyori.adventure.text.event.ClickEvent.runCommand(
                              "/df dungeon segen " + (i + 1)))
                      .hoverEvent(
                          net.kyori.adventure.text.event.HoverEvent.showText(
                              Component.text("Ein Segen pro Raum", NamedTextColor.GRAY))))
              .append(Component.text(" "));
    p.sendMessage(line);
  }

  private void bless(Run r, Player p, int i) {
    if (r.shrineRoom < 0) {
      plugin.tell(p, "Segen gibt es, sobald ein Kampfraum geschafft ist.");
      return;
    }
    if (down(p)) return;
    double max = Gear.stats(plugin.profile(p)).health();
    if (i == 2 && p.getHealth() >= max) {
      plugin.tell(p, "Du bist bereits vollständig geheilt. Wähle Kraft oder Schutz.");
      return;
    }
    if (!r.blessings.choose(p.getUniqueId(), r.shrineRoom, i)) {
      plugin.tell(p, "Du hast den Segen dieses Raums bereits gewählt.");
      return;
    }
    if (i == 2) p.setHealth(Math.min(max, p.getHealth() + max * .35));
    plugin.tell(
        p,
        new String[] {
              "Kraftsegen: +8% Schaden für diesen Lauf (bis zu 3× stapelbar).",
              "Schutzsegen: -8% erlittener Schaden für diesen Lauf (bis zu 3× stapelbar).",
              "Die Quelle heilt 35% deines maximalen Lebens."
            }
            [i]);
    p.playSound(p.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1, 1.2f);
  }


  private void sideGate(Run r, boolean open) {
    DungeonPlan.Room room = room(r);
    if (room.sideDoor == null) return;
    r.branchOpen[r.room] = open;
    gate(r, room, room.sideDoor, open);
  }


  private void startChallenge(Run r, boolean curse, DungeonPlan.Room side) {
    r.challengeAttempted = true;
    r.pendingOptional = curse ? AdventureRewards.CURSE : AdventureRewards.ELITE;
    r.stage = Stage.SIDE;
    DungeonPlan.Room room = room(r);
    if (room.out != null) {
      gate(r, room, room.out, false);
      DungeonPlan.Room next = r.plan.rooms.get(r.room + 1);
      gate(r, next, next.in, false);
    }
    for (int i = 0; i < r.size + 2; i++) {
      spawnAt(r, false, i % 4, in(r, side, -4 + (i % 3) * 4, 0, -3 + (i / 3) * 3), side.index);
      Enemy e = r.mobs.getLast();
      e.elite = true;
      e.hp =
          e.max =
              DungeonRules.health(r.zone, r.mode, r.size, Math.max(1, r.wave), false, r.level)
                  * (curse ? 2 : 1.4);
      e.mob.customName(Component.text(enemyName(e), NamedTextColor.RED));
      health(e);
    }
    say(
        r,
        curse
            ? "Fluchprüfung gestartet! Besiegt die Elite für zwei Bonusfunde."
            : "Eliteprüfung gestartet! Besiegt die Elite für einen Bonusfund.");
  }

  private void completeChallenge(Run r) {
    r.optionalFlags |= r.pendingOptional;
    r.pendingOptional = 0;
    revive(r);
    travel(r);
    say(r, "Prüfung bestanden! Die Beute wird nach dem Endboss ausgezahlt.");
  }

  private void rescue(Run r, DungeonPlan.Room prison) {
    if ((r.optionalFlags & AdventureRewards.RESCUE) != 0 || r.captive == null) return;
    for (int x = -1; x <= 1; x++)
      for (int z = -1; z <= 1; z++)
        for (int y = 0; y < 3; y++)
          if (x != 0 || z != 0) in(r, prison, x, y, z).getBlock().setType(Material.AIR, false);
    r.captive.customName(Component.text("Bergarbeiter gerettet!", NamedTextColor.GREEN));
    r.optionalFlags |= AdventureRewards.RESCUE;
    say(r, "Bergarbeiter befreit! Bei Abschluss: Bonusfund und dauerhaft 20% Händlerrabatt.");
  }

  private void takeKey(Run r, org.bukkit.block.Block barrel) {
    if (r.key) return;
    r.key = true;
    barrel.setType(Material.AIR, false);
    r.clickables.remove(barrel);
    say(r, "Gruppenschlüssel gefunden! Er öffnet die Schatzkammer in einem der nächsten Räume.");
  }

  private void takeTreasure(Run r, org.bukkit.block.Block chest) {
    if (!r.key || (r.optionalFlags & AdventureRewards.TREASURE) != 0) return;
    r.optionalFlags |= AdventureRewards.TREASURE;
    chest.setType(Material.BARREL, false);
    r.clickables.remove(chest);
    say(r, "Schatz gesichert! Ein zusätzlicher Bonusfund wartet nach dem Endboss.");
  }

  /** Contents of an optional side room. */
  private void setupSide(Run r, DungeonPlan.Room side) {
    switch (side.side) {
      case CHALLENGE -> {
        org.bukkit.block.Block elite = in(r, side, -3, 0, -3).getBlock();
        org.bukkit.block.Block curse = in(r, side, 3, 0, -3).getBlock();
        elite.setType(Material.RED_GLAZED_TERRACOTTA, false);
        curse.setType(Material.PURPLE_GLAZED_TERRACOTTA, false);
        r.clickables.put(elite, "elite");
        r.clickables.put(curse, "curse");
        label(r, side, -3, 1.6, -3, "ELITEPRÜFUNG · 1 Bonusfund\nRechtsklick · Gruppenleiter", NamedTextColor.GOLD);
        label(r, side, 3, 1.6, -3, "FLUCHPRÜFUNG · 2 Bonusfunde\nDoppelte Gegner-LP", NamedTextColor.GOLD);
      }
      case PRISON -> {
        for (int x = -1; x <= 1; x++)
          for (int z = -1; z <= 1; z++)
            for (int y = 0; y < 3; y++)
              if (x != 0 || z != 0) in(r, side, x, y, z).getBlock().setType(Material.IRON_BARS, false);
        in(r, side, 0, 3, 0).getBlock().setType(Material.IRON_BARS, false);
        org.bukkit.block.Block lock = in(r, side, 0, 0, -4).getBlock();
        lock.setType(Material.LODESTONE, false);
        r.clickables.put(lock, "lock");
        label(r, side, 0, 1.6, -4, "ZELLENSCHLOSS · Rechtsklick\nRettung: Bonusfund + Händlerrabatt", NamedTextColor.GOLD);
        r.captive =
            plugin
                .mines()
                .world()
                .spawn(
                    in(r, side, 0, 0, 0),
                    Villager.class,
                    false,
                    v -> {
                      v.setAI(false);
                      v.setAdult();
                      v.setInvulnerable(true);
                      v.setSilent(true);
                      v.setPersistent(false);
                      v.customName(Component.text("Gefangener Bergarbeiter", NamedTextColor.GOLD));
                      v.setCustomNameVisible(true);
                    });
        r.decorations.add(r.captive);
      }
      case TREASURE -> {
        org.bukkit.block.Block chest = in(r, side, 0, 0, 0).getBlock();
        chest.setBlockData(Bukkit.createBlockData("minecraft:chest[facing=south]"), false);
        r.clickables.put(chest, "treasure");
        label(r, side, 0, 1.6, 0, "SCHATZKAMMER · Schlüssel benötigt\nRechtsklick zum Öffnen", NamedTextColor.GOLD);
      }
    }
  }

  @EventHandler
  public void captiveInteraction(PlayerInteractEntityEvent e) {
    if (runs.values().stream().anyMatch(r -> r.captive == e.getRightClicked())) {
      e.setCancelled(true);
      plugin.tell(e.getPlayer(), "Das Zellenschloss vor dem Käfig öffnet die Tür.");
    }
  }

  @EventHandler(priority = EventPriority.LOW)
  public void optional(PlayerInteractEvent e) {
    Player p = e.getPlayer();
    Run r = membership.get(p.getUniqueId());
    if (r == null
        || down(p)
        || e.getHand() != EquipmentSlot.HAND
        || !e.getAction().isRightClick()
        || e.getClickedBlock() == null) return;
    String action = r.clickables.get(e.getClickedBlock());
    if (action == null || !Set.of("elite", "curse", "lock", "treasure", "key").contains(action)) return;
    e.setCancelled(true);
    if (p.getLocation().distanceSquared(e.getClickedBlock().getLocation()) > 36) return;
    DungeonPlan.Room here = r.plan.roomAt(
        e.getClickedBlock().getX() - r.x, e.getClickedBlock().getZ() + 512);
    switch (action) {
      case "key" -> takeKey(r, e.getClickedBlock());
      case "treasure" -> {
        if (!r.key)
          plugin.tell(p, "Verschlossen. Der Schlüssel liegt in einem Fass in einem der Räume davor.");
        else takeTreasure(r, e.getClickedBlock());
      }
      case "lock" -> {
        if (here != null && r.branchOpen[here.parent]) rescue(r, here);
      }
      default -> {
        if (here == null || r.stage != Stage.TRAVEL || r.room != here.parent || r.challengeAttempted) {
          plugin.tell(p, "Diese Prüfung ist noch nicht verfügbar oder bereits gewählt.");
          return;
        }
        PartyBook.Party party = parties.get(p.getUniqueId());
        if (party != null && !party.leader.equals(p.getUniqueId())) {
          plugin.tell(p, "Nur der Gruppenleiter startet die Prüfung.");
          return;
        }
        if (living(r).stream()
            .anyMatch(m -> !inRoom(r, here, m.getLocation(), 0) && !inRoom(r, room(r), m.getLocation(), 0))) {
          plugin.tell(p, "Alle müssen zuerst in diesen Raum oder die Prüfungskammer kommen.");
          return;
        }
        startChallenge(r, action.equals("curse"), here);
      }
    }
  }

  private void enterNextRoom(Run r) {
    DungeonPlan.Room from = room(r);
    if (from.out != null) gate(r, from, from.out, false);
    if (from.sideRoom >= 0 && r.branchOpen[r.room]) sideGate(r, false);
    r.room++;
    DungeonPlan.Room room = room(r);
    gate(r, room, room.in, false);
    for (UUID id : r.down) {
      Player p = Bukkit.getPlayer(id);
      if (p != null) p.teleport(checkpoint(r, true));
    }
    say(r, roomName(r, room) + " erreicht. Bereitet euch vor!");
    startRoom(r);
  }

  /** A room begins with its waves, then its puzzle, then the gate opens. */
  private void startRoom(Run r) {
    r.roomWave = 0;
    DungeonPlan.Room room = room(r);
    if (room.waves > 0) countdown(r);
    else if (room.puzzle != null) startPuzzle(r);
    else travel(r);
  }

  private void countdown(Run r) {
    r.stage = Stage.COUNTDOWN;
    r.deadline = tick + 100;
  }

  private void beginWave(Run r) {
    r.wave++;
    r.stage = Stage.WAVE;
    r.spawned = 0;
    r.reinforcements = 0;
    r.pending = DungeonRules.count(r.wave, r.size, r.level);
    refill(r);
    say(
        r,
        r.wave == r.totalWaves
            ? "ENDWELLE · "
                + r.variant.boss(r.zone)
                + " erwacht! Drei Phasen – weiche seinen Angriffen aus und schlag bei"
                + " SCHWACHSTELLE zu."
            : "Welle "
                + r.wave
                + "/"
                + r.totalWaves
                + " · "
                + DungeonRules.conditionName(r.level)
                + (r.level >= 4 ? " · Jäger lauern auf euch!" : ""));
  }

  private void refill(Run r) {
    DungeonPlan.Room room = room(r);
    double rx = Math.min(11, room.hw - 5), rz = Math.min(10, room.hd - 5);
    while (r.pending > 0 && r.mobs.size() < DungeonRules.activeLimit(r.size)) {
      int ordinal = r.spawned;
      double angle = (ordinal * 2.4 + r.wave) % (Math.PI * 2);
      int kind = DungeonRules.kind(r.level, r.wave, ordinal, r.id.getLeastSignificantBits());
      double x = Math.cos(angle) * rx, z = Math.sin(angle) * rz;
      // Bridge rooms: only on the cross of bridges, never above the pit.
      if (room.shape == DungeonPlan.Shape.BRIDGE) {
        if (Math.abs(x) > Math.abs(z)) z = 0;
        else x = 0;
      }
      spawn(r, r.wave == r.totalWaves && ordinal == 0, kind, x, z);
      r.pending--;
      r.spawned++;
    }
  }

  private void spawn(Run r, boolean boss, int kind, double x, double z) {
    spawnAt(r, boss, kind, at(r, x, 0, z), r.room);
  }

  private void spawnAt(Run r, boolean boss, int kind, Location where, int roomIndex) {
    Enemy e = new Enemy();
    e.run = r;
    e.room = roomIndex;
    e.boss = boss;
    e.kind = kind;
    e.elite = !boss && DungeonRules.elite(r.level, r.spawned);
    e.hp =
        e.max =
            DungeonRules.health(r.zone, r.mode, r.size, r.wave, boss, r.level)
                * (e.elite ? 1.6 : 1);
    e.attackAt = tick + 50 + random.nextInt(40);
    e.mob =
        plugin
            .mines()
            .world()
            .spawn(
                where,
                Husk.class,
                false,
                mob -> {
                  mob.setAdult();
                  mob.getEquipment().clear();
                  mob.setPersistent(false);
                  mob.setSilent(true);
                  mob.setInvisible(true);
                  mob.setShouldBurnInDay(false);
                  mob.setRemoveWhenFarAway(false);
                  mob.setCanPickupItems(false);
                  mob.getAttribute(Attribute.MOVEMENT_SPEED)
                      .setBaseValue(
                          (boss ? .24 : kind == 3 ? .34 : .28)
                              * (DungeonRules.condition(r.level) == 1 ? 1.1 : 1));
                  mob.getAttribute(Attribute.SCALE).setBaseValue(boss ? 1.55 : kind == 1 ? 1 : .8);
                  mob.getAttribute(Attribute.KNOCKBACK_RESISTANCE).setBaseValue(0);
                  mob.customName(
                      Component.text(enemyName(e) + " · L" + r.level, NamedTextColor.RED));
                  mob.setCustomNameVisible(false);
                });
    r.mobs.add(e);
    enemies.put(e.mob.getUniqueId(), e);
    RailNavigation.allowRails(e.mob);
    e.rig = new MonsterRig(plugin, e.mob.getLocation(), (r.zone + kind) % 7, boss, kind);
    e.health = new MonsterHealthIndicator(plugin, e.mob.getLocation(), r.members, boss);
    health(e);
  }

  private void health(Enemy e) {
    if (e.health != null)
      e.health.update(
          e.mob.getLocation(),
          e.rig.labelHeight(),
          enemyName(e) + " · L" + e.run.level,
          e.hp,
          e.max,
          e.boss);
  }

  private String enemyName(Enemy e) {
    return (e.elite ? "ELITE · " : "")
        + (e.boss
            ? e.run.variant.boss(e.run.zone)
            : switch (e.kind) {
              case 0 -> "Sprenger";
              case 1 -> "Strahlenwirker";
              case 2 -> "Heilrufer";
              default -> "Rissjäger";
            });
  }

  private void enemyTick(Enemy e) {
    Run r = e.run;
    health(e);
    if (!e.mob.isValid()) throw new IllegalStateException("Dungeon enemy disappeared");
    List<Player> targets = living(r);
    if (targets.isEmpty()) return;
    Player target =
        targets.stream()
            .min(
                Comparator.comparingDouble(
                    p -> p.getLocation().distanceSquared(e.mob.getLocation())))
            .orElseThrow();
    if (e.boss && r.level >= 6) {
      int phase = e.hp < e.max * .33 ? 2 : e.hp < e.max * .66 ? 1 : 0;
      if (phase > r.reinforcements) {
        r.pending += (phase - r.reinforcements) * (1 + r.size);
        r.reinforcements = phase;
        say(r, "Der Wächter ruft Verstärkung! Noch " + r.pending + " Gegner im Anmarsch.");
      }
    }
    if (e.elite && tick % 10 == 0)
      e.mob
          .getWorld()
          .spawnParticle(Particle.ENCHANT, e.mob.getLocation().add(0, 1.5, 0), 5, .4, .6, .4, 0);
    if (!inside(r, e.mob.getLocation())) e.mob.teleport(in(r, r.plan.rooms.get(e.room), 0, 0, 0));
    e.mob.setTarget(target);
    if (e.boss && (e.brain == null || !e.brain.busy()) && rearCounter(e, targets)) return;
    if (e.boss) {
      if (e.brain == null) {
        e.brain = new BossBrain(arena(r), e.mob, tick);
        r.bossFought = true;
        say(
            r,
            "ENDBOSS: "
                + e.brain.name()
                + "! Achte auf die Warnungen – seinen Angriffen musst du ausweichen (Sneak +"
                + " Rechtsklick = Rolle).");
      }
      e.brain.tick(tick, e.hp, e.max);
      r.bossStruck.addAll(e.brain.struck);
      e.mob.setAware(!e.brain.busy() && tick >= e.recoilAt);
      e.rig.animate(
          e.mob.getLocation(),
          tick,
          e.brain.busy(),
          tick < e.recoilAt,
          e.mob.getVelocity().lengthSquared() > .001);
      if (tick % 30 == 0 && target.getLocation().distanceSquared(e.mob.getLocation()) < 3.5)
        hurt(r, target, DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * .7);
      return;
    }
    e.mob.setAware(e.resolveAt == 0 && tick >= e.recoilAt);
    e.rig.animate(
        e.mob.getLocation(),
        tick,
        e.resolveAt > 0,
        tick < e.recoilAt,
        e.mob.getVelocity().lengthSquared() > .001);
    if (e.resolveAt > 0) {
      if (e.spell == 0) circle(e.marker, e.boss ? 4 : 2.7, Color.RED);
      else if (e.spell == 1 || e.spell == 3) beam(e.marker, e.direction, e.spell == 3 ? 7 : 18);
      else circle(e.marker, 5, Color.LIME);
      if (e.secondary != null) circle(e.secondary, 2.7, Color.RED);
      if (tick >= e.resolveAt) {
        for (Player p : targets) {
          Vector d = p.getLocation().toVector().subtract(e.marker.toVector());
          boolean hit =
              e.spell == 0
                  ? d.clone().setY(0).lengthSquared() <= (e.boss ? 16 : 7.29)
                  : (e.spell == 1 || e.spell == 3)
                      && d.dot(e.direction) >= 0
                      && d.dot(e.direction) < (e.spell == 3 ? 7 : 18)
                      && Math.abs(d.getX() * e.direction.getZ() - d.getZ() * e.direction.getX())
                          < 1.2;
          if ((e.spell == 1 || e.spell == 3) && !p.hasLineOfSight(e.mob)) hit = false;
          if (e.secondary != null
              && p.getLocation().toVector().subtract(e.secondary.toVector()).setY(0).lengthSquared()
                  <= 7.29) hit = true;
          if (hit)
            hurt(
                r,
                p,
                DungeonRules.damage(r.zone, r.mode, e.boss, r.level, r.size)
                    * (e.elite ? 1.25 : 1));
        }
        if (e.spell == 3) KnockbackMotion.push(e.mob, e.direction.clone().multiply(4));
        if (e.spell == 2)
          for (Enemy ally : r.mobs)
            if (ally != e && ally.mob.getLocation().distanceSquared(e.marker) < 25) {
              ally.hp = Math.min(ally.max, ally.hp + ally.max * .12);
              health(ally);
            }
        e.resolveAt = 0;
        e.secondary = null;
        e.attackAt = tick + DungeonRules.recovery(r.level, e.boss && e.hp < e.max * .5);
      }
    } else if (tick >= e.attackAt) {
      e.spell = e.boss ? (e.spell + 1) % 3 : e.kind;
      e.marker = e.spell == 0 ? target.getLocation().clone() : e.mob.getLocation().clone();
      e.direction = target.getLocation().toVector().subtract(e.marker.toVector()).setY(0);
      if (e.direction.lengthSquared() < .001) e.direction = new Vector(0, 0, 1);
      else e.direction.normalize();
      if (e.boss && e.spell == 0 && DungeonRules.condition(r.level) == 3) {
        e.secondary =
            targets.size() > 1
                ? targets.get((targets.indexOf(target) + 1) % targets.size()).getLocation().clone()
                : target.getLocation().clone().add(target.getX() > r.x ? -4 : 4, 0, 0);
      }
      e.resolveAt = tick + DungeonRules.warning(r.level, e.boss && e.hp < e.max * .5);
      Vector aim = target.getLocation().toVector().subtract(e.mob.getLocation().toVector()).setY(0);
      if (aim.lengthSquared() > .001)
        e.mob.setRotation(e.mob.getLocation().setDirection(aim).getYaw(), 0);
      e.mob
          .getWorld()
          .playSound(
              e.mob.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, .5f, e.spell == 2 ? 1.5f : .6f);
    }
    // Contact pressure is independently rate limited by CombatEngine's hurt protection.
    if (tick % 30 == 0 && target.getLocation().distanceSquared(e.mob.getLocation()) < 3.5)
      hurt(
          r,
          target,
          DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * .7 * (e.elite ? 1.25 : 1));
  }

  private BossBrain.Arena arena(Run r) {
    return new BossBrain.Arena() {
      public List<Player> living() {
        return Dungeons.this.living(r);
      }

      public void hurt(Player p, double damage) {
        Dungeons.this.hurt(r, p, damage);
      }

      public void say(String text) {
        Dungeons.this.say(r, text);
      }

      public Location center() {
        return at(r, 0, 0, 0);
      }

      public double baseDamage() {
        return DungeonRules.damage(r.zone, r.mode, true, r.level, r.size);
      }

      public int zone() {
        return r.zone;
      }

      public int variant() {
        return r.variant.ordinal();
      }

      public int level() {
        return r.level;
      }

      public long seed() {
        return r.id.getMostSignificantBits();
      }

      public void danger(Player p, BossPatterns.Attack attack) {
        plugin.drones().danger(p, attack.title);
      }
    };
  }

  /** Admin test: skip straight to the final wave with the boss. */
  public String debugBoss(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || r.stage == Stage.BUILDING || r.stage == Stage.COMPLETE)
      return "Zuerst einen Dungeon starten (/df dungeon start).";
    for (Enemy e : new ArrayList<>(r.mobs)) removeEnemy(e);
    r.pending = 0;
    r.room = r.plan.mainRooms - 1;
    DungeonPlan.Room boss = room(r);
    r.roomWave = boss.waves - 1;
    r.wave = r.totalWaves - 1;
    for (Player m : online(r)) m.teleport(checkpoint(r, false));
    beginWave(r);
    return "Testmodus: Endboss gestartet.";
  }

  /** Admin test: finish the current room, or walk the group into the next one. */
  public String debugSkip(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || r.stage == Stage.BUILDING || r.stage == Stage.COMPLETE)
      return "Zuerst einen Dungeon starten (/df dungeon start).";
    if (r.stage == Stage.TRAVEL) {
      if (r.room + 1 >= r.plan.mainRooms) return "Das ist der letzte Raum.";
      DungeonPlan.Room next = r.plan.rooms.get(r.room + 1);
      for (Player m : living(r)) m.teleport(in(r, next, 0, 0, 0));
      return "Testmodus: in den nächsten Raum gebracht.";
    }
    for (Enemy e : new ArrayList<>(r.mobs)) removeEnemy(e);
    r.pending = 0;
    DungeonPlan.Room room = room(r);
    if (r.stage == Stage.WAVE || r.stage == Stage.COUNTDOWN) {
      r.wave += room.waves - r.roomWave - (r.stage == Stage.WAVE ? 1 : 0);
      r.roomWave = room.waves;
      if (r.wave >= r.totalWaves) {
        finish(r, true, r.variant.title + " bezwungen! (Testmodus)");
        return "Testmodus: Dungeon beendet.";
      }
      if (room.puzzle != null) {
        startPuzzle(r);
        return "Testmodus: Wellen übersprungen, Rätsel " + room.puzzle.title + " läuft.";
      }
    }
    travel(r);
    return "Testmodus: Raum " + (r.room + 1) + " erledigt (" + roomName(r, room) + ").";
  }

  /** Admin test: a summary of the generated layout. */
  public String debugPlan(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || r.plan == null) return "Kein Dungeon.";
    StringBuilder sb = new StringBuilder("Raum " + (r.room + 1) + "/" + r.plan.mainRooms + " · " + r.stage + ": ");
    for (DungeonPlan.Room room : r.plan.rooms)
      sb.append(room.index + 1)
          .append(' ')
          .append(roomName(r, room))
          .append(room.puzzle != null ? " [" + room.puzzle.title + "]" : "")
          .append(room.waves > 0 ? " " + room.waves + "W" : "")
          .append(" · ");
    if (r.room + 1 < r.plan.mainRooms) {
      Location next = in(r, r.plan.rooms.get(r.room + 1), 0, 0, 0);
      sb.append("NEXT@").append(next.getBlockX()).append(',').append(next.getBlockY()).append(',').append(next.getBlockZ());
    }
    return sb.toString();
  }

  /** Drone turret: hits the nearest enemy of the owner's run; returns where it hit. */
  public Location droneShot(Player p, double damage) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || down(p)) return null;
    Enemy best = null;
    double bestDistance = 144;
    for (Enemy e : r.mobs) {
      if (e.hp <= 0 || !e.mob.isValid()) continue;
      double d = e.mob.getLocation().distanceSquared(p.getLocation());
      if (d < bestDistance) {
        bestDistance = d;
        best = e;
      }
    }
    if (best == null) return null;
    Location at = best.mob.getLocation().add(0, best.boss ? 1.8 : 1, 0);
    strike(best, p, damage, false);
    return at;
  }

  private boolean rearCounter(Enemy e, List<Player> targets) {
    BossPressure.Step step = e.pressure.step(tick, e.resolveAt == 0);
    if (step == BossPressure.Step.NONE) return false;
    e.mob.setAware(false);
    e.mob.setVelocity(new Vector());
    e.attackAt = Math.max(e.attackAt, tick + 20);
    if (step == BossPressure.Step.START) {
      e.sweepOrigin = e.mob.getLocation().clone();
      say(e.run, "RUNDUMSCHLAG! Raus aus dem roten Kreis – auch hinter dem Wächter!");
      e.mob.getWorld().playSound(e.sweepOrigin, Sound.BLOCK_NOTE_BLOCK_BASS, 1, .5f);
    }
    circle(e.sweepOrigin, BossPressure.RADIUS, Color.RED);
    e.rig.animate(e.mob.getLocation(), tick, true, false, false);
    if (step == BossPressure.Step.STRIKE) {
      for (Player p : targets) {
        Vector d = p.getLocation().toVector().subtract(e.sweepOrigin.toVector());
        if (BossPressure.inSweep(d.getX(), d.getY(), d.getZ()) && e.mob.hasLineOfSight(p))
          hurt(
              e.run,
              p,
              DungeonRules.damage(e.run.zone, e.run.mode, true, e.run.level, e.run.size) * 1.35);
      }
      e.mob
          .getWorld()
          .spawnParticle(
              Particle.SWEEP_ATTACK, e.sweepOrigin.clone().add(0, 1, 0), 14, 2, .4, 2, 0);
      e.mob.getWorld().playSound(e.sweepOrigin, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1, .6f);
      e.sweepOrigin = null;
    }
    return true;
  }

  /** The dungeon's own hazard: Glutschmiede eruptions or Frostkrypta cold. */
  private void hazard(Run r) {
    switch (r.variant) {
      case GLUTSCHMIEDE -> embers(r);
      case FROSTKRYPTA -> cold(r);
      default -> {}
    }
  }

  /** Glowing floor spots under every player (plus a few random ones) that erupt shortly after. */
  private void embers(Run r) {
    if (r.stage != Stage.WAVE) {
      r.eruptSpots.clear();
      r.eruptNext = 0;
      return;
    }
    if (r.eruptNext == 0) r.eruptNext = tick + 100;
    if (r.eruptSpots.isEmpty()) {
      if (tick < r.eruptNext) return;
      List<Player> targets = living(r);
      if (targets.isEmpty()) return;
      for (Player p : targets) {
        Location l = p.getLocation().clone();
        l.setY(65);
        r.eruptSpots.add(l);
      }
      int extra = DungeonVariant.eruptions(targets.size(), r.mode) - targets.size();
      for (int i = 0; i < extra; i++)
        r.eruptSpots.add(
            at(
                r,
                (random.nextDouble() * 2 - 1) * (room(r).hw - 3),
                0,
                (random.nextDouble() * 2 - 1) * (room(r).hd - 3)));
      r.eruptLand = tick + DungeonVariant.ERUPT_WARNING;
      // During the boss fight the floor erupts half as often, next to the boss attacks.
      boolean boss = r.mobs.stream().anyMatch(e -> e.boss);
      r.eruptNext = tick + DungeonVariant.eruptionInterval(r.mode, r.level) * (boss ? 2L : 1L);
      for (Player p : targets) p.playSound(p.getLocation(), Sound.BLOCK_LAVA_POP, 1, .7f);
      return;
    }
    if (tick < r.eruptLand) {
      if (tick % 4 == 0)
        for (Location l : r.eruptSpots) {
          circle(l, DungeonVariant.ERUPT_RADIUS, Color.ORANGE);
          circle(l, DungeonVariant.ERUPT_RADIUS * .5, Color.RED);
          l.getWorld().spawnParticle(Particle.LAVA, l, 1, .8, 0, .8, 0);
        }
      return;
    }
    double damage = DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * 1.3;
    for (Location l : r.eruptSpots) {
      l.getWorld().spawnParticle(Particle.FLAME, l.clone().add(0, .5, 0), 30, .9, .8, .9, .04);
      l.getWorld().spawnParticle(Particle.LAVA, l, 8, .8, .2, .8, 0);
      l.getWorld().playSound(l, Sound.ENTITY_BLAZE_SHOOT, .8f, .6f);
    }
    for (Player p : living(r)) {
      Location at = p.getLocation();
      for (Location l : r.eruptSpots)
        if (DungeonVariant.inEruption(at.getX() - l.getX(), at.getZ() - l.getZ())) {
          hurt(r, p, damage);
          p.setFireTicks(30);
          break;
        }
    }
    r.eruptSpots.clear();
  }

  /** Frost stacks while fighting; the braziers in every hall warm you up again. */
  private void cold(Run r) {
    if (tick < r.frostNext) return;
    r.frostNext = tick + DungeonVariant.frostInterval(r.mode);
    boolean fighting = r.stage == Stage.WAVE || r.stage == Stage.SIDE;
    double reach = DungeonVariant.BRAZIER_RADIUS * DungeonVariant.BRAZIER_RADIUS;
    for (Player p : online(r)) {
      UUID id = p.getUniqueId();
      int before = r.frost.getOrDefault(id, 0);
      boolean warm =
          r.braziers.stream()
              .anyMatch(
                  b -> b.getWorld().equals(p.getWorld()) && b.distanceSquared(p.getLocation()) <= reach);
      int now =
          fighting && !r.down.contains(id)
              ? DungeonVariant.frost(before, warm)
              : Math.max(0, before - 2);
      if (DungeonVariant.frozen(now)) {
        hurt(r, p, DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * 1.5);
        p.getWorld()
            .spawnParticle(Particle.SNOWFLAKE, p.getLocation().add(0, 1, 0), 30, .4, .6, .4, .02);
        p.playSound(p.getLocation(), Sound.BLOCK_GLASS_BREAK, 1, .6f);
        frostTitle(p, "❄ Eingefroren! Ab zu einem Glutbecken!");
        now = DungeonVariant.FROST_AFTER_FREEZE;
      } else if (now >= DungeonVariant.FROST_SLOW && before < DungeonVariant.FROST_SLOW)
        frostTitle(p, "❄ Dir wird kalt – wärm dich am Glutbecken auf");
      if (warm && now < before)
        p.getWorld().spawnParticle(Particle.FLAME, p.getLocation().add(0, .2, 0), 4, .3, .1, .3, 0);
      r.frost.put(id, now);
      p.lockFreezeTicks(true);
      // Vanilla freeze damage starts at 140 ticks; 13 per stack keeps it purely visual.
      p.setFreezeTicks(now * 13);
      if (now >= DungeonVariant.FROST_SLOW)
        p.addPotionEffect(
            new org.bukkit.potion.PotionEffect(
                org.bukkit.potion.PotionEffectType.SLOWNESS,
                DungeonVariant.frostInterval(r.mode) + 10,
                0,
                false,
                false,
                true));
    }
  }

  private void frostTitle(Player p, String text) {
    p.showTitle(
        net.kyori.adventure.title.Title.title(
            Component.empty(),
            Component.text(text, NamedTextColor.AQUA),
            net.kyori.adventure.title.Title.Times.times(
                java.time.Duration.ZERO,
                java.time.Duration.ofMillis(1500),
                java.time.Duration.ofMillis(400))));
  }

  private static void thaw(Player p) {
    p.lockFreezeTicks(false);
    p.setFreezeTicks(0);
  }

  private void circle(Location l, double radius, Color color) {
    for (int i = 0; i < 18; i++) {
      double a = i * Math.PI / 9;
      l.getWorld()
          .spawnParticle(
              Particle.DUST,
              l.clone().add(Math.cos(a) * radius, .15, Math.sin(a) * radius),
              1,
              0,
              0,
              0,
              0,
              new Particle.DustOptions(color, 1.2f));
    }
  }

  private void beam(Location l, Vector direction) {
    beam(l, direction, 18);
  }

  private void beam(Location l, Vector direction, int length) {
    for (int i = 0; i < length; i++)
      l.getWorld()
          .spawnParticle(
              Particle.DUST,
              l.clone().add(direction.clone().multiply(i)).add(0, .3, 0),
              1,
              .12,
              0,
              .12,
              0,
              new Particle.DustOptions(Color.ORANGE, 1.5f));
  }

  private void hurt(Run r, Player p, double amount) {
    if (r.down.contains(p.getUniqueId())) return;
    plugin
        .combat()
        .dungeonDamage(
            p,
            amount * r.blessings.incoming(p.getUniqueId()),
            () -> {
              r.down.add(p.getUniqueId());
              p.setHealth(Math.min(Gear.stats(plugin.profile(p)).health(), 4));
              p.teleport(checkpoint(r, true));
              say(r, p.getName() + " wurde besiegt. Überlebt die Phase für seine Rückkehr!");
            });
  }

  private void revive(Run r) {
    for (Player p : online(r)) {
      if (!plugin.playing(p) || p.isDead()) continue;
      plugin.combat().applyStats(p);
      boolean revived = r.down.remove(p.getUniqueId());
      double max = Gear.stats(plugin.profile(p)).health();
      p.setHealth(revived ? max * .5 : Math.min(max, p.getHealth() + max * .15));
      if (revived) p.teleport(checkpoint(r, false));
    }
    r.down.clear();
  }

  @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
  public void hit(EntityDamageByEntityEvent event) {
    Enemy source = enemies.get(event.getDamager().getUniqueId());
    if (source != null) {
      event.setCancelled(true);
      return;
    }
    Enemy e = enemies.get(event.getEntity().getUniqueId());
    if (e == null) return;
    event.setCancelled(true);
    if (!(event.getDamager() instanceof Player p)
        || membership.get(p.getUniqueId()) != e.run
        || down(p)
        || !plugin.items().kind(p.getInventory().getItemInMainHand()).equals("sword")
        || !p.hasLineOfSight(e.mob)
        || p.getLocation().distanceSquared(e.mob.getLocation()) > 25) return;
    long now = Bukkit.getCurrentTick();
    if (clicks.getOrDefault(p.getUniqueId(), -1L) == now) return;
    clicks.put(p.getUniqueId(), now);
    strike(e, p, RapidCombat.damage(Gear.stats(plugin.profile(p))));
  }

  private void strike(Enemy e, Player p, double damage) {
    strike(e, p, damage, true);
  }

  private void strike(Enemy e, Player p, double damage, boolean procAllowed) {
    if (e.hp <= 0) return;
    if (e.brain != null && e.brain.immune(tick)) {
      plugin.combat().showDamage(p, e.mob.getLocation().add(0, 3.4, 0), 0, false, false, true);
      p.playSound(p.getLocation(), Sound.ITEM_SHIELD_BLOCK, .6f, 1.4f);
      return;
    }
    if (e.brain != null) damage *= e.brain.damageTaken(tick);
    ArtifactCombat.Proc proc =
        procAllowed
            ? plugin.adventure().hit(p, e.mob.getUniqueId())
            : new ArtifactCombat.Proc(false, false);
    if (plugin.adventure().fractured(e.mob.getUniqueId())) damage *= 1.15;
    damage *= e.run.blessings.damage(p.getUniqueId());
    Gear.Stats stats = Gear.stats(plugin.profile(p));
    Gear.Item weapon = Gear.equipped(plugin.profile(p), Gear.Slot.WEAPON);
    String style = weapon == null ? "sword" : weapon.style;
    Vector delta = p.getLocation().toVector().subtract(e.mob.getLocation().toVector());
    Vector facing = e.mob.getLocation().getDirection();
    double alignment = WeaponRules.facing(delta.getX(), delta.getZ(), facing.getX(), facing.getZ());
    if (e.boss) e.pressure.hit(tick, alignment, delta.clone().setY(0).lengthSquared());
    boolean backstab = style.equals("dagger") && alignment <= -.5;
    damage *= WeaponRules.multiplier(style, WeaponRules.rearBonus(weapon), false, false, alignment);
    if (procAllowed) damage *= plugin.combat().comboHit(p);
    boolean crit = random.nextDouble() < stats.crit();
    if (crit) damage *= stats.critDamage();
    double dealt = Math.min(e.hp, damage);
    e.hp -= dealt;
    health(e);
    e.rig.hurt(tick);
    plugin
        .combat()
        .showDamage(
            p, e.mob.getLocation().add(0, e.boss ? 3.4 : 2, 0), dealt, crit, backstab, false);
    p.playSound(
        p.getLocation(),
        crit ? Sound.ENTITY_PLAYER_ATTACK_CRIT : Sound.ENTITY_PLAYER_ATTACK_STRONG,
        .65f,
        1.2f);
    if (tick >= e.recoilAt + 8 && e.sweepOrigin == null) {
      Vector away = e.mob.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
      if (away.lengthSquared() > .01)
        e.mob.setVelocity(
            away.normalize().multiply(HitFeedback.knockback(style, e.boss, false)).setY(.18));
      e.recoilAt = tick + (e.boss ? 2 : 5);
    }
    if (proc.lightning()) {
      Location origin = e.mob.getLocation().add(0, 1, 0);
      for (Enemy other :
          e.run.mobs.stream()
              .filter(
                  v ->
                      v != e
                          && v.hp > 0
                          && v.mob.getLocation().distanceSquared(origin) < 36
                          && e.mob.hasLineOfSight(v.mob))
              .limit(3)
              .toList()) {
        plugin.adventure().arc(p, origin, other.mob.getLocation().add(0, 1, 0));
        strike(other, p, plugin.adventure().arcDamage(p), false);
      }
    }
    if (proc.fracture())
      plugin.tell(p, "Runenhammer: Ziel 4 Sekunden lang verwundbar (+15% Schaden)!");
    if (e.hp <= 0) {
      plugin.passXp(p, e.boss ? DeepPass.XP_BOSS : DeepPass.XP_KILL);
      plugin.adventure().kill(p, e.mob.getLocation());
      if (!e.boss && random.nextDouble() < (e.elite ? .4 : .12)) {
        living(e.run).stream()
            .filter(
                member ->
                    e.run.healingDrops.getOrDefault(member.getUniqueId(), 0) < 3
                        && plugin.profile(member).healingCharges < Healing.CAPACITY)
            .min(Comparator.comparingInt(member -> plugin.profile(member).healingCharges))
            .ifPresent(
                member -> {
                  e.run.healingDrops.merge(member.getUniqueId(), 1, Integer::sum);
                  plugin.healing().found(member, 1);
                });
      }
      removeEnemy(e);
    }
  }

  public void ability(Player p, String style, Vector facing) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || down(p)) return;
    for (Enemy e : new ArrayList<>(r.mobs)) {
      Vector d = e.mob.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
      double length = d.length();
      boolean hit =
          style.equals("crossbow")
              ? length < 13 && (length < .1 || d.clone().normalize().dot(facing) > .96)
              : style.equals("spear")
                  ? length < 8 && (length < .1 || d.clone().normalize().dot(facing) > .8)
                  : length < 4;
      double bonus =
          style.equals("hammer") && Gear.hasEffect(plugin.profile(p), 4)
              ? 1.35
              : style.equals("spear") && Gear.hasEffect(plugin.profile(p), 3) ? 1.4 : 1;
      if (hit && p.hasLineOfSight(e.mob))
        strike(
            e,
            p,
            Gear.stats(plugin.profile(p)).damage() * (style.equals("hammer") ? 2.1 : 1.5) * bonus);
    }
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void damage(EntityDamageEvent e) {
    if (enemies.containsKey(e.getEntity().getUniqueId())) e.setCancelled(true);
    if (e.getEntity() instanceof Player p && active(p)) e.setCancelled(true);
  }

  @EventHandler
  public void targeting(EntityTargetLivingEntityEvent e) {
    Enemy enemy = enemies.get(e.getEntity().getUniqueId());
    if (enemy != null
        && e.getTarget() != null
        && (!(e.getTarget() instanceof Player p)
            || membership.get(p.getUniqueId()) != enemy.run
            || down(p))) e.setCancelled(true);
  }

  @EventHandler
  public void died(PlayerDeathEvent e) {
    Run r = membership.get(e.getEntity().getUniqueId());
    if (r == null) return;
    r.down.add(e.getEntity().getUniqueId());
    e.setKeepInventory(true);
    e.getDrops().clear();
    e.setKeepLevel(true);
    e.setDroppedExp(0);
  }

  public Location respawnLocation(Player p) {
    Run r = membership.get(p.getUniqueId());
    return r == null ? null : checkpoint(r, r.down.contains(p.getUniqueId()));
  }



  @EventHandler(priority = EventPriority.LOW)
  public void shrine(PlayerInteractEvent e) {
    Player p = e.getPlayer();
    Run r = membership.get(p.getUniqueId());
    if (r == null
        || r.shrines.isEmpty()
        || e.getHand() != EquipmentSlot.HAND
        || !e.getAction().isRightClick()
        || e.getClickedBlock() == null) return;
    int i = r.shrines.indexOf(e.getClickedBlock());
    if (i < 0) return;
    e.setCancelled(true);
    if (p.getLocation().distanceSquared(e.getClickedBlock().getLocation()) > 36) return;
    bless(r, p, i);
  }

  @EventHandler(priority = EventPriority.LOW)
  public void puzzle(PlayerInteractEvent e) {
    Player p = e.getPlayer();
    Run r = membership.get(p.getUniqueId());
    if (r == null
        || r.stage != Stage.PUZZLE
        || e.getClickedBlock() == null
        || down(p)
        || e.getHand() != EquipmentSlot.HAND) return;
    String action = r.clickables.get(e.getClickedBlock());
    if (action == null || !action.contains(":")) return;
    e.setCancelled(true);
    if (p.getLocation().distanceSquared(e.getClickedBlock().getLocation()) > 42) return;
    puzzleClick(r, p, e.getClickedBlock(), action);
  }

  @EventHandler
  public void move(PlayerMoveEvent e) {
    if (e instanceof PlayerTeleportEvent || !down(e.getPlayer()) || e.getTo() == null) return;
    Location from = e.getFrom(), to = e.getTo();
    if (from.distanceSquared(to) > .0001) {
      Location lock = from.clone();
      lock.setYaw(to.getYaw());
      lock.setPitch(to.getPitch());
      e.setTo(lock);
    }
  }

  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  public void teleport(PlayerTeleportEvent e) {
    if (e.getTo() == null) return;
    Run own = membership.get(e.getPlayer().getUniqueId());
    if (own != null
        && own.plan != null
        && own.stage != Stage.BUILDING
        && inside(own, e.getTo())
        && !allowed(own, e.getTo())) {
      e.setCancelled(true);
      return;
    }
    for (Run r : runs.values())
      if (inside(r, e.getTo())
          && membership.get(e.getPlayer().getUniqueId()) != r
          && !r.watchers.contains(e.getPlayer().getUniqueId())) {
        e.setCancelled(true);
        return;
      }
  }

  // ---- Puzzles ----

  private static final int[][] MIMIC_SPOTS = {{-8, -7}, {8, -7}, {-8, 5}, {8, 5}, {0, -9}};
  private static final Material LAMP_ON = Material.SEA_LANTERN, LAMP_OFF = Material.COAL_BLOCK;

  private Random puzzleRandom(Run r, DungeonPlan.Room room) {
    return new Random(r.id.getLeastSignificantBits() ^ room.index * 0x9E3779B97F4A7C15L);
  }

  private void clickable(Run r, Location at, String action) {
    r.clickables.put(at.getBlock(), action);
  }

  /** Static puzzle parts are placed while the dungeon is built; state lives in the run. */
  private void setupPuzzle(Run r, DungeonPlan.Room room) {
    Random rnd = puzzleRandom(r, room);
    switch (room.puzzle) {
      case RUNES -> {
        for (int i = 0; i < 4; i++) {
          in(r, room, -9 + i * 6, 0, -6).getBlock().setType(RUNES[i], false);
          in(r, room, -9 + i * 6, -1, -6).getBlock().setType(Material.SEA_LANTERN, false);
          clickable(r, in(r, room, -9 + i * 6, 0, -6), "rune:" + i);
        }
        r.puzzleStates.put(room.index, DungeonRules.sequence(r.id, room.index));
        label(r, room, 0, 2.5, -6, "RUNENWAND\nFarben merken, dann in Reihenfolge anklicken", NamedTextColor.AQUA);
      }
      case SEALS -> {
        for (int i = 0; i < 3; i++)
          in(r, room, -6 + i * 6, -1, 3).getBlock().setType(Material.WAXED_OXIDIZED_CUT_COPPER, false);
        label(r, room, 0, 2.5, 3, "GRUPPENSIEGEL\nAlle Platten gleichzeitig besetzen", NamedTextColor.AQUA);
      }
      case LEVERS -> {
        DungeonPuzzles.Levers levers = new DungeonPuzzles.Levers(rnd);
        r.puzzleStates.put(room.index, levers);
        for (int i = 0; i < DungeonPuzzles.Levers.COUNT; i++) {
          Location lever = in(r, room, -8 + i * 4, 0, -5);
          lever
              .getBlock()
              .setBlockData(
                  Bukkit.createBlockData("minecraft:lever[face=floor,facing=north,powered=false]"),
                  false);
          clickable(r, lever, "lever:" + i);
          in(r, room, -8 + i * 4, 0, -8).getBlock().setType(Material.CHISELED_STONE_BRICKS, false);
        }
        drawLamps(r, room, levers);
        label(r, room, 0, 3, -8, "HEBELRÄTSEL\nJeder Hebel schaltet seine Lampe und die Nachbarn um.\nAlle Lampen an = offen", NamedTextColor.AQUA);
      }
      case PLATES -> {
        r.puzzleStates.put(room.index, new DungeonPuzzles.Plates(rnd, r.level));
        for (int k = 0; k < 9; k++)
          plate(r, room, k).getBlock().setType(Material.GRAY_CONCRETE, false);
        label(r, room, 0, 3, -8, "PLATTENLAUF\nImmer auf die leuchtende Platte – bevor die Zeit abläuft", NamedTextColor.AQUA);
      }
      case LIGHT -> {
        DungeonPuzzles.Light light = new DungeonPuzzles.Light(rnd);
        r.puzzleStates.put(room.index, light);
        in(r, room, -9, 0, lightZ(light.sourceZ)).getBlock().setType(Material.SEA_LANTERN, false);
        in(r, room, lightX(light.targetX), 0, lightZ(light.targetZ))
            .getBlock()
            .setType(Material.AMETHYST_BLOCK, false);
        label(r, room, -9, 1.8, lightZ(light.sourceZ), "Lichtquelle", NamedTextColor.YELLOW);
        label(r, room, lightX(light.targetX), 1.8, lightZ(light.targetZ), "Kristall", NamedTextColor.LIGHT_PURPLE);
        for (var mirror : light.mirrors.entrySet()) {
          int cell = mirror.getKey();
          Location base = in(r, room, lightX(cell % DungeonPuzzles.Light.N), 0, lightZ(cell / DungeonPuzzles.Light.N));
          base.getBlock().setType(Material.POLISHED_ANDESITE, false);
          clickable(r, base, "mirror:" + cell);
          ItemDisplay glass =
              plugin
                  .mines()
                  .world()
                  .spawn(
                      base.clone().add(0, 1.1, 0),
                      ItemDisplay.class,
                      d -> {
                        d.setItemStack(new ItemStack(Material.LIGHT_BLUE_STAINED_GLASS_PANE));
                        d.setPersistent(false);
                      });
          r.decorations.add(glass);
          r.mirrors.put(cell, glass);
          turnMirror(glass, mirror.getValue());
        }
        label(r, room, 0, 3.5, -10, "LICHTSTRAHL\nSockel anklicken dreht den Spiegel.\nLenke das Licht auf den Kristall", NamedTextColor.AQUA);
      }
      case TRAPS -> {
        int length = room.out.alongX() ? room.hw : room.hd;
        int stripes = DungeonPuzzles.Traps.stripes(length * 2);
        for (int k = 0; k < stripes; k++) {
          int a = trapStripe(room, k);
          for (int lateral = -3; lateral <= 3; lateral++)
            trapLocation(r, room, a, lateral, -1).getBlock().setType(Material.CHISELED_POLISHED_BLACKSTONE, false);
        }
        label(r, room, 0, 3, 0, "FALLENGANG\nDie Glutdüsen feuern im Takt – durch die Lücken zum anderen Ende!", NamedTextColor.AQUA);
      }
      case BELLS -> {
        r.puzzleStates.put(room.index, new DungeonPuzzles.Bells(rnd, r.level));
        for (int i = 0; i < 4; i++) {
          Location bell = in(r, room, -6 + i * 4, 0, -6);
          bell.getBlock()
              .setBlockData(Bukkit.createBlockData("minecraft:bell[attachment=floor,facing=south]"), false);
          clickable(r, bell, "bell:" + i);
        }
        label(r, room, 0, 2.5, -6, "GLOCKENMELODIE\nZuhören, dann die Glocken in derselben Reihenfolge anschlagen", NamedTextColor.AQUA);
      }
      case MIMICS -> {
        r.puzzleStates.put(room.index, new DungeonPuzzles.Mimics(rnd));
        for (int i = 0; i < DungeonPuzzles.Mimics.COUNT; i++) {
          Location chest = in(r, room, MIMIC_SPOTS[i][0], 0, MIMIC_SPOTS[i][1]);
          chest.getBlock().setBlockData(Bukkit.createBlockData("minecraft:chest[facing=south]"), false);
          clickable(r, chest, "chest:" + i);
        }
        label(r, room, 0, 3, -2, "FALSCHE TRUHEN\nNur eine hat den Schlüssel – die anderen beißen", NamedTextColor.AQUA);
      }
    }
  }

  private static int lightX(int cell) {
    return -6 + cell * 3;
  }

  private static int lightZ(int cell) {
    return -8 + cell * 3;
  }

  private static void turnMirror(ItemDisplay glass, boolean slash) {
    glass.setTransformation(
        new org.bukkit.util.Transformation(
            new org.joml.Vector3f(),
            new org.joml.Quaternionf().rotateY((float) (slash ? Math.PI / 4 : -Math.PI / 4)),
            new org.joml.Vector3f(1.4f, 1.4f, 1.4f),
            new org.joml.Quaternionf()));
  }

  private Location plate(Run r, DungeonPlan.Room room, int k) {
    return in(r, room, -4 + 4 * (k % 3), -1, -4 + 4 * (k / 3));
  }

  private void drawLamps(Run r, DungeonPlan.Room room, DungeonPuzzles.Levers levers) {
    for (int i = 0; i < DungeonPuzzles.Levers.COUNT; i++)
      in(r, room, -8 + i * 4, 1, -8).getBlock().setType(levers.lit[i] ? LAMP_ON : LAMP_OFF, false);
  }

  /** Position of trap stripe k along the gauntlet (distance from the centre toward the exit). */
  private static int trapStripe(DungeonPlan.Room room, int k) {
    int length = room.out.alongX() ? room.hw : room.hd;
    return -length + 5 + 4 * k;
  }

  private Location trapLocation(Run r, DungeonPlan.Room room, double along, double lateral, double y) {
    DungeonPlan.Dir d = room.out;
    double x = d.dx * along + (d.alongX() ? 0 : lateral), z = d.dz * along + (d.alongX() ? lateral : 0);
    return in(r, room, x, y, z);
  }

  private double along(Run r, DungeonPlan.Room room, Location l) {
    double x = l.getX() - r.x - room.cx - .5, z = l.getZ() + 512 - room.cz - .5;
    return x * room.out.dx + z * room.out.dz;
  }

  private void startPuzzle(Run r) {
    DungeonPlan.Room room = room(r);
    r.stage = Stage.PUZZLE;
    r.puzzleStarted = tick;
    r.memoryStep = 0;
    r.sealTicks = 0;
    switch (room.puzzle) {
      case RUNES -> {
        @SuppressWarnings("unchecked")
        List<Integer> sequence = (List<Integer>) r.puzzleStates.get(room.index);
        r.sequence = sequence;
        r.deadline = tick + 160;
        say(r, "Runenrätsel: Merkt euch die Farbfolge oben in der Leiste. Danach die Runen an der Wand in dieser Reihenfolge anklicken. /df dungeon hint zeigt sie nochmal.");
      }
      case SEALS -> say(r, "Siegelrätsel: Besetzt die türkisfarbenen Platten gleichzeitig für 3 Sekunden. Solo reicht die linke, zu zweit die linken zwei, ab drei alle.");
      case LEVERS -> say(r, "Hebelrätsel: Jeder Hebel schaltet seine Lampe und die beiden daneben um. Bringt alle fünf Lampen zum Leuchten!");
      case PLATES -> {
        r.plateDeadline = tick + 60 + ((DungeonPuzzles.Plates) r.puzzleStates.get(room.index)).window;
        showPlate(r, room);
        say(r, "Plattenlauf: Lauft immer auf die leuchtende Platte, bevor sie erlischt.");
      }
      case LIGHT -> say(r, "Lichtstrahl: Dreht die Spiegel (Sockel anklicken), bis das Licht den Kristall trifft.");
      case TRAPS -> say(r, "Fallengang: Die Glutdüsen feuern im Takt. Wartet auf die Lücke und erreicht alle das andere Ende!");
      case BELLS -> {
        replayPuzzle(r);
        say(r, "Glockenmelodie: Hört genau hin und spielt die Melodie danach auf den Glocken nach. /df dungeon hint spielt sie nochmal.");
      }
      case MIMICS -> say(r, "Falsche Truhen: Nur eine Truhe hat den Schlüssel. Die anderen sind Mimics und greifen an!");
    }
  }

  /** Shows the rune colours or plays the melody again. */
  private void replayPuzzle(Run r) {
    DungeonPlan.Room room = room(r);
    if (room.puzzle == DungeonPlan.Puzzle.RUNES) {
      r.deadline = tick + 100;
      r.memoryStep = 0;
      say(r, "Runenfolge wird erneut angezeigt. Danach bei der ersten Rune beginnen.");
    } else if (room.puzzle == DungeonPlan.Puzzle.BELLS) {
      DungeonPuzzles.Bells bells = (DungeonPuzzles.Bells) r.puzzleStates.get(room.index);
      bells.step = 0;
      r.puzzleStarted = tick + 20;
      r.deadline = r.puzzleStarted + bells.melody.length * 14L + 10;
    }
  }

  private void completePuzzle(Run r) {
    DungeonPlan.Room room = room(r);
    if (room.puzzle == DungeonPlan.Puzzle.RUNES)
      for (Player member : online(r)) {
        Profile data = plugin.profile(member);
        data.discovered.add("tutorial/runes");
        plugin.commit(member, data);
      }
    for (Player member : online(r)) {
      member.playSound(member.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, .6f, 1.2f);
      plugin.passXp(member, DeepPass.XP_PUZZLE);
      plugin.commit(member, plugin.profile(member));
    }
    say(r, room.puzzle.title + " gelöst!");
    travel(r);
  }

  private String puzzleLabel(Run r) {
    DungeonPlan.Room room = room(r);
    Object state = r.puzzleStates.get(room.index);
    return switch (room.puzzle) {
      case RUNES ->
          tick < r.deadline
              ? "Merken: " + String.join(" → ", r.sequence.stream().map(i -> NAMES[i]).toList())
              : "Runenwand: " + r.memoryStep + "/" + r.sequence.size() + " · Anklicken";
      case SEALS -> "Siegel: auf die Platten stellen · " + (r.sealTicks / 20) + "/3 s";
      case LEVERS -> {
        DungeonPuzzles.Levers l = (DungeonPuzzles.Levers) state;
        int lit = 0;
        for (boolean b : l.lit) if (b) lit++;
        yield "Hebelrätsel: " + lit + "/" + DungeonPuzzles.Levers.COUNT + " Lampen an";
      }
      case PLATES -> {
        DungeonPuzzles.Plates pl = (DungeonPuzzles.Plates) state;
        yield "Plattenlauf: " + pl.step + "/" + pl.order.length + " · " + Math.max(0, (r.plateDeadline - tick) / 20) + " s";
      }
      case LIGHT -> "Lichtstrahl: Spiegel drehen, Kristall treffen";
      case TRAPS -> "Fallengang: alle zum anderen Ende";
      case BELLS ->
          tick < r.deadline
              ? "Hört zu …"
              : "Glocken: " + ((DungeonPuzzles.Bells) state).step + "/" + ((DungeonPuzzles.Bells) state).melody.length;
      case MIMICS ->
          r.mimicKey
              ? "Schlüssel gefunden · besiegt die Mimics (" + r.mobs.size() + ")"
              : "Falsche Truhen: Schlüssel suchen";
    };
  }

  private void showPlate(Run r, DungeonPlan.Room room) {
    DungeonPuzzles.Plates plates = (DungeonPuzzles.Plates) r.puzzleStates.get(room.index);
    for (int k = 0; k < 9; k++)
      plate(r, room, k)
          .getBlock()
          .setType(
              plates.step < plates.order.length && k == plates.current()
                  ? Material.SEA_LANTERN
                  : Material.GRAY_CONCRETE,
              false);
  }

  private void puzzleTick(Run r) {
    DungeonPlan.Room room = room(r);
    Object state = r.puzzleStates.get(room.index);
    switch (room.puzzle) {
      case SEALS -> {
        int needed = Math.max(1, Math.min(3, living(r).size()));
        Set<UUID> used = new HashSet<>();
        for (int i = 0; i < needed; i++) {
          Location pad = at(r, -6 + i * 6, 0, 3);
          for (Player p : living(r))
            if (!used.contains(p.getUniqueId()) && p.getLocation().distanceSquared(pad) < 2.2) {
              used.add(p.getUniqueId());
              break;
            }
          circle(pad, 1, Color.AQUA);
        }
        r.sealTicks = used.size() == needed ? r.sealTicks + 2 : 0;
        if (r.sealTicks >= 60) completePuzzle(r);
      }
      case PLATES -> {
        DungeonPuzzles.Plates plates = (DungeonPuzzles.Plates) state;
        Location target = plate(r, room, plates.current()).add(0, 1, 0);
        if (tick % 6 == 0) circle(target, .8, Color.YELLOW);
        boolean on =
            living(r).stream()
                .anyMatch(
                    p ->
                        Math.abs(p.getX() - target.getX()) < .9
                            && Math.abs(p.getZ() - target.getZ()) < .9
                            && Math.abs(p.getY() - target.getY()) < 1.2);
        if (on) {
          for (Player p : online(r)) p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, .8f, .8f + plates.step * .15f);
          if (plates.stepOn(plates.current())) {
            showPlate(r, room);
            completePuzzle(r);
            return;
          }
          r.plateDeadline = tick + plates.window;
          showPlate(r, room);
        } else if (tick > r.plateDeadline) {
          plates.step = 0;
          r.plateDeadline = tick + 40 + plates.window;
          showPlate(r, room);
          say(r, "Zu langsam! Der Plattenlauf beginnt von vorn.");
          for (Player p : living(r)) hurt(r, p, 1 + r.mode);
        }
      }
      case LIGHT -> {
        if (tick % 6 != 0) break;
        DungeonPuzzles.Light light = (DungeonPuzzles.Light) state;
        Location from = in(r, room, -9, 1.2, lightZ(light.sourceZ));
        for (int[] cell : light.beam()) {
          Location to = in(r, room, lightX(cell[0]), 1.2, lightZ(cell[1]));
          Vector step = to.toVector().subtract(from.toVector()).multiply(1 / 6.0);
          Location dot = from.clone();
          for (int i = 0; i < 6; i++) {
            dot.add(step);
            dot.getWorld().spawnParticle(Particle.DUST, dot, 1, 0, 0, 0, 0, new Particle.DustOptions(Color.YELLOW, 1.1f));
          }
          from = to;
        }
      }
      case TRAPS -> {
        int length = room.out.alongX() ? room.hw : room.hd;
        int stripes = DungeonPuzzles.Traps.stripes(length * 2);
        double damage = DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * 1.2;
        for (int k = 0; k < stripes; k++) {
          int stateNow = DungeonPuzzles.Traps.state(k, tick);
          int a = trapStripe(room, k);
          if (stateNow == 0 || tick % 4 != 0 && stateNow == 1) continue;
          for (int lateral = -3; lateral <= 3; lateral++) {
            Location l = trapLocation(r, room, a, lateral, .2);
            if (stateNow == 1)
              l.getWorld().spawnParticle(Particle.DUST, l, 1, .2, 0, .2, 0, new Particle.DustOptions(Color.RED, 1.3f));
            else if (tick % 4 == 0) l.getWorld().spawnParticle(Particle.FLAME, l, 3, .3, .5, .3, .02);
          }
          if (stateNow == 2)
            for (Player p : living(r))
              if (Math.abs(along(r, room, p.getLocation()) - a) < 1.3
                  && tick - r.trapHits.getOrDefault(p.getUniqueId(), -100L) > 12) {
                r.trapHits.put(p.getUniqueId(), tick);
                hurt(r, p, damage);
                p.setFireTicks(20);
              }
        }
        if (living(r).stream().allMatch(p -> along(r, room, p.getLocation()) >= length - 4))
          completePuzzle(r);
      }
      case BELLS -> {
        DungeonPuzzles.Bells bells = (DungeonPuzzles.Bells) state;
        long since = tick - r.puzzleStarted;
        if (tick < r.deadline && since >= 0 && since % 14 == 0 && since / 14 < bells.melody.length)
          ringBell(r, room, bells.melody[(int) (since / 14)]);
      }
      case MIMICS -> {
        if (r.mimicKey && r.mobs.isEmpty()) completePuzzle(r);
      }
      default -> {}
    }
  }

  private void ringBell(Run r, DungeonPlan.Room room, int bell) {
    Location at = in(r, room, -6 + bell * 4, 1.4, -6);
    at.getWorld().playSound(at, Sound.BLOCK_NOTE_BLOCK_BELL, 1.2f, DungeonPuzzles.Bells.PITCH[bell]);
    at.getWorld().spawnParticle(Particle.NOTE, at.clone().add(0, .6, 0), 3, .2, .1, .2, 1);
  }

  private void puzzleClick(Run r, Player p, org.bukkit.block.Block block, String action) {
    DungeonPlan.Room room = room(r);
    String[] part = action.split(":");
    int i = Integer.parseInt(part[1]);
    Object state = r.puzzleStates.get(room.index);
    switch (part[0]) {
      case "rune" -> {
        if (room.puzzle != DungeonPlan.Puzzle.RUNES || tick < r.deadline) return;
        if (r.sequence.get(r.memoryStep) == i) {
          r.memoryStep++;
          p.getWorld().playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1, .7f + r.memoryStep * .3f);
          if (r.memoryStep == r.sequence.size()) completePuzzle(r);
        } else {
          r.memoryStep = 0;
          r.mistakes++;
          r.deadline = tick + 100;
          say(r, "Falsche Rune! Die Reihenfolge wird nochmals angezeigt; die Runen entladen sich.");
          for (Player member : living(r)) hurt(r, member, 2 + r.mode);
        }
      }
      case "lever" -> {
        if (room.puzzle != DungeonPlan.Puzzle.LEVERS) return;
        DungeonPuzzles.Levers levers = (DungeonPuzzles.Levers) state;
        levers.pull(i);
        var data = (org.bukkit.block.data.Powerable) block.getBlockData();
        data.setPowered(!data.isPowered());
        block.setBlockData(data, false);
        drawLamps(r, room, levers);
        p.getWorld().playSound(block.getLocation(), Sound.BLOCK_LEVER_CLICK, 1, 1);
        if (levers.solved()) completePuzzle(r);
      }
      case "mirror" -> {
        if (room.puzzle != DungeonPlan.Puzzle.LIGHT) return;
        DungeonPuzzles.Light light = (DungeonPuzzles.Light) state;
        light.rotate(i);
        ItemDisplay glass = r.mirrors.get(i);
        if (glass != null) turnMirror(glass, light.mirrors.get(i));
        p.getWorld().playSound(block.getLocation(), Sound.BLOCK_GRINDSTONE_USE, .6f, 1.4f);
        if (light.solved()) {
          in(r, room, lightX(light.targetX), 0, lightZ(light.targetZ)).getBlock().setType(Material.BEACON, false);
          completePuzzle(r);
        }
      }
      case "bell" -> {
        if (room.puzzle != DungeonPlan.Puzzle.BELLS || tick < r.deadline) return;
        DungeonPuzzles.Bells bells = (DungeonPuzzles.Bells) state;
        ringBell(r, room, i);
        int result = bells.ring(i);
        if (result == 2) completePuzzle(r);
        else if (result == 0) {
          say(r, "Falscher Ton! Die Melodie wird noch einmal gespielt.");
          for (Player member : living(r)) hurt(r, member, 1 + r.mode);
          replayPuzzle(r);
        }
      }
      case "chest" -> {
        if (room.puzzle != DungeonPlan.Puzzle.MIMICS) return;
        DungeonPuzzles.Mimics mimics = (DungeonPuzzles.Mimics) state;
        if (mimics.opened[i]) return;
        mimics.opened[i] = true;
        Location at = block.getLocation().add(.5, 0, .5);
        block.setType(Material.AIR, false);
        r.clickables.remove(block);
        if (i == mimics.key) {
          r.mimicKey = true;
          p.getWorld().playSound(at, Sound.BLOCK_CHEST_OPEN, 1, 1);
          say(r, "Schlüssel gefunden!" + (r.mobs.isEmpty() ? "" : " Besiegt noch die Mimics."));
        } else {
          p.getWorld().playSound(at, Sound.ENTITY_EVOKER_FANGS_ATTACK, 1, .7f);
          spawnAt(r, false, random.nextInt(4), at, room.index);
          Enemy e = r.mobs.getLast();
          e.elite = true;
          e.hp = e.max = DungeonRules.health(r.zone, r.mode, r.size, Math.max(1, r.wave), false, r.level) * 1.2;
          e.mob.customName(Component.text("Mimic", NamedTextColor.RED));
          health(e);
          say(r, "Ein Mimic! Diese Truhe war falsch.");
        }
      }
      default -> {}
    }
  }

  // ---- Self test (/df verify) ----

  private void diagnose(Run r) {
    List<String> problems = new ArrayList<>();
    for (DungeonPlan.Corridor c : r.plan.corridors)
      for (int t = 1; t < c.tiles.size() - 1; t++) {
        DungeonPlan.Tile tile = c.tiles.get(t);
        Location l = worldAt(r, tile.x(), tile.floor(), tile.z());
        if (!l.getBlock().isPassable()
            || !l.clone().add(0, 1, 0).getBlock().isPassable()
            || !l.clone().add(0, -1, 0).getBlock().getType().isSolid())
          problems.add("corridor " + c.index + " blocked at " + tile);
      }
    int puzzles = 0;
    for (DungeonPlan.Room room : r.plan.rooms) {
      Location center = in(r, room, room.shape == DungeonPlan.Shape.BRIDGE ? 0 : 1, 0, 0);
      if (!center.clone().add(0, -1, 0).getBlock().getType().isSolid()) problems.add("room " + room.index + " floor");
      if (room.puzzle != null) puzzles++;
    }
    // Every clickable puzzle part must still be there, and every mirror has its glass.
    for (var entry : r.clickables.entrySet()) {
      Material type = entry.getKey().getType();
      String kind = entry.getValue().split(":")[0];
      boolean ok =
          switch (kind) {
            case "rune" -> type.name().endsWith("_CONCRETE");
            case "lever" -> type == Material.LEVER;
            case "bell" -> type == Material.BELL;
            case "chest", "treasure" -> type == Material.CHEST;
            case "mirror" -> type == Material.POLISHED_ANDESITE;
            case "key" -> type == Material.BARREL;
            case "lock" -> type == Material.LODESTONE;
            default -> type != Material.AIR;
          };
      if (!ok) problems.add(entry.getValue() + " is " + type);
    }
    for (DungeonPlan.Room room : r.plan.rooms)
      if (room.puzzle == DungeonPlan.Puzzle.LIGHT) {
        DungeonPuzzles.Light light = (DungeonPuzzles.Light) r.puzzleStates.get(room.index);
        if (r.mirrors.size() != light.mirrors.size()) problems.add("mirror displays " + r.mirrors.size() + "/" + light.mirrors.size());
        long bases = r.clickables.values().stream().filter(v -> v.startsWith("mirror:")).count();
        if (bases != light.mirrors.size()) problems.add("mirror bases " + bases + "/" + light.mirrors.size());
      }
    int expected = 0, checked = 0;
    Set<Integer> kinds = new HashSet<>();
    boolean boss = false;
    for (int w = 1; w <= r.totalWaves; w++) {
      r.room = w == r.totalWaves ? r.plan.mainRooms - 1 : 0;
      r.wave = w - 1;
      beginWave(r);
      expected += DungeonRules.count(w, r.size, r.level);
      for (int guard = 0; guard < 100 && (!r.mobs.isEmpty() || r.pending > 0); guard++) {
        for (Enemy e : new ArrayList<>(r.mobs)) {
          checked++;
          kinds.add(e.kind);
          boss |= e.boss;
          removeEnemy(e);
        }
        refill(r);
      }
    }
    if (checked != expected) problems.add("enemies " + checked + "/" + expected);
    if (!boss) problems.add("no boss");
    List<Chunk> chunks =
        r.chunks.stream()
            .map(key -> plugin.mines().world().getChunkAt((int) (long) key, (int) (key >> 32)))
            .toList();
    String summary =
        r.plan.mainRooms + " rooms, " + (r.plan.rooms.size() - r.plan.mainRooms) + " side rooms, "
            + r.plan.corridors.size() + " corridors, " + puzzles + " puzzles, " + checked
            + " enemies, " + kinds.size() + " kinds";
    finish(r, false, "");
    if (plugin.mines().world().getEntities().stream().anyMatch(e -> inside(r, e.getLocation())))
      problems.add("entities left");
    if (chunks.stream().anyMatch(c -> c.getPluginChunkTickets().contains(plugin)))
      problems.add("chunk tickets left");
    verification = problems.isEmpty() ? "OK: " + summary : "FAILED: " + problems + " · " + summary;
  }

  /** Where a member may be moved to: this room, the way on while travelling, an open side room. */
  private boolean allowed(Run r, Location to) {
    int bx = (int) Math.floor(to.getX() - r.x), bz = (int) Math.floor(to.getZ() + 512);
    DungeonPlan.Room at = r.plan.roomAt(bx, bz);
    if (at != null)
      return at.index == r.room
          || r.stage == Stage.TRAVEL && at.index == r.room + 1
          || at.role == DungeonPlan.Role.SIDE && at.parent == r.room && r.branchOpen[r.room];
    int c = r.plan.corridorAt(bx, bz);
    if (c < 0) return false;
    DungeonPlan.Corridor corridor = r.plan.corridors.get(c);
    if (corridor.from != r.room) return false;
    return r.stage == Stage.TRAVEL && corridor.to == r.room + 1
        || r.plan.rooms.get(corridor.to).role == DungeonPlan.Role.SIDE && r.branchOpen[r.room];
  }

  public void disconnect(Player p) {
    if (watching(p)) stopWatching(p, null);
    Run r = membership.get(p.getUniqueId());
    if (r != null) {
      r.disconnected.put(p.getUniqueId(), tick);
      p.hideBossBar(r.bar);
      say(r, p.getName() + " hat 60 Sekunden zum Wiederbeitreten.");
    } else parties.leave(p.getUniqueId());
  }

  public void resume(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r == null) return;
    if (tick - r.disconnected.getOrDefault(p.getUniqueId(), tick) > 1200) {
      remove(r, p.getUniqueId());
      return;
    }
    r.disconnected.remove(p.getUniqueId());
    p.showBossBar(r.bar);
    if (r.stage != Stage.BUILDING) p.teleport(checkpoint(r, r.down.contains(p.getUniqueId())));
  }

  public void withdraw(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r == null) return;
    remove(r, p.getUniqueId());
    p.hideBossBar(r.bar);
    plugin.goHome(p);
    plugin.autoPreset(p, GearPresets.AUTO_AFTER);
    plugin.tell(p, "Dungeon verlassen. Keine Abschlussbeute für diesen Lauf.");
    if (r.members.isEmpty()) finish(r, false, "");
  }

  private void remove(Run r, UUID id) {
    Player gone = Bukkit.getPlayer(id);
    if (gone != null) thaw(gone);
    r.frost.remove(id);
    r.members.remove(id);
    r.down.remove(id);
    r.disconnected.remove(id);
    membership.remove(id, r);
    parties.leave(id);
    clicks.remove(id);
  }

  private void removeEnemy(Enemy e) {
    enemies.remove(e.mob.getUniqueId());
    e.run.mobs.remove(e);
    if (e.rig != null) e.rig.close();
    if (e.health != null) e.health.close();
    e.mob.remove();
  }

  private void finish(Run r, boolean win, String message) {
    if (r.ended) return;
    r.ended = true;
    try {
      Map<String, RewardDiff> gains =
          win
              ? plugin.rewardDungeon(
                  List.copyOf(r.members),
                  r.id,
                  r.zone,
                  r.mode,
                  tick - r.started,
                  r.level,
                  r.optionalFlags,
                  r.variant)
              : Map.of();
      if (!message.isBlank()) say(r, message);
      if (win)
        for (Player player : online(r)) {
          plugin.items().refresh(player, plugin.profile(player));
          RewardDiff gain = gains.get(player.getUniqueId().toString());
          if (gain == null) {
            plugin.tell(player, "Diese Belohnung hast du für diesen Lauf bereits erhalten.");
            continue;
          }
          plugin.passXp(player, DeepPass.XP_DUNGEON);
          plugin.commit(player, plugin.profile(player));
          plugin.tell(player, "━━━━━━━ DUNGEON-BEUTE ━━━━━━━");
          for (String line : gain.lines()) plugin.tell(player, "  " + line);
          if (r.bossFought && !r.bossStruck.contains(player.getUniqueId())) {
            long bonus = DungeonRules.coins(r.zone, r.mode, r.level) / 4;
            plugin.change(
                player,
                data -> {
                  data.money += bonus;
                  data.lifetimeRevenue += bonus;
                  data.flawlessBosses++;
                  return "  MAKELLOS! Keinem großen Bossangriff getroffen: +" + bonus + " $";
                });
          }
          plugin.tell(player, "Alles ansehen: /df reward · Ausrüsten: /df loot");
          plugin.tell(
              player,
              "Bonus: bis zu 3 Gewölbekisten für diesen Sieg kaufen (erste "
                  + Hud.money(LootChests.price(plugin.profile(player)))
                  + ") – /df reward");
          player.showTitle(
              net.kyori.adventure.title.Title.title(
                  net.kyori.adventure.text.Component.text(
                      "SIEG!", net.kyori.adventure.text.format.NamedTextColor.GOLD),
                  net.kyori.adventure.text.Component.text(
                      gain.headline(), net.kyori.adventure.text.format.NamedTextColor.YELLOW)));
          player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
          UUID id = player.getUniqueId();
          // After the teleport home the reward window shows every new item with its values.
          Bukkit.getScheduler()
              .runTaskLater(
                  plugin,
                  () -> {
                    Player back = Bukkit.getPlayer(id);
                    if (back != null && plugin.playing(back) && !active(back))
                      plugin.menus().open(back, "reward");
                  },
                  50);
        }
    } finally {
      r.stage = Stage.COMPLETE;
      for (UUID id : new ArrayList<>(r.watchers)) {
        Player w = Bukkit.getPlayer(id);
        if (w != null)
          stopWatching(w, win ? "Der Lauf ist vorbei – Sieg!" : "Der Lauf ist vorbei.");
        else watching.remove(id, r);
      }
      r.watchers.clear();
      for (Enemy e : new ArrayList<>(r.mobs)) removeEnemy(e);
      r.decorations.forEach(Entity::remove);
      r.decorations.clear();
      runs.remove(r.slot, r);
      for (UUID id : new ArrayList<>(r.members)) {
        membership.remove(id, r);
        clicks.remove(id);
        Player p = Bukkit.getPlayer(id);
        if (p != null) {
          thaw(p);
          p.hideBossBar(r.bar);
          plugin.goHome(p);
          plugin.autoPreset(p, GearPresets.AUTO_AFTER);
        } else parties.leave(id);
      }
      for (long key : r.chunks)
        plugin
            .mines()
            .world()
            .getChunkAt((int) key, (int) (key >> 32))
            .removePluginChunkTicket(plugin);
      r.chunks.clear();
    }
  }

  // ---- Spectating ----

  public boolean watching(Player p) {
    return watching.containsKey(p.getUniqueId());
  }

  /** Watch the run of {@code target}, or the next running dungeon when no name is given. */
  public void spectate(Player p, String target) {
    if (active(p))
      throw new IllegalArgumentException("Du bist selbst im Dungeon – zuschauen geht danach.");
    if (plugin.combat().fighting(p))
      throw new IllegalArgumentException("Zuerst den Kampf beenden.");
    Run r;
    if (target != null) {
      Player t = Bukkit.getPlayerExact(target);
      r = t == null ? null : membership.get(t.getUniqueId());
      if (r == null || r.ended)
        throw new IllegalArgumentException(target + " ist gerade in keinem Dungeon.");
    } else {
      List<Run> open =
          runs.values().stream()
              .filter(x -> !x.ended)
              .sorted(Comparator.comparingInt(x -> x.slot))
              .toList();
      if (open.isEmpty()) throw new IllegalArgumentException("Gerade läuft kein Dungeon.");
      Run current = watching.get(p.getUniqueId());
      r = open.get(current == null ? 0 : (open.indexOf(current) + 1) % open.size());
    }
    watch(p, r);
  }

  /** Admin view: watch the run in instance slot {@code slot}. */
  public void watchSlot(Player p, int slot) {
    Run r = runs.get(slot);
    if (r == null || r.ended) throw new IllegalArgumentException("Dieser Lauf ist schon vorbei.");
    if (active(p)) throw new IllegalArgumentException("Du bist selbst im Dungeon.");
    watch(p, r);
  }

  private void watch(Player p, Run r) {
    UUID id = p.getUniqueId();
    Run before = watching.put(id, r);
    if (before != null) {
      before.watchers.remove(id);
      p.hideBossBar(before.bar);
    }
    r.watchers.add(id);
    p.closeInventory();
    SpectatorState.enter(p);
    p.setSpectatorTarget(null);
    p.showBossBar(r.bar);
    p.teleport(watchPoint(r));
    plugin.tell(
        p,
        "Du schaust zu: "
            + names(r)
            + " · "
            + r.variant.title
            + " · "
            + DungeonRules.MODES[r.mode]
            + ". Spieler anklicken = ihre Sicht · /df dungeon zuschauen = nächster Dungeon ·"
            + " /df dungeon leave = beenden.");
    if (before != r)
      for (Player m : online(r)) plugin.tell(m, p.getName() + " schaut euch zu.");
  }

  private Location watchPoint(Run r) {
    DungeonPlan.Room room = room(r);
    Location l = at(r, 0, Math.min(7, room.height - 2), room.hd - 3);
    l.setPitch(25);
    return l;
  }

  private String names(Run r) {
    return r.members.stream().map(this::name).reduce((a, b) -> a + ", " + b).orElse("?");
  }

  public void stopWatching(Player p, String message) {
    Run r = watching.remove(p.getUniqueId());
    if (r == null) return;
    r.watchers.remove(p.getUniqueId());
    p.hideBossBar(r.bar);
    if (p.getGameMode() == GameMode.SPECTATOR) p.setSpectatorTarget(null);
    SpectatorState.restore(p);
    if (message != null) plugin.tell(p, message);
  }

  /** Watchers stay inside the dungeon they watch. */
  private void keepWatchers() {
    for (Map.Entry<UUID, Run> w : new ArrayList<>(watching.entrySet())) {
      Player p = Bukkit.getPlayer(w.getKey());
      Run r = w.getValue();
      if (p == null) {
        watching.remove(w.getKey());
        r.watchers.remove(w.getKey());
        continue;
      }
      if (p.getGameMode() != GameMode.SPECTATOR) {
        // Someone changed the gamemode by hand: treat it as leaving.
        stopWatching(p, "Zuschauen beendet.");
        continue;
      }
      if (p.getSpectatorTarget() == null && !inside(r, p.getLocation()))
        p.teleport(watchPoint(r));
    }
  }

  /** One line per running dungeon, for the admin overview. */
  public record RunInfo(int slot, String title, List<String> lines) {}

  public List<RunInfo> overview() {
    List<RunInfo> out = new ArrayList<>();
    for (Run r : runs.values().stream().sorted(Comparator.comparingInt(x -> x.slot)).toList()) {
      if (r.ended) continue;
      long seconds = (tick - r.started) / 20;
      out.add(
          new RunInfo(
              r.slot,
              r.variant.title + " · " + Zone.at(r.zone).title + " · " + DungeonRules.MODES[r.mode],
              List.of(
                  "Spieler: " + names(r),
                  "Level " + r.level + " · " + r.stage.name() + " · Welle " + r.wave + "/" + r.totalWaves,
                  "Läuft seit " + seconds / 60 + ":" + String.format("%02d", seconds % 60),
                  "Zuschauer: " + r.watchers.size())));
    }
    return out;
  }

  /** Admin: close a run without rewards (for stuck or abused runs). */
  public void closeRun(int slot, String by) {
    Run r = runs.get(slot);
    if (r == null || r.ended) throw new IllegalArgumentException("Dieser Lauf ist schon vorbei.");
    finish(r, false, "Dieser Dungeon wurde von " + by + " beendet. Deine Ausrüstung bleibt erhalten.");
  }

  public String verify() {
    if (verification.startsWith("RUNNING")) return verification;
    int slot = 0;
    while (runs.containsKey(slot)) slot++;
    if (slot >= 4) return "BUSY";
    Run r =
        new Run(
            slot,
            0,
            0,
            List.of(UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID()),
            31);
    r.diagnostic = true;
    runs.put(slot, r);
    verification = "RUNNING: arena and model lifecycle";
    return verification;
  }

  public String verification() {
    return verification;
  }

  @Override
  public void close() {
    task.cancel();
    for (Run r : new ArrayList<>(runs.values()))
      finish(r, false, "Serverneustart: Dungeon beendet, keine Ausrüstung verloren.");
  }
}
