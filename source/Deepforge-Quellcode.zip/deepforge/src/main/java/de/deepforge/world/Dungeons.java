package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import de.deepforge.ui.Hud;
import java.util.*;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

/**
 * Bounded, private cooperative instances in the plugin-owned world. All state runs on the main
 * thread.
 */
public final class Dungeons implements Listener, AutoCloseable {
  private final DeepforgePlugin plugin;
  private final PartyBook parties = new PartyBook();
  private final Map<UUID, Run> membership = new HashMap<>();
  private final Map<Integer, Run> runs = new HashMap<>();
  private final Map<UUID, Enemy> enemies = new HashMap<>();
  private final Map<UUID, Long> clicks = new HashMap<>();
  private final Map<UUID, Run> watching = new HashMap<>();
  private final Random random = new Random();
  private final BukkitTask task;
  private long tick;
  private String verification = "Noch nicht gestartet";
  private static final Material[] RUNES = {
    Material.RED_CONCRETE, Material.BLUE_CONCRETE, Material.LIME_CONCRETE, Material.YELLOW_CONCRETE
  };
  private static final String[] NAMES = {"Rot", "Blau", "Grün", "Gelb"};

  private enum Stage {
    BUILDING,
    COUNTDOWN,
    WAVE,
    TRAVEL,
    SIDE,
    MEMORY,
    SEALS,
    COMPLETE
  }

  private static final class Run {
    final UUID id = UUID.randomUUID();
    final int slot, zone, mode, x, level, totalWaves;
    final DungeonVariant variant;
    // Glutschmiede: spots that erupt at eruptLand; Frostkrypta: frost stacks and warm braziers.
    final List<Location> eruptSpots = new ArrayList<>();
    long eruptNext, eruptLand;
    final Map<UUID, Integer> frost = new HashMap<>();
    final List<Location> braziers = new ArrayList<>();
    long frostNext;
    // Players watching this run in spectator mode.
    final Set<UUID> watchers = new LinkedHashSet<>();
    // Players currently taking part; follows leaves and disconnects during the run.
    int size;
    final LinkedHashSet<UUID> members;
    final Map<UUID, Long> disconnected = new HashMap<>();
    final Set<UUID> down = new HashSet<>();
    final Map<UUID, Integer> healingDrops = new HashMap<>();
    final DungeonBlessings blessings = new DungeonBlessings();
    final Set<Long> chunks = new HashSet<>();
    final List<Enemy> mobs = new ArrayList<>();
    final List<Entity> decorations = new ArrayList<>();
    final BossBar bar =
        BossBar.bossBar(
            Component.text("Gewölbe wird vorbereitet"),
            1,
            BossBar.Color.PURPLE,
            BossBar.Overlay.PROGRESS);
    Stage stage = Stage.BUILDING;
    long deadline, started, sealTicks;
    int room, cursor, wave, memoryStep, mistakes, pending, spawned, reinforcements;
    int optionalFlags, pendingOptional, diagnosticExtra;
    boolean challengeAttempted, key;
    final boolean[] branchOpen = new boolean[3];
    final Set<Integer> shrinesBuilt = new HashSet<>();
    Villager captive;
    boolean diagnostic, ended;
    boolean diagnosticValid = true, diagnosticElite, diagnosticBoss;
    int diagnosticChecked;
    final Set<Integer> diagnosticKinds = new HashSet<>();
    List<Integer> sequence = List.of();
    // Players hit by a big boss attack; everyone else earns the flawless bonus.
    final Set<UUID> bossStruck = new HashSet<>();
    boolean bossFought;

    Run(int slot, int zone, int mode, List<UUID> ids) {
      this(slot, zone, mode, ids, 1);
    }

    Run(int slot, int zone, int mode, List<UUID> ids, int level) {
      this(slot, zone, mode, ids, level, DungeonVariant.GEWOELBE);
    }

    Run(int slot, int zone, int mode, List<UUID> ids, int level, DungeonVariant variant) {
      this.variant = variant;
      this.slot = slot;
      this.zone = zone;
      this.mode = mode;
      this.level = level;
      totalWaves = DungeonRules.waves(level);
      size = Math.max(1, ids.size());
      x = -512 - slot * 128;
      members = new LinkedHashSet<>(ids);
    }
  }

  private static final class Enemy {
    Run run;
    Mob mob;
    MonsterRig rig;
    MonsterHealthIndicator health;
    int kind;
    boolean boss, elite;
    double hp, max;
    long attackAt, resolveAt, recoilAt;
    final BossPressure pressure = new BossPressure();
    Location sweepOrigin;
    int spell;
    Location marker, secondary;
    Vector direction;
    BossBrain brain;
  }

  public Dungeons(DeepforgePlugin plugin) {
    this.plugin = plugin;
    Bukkit.getPluginManager().registerEvents(this, plugin);
    task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1, 2);
  }

  public boolean active(Player p) {
    return membership.containsKey(p.getUniqueId());
  }

  public PartyBook parties() {
    return parties;
  }

  public boolean down(Player p) {
    Run r = membership.get(p.getUniqueId());
    return r != null && r.down.contains(p.getUniqueId());
  }

  public boolean shrineBlock(Player p, org.bukkit.block.Block block) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || block == null) return false;
    if (optionalBlock(r, block)) return true;
    if (r.stage != Stage.TRAVEL) return false;
    for (int i = 0; i < 3; i++) if (block.equals(at(r, -8 + i * 8, 0, -10).getBlock())) return true;
    return false;
  }

  private Location at(Run r, double x, double y, double z) {
    return worldAt(r, x, y, z + DungeonLayout.roomZ(r.room));
  }

  private Location worldAt(Run r, double x, double y, double z) {
    return new Location(plugin.mines().world(), r.x + x + .5, 65 + y, -512 + z + .5, 180, 0);
  }

  public boolean contains(Player p) {
    Run r = membership.get(p.getUniqueId());
    return r != null && inside(r, p.getLocation());
  }

  private boolean inside(Run r, Location l) {
    return l.getWorld().equals(plugin.mines().world())
        && DungeonLayout.contains(l.getX() - r.x - .5, l.getY() - 65, l.getZ() + 511.5);
  }

  private List<Player> online(Run r) {
    return r.members.stream()
        .map(Bukkit::getPlayer)
        .filter(Objects::nonNull)
        .filter(Player::isOnline)
        .toList();
  }

  private List<Player> living(Run r) {
    return online(r).stream()
        .filter(
            p ->
                !r.down.contains(p.getUniqueId())
                    && plugin.playing(p)
                    && !p.isDead()
                    && inside(r, p.getLocation()))
        .toList();
  }

  private void say(Run r, String text) {
    online(r).forEach(p -> plugin.tell(p, text));
    for (UUID id : r.watchers) {
      Player w = Bukkit.getPlayer(id);
      if (w != null) plugin.tell(w, "[Zuschauer] " + text);
    }
  }

  private void partySay(PartyBook.Party party, String text) {
    for (UUID id : party.members) {
      Player p = Bukkit.getPlayer(id);
      if (p != null) plugin.tell(p, text);
    }
  }

  public void command(Player p, String[] args) {
    if (!plugin.playing(p)) {
      plugin.tell(p, "Zuerst /df start.");
      return;
    }
    try {
      if (args[0].equalsIgnoreCase("dungeon")) {
        if (args.length > 1 && args[1].equalsIgnoreCase("hint")) {
          Run r = membership.get(p.getUniqueId());
          if (r != null && r.stage == Stage.MEMORY) {
            r.deadline = tick + 100;
            r.memoryStep = 0;
            say(r, "Runenfolge wird erneut angezeigt. Danach bei der ersten Rune beginnen.");
          }
          return;
        }
        if (args.length > 1 && args[1].equalsIgnoreCase("leave")) {
          if (watching(p)) stopWatching(p, "Zuschauen beendet.");
          else withdraw(p);
          return;
        }
        if (args.length > 1
            && Set.of("zuschauen", "spectate", "watch").contains(args[1].toLowerCase(Locale.ROOT))) {
          spectate(p, args.length > 2 ? args[2] : null);
          return;
        }
        if (args.length > 1 && args[1].equalsIgnoreCase("start")) {
          int mode = args.length > 2 ? Integer.parseInt(args[2]) - 1 : 0;
          int zone = args.length > 3 ? Integer.parseInt(args[3]) - 1 : commonZone(p);
          int variant = args.length > 4 ? Integer.parseInt(args[4]) - 1 : 0;
          if (variant < 0 || variant >= DungeonVariant.values().length)
            throw new IllegalArgumentException(
                "Dungeon 1 = Runengewölbe, 2 = Glutschmiede, 3 = Frostkrypta.");
          start(p, zone, mode, DungeonVariant.of(variant));
          return;
        }
        open(p, commonZone(p), lastVariant(p));
        return;
      }
      String action = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "status";
      UUID id = p.getUniqueId();
      if (active(p) && !action.equals("status"))
        throw new IllegalArgumentException(
            "Während des Laufs ist die Party fest. /df dungeon leave zum Aussteigen.");
      switch (action) {
        case "create" -> {
          parties.create(id);
          plugin.tell(p, "Party erstellt. /df party invite <Spieler> · maximal 4 Spieler.");
        }
        case "invite" -> {
          Player guest = args.length > 2 ? Bukkit.getPlayerExact(args[2]) : null;
          if (guest == null || !plugin.playing(guest) || active(guest))
            throw new IllegalArgumentException("Der Spieler muss online und in Deepforge sein.");
          parties.invite(id, guest.getUniqueId(), System.currentTimeMillis());
          plugin.tell(
              guest,
              p.getName() + " lädt dich ins Gewölbe ein. /df party accept (60 Sekunden gültig).");
          plugin.tell(p, "Einladung an " + guest.getName() + " gesendet.");
        }
        case "accept" -> {
          // An invitation is invalidated when its leader starts a run.
          PartyBook.Party joined = parties.accept(id, System.currentTimeMillis());
          if (joined.members.stream().anyMatch(membership::containsKey)) {
            parties.leave(id);
            throw new IllegalArgumentException("Die Gruppe ist schon im Dungeon.");
          }
          partySay(
              joined, p.getName() + " ist beigetreten. Alle bestätigen neu mit /df party ready.");
        }
        case "ready" -> {
          boolean ready = parties.ready(id);
          partySay(
              parties.get(id), p.getName() + (ready ? " ist bereit." : " ist nicht mehr bereit."));
        }
        case "leave" -> {
          parties.leave(id);
          plugin.tell(p, "Party verlassen.");
        }
        default -> {
          PartyBook.Party party = parties.get(id);
          if (party == null)
            plugin.tell(
                p, "/df party create · invite <Name> · accept · ready · leave. Solo: /df dungeon.");
          else {
            plugin.tell(p, "Party: " + party.members.size() + "/4 · Leiter: " + name(party.leader));
            for (UUID member : party.members)
              plugin.tell(
                  p, name(member) + (party.ready.contains(member) ? " · Bereit" : " · Wartet"));
          }
        }
      }
    } catch (IllegalArgumentException e) {
      plugin.tell(p, DeepforgePlugin.readable(e, e.getMessage() == null ? "Ungültige Eingabe." : e.getMessage()));
    }
  }

  private String name(UUID id) {
    Player p = Bukkit.getPlayer(id);
    return p == null ? "Offline" : p.getName();
  }

  private int commonZone(Player p) {
    PartyBook.Party party = parties.get(p.getUniqueId());
    int zone = plugin.profile(p).zone;
    if (party != null)
      for (UUID id : party.members) {
        Player m = Bukkit.getPlayer(id);
        if (m != null) zone = Math.min(zone, plugin.profile(m).zone);
      }
    return zone;
  }

  private int previewLevel(Player p, int zone) {
    PartyBook.Party party = parties.get(p.getUniqueId());
    List<Profile> profiles = new ArrayList<>();
    profiles.add(plugin.profile(p));
    if (party != null)
      for (UUID id : party.members) {
        Player member = Bukkit.getPlayer(id);
        if (member != null && !id.equals(p.getUniqueId())) profiles.add(plugin.profile(member));
      }
    return DungeonRules.groupLevel(profiles, zone);
  }

  private static final class Menu implements InventoryHolder {
    Inventory inventory;
    int zone;
    DungeonVariant variant = DungeonVariant.GEWOELBE;
    UUID owner;

    public Inventory getInventory() {
      return inventory;
    }
  }

  private ItemStack icon(Material material, String title, String... lore) {
    String model =
        switch (material) {
          case LIME_DYE -> "relic";
          case PLAYER_HEAD -> "gear_helmet";
          case OAK_DOOR, BARRIER -> "close";
          case IRON_SWORD -> "weapon_sword";
          case DIAMOND_SWORD -> "weapon_spear";
          case NETHERITE_SWORD -> "weapon_hammer";
          case ARROW -> "back";
          case AMETHYST_SHARD -> "healing_crystal";
          case CHEST -> "crate";
          case CLOCK -> "clock";
          default -> "handbook";
        };
    return icon(material, model, false, title, lore);
  }

  /** Menu button; {@code model == null} keeps the vanilla item, {@code glint} marks the choice. */
  private ItemStack icon(
      Material material, String model, boolean glint, String title, String... lore) {
    ItemStack item = plugin.items().button(material, model == null ? "handbook" : model, title, lore);
    org.bukkit.inventory.meta.ItemMeta meta = item.getItemMeta();
    if (model == null) meta.setItemModel(null);
    if (glint) meta.setEnchantmentGlintOverride(true);
    item.setItemMeta(meta);
    return item;
  }

  // Last dungeon picked in the menu, so reopening shows the same one.
  private final Map<UUID, DungeonVariant> picked = new HashMap<>();

  private DungeonVariant lastVariant(Player p) {
    Run r = membership.get(p.getUniqueId());
    return r != null ? r.variant : picked.getOrDefault(p.getUniqueId(), DungeonVariant.GEWOELBE);
  }

  /** Every party member (or the player alone) has this dungeon unlocked. */
  private boolean unlockedForAll(Player p, DungeonVariant v) {
    if (!v.unlocked(plugin.profile(p))) return false;
    PartyBook.Party party = parties.get(p.getUniqueId());
    if (party != null)
      for (UUID id : party.members) {
        Player m = Bukkit.getPlayer(id);
        if (m != null && !v.unlocked(plugin.profile(m))) return false;
      }
    return true;
  }

  public void open(Player p, int zone) {
    open(p, zone, lastVariant(p));
  }

  /** Members whose progress blocks {@code mode} in {@code zone}, with the reason. */
  private List<String> missing(Player p, int zone, int mode) {
    List<String> out = new ArrayList<>();
    PartyBook.Party party = parties.get(p.getUniqueId());
    List<UUID> ids = party == null ? List.of(p.getUniqueId()) : List.copyOf(party.members);
    for (UUID id : ids) {
      Player member = Bukkit.getPlayer(id);
      if (member == null) {
        out.add(name(id) + " (offline)");
        continue;
      }
      Profile data = plugin.profile(member);
      if (data.zone < zone) out.add(member.getName() + " (Gebiet fehlt)");
      else if (mode > 0 && data.dungeonWins[zone * 3 + mode - 1] == 0)
        out.add(member.getName() + " (" + DungeonRules.MODES[mode - 1] + "-Sieg fehlt)");
    }
    return out;
  }

  // Menu layout: one row per step, labels in the left column.
  private static final int ROW_DUNGEON = 9, ROW_ZONE = 18, ROW_MODE = 27, ROW_PARTY = 36;
  private static final Material[] VARIANT_ICONS = {
    Material.CHISELED_STONE_BRICKS, Material.MAGMA_BLOCK, Material.PACKED_ICE
  };

  public void open(Player p, int zone, DungeonVariant variant) {
    boolean inRun = active(p);
    Menu m = new Menu();
    m.zone = Math.clamp(zone, 0, commonZone(p));
    int level = inRun ? membership.get(p.getUniqueId()).level : previewLevel(p, m.zone);
    m.variant = unlockedForAll(p, variant) ? variant : DungeonVariant.GEWOELBE;
    picked.put(p.getUniqueId(), m.variant);
    m.owner = p.getUniqueId();
    m.inventory =
        Bukkit.createInventory(m, 54, plugin.menus().styledTitle(p, "DUNGEON · LEVEL " + level));
    PartyBook.Party party = parties.get(p.getUniqueId());
    int size = party == null ? 1 : party.members.size();
    Inventory inv = m.inventory;

    // Summary of the current choice.
    inv.setItem(
        4,
        icon(
            VARIANT_ICONS[m.variant.ordinal()],
            null,
            true,
            m.variant.title + " · " + Zone.at(m.zone).title,
            "Endboss: " + m.variant.boss(m.zone),
            m.variant.hazard,
            m.variant.loot,
            DungeonRules.waves(level) + " Wellen · 2 Rätsel · " + DungeonRules.TIME_MINUTES + " Minuten",
            "Bedingung: " + DungeonRules.conditionName(level),
            "Dein Level in diesem Gebiet: " + DungeonRules.level(plugin.profile(p), m.zone),
            party != null ? "Gruppenlevel = höchstes Level der Party in diesem Gebiet" : ""));

    // 1 · Dungeon
    inv.setItem(ROW_DUNGEON, icon(Material.PAPER, "handbook", false, "① Dungeon wählen"));
    for (DungeonVariant v : DungeonVariant.values()) {
      boolean open = unlockedForAll(p, v), chosen = v == m.variant;
      inv.setItem(
          ROW_DUNGEON + 2 + v.ordinal() * 2,
          icon(
              open ? VARIANT_ICONS[v.ordinal()] : Material.BARRIER,
              open ? null : "close",
              chosen,
              (chosen ? "▶ " : "") + v.title + (open ? "" : " · gesperrt"),
              v.flavor,
              v.hazard,
              v.loot,
              "Deine Siege hier: " + DungeonVariant.wins(plugin.profile(p), v),
              chosen
                  ? "✔ Ausgewählt"
                  : open
                      ? "Klick: auswählen"
                      : "✖ " + v.requirement() + (party != null ? " (alle in der Party)" : "")));
    }

    // 2 · Gebiet
    int unlocked = commonZone(p);
    inv.setItem(ROW_ZONE, icon(Material.PAPER, "handbook", false, "② Gebiet wählen"));
    inv.setItem(
        ROW_ZONE + 2,
        m.zone > 0
            ? icon(Material.ARROW, "back", false, "◀ " + Zone.at(m.zone - 1).title)
            : icon(Material.GRAY_DYE, null, false, "Erstes Gebiet"));
    inv.setItem(
        ROW_ZONE + 4,
        icon(
            Material.RAW_IRON,
            "ore_" + Zone.at(m.zone).key,
            true,
            "Gebiet " + (m.zone + 1) + ": " + Zone.at(m.zone).title,
            "Dein Dungeonlevel hier: " + DungeonRules.level(plugin.profile(p), m.zone),
            "Wählbar: Gebiet 1 bis " + (unlocked + 1),
            party != null
                ? "Die Party kann nur Gebiete wählen, die alle freigeschaltet haben."
                : "Neue Gebiete schaltest du im Aufzug frei."));
    inv.setItem(
        ROW_ZONE + 6,
        m.zone < unlocked
            ? icon(Material.ARROW, "next", false, Zone.at(m.zone + 1).title + " ▶")
            : icon(
                Material.GRAY_DYE,
                null,
                false,
                m.zone < 6 ? "Gebiet " + (m.zone + 2) + " gesperrt" : "Letztes Gebiet",
                m.zone < 6
                    ? "Zuerst im Aufzug freischalten" + (party != null ? " (alle in der Party)" : "")
                    : ""));

    // 3 · Schwierigkeit & Start
    inv.setItem(ROW_MODE, icon(Material.PAPER, "handbook", false, "③ Schwierigkeit & Start"));
    boolean leader = party == null || party.leader.equals(p.getUniqueId());
    boolean allReady = party == null || party.ready.containsAll(party.members);
    for (int mode = 0; mode < 3; mode++) {
      List<String> blocked = missing(p, m.zone, mode);
      String state =
          inRun
              ? "Ihr seid schon im Dungeon."
              : !blocked.isEmpty()
                  ? "✖ Gesperrt – fehlt bei: " + String.join(", ", blocked)
                  : !allReady
                      ? "✖ Noch nicht alle bereit (" + party.ready.size() + "/" + size + ")"
                      : !leader ? "✖ Nur der Partyleiter kann starten" : "✔ Klick: jetzt starten!";
      List<String> lore = new ArrayList<>();
      lore.add(
          m.variant.coins(DungeonRules.coins(m.zone, mode, level))
              + " $ pro Person · Boss "
              + (int) DungeonRules.health(m.zone, mode, size, DungeonRules.waves(level), true, level)
              + " LP");
      lore.add(
          "Mythisch "
              + DungeonRules.mythicThreshold(mode, level) / 10.
              + " % · Legendär "
              + (DungeonRules.legendaryThreshold(mode, level)
                      - DungeonRules.mythicThreshold(mode, level))
                  / 10.
              + " %");
      if (mode > 0) lore.add("Braucht: " + DungeonRules.MODES[mode - 1] + "-Sieg in diesem Gebiet (alle)");
      lore.add(state);
      Material weapon =
          mode == 0 ? Material.IRON_SWORD : mode == 1 ? Material.DIAMOND_SWORD : Material.NETHERITE_SWORD;
      boolean ready = state.startsWith("✔");
      inv.setItem(
          ROW_MODE + 2 + mode * 2,
          icon(
              blocked.isEmpty() ? weapon : Material.BARRIER,
              blocked.isEmpty()
                  ? mode == 0 ? "weapon_sword" : mode == 1 ? "weapon_spear" : "weapon_hammer"
                  : "close",
              ready,
              DungeonRules.MODES[mode] + (blocked.isEmpty() ? "" : " · gesperrt"),
              lore.toArray(String[]::new)));
    }

    // 4 · Party
    inv.setItem(ROW_PARTY, icon(Material.PAPER, "handbook", false, "④ Party"));
    List<String> members = new ArrayList<>();
    if (party == null) members.add("Solo – du spielst allein");
    else
      for (UUID id : party.members)
        members.add(
            (party.ready.contains(id) ? "✔ " : "✖ ")
                + name(id)
                + (id.equals(party.leader) ? " (Leiter)" : ""));
    members.add("Einladen: /df party invite <Name>");
    members.add("Bis zu 4 Spieler · Gruppenlevel = höchstes Level");
    inv.setItem(
        ROW_PARTY + 2,
        icon(
            Material.PLAYER_HEAD,
            "gear_helmet",
            false,
            party == null ? "Keine Party" : "Party " + party.ready.size() + "/" + size + " bereit",
            members.toArray(String[]::new)));
    boolean meReady = party != null && party.ready.contains(p.getUniqueId());
    inv.setItem(
        ROW_PARTY + 4,
        icon(
            meReady ? Material.LIME_DYE : Material.GRAY_DYE,
            meReady ? "relic" : null,
            meReady,
            meReady ? "✔ Du bist bereit" : "Bereit melden",
            party == null ? "Solo: einfach eine Schwierigkeit anklicken" : "Klick: umschalten"));
    inv.setItem(
        ROW_PARTY + 6,
        icon(
            Material.OAK_DOOR,
            "close",
            false,
            inRun ? "Dungeon verlassen" : "Party verlassen",
            inRun ? "Du verlierst die Abschlussbeute dieses Laufs" : ""));
    long others = runs.values().stream().filter(r -> !r.members.contains(p.getUniqueId())).count();
    inv.setItem(
        ROW_PARTY + 8,
        icon(
            Material.ENDER_EYE,
            null,
            false,
            watching(p) ? "Nächsten Dungeon ansehen" : "Zuschauen",
            others == 0 ? "Gerade läuft kein anderer Dungeon" : others + " laufen gerade",
            "Beenden: /df dungeon leave"));

    // Bottom bar
    inv.setItem(45, icon(Material.ARROW, "Zurück: Kampf & Ausrüstung"));
    inv.setItem(47, icon(Material.BOOK, "Hauptmenü"));
    inv.setItem(49, icon(Material.BARRIER, "Schließen"));
    inv.setItem(
        51,
        icon(
            Material.CHEST,
            "So läuft ein Dungeon",
            m.variant.room(0) + ": 2 Wellen + Runenfolge",
            m.variant.room(1) + ": 2 Wellen + Gruppensiegel",
            m.variant.room(2)
                + ": "
                + (DungeonRules.waves(level) - 4)
                + (DungeonRules.waves(level) - 4 == 1 ? " Welle" : " Wellen")
                + " + Endboss",
            "Optional: Prüfung, Rettung, Schatzkammer",
            "Niederlage: alle gleichzeitig besiegt",
            "Jedes Gebiet hat sein eigenes Level: Sieg = +1 dort",
            "Beute: /df loot · Kisten nach dem Sieg: /df reward"));
    inv.setItem(
        53,
        icon(
            Material.AMETHYST_SHARD,
            "Heilen · " + plugin.profile(p).healingCharges + " Splitter",
            "Rechtsklick mit dem Splitter oder /df heal",
            "4 LP + 35 % Leben · 20 s Pause"));
    plugin.items().forViewer(m.inventory, p);
    p.openInventory(m.inventory);
  }

  @EventHandler
  public void click(InventoryClickEvent e) {
    if (!(e.getView().getTopInventory().getHolder() instanceof Menu m)) return;
    e.setCancelled(true);
    if (!(e.getWhoClicked() instanceof Player p) || !m.owner.equals(p.getUniqueId())) return;
    int slot = e.getRawSlot();
    // Opening another inventory inside the click event is unreliable; act one tick later.
    Bukkit.getScheduler().runTask(plugin, () -> {
      if (p.isOnline()) menuClick(p, m, slot);
    });
  }

  private void menuClick(Player p, Menu m, int slot) {
    try {
      if (slot == 49) p.closeInventory();
      else if (slot == 45 || slot == 47) plugin.menus().open(p, slot == 45 ? "combat" : "main");
      else if (slot == ROW_PARTY + 4) {
        if (active(p)) throw new IllegalArgumentException("Die Gruppe ist bereits im Dungeon.");
        if (parties.get(p.getUniqueId()) == null) parties.create(p.getUniqueId());
        parties.ready(p.getUniqueId());
        open(p, m.zone, m.variant);
      } else if (slot == ROW_PARTY + 6) {
        p.closeInventory();
        if (active(p)) withdraw(p);
        else parties.leave(p.getUniqueId());
      } else if (slot == ROW_PARTY + 8) spectate(p, null);
      else if (slot == ROW_ZONE + 2 || slot == ROW_ZONE + 6) {
        int next = m.zone + (slot == ROW_ZONE + 2 ? -1 : 1);
        if (next < 0 || next > commonZone(p)) {
          p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, .6f, 1);
          plugin.tell(
              p,
              next < 0
                  ? "Das ist bereits das erste Gebiet."
                  : "Gebiet " + (next + 1) + " ist noch nicht freigeschaltet"
                      + (parties.get(p.getUniqueId()) != null ? " (für alle in der Party)." : "."));
        } else {
          p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, .6f, 1.2f);
          open(p, next, m.variant);
        }
      } else if (slot >= ROW_DUNGEON + 2 && slot <= ROW_DUNGEON + 6 && slot % 2 == 1) {
        DungeonVariant v = DungeonVariant.of((slot - ROW_DUNGEON - 2) / 2);
        if (!unlockedForAll(p, v)) {
          p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, .6f, 1);
          plugin.tell(p, v.title + " ist noch gesperrt. " + v.requirement() + ".");
        } else {
          p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, .6f, 1.2f);
          open(p, m.zone, v);
        }
      } else if (slot == ROW_MODE + 2 || slot == ROW_MODE + 4 || slot == ROW_MODE + 6)
        start(p, m.zone, (slot - ROW_MODE - 2) / 2, m.variant);
    } catch (IllegalArgumentException ex) {
      p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, .6f, 1);
      plugin.tell(p, ex.getMessage());
    }
  }

  @EventHandler
  public void drag(InventoryDragEvent e) {
    if (e.getView().getTopInventory().getHolder() instanceof Menu) e.setCancelled(true);
  }

  private void start(Player leader, int zone, int mode, DungeonVariant variant) {
    if (zone < 0 || zone > 6 || mode < 0 || mode > 2)
      throw new IllegalArgumentException("/df dungeon start <1..3 Schwierigkeit> <1..7 Gebiet>");
    if (parties.get(leader.getUniqueId()) == null) {
      parties.create(leader.getUniqueId());
      parties.ready(leader.getUniqueId());
    }
    List<UUID> roster = parties.roster(leader.getUniqueId());
    for (UUID id : roster) {
      Player p = Bukkit.getPlayer(id);
      if (p == null
          || !plugin.playing(p)
          || p.isDead()
          || p.getGameMode() != GameMode.SURVIVAL
          || plugin.combat().fighting(p))
        throw new IllegalArgumentException(
            "Alle müssen online, im Überlebensmodus und außerhalb eines Kampfes sein.");
      Profile data = plugin.profile(p);
      if (data.zone < zone || mode > 0 && data.dungeonWins[zone * 3 + mode - 1] == 0)
        throw new IllegalArgumentException(
            p.getName() + " hat Gebiet oder Schwierigkeit noch nicht freigeschaltet.");
      if (!variant.unlocked(data))
        throw new IllegalArgumentException(
            p.getName()
                + " hat "
                + variant.title
                + " noch nicht freigeschaltet. "
                + variant.requirement()
                + ".");
    }
    int slot = 0;
    while (runs.containsKey(slot)) slot++;
    if (slot >= 4)
      throw new IllegalArgumentException("Alle vier Gewölbe sind belegt. Bitte kurz warten.");
    int level =
        DungeonRules.groupLevel(
            roster.stream().map(Bukkit::getPlayer).map(plugin::profile).toList(), zone);
    Run r = new Run(slot, zone, mode, roster, level, variant);
    r.started = tick;
    runs.put(slot, r);
    for (UUID id : roster) {
      Player p = Bukkit.getPlayer(id);
      plugin.combat().clear(p, false);
      p.closeInventory();
      membership.put(id, r);
      p.showBossBar(r.bar);
    }
    parties.get(leader.getUniqueId()).ready.clear();
    say(
        r,
        r.variant.title + " wird aufgebaut. Gruppe: "
            + roster.size()
            + " · "
            + DungeonRules.MODES[mode]
            + " · Level "
            + level
            + " · "
            + DungeonRules.conditionName(level)
            + ".");
  }

  private void tick() {
    tick += 2;
    if (tick % 20 == 0) keepWatchers();
    for (Run r : new ArrayList<>(runs.values())) {
      try {
        step(r);
      } catch (RuntimeException ex) {
        plugin.getLogger().log(java.util.logging.Level.SEVERE, "Dungeon instance failed", ex);
        finish(r, false, "Gewölbe wegen eines Fehlers geschlossen; dein Inventar bleibt erhalten.");
        if (r.diagnostic) verification = "FAILED: " + ex.getMessage();
      }
    }
  }

  /** Enemy health keeps its percentage when the party shrinks or grows mid-run. */
  private void resize(Run r) {
    int now =
        Math.max(
            1,
            (int)
                r.members.stream()
                    .filter(id -> !r.disconnected.containsKey(id) && Bukkit.getPlayer(id) != null)
                    .count());
    if (now == r.size) return;
    double ratio = RapidCombat.partyHealth(now) / RapidCombat.partyHealth(r.size);
    for (Enemy e : r.mobs) {
      e.max *= ratio;
      e.hp *= ratio;
    }
    say(
        r,
        "Gewölbe passt sich an: "
            + now
            + " Spieler – Gegner werden "
            + (now < r.size ? "schwächer." : "stärker."));
    r.size = now;
  }

  private void step(Run r) {
    if (r.stage == Stage.BUILDING) {
      build(r);
      return;
    }
    if (!r.diagnostic) {
      resize(r);
      hazard(r);
    }
    if (r.diagnostic) {
      if (tick >= r.deadline) {
        r.diagnosticValid &=
            r.mobs.size() <= DungeonRules.activeLimit(r.size)
                && r.mobs.stream().allMatch(m -> m.mob.isValid());
        for (Enemy enemy : new ArrayList<>(r.mobs)) {
          r.diagnosticChecked++;
          r.diagnosticKinds.add(enemy.kind);
          r.diagnosticElite |= enemy.elite;
          r.diagnosticBoss |= enemy.boss;
          removeEnemy(enemy);
        }
        refill(r);
        if (r.mobs.isEmpty() && r.wave < r.totalWaves) {
          if (r.wave == 2) {
            memory(r);
            r.diagnosticValid &= r.sequence.size() == 3;
          }
          if (r.wave == 4) {
            seals(r);
            r.diagnosticValid &= r.stage == Stage.SEALS;
          }
          if (r.wave == 2 || r.wave == 4) {
            r.diagnosticValid &=
                worldAt(r, 0, 1, DungeonLayout.roomZ(r.room) - 20).getBlock().getType()
                    == Material.IRON_BARS;
            travel(r);
            for (int z = DungeonLayout.roomZ(r.room) - 19;
                z >= DungeonLayout.roomZ(r.room) - 40;
                z--)
              r.diagnosticValid &=
                  worldAt(r, 0, 0, z).getBlock().isPassable()
                      && worldAt(r, 0, 1, z).getBlock().isPassable()
                      && worldAt(r, 0, -1, z).getBlock().getType().isSolid();
            if (r.wave == 2) {
              startChallenge(r, true);
              r.diagnosticExtra = r.mobs.size();
              for (Enemy extra : new ArrayList<>(r.mobs)) {
                r.diagnosticValid &= extra.mob.isValid() && extra.elite;
                r.diagnosticChecked++;
                removeEnemy(extra);
              }
              completeChallenge(r);
            } else {
              rescue(r);
              takeKey(r);
            }
            enterNextRoom(r);
            if (r.room == 2) {
              sideGate(r, true);
              takeTreasure(r);
            }
          }
          beginWave(r);
        }
        if (!r.mobs.isEmpty()) {
          r.deadline = tick + 20;
          return;
        }
        int expected = r.diagnosticExtra;
        for (int wave = 1; wave <= r.totalWaves; wave++)
          expected += DungeonRules.count(wave, r.size, r.level);
        boolean valid =
            r.diagnosticValid
                && r.diagnosticChecked == expected
                && r.diagnosticKinds.size() == 4
                && r.diagnosticElite
                && r.diagnosticBoss
                && r.optionalFlags
                    == (AdventureRewards.CURSE
                        | AdventureRewards.RESCUE
                        | AdventureRewards.TREASURE)
                && r.key
                && r.room == 2
                && at(r, 0, -1, 0).getBlock().getType().isSolid()
                && at(r, -9, 0, -16).getBlock().getType() == RUNES[0];
        String diagnosticDetail =
            "checks="
                + r.diagnosticValid
                + ", count="
                + r.diagnosticChecked
                + "/"
                + expected
                + ", kinds="
                + r.diagnosticKinds
                + ", elite="
                + r.diagnosticElite
                + ", boss="
                + r.diagnosticBoss
                + ", floor="
                + at(r, 0, -1, 0).getBlock().getType()
                + ", rune="
                + at(r, -9, 0, -16).getBlock().getType();
        List<Chunk> checkedChunks =
            r.chunks.stream()
                .map(key -> plugin.mines().world().getChunkAt((int) (long) key, (int) (key >> 32)))
                .toList();
        finish(r, false, "");
        valid &=
            enemies.values().stream().noneMatch(e -> e.run == r)
                && plugin.mines().world().getEntities().stream()
                    .noneMatch(e -> inside(r, e.getLocation()))
                && checkedChunks.stream()
                    .noneMatch(c -> c.getPluginChunkTickets().contains(plugin));
        verification =
            valid
                ? "OK: level "
                    + r.level
                    + ", party "
                    + r.size
                    + ", "
                    + r.totalWaves
                    + " waves, "
                    + r.diagnosticChecked
                    + " enemies, 4 kinds, elites, boss, queued spawns, runes, healing item, 3"
                    + " connected rooms, walkable gates, optional challenge, rescue, key chest,"
                    + " cleanup, chunk tickets"
                : "FAILED: "
                    + diagnosticDetail
                    + ", remaining="
                    + plugin.mines().world().getEntities().stream()
                        .filter(e -> inside(r, e.getLocation()))
                        .map(e -> e.getType().name())
                        .toList()
                    + ", tickets="
                    + checkedChunks.stream()
                        .filter(c -> c.getPluginChunkTickets().contains(plugin))
                        .count();
      } else {
        for (Enemy e : r.mobs) e.rig.animate(e.mob.getLocation(), tick, true, false, false);
        circle(at(r, 0, 0, 0), 4, Color.RED);
        beam(at(r, -8, 0, -8), new Vector(0, 0, 1));
        circle(at(r, 8, 0, 0), 5, Color.LIME);
      }
      return;
    }
    for (UUID id : new ArrayList<>(r.members)) {
      Player p = Bukkit.getPlayer(id);
      if (p == null) {
        r.disconnected.putIfAbsent(id, tick);
        if (tick - r.disconnected.get(id) > 1200) remove(r, id);
      } else if (r.disconnected.containsKey(id)) {
        if (tick - r.disconnected.get(id) > 1200) {
          remove(r, id);
          p.hideBossBar(r.bar);
          plugin.goHome(p);
        }
      } else if (!plugin.playing(p)) {
        remove(r, id);
        p.hideBossBar(r.bar);
      } else if (!inside(r, p.getLocation())) p.teleport(checkpoint(r, r.down.contains(id)));
    }
    if (r.members.isEmpty()) {
      finish(r, false, "Gruppe aufgelöst.");
      return;
    }
    if (tick - r.started > DungeonRules.TIME_TICKS) {
      finish(r, false, "Zeitlimit erreicht. Neuer Versuch im Dungeonmenü.");
      return;
    }
    if (r.members.stream().allMatch(r.down::contains)) {
      finish(r, false, "Die Gruppe wurde besiegt. Eure Ausrüstung bleibt erhalten.");
      return;
    }
    if (living(r).isEmpty()) return;
    if (r.stage == Stage.TRAVEL) {
      int nextRoom = DungeonLayout.nextRoom(r.wave);
      if (living(r).stream()
          .allMatch(p -> DungeonLayout.arrived(nextRoom, p.getX() - r.x - .5, p.getZ() + 511.5)))
        enterNextRoom(r);
      else if (tick % 20 == 0)
        circle(worldAt(r, 0, .1, DungeonLayout.roomZ(nextRoom) + 10), 2, Color.AQUA);
    }
    if (r.stage == Stage.COUNTDOWN && tick >= r.deadline) beginWave(r);
    if (r.stage == Stage.SIDE) {
      for (Enemy e : new ArrayList<>(r.mobs)) enemyTick(e);
      if (r.mobs.isEmpty()) completeChallenge(r);
    }
    if (r.stage == Stage.WAVE) {
      for (Enemy e : new ArrayList<>(r.mobs)) enemyTick(e);
      refill(r);
      if (r.mobs.isEmpty() && r.pending == 0) {
        revive(r);
        if (r.wave == r.totalWaves) {
          finish(r, true, r.variant.title + " bezwungen!");
          return;
        }
        if (r.wave == 2) memory(r);
        else if (r.wave == 4) seals(r);
        else countdown(r);
      }
    } else if (r.stage == Stage.SEALS) {
      int needed = Math.max(1, Math.min(3, living(r).size()));
      Set<UUID> used = new HashSet<>();
      for (int i = 0; i < needed; i++) {
        Location pad = at(r, -6 + i * 6, 0, 0);
        for (Player p : living(r))
          if (!used.contains(p.getUniqueId()) && p.getLocation().distanceSquared(pad) < 2.2) {
            used.add(p.getUniqueId());
            break;
          }
        circle(pad, 1, Color.AQUA);
      }
      r.sealTicks = used.size() == needed ? r.sealTicks + 2 : 0;
      if (r.sealTicks >= 60) {
        say(r, "Siegel stabilisiert. Das Tor zum Heiligtum öffnet sich!");
        travel(r);
      }
    }
    if (tick % 20 == 0) {
      String label =
          switch (r.stage) {
            case TRAVEL ->
                "Tor offen: gemeinsam in " + r.variant.room(DungeonLayout.nextRoom(r.wave));
            case SIDE -> "Optionale Prüfung · " + r.mobs.size() + " Elitegegner";
            case MEMORY -> "Runenwand: " + r.memoryStep + "/3 · Linksklick";
            case SEALS ->
                "Siegel: auf türkisfarbene Platten stellen · " + (r.sealTicks / 20) + "/3 s";
            case COUNTDOWN -> "Nächste Welle in " + Math.max(0, (r.deadline - tick) / 20) + " s";
            default ->
                r.mobs.stream().filter(m -> m.brain != null).findFirst().map(m -> m.brain.status(tick)).orElse("Welle "
                    + r.wave
                    + "/"
                    + r.totalWaves
                    + " · Gegner "
                    + r.mobs.size()
                    + " +"
                    + r.pending);
          };
      // Sequence text stays visible only during the memory window.
      if (r.stage == Stage.MEMORY && tick < r.deadline)
        label = "Merken: " + String.join(" → ", r.sequence.stream().map(i -> NAMES[i]).toList());
      r.bar.name(
          Component.text(
              r.variant.room(r.room)
                  + " · L"
                  + r.level
                  + " · "
                  + label
                  + " · "
                  + Math.max(0, (DungeonRules.TIME_TICKS - tick + r.started) / 1200)
                  + " Min"));
      r.bar.progress(
          (float)
              Math.clamp(
                  (r.wave - 1 + (r.stage == Stage.WAVE ? 0.5 : 1)) / (double) r.totalWaves, 0, 1));
    }
  }

  private void build(Run r) {
    for (int n = 0; n < 900 && r.cursor < DungeonLayout.SIZE; n++, r.cursor++) {
      int x = r.cursor % DungeonLayout.WIDTH - 48;
      int z = 20 - r.cursor / DungeonLayout.WIDTH % DungeonLayout.LENGTH;
      int y = r.cursor / (DungeonLayout.WIDTH * DungeonLayout.LENGTH) - 1;
      Location loc = worldAt(r, x, y, z);
      var chunk = loc.getChunk();
      if (r.chunks.add(chunk.getChunkKey())) chunk.addPluginChunkTicket(plugin);
      loc.getBlock().setType(DungeonLayout.material(r.variant, r.zone, x, y, z), false);
    }
    if (r.cursor < DungeonLayout.SIZE) return;
    for (int room = 0; room < 3; room++) {
      int center = DungeonLayout.roomZ(room);
      for (int i = 0; i < 4; i++) {
        worldAt(r, -9 + i * 6, 0, center - 16).getBlock().setType(RUNES[i], false);
        worldAt(r, -9 + i * 6, -1, center - 16).getBlock().setType(Material.SEA_LANTERN, false);
      }
      for (int i = 0; i < 3; i++)
        worldAt(r, -6 + i * 6, -1, center)
            .getBlock()
            .setType(Material.WAXED_OXIDIZED_CUT_COPPER, false);
      final int index = room;
      r.decorations.add(
          plugin
              .mines()
              .world()
              .spawn(
                  worldAt(r, 0, 4, center + 16),
                  TextDisplay.class,
                  display -> {
                    display.text(Component.text(r.variant.room(index), NamedTextColor.GOLD));
                    display.setBillboard(Display.Billboard.CENTER);
                    display.setPersistent(false);
                  }));
    }
    worldAt(r, -10, 0, DungeonLayout.roomZ(1) + 11).getBlock().setType(Material.BARREL, false);
    worldAt(r, -19, 0, DungeonLayout.roomZ(2) + 4).getBlock().setType(Material.LODESTONE, false);
    r.captive =
        plugin
            .mines()
            .world()
            .spawn(
                worldAt(r, -44, 0, DungeonLayout.roomZ(1)),
                Villager.class,
                false,
                v -> {
                  v.setAI(false);
                  v.setAdult();
                  v.setInvulnerable(true);
                  v.setSilent(true);
                  v.setPersistent(false);
                  v.customName(Component.text("Gefangener Bergarbeiter", NamedTextColor.GOLD));
                  v.setCustomNameVisible(true);
                });
    r.decorations.add(r.captive);
    branchLabel(r, 0, -38, -3, "ELITEPRÜFUNG · 1 Bonusfund\nRechtsklick · Gruppenleiter startet");
    branchLabel(
        r, 0, -38, 3, "FLUCHPRÜFUNG · 2 Bonusfunde\nDoppelte Gegner-LP · nur eine Prüfung wählbar");
    branchLabel(
        r,
        1,
        -38,
        -3,
        "ZELLENSCHLOSS · Rechtsklick\nRettung: Bonusfund + dauerhafter Händlerrabatt");
    branchLabel(r, 1, -10, 11, "Verstaubtes Fass · untersuchen");
    branchLabel(r, 2, -19, 4, "SCHATZKAMMER · Schlüssel benötigt\nRechtsklick zum Öffnen");
    branchLabel(r, 2, -38, -3, "VERSIEGELTE BEUTE\nRechtsklick · Auszahlung erst nach dem Sieg");
    if (r.variant == DungeonVariant.FROSTKRYPTA)
      for (int room = 0; room < 3; room++)
        for (int side = -1; side <= 1; side += 2) {
          int bx = side * 10, local = side * 5, bz = DungeonLayout.roomZ(room) + local;
          worldAt(r, bx, 0, bz).getBlock().setType(Material.POLISHED_BLACKSTONE_WALL, false);
          worldAt(r, bx, 1, bz).getBlock().setType(Material.CAMPFIRE, false);
          r.braziers.add(worldAt(r, bx, 0, bz));
          branchLabel(r, room, bx, local, "GLUTBECKEN\nHier aufwärmen");
        }
    if (r.diagnostic) {
      r.stage = Stage.WAVE;
      Profile probeProfile = new Profile();
      probeProfile.healingCharges = 12;
      var crystal = plugin.items().healingCrystal(probeProfile);
      r.diagnosticValid &=
          crystal.getAmount() == 12
              && plugin.items().kind(crystal).equals("heal")
              && new NamespacedKey("deepforge", "healing_crystal")
                  .equals(crystal.getItemMeta().getItemModel());
      r.decorations.add(
          plugin
              .mines()
              .world()
              .spawn(
                  at(r, 0, 2, 10),
                  ItemDisplay.class,
                  display -> {
                    display.setItemStack(crystal);
                    display.setPersistent(false);
                  }));
      r.wave = 0;
      beginWave(r);
      r.deadline = tick + 20;
      return;
    }
    for (Player p : online(r)) {
      if (!plugin.playing(p)) continue;
      p.teleport(at(r, 0, 0, 12));
      plugin.combat().applyStats(p);
      p.setHealth(Gear.stats(plugin.profile(p)).health());
      p.setFoodLevel(20);
    }
    say(
        r,
        "Rote Kreise und orange Strahlen kündigen Angriffe an. Ausweichen: Sneak + Rechtsklick mit"
            + " Waffe. /df dungeon leave beendet deinen Lauf.");
    countdown(r);
  }

  private Location checkpoint(Run r, boolean down) {
    return standable(at(r, down ? 17 : 0, 0, down ? 2 : 12));
  }

  /**
   * Moves a spot up until feet and head are free. The boss hall has a raised amethyst floor in the
   * viewing alcove; downed players used to be placed inside it.
   */
  private static Location standable(Location l) {
    Location at = l.clone();
    for (int i = 0; i < 6; i++) {
      if (at.getBlock().isPassable() && at.clone().add(0, 1, 0).getBlock().isPassable()) return at;
      at.add(0, 1, 0);
    }
    return l;
  }

  private void gate(Run r, int z, boolean open) {
    for (int x = -3; x <= 3; x++)
      for (int y = 0; y < 5; y++)
        worldAt(r, x, y, z).getBlock().setType(open ? Material.AIR : Material.IRON_BARS, false);
    worldAt(r, 0, 1, z)
        .getWorld()
        .playSound(worldAt(r, 0, 1, z), Sound.BLOCK_IRON_DOOR_OPEN, 1, .6f);
  }

  private void travel(Run r) {
    r.stage = Stage.TRAVEL;
    gate(r, DungeonLayout.roomZ(r.room) - 20, true);
    gate(r, DungeonLayout.roomZ(DungeonLayout.nextRoom(r.wave)) + 20, true);
    sideGate(r, true);
    if (!r.shrinesBuilt.add(r.room)) return;
    for (int i = 0; i < 3; i++) {
      at(r, -8 + i * 8, 0, -10)
          .getBlock()
          .setType(
              new Material[] {
                    Material.RED_GLAZED_TERRACOTTA,
                    Material.BLUE_GLAZED_TERRACOTTA,
                    Material.LIME_GLAZED_TERRACOTTA
                  }
                  [i],
              false);
      final String title =
          new String[] {
                "KRAFT · +8% Schaden",
                "SCHUTZ · -8% erlittener Schaden",
                "QUELLE · 35% Leben heilen"
              }
              [i];
      r.decorations.add(
          plugin
              .mines()
              .world()
              .spawn(
                  at(r, -8 + i * 8, 2, -10),
                  TextDisplay.class,
                  display -> {
                    display.text(
                        Component.text(
                            title + "\nEin Segen pro Halle · Rechtsklick", NamedTextColor.AQUA));
                    display.setBillboard(Display.Billboard.CENTER);
                    display.setPersistent(false);
                  }));
    }
    say(r, "Das Tor ist offen! Geht gemeinsam durch die Galerie zur nächsten Halle.");
    say(r, "Die drei Runenschreine sind aktiv: Jeder darf einen Segen für diesen Lauf wählen.");
  }

  private void branchLabel(Run r, int room, int x, int z, String text) {
    r.decorations.add(
        plugin
            .mines()
            .world()
            .spawn(
                worldAt(r, x, 2.5, DungeonLayout.roomZ(room) + z),
                TextDisplay.class,
                d -> {
                  d.text(Component.text(text, NamedTextColor.GOLD));
                  d.setBillboard(Display.Billboard.CENTER);
                  d.setPersistent(false);
                }));
  }

  private void sideGate(Run r, boolean open) {
    r.branchOpen[r.room] = open;
    for (int z = -2; z <= 2; z++)
      for (int y = 0; y < 5; y++)
        at(r, -20, y, z).getBlock().setType(open ? Material.AIR : Material.IRON_BARS, false);
  }

  private boolean optionalBlock(Run r, org.bukkit.block.Block b) {
    return b.equals(at(r, -38, 0, -3).getBlock())
        || r.room == 0 && b.equals(at(r, -38, 0, 3).getBlock())
        || r.room == 1 && b.equals(at(r, -10, 0, 11).getBlock())
        || r.room == 2 && b.equals(at(r, -19, 0, 4).getBlock());
  }

  private void startChallenge(Run r, boolean curse) {
    r.challengeAttempted = true;
    r.pendingOptional = curse ? AdventureRewards.CURSE : AdventureRewards.ELITE;
    r.stage = Stage.SIDE;
    gate(r, DungeonLayout.roomZ(r.room) - 20, false);
    gate(r, DungeonLayout.roomZ(r.room + 1) + 20, false);
    for (int i = 0; i < r.size + 2; i++) {
      spawn(r, false, i % 4, -34 - i % 3 * 3, -6 + i * 2);
      Enemy e = r.mobs.getLast();
      e.elite = true;
      e.hp =
          e.max =
              DungeonRules.health(r.zone, r.mode, r.size, r.wave, false, r.level)
                  * (curse ? 2 : 1.4);
      e.mob.customName(Component.text(enemyName(e), NamedTextColor.RED));
      health(e);
    }
    say(
        r,
        curse
            ? "Fluchprüfung gestartet! Besiegt die Elite für zwei Bonusfunde."
            : "Eliteprüfung gestartet! Besiegt die Elite für einen Bonusfund.");
  }

  private void completeChallenge(Run r) {
    r.optionalFlags |= r.pendingOptional;
    r.pendingOptional = 0;
    revive(r);
    travel(r);
    say(r, "Prüfung bestanden! Die Beute wird nach dem Endboss ausgezahlt.");
  }

  private void rescue(Run r) {
    if ((r.optionalFlags & AdventureRewards.RESCUE) != 0) return;
    for (int z = -1; z <= 1; z++)
      for (int y = 0; y < 3; y++) at(r, -42, y, z).getBlock().setType(Material.AIR, false);
    r.captive.teleport(at(r, -40, 0, 0));
    r.captive.customName(Component.text("Bergarbeiter gerettet!", NamedTextColor.GREEN));
    r.optionalFlags |= AdventureRewards.RESCUE;
    say(r, "Bergarbeiter befreit! Bei Abschluss: Bonusfund und dauerhaft 20% Händlerrabatt.");
  }

  private void takeKey(Run r) {
    r.key = true;
    at(r, -10, 0, 11).getBlock().setType(Material.AIR, false);
    say(r, "Gruppenschlüssel gefunden! Er öffnet die Schatzkammer in der letzten Halle.");
  }

  private void takeTreasure(Run r) {
    if (!r.key || (r.optionalFlags & AdventureRewards.TREASURE) != 0) return;
    r.optionalFlags |= AdventureRewards.TREASURE;
    at(r, -38, 0, -3).getBlock().setType(Material.BARREL, false);
    say(r, "Schatz gesichert! Ein zusätzlicher Bonusfund wartet nach dem Endboss.");
  }

  @EventHandler
  public void captiveInteraction(PlayerInteractEntityEvent e) {
    if (runs.values().stream().anyMatch(r -> r.captive == e.getRightClicked())) {
      e.setCancelled(true);
      plugin.tell(
          e.getPlayer(), "Das Zellenschloss neben dem Käfig öffnet die Tür nach dem Siegelrätsel.");
    }
  }

  @EventHandler(priority = EventPriority.LOW)
  public void optional(PlayerInteractEvent e) {
    Player p = e.getPlayer();
    Run r = membership.get(p.getUniqueId());
    if (r == null
        || down(p)
        || e.getHand() != EquipmentSlot.HAND
        || !e.getAction().isRightClick()
        || e.getClickedBlock() == null
        || !optionalBlock(r, e.getClickedBlock())) return;
    e.setCancelled(true);
    if (p.getLocation().distanceSquared(e.getClickedBlock().getLocation()) > 36) return;
    if (r.room == 0) {
      if (r.stage != Stage.TRAVEL || r.challengeAttempted) {
        plugin.tell(p, "Diese Prüfung ist noch nicht verfügbar oder bereits gewählt.");
        return;
      }
      PartyBook.Party party = parties.get(p.getUniqueId());
      if (party != null && !party.leader.equals(p.getUniqueId())) {
        plugin.tell(p, "Nur der Gruppenleiter startet die Prüfung.");
        return;
      }
      if (living(r).stream().anyMatch(m -> Math.abs(m.getZ() - at(r, 0, 0, 0).getZ()) >= 19)) {
        plugin.tell(p, "Alle müssen zuerst in diese Halle zurückkehren.");
        return;
      }
      startChallenge(r, e.getClickedBlock().equals(at(r, -38, 0, 3).getBlock()));
    } else if (r.room == 1) {
      if (e.getClickedBlock().equals(at(r, -10, 0, 11).getBlock())) {
        if (!r.key) takeKey(r);
      } else if (r.stage == Stage.TRAVEL && r.branchOpen[1]) rescue(r);
    } else {
      if (!r.key) {
        plugin.tell(
            p,
            "Der Schlüssel liegt in der Siegelgalerie. Beim nächsten Lauf nach dem Fass suchen!");
        return;
      }
      if (e.getClickedBlock().equals(at(r, -19, 0, 4).getBlock())) {
        sideGate(r, true);
        plugin.tell(p, "Schatzkammer geöffnet!");
      } else if (r.branchOpen[2]) takeTreasure(r);
    }
  }

  private void enterNextRoom(Run r) {
    gate(r, DungeonLayout.roomZ(r.room) - 20, false);
    r.room = DungeonLayout.nextRoom(r.wave);
    gate(r, DungeonLayout.roomZ(r.room) + 20, false);
    say(r, r.variant.room(r.room) + " erreicht. Bereitet euch vor!");
    countdown(r);
  }

  private void countdown(Run r) {
    r.stage = Stage.COUNTDOWN;
    r.deadline = tick + 100;
  }

  private void beginWave(Run r) {
    r.wave++;
    r.stage = Stage.WAVE;
    r.spawned = 0;
    r.reinforcements = 0;
    r.pending = DungeonRules.count(r.wave, r.size, r.level);
    refill(r);
    say(
        r,
        r.wave == r.totalWaves
            ? "ENDWELLE · "
                + r.variant.boss(r.zone)
                + " erwacht! Drei Phasen – weiche seinen Angriffen aus und schlag bei"
                + " SCHWACHSTELLE zu."
            : "Welle "
                + r.wave
                + "/"
                + r.totalWaves
                + " · "
                + DungeonRules.conditionName(r.level)
                + (r.level >= 4 ? " · Jäger lauern auf euch!" : ""));
  }

  private void refill(Run r) {
    while (r.pending > 0 && r.mobs.size() < DungeonRules.activeLimit(r.size)) {
      int ordinal = r.spawned;
      double angle = (ordinal * 2.4 + r.wave) % (Math.PI * 2);
      int kind = DungeonRules.kind(r.level, r.wave, ordinal, r.id.getLeastSignificantBits());
      spawn(
          r,
          r.wave == r.totalWaves && ordinal == 0,
          kind,
          Math.cos(angle) * 11,
          Math.sin(angle) * 10);
      r.pending--;
      r.spawned++;
    }
  }

  private void spawn(Run r, boolean boss, int kind, double x, double z) {
    Enemy e = new Enemy();
    e.run = r;
    e.boss = boss;
    e.kind = kind;
    e.elite = !boss && DungeonRules.elite(r.level, r.spawned);
    e.hp =
        e.max =
            DungeonRules.health(r.zone, r.mode, r.size, r.wave, boss, r.level)
                * (e.elite ? 1.6 : 1);
    e.attackAt = tick + 50 + random.nextInt(40);
    e.mob =
        plugin
            .mines()
            .world()
            .spawn(
                at(r, x, 0, z),
                Husk.class,
                false,
                mob -> {
                  mob.setAdult();
                  mob.getEquipment().clear();
                  mob.setPersistent(false);
                  mob.setSilent(true);
                  mob.setInvisible(true);
                  mob.setShouldBurnInDay(false);
                  mob.setRemoveWhenFarAway(false);
                  mob.setCanPickupItems(false);
                  mob.getAttribute(Attribute.MOVEMENT_SPEED)
                      .setBaseValue(
                          (boss ? .24 : kind == 3 ? .34 : .28)
                              * (DungeonRules.condition(r.level) == 1 ? 1.1 : 1));
                  mob.getAttribute(Attribute.SCALE).setBaseValue(boss ? 1.55 : kind == 1 ? 1 : .8);
                  mob.getAttribute(Attribute.KNOCKBACK_RESISTANCE).setBaseValue(0);
                  mob.customName(
                      Component.text(enemyName(e) + " · L" + r.level, NamedTextColor.RED));
                  mob.setCustomNameVisible(false);
                });
    r.mobs.add(e);
    enemies.put(e.mob.getUniqueId(), e);
    RailNavigation.allowRails(e.mob);
    e.rig = new MonsterRig(plugin, e.mob.getLocation(), (r.zone + kind) % 7, boss, kind);
    e.health = new MonsterHealthIndicator(plugin, e.mob.getLocation(), r.members, boss);
    health(e);
  }

  private void health(Enemy e) {
    if (e.health != null)
      e.health.update(
          e.mob.getLocation(),
          e.rig.labelHeight(),
          enemyName(e) + " · L" + e.run.level,
          e.hp,
          e.max,
          e.boss);
  }

  private String enemyName(Enemy e) {
    return (e.elite ? "ELITE · " : "")
        + (e.boss
            ? e.run.variant.boss(e.run.zone)
            : switch (e.kind) {
              case 0 -> "Sprenger";
              case 1 -> "Strahlenwirker";
              case 2 -> "Heilrufer";
              default -> "Rissjäger";
            });
  }

  private void enemyTick(Enemy e) {
    Run r = e.run;
    health(e);
    if (!e.mob.isValid()) throw new IllegalStateException("Dungeon enemy disappeared");
    List<Player> targets = living(r);
    if (targets.isEmpty()) return;
    Player target =
        targets.stream()
            .min(
                Comparator.comparingDouble(
                    p -> p.getLocation().distanceSquared(e.mob.getLocation())))
            .orElseThrow();
    if (e.boss && r.level >= 6) {
      int phase = e.hp < e.max * .33 ? 2 : e.hp < e.max * .66 ? 1 : 0;
      if (phase > r.reinforcements) {
        r.pending += (phase - r.reinforcements) * (1 + r.size);
        r.reinforcements = phase;
        say(r, "Der Wächter ruft Verstärkung! Noch " + r.pending + " Gegner im Anmarsch.");
      }
    }
    if (e.elite && tick % 10 == 0)
      e.mob
          .getWorld()
          .spawnParticle(Particle.ENCHANT, e.mob.getLocation().add(0, 1.5, 0), 5, .4, .6, .4, 0);
    if (!inside(r, e.mob.getLocation())
        || Math.abs(e.mob.getZ() - at(r, 0, 0, 0).getZ()) > 19
        || e.mob.getX() > r.x + 15) e.mob.teleport(at(r, 0, 0, -8));
    e.mob.setTarget(target);
    if (e.boss && (e.brain == null || !e.brain.busy()) && rearCounter(e, targets)) return;
    if (e.boss) {
      if (e.brain == null) {
        e.brain = new BossBrain(arena(r), e.mob, tick);
        r.bossFought = true;
        say(
            r,
            "ENDBOSS: "
                + e.brain.name()
                + "! Achte auf die Warnungen – seinen Angriffen musst du ausweichen (Sneak +"
                + " Rechtsklick = Rolle).");
      }
      e.brain.tick(tick, e.hp, e.max);
      r.bossStruck.addAll(e.brain.struck);
      e.mob.setAware(!e.brain.busy() && tick >= e.recoilAt);
      e.rig.animate(
          e.mob.getLocation(),
          tick,
          e.brain.busy(),
          tick < e.recoilAt,
          e.mob.getVelocity().lengthSquared() > .001);
      if (tick % 30 == 0 && target.getLocation().distanceSquared(e.mob.getLocation()) < 3.5)
        hurt(r, target, DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * .7);
      return;
    }
    e.mob.setAware(e.resolveAt == 0 && tick >= e.recoilAt);
    e.rig.animate(
        e.mob.getLocation(),
        tick,
        e.resolveAt > 0,
        tick < e.recoilAt,
        e.mob.getVelocity().lengthSquared() > .001);
    if (e.resolveAt > 0) {
      if (e.spell == 0) circle(e.marker, e.boss ? 4 : 2.7, Color.RED);
      else if (e.spell == 1 || e.spell == 3) beam(e.marker, e.direction, e.spell == 3 ? 7 : 18);
      else circle(e.marker, 5, Color.LIME);
      if (e.secondary != null) circle(e.secondary, 2.7, Color.RED);
      if (tick >= e.resolveAt) {
        for (Player p : targets) {
          Vector d = p.getLocation().toVector().subtract(e.marker.toVector());
          boolean hit =
              e.spell == 0
                  ? d.clone().setY(0).lengthSquared() <= (e.boss ? 16 : 7.29)
                  : (e.spell == 1 || e.spell == 3)
                      && d.dot(e.direction) >= 0
                      && d.dot(e.direction) < (e.spell == 3 ? 7 : 18)
                      && Math.abs(d.getX() * e.direction.getZ() - d.getZ() * e.direction.getX())
                          < 1.2;
          if ((e.spell == 1 || e.spell == 3) && !p.hasLineOfSight(e.mob)) hit = false;
          if (e.secondary != null
              && p.getLocation().toVector().subtract(e.secondary.toVector()).setY(0).lengthSquared()
                  <= 7.29) hit = true;
          if (hit)
            hurt(
                r,
                p,
                DungeonRules.damage(r.zone, r.mode, e.boss, r.level, r.size)
                    * (e.elite ? 1.25 : 1));
        }
        if (e.spell == 3) KnockbackMotion.push(e.mob, e.direction.clone().multiply(4));
        if (e.spell == 2)
          for (Enemy ally : r.mobs)
            if (ally != e && ally.mob.getLocation().distanceSquared(e.marker) < 25) {
              ally.hp = Math.min(ally.max, ally.hp + ally.max * .12);
              health(ally);
            }
        e.resolveAt = 0;
        e.secondary = null;
        e.attackAt = tick + DungeonRules.recovery(r.level, e.boss && e.hp < e.max * .5);
      }
    } else if (tick >= e.attackAt) {
      e.spell = e.boss ? (e.spell + 1) % 3 : e.kind;
      e.marker = e.spell == 0 ? target.getLocation().clone() : e.mob.getLocation().clone();
      e.direction = target.getLocation().toVector().subtract(e.marker.toVector()).setY(0);
      if (e.direction.lengthSquared() < .001) e.direction = new Vector(0, 0, 1);
      else e.direction.normalize();
      if (e.boss && e.spell == 0 && DungeonRules.condition(r.level) == 3) {
        e.secondary =
            targets.size() > 1
                ? targets.get((targets.indexOf(target) + 1) % targets.size()).getLocation().clone()
                : target.getLocation().clone().add(target.getX() > r.x ? -4 : 4, 0, 0);
      }
      e.resolveAt = tick + DungeonRules.warning(r.level, e.boss && e.hp < e.max * .5);
      Vector aim = target.getLocation().toVector().subtract(e.mob.getLocation().toVector()).setY(0);
      if (aim.lengthSquared() > .001)
        e.mob.setRotation(e.mob.getLocation().setDirection(aim).getYaw(), 0);
      e.mob
          .getWorld()
          .playSound(
              e.mob.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, .5f, e.spell == 2 ? 1.5f : .6f);
    }
    // Contact pressure is independently rate limited by CombatEngine's hurt protection.
    if (tick % 30 == 0 && target.getLocation().distanceSquared(e.mob.getLocation()) < 3.5)
      hurt(
          r,
          target,
          DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * .7 * (e.elite ? 1.25 : 1));
  }

  private BossBrain.Arena arena(Run r) {
    return new BossBrain.Arena() {
      public List<Player> living() {
        return Dungeons.this.living(r);
      }

      public void hurt(Player p, double damage) {
        Dungeons.this.hurt(r, p, damage);
      }

      public void say(String text) {
        Dungeons.this.say(r, text);
      }

      public Location center() {
        return at(r, 0, 0, 0);
      }

      public double baseDamage() {
        return DungeonRules.damage(r.zone, r.mode, true, r.level, r.size);
      }

      public int zone() {
        return r.zone;
      }

      public int variant() {
        return r.variant.ordinal();
      }

      public int level() {
        return r.level;
      }

      public long seed() {
        return r.id.getMostSignificantBits();
      }

      public void danger(Player p, BossPatterns.Attack attack) {
        plugin.drones().danger(p, attack.title);
      }
    };
  }

  /** Admin test: skip straight to the final wave with the boss. */
  public String debugBoss(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || r.stage == Stage.BUILDING || r.stage == Stage.COMPLETE)
      return "Zuerst einen Dungeon starten (/df dungeon start).";
    for (Enemy e : new ArrayList<>(r.mobs)) removeEnemy(e);
    r.pending = 0;
    r.room = 2;
    r.wave = r.totalWaves - 1;
    for (Player m : online(r)) m.teleport(at(r, 0, 0, 8));
    beginWave(r);
    return "Testmodus: Endboss gestartet.";
  }

  /** Drone turret: hits the nearest enemy of the owner's run; returns where it hit. */
  public Location droneShot(Player p, double damage) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || down(p)) return null;
    Enemy best = null;
    double bestDistance = 144;
    for (Enemy e : r.mobs) {
      if (e.hp <= 0 || !e.mob.isValid()) continue;
      double d = e.mob.getLocation().distanceSquared(p.getLocation());
      if (d < bestDistance) {
        bestDistance = d;
        best = e;
      }
    }
    if (best == null) return null;
    Location at = best.mob.getLocation().add(0, best.boss ? 1.8 : 1, 0);
    strike(best, p, damage, false);
    return at;
  }

  private boolean rearCounter(Enemy e, List<Player> targets) {
    BossPressure.Step step = e.pressure.step(tick, e.resolveAt == 0);
    if (step == BossPressure.Step.NONE) return false;
    e.mob.setAware(false);
    e.mob.setVelocity(new Vector());
    e.attackAt = Math.max(e.attackAt, tick + 20);
    if (step == BossPressure.Step.START) {
      e.sweepOrigin = e.mob.getLocation().clone();
      say(e.run, "RUNDUMSCHLAG! Raus aus dem roten Kreis – auch hinter dem Wächter!");
      e.mob.getWorld().playSound(e.sweepOrigin, Sound.BLOCK_NOTE_BLOCK_BASS, 1, .5f);
    }
    circle(e.sweepOrigin, BossPressure.RADIUS, Color.RED);
    e.rig.animate(e.mob.getLocation(), tick, true, false, false);
    if (step == BossPressure.Step.STRIKE) {
      for (Player p : targets) {
        Vector d = p.getLocation().toVector().subtract(e.sweepOrigin.toVector());
        if (BossPressure.inSweep(d.getX(), d.getY(), d.getZ()) && e.mob.hasLineOfSight(p))
          hurt(
              e.run,
              p,
              DungeonRules.damage(e.run.zone, e.run.mode, true, e.run.level, e.run.size) * 1.35);
      }
      e.mob
          .getWorld()
          .spawnParticle(
              Particle.SWEEP_ATTACK, e.sweepOrigin.clone().add(0, 1, 0), 14, 2, .4, 2, 0);
      e.mob.getWorld().playSound(e.sweepOrigin, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1, .6f);
      e.sweepOrigin = null;
    }
    return true;
  }

  /** The dungeon's own hazard: Glutschmiede eruptions or Frostkrypta cold. */
  private void hazard(Run r) {
    switch (r.variant) {
      case GLUTSCHMIEDE -> embers(r);
      case FROSTKRYPTA -> cold(r);
      default -> {}
    }
  }

  /** Glowing floor spots under every player (plus a few random ones) that erupt shortly after. */
  private void embers(Run r) {
    if (r.stage != Stage.WAVE) {
      r.eruptSpots.clear();
      r.eruptNext = 0;
      return;
    }
    if (r.eruptNext == 0) r.eruptNext = tick + 100;
    if (r.eruptSpots.isEmpty()) {
      if (tick < r.eruptNext) return;
      List<Player> targets = living(r);
      if (targets.isEmpty()) return;
      for (Player p : targets) {
        Location l = p.getLocation().clone();
        l.setY(65);
        r.eruptSpots.add(l);
      }
      int extra = DungeonVariant.eruptions(targets.size(), r.mode) - targets.size();
      for (int i = 0; i < extra; i++)
        r.eruptSpots.add(at(r, -16 + random.nextDouble() * 32, 0, -16 + random.nextDouble() * 32));
      r.eruptLand = tick + DungeonVariant.ERUPT_WARNING;
      // During the boss fight the floor erupts half as often, next to the boss attacks.
      boolean boss = r.mobs.stream().anyMatch(e -> e.boss);
      r.eruptNext = tick + DungeonVariant.eruptionInterval(r.mode, r.level) * (boss ? 2L : 1L);
      for (Player p : targets) p.playSound(p.getLocation(), Sound.BLOCK_LAVA_POP, 1, .7f);
      return;
    }
    if (tick < r.eruptLand) {
      if (tick % 4 == 0)
        for (Location l : r.eruptSpots) {
          circle(l, DungeonVariant.ERUPT_RADIUS, Color.ORANGE);
          circle(l, DungeonVariant.ERUPT_RADIUS * .5, Color.RED);
          l.getWorld().spawnParticle(Particle.LAVA, l, 1, .8, 0, .8, 0);
        }
      return;
    }
    double damage = DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * 1.3;
    for (Location l : r.eruptSpots) {
      l.getWorld().spawnParticle(Particle.FLAME, l.clone().add(0, .5, 0), 30, .9, .8, .9, .04);
      l.getWorld().spawnParticle(Particle.LAVA, l, 8, .8, .2, .8, 0);
      l.getWorld().playSound(l, Sound.ENTITY_BLAZE_SHOOT, .8f, .6f);
    }
    for (Player p : living(r)) {
      Location at = p.getLocation();
      for (Location l : r.eruptSpots)
        if (DungeonVariant.inEruption(at.getX() - l.getX(), at.getZ() - l.getZ())) {
          hurt(r, p, damage);
          p.setFireTicks(30);
          break;
        }
    }
    r.eruptSpots.clear();
  }

  /** Frost stacks while fighting; the braziers in every hall warm you up again. */
  private void cold(Run r) {
    if (tick < r.frostNext) return;
    r.frostNext = tick + DungeonVariant.frostInterval(r.mode);
    boolean fighting = r.stage == Stage.WAVE || r.stage == Stage.SIDE;
    double reach = DungeonVariant.BRAZIER_RADIUS * DungeonVariant.BRAZIER_RADIUS;
    for (Player p : online(r)) {
      UUID id = p.getUniqueId();
      int before = r.frost.getOrDefault(id, 0);
      boolean warm =
          r.braziers.stream()
              .anyMatch(
                  b -> b.getWorld().equals(p.getWorld()) && b.distanceSquared(p.getLocation()) <= reach);
      int now =
          fighting && !r.down.contains(id)
              ? DungeonVariant.frost(before, warm)
              : Math.max(0, before - 2);
      if (DungeonVariant.frozen(now)) {
        hurt(r, p, DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * 1.5);
        p.getWorld()
            .spawnParticle(Particle.SNOWFLAKE, p.getLocation().add(0, 1, 0), 30, .4, .6, .4, .02);
        p.playSound(p.getLocation(), Sound.BLOCK_GLASS_BREAK, 1, .6f);
        frostTitle(p, "❄ Eingefroren! Ab zu einem Glutbecken!");
        now = DungeonVariant.FROST_AFTER_FREEZE;
      } else if (now >= DungeonVariant.FROST_SLOW && before < DungeonVariant.FROST_SLOW)
        frostTitle(p, "❄ Dir wird kalt – wärm dich am Glutbecken auf");
      if (warm && now < before)
        p.getWorld().spawnParticle(Particle.FLAME, p.getLocation().add(0, .2, 0), 4, .3, .1, .3, 0);
      r.frost.put(id, now);
      p.lockFreezeTicks(true);
      // Vanilla freeze damage starts at 140 ticks; 13 per stack keeps it purely visual.
      p.setFreezeTicks(now * 13);
      if (now >= DungeonVariant.FROST_SLOW)
        p.addPotionEffect(
            new org.bukkit.potion.PotionEffect(
                org.bukkit.potion.PotionEffectType.SLOWNESS,
                DungeonVariant.frostInterval(r.mode) + 10,
                0,
                false,
                false,
                true));
    }
  }

  private void frostTitle(Player p, String text) {
    p.showTitle(
        net.kyori.adventure.title.Title.title(
            Component.empty(),
            Component.text(text, NamedTextColor.AQUA),
            net.kyori.adventure.title.Title.Times.times(
                java.time.Duration.ZERO,
                java.time.Duration.ofMillis(1500),
                java.time.Duration.ofMillis(400))));
  }

  private static void thaw(Player p) {
    p.lockFreezeTicks(false);
    p.setFreezeTicks(0);
  }

  private void circle(Location l, double radius, Color color) {
    for (int i = 0; i < 18; i++) {
      double a = i * Math.PI / 9;
      l.getWorld()
          .spawnParticle(
              Particle.DUST,
              l.clone().add(Math.cos(a) * radius, .15, Math.sin(a) * radius),
              1,
              0,
              0,
              0,
              0,
              new Particle.DustOptions(color, 1.2f));
    }
  }

  private void beam(Location l, Vector direction) {
    beam(l, direction, 18);
  }

  private void beam(Location l, Vector direction, int length) {
    for (int i = 0; i < length; i++)
      l.getWorld()
          .spawnParticle(
              Particle.DUST,
              l.clone().add(direction.clone().multiply(i)).add(0, .3, 0),
              1,
              .12,
              0,
              .12,
              0,
              new Particle.DustOptions(Color.ORANGE, 1.5f));
  }

  private void hurt(Run r, Player p, double amount) {
    if (r.down.contains(p.getUniqueId())) return;
    plugin
        .combat()
        .dungeonDamage(
            p,
            amount * r.blessings.incoming(p.getUniqueId()),
            () -> {
              r.down.add(p.getUniqueId());
              p.setHealth(Math.min(Gear.stats(plugin.profile(p)).health(), 4));
              p.teleport(checkpoint(r, true));
              say(r, p.getName() + " wurde besiegt. Überlebt die Phase für seine Rückkehr!");
            });
  }

  private void revive(Run r) {
    for (Player p : online(r)) {
      if (!plugin.playing(p) || p.isDead()) continue;
      plugin.combat().applyStats(p);
      boolean revived = r.down.remove(p.getUniqueId());
      double max = Gear.stats(plugin.profile(p)).health();
      p.setHealth(revived ? max * .5 : Math.min(max, p.getHealth() + max * .15));
      if (revived) p.teleport(checkpoint(r, false));
    }
    r.down.clear();
  }

  @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
  public void hit(EntityDamageByEntityEvent event) {
    Enemy source = enemies.get(event.getDamager().getUniqueId());
    if (source != null) {
      event.setCancelled(true);
      return;
    }
    Enemy e = enemies.get(event.getEntity().getUniqueId());
    if (e == null) return;
    event.setCancelled(true);
    if (!(event.getDamager() instanceof Player p)
        || membership.get(p.getUniqueId()) != e.run
        || down(p)
        || !plugin.items().kind(p.getInventory().getItemInMainHand()).equals("sword")
        || !p.hasLineOfSight(e.mob)
        || p.getLocation().distanceSquared(e.mob.getLocation()) > 25) return;
    long now = Bukkit.getCurrentTick();
    if (clicks.getOrDefault(p.getUniqueId(), -1L) == now) return;
    clicks.put(p.getUniqueId(), now);
    strike(e, p, RapidCombat.damage(Gear.stats(plugin.profile(p))));
  }

  private void strike(Enemy e, Player p, double damage) {
    strike(e, p, damage, true);
  }

  private void strike(Enemy e, Player p, double damage, boolean procAllowed) {
    if (e.hp <= 0) return;
    if (e.brain != null && e.brain.immune(tick)) {
      plugin.combat().showDamage(p, e.mob.getLocation().add(0, 3.4, 0), 0, false, false, true);
      p.playSound(p.getLocation(), Sound.ITEM_SHIELD_BLOCK, .6f, 1.4f);
      return;
    }
    if (e.brain != null) damage *= e.brain.damageTaken(tick);
    ArtifactCombat.Proc proc =
        procAllowed
            ? plugin.adventure().hit(p, e.mob.getUniqueId())
            : new ArtifactCombat.Proc(false, false);
    if (plugin.adventure().fractured(e.mob.getUniqueId())) damage *= 1.15;
    damage *= e.run.blessings.damage(p.getUniqueId());
    Gear.Stats stats = Gear.stats(plugin.profile(p));
    Gear.Item weapon = Gear.equipped(plugin.profile(p), Gear.Slot.WEAPON);
    String style = weapon == null ? "sword" : weapon.style;
    Vector delta = p.getLocation().toVector().subtract(e.mob.getLocation().toVector());
    Vector facing = e.mob.getLocation().getDirection();
    double alignment = WeaponRules.facing(delta.getX(), delta.getZ(), facing.getX(), facing.getZ());
    if (e.boss) e.pressure.hit(tick, alignment, delta.clone().setY(0).lengthSquared());
    boolean backstab = style.equals("dagger") && alignment <= -.5;
    damage *= WeaponRules.multiplier(style, WeaponRules.rearBonus(weapon), false, false, alignment);
    boolean crit = random.nextDouble() < stats.crit();
    if (crit) damage *= stats.critDamage();
    double dealt = Math.min(e.hp, damage);
    e.hp -= dealt;
    health(e);
    e.rig.hurt(tick);
    plugin
        .combat()
        .showDamage(
            p, e.mob.getLocation().add(0, e.boss ? 3.4 : 2, 0), dealt, crit, backstab, false);
    p.playSound(
        p.getLocation(),
        crit ? Sound.ENTITY_PLAYER_ATTACK_CRIT : Sound.ENTITY_PLAYER_ATTACK_STRONG,
        .65f,
        1.2f);
    if (tick >= e.recoilAt + 8 && e.sweepOrigin == null) {
      Vector away = e.mob.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
      if (away.lengthSquared() > .01)
        e.mob.setVelocity(
            away.normalize().multiply(HitFeedback.knockback(style, e.boss, false)).setY(.18));
      e.recoilAt = tick + (e.boss ? 2 : 5);
    }
    if (proc.lightning()) {
      Location origin = e.mob.getLocation().add(0, 1, 0);
      for (Enemy other :
          e.run.mobs.stream()
              .filter(
                  v ->
                      v != e
                          && v.hp > 0
                          && v.mob.getLocation().distanceSquared(origin) < 36
                          && e.mob.hasLineOfSight(v.mob))
              .limit(3)
              .toList()) {
        plugin.adventure().arc(p, origin, other.mob.getLocation().add(0, 1, 0));
        strike(other, p, plugin.adventure().arcDamage(p), false);
      }
    }
    if (proc.fracture())
      plugin.tell(p, "Runenhammer: Ziel 4 Sekunden lang verwundbar (+15% Schaden)!");
    if (e.hp <= 0) {
      plugin.adventure().kill(p, e.mob.getLocation());
      if (!e.boss && random.nextDouble() < (e.elite ? .4 : .12)) {
        living(e.run).stream()
            .filter(
                member ->
                    e.run.healingDrops.getOrDefault(member.getUniqueId(), 0) < 3
                        && plugin.profile(member).healingCharges < Healing.CAPACITY)
            .min(Comparator.comparingInt(member -> plugin.profile(member).healingCharges))
            .ifPresent(
                member -> {
                  e.run.healingDrops.merge(member.getUniqueId(), 1, Integer::sum);
                  plugin.healing().found(member, 1);
                });
      }
      removeEnemy(e);
    }
  }

  public void ability(Player p, String style, Vector facing) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || down(p)) return;
    for (Enemy e : new ArrayList<>(r.mobs)) {
      Vector d = e.mob.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
      double length = d.length();
      boolean hit =
          style.equals("crossbow")
              ? length < 13 && (length < .1 || d.clone().normalize().dot(facing) > .96)
              : style.equals("spear")
                  ? length < 8 && (length < .1 || d.clone().normalize().dot(facing) > .8)
                  : length < 4;
      double bonus =
          style.equals("hammer") && Gear.hasEffect(plugin.profile(p), 4)
              ? 1.35
              : style.equals("spear") && Gear.hasEffect(plugin.profile(p), 3) ? 1.4 : 1;
      if (hit && p.hasLineOfSight(e.mob))
        strike(
            e,
            p,
            Gear.stats(plugin.profile(p)).damage() * (style.equals("hammer") ? 2.1 : 1.5) * bonus);
    }
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void damage(EntityDamageEvent e) {
    if (enemies.containsKey(e.getEntity().getUniqueId())) e.setCancelled(true);
    if (e.getEntity() instanceof Player p && active(p)) e.setCancelled(true);
  }

  @EventHandler
  public void targeting(EntityTargetLivingEntityEvent e) {
    Enemy enemy = enemies.get(e.getEntity().getUniqueId());
    if (enemy != null
        && e.getTarget() != null
        && (!(e.getTarget() instanceof Player p)
            || membership.get(p.getUniqueId()) != enemy.run
            || down(p))) e.setCancelled(true);
  }

  @EventHandler
  public void died(PlayerDeathEvent e) {
    Run r = membership.get(e.getEntity().getUniqueId());
    if (r == null) return;
    r.down.add(e.getEntity().getUniqueId());
    e.setKeepInventory(true);
    e.getDrops().clear();
    e.setKeepLevel(true);
    e.setDroppedExp(0);
  }

  public Location respawnLocation(Player p) {
    Run r = membership.get(p.getUniqueId());
    return r == null ? null : checkpoint(r, r.down.contains(p.getUniqueId()));
  }

  private void memory(Run r) {
    r.stage = Stage.MEMORY;
    r.sequence = DungeonRules.sequence(r.id, 0);
    r.memoryStep = 0;
    r.deadline = tick + 160;
    say(
        r,
        "Runenrätsel: Merkt euch die drei Farben oben. Danach die farbigen Blöcke an der Nordwand"
            + " in dieser Reihenfolge LINKSKLICKEN. /df dungeon hint wiederholt den Hinweis.");
  }

  private void seals(Run r) {
    r.stage = Stage.SEALS;
    r.sealTicks = 0;
    say(
        r,
        "Siegelrätsel: Besetzt die leuchtenden Bodenplatten gleichzeitig für 3 Sekunden. Solo"
            + " reicht die linke Platte, zu zweit die linken zwei, ab drei alle drei.");
  }

  @EventHandler(priority = EventPriority.LOW)
  public void shrine(PlayerInteractEvent e) {
    Player p = e.getPlayer();
    Run r = membership.get(p.getUniqueId());
    if (r == null
        || r.stage != Stage.TRAVEL
        || down(p)
        || e.getHand() != EquipmentSlot.HAND
        || !e.getAction().isRightClick()
        || e.getClickedBlock() == null) return;
    for (int i = 0; i < 3; i++)
      if (e.getClickedBlock().equals(at(r, -8 + i * 8, 0, -10).getBlock())) {
        e.setCancelled(true);
        if (p.getLocation().distanceSquared(e.getClickedBlock().getLocation()) > 36) return;
        double max = Gear.stats(plugin.profile(p)).health();
        if (i == 2 && p.getHealth() >= max) {
          plugin.tell(p, "Du bist bereits vollständig geheilt. Wähle Kraft oder Schutz.");
          return;
        }
        if (!r.blessings.choose(p.getUniqueId(), r.room, i)) {
          plugin.tell(p, "Du hast den Segen dieser Halle bereits gewählt.");
          return;
        }
        if (i == 2) p.setHealth(Math.min(max, p.getHealth() + max * .35));
        plugin.tell(
            p,
            new String[] {
                  "Kraftsegen: +8% Schaden für diesen Lauf.",
                  "Schutzsegen: -8% erlittener Schaden für diesen Lauf.",
                  "Die Quelle heilt 35% deines maximalen Lebens."
                }
                [i]);
        p.playSound(p.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1, 1.2f);
        return;
      }
  }

  @EventHandler(priority = EventPriority.LOW)
  public void puzzle(PlayerInteractEvent e) {
    Player p = e.getPlayer();
    Run r = membership.get(p.getUniqueId());
    if (r == null
        || r.stage != Stage.MEMORY
        || e.getClickedBlock() == null
        || down(p)
        || e.getHand() != EquipmentSlot.HAND) return;
    if (!e.getAction().isLeftClick()) return;
    for (int i = 0; i < 4; i++)
      if (e.getClickedBlock().equals(at(r, -9 + i * 6, 0, -16).getBlock())) {
        e.setCancelled(true);
        if (tick < r.deadline
            || p.getLocation().distanceSquared(e.getClickedBlock().getLocation()) > 36) return;
        if (r.sequence.get(r.memoryStep) == i) {
          r.memoryStep++;
          p.getWorld()
              .playSound(
                  p.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1, .7f + r.memoryStep * .3f);
          if (r.memoryStep == 3) {
            for (Player member : online(r)) {
              Profile data = plugin.profile(member);
              data.discovered.add("tutorial/runes");
              plugin.commit(member, data);
            }
            say(r, "Runenschloss geöffnet!");
            travel(r);
          }
        } else {
          r.memoryStep = 0;
          r.mistakes++;
          r.deadline = tick + 100;
          say(r, "Falsche Rune! Die Reihenfolge wird nochmals angezeigt; die Runen entladen sich.");
          for (Player member : living(r)) hurt(r, member, 2 + r.mode);
        }
        return;
      }
  }

  @EventHandler
  public void move(PlayerMoveEvent e) {
    if (e instanceof PlayerTeleportEvent || !down(e.getPlayer()) || e.getTo() == null) return;
    Location from = e.getFrom(), to = e.getTo();
    if (from.distanceSquared(to) > .0001) {
      Location lock = from.clone();
      lock.setYaw(to.getYaw());
      lock.setPitch(to.getPitch());
      e.setTo(lock);
    }
  }

  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  public void teleport(PlayerTeleportEvent e) {
    if (e.getTo() == null) return;
    Run own = membership.get(e.getPlayer().getUniqueId());
    if (own != null
        && inside(own, e.getTo())
        && !DungeonLayout.accessible(
            own.room, own.stage == Stage.TRAVEL, e.getTo().getZ() + 511.5)) {
      e.setCancelled(true);
      return;
    }
    if (own != null
        && inside(own, e.getTo())
        && e.getTo().getX() < own.x - 19.5
        && !own.branchOpen[own.room]) {
      e.setCancelled(true);
      return;
    }
    for (Run r : runs.values())
      if (inside(r, e.getTo())
          && membership.get(e.getPlayer().getUniqueId()) != r
          && !r.watchers.contains(e.getPlayer().getUniqueId())) {
        e.setCancelled(true);
        return;
      }
  }

  public void disconnect(Player p) {
    if (watching(p)) stopWatching(p, null);
    Run r = membership.get(p.getUniqueId());
    if (r != null) {
      r.disconnected.put(p.getUniqueId(), tick);
      p.hideBossBar(r.bar);
      say(r, p.getName() + " hat 60 Sekunden zum Wiederbeitreten.");
    } else parties.leave(p.getUniqueId());
  }

  public void resume(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r == null) return;
    if (tick - r.disconnected.getOrDefault(p.getUniqueId(), tick) > 1200) {
      remove(r, p.getUniqueId());
      return;
    }
    r.disconnected.remove(p.getUniqueId());
    p.showBossBar(r.bar);
    if (r.stage != Stage.BUILDING) p.teleport(checkpoint(r, r.down.contains(p.getUniqueId())));
  }

  public void withdraw(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r == null) return;
    remove(r, p.getUniqueId());
    p.hideBossBar(r.bar);
    plugin.goHome(p);
    plugin.tell(p, "Dungeon verlassen. Keine Abschlussbeute für diesen Lauf.");
    if (r.members.isEmpty()) finish(r, false, "");
  }

  private void remove(Run r, UUID id) {
    Player gone = Bukkit.getPlayer(id);
    if (gone != null) thaw(gone);
    r.frost.remove(id);
    r.members.remove(id);
    r.down.remove(id);
    r.disconnected.remove(id);
    membership.remove(id, r);
    parties.leave(id);
    clicks.remove(id);
  }

  private void removeEnemy(Enemy e) {
    enemies.remove(e.mob.getUniqueId());
    e.run.mobs.remove(e);
    if (e.rig != null) e.rig.close();
    if (e.health != null) e.health.close();
    e.mob.remove();
  }

  private void finish(Run r, boolean win, String message) {
    if (r.ended) return;
    r.ended = true;
    try {
      Map<String, RewardDiff> gains =
          win
              ? plugin.rewardDungeon(
                  List.copyOf(r.members),
                  r.id,
                  r.zone,
                  r.mode,
                  tick - r.started,
                  r.level,
                  r.optionalFlags,
                  r.variant)
              : Map.of();
      if (!message.isBlank()) say(r, message);
      if (win)
        for (Player player : online(r)) {
          plugin.items().refresh(player, plugin.profile(player));
          RewardDiff gain = gains.get(player.getUniqueId().toString());
          if (gain == null) {
            plugin.tell(player, "Diese Belohnung hast du für diesen Lauf bereits erhalten.");
            continue;
          }
          plugin.tell(player, "━━━━━━━ DUNGEON-BEUTE ━━━━━━━");
          for (String line : gain.lines()) plugin.tell(player, "  " + line);
          if (r.bossFought && !r.bossStruck.contains(player.getUniqueId())) {
            long bonus = DungeonRules.coins(r.zone, r.mode, r.level) / 4;
            plugin.change(
                player,
                data -> {
                  data.money += bonus;
                  data.lifetimeRevenue += bonus;
                  data.flawlessBosses++;
                  return "  MAKELLOS! Keinem großen Bossangriff getroffen: +" + bonus + " $";
                });
          }
          plugin.tell(player, "Alles ansehen: /df reward · Ausrüsten: /df loot");
          plugin.tell(
              player,
              "Bonus: bis zu 3 Gewölbekisten für diesen Sieg kaufen (erste "
                  + Hud.money(LootChests.price(plugin.profile(player)))
                  + ") – /df reward");
          player.showTitle(
              net.kyori.adventure.title.Title.title(
                  net.kyori.adventure.text.Component.text(
                      "SIEG!", net.kyori.adventure.text.format.NamedTextColor.GOLD),
                  net.kyori.adventure.text.Component.text(
                      gain.headline(), net.kyori.adventure.text.format.NamedTextColor.YELLOW)));
          player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
          UUID id = player.getUniqueId();
          // After the teleport home the reward window shows every new item with its values.
          Bukkit.getScheduler()
              .runTaskLater(
                  plugin,
                  () -> {
                    Player back = Bukkit.getPlayer(id);
                    if (back != null && plugin.playing(back) && !active(back))
                      plugin.menus().open(back, "reward");
                  },
                  50);
        }
    } finally {
      r.stage = Stage.COMPLETE;
      for (UUID id : new ArrayList<>(r.watchers)) {
        Player w = Bukkit.getPlayer(id);
        if (w != null)
          stopWatching(w, win ? "Der Lauf ist vorbei – Sieg!" : "Der Lauf ist vorbei.");
        else watching.remove(id, r);
      }
      r.watchers.clear();
      for (Enemy e : new ArrayList<>(r.mobs)) removeEnemy(e);
      r.decorations.forEach(Entity::remove);
      r.decorations.clear();
      runs.remove(r.slot, r);
      for (UUID id : new ArrayList<>(r.members)) {
        membership.remove(id, r);
        clicks.remove(id);
        Player p = Bukkit.getPlayer(id);
        if (p != null) {
          thaw(p);
          p.hideBossBar(r.bar);
          plugin.goHome(p);
        } else parties.leave(id);
      }
      for (long key : r.chunks)
        plugin
            .mines()
            .world()
            .getChunkAt((int) key, (int) (key >> 32))
            .removePluginChunkTicket(plugin);
      r.chunks.clear();
    }
  }

  // ---- Spectating ----

  public boolean watching(Player p) {
    return watching.containsKey(p.getUniqueId());
  }

  /** Watch the run of {@code target}, or the next running dungeon when no name is given. */
  public void spectate(Player p, String target) {
    if (active(p))
      throw new IllegalArgumentException("Du bist selbst im Dungeon – zuschauen geht danach.");
    if (plugin.combat().fighting(p))
      throw new IllegalArgumentException("Zuerst den Kampf beenden.");
    Run r;
    if (target != null) {
      Player t = Bukkit.getPlayerExact(target);
      r = t == null ? null : membership.get(t.getUniqueId());
      if (r == null || r.ended)
        throw new IllegalArgumentException(target + " ist gerade in keinem Dungeon.");
    } else {
      List<Run> open =
          runs.values().stream()
              .filter(x -> !x.ended)
              .sorted(Comparator.comparingInt(x -> x.slot))
              .toList();
      if (open.isEmpty()) throw new IllegalArgumentException("Gerade läuft kein Dungeon.");
      Run current = watching.get(p.getUniqueId());
      r = open.get(current == null ? 0 : (open.indexOf(current) + 1) % open.size());
    }
    watch(p, r);
  }

  /** Admin view: watch the run in instance slot {@code slot}. */
  public void watchSlot(Player p, int slot) {
    Run r = runs.get(slot);
    if (r == null || r.ended) throw new IllegalArgumentException("Dieser Lauf ist schon vorbei.");
    if (active(p)) throw new IllegalArgumentException("Du bist selbst im Dungeon.");
    watch(p, r);
  }

  private void watch(Player p, Run r) {
    UUID id = p.getUniqueId();
    Run before = watching.put(id, r);
    if (before != null) {
      before.watchers.remove(id);
      p.hideBossBar(before.bar);
    }
    r.watchers.add(id);
    p.closeInventory();
    SpectatorState.enter(p);
    p.setSpectatorTarget(null);
    p.showBossBar(r.bar);
    p.teleport(watchPoint(r));
    plugin.tell(
        p,
        "Du schaust zu: "
            + names(r)
            + " · "
            + r.variant.title
            + " · "
            + DungeonRules.MODES[r.mode]
            + ". Spieler anklicken = ihre Sicht · /df dungeon zuschauen = nächster Dungeon ·"
            + " /df dungeon leave = beenden.");
    if (before != r)
      for (Player m : online(r)) plugin.tell(m, p.getName() + " schaut euch zu.");
  }

  private Location watchPoint(Run r) {
    Location l = at(r, 0, 7, 16);
    l.setPitch(25);
    return l;
  }

  private String names(Run r) {
    return r.members.stream().map(this::name).reduce((a, b) -> a + ", " + b).orElse("?");
  }

  public void stopWatching(Player p, String message) {
    Run r = watching.remove(p.getUniqueId());
    if (r == null) return;
    r.watchers.remove(p.getUniqueId());
    p.hideBossBar(r.bar);
    if (p.getGameMode() == GameMode.SPECTATOR) p.setSpectatorTarget(null);
    SpectatorState.restore(p);
    if (message != null) plugin.tell(p, message);
  }

  /** Watchers stay inside the dungeon they watch. */
  private void keepWatchers() {
    for (Map.Entry<UUID, Run> w : new ArrayList<>(watching.entrySet())) {
      Player p = Bukkit.getPlayer(w.getKey());
      Run r = w.getValue();
      if (p == null) {
        watching.remove(w.getKey());
        r.watchers.remove(w.getKey());
        continue;
      }
      if (p.getGameMode() != GameMode.SPECTATOR) {
        // Someone changed the gamemode by hand: treat it as leaving.
        stopWatching(p, "Zuschauen beendet.");
        continue;
      }
      if (p.getSpectatorTarget() == null && !inside(r, p.getLocation()))
        p.teleport(watchPoint(r));
    }
  }

  /** One line per running dungeon, for the admin overview. */
  public record RunInfo(int slot, String title, List<String> lines) {}

  public List<RunInfo> overview() {
    List<RunInfo> out = new ArrayList<>();
    for (Run r : runs.values().stream().sorted(Comparator.comparingInt(x -> x.slot)).toList()) {
      if (r.ended) continue;
      long seconds = (tick - r.started) / 20;
      out.add(
          new RunInfo(
              r.slot,
              r.variant.title + " · " + Zone.at(r.zone).title + " · " + DungeonRules.MODES[r.mode],
              List.of(
                  "Spieler: " + names(r),
                  "Level " + r.level + " · " + r.stage.name() + " · Welle " + r.wave + "/" + r.totalWaves,
                  "Läuft seit " + seconds / 60 + ":" + String.format("%02d", seconds % 60),
                  "Zuschauer: " + r.watchers.size())));
    }
    return out;
  }

  /** Admin: close a run without rewards (for stuck or abused runs). */
  public void closeRun(int slot, String by) {
    Run r = runs.get(slot);
    if (r == null || r.ended) throw new IllegalArgumentException("Dieser Lauf ist schon vorbei.");
    finish(r, false, "Dieser Dungeon wurde von " + by + " beendet. Deine Ausrüstung bleibt erhalten.");
  }

  public String verify() {
    if (verification.startsWith("RUNNING")) return verification;
    int slot = 0;
    while (runs.containsKey(slot)) slot++;
    if (slot >= 4) return "BUSY";
    Run r =
        new Run(
            slot,
            0,
            0,
            List.of(UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID()),
            31);
    r.diagnostic = true;
    runs.put(slot, r);
    verification = "RUNNING: arena and model lifecycle";
    return verification;
  }

  public String verification() {
    return verification;
  }

  @Override
  public void close() {
    task.cancel();
    for (Run r : new ArrayList<>(runs.values()))
      finish(r, false, "Serverneustart: Dungeon beendet, keine Ausrüstung verloren.");
  }
}
