package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import de.deepforge.ui.Hud;
import java.util.*;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

/**
 * Bounded, private cooperative instances in the plugin-owned world. All state runs on the main
 * thread.
 */
public final class Dungeons implements Listener, AutoCloseable {
  private final DeepforgePlugin plugin;
  private final PartyBook parties = new PartyBook();
  private final Map<UUID, Run> membership = new HashMap<>();
  private final Map<Integer, Run> runs = new HashMap<>();
  private final Map<UUID, Enemy> enemies = new HashMap<>();
  private final Map<UUID, Long> clicks = new HashMap<>();
  private final Map<UUID, Run> watching = new HashMap<>();
  private final Random random = new Random();
  private final BukkitTask task;
  private long tick;
  private String verification = "Noch nicht gestartet";
  private static final Material[] RUNES = {
    Material.RED_CONCRETE, Material.BLUE_CONCRETE, Material.LIME_CONCRETE, Material.YELLOW_CONCRETE
  };
  private static final String[] NAMES = {"Rot", "Blau", "Grün", "Gelb"};

  private enum Stage {
    BUILDING,
    COUNTDOWN,
    WAVE,
    TRAVEL,
    SIDE,
    PUZZLE,
    // 0.9.2: after the win – camera flight, statistics, vault chests, leave when ready.
    VICTORY,
    COMPLETE
  }

  private static final class Run {
    final UUID id = UUID.randomUUID();
    final int slot, mode, x;
    // Tiefengang runs move one mine deeper every five Ebenen.
    int zone;
    // Tiefengang runs change level and wave count with every Ebene.
    int level, totalWaves;
    boolean endless;
    int floor = 1;
    final DungeonVariant variant;
    // Glutschmiede: spots that erupt at eruptLand; Frostkrypta: frost stacks and warm braziers.
    final List<Location> eruptSpots = new ArrayList<>();
    long eruptNext, eruptLand;
    final Map<UUID, Integer> frost = new HashMap<>();
    final List<Location> braziers = new ArrayList<>();
    long frostNext;
    // Players watching this run in spectator mode.
    final Set<UUID> watchers = new LinkedHashSet<>();
    // Players currently taking part; follows leaves and disconnects during the run.
    int size;
    final LinkedHashSet<UUID> members;
    final Map<UUID, Long> disconnected = new HashMap<>();
    final Set<UUID> down = new HashSet<>();
    final Map<UUID, Integer> healingDrops = new HashMap<>();
    final DungeonBlessings blessings = new DungeonBlessings();
    final Set<Long> chunks = new HashSet<>();
    final List<Enemy> mobs = new ArrayList<>();
    final List<Entity> decorations = new ArrayList<>();
    final BossBar bar =
        BossBar.bossBar(
            Component.text("Gewölbe wird vorbereitet"),
            1,
            BossBar.Color.PURPLE,
            BossBar.Overlay.PROGRESS);
    Stage stage = Stage.BUILDING;
    long deadline, started, sealTicks;
    int room, cursor, wave, memoryStep, mistakes, pending, spawned, reinforcements;
    int optionalFlags, pendingOptional, diagnosticExtra;
    boolean challengeAttempted, key;
    // Generated layout, build progress and per-room state.
    DungeonPlan plan;
    List<int[]> boxes = List.of();
    int boxIndex, roomWave;
    long boxCursor, timeTicks;
    boolean[] branchOpen = new boolean[0];
    final Map<Integer, Object> puzzleStates = new HashMap<>();
    // Blocks players can click: puzzle parts and optional side-room objects.
    final Map<org.bukkit.block.Block, String> clickables = new HashMap<>();
    final Map<Integer, ItemDisplay> mirrors = new HashMap<>();
    final Map<UUID, Long> trapHits = new HashMap<>();
    long puzzleStarted, plateDeadline;
    boolean mimicKey;
    final Set<Integer> shrinesBuilt = new HashSet<>();
    // Room whose blessing can be chosen right now, and its shrine blocks (index = blessing).
    int shrineRoom = -1;
    final List<org.bukkit.block.Block> shrines = new ArrayList<>();
    Villager captive;
    boolean diagnostic, ended;
    boolean diagnosticValid = true, diagnosticElite, diagnosticBoss;
    int diagnosticChecked;
    final Set<Integer> diagnosticKinds = new HashSet<>();
    List<Integer> sequence = List.of();
    // Players hit by a big boss attack; everyone else earns the flawless bonus.
    final Set<UUID> bossStruck = new HashSet<>();
    boolean bossFought;
    // Victory hall (0.9.2): per-player numbers, camera flight and the hall's own blocks.
    final DungeonStats stats = new DungeonStats();
    // Highest prestige in the group (0.12.0): enemies scale with it.
    int prestige;
    // Minions of the boss's Schildphase (0.11.0).
    final Set<Enemy> summoned = new HashSet<>();
    long victoryAt, clearTicks;
    ArmorStand camera;
    final Set<UUID> filming = new HashSet<>();
    final List<org.bukkit.block.Block> hallBlocks = new ArrayList<>();

    Run(int slot, int zone, int mode, List<UUID> ids) {
      this(slot, zone, mode, ids, 1);
    }

    Run(int slot, int zone, int mode, List<UUID> ids, int level) {
      this(slot, zone, mode, ids, level, DungeonVariant.GEWOELBE);
    }

    Run(int slot, int zone, int mode, List<UUID> ids, int level, DungeonVariant variant) {
      this.variant = variant;
      this.slot = slot;
      this.zone = zone;
      this.mode = mode;
      this.level = level;
      totalWaves = DungeonRules.waves(level);
      plan =
          DungeonPlan.generate(
              id.getMostSignificantBits() ^ id.getLeastSignificantBits(), totalWaves, level);
      boxes = plan.boxes();
      timeTicks = plan.minutes() * 1200L;
      branchOpen = new boolean[plan.rooms.size()];
      size = Math.max(1, ids.size());
      x = -512 - slot * 128;
      members = new LinkedHashSet<>(ids);
    }

    /** Tiefengang (0.9.3): one arena, endless Ebenen. */
    static Run endless(int slot, int zone, List<UUID> ids) {
      Run r = new Run(slot, zone, 0, ids, 1, DungeonVariant.GEWOELBE);
      r.endless = true;
      r.floor = 1;
      r.level = DeepDescent.level(1);
      r.totalWaves = DeepDescent.waves(1);
      r.plan = DungeonPlan.arena(r.id.getMostSignificantBits());
      r.boxes = r.plan.boxes();
      r.branchOpen = new boolean[r.plan.rooms.size()];
      r.timeTicks = Long.MAX_VALUE / 4;
      return r;
    }
  }

  private static final class Enemy {
    Run run;
    // Room the enemy belongs to; it never leaves it.
    int room;
    Mob mob;
    MonsterRig rig;
    MonsterHealthIndicator health;
    int kind;
    boolean boss, elite;
    double hp, max;
    long attackAt, resolveAt, recoilAt;
    final BossPressure pressure = new BossPressure();
    Location sweepOrigin;
    int spell;
    Location marker, secondary;
    Vector direction;
    BossBrain brain;
    // Wächter (0.11.0).
    Minibosses.Kind guard;
    long born, cycleAt, eruptAt, stunUntil, twinFell = -1, warnAt;
    boolean mirrorShown;
    Enemy twin;
    Location twinSpot;
    final Set<Enemy> minions = new HashSet<>();
    final List<double[]> islands = new ArrayList<>();
  }

  public Dungeons(DeepforgePlugin plugin) {
    this.plugin = plugin;
    Bukkit.getPluginManager().registerEvents(this, plugin);
    task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1, 2);
  }

  public boolean active(Player p) {
    return membership.containsKey(p.getUniqueId());
  }

  public PartyBook parties() {
    return parties;
  }

  public boolean down(Player p) {
    Run r = membership.get(p.getUniqueId());
    return r != null && r.down.contains(p.getUniqueId());
  }

  private int partyPrestige(Collection<UUID> roster) {
    int best = 0;
    for (UUID id : roster) {
      Player p = Bukkit.getPlayer(id);
      if (p != null && plugin.playing(p)) best = Math.max(best, plugin.profile(p).prestige);
    }
    return best;
  }

  /** Albtraum, last boss phase: healing items are blocked (0.11.0). */
  public boolean healLocked(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || !BossPatterns.healLock(r.mode)) return false;
    for (Enemy e : r.mobs) if (e.brain != null && e.brain.phase() >= 2) return true;
    return false;
  }

  public boolean shrineBlock(Player p, org.bukkit.block.Block block) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || block == null) return false;
    if (r.clickables.containsKey(block)) return true;
    if (r.stage != Stage.TRAVEL) return false;
    for (int i = 0; i < 3; i++) if (block.equals(at(r, -8 + i * 8, 0, -10).getBlock())) return true;
    return false;
  }

  private DungeonPlan.Room room(Run r) {
    return r.plan.rooms.get(r.room);
  }

  /** Relative to the current room: centre of the floor, y = 0 is where players stand. */
  private Location at(Run r, double x, double y, double z) {
    return in(r, room(r), x, y, z);
  }

  private Location in(Run r, DungeonPlan.Room room, double x, double y, double z) {
    return worldAt(r, room.cx + x, room.floor + y, room.cz + z);
  }

  private Location worldAt(Run r, double x, double y, double z) {
    return new Location(plugin.mines().world(), r.x + x + .5, 65 + y, -512 + z + .5, 180, 0);
  }

  public boolean contains(Player p) {
    Run r = membership.get(p.getUniqueId());
    return r != null && inside(r, p.getLocation());
  }

  private boolean inside(Run r, Location l) {
    return l.getWorld().equals(plugin.mines().world())
        && r.plan != null
        && r.plan.contains(l.getX() - r.x, l.getY() - 65, l.getZ() + 512);
  }

  /** Inside the walls of a room, at least {@code margin} blocks away from them. */
  private boolean inRoom(Run r, DungeonPlan.Room room, Location l, double margin) {
    double x = l.getX() - r.x - room.cx - .5, z = l.getZ() + 512 - room.cz - .5;
    return Math.abs(x) <= room.hw - .5 - margin && Math.abs(z) <= room.hd - .5 - margin;
  }

  private String roomName(Run r, DungeonPlan.Room room) {
    return switch (room.role) {
      case START -> r.variant.room(0);
      case BOSS -> r.variant.room(2);
      case SIDE ->
          switch (room.side) {
            case CHALLENGE -> "Prüfungskammer";
            case PRISON -> "Zellentrakt";
            case TREASURE -> "Schatzkammer";
          };
      default ->
          (switch (r.variant) {
                case GEWOELBE -> "Runen";
                case GLUTSCHMIEDE -> "Schlacken";
                case FROSTKRYPTA -> "Eis";
              })
              + switch (room.shape) {
                case PILLARS -> "säulenhalle";
                case BRIDGE -> "brücke";
                case CRYPT -> "gruft";
                case GAUNTLET -> "gang";
                case CHAMBER -> "kammer";
                case ARENA -> "arena";
                default -> "halle";
              };
    };
  }

  private List<Player> online(Run r) {
    return r.members.stream()
        .map(Bukkit::getPlayer)
        .filter(Objects::nonNull)
        .filter(Player::isOnline)
        .toList();
  }

  private List<Player> living(Run r) {
    return online(r).stream()
        .filter(
            p ->
                !r.down.contains(p.getUniqueId())
                    && plugin.playing(p)
                    && !p.isDead()
                    && inside(r, p.getLocation()))
        .toList();
  }

  private void say(Run r, String text) {
    online(r).forEach(p -> plugin.tell(p, text));
    for (UUID id : r.watchers) {
      Player w = Bukkit.getPlayer(id);
      if (w != null) plugin.tell(w, "[Zuschauer] " + text);
    }
  }

  private void partySay(PartyBook.Party party, String text) {
    for (UUID id : party.members) {
      Player p = Bukkit.getPlayer(id);
      if (p != null) plugin.tell(p, text);
    }
  }

  public void command(Player p, String[] args) {
    if (!plugin.playing(p)) {
      plugin.tell(p, "Zuerst /df start.");
      return;
    }
    try {
      if (args[0].equalsIgnoreCase("dungeon")) {
        if (args.length > 2 && args[1].equalsIgnoreCase("segen")) {
          Run r = membership.get(p.getUniqueId());
          int choice = Integer.parseInt(args[2]) - 1;
          if (r == null) plugin.tell(p, "Du bist in keinem Dungeon.");
          else if (choice < 0 || choice > 2) plugin.tell(p, "Segen 1 = Kraft, 2 = Schutz, 3 = Quelle.");
          else bless(r, p, choice);
          return;
        }
        if (args.length > 1
            && Set.of("tiefengang", "tief", "endlos").contains(args[1].toLowerCase(Locale.ROOT))) {
          startDeep(p);
          return;
        }
        if (args.length > 1 && args[1].equalsIgnoreCase("hint")) {
          Run r = membership.get(p.getUniqueId());
          if (r != null && r.stage == Stage.PUZZLE && DungeonPuzzles.silent(r.mode))
            plugin.tell(p, "Auf Albtraum gibt es keine Hinweise.");
          else if (r != null && r.stage == Stage.PUZZLE) replayPuzzle(r);
          return;
        }
        if (args.length > 1 && args[1].equalsIgnoreCase("leave")) {
          if (watching(p)) stopWatching(p, "Zuschauen beendet.");
          else withdraw(p);
          return;
        }
        if (args.length > 1
            && Set.of("zuschauen", "spectate", "watch").contains(args[1].toLowerCase(Locale.ROOT))) {
          spectate(p, args.length > 2 ? args[2] : null);
          return;
        }
        if (args.length > 1 && args[1].equalsIgnoreCase("start")) {
          int mode = args.length > 2 ? Integer.parseInt(args[2]) - 1 : 0;
          int zone = args.length > 3 ? Integer.parseInt(args[3]) - 1 : commonZone(p);
          int variant = args.length > 4 ? Integer.parseInt(args[4]) - 1 : 0;
          if (variant < 0 || variant >= DungeonVariant.values().length)
            throw new IllegalArgumentException(
                "Dungeon 1 = Runengewölbe, 2 = Glutschmiede, 3 = Frostkrypta.");
          start(p, zone, mode, DungeonVariant.of(variant));
          return;
        }
        open(p, commonZone(p), lastVariant(p));
        return;
      }
      String action = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "status";
      UUID id = p.getUniqueId();
      if (active(p) && !action.equals("status"))
        throw new IllegalArgumentException(
            "Während des Laufs ist die Party fest. /df dungeon leave zum Aussteigen.");
      if (parties.networkMode() && Set.of("create", "invite", "accept", "leave").contains(action)) {
        plugin.tell(
            p,
            "Partys laufen über das Netzwerk: /party invite <Name>, /party accept, /party leave."
                + " Deepforge übernimmt deine Party automatisch.");
        return;
      }
      switch (action) {
        case "create" -> {
          parties.create(id);
          plugin.tell(p, "Party erstellt. /df party invite <Spieler> · maximal 4 Spieler.");
        }
        case "invite" -> {
          Player guest = args.length > 2 ? Bukkit.getPlayerExact(args[2]) : null;
          if (guest == null || !plugin.playing(guest) || active(guest))
            throw new IllegalArgumentException("Der Spieler muss online und in Deepforge sein.");
          parties.invite(id, guest.getUniqueId(), System.currentTimeMillis());
          plugin.tell(
              guest,
              p.getName() + " lädt dich ins Gewölbe ein. /df party accept (60 Sekunden gültig).");
          plugin.tell(p, "Einladung an " + guest.getName() + " gesendet.");
        }
        case "accept" -> {
          // An invitation is invalidated when its leader starts a run.
          PartyBook.Party joined = parties.accept(id, System.currentTimeMillis());
          if (joined.members.stream().anyMatch(membership::containsKey)) {
            parties.leave(id);
            throw new IllegalArgumentException("Die Gruppe ist schon im Dungeon.");
          }
          partySay(
              joined, p.getName() + " ist beigetreten. Alle bestätigen neu mit /df party ready.");
        }
        case "ready" -> {
          boolean ready = parties.ready(id);
          partySay(
              parties.get(id), p.getName() + (ready ? " ist bereit." : " ist nicht mehr bereit."));
        }
        case "leave" -> {
          parties.leave(id);
          plugin.tell(p, "Party verlassen.");
        }
        default -> {
          PartyBook.Party party = parties.get(id);
          if (party == null)
            plugin.tell(
                p,
                parties.networkMode()
                    ? "Keine Party. Netzwerk-Party: /party invite <Name>. Solo: /df dungeon."
                    : "/df party create · invite <Name> · accept · ready · leave. Solo: /df dungeon.");
          else {
            plugin.tell(
                p,
                "Party: "
                    + party.members.size()
                    + (party.network ? " (Netzwerk)" : "/" + PartyBook.LIMIT)
                    + " · Leiter: "
                    + name(party.leader));
            for (UUID member : party.members)
              plugin.tell(
                  p, name(member) + (party.ready.contains(member) ? " · Bereit" : " · Wartet"));
          }
        }
      }
    } catch (IllegalArgumentException e) {
      plugin.tell(p, DeepforgePlugin.readable(e, e.getMessage() == null ? "Ungültige Eingabe." : e.getMessage()));
    }
  }

  private String name(UUID id) {
    Player p = Bukkit.getPlayer(id);
    return p == null ? "Offline" : p.getName();
  }

  private int commonZone(Player p) {
    PartyBook.Party party = parties.get(p.getUniqueId());
    int zone = plugin.profile(p).zone;
    if (party != null)
      for (UUID id : party.members) {
        Player m = Bukkit.getPlayer(id);
        if (m != null) zone = Math.min(zone, plugin.profile(m).zone);
      }
    return zone;
  }

  private int previewLevel(Player p, int zone) {
    PartyBook.Party party = parties.get(p.getUniqueId());
    List<Profile> profiles = new ArrayList<>();
    profiles.add(plugin.profile(p));
    if (party != null)
      for (UUID id : party.members) {
        Player member = Bukkit.getPlayer(id);
        if (member != null && !id.equals(p.getUniqueId())) profiles.add(plugin.profile(member));
      }
    return DungeonRules.groupLevel(profiles, zone);
  }

  private static final class Menu implements InventoryHolder {
    Inventory inventory;
    int zone;
    DungeonVariant variant = DungeonVariant.GEWOELBE;
    UUID owner;

    public Inventory getInventory() {
      return inventory;
    }
  }

  private ItemStack icon(Material material, String title, String... lore) {
    String model =
        switch (material) {
          case LIME_DYE -> "relic";
          case PLAYER_HEAD -> "gear_helmet";
          case OAK_DOOR, BARRIER -> "close";
          case IRON_SWORD -> "weapon_sword";
          case DIAMOND_SWORD -> "weapon_spear";
          case NETHERITE_SWORD -> "weapon_hammer";
          case ARROW -> "back";
          case AMETHYST_SHARD -> "healing_crystal";
          case CHEST -> "crate";
          case CLOCK -> "clock";
          default -> "handbook";
        };
    return icon(material, model, false, title, lore);
  }

  /** Menu button; {@code model == null} keeps the vanilla item, {@code glint} marks the choice. */
  private ItemStack icon(
      Material material, String model, boolean glint, String title, String... lore) {
    ItemStack item = plugin.items().button(material, model == null ? "handbook" : model, title, lore);
    org.bukkit.inventory.meta.ItemMeta meta = item.getItemMeta();
    if (model == null) meta.setItemModel(null);
    if (glint) meta.setEnchantmentGlintOverride(true);
    item.setItemMeta(meta);
    return item;
  }

  // Last dungeon picked in the menu, so reopening shows the same one.
  private final Map<UUID, DungeonVariant> picked = new HashMap<>();
  // 0.10.0: level the player chose in the menu, per zone ({zone, level}); default = own level.
  private final Map<UUID, int[]> wished = new HashMap<>();
  private final Set<UUID> shiftClicks = new HashSet<>();

  /** Chosen run level for this zone: 1 … group level, the group level when nothing was chosen. */
  private int wishedLevel(Player p, int zone) {
    int max = previewLevel(p, zone);
    int[] w = wished.get(p.getUniqueId());
    return w == null || w[0] != zone ? max : Math.clamp(w[1], 1, max);
  }

  private DungeonVariant lastVariant(Player p) {
    Run r = membership.get(p.getUniqueId());
    return r != null ? r.variant : picked.getOrDefault(p.getUniqueId(), DungeonVariant.GEWOELBE);
  }

  /** Every party member (or the player alone) has this dungeon unlocked. */
  private boolean unlockedForAll(Player p, DungeonVariant v) {
    if (!v.unlocked(plugin.profile(p))) return false;
    PartyBook.Party party = parties.get(p.getUniqueId());
    if (party != null)
      for (UUID id : party.members) {
        Player m = Bukkit.getPlayer(id);
        if (m != null && !v.unlocked(plugin.profile(m))) return false;
      }
    return true;
  }

  public void open(Player p, int zone) {
    open(p, zone, lastVariant(p));
  }

  /** Members whose progress blocks {@code mode} in {@code zone}, with the reason. */
  private List<String> missing(Player p, int zone, int mode) {
    List<String> out = new ArrayList<>();
    PartyBook.Party party = parties.get(p.getUniqueId());
    List<UUID> ids = party == null ? List.of(p.getUniqueId()) : List.copyOf(party.members);
    for (UUID id : ids) {
      Player member = Bukkit.getPlayer(id);
      if (member == null) {
        out.add(name(id) + " (offline)");
        continue;
      }
      Profile data = plugin.profile(member);
      if (data.zone < zone) out.add(member.getName() + " (Gebiet fehlt)");
      else if (mode > 0 && data.dungeonWins[zone * 3 + mode - 1] == 0)
        out.add(member.getName() + " (" + DungeonRules.MODES[mode - 1] + "-Sieg fehlt)");
    }
    return out;
  }

  // Menu layout: one row per step, labels in the left column.
  private static final int ROW_DUNGEON = 9, ROW_ZONE = 18, ROW_MODE = 27, ROW_PARTY = 36;
  private static final Material[] VARIANT_ICONS = {
    Material.CHISELED_STONE_BRICKS, Material.MAGMA_BLOCK, Material.PACKED_ICE
  };

  public void open(Player p, int zone, DungeonVariant variant) {
    boolean inRun = active(p);
    Menu m = new Menu();
    m.zone = Math.clamp(zone, 0, commonZone(p));
    int maxLevel = previewLevel(p, m.zone);
    int level = inRun ? membership.get(p.getUniqueId()).level : wishedLevel(p, m.zone);
    m.variant = unlockedForAll(p, variant) ? variant : DungeonVariant.GEWOELBE;
    picked.put(p.getUniqueId(), m.variant);
    m.owner = p.getUniqueId();
    m.inventory =
        Bukkit.createInventory(m, 54, plugin.menus().styledTitle(p, "DUNGEON · LEVEL " + level));
    PartyBook.Party party = parties.get(p.getUniqueId());
    int size = party == null ? 1 : party.members.size();
    Inventory inv = m.inventory;

    // Summary of the current choice.
    inv.setItem(
        4,
        icon(
            VARIANT_ICONS[m.variant.ordinal()],
            null,
            true,
            m.variant.title + " · " + Zone.at(m.zone).title,
            "Endboss: " + m.variant.boss(m.zone),
            m.variant.hazard,
            m.variant.loot,
            "5–8 Räume · " + DungeonRules.waves(level) + " Wellen · 2–3 Rätsel · jedes Mal neu",
            "Bedingung: " + DungeonRules.conditionName(level),
            "Dein Level in diesem Gebiet: " + DungeonRules.level(plugin.profile(p), m.zone),
            party != null ? "Gruppenlevel = höchstes Level der Party in diesem Gebiet" : ""));

    // 1 · Dungeon
    inv.setItem(ROW_DUNGEON, icon(Material.PAPER, "handbook", false, "① Dungeon wählen"));
    for (DungeonVariant v : DungeonVariant.values()) {
      boolean open = unlockedForAll(p, v), chosen = v == m.variant;
      inv.setItem(
          ROW_DUNGEON + 2 + v.ordinal() * 2,
          icon(
              open ? VARIANT_ICONS[v.ordinal()] : Material.BARRIER,
              open ? null : "close",
              chosen,
              (chosen ? "▶ " : "") + v.title + (open ? "" : " · gesperrt"),
              v.flavor,
              v.hazard,
              v.loot,
              "Deine Siege hier: " + DungeonVariant.wins(plugin.profile(p), v),
              chosen
                  ? "✔ Ausgewählt"
                  : open
                      ? "Klick: auswählen"
                      : "✖ " + v.requirement() + (party != null ? " (alle in der Party)" : "")));
    }

    // 2 · Gebiet
    int unlocked = commonZone(p);
    inv.setItem(ROW_ZONE, icon(Material.PAPER, "handbook", false, "② Gebiet wählen"));
    inv.setItem(
        ROW_ZONE + 2,
        m.zone > 0
            ? icon(Material.ARROW, "back", false, "◀ " + Zone.at(m.zone - 1).title)
            : icon(Material.GRAY_DYE, null, false, "Erstes Gebiet"));
    inv.setItem(
        ROW_ZONE + 4,
        icon(
            Material.RAW_IRON,
            "ore_" + Zone.at(m.zone).key,
            true,
            "Gebiet " + (m.zone + 1) + ": " + Zone.at(m.zone).title,
            "Dein Dungeonlevel hier: " + DungeonRules.level(plugin.profile(p), m.zone),
            "Wählbar: Gebiet 1 bis " + (unlocked + 1),
            party != null
                ? "Die Party kann nur Gebiete wählen, die alle freigeschaltet haben."
                : "Neue Gebiete schaltest du im Aufzug frei."));
    inv.setItem(
        ROW_ZONE + 6,
        m.zone < unlocked
            ? icon(Material.ARROW, "next", false, Zone.at(m.zone + 1).title + " ▶")
            : icon(
                Material.GRAY_DYE,
                null,
                false,
                m.zone < Zone.LAST ? "Gebiet " + (m.zone + 2) + " gesperrt" : "Letztes Gebiet",
                m.zone < Zone.LAST
                    ? "Zuerst im Aufzug freischalten" + (party != null ? " (alle in der Party)" : "")
                    : ""));

    // 3 · Schwierigkeit & Start
    inv.setItem(ROW_MODE, icon(Material.PAPER, "handbook", false, "③ Schwierigkeit & Start"));
    boolean leader = party == null || party.leader.equals(p.getUniqueId());
    boolean allReady = party == null || party.ready.containsAll(party.members);
    for (int mode = 0; mode < 3; mode++) {
      List<String> blocked = missing(p, m.zone, mode);
      String state =
          inRun
              ? "Ihr seid schon im Dungeon."
              : !blocked.isEmpty()
                  ? "✖ Gesperrt – fehlt bei: " + String.join(", ", blocked)
                  : !allReady
                      ? "✖ Noch nicht alle bereit (" + party.ready.size() + "/" + size + ")"
                      : !leader ? "✖ Nur der Partyleiter kann starten" : "✔ Klick: jetzt starten!";
      List<String> lore = new ArrayList<>();
      lore.add(
          m.variant.coins(DungeonRules.coins(m.zone, mode, level))
              + " $ pro Person · Boss "
              + (int) DungeonRules.health(m.zone, mode, size, DungeonRules.waves(level), true, level)
              + " LP");
      int myth = DungeonRules.mythicThreshold(mode, level),
          leg = DungeonRules.legendaryThreshold(mode, level) - myth,
          epic = DungeonRules.epicThreshold(mode, level) - myth - leg;
      lore.add(
          String.format(
              Locale.GERMAN,
              "Mythisch %.1f %% · Legendär %.1f %% · Episch %.1f %%",
              myth / 10.,
              leg / 10.,
              epic / 10.));
      lore.add(
          String.format(
              Locale.GERMAN,
              "Beutestärke ×%.2f · Geld ×%.2f (Level %d)",
              DungeonRules.lootGrowth(level),
              1 + .12 * (level - 1),
              level));
      lore.addAll(DungeonRules.perLevel(mode, level));
      if (level > 1)
        lore.add(
            String.format(
                Locale.GERMAN,
                "Gegenüber Level 1: Mythisch ×%.1f · Legendär ×%.1f",
                myth / (double) DungeonRules.mythicThreshold(mode, 1),
                (DungeonRules.legendaryThreshold(mode, level) - myth)
                    / (double) (DungeonRules.legendaryThreshold(mode, 1) - DungeonRules.mythicThreshold(mode, 1))));
      if (mode > 0) lore.add("Braucht: " + DungeonRules.MODES[mode - 1] + "-Sieg in diesem Gebiet (alle)");
      lore.add(state);
      Material weapon =
          mode == 0 ? Material.IRON_SWORD : mode == 1 ? Material.DIAMOND_SWORD : Material.NETHERITE_SWORD;
      boolean ready = state.startsWith("✔");
      inv.setItem(
          ROW_MODE + 2 + mode * 2,
          icon(
              blocked.isEmpty() ? weapon : Material.BARRIER,
              blocked.isEmpty()
                  ? mode == 0 ? "weapon_sword" : mode == 1 ? "weapon_spear" : "weapon_hammer"
                  : "close",
              ready,
              DungeonRules.MODES[mode] + (blocked.isEmpty() ? "" : " · gesperrt"),
              lore.toArray(String[]::new)));
    }

    // Level choice (0.10.0): replay lower levels for easier, smaller rewards.
    inv.setItem(
        ROW_MODE + 1,
        icon(
            level > 1 ? Material.ARROW : Material.GRAY_DYE,
            level > 1 ? "back" : null,
            false,
            "◀ Level " + Math.max(1, level - 1),
            "Klick: −1 · Shift-Klick: −5",
            "Niedrigere Level sind leichter, geben aber weniger Beute.",
            "Dein Level steigt nur bei einem Sieg auf deinem Höchstlevel."));
    inv.setItem(
        ROW_MODE + 7,
        icon(
            level < maxLevel ? Material.ARROW : Material.GRAY_DYE,
            level < maxLevel ? "next" : null,
            false,
            level < maxLevel ? "Level " + (level + 1) + " ▶" : "Höchstlevel " + maxLevel,
            "Klick: +1 · Shift-Klick: +5",
            "Gewählt: Level " + level + " von " + maxLevel));

    // 4 · Party
    inv.setItem(ROW_PARTY, icon(Material.PAPER, "handbook", false, "④ Party"));
    List<String> members = new ArrayList<>();
    if (party == null) members.add("Solo – du spielst allein");
    else
      for (UUID id : party.members)
        members.add(
            (party.ready.contains(id) ? "✔ " : "✖ ")
                + name(id)
                + (id.equals(party.leader) ? " (Leiter)" : ""));
    members.add("Einladen: /df party invite <Name>");
    members.add("Bis zu 4 Spieler · Gruppenlevel = höchstes Level");
    inv.setItem(
        ROW_PARTY + 2,
        icon(
            Material.PLAYER_HEAD,
            "gear_helmet",
            false,
            party == null ? "Keine Party" : "Party " + party.ready.size() + "/" + size + " bereit",
            members.toArray(String[]::new)));
    boolean meReady = party != null && party.ready.contains(p.getUniqueId());
    inv.setItem(
        ROW_PARTY + 4,
        icon(
            meReady ? Material.LIME_DYE : Material.GRAY_DYE,
            meReady ? "relic" : null,
            meReady,
            meReady ? "✔ Du bist bereit" : "Bereit melden",
            party == null ? "Solo: einfach eine Schwierigkeit anklicken" : "Klick: umschalten"));
    inv.setItem(
        ROW_PARTY + 6,
        icon(
            Material.OAK_DOOR,
            "close",
            false,
            inRun ? "Dungeon verlassen" : "Party verlassen",
            inRun ? "Du verlierst die Abschlussbeute dieses Laufs" : ""));
    long others = runs.values().stream().filter(r -> !r.members.contains(p.getUniqueId())).count();
    inv.setItem(
        ROW_PARTY + 8,
        icon(
            Material.ENDER_EYE,
            null,
            false,
            watching(p) ? "Nächsten Dungeon ansehen" : "Zuschauen",
            others == 0 ? "Gerade läuft kein anderer Dungeon" : others + " laufen gerade",
            "Beenden: /df dungeon leave"));

    // Bottom bar
    inv.setItem(45, icon(Material.ARROW, "Zurück: Kampf & Ausrüstung"));
    inv.setItem(47, icon(Material.BOOK, "Hauptmenü"));
    inv.setItem(49, icon(Material.BARRIER, "Schließen"));
    inv.setItem(
        51,
        icon(
            Material.CHEST,
            "So läuft ein Dungeon",
            "Jeder Lauf baut einen neuen Grundriss: 5–8 Räume",
            "Verwinkelte Gänge, Treppen, Nebenräume",
            "2–3 Rätsel aus 8: Runen, Siegel, Hebel, Platten,",
            "Lichtstrahl, Fallengang, Glocken, falsche Truhen",
            "Am Ende: " + m.variant.room(2) + " mit dem Endboss",
            "Optional: Prüfung, Rettung, Schatzkammer (Schlüssel im Fass)",
            "Niederlage: alle gleichzeitig besiegt",
            "Jedes Gebiet hat sein eigenes Level: Sieg = +1 dort",
            "Nach dem Sieg: Siegeshalle mit Statistik und Gewölbekisten"));
    inv.setItem(
        53,
        icon(
            Material.AMETHYST_SHARD,
            "Heilen · " + plugin.profile(p).healingCharges + " Splitter",
            "Klick: heilen · 4 LP + 35 % Leben · 20 s Pause",
            "Rechtsklick: 1 nachkaufen · " + Healing.price(plugin.profile(p)) + " $",
            "Shift-Klick: Vorrat auffüllen",
            "Nur vor dem Start! Im Dungeon gibt es keinen Nachkauf."));
    plugin.items().forViewer(m.inventory, p);
    p.openInventory(m.inventory);
  }

  @EventHandler
  public void click(InventoryClickEvent e) {
    if (!(e.getView().getTopInventory().getHolder() instanceof Menu m)) return;
    e.setCancelled(true);
    if (!(e.getWhoClicked() instanceof Player p) || !m.owner.equals(p.getUniqueId())) return;
    int slot = e.getRawSlot();
    if (e.isShiftClick()) shiftClicks.add(p.getUniqueId());
    else shiftClicks.remove(p.getUniqueId());
    if (slot == 53) {
      if (e.getClick() == ClickType.DOUBLE_CLICK) return;
      int buy = e.isShiftClick() ? Healing.CAPACITY : e.isRightClick() ? 1 : 0;
      Bukkit.getScheduler().runTask(plugin, () -> {
        if (!p.isOnline()) return;
        if (buy == 0) {
          p.closeInventory();
          plugin.healing().use(p);
        } else {
          plugin.healing().buy(p, buy);
          open(p, m.zone, m.variant);
        }
      });
      return;
    }
    // Opening another inventory inside the click event is unreliable; act one tick later.
    Bukkit.getScheduler().runTask(plugin, () -> {
      if (p.isOnline()) menuClick(p, m, slot);
    });
  }

  private void menuClick(Player p, Menu m, int slot) {
    try {
      if (slot == 49) p.closeInventory();
      else if (slot == 45 || slot == 47) plugin.menus().open(p, slot == 45 ? "combat" : "main");
      else if (slot == ROW_PARTY + 4) {
        if (active(p)) throw new IllegalArgumentException("Die Gruppe ist bereits im Dungeon.");
        if (parties.get(p.getUniqueId()) == null) parties.create(p.getUniqueId());
        parties.ready(p.getUniqueId());
        open(p, m.zone, m.variant);
      } else if (slot == ROW_PARTY + 6) {
        p.closeInventory();
        if (active(p)) withdraw(p);
        else parties.leave(p.getUniqueId());
      } else if (slot == ROW_PARTY + 8) spectate(p, null);
      else if (slot == ROW_ZONE + 2 || slot == ROW_ZONE + 6) {
        int next = m.zone + (slot == ROW_ZONE + 2 ? -1 : 1);
        if (next < 0 || next > commonZone(p)) {
          p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, .6f, 1);
          plugin.tell(
              p,
              next < 0
                  ? "Das ist bereits das erste Gebiet."
                  : "Gebiet " + (next + 1) + " ist noch nicht freigeschaltet"
                      + (parties.get(p.getUniqueId()) != null ? " (für alle in der Party)." : "."));
        } else {
          p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, .6f, 1.2f);
          open(p, next, m.variant);
        }
      } else if (slot >= ROW_DUNGEON + 2 && slot <= ROW_DUNGEON + 6 && slot % 2 == 1) {
        DungeonVariant v = DungeonVariant.of((slot - ROW_DUNGEON - 2) / 2);
        if (!unlockedForAll(p, v)) {
          p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, .6f, 1);
          plugin.tell(p, v.title + " ist noch gesperrt. " + v.requirement() + ".");
        } else {
          p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, .6f, 1.2f);
          open(p, m.zone, v);
        }
      } else if (slot == ROW_MODE + 1 || slot == ROW_MODE + 7) {
        int step = (slot == ROW_MODE + 1 ? -1 : 1) * (shiftClicks.contains(p.getUniqueId()) ? 5 : 1);
        int max = previewLevel(p, m.zone);
        int next = Math.clamp(wishedLevel(p, m.zone) + step, 1, max);
        wished.put(p.getUniqueId(), new int[] {m.zone, next});
        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, .6f, next == max ? 1.4f : 1f);
        open(p, m.zone, m.variant);
      } else if (slot == ROW_MODE + 2 || slot == ROW_MODE + 4 || slot == ROW_MODE + 6)
        start(p, m.zone, (slot - ROW_MODE - 2) / 2, m.variant);
    } catch (IllegalArgumentException ex) {
      p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, .6f, 1);
      plugin.tell(p, ex.getMessage());
    }
  }

  @EventHandler
  public void drag(InventoryDragEvent e) {
    if (e.getView().getTopInventory().getHolder() instanceof Menu) e.setCancelled(true);
  }

  private void start(Player leader, int zone, int mode, DungeonVariant variant) {
    if (zone < 0 || zone > Zone.LAST || mode < 0 || mode > 2)
      throw new IllegalArgumentException(
          "/df dungeon start <1..3 Schwierigkeit> <1.." + Zone.COUNT + " Gebiet>");
    if (parties.get(leader.getUniqueId()) == null) {
      parties.create(leader.getUniqueId());
      parties.ready(leader.getUniqueId());
    }
    // Alone in a party (e.g. from the last run): starting is being ready.
    PartyBook.Party own = parties.get(leader.getUniqueId());
    if (own.members.size() == 1) own.ready.add(leader.getUniqueId());
    List<UUID> roster = parties.roster(leader.getUniqueId());
    // Network parties can be bigger than a vault: at most four go in.
    if (roster.size() > PartyBook.LIMIT)
      throw new IllegalArgumentException(
          "Ein Gewölbe fasst höchstens " + PartyBook.LIMIT + " Spieler – deine Party hat " + roster.size() + ".");
    for (UUID id : roster) {
      Player p = Bukkit.getPlayer(id);
      if (p == null
          || !plugin.playing(p)
          || p.isDead()
          || p.getGameMode() != GameMode.SURVIVAL
          || plugin.combat().fighting(p))
        throw new IllegalArgumentException(
            "Alle müssen online, im Überlebensmodus und außerhalb eines Kampfes sein.");
      Profile data = plugin.profile(p);
      if (data.zone < zone || mode > 0 && data.dungeonWins[zone * 3 + mode - 1] == 0)
        throw new IllegalArgumentException(
            p.getName() + " hat Gebiet oder Schwierigkeit noch nicht freigeschaltet.");
      if (!variant.unlocked(data))
        throw new IllegalArgumentException(
            p.getName()
                + " hat "
                + variant.title
                + " noch nicht freigeschaltet. "
                + variant.requirement()
                + ".");
    }
    int slot = 0;
    while (runs.containsKey(slot)) slot++;
    if (slot >= 4)
      throw new IllegalArgumentException("Alle vier Gewölbe sind belegt. Bitte kurz warten.");
    int level =
        Math.min(
            wishedLevel(leader, zone),
            DungeonRules.groupLevel(
                roster.stream().map(Bukkit::getPlayer).map(plugin::profile).toList(), zone));
    Run r = new Run(slot, zone, mode, roster, level, variant);
    r.prestige = partyPrestige(roster);
    r.started = tick;
    runs.put(slot, r);
    for (UUID id : roster) {
      Player p = Bukkit.getPlayer(id);
      plugin.combat().clear(p, false);
      p.closeInventory();
      membership.put(id, r);
      p.showBossBar(r.bar);
    }
    parties.get(leader.getUniqueId()).ready.clear();
    say(
        r,
        r.variant.title + " wird aufgebaut. Gruppe: "
            + roster.size()
            + " · "
            + DungeonRules.MODES[mode]
            + " · Level "
            + level
            + " · "
            + DungeonRules.conditionName(level)
            + ".");
  }

  private void tick() {
    tick += 2;
    if (tick % 20 == 0) keepWatchers();
    for (Run r : new ArrayList<>(runs.values())) {
      try {
        step(r);
        leash(r);
        followRigs(r);
      } catch (RuntimeException ex) {
        plugin.getLogger().log(java.util.logging.Level.SEVERE, "Dungeon instance failed", ex);
        finish(r, false, "Gewölbe wegen eines Fehlers geschlossen; dein Inventar bleibt erhalten.");
        if (r.diagnostic) verification = "FAILED: " + ex.getMessage();
      }
    }
  }

  /**
   * Keeps every monster model on its mob. Enemies are only driven during fights; in puzzles,
   * while walking or when nobody is standing, a pushed mob used to leave its bones behind.
   */
  private void followRigs(Run r) {
    if (r.ended) return;
    for (Enemy e : r.mobs)
      if (e.rig != null && e.mob.isValid() && !e.rig.animatedAt(tick))
        e.rig.animate(
            e.mob.getLocation(), tick, false, false, e.mob.getVelocity().lengthSquared() > .001);
  }

  /** Half size of the area a boss may use: the hall is 40x40, walls and alcoves stay off-limits. */
  static final double BOSS_AREA = 17;

  /**
   * The boss never leaves its hall: players could otherwise lure it into the gallery or the
   * downed alcove and fight it from safety. Pushed or walked out, it is set back at the edge.
   */
  private void leash(Run r) {
    if (r.ended || r.plan == null) return;
    for (Enemy e : r.mobs) {
      if (!e.mob.isValid()) continue;
      DungeonPlan.Room room = r.plan.rooms.get(e.room);
      Location l = e.mob.getLocation();
      double x = l.getX() - r.x - room.cx - .5, z = l.getZ() + 512 - room.cz - .5;
      double limitX = room.hw - 2, limitZ = room.hd - 2;
      double cx = Math.clamp(x, -limitX, limitX), cz = Math.clamp(z, -limitZ, limitZ);
      if (room.shape == DungeonPlan.Shape.ARENA) {
        double radius = Math.min(room.hw, room.hd) - 2.5, d = Math.hypot(x, z);
        if (d > radius) {
          cx = x * radius / d;
          cz = z * radius / d;
        }
      }
      boolean fell = l.getY() < 65 + room.floor - 1.2;
      if (cx == x && cz == z && !fell && l.getY() < 65 + room.floor + room.height) continue;
      Location back = fell ? in(r, room, 0, 0, 0) : in(r, room, cx, 0, cz);
      back.setYaw(l.getYaw());
      e.mob.teleport(back);
      e.mob.setVelocity(new Vector());
    }
  }

  /** Enemy health keeps its percentage when the party shrinks or grows mid-run. */
  private void resize(Run r) {
    int now =
        Math.max(
            1,
            (int)
                r.members.stream()
                    .filter(id -> !r.disconnected.containsKey(id) && Bukkit.getPlayer(id) != null)
                    .count());
    if (now == r.size) return;
    double ratio = RapidCombat.partyHealth(now) / RapidCombat.partyHealth(r.size);
    for (Enemy e : r.mobs) {
      e.max *= ratio;
      e.hp *= ratio;
    }
    say(
        r,
        "Gewölbe passt sich an: "
            + now
            + " Spieler – Gegner werden "
            + (now < r.size ? "schwächer." : "stärker."));
    r.size = now;
  }

  private void step(Run r) {
    if (r.stage == Stage.VICTORY) {
      victoryTick(r);
      return;
    }
    if (r.stage == Stage.BUILDING) {
      build(r);
      return;
    }
    if (r.diagnostic) {
      diagnose(r);
      return;
    }
    resize(r);
    hazard(r);
    for (UUID id : new ArrayList<>(r.members)) {
      Player p = Bukkit.getPlayer(id);
      if (p == null) {
        r.disconnected.putIfAbsent(id, tick);
        if (tick - r.disconnected.get(id) > 1200) remove(r, id);
      } else if (r.disconnected.containsKey(id)) {
        if (tick - r.disconnected.get(id) > 1200) {
          remove(r, id);
          p.hideBossBar(r.bar);
          plugin.goHome(p);
        }
      } else if (!plugin.playing(p)) {
        remove(r, id);
        p.hideBossBar(r.bar);
      } else if (!inside(r, p.getLocation())) p.teleport(checkpoint(r, r.down.contains(id)));
      else if (!r.down.contains(id)) {
        // Fell into the pit of a bridge room: back to the entrance with a scratch.
        DungeonPlan.Room room = room(r);
        if (room.shape == DungeonPlan.Shape.BRIDGE
            && p.getY() < 65 + room.floor - 1.5
            && inRoom(r, room, p.getLocation(), 0)) {
          p.teleport(checkpoint(r, false));
          hurt(r, p, DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * .5);
          plugin.tell(p, "In den Abgrund gestürzt! Bleib auf den Brücken.");
        }
      }
    }
    if (r.members.isEmpty()) {
      finish(r, false, "Gruppe aufgelöst.");
      return;
    }
    if (tick - r.started > r.timeTicks) {
      finish(r, false, "Zeitlimit erreicht. Neuer Versuch im Dungeonmenü.");
      return;
    }
    if (r.members.stream().allMatch(r.down::contains)) {
      if (r.endless)
        finish(r, true, "Tiefengang beendet: auf Ebene " + r.floor + " gefallen. Alle Belohnungen sind ausgezahlt.");
      else finish(r, false, "Die Gruppe wurde besiegt. Eure Ausrüstung bleibt erhalten.");
      return;
    }
    if (living(r).isEmpty()) return;
    switch (r.stage) {
      case TRAVEL -> {
        DungeonPlan.Room next =
            r.room + 1 < r.plan.mainRooms ? r.plan.rooms.get(r.room + 1) : null;
        if (next != null
            && living(r).stream().allMatch(p -> inRoom(r, next, p.getLocation(), 1.5)))
          enterNextRoom(r);
        else if (next != null && tick % 20 == 0) circle(entrance(r, next), 2, Color.AQUA);
      }
      case COUNTDOWN -> {
        if (tick >= r.deadline) beginWave(r);
      }
      case SIDE -> {
        for (Enemy e : new ArrayList<>(r.mobs)) enemyTick(e);
        if (r.mobs.isEmpty()) completeChallenge(r);
      }
      case WAVE -> {
        for (Enemy e : new ArrayList<>(r.mobs)) enemyTick(e);
        refill(r);
        if (r.mobs.isEmpty() && r.pending == 0) waveDone(r);
      }
      case PUZZLE -> {
        for (Enemy e : new ArrayList<>(r.mobs)) enemyTick(e);
        puzzleTick(r);
      }
      default -> {}
    }
    if (tick % 20 == 0 && !r.ended) updateBar(r);
  }

  private void waveDone(Run r) {
    revive(r);
    if (r.endless) {
      if (r.wave >= r.totalWaves) floorDone(r);
      else countdown(r);
      return;
    }
    if (r.wave >= r.totalWaves) {
      finish(r, true, r.variant.title + " bezwungen!");
      return;
    }
    r.roomWave++;
    DungeonPlan.Room room = room(r);
    if (r.roomWave < room.waves) countdown(r);
    else if (room.puzzle != null) startPuzzle(r);
    else travel(r);
  }

  /** Tiefengang: pay the Ebene, record it, and descend one Ebene deeper. */
  private void floorDone(Run r) {
    int cleared = r.floor, week = DeepDescent.currentWeek();
    Random rnd = new Random(r.id.getMostSignificantBits() ^ cleared * 0x9E3779B97F4A7C15L);
    for (Player p : online(r)) {
      boolean[] record = {false};
      plugin.change(
          p,
          data -> {
            List<String> lines = DeepDescent.reward(data, r.zone, cleared, rnd);
            record[0] = DeepDescent.record(data, cleared, week);
            return "EBENE " + cleared + " geschafft · " + String.join(" · ", lines);
          });
      plugin.passXp(p, DeepDescent.bossFloor(cleared) ? DeepPass.XP_BOSS : DeepPass.XP_KILL * 3);
      if (DeepDescent.bossFloor(cleared)) plugin.relicDrop(p, Relics.Part.PERLE, 0);
      if (record[0])
        plugin.tell(p, "★ Neuer Wochenrekord im Tiefengang: Ebene " + cleared + "! Rangliste: /df top");
    }
    r.floor++;
    r.zone = DeepDescent.zone(r.floor);
    r.level = DeepDescent.level(r.floor);
    r.totalWaves = DeepDescent.waves(r.floor);
    r.wave = 0;
    r.roomWave = 0;
    boolean newBand = DeepDescent.band(r.floor) != DeepDescent.band(cleared);
    for (Player p : online(r)) {
      p.addPotionEffect(
          new org.bukkit.potion.PotionEffect(
              org.bukkit.potion.PotionEffectType.DARKNESS, 50, 0, false, false));
      p.showTitle(
          bigTitle(
              "EBENE " + r.floor,
              DeepDescent.bossFloor(r.floor) ? NamedTextColor.RED : NamedTextColor.AQUA,
              DeepDescent.bandName(r.floor)
                  + (DeepDescent.bossFloor(r.floor) ? " · BOSS-EBENE" : "")
                  + (newBand ? " · neues Gestein" : ""),
              40));
      p.playSound(p.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 1, .6f);
      p.playSound(p.getLocation(), Sound.BLOCK_DEEPSLATE_BREAK, 1, .5f);
    }
    if (newBand) repaint(r);
    r.stage = Stage.COUNTDOWN;
    r.deadline = tick + 120;
  }

  /** Re-paints the whole arena at once (about 15.000 blocks) in the new depth band's stone. */
  private void repaint(Run r) {
    World world = plugin.mines().world();
    for (int[] b : r.boxes)
      for (int x = b[0]; x <= b[3]; x++)
        for (int z = b[1]; z <= b[4]; z++)
          for (int y = b[2]; y <= b[5]; y++) {
            DungeonPlan.Paint paint = r.plan.paint(x, y, z);
            if (paint == null || paint == DungeonPlan.Paint.AIR) continue;
            world.getBlockAt(r.x + x, 65 + y, -512 + z).setBlockData(block(r, paint, x, y, z), false);
          }
  }

  /** Start a Tiefengang for the player's party (or alone). */
  public void startDeep(Player leader) {
    if (active(leader)) throw new IllegalArgumentException("Du bist schon in einem Dungeon.");
    if (parties.get(leader.getUniqueId()) == null) {
      parties.create(leader.getUniqueId());
      parties.ready(leader.getUniqueId());
    }
    PartyBook.Party own = parties.get(leader.getUniqueId());
    if (own.members.size() == 1) own.ready.add(leader.getUniqueId());
    if (!own.leader.equals(leader.getUniqueId()))
      throw new IllegalArgumentException("Nur der Partyleiter kann den Tiefengang starten.");
    List<UUID> roster = parties.roster(leader.getUniqueId());
    // Network parties can be bigger than a vault: at most four go in.
    if (roster.size() > PartyBook.LIMIT)
      throw new IllegalArgumentException(
          "Ein Gewölbe fasst höchstens " + PartyBook.LIMIT + " Spieler – deine Party hat " + roster.size() + ".");
    for (UUID id : roster) {
      Player p = Bukkit.getPlayer(id);
      if (p == null
          || !plugin.playing(p)
          || p.isDead()
          || p.getGameMode() != GameMode.SURVIVAL
          || plugin.combat().fighting(p)
          || active(p))
        throw new IllegalArgumentException(
            "Alle müssen online, im Überlebensmodus und außerhalb eines Kampfes sein.");
      Profile data = plugin.profile(p);
      if (!DeepDescent.unlocked(data))
        throw new IllegalArgumentException(
            p.getName() + " muss zuerst einen Dungeon gewinnen, dann öffnet sich der Tiefengang.");
    }
    int slot = 0;
    while (runs.containsKey(slot)) slot++;
    if (slot >= 4)
      throw new IllegalArgumentException("Alle vier Gewölbe sind belegt. Bitte kurz warten.");
    Run r = Run.endless(slot, DeepDescent.zone(1), roster);
    r.prestige = partyPrestige(roster);
    r.started = tick;
    runs.put(slot, r);
    for (UUID id : roster) {
      Player p = Bukkit.getPlayer(id);
      plugin.combat().clear(p, false);
      p.closeInventory();
      membership.put(id, r);
      p.showBossBar(r.bar);
      plugin.profile(p).deepRuns++;
    }
    own.ready.clear();
    say(
        r,
        "Der Tiefengang öffnet sich … Gruppe: "
            + roster.size()
            + " · Alle beginnen in der Eisenmine, alle fünf Ebenen geht es eine Mine tiefer."
            + " Jede fünfte Ebene hat einen Boss. Wie tief kommt ihr?");
  }

  private void updateBar(Run r) {
    DungeonPlan.Room room = room(r);
    if (r.endless) {
      String what =
          r.stage == Stage.COUNTDOWN
              ? "Nächste Welle in " + Math.max(0, (r.deadline - tick) / 20) + " s"
              : r.mobs.stream()
                  .filter(m -> m.brain != null)
                  .findFirst()
                  .map(m -> m.brain.status(tick))
                  .orElse("Welle " + r.wave + "/" + r.totalWaves + " · Gegner " + r.mobs.size() + " +" + r.pending);
      r.bar.name(
          Component.text(
              "TIEFENGANG · Ebene "
                  + r.floor
                  + " · "
                  + DeepDescent.bandName(r.floor)
                  + (DeepDescent.bossFloor(r.floor) ? " · BOSS" : "")
                  + " · "
                  + what));
      r.bar.progress((float) Math.clamp(r.wave / (double) Math.max(1, r.totalWaves), 0, 1));
      return;
    }
    String label =
        switch (r.stage) {
          case TRAVEL ->
              r.room + 1 < r.plan.mainRooms
                  ? "Tor offen: weiter in "
                      + roomName(r, r.plan.rooms.get(r.room + 1))
                      + (room.sideRoom >= 0 && r.branchOpen[r.room] ? " · Nebenraum offen" : "")
                  : "";
          case SIDE -> "Optionale Prüfung · " + r.mobs.size() + " Elitegegner";
          case PUZZLE -> puzzleLabel(r);
          case COUNTDOWN -> "Nächste Welle in " + Math.max(0, (r.deadline - tick) / 20) + " s";
          default ->
              r.mobs.stream()
                  .filter(m -> m.brain != null)
                  .findFirst()
                  .map(m -> m.brain.status(tick))
                  .orElse(
                      "Welle "
                          + r.wave
                          + "/"
                          + r.totalWaves
                          + " · Gegner "
                          + r.mobs.size()
                          + " +"
                          + r.pending);
        };
    r.bar.name(
        Component.text(
            roomName(r, room)
                + " · Raum "
                + (r.room + 1)
                + "/"
                + r.plan.mainRooms
                + " · L"
                + r.level
                + " · "
                + label
                + " · "
                + Math.max(0, (r.timeTicks - tick + r.started) / 1200)
                + " Min"));
    r.bar.progress(
        (float)
            Math.clamp(
                (r.room + (r.stage == Stage.TRAVEL ? 1 : .5)) / (double) r.plan.mainRooms, 0, 1));
  }

  private final Map<String, org.bukkit.block.data.BlockData> blockCache = new HashMap<>();

  private final Map<String, org.bukkit.block.data.BlockData> deepPalette = new HashMap<>();

  private org.bukkit.block.data.BlockData block(Run r, DungeonPlan.Paint paint, int x, int y, int z) {
    if (r.endless
        && (paint == DungeonPlan.Paint.WALL
            || paint == DungeonPlan.Paint.VAULT
            || paint == DungeonPlan.Paint.CEILING
            || paint == DungeonPlan.Paint.FLOOR
            || paint == DungeonPlan.Paint.PILLAR)) {
      // Tiefengang: every five Ebenen the arena takes on the stone of the next mine.
      String[] rock = MineBlueprint.rock(DeepDescent.band(r.floor));
      int pick =
          paint == DungeonPlan.Paint.FLOOR
              ? Math.floorMod(x * 3 + z * 5, 2)
              : Math.floorMod(x * 7 + y * 3 + z * 5 + (x ^ z), rock.length);
      return deepPalette.computeIfAbsent(rock[pick], v -> Bukkit.createBlockData("minecraft:" + v));
    }
    DungeonPlan.Room room = r.plan.roomAt(x, z);
    int style = room == null ? 0 : room.role == DungeonPlan.Role.BOSS ? 2 : room.index % 3;
    boolean crack = Math.floorMod(x * 31 + y * 17 + z * 7, 13) == 0;
    Material base =
        switch (paint) {
          case AIR -> Material.AIR;
          case WALL, CEILING ->
              crack
                  ? Material.CRACKED_STONE_BRICKS
                  : new Material[] {
                        Material.STONE_BRICKS,
                        Material.DEEPSLATE_BRICKS,
                        Material.POLISHED_BLACKSTONE_BRICKS
                      }
                      [style];
          case FLOOR ->
              crack
                  ? Material.CRACKED_STONE_BRICKS
                  : new Material[] {
                        Material.POLISHED_ANDESITE,
                        Material.DEEPSLATE_TILES,
                        Material.POLISHED_BLACKSTONE
                      }
                      [style];
          case PATH ->
              Math.floorMod(x + z, 4) == 0
                  ? Material.CHISELED_STONE_BRICKS
                  : Material.DEEPSLATE_TILES;
          case STAIR_N, STAIR_E, STAIR_S, STAIR_W -> Material.STONE_BRICK_STAIRS;
          case LIGHT -> Material.SEA_LANTERN;
          case ACCENT -> DungeonLayout.accent(r.zone);
          case PILLAR -> Material.POLISHED_BASALT;
          case DECOR -> Material.CHISELED_TUFF_BRICKS;
          case VAULT ->
              new Material[] {
                    Material.STONE_BRICKS, Material.DEEPSLATE_BRICKS, Material.POLISHED_BLACKSTONE_BRICKS
                  }
                  [style];
          case RIB -> style == 0 ? Material.POLISHED_DEEPSLATE : Material.POLISHED_BLACKSTONE;
          case TRIM ->
              new Material[] {
                    Material.POLISHED_ANDESITE, Material.POLISHED_DEEPSLATE, Material.POLISHED_BLACKSTONE
                  }
                  [style];
          case CHAIN -> Material.CHAIN;
          case LANTERN -> r.variant == DungeonVariant.FROSTKRYPTA ? Material.SOUL_LANTERN : Material.LANTERN;
          case WEB -> Material.COBWEB;
          case PIT_FLOOR ->
              switch (r.variant) {
                case GLUTSCHMIEDE -> Material.MAGMA_BLOCK;
                case FROSTKRYPTA -> Material.BLUE_ICE;
                default -> Material.SOUL_SOIL;
              };
        };
    Material material = DungeonLayout.remap(r.variant, base);
    String facing =
        switch (paint) {
          case STAIR_N -> "north";
          case STAIR_E -> "east";
          case STAIR_S -> "south";
          case STAIR_W -> "west";
          default -> null;
        };
    String key = material.name() + (facing == null ? "" : ":" + facing);
    if (paint == DungeonPlan.Paint.LANTERN)
      return blockCache.computeIfAbsent(
          key + ":hanging",
          k -> Bukkit.createBlockData(material.getKey() + "[hanging=true]"));
    return blockCache.computeIfAbsent(
        key,
        k ->
            facing == null
                ? material.createBlockData()
                : Bukkit.createBlockData(
                    material, data -> ((org.bukkit.block.data.Directional) data).setFacing(org.bukkit.block.BlockFace.valueOf(facing.toUpperCase(Locale.ROOT)))));
  }

  private void build(Run r) {
    int budget = 1600;
    while (budget > 0 && r.boxIndex < r.boxes.size()) {
      int[] b = r.boxes.get(r.boxIndex);
      int w = b[3] - b[0] + 1, d = b[4] - b[1] + 1, h = b[5] - b[2] + 1;
      long total = (long) w * d * h;
      for (; budget > 0 && r.boxCursor < total; budget--, r.boxCursor++) {
        int x = b[0] + (int) (r.boxCursor % w);
        int z = b[1] + (int) (r.boxCursor / w % d);
        int y = b[2] + (int) (r.boxCursor / ((long) w * d));
        DungeonPlan.Paint paint = r.plan.paint(x, y, z);
        if (paint == null) continue;
        int bx = r.x + x, bz = -512 + z;
        long chunkKey = ((long) (bz >> 4) << 32) | ((bx >> 4) & 0xffffffffL);
        if (r.chunks.add(chunkKey))
          plugin.mines().world().getChunkAt(bx >> 4, bz >> 4).addPluginChunkTicket(plugin);
        plugin
            .mines()
            .world()
            .getBlockAt(bx, 65 + y, bz)
            .setBlockData(block(r, paint, x, y, z), false);
      }
      if (r.boxCursor >= total) {
        r.boxIndex++;
        r.boxCursor = 0;
      }
    }
    if (r.boxIndex < r.boxes.size()) return;
    furnish(r);
    if (r.diagnostic) {
      r.stage = Stage.COUNTDOWN;
      return;
    }
    for (Player p : online(r)) {
      if (!plugin.playing(p)) continue;
      p.teleport(checkpoint(r, false));
      plugin.combat().applyStats(p);
      CombatEngine.setHealth(p, Gear.stats(plugin.profile(p)).health());
      p.setFoodLevel(20);
    }
    if (r.endless) {
      say(r, "Tiefengang: eine Arena, endlose Ebenen. /df dungeon leave beendet den Lauf – alles Verdiente bleibt.");
      startRoom(r);
      return;
    }
    say(
        r,
        r.variant.title
            + ": "
            + r.plan.mainRooms
            + " Räume · "
            + r.plan.rooms.stream().filter(x -> x.puzzle != null).count()
            + " Rätsel"
            + (r.plan.rooms.size() > r.plan.mainRooms ? " · Nebenräume zu entdecken" : "")
            + ". Rote Kreise und orange Strahlen kündigen Angriffe an. Ausweichen: Sneak +"
            + " Rechtsklick mit Waffe. /df dungeon leave beendet deinen Lauf.");
    startRoom(r);
  }

  /** Gates, labels, puzzles, side rooms, braziers: everything after the raw blocks. */
  private void furnish(Run r) {
    for (DungeonPlan.Room room : r.plan.rooms) {
      if (room.role != DungeonPlan.Role.SIDE) {
        if (room.in != null) gate(r, room, room.in, false);
        if (room.out != null) gate(r, room, room.out, false);
        if (room.sideDoor != null) gate(r, room, room.sideDoor, false);
      }
      DungeonPlan.Dir entry = room.in == null ? DungeonPlan.Dir.S : room.in;
      label(
          r,
          room,
          entry.dx * (room.hw - 2),
          Math.min(4, room.height - 2),
          entry.dz * (room.hd - 2),
          roomName(r, room)
              + (room.puzzle != null ? "\nRätsel: " + room.puzzle.title : "")
              + (room.role == DungeonPlan.Role.BOSS ? "\nEndboss: " + r.variant.boss(r.zone) : ""),
          NamedTextColor.GOLD);
      if (room.puzzle != null) setupPuzzle(r, room);
      if (room.keyBarrel) {
        org.bukkit.block.Block barrel = in(r, room, -(room.hw - 2), 0, -(room.hd - 2)).getBlock();
        barrel.setType(Material.BARREL, false);
        r.clickables.put(barrel, "key");
        label(r, room, -(room.hw - 2), 1.6, -(room.hd - 2), "Verstaubtes Fass · untersuchen", NamedTextColor.GOLD);
      }
      if (room.role == DungeonPlan.Role.SIDE) setupSide(r, room);
      if (r.variant == DungeonVariant.FROSTKRYPTA
          && room.role != DungeonPlan.Role.SIDE
          && room.shape != DungeonPlan.Shape.GAUNTLET) {
        int o = Math.min(room.hw, room.hd) - (room.shape == DungeonPlan.Shape.ARENA ? 6 : 4);
        for (int side = -1; side <= 1; side += 2) {
          Location at = in(r, room, side * o, 0, -side * o);
          at.getBlock().setType(Material.POLISHED_BLACKSTONE_WALL, false);
          at.clone().add(0, 1, 0).getBlock().setType(Material.CAMPFIRE, false);
          r.braziers.add(at);
          if (side < 0) label(r, room, side * o, 2.6, -side * o, "GLUTBECKEN\nHier aufwärmen", NamedTextColor.GOLD);
        }
      }
    }
  }

  private void label(
      Run r, DungeonPlan.Room room, double x, double y, double z, String text, NamedTextColor color) {
    r.decorations.add(
        plugin
            .mines()
            .world()
            .spawn(
                in(r, room, x, y, z),
                TextDisplay.class,
                d -> {
                  d.text(Component.text(text, color));
                  d.setBillboard(Display.Billboard.CENTER);
                  d.setPersistent(false);
                }));
  }

  /** Room entrance point (inside, in front of the entry door). */
  private Location entrance(Run r, DungeonPlan.Room room) {
    DungeonPlan.Dir entry = room.in == null ? DungeonPlan.Dir.S : room.in;
    return in(r, room, entry.dx * (room.hw - 3), .1, entry.dz * (room.hd - 3));
  }

  private Location checkpoint(Run r, boolean down) {
    DungeonPlan.Room room = room(r);
    if (down) return standable(at(r, room.hw - 2, 0, 0));
    Location l = entrance(r, room);
    l.setY(65 + room.floor);
    return standable(l);
  }

  /**
   * Moves a spot up until feet and head are free. The boss hall has a raised amethyst floor in the
   * viewing alcove; downed players used to be placed inside it.
   */
  private static Location standable(Location l) {
    Location at = l.clone();
    for (int i = 0; i < 6; i++) {
      if (at.getBlock().isPassable() && at.clone().add(0, 1, 0).getBlock().isPassable()) return at;
      at.add(0, 1, 0);
    }
    return l;
  }

  private void gate(Run r, DungeonPlan.Room room, DungeonPlan.Dir d, boolean open) {
    int x = room.doorX(d), z = room.doorZ(d);
    for (int lateral = -1; lateral <= 1; lateral++)
      for (int y = 0; y < 4; y++)
        worldAt(r, x + (d.alongX() ? 0 : lateral), room.floor + y, z + (d.alongX() ? lateral : 0))
            .getBlock()
            .setType(open ? Material.AIR : Material.IRON_BARS, false);
    Location at = worldAt(r, x, room.floor + 1, z);
    at.getWorld().playSound(at, Sound.BLOCK_IRON_DOOR_OPEN, 1, .6f);
  }

  private void travel(Run r) {
    r.stage = Stage.TRAVEL;
    DungeonPlan.Room room = room(r);
    if (room.out != null) {
      gate(r, room, room.out, true);
      DungeonPlan.Room next = r.plan.rooms.get(r.room + 1);
      gate(r, next, next.in, true);
    }
    if (room.sideRoom >= 0 && !r.branchOpen[r.room]) sideGate(r, true);
    if (room.waves == 0 || !r.shrinesBuilt.add(r.room)) {
      say(r, "Das Tor ist offen! Geht gemeinsam weiter.");
      return;
    }
    r.shrineRoom = r.room;
    r.shrines.clear();
    List<Location> spots = shrineSpots(r, room);
    Material[] stones = {
      Material.RED_GLAZED_TERRACOTTA, Material.BLUE_GLAZED_TERRACOTTA, Material.LIME_GLAZED_TERRACOTTA
    };
    for (int i = 0; i < spots.size(); i++) {
      org.bukkit.block.Block shrine = spots.get(i).getBlock();
      shrine.setType(stones[i], false);
      r.shrines.add(shrine);
      final String title = BLESSINGS[i];
      r.decorations.add(
          plugin
              .mines()
              .world()
              .spawn(
                  spots.get(i).clone().add(.5, 2, .5),
                  TextDisplay.class,
                  display -> {
                    display.text(
                        Component.text(
                            title + "\nEin Segen pro Raum · Rechtsklick", NamedTextColor.AQUA));
                    display.setBillboard(Display.Billboard.CENTER);
                    display.setPersistent(false);
                  }));
    }
    say(
        r,
        "Das Tor ist offen! Geht gemeinsam weiter."
            + (room.sideRoom >= 0 ? " Ein Nebenraum ist jetzt auch offen." : ""));
    for (Player member : online(r)) offerBlessing(r, member);
  }

  static final String[] BLESSINGS = {
    "KRAFT · +8% Schaden", "SCHUTZ · -8% erlittener Schaden", "QUELLE · 35% Leben heilen"
  };

  /** Three free floor spots along a wall without a door, or none (the chat buttons still work). */
  private List<Location> shrineSpots(Run r, DungeonPlan.Room room) {
    for (int inset = 2; inset <= 5; inset++)
      for (int spacing : new int[] {6, 4, 3})
        for (DungeonPlan.Dir d : DungeonPlan.Dir.values()) {
          if (d == room.in || d == room.out || d == room.sideDoor) continue;
          int depth = (d.alongX() ? room.hw : room.hd) - inset;
          int half = (d.alongX() ? room.hd : room.hw) - 2;
          if (depth < 2 || half < spacing) continue;
          List<Location> spots = new ArrayList<>();
          for (int k = -1; k <= 1; k++) {
            int x = room.cx + d.dx * depth + (d.alongX() ? 0 : k * spacing);
            int z = room.cz + d.dz * depth + (d.alongX() ? k * spacing : 0);
            org.bukkit.block.Block b = worldAt(r, x, room.floor, z).getBlock();
            if (!b.getType().isAir()
                || !b.getRelative(0, 1, 0).getType().isAir()
                || !b.getRelative(0, -1, 0).getType().isSolid()) break;
            spots.add(b.getLocation());
          }
          if (spots.size() == 3) return spots;
        }
    return List.of();
  }

  /** Clickable blessing choice in chat, so a blessing can always be picked. */
  private void offerBlessing(Run r, Player p) {
    if (r.shrineRoom < 0 || r.blessings.chosen(p.getUniqueId(), r.shrineRoom)) return;
    Component line = Component.text("Segen wählen » ", NamedTextColor.AQUA);
    NamedTextColor[] colors = {NamedTextColor.RED, NamedTextColor.BLUE, NamedTextColor.GREEN};
    for (int i = 0; i < 3; i++)
      line =
          line.append(
                  Component.text("[" + BLESSINGS[i] + "]", colors[i])
                      .clickEvent(
                          net.kyori.adventure.text.event.ClickEvent.runCommand(
                              "/df dungeon segen " + (i + 1)))
                      .hoverEvent(
                          net.kyori.adventure.text.event.HoverEvent.showText(
                              Component.text("Ein Segen pro Raum", NamedTextColor.GRAY))))
              .append(Component.text(" "));
    p.sendMessage(line);
  }

  private void bless(Run r, Player p, int i) {
    if (r.shrineRoom < 0) {
      plugin.tell(p, "Segen gibt es, sobald ein Kampfraum geschafft ist.");
      return;
    }
    if (down(p)) return;
    double max = Gear.stats(plugin.profile(p)).health();
    if (i == 2 && p.getHealth() >= max) {
      plugin.tell(p, "Du bist bereits vollständig geheilt. Wähle Kraft oder Schutz.");
      return;
    }
    if (!r.blessings.choose(p.getUniqueId(), r.shrineRoom, i)) {
      plugin.tell(p, "Du hast den Segen dieses Raums bereits gewählt.");
      return;
    }
    if (i == 2) CombatEngine.setHealth(p, Math.min(max, p.getHealth() + max * .35));
    plugin.tell(
        p,
        new String[] {
              "Kraftsegen: +8% Schaden für diesen Lauf (bis zu 3× stapelbar).",
              "Schutzsegen: -8% erlittener Schaden für diesen Lauf (bis zu 3× stapelbar).",
              "Die Quelle heilt 35% deines maximalen Lebens."
            }
            [i]);
    p.playSound(p.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1, 1.2f);
  }


  private void sideGate(Run r, boolean open) {
    DungeonPlan.Room room = room(r);
    if (room.sideDoor == null) return;
    r.branchOpen[r.room] = open;
    gate(r, room, room.sideDoor, open);
  }


  private void startChallenge(Run r, boolean curse, DungeonPlan.Room side) {
    r.challengeAttempted = true;
    r.pendingOptional = curse ? AdventureRewards.CURSE : AdventureRewards.ELITE;
    r.stage = Stage.SIDE;
    DungeonPlan.Room room = room(r);
    if (room.out != null) {
      gate(r, room, room.out, false);
      DungeonPlan.Room next = r.plan.rooms.get(r.room + 1);
      gate(r, next, next.in, false);
    }
    for (int i = 0; i < r.size + 2; i++) {
      spawnAt(r, false, i % 4, in(r, side, -4 + (i % 3) * 4, 0, -3 + (i / 3) * 3), side.index);
      Enemy e = r.mobs.getLast();
      e.elite = true;
      e.hp =
          e.max =
              DungeonRules.health(r.zone, r.mode, r.size, Math.max(1, r.wave), false, r.level)
                  * (curse ? 2 : 1.4);
      e.mob.customName(Component.text(enemyName(e), NamedTextColor.RED));
      health(e);
    }
    say(
        r,
        curse
            ? "Fluchprüfung gestartet! Besiegt die Elite für zwei Bonusfunde."
            : "Eliteprüfung gestartet! Besiegt die Elite für einen Bonusfund.");
  }

  private void completeChallenge(Run r) {
    r.optionalFlags |= r.pendingOptional;
    r.pendingOptional = 0;
    revive(r);
    travel(r);
    say(r, "Prüfung bestanden! Die Beute wird nach dem Endboss ausgezahlt.");
  }

  private void rescue(Run r, DungeonPlan.Room prison) {
    if ((r.optionalFlags & AdventureRewards.RESCUE) != 0 || r.captive == null) return;
    for (int x = -1; x <= 1; x++)
      for (int z = -1; z <= 1; z++)
        for (int y = 0; y < 3; y++)
          if (x != 0 || z != 0) in(r, prison, x, y, z).getBlock().setType(Material.AIR, false);
    r.captive.customName(Component.text("Bergarbeiter gerettet!", NamedTextColor.GREEN));
    r.optionalFlags |= AdventureRewards.RESCUE;
    say(r, "Bergarbeiter befreit! Bei Abschluss: Bonusfund und dauerhaft 20% Händlerrabatt.");
  }

  private void takeKey(Run r, org.bukkit.block.Block barrel) {
    if (r.key) return;
    r.key = true;
    barrel.setType(Material.AIR, false);
    r.clickables.remove(barrel);
    say(r, "Gruppenschlüssel gefunden! Er öffnet die Schatzkammer in einem der nächsten Räume.");
  }

  private void takeTreasure(Run r, org.bukkit.block.Block chest) {
    if (!r.key || (r.optionalFlags & AdventureRewards.TREASURE) != 0) return;
    r.optionalFlags |= AdventureRewards.TREASURE;
    chest.setType(Material.BARREL, false);
    r.clickables.remove(chest);
    say(r, "Schatz gesichert! Ein zusätzlicher Bonusfund wartet nach dem Endboss.");
  }

  /** Contents of an optional side room. */
  private void setupSide(Run r, DungeonPlan.Room side) {
    switch (side.side) {
      case CHALLENGE -> {
        org.bukkit.block.Block elite = in(r, side, -3, 0, -3).getBlock();
        org.bukkit.block.Block curse = in(r, side, 3, 0, -3).getBlock();
        elite.setType(Material.RED_GLAZED_TERRACOTTA, false);
        curse.setType(Material.PURPLE_GLAZED_TERRACOTTA, false);
        r.clickables.put(elite, "elite");
        r.clickables.put(curse, "curse");
        label(r, side, -3, 1.6, -3, "ELITEPRÜFUNG · 1 Bonusfund\nRechtsklick · Gruppenleiter", NamedTextColor.GOLD);
        label(r, side, 3, 1.6, -3, "FLUCHPRÜFUNG · 2 Bonusfunde\nDoppelte Gegner-LP", NamedTextColor.GOLD);
      }
      case PRISON -> {
        for (int x = -1; x <= 1; x++)
          for (int z = -1; z <= 1; z++)
            for (int y = 0; y < 3; y++)
              if (x != 0 || z != 0) in(r, side, x, y, z).getBlock().setType(Material.IRON_BARS, false);
        in(r, side, 0, 3, 0).getBlock().setType(Material.IRON_BARS, false);
        org.bukkit.block.Block lock = in(r, side, 0, 0, -4).getBlock();
        lock.setType(Material.LODESTONE, false);
        r.clickables.put(lock, "lock");
        label(r, side, 0, 1.6, -4, "ZELLENSCHLOSS · Rechtsklick\nRettung: Bonusfund + Händlerrabatt", NamedTextColor.GOLD);
        r.captive =
            plugin
                .mines()
                .world()
                .spawn(
                    in(r, side, 0, 0, 0),
                    Villager.class,
                    false,
                    v -> {
                      v.setAI(false);
                      v.setAdult();
                      v.setInvulnerable(true);
                      v.setSilent(true);
                      v.setPersistent(false);
                      v.customName(Component.text("Gefangener Bergarbeiter", NamedTextColor.GOLD));
                      v.setCustomNameVisible(true);
                    });
        r.decorations.add(r.captive);
      }
      case TREASURE -> {
        org.bukkit.block.Block chest = in(r, side, 0, 0, 0).getBlock();
        chest.setBlockData(Bukkit.createBlockData("minecraft:chest[facing=south]"), false);
        r.clickables.put(chest, "treasure");
        label(r, side, 0, 1.6, 0, "SCHATZKAMMER · Schlüssel benötigt\nRechtsklick zum Öffnen", NamedTextColor.GOLD);
      }
    }
  }

  @EventHandler
  public void captiveInteraction(PlayerInteractEntityEvent e) {
    if (runs.values().stream().anyMatch(r -> r.captive == e.getRightClicked())) {
      e.setCancelled(true);
      plugin.tell(e.getPlayer(), "Das Zellenschloss vor dem Käfig öffnet die Tür.");
    }
  }

  @EventHandler(priority = EventPriority.LOW)
  public void optional(PlayerInteractEvent e) {
    Player p = e.getPlayer();
    Run r = membership.get(p.getUniqueId());
    if (r == null
        || down(p)
        || e.getHand() != EquipmentSlot.HAND
        || !e.getAction().isRightClick()
        || e.getClickedBlock() == null) return;
    String action = r.clickables.get(e.getClickedBlock());
    if (action == null || !Set.of("elite", "curse", "lock", "treasure", "key").contains(action)) return;
    e.setCancelled(true);
    if (p.getLocation().distanceSquared(e.getClickedBlock().getLocation()) > 36) return;
    DungeonPlan.Room here = r.plan.roomAt(
        e.getClickedBlock().getX() - r.x, e.getClickedBlock().getZ() + 512);
    switch (action) {
      case "key" -> takeKey(r, e.getClickedBlock());
      case "treasure" -> {
        if (!r.key)
          plugin.tell(p, "Verschlossen. Der Schlüssel liegt in einem Fass in einem der Räume davor.");
        else takeTreasure(r, e.getClickedBlock());
      }
      case "lock" -> {
        if (here != null && r.branchOpen[here.parent]) rescue(r, here);
      }
      default -> {
        if (here == null || r.stage != Stage.TRAVEL || r.room != here.parent || r.challengeAttempted) {
          plugin.tell(p, "Diese Prüfung ist noch nicht verfügbar oder bereits gewählt.");
          return;
        }
        PartyBook.Party party = parties.get(p.getUniqueId());
        if (party != null && !party.leader.equals(p.getUniqueId())) {
          plugin.tell(p, "Nur der Gruppenleiter startet die Prüfung.");
          return;
        }
        if (living(r).stream()
            .anyMatch(m -> !inRoom(r, here, m.getLocation(), 0) && !inRoom(r, room(r), m.getLocation(), 0))) {
          plugin.tell(p, "Alle müssen zuerst in diesen Raum oder die Prüfungskammer kommen.");
          return;
        }
        startChallenge(r, action.equals("curse"), here);
      }
    }
  }

  private void enterNextRoom(Run r) {
    DungeonPlan.Room from = room(r);
    if (from.out != null) gate(r, from, from.out, false);
    if (from.sideRoom >= 0 && r.branchOpen[r.room]) sideGate(r, false);
    r.room++;
    DungeonPlan.Room room = room(r);
    gate(r, room, room.in, false);
    for (UUID id : r.down) {
      Player p = Bukkit.getPlayer(id);
      if (p != null) p.teleport(checkpoint(r, true));
    }
    say(r, roomName(r, room) + " erreicht. Bereitet euch vor!");
    startRoom(r);
  }

  /** A room begins with its waves, then its puzzle, then the gate opens. */
  private void startRoom(Run r) {
    r.roomWave = 0;
    DungeonPlan.Room room = room(r);
    if (room.waves > 0) countdown(r);
    else if (room.puzzle != null) startPuzzle(r);
    else travel(r);
  }

  private void countdown(Run r) {
    r.stage = Stage.COUNTDOWN;
    r.deadline = tick + 100;
  }

  private void beginWave(Run r) {
    r.wave++;
    r.stage = Stage.WAVE;
    r.spawned = 0;
    r.reinforcements = 0;
    r.pending = DungeonRules.count(r.wave, r.size, r.level);
    Minibosses.Kind guard = guardFor(r);
    if (guard != null) r.pending = Math.max(1, r.pending / 2);
    refill(r);
    if (guard != null) spawnGuard(r, guard);
    say(
        r,
        r.endless && !bossWave(r)
            ? "Ebene " + r.floor + " · Welle " + r.wave + "/" + r.totalWaves + " · " + DeepDescent.bandName(r.floor)
            : bossWave(r)
            ? (r.endless ? "BOSS-EBENE " + r.floor + " · " : "ENDWELLE · ")
                + r.variant.boss(r.zone)
                + " erwacht! Drei Phasen – weiche seinen Angriffen aus und schlag bei"
                + " SCHWACHSTELLE zu."
            : "Welle "
                + r.wave
                + "/"
                + r.totalWaves
                + " · "
                + DungeonRules.conditionName(r.level)
                + (r.level >= 4 ? " · Jäger lauern auf euch!" : ""));
  }

  private void refill(Run r) {
    DungeonPlan.Room room = room(r);
    double rx = Math.min(11, room.hw - 5), rz = Math.min(10, room.hd - 5);
    while (r.pending > 0 && r.mobs.size() < DungeonRules.activeLimit(r.size)) {
      int ordinal = r.spawned;
      double angle = (ordinal * 2.4 + r.wave) % (Math.PI * 2);
      int kind = DungeonRules.kind(r.level, r.wave, ordinal, r.id.getLeastSignificantBits());
      double x = Math.cos(angle) * rx, z = Math.sin(angle) * rz;
      // Bridge rooms: only on the cross of bridges, never above the pit.
      if (room.shape == DungeonPlan.Shape.BRIDGE) {
        if (Math.abs(x) > Math.abs(z)) z = 0;
        else x = 0;
      }
      spawn(r, bossWave(r) && ordinal == 0, kind, x, z);
      r.pending--;
      r.spawned++;
    }
  }

  /** The wave with the boss: the last one of a dungeon, or of every fifth Tiefengang Ebene. */
  private static boolean bossWave(Run r) {
    return r.wave == r.totalWaves && (!r.endless || DeepDescent.bossFloor(r.floor));
  }

  private void spawn(Run r, boolean boss, int kind, double x, double z) {
    spawnAt(r, boss, kind, at(r, x, 0, z), r.room);
  }

  private void spawnAt(Run r, boolean boss, int kind, Location where, int roomIndex) {
    spawnAt(r, boss, kind, where, roomIndex, false);
  }

  private Enemy spawnAt(Run r, boolean boss, int kind, Location where, int roomIndex, boolean big) {
    Enemy e = new Enemy();
    e.run = r;
    e.room = roomIndex;
    e.boss = boss;
    e.kind = kind;
    e.elite = !boss && DungeonRules.elite(r.level, r.spawned);
    e.hp =
        e.max =
            DungeonRules.health(r.zone, r.mode, r.size, r.wave, boss, r.level)
                * (e.elite ? 1.6 : 1)
                * (r.endless ? DeepDescent.health(r.floor) : 1)
                * Prestige.health(r.prestige);
    e.attackAt = tick + 50 + random.nextInt(40);
    e.mob =
        plugin
            .mines()
            .world()
            .spawn(
                where,
                Husk.class,
                false,
                mob -> {
                  mob.setAdult();
                  mob.getEquipment().clear();
                  mob.setPersistent(false);
                  mob.setSilent(true);
                  mob.setInvisible(true);
                  mob.setShouldBurnInDay(false);
                  mob.setRemoveWhenFarAway(false);
                  mob.setCanPickupItems(false);
                  mob.getAttribute(Attribute.MOVEMENT_SPEED)
                      .setBaseValue(
                          (boss ? .24 : kind == 3 ? .34 : .28)
                              * (DungeonRules.condition(r.level) == 1 ? 1.1 : 1));
                  mob.getAttribute(Attribute.SCALE)
                      .setBaseValue(boss ? 1.55 : big ? 1.25 : kind == 1 ? 1 : .8);
                  mob.getAttribute(Attribute.KNOCKBACK_RESISTANCE).setBaseValue(0);
                  mob.customName(
                      Component.text(enemyName(e) + " · L" + r.level, NamedTextColor.RED));
                  mob.setCustomNameVisible(false);
                });
    r.mobs.add(e);
    enemies.put(e.mob.getUniqueId(), e);
    RailNavigation.allowRails(e.mob);
    e.rig = new MonsterRig(plugin, e.mob.getLocation(), r.zone < 7 ? (r.zone + kind) % 7 : 7 + (r.zone - 7 + kind) % 10, boss || big,
        // Rissjäger: the slim, long-armed hunter body of the mine's Springer.
        kind == 3 ? 4 : kind);
    e.health = new MonsterHealthIndicator(plugin, e.mob.getLocation(), r.members, boss || big);
    health(e);
    return e;
  }

  private void health(Enemy e) {
    if (e.health != null)
      e.health.update(
          e.mob.getLocation(),
          e.rig.labelHeight(),
          enemyName(e) + " · L" + e.run.level,
          e.hp,
          e.max,
          e.boss);
  }

  private String enemyName(Enemy e) {
    if (e.guard != null) return "WÄCHTER · " + e.guard.title;
    return (e.elite ? "ELITE · " : "")
        + (e.boss
            ? e.run.variant.boss(e.run.zone)
            : switch (e.kind) {
              case 0 -> "Sprenger";
              case 1 -> "Strahlenwirker";
              case 2 -> "Heilrufer";
              default -> "Rissjäger";
            });
  }

  private void enemyTick(Enemy e) {
    Run r = e.run;
    health(e);
    if (!e.mob.isValid()) throw new IllegalStateException("Dungeon enemy disappeared");
    List<Player> targets = living(r);
    if (targets.isEmpty()) return;
    Player target =
        targets.stream()
            .min(
                Comparator.comparingDouble(
                    p -> p.getLocation().distanceSquared(e.mob.getLocation())))
            .orElseThrow();
    if (e.boss && r.level >= 6) {
      int phase = e.hp < e.max * .33 ? 2 : e.hp < e.max * .66 ? 1 : 0;
      if (phase > r.reinforcements) {
        r.pending += (phase - r.reinforcements) * (1 + r.size);
        r.reinforcements = phase;
        say(r, "Der Wächter ruft Verstärkung! Noch " + r.pending + " Gegner im Anmarsch.");
      }
    }
    if (e.elite && tick % 10 == 0)
      e.mob
          .getWorld()
          .spawnParticle(Particle.ENCHANT, e.mob.getLocation().add(0, 1.5, 0), 5, .4, .6, .4, 0);
    if (!inside(r, e.mob.getLocation())) e.mob.teleport(in(r, r.plan.rooms.get(e.room), 0, 0, 0));
    e.mob.setTarget(target);
    if (e.guard != null) guardTick(e, targets);
    if (e.boss && (e.brain == null || !e.brain.busy()) && rearCounter(e, targets)) return;
    if (e.boss) {
      if (e.brain == null) {
        e.brain = new BossBrain(arena(r), e.mob, tick);
        r.bossFought = true;
        say(
            r,
            "ENDBOSS: "
                + e.brain.name()
                + "! Achte auf die Warnungen – seinen Angriffen musst du ausweichen (Sneak +"
                + " Rechtsklick = Rolle).");
      }
      e.brain.tick(tick, e.hp, e.max);
      r.bossStruck.addAll(e.brain.struck);
      e.mob.setAware(!e.brain.busy() && tick >= e.recoilAt);
      e.rig.animate(
          e.mob.getLocation(),
          tick,
          e.brain.busy(),
          tick < e.recoilAt,
          e.mob.getVelocity().lengthSquared() > .001);
      if (tick % 30 == 0 && target.getLocation().distanceSquared(e.mob.getLocation()) < 3.5) {
        e.rig.strike(tick);
        hurt(r, target, DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * .7);
      }
      return;
    }
    e.mob.setAware(e.resolveAt == 0 && tick >= e.recoilAt);
    e.rig.animate(
        e.mob.getLocation(),
        tick,
        e.resolveAt > 0,
        tick < e.recoilAt,
        e.mob.getVelocity().lengthSquared() > .001);
    if (e.resolveAt > 0) {
      if (e.spell == 0) circle(e.marker, e.boss ? 4 : 2.7, Color.RED);
      else if (e.spell == 1 || e.spell == 3) beam(e.marker, e.direction, e.spell == 3 ? 7 : 18);
      else circle(e.marker, 5, Color.LIME);
      if (e.secondary != null) circle(e.secondary, 2.7, Color.RED);
      if (tick >= e.resolveAt) {
        for (Player p : targets) {
          Vector d = p.getLocation().toVector().subtract(e.marker.toVector());
          boolean hit =
              e.spell == 0
                  ? d.clone().setY(0).lengthSquared() <= (e.boss ? 16 : 7.29)
                  : (e.spell == 1 || e.spell == 3)
                      && d.dot(e.direction) >= 0
                      && d.dot(e.direction) < (e.spell == 3 ? 7 : 18)
                      && Math.abs(d.getX() * e.direction.getZ() - d.getZ() * e.direction.getX())
                          < 1.2;
          if ((e.spell == 1 || e.spell == 3) && !p.hasLineOfSight(e.mob)) hit = false;
          if (e.secondary != null
              && p.getLocation().toVector().subtract(e.secondary.toVector()).setY(0).lengthSquared()
                  <= 7.29) hit = true;
          if (hit)
            hurt(
                r,
                p,
                DungeonRules.damage(r.zone, r.mode, e.boss, r.level, r.size) * power(e));
        }
        if (e.spell == 3) KnockbackMotion.push(e.mob, e.direction.clone().multiply(4));
        if (e.guard == Minibosses.Kind.SHIELD) {
          e.stunUntil = tick + 50 - 8L * r.mode;
          e.recoilAt = e.stunUntil;
          for (Player m : targets)
            plugin.notice(m, "SCHILD GESENKT – jetzt zuschlagen!", NamedTextColor.GREEN);
        }
        if (e.spell == 2)
          for (Enemy ally : r.mobs)
            if (ally != e && ally.mob.getLocation().distanceSquared(e.marker) < 25) {
              ally.hp = Math.min(ally.max, ally.hp + ally.max * .12);
              health(ally);
            }
        e.resolveAt = 0;
        e.secondary = null;
        e.attackAt = tick + DungeonRules.recovery(r.level, e.boss && e.hp < e.max * .5);
      }
    } else if (tick >= e.attackAt) {
      e.spell = e.boss ? (e.spell + 1) % 3 : e.kind;
      e.marker = e.spell == 0 ? target.getLocation().clone() : e.mob.getLocation().clone();
      e.direction = target.getLocation().toVector().subtract(e.marker.toVector()).setY(0);
      if (e.direction.lengthSquared() < .001) e.direction = new Vector(0, 0, 1);
      else e.direction.normalize();
      if (e.boss && e.spell == 0 && DungeonRules.condition(r.level) == 3) {
        e.secondary =
            targets.size() > 1
                ? targets.get((targets.indexOf(target) + 1) % targets.size()).getLocation().clone()
                : target.getLocation().clone().add(target.getX() > r.x ? -4 : 4, 0, 0);
      }
      e.resolveAt = tick + DungeonRules.warning(r.level, e.boss && e.hp < e.max * .5);
      Vector aim = target.getLocation().toVector().subtract(e.mob.getLocation().toVector()).setY(0);
      if (aim.lengthSquared() > .001)
        e.mob.setRotation(e.mob.getLocation().setDirection(aim).getYaw(), 0);
      e.mob
          .getWorld()
          .playSound(
              e.mob.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, .5f, e.spell == 2 ? 1.5f : .6f);
    }
    // Contact pressure is independently rate limited by CombatEngine's hurt protection.
    if (tick % 30 == 0 && target.getLocation().distanceSquared(e.mob.getLocation()) < 3.5)
      hurt(
          r,
          target,
          DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * .7 * power(e));
  }

  private static double power(Enemy e) {
    return e.guard != null ? Minibosses.DAMAGE : e.elite ? 1.25 : 1;
  }

  // ───────────────────────── Wächter (0.11.0) ─────────────────────────

  /** Guarded main rooms of this run (never in the Tiefengang). */
  private static List<Integer> guardRooms(Run r) {
    if (r.endless || r.plan == null) return List.of();
    List<Integer> fight = new ArrayList<>();
    for (int i = 0; i < r.plan.mainRooms; i++) if (r.plan.rooms.get(i).waves > 0) fight.add(i);
    return Minibosses.rooms(fight, r.plan.mainRooms - 1, r.mode, r.id.getMostSignificantBits());
  }

  /** The guardian that joins this wave: only the last wave of a guarded room. */
  private static Minibosses.Kind guardFor(Run r) {
    if (r.endless || bossWave(r)) return null;
    DungeonPlan.Room room = r.plan.rooms.get(r.room);
    if (r.roomWave != room.waves - 1) return null;
    int order = guardRooms(r).indexOf(r.room);
    return order < 0 ? null : Minibosses.kind(r.id.getLeastSignificantBits(), order);
  }

  private void spawnGuard(Run r, Minibosses.Kind kind) {
    if (kind == Minibosses.Kind.TWINS) {
      Enemy a = guardian(r, kind, at(r, -4, 0, 0), Minibosses.TWIN_HEALTH);
      Enemy b = guardian(r, kind, at(r, 4, 0, 0), Minibosses.TWIN_HEALTH);
      a.twin = b;
      b.twin = a;
    } else guardian(r, kind, at(r, 0, 0, 0), Minibosses.HEALTH);
    String hint = DungeonPuzzles.silent(r.mode) ? "Finde seine Schwäche selbst heraus!" : kind.hint;
    for (Player m : online(r)) {
      m.showTitle(bigTitle("⚔ WÄCHTER: " + kind.title, NamedTextColor.RED, hint, 60));
      m.playSound(m.getLocation(), Sound.ENTITY_WITHER_SPAWN, .5f, 1.4f);
    }
    say(r, "⚔ WÄCHTER: " + kind.title + " – " + hint);
  }

  private Enemy guardian(Run r, Minibosses.Kind kind, Location where, double share) {
    int look =
        switch (kind) {
          case SHIELD -> 3; // charges like a Rissjäger, then lowers the shield
          case CALLER, ROOT -> 1;
          case MIRROR, CHAIN -> 0;
          case TWINS -> 2;
        };
    Enemy e = spawnAt(r, false, look, where, r.room, true);
    e.guard = kind;
    e.elite = false;
    e.born = tick;
    e.cycleAt = tick + (kind == Minibosses.Kind.ROOT ? 100 : 40);
    e.hp =
        e.max =
            DungeonRules.health(r.zone, r.mode, r.size, r.totalWaves, true, r.level)
                * share
                * Prestige.health(r.prestige);
    e.mob.customName(Component.text(enemyName(e) + " · L" + r.level, NamedTextColor.RED));
    health(e);
    return e;
  }

  private void guardTick(Enemy e, List<Player> targets) {
    Run r = e.run;
    Location at = e.mob.getLocation();
    double base = DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * Minibosses.DAMAGE;
    switch (e.guard) {
      case SHIELD -> {
        if (tick < e.stunUntil) {
          if (tick % 6 == 0)
            at.getWorld().spawnParticle(Particle.CRIT, at.clone().add(0, 2.6, 0), 6, .3, .1, .3, 0);
        } else if (tick % 4 == 0) {
          Vector f = at.getDirection().setY(0);
          if (f.lengthSquared() > .001) {
            f.normalize();
            Vector side = new Vector(-f.getZ(), 0, f.getX());
            for (double s = -1; s <= 1; s += .5)
              at.getWorld()
                  .spawnParticle(
                      Particle.ENCHANTED_HIT,
                      at.clone()
                          .add(f.clone().multiply(1.2))
                          .add(side.clone().multiply(s))
                          .add(0, 1.2, 0),
                      1,
                      0,
                      .4,
                      0,
                      0);
          }
        }
      }
      case CALLER -> {
        e.minions.removeIf(m -> !r.mobs.contains(m));
        if (!e.minions.isEmpty()) {
          e.cycleAt = tick + Minibosses.CALL_EVERY;
          if (tick % 10 == 0) {
            circle(at, 1.6, Color.AQUA);
            for (Enemy m : e.minions)
              at.getWorld()
                  .spawnParticle(
                      Particle.SOUL_FIRE_FLAME, m.mob.getLocation().add(0, 2, 0), 2, .2, .2, .2, 0);
          }
        } else if (tick >= e.cycleAt) {
          int n = Minibosses.minions(r.mode, r.size);
          DungeonPlan.Room room = r.plan.rooms.get(e.room);
          double rx = Math.min(8, room.hw - 4), rz = Math.min(8, room.hd - 4);
          for (int i = 0; i < n; i++) {
            double a = Math.PI * 2 * i / n + tick;
            Enemy m =
                spawnAt(
                    r,
                    false,
                    random.nextInt(4),
                    in(r, room, Math.cos(a) * rx, 0, Math.sin(a) * rz),
                    e.room,
                    false);
            m.hp = m.max = m.max * .6;
            health(m);
            e.minions.add(m);
          }
          say(r, e.guard.title + " ruft " + n + " Diener – er ist immun, solange sie leben!");
          at.getWorld().playSound(at, Sound.ENTITY_EVOKER_PREPARE_SUMMON, 1, 1);
        }
      }
      case TWINS -> {
        if (e.twin != null && r.mobs.contains(e.twin) && tick % 8 == 0)
          link(at.clone().add(0, 1.2, 0), e.twin.mob.getLocation().add(0, 1.2, 0), Particle.WITCH);
        if (e.twinFell >= 0) {
          long left = Minibosses.TWIN_WINDOW - (tick - e.twinFell);
          if (tick % 10 == 0)
            for (Player m : targets)
              plugin.notice(
                  m,
                  "Zweiter Zwilling: "
                      + String.format(Locale.GERMAN, "%.1f", Math.max(0, left) / 20.0)
                      + " s!",
                  NamedTextColor.RED);
          if (Minibosses.revive(e.twinFell, tick)) {
            Enemy back = guardian(r, Minibosses.Kind.TWINS, e.twinSpot, Minibosses.TWIN_HEALTH);
            back.hp = back.max * Minibosses.TWIN_REVIVE;
            health(back);
            back.twin = e;
            e.twin = back;
            e.twinFell = -1;
            say(r, "Zu langsam – der Zwilling steht mit halbem Leben wieder auf!");
            at.getWorld().playSound(at, Sound.ENTITY_ZOMBIE_VILLAGER_CURE, .8f, 1.2f);
          }
        }
      }
      case MIRROR -> {
        boolean on = Minibosses.mirrored(tick - e.born, r.mode);
        if (on) {
          if (tick % 3 == 0)
            at.getWorld()
                .spawnParticle(Particle.END_ROD, at.clone().add(0, 1.4, 0), 6, .5, .9, .5, .02);
          if (!e.mirrorShown) {
            e.mirrorShown = true;
            for (Player m : targets) {
              plugin.notice(m, "SPIEGEL! Nicht zuschlagen!", NamedTextColor.WHITE);
              m.playSound(m.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, .7f, 1.8f);
            }
          }
        } else if (e.mirrorShown) {
          e.mirrorShown = false;
          for (Player m : targets)
            plugin.notice(m, "Spiegel erloschen – angreifen!", NamedTextColor.GREEN);
        }
      }
      case CHAIN -> {
        for (Player m : targets) {
          boolean over = Minibosses.tethered(m.getLocation().distance(at));
          if (tick % 5 == 0)
            link(
                at.clone().add(0, 1.2, 0),
                m.getLocation().add(0, 1, 0),
                over ? Particle.FLAME : Particle.SMOKE);
          if (over && tick % 20 == 0) {
            if (hurt(r, m, base * .6) > 0) r.stats.hitBy(m.getUniqueId(), "Kette (" + e.guard.title + ")");
            Vector pull = at.toVector().subtract(m.getLocation().toVector()).setY(0);
            if (pull.lengthSquared() > .01) m.setVelocity(pull.normalize().multiply(.9).setY(.25));
            plugin.notice(m, "KETTE! Zurück zum Kettenbrecher!", NamedTextColor.RED);
          }
        }
      }
      case ROOT -> {
        DungeonPlan.Room room = r.plan.rooms.get(e.room);
        if (e.eruptAt == 0 && tick >= e.cycleAt) {
          e.islands.clear();
          double rx = Math.min(9, room.hw - 4), rz = Math.min(9, room.hd - 4);
          int n = Minibosses.islands(r.size, r.mode);
          for (int i = 0; i < n; i++) {
            double a = random.nextDouble() * Math.PI * 2, f = .35 + random.nextDouble() * .6;
            Location l = in(r, room, Math.cos(a) * rx * f, 0, Math.sin(a) * rz * f);
            e.islands.add(new double[] {l.getX(), l.getZ()});
          }
          e.eruptAt = tick + Minibosses.rootWarning(r.mode);
          for (Player m : targets) {
            plugin.notice(m, "DORNEN! Rauf auf eine grüne Insel!", NamedTextColor.DARK_GREEN);
            m.playSound(m.getLocation(), Sound.BLOCK_SWEET_BERRY_BUSH_PLACE, 1, .6f);
          }
        }
        if (e.eruptAt > 0) {
          if (tick % 4 == 0) {
            for (double[] i : e.islands)
              circle(
                  new Location(at.getWorld(), i[0], at.getY(), i[1]), Minibosses.ISLAND, Color.LIME);
            for (Player m : targets)
              at.getWorld()
                  .spawnParticle(
                      Particle.CRIMSON_SPORE, m.getLocation().add(0, .2, 0), 12, 2.5, 0, 2.5, 0);
          }
          if (tick >= e.eruptAt) {
            for (Player m : targets) {
              if (Minibosses.onIsland(m.getX(), m.getZ(), e.islands)) continue;
              if (hurt(r, m, base * 2.2) > 0) r.stats.hitBy(m.getUniqueId(), "Dornen (" + e.guard.title + ")");
              m.getWorld()
                  .spawnParticle(
                      Particle.BLOCK,
                      m.getLocation(),
                      30,
                      .5,
                      .3,
                      .5,
                      0,
                      Material.MANGROVE_ROOTS.createBlockData());
              m.playSound(m.getLocation(), Sound.ENTITY_PLAYER_HURT_SWEET_BERRY_BUSH, 1, .8f);
            }
            e.eruptAt = 0;
            e.islands.clear();
            e.cycleAt = tick + Minibosses.rootCycle(r.mode);
          }
        }
      }
    }
  }

  private void link(Location from, Location to, Particle particle) {
    Vector step = to.toVector().subtract(from.toVector());
    double length = step.length();
    if (length < .1) return;
    step.multiply(.8 / length);
    Location l = from.clone();
    for (double d = 0; d < length; d += .8) {
      l.getWorld().spawnParticle(particle, l, 1, 0, 0, 0, 0);
      l.add(step);
    }
  }

  /** False when the guardian's rule blocks this hit (the hit is then fully absorbed). */
  private boolean guardAllows(Enemy e, Player p) {
    Run r = e.run;
    String block = null;
    switch (e.guard) {
      case SHIELD -> {
        if (tick >= e.stunUntil) {
          Vector delta = p.getLocation().toVector().subtract(e.mob.getLocation().toVector());
          Vector facing = e.mob.getLocation().getDirection();
          double alignment =
              WeaponRules.facing(delta.getX(), delta.getZ(), facing.getX(), facing.getZ());
          if (!Minibosses.behind(alignment)) block = "Der Schild blockt – greif ihn von hinten an!";
        }
      }
      case CALLER -> {
        e.minions.removeIf(m -> !r.mobs.contains(m));
        if (!e.minions.isEmpty())
          block = "Immun – erst die " + e.minions.size() + " Diener besiegen!";
      }
      case MIRROR -> {
        if (Minibosses.mirrored(tick - e.born, r.mode)) {
          double reflected =
              DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * Minibosses.reflect(r.mode);
          if (hurt(r, p, reflected) > 0)
            r.stats.hitBy(p.getUniqueId(), "Spiegelung (" + e.guard.title + ")");
          p.getWorld()
              .spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1, 0), 12, .3, .5, .3, .05);
          block = "Gespiegelt! Warte, bis er aufhört zu leuchten.";
        }
      }
      default -> {}
    }
    if (block == null) return true;
    plugin.combat().showDamage(p, e.mob.getLocation().add(0, 2.6, 0), 0, false, false, true);
    p.playSound(p.getLocation(), Sound.ITEM_SHIELD_BLOCK, .6f, 1.2f);
    if (tick >= e.warnAt) {
      e.warnAt = tick + 20;
      plugin.notice(p, block, NamedTextColor.GOLD);
    }
    return false;
  }

  private void guardDown(Enemy e) {
    Run r = e.run;
    if (e.guard == Minibosses.Kind.TWINS
        && e.twin != null
        && r.mobs.contains(e.twin)
        && e.twin.hp > 0) {
      e.twin.twinFell = tick;
      e.twin.twinSpot = e.mob.getLocation();
      e.twin.twin = null;
      say(r, "Ein Zwilling fällt – besiegt den anderen in 5 Sekunden!");
      return;
    }
    Minibosses.Kind kind = e.guard;
    say(r, "★ Wächter besiegt: " + kind.title + "! Wächtertruhe für alle.");
    for (Player m : online(r)) {
      Random rnd =
          new Random(
              r.id.getMostSignificantBits()
                  ^ m.getUniqueId().hashCode()
                  ^ (e.room + 1) * 0x9E3779B97F4A7C15L);
      plugin.change(
          m,
          data ->
              "WÄCHTERTRUHE · "
                  + String.join(" · ", Minibosses.chest(data, r.zone, r.mode, r.level, kind, rnd)));
      plugin.passXp(m, DeepPass.XP_KILL * 5);
      m.playSound(m.getLocation(), Sound.BLOCK_CHEST_OPEN, 1, 1.2f);
      plugin.relicDrop(m, Relics.Part.WAECHTERZAHN, r.mode);
    }
  }

  /** Admin test: a guardian of the given kind in the current room. */
  public String debugGuard(Player p, String name) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || r.stage != Stage.WAVE) return "Zuerst in einem Dungeon eine Welle starten.";
    Minibosses.Kind kind = null;
    for (Minibosses.Kind k : Minibosses.Kind.values())
      if (k.name().equalsIgnoreCase(name) || k.title.equalsIgnoreCase(name)) kind = k;
    if (kind == null) return "Wächter: shield, caller, twins, mirror, chain, root";
    spawnGuard(r, kind);
    return "Testmodus: " + kind.title + " erscheint.";
  }

  private BossBrain.Arena arena(Run r) {
    return new BossBrain.Arena() {
      public List<Player> living() {
        return Dungeons.this.living(r);
      }

      public double hurt(Player p, double damage) {
        return Dungeons.this.hurt(r, p, damage);
      }

      public void say(String text) {
        Dungeons.this.say(r, text);
      }

      public Location center() {
        return at(r, 0, 0, 0);
      }

      public double baseDamage() {
        return DungeonRules.damage(r.zone, r.mode, true, r.level, r.size)
            * BossPatterns.modeDamage(r.mode);
      }

      public int mode() {
        return r.mode;
      }

      public void summon(int count) {
        r.summoned.clear();
        for (int i = 0; i < count; i++) {
          double a = Math.PI * 2 * i / count;
          int before = r.mobs.size();
          spawnAt(r, false, i % 4, at(r, Math.cos(a) * 7, 0, Math.sin(a) * 7), r.room);
          if (r.mobs.size() > before) r.summoned.add(r.mobs.getLast());
        }
      }

      public int summonsAlive() {
        r.summoned.removeIf(e -> !r.mobs.contains(e));
        return r.summoned.size();
      }

      public void record(Player p, BossPatterns.Attack attack) {
        r.stats.hitBy(p.getUniqueId(), attack.title);
      }

      public int zone() {
        return r.zone;
      }

      public int variant() {
        return r.variant.ordinal();
      }

      public int level() {
        return r.level;
      }

      public long seed() {
        return r.id.getMostSignificantBits();
      }

      public void danger(Player p, BossPatterns.Attack attack) {
        plugin.drones().danger(p, attack.title);
      }
    };
  }

  /** Admin test: skip straight to the final wave with the boss. */
  /** Admin test: jump the boss of the running fight into the given phase (1–3). */
  public String debugPhase(Player p, int phase) {
    Run r = membership.get(p.getUniqueId());
    if (r == null) return "Zuerst einen Dungeon starten (/df dungeon start).";
    for (Enemy e : r.mobs)
      if (e.boss) {
        e.hp = Math.min(e.hp, e.max * (phase >= 3 ? .3 : phase == 2 ? .6 : 1));
        health(e);
        return "Testmodus: Boss auf Phase " + phase + ".";
      }
    return "Kein Boss im Kampf – erst /df admin boss.";
  }

  public String debugBoss(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || r.stage == Stage.BUILDING || r.stage == Stage.COMPLETE || r.stage == Stage.VICTORY)
      return "Zuerst einen Dungeon starten (/df dungeon start).";
    for (Enemy e : new ArrayList<>(r.mobs)) removeEnemy(e);
    r.pending = 0;
    r.room = r.plan.mainRooms - 1;
    DungeonPlan.Room boss = room(r);
    r.roomWave = boss.waves - 1;
    r.wave = r.totalWaves - 1;
    for (Player m : online(r)) m.teleport(checkpoint(r, false));
    beginWave(r);
    return "Testmodus: Endboss gestartet.";
  }

  /** Admin test: finish the current room, or walk the group into the next one. */
  public String debugSkip(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || r.stage == Stage.BUILDING || r.stage == Stage.COMPLETE || r.stage == Stage.VICTORY)
      return "Zuerst einen Dungeon starten (/df dungeon start).";
    if (r.endless) {
      for (Enemy e : new ArrayList<>(r.mobs)) removeEnemy(e);
      r.pending = 0;
      r.wave = r.totalWaves;
      revive(r);
      floorDone(r);
      return "Testmodus: Ebene übersprungen, jetzt Ebene " + r.floor + ".";
    }
    if (r.stage == Stage.TRAVEL) {
      if (r.room + 1 >= r.plan.mainRooms) return "Das ist der letzte Raum.";
      DungeonPlan.Room next = r.plan.rooms.get(r.room + 1);
      for (Player m : living(r)) m.teleport(in(r, next, 0, 0, 0));
      return "Testmodus: in den nächsten Raum gebracht.";
    }
    for (Enemy e : new ArrayList<>(r.mobs)) removeEnemy(e);
    r.pending = 0;
    DungeonPlan.Room room = room(r);
    if (r.stage == Stage.WAVE || r.stage == Stage.COUNTDOWN) {
      r.wave += room.waves - r.roomWave - (r.stage == Stage.WAVE ? 1 : 0);
      r.roomWave = room.waves;
      if (r.wave >= r.totalWaves) {
        finish(r, true, r.variant.title + " bezwungen! (Testmodus)");
        return "Testmodus: Dungeon beendet.";
      }
      if (room.puzzle != null) {
        startPuzzle(r);
        return "Testmodus: Wellen übersprungen, Rätsel " + room.puzzle.title + " läuft.";
      }
    }
    travel(r);
    return "Testmodus: Raum " + (r.room + 1) + " erledigt (" + roomName(r, room) + ").";
  }

  /** Admin test: a summary of the generated layout. */
  public String debugPlan(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || r.plan == null) return "Kein Dungeon.";
    StringBuilder sb = new StringBuilder("Raum " + (r.room + 1) + "/" + r.plan.mainRooms + " · " + r.stage + ": ");
    for (DungeonPlan.Room room : r.plan.rooms)
      sb.append(room.index + 1)
          .append(' ')
          .append(roomName(r, room))
          .append(room.puzzle != null ? " [" + room.puzzle.title + "]" : "")
          .append(room.waves > 0 ? " " + room.waves + "W" : "")
          .append(" · ");
    if (r.room + 1 < r.plan.mainRooms) {
      Location next = in(r, r.plan.rooms.get(r.room + 1), 0, 0, 0);
      sb.append("NEXT@").append(next.getBlockX()).append(',').append(next.getBlockY()).append(',').append(next.getBlockZ());
    }
    return sb.toString();
  }

  /** Drone turret: hits the nearest enemy of the owner's run; returns where it hit. */
  public Location droneShot(Player p, double damage) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || down(p)) return null;
    Enemy best = null;
    double bestDistance = 144;
    for (Enemy e : r.mobs) {
      if (e.hp <= 0 || !e.mob.isValid()) continue;
      double d = e.mob.getLocation().distanceSquared(p.getLocation());
      if (d < bestDistance) {
        bestDistance = d;
        best = e;
      }
    }
    if (best == null) return null;
    Location at = best.mob.getLocation().add(0, best.boss ? 1.8 : 1, 0);
    strike(best, p, damage, false);
    return at;
  }

  private boolean rearCounter(Enemy e, List<Player> targets) {
    BossPressure.Step step = e.pressure.step(tick, e.resolveAt == 0);
    if (step == BossPressure.Step.NONE) return false;
    e.mob.setAware(false);
    e.mob.setVelocity(new Vector());
    e.attackAt = Math.max(e.attackAt, tick + 20);
    if (step == BossPressure.Step.START) {
      e.sweepOrigin = e.mob.getLocation().clone();
      say(e.run, "RUNDUMSCHLAG! Raus aus dem roten Kreis – auch hinter dem Wächter!");
      e.mob.getWorld().playSound(e.sweepOrigin, Sound.BLOCK_NOTE_BLOCK_BASS, 1, .5f);
    }
    circle(e.sweepOrigin, BossPressure.RADIUS, Color.RED);
    e.rig.animate(e.mob.getLocation(), tick, true, false, false);
    if (step == BossPressure.Step.STRIKE) {
      for (Player p : targets) {
        Vector d = p.getLocation().toVector().subtract(e.sweepOrigin.toVector());
        if (BossPressure.inSweep(d.getX(), d.getY(), d.getZ()) && e.mob.hasLineOfSight(p))
          hurt(
              e.run,
              p,
              DungeonRules.damage(e.run.zone, e.run.mode, true, e.run.level, e.run.size) * 1.35);
      }
      e.mob
          .getWorld()
          .spawnParticle(
              Particle.SWEEP_ATTACK, e.sweepOrigin.clone().add(0, 1, 0), 14, 2, .4, 2, 0);
      e.mob.getWorld().playSound(e.sweepOrigin, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1, .6f);
      e.sweepOrigin = null;
    }
    return true;
  }

  /** The dungeon's own hazard: Glutschmiede eruptions or Frostkrypta cold. */
  private void hazard(Run r) {
    switch (r.variant) {
      case GLUTSCHMIEDE -> embers(r);
      case FROSTKRYPTA -> cold(r);
      default -> {}
    }
  }

  /** Glowing floor spots under every player (plus a few random ones) that erupt shortly after. */
  private void embers(Run r) {
    if (r.stage != Stage.WAVE) {
      r.eruptSpots.clear();
      r.eruptNext = 0;
      return;
    }
    if (r.eruptNext == 0) r.eruptNext = tick + 100;
    if (r.eruptSpots.isEmpty()) {
      if (tick < r.eruptNext) return;
      List<Player> targets = living(r);
      if (targets.isEmpty()) return;
      for (Player p : targets) {
        Location l = p.getLocation().clone();
        l.setY(65);
        r.eruptSpots.add(l);
      }
      int extra = DungeonVariant.eruptions(targets.size(), r.mode) - targets.size();
      for (int i = 0; i < extra; i++)
        r.eruptSpots.add(
            at(
                r,
                (random.nextDouble() * 2 - 1) * (room(r).hw - 3),
                0,
                (random.nextDouble() * 2 - 1) * (room(r).hd - 3)));
      r.eruptLand = tick + DungeonVariant.ERUPT_WARNING;
      // During the boss fight the floor erupts half as often, next to the boss attacks.
      boolean boss = r.mobs.stream().anyMatch(e -> e.boss);
      r.eruptNext = tick + DungeonVariant.eruptionInterval(r.mode, r.level) * (boss ? 2L : 1L);
      for (Player p : targets) p.playSound(p.getLocation(), Sound.BLOCK_LAVA_POP, 1, .7f);
      return;
    }
    if (tick < r.eruptLand) {
      if (tick % 4 == 0)
        for (Location l : r.eruptSpots) {
          circle(l, DungeonVariant.ERUPT_RADIUS, Color.ORANGE);
          circle(l, DungeonVariant.ERUPT_RADIUS * .5, Color.RED);
          l.getWorld().spawnParticle(Particle.LAVA, l, 1, .8, 0, .8, 0);
        }
      return;
    }
    double damage = DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * 1.3;
    for (Location l : r.eruptSpots) {
      l.getWorld().spawnParticle(Particle.FLAME, l.clone().add(0, .5, 0), 30, .9, .8, .9, .04);
      l.getWorld().spawnParticle(Particle.LAVA, l, 8, .8, .2, .8, 0);
      l.getWorld().playSound(l, Sound.ENTITY_BLAZE_SHOOT, .8f, .6f);
    }
    for (Player p : living(r)) {
      Location at = p.getLocation();
      for (Location l : r.eruptSpots)
        if (DungeonVariant.inEruption(at.getX() - l.getX(), at.getZ() - l.getZ())) {
          hurt(r, p, damage);
          p.setFireTicks(30);
          break;
        }
    }
    r.eruptSpots.clear();
  }

  /** Frost stacks while fighting; the braziers in every hall warm you up again. */
  private void cold(Run r) {
    if (tick < r.frostNext) return;
    r.frostNext = tick + DungeonVariant.frostInterval(r.mode);
    boolean fighting = r.stage == Stage.WAVE || r.stage == Stage.SIDE;
    double reach = DungeonVariant.BRAZIER_RADIUS * DungeonVariant.BRAZIER_RADIUS;
    for (Player p : online(r)) {
      UUID id = p.getUniqueId();
      int before = r.frost.getOrDefault(id, 0);
      boolean warm =
          r.braziers.stream()
              .anyMatch(
                  b -> b.getWorld().equals(p.getWorld()) && b.distanceSquared(p.getLocation()) <= reach);
      int now =
          fighting && !r.down.contains(id)
              ? DungeonVariant.frost(before, warm)
              : Math.max(0, before - 2);
      if (DungeonVariant.frozen(now)) {
        hurt(r, p, DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * 1.5);
        p.getWorld()
            .spawnParticle(Particle.SNOWFLAKE, p.getLocation().add(0, 1, 0), 30, .4, .6, .4, .02);
        p.playSound(p.getLocation(), Sound.BLOCK_GLASS_BREAK, 1, .6f);
        frostTitle(p, "❄ Eingefroren! Ab zu einem Glutbecken!");
        now = DungeonVariant.FROST_AFTER_FREEZE;
      } else if (now >= DungeonVariant.FROST_SLOW && before < DungeonVariant.FROST_SLOW)
        frostTitle(p, "❄ Dir wird kalt – wärm dich am Glutbecken auf");
      if (warm && now < before)
        p.getWorld().spawnParticle(Particle.FLAME, p.getLocation().add(0, .2, 0), 4, .3, .1, .3, 0);
      r.frost.put(id, now);
      p.lockFreezeTicks(true);
      // Vanilla freeze damage starts at 140 ticks; 13 per stack keeps it purely visual.
      p.setFreezeTicks(now * 13);
      if (now >= DungeonVariant.FROST_SLOW)
        p.addPotionEffect(
            new org.bukkit.potion.PotionEffect(
                org.bukkit.potion.PotionEffectType.SLOWNESS,
                DungeonVariant.frostInterval(r.mode) + 10,
                0,
                false,
                false,
                true));
    }
  }

  private void frostTitle(Player p, String text) {
    p.showTitle(
        net.kyori.adventure.title.Title.title(
            Component.empty(),
            Component.text(text, NamedTextColor.AQUA),
            net.kyori.adventure.title.Title.Times.times(
                java.time.Duration.ZERO,
                java.time.Duration.ofMillis(1500),
                java.time.Duration.ofMillis(400))));
  }

  private static void thaw(Player p) {
    p.lockFreezeTicks(false);
    p.setFreezeTicks(0);
  }

  private void circle(Location l, double radius, Color color) {
    for (int i = 0; i < 18; i++) {
      double a = i * Math.PI / 9;
      l.getWorld()
          .spawnParticle(
              Particle.DUST,
              l.clone().add(Math.cos(a) * radius, .15, Math.sin(a) * radius),
              1,
              0,
              0,
              0,
              0,
              new Particle.DustOptions(color, 1.2f));
    }
  }

  private void beam(Location l, Vector direction) {
    beam(l, direction, 18);
  }

  private void beam(Location l, Vector direction, int length) {
    for (int i = 0; i < length; i++)
      l.getWorld()
          .spawnParticle(
              Particle.DUST,
              l.clone().add(direction.clone().multiply(i)).add(0, .3, 0),
              1,
              .12,
              0,
              .12,
              0,
              new Particle.DustOptions(Color.ORANGE, 1.5f));
  }

  private double hurt(Run r, Player p, double amount) {
    if (r.down.contains(p.getUniqueId())) return 0;
    double taken =
        plugin
        .combat()
        .dungeonDamage(
            p,
            amount
                * Relics.damageTaken(plugin.profile(p))
                * r.blessings.incoming(p.getUniqueId())
                * (r.endless ? DeepDescent.damage(r.floor) : 1)
                * Prestige.damage(r.prestige),
            () -> {
              r.stats.of(p.getUniqueId()).downs++;
              r.down.add(p.getUniqueId());
              CombatEngine.setHealth(p, Math.min(Gear.stats(plugin.profile(p)).health(), 4));
              p.teleport(checkpoint(r, true));
              say(r, p.getName() + " wurde besiegt. Überlebt die Phase für seine Rückkehr!");
            });
    r.stats.of(p.getUniqueId()).taken += taken;
    return taken;
  }

  /** Healing shards used during a run count for the victory statistics. */
  public void healed(Player p, double amount) {
    Run r = membership.get(p.getUniqueId());
    if (r != null && !r.ended) r.stats.of(p.getUniqueId()).healed += amount;
  }

  private void revive(Run r) {
    for (Player p : online(r)) {
      if (!plugin.playing(p) || p.isDead()) continue;
      plugin.combat().applyStats(p);
      boolean revived = r.down.remove(p.getUniqueId());
      double max = Gear.stats(plugin.profile(p)).health();
      CombatEngine.setHealth(p, revived ? max * .5 : Math.min(max, p.getHealth() + max * .15));
      if (revived) p.teleport(checkpoint(r, false));
    }
    r.down.clear();
  }

  @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
  public void hit(EntityDamageByEntityEvent event) {
    Enemy source = enemies.get(event.getDamager().getUniqueId());
    if (source != null) {
      event.setCancelled(true);
      return;
    }
    Enemy e = enemies.get(event.getEntity().getUniqueId());
    if (e == null) return;
    event.setCancelled(true);
    if (!(event.getDamager() instanceof Player p)
        || membership.get(p.getUniqueId()) != e.run
        || down(p)
        || !plugin.items().kind(p.getInventory().getItemInMainHand()).equals("sword")
        || !p.hasLineOfSight(e.mob)
        || p.getLocation().distanceSquared(e.mob.getLocation()) > 25) return;
    long now = Bukkit.getCurrentTick();
    if (clicks.getOrDefault(p.getUniqueId(), -1L) == now) return;
    clicks.put(p.getUniqueId(), now);
    strike(e, p, RapidCombat.damage(Gear.stats(plugin.profile(p))));
  }

  private void strike(Enemy e, Player p, double damage) {
    strike(e, p, damage, true);
  }

  private void strike(Enemy e, Player p, double damage, boolean procAllowed) {
    if (e.hp <= 0) return;
    if (e.brain != null && e.brain.immune(tick)) {
      plugin.combat().showDamage(p, e.mob.getLocation().add(0, 3.4, 0), 0, false, false, true);
      p.playSound(p.getLocation(), Sound.ITEM_SHIELD_BLOCK, .6f, 1.4f);
      return;
    }
    if (e.brain != null) damage *= e.brain.damageTaken(tick);
    if (e.guard != null && !guardAllows(e, p)) return;
    ArtifactCombat.Proc proc =
        procAllowed
            ? plugin.adventure().hit(p, e.mob.getUniqueId())
            : new ArtifactCombat.Proc(false, false);
    if (plugin.adventure().fractured(e.mob.getUniqueId())) damage *= 1.15;
    damage *= e.run.blessings.damage(p.getUniqueId());
    Gear.Stats stats = Gear.stats(plugin.profile(p));
    Gear.Item weapon = Gear.equipped(plugin.profile(p), Gear.Slot.WEAPON);
    String style = weapon == null ? "sword" : weapon.style;
    Vector delta = p.getLocation().toVector().subtract(e.mob.getLocation().toVector());
    Vector facing = e.mob.getLocation().getDirection();
    double alignment = WeaponRules.facing(delta.getX(), delta.getZ(), facing.getX(), facing.getZ());
    if (e.boss) e.pressure.hit(tick, alignment, delta.clone().setY(0).lengthSquared());
    boolean backstab = style.equals("dagger") && alignment <= -.5;
    damage *= WeaponRules.multiplier(style, WeaponRules.rearBonus(weapon), false, false, alignment);
    if (procAllowed) damage *= plugin.combat().comboHit(p);
    damage *= plugin.combat().abilityBuff(p);
    boolean crit =
        random.nextDouble() < stats.crit()
            || procAllowed
                && Talents.bloodrush(plugin.profile(p))
                && plugin.combat().combo(p) % 10 == 0;
    if (crit) damage *= stats.critDamage();
    if (e.boss || e.guard != null) damage *= Relics.bossDamage(plugin.profile(p));
    double dealt = Math.min(e.hp, damage);
    e.hp -= dealt;
    plugin.combat().relicAfterHit(p, dealt);
    e.run.stats.hit(p.getUniqueId(), dealt, e.boss, crit, plugin.combat().combo(p), e.hp <= 0);
    health(e);
    e.rig.hurt(tick);
    plugin
        .combat()
        .showDamage(
            p, e.mob.getLocation().add(0, e.boss ? 3.4 : 2, 0), dealt, crit, backstab, false);
    if (procAllowed) plugin.combat().starStrike(p, e.mob.getLocation(), damage);
    if (procAllowed && e.hp > 0 && random.nextDouble() < Relics.doubleShot(plugin.profile(p)))
      strike(e, p, damage * .6, false);
    p.playSound(
        p.getLocation(),
        crit ? Sound.ENTITY_PLAYER_ATTACK_CRIT : Sound.ENTITY_PLAYER_ATTACK_STRONG,
        .65f,
        1.2f);
    if (tick >= e.recoilAt + 8 && e.sweepOrigin == null) {
      Vector away = e.mob.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
      if (away.lengthSquared() > .01)
        e.mob.setVelocity(
            away.normalize().multiply(HitFeedback.knockback(style, e.boss, false)).setY(.18));
      e.recoilAt = tick + (e.boss ? 2 : 5);
    }
    if (proc.lightning()) {
      Location origin = e.mob.getLocation().add(0, 1, 0);
      for (Enemy other :
          e.run.mobs.stream()
              .filter(
                  v ->
                      v != e
                          && v.hp > 0
                          && v.mob.getLocation().distanceSquared(origin) < 36
                          && e.mob.hasLineOfSight(v.mob))
              .limit(3)
              .toList()) {
        plugin.adventure().arc(p, origin, other.mob.getLocation().add(0, 1, 0));
        strike(other, p, plugin.adventure().arcDamage(p), false);
      }
    }
    if (proc.fracture())
      plugin.tell(p, "Runenhammer: Ziel 4 Sekunden lang verwundbar (+15% Schaden)!");
    if (e.hp <= 0) {
      plugin.passXp(p, e.boss ? DeepPass.XP_BOSS : DeepPass.XP_KILL);
      plugin.pets().victory(p);
      plugin.adventure().kill(p, e.mob.getLocation());
      if (!e.boss && random.nextDouble() < (e.elite ? .4 : .12)) {
        living(e.run).stream()
            .filter(
                member ->
                    e.run.healingDrops.getOrDefault(member.getUniqueId(), 0) < 3
                        && plugin.profile(member).healingCharges < Healing.capacity(plugin.profile(member)))
            .min(Comparator.comparingInt(member -> plugin.profile(member).healingCharges))
            .ifPresent(
                member -> {
                  e.run.healingDrops.merge(member.getUniqueId(), 1, Integer::sum);
                  plugin.healing().found(member, 1);
                });
      }
      if (e.guard != null) guardDown(e);
      removeEnemy(e);
    }
  }

  /** Living enemies of this player's dungeon run, for weapon abilities. */
  List<AbilityTarget> abilityTargets(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || down(p)) return List.of();
    List<AbilityTarget> out = new ArrayList<>();
    for (Enemy e : new ArrayList<>(r.mobs))
      if (e.hp > 0 && e.mob.isValid()) out.add(new AbilityTarget(e.mob, damage -> strike(e, p, damage)));
    return out;
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void damage(EntityDamageEvent e) {
    if (enemies.containsKey(e.getEntity().getUniqueId())) e.setCancelled(true);
    if (e.getEntity() instanceof Player p && active(p)) e.setCancelled(true);
  }

  @EventHandler
  public void targeting(EntityTargetLivingEntityEvent e) {
    Enemy enemy = enemies.get(e.getEntity().getUniqueId());
    if (enemy != null
        && e.getTarget() != null
        && (!(e.getTarget() instanceof Player p)
            || membership.get(p.getUniqueId()) != enemy.run
            || down(p))) e.setCancelled(true);
  }

  @EventHandler
  public void died(PlayerDeathEvent e) {
    Run r = membership.get(e.getEntity().getUniqueId());
    if (r == null) return;
    if (r.down.add(e.getEntity().getUniqueId())) r.stats.of(e.getEntity().getUniqueId()).downs++;
    e.setKeepInventory(true);
    e.getDrops().clear();
    e.setKeepLevel(true);
    e.setDroppedExp(0);
  }

  public Location respawnLocation(Player p) {
    Run r = membership.get(p.getUniqueId());
    return r == null ? null : checkpoint(r, r.down.contains(p.getUniqueId()));
  }



  @EventHandler(priority = EventPriority.LOW)
  public void shrine(PlayerInteractEvent e) {
    Player p = e.getPlayer();
    Run r = membership.get(p.getUniqueId());
    if (r == null
        || r.shrines.isEmpty()
        || e.getHand() != EquipmentSlot.HAND
        || !e.getAction().isRightClick()
        || e.getClickedBlock() == null) return;
    int i = r.shrines.indexOf(e.getClickedBlock());
    if (i < 0) return;
    e.setCancelled(true);
    if (p.getLocation().distanceSquared(e.getClickedBlock().getLocation()) > 36) return;
    bless(r, p, i);
  }

  @EventHandler(priority = EventPriority.LOW)
  public void puzzle(PlayerInteractEvent e) {
    Player p = e.getPlayer();
    Run r = membership.get(p.getUniqueId());
    if (r == null
        || r.stage != Stage.PUZZLE
        || e.getClickedBlock() == null
        || down(p)
        || e.getHand() != EquipmentSlot.HAND) return;
    String action = r.clickables.get(e.getClickedBlock());
    if (action == null || !action.contains(":")) return;
    e.setCancelled(true);
    if (p.getLocation().distanceSquared(e.getClickedBlock().getLocation()) > 42) return;
    puzzleClick(r, p, e.getClickedBlock(), action);
  }

  @EventHandler
  public void move(PlayerMoveEvent e) {
    if (e instanceof PlayerTeleportEvent || !down(e.getPlayer()) || e.getTo() == null) return;
    Location from = e.getFrom(), to = e.getTo();
    if (from.distanceSquared(to) > .0001) {
      Location lock = from.clone();
      lock.setYaw(to.getYaw());
      lock.setPitch(to.getPitch());
      e.setTo(lock);
    }
  }

  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  public void teleport(PlayerTeleportEvent e) {
    if (e.getTo() == null) return;
    Run own = membership.get(e.getPlayer().getUniqueId());
    if (own != null
        && own.plan != null
        && own.stage != Stage.BUILDING
        && inside(own, e.getTo())
        && !allowed(own, e.getTo())) {
      e.setCancelled(true);
      return;
    }
    for (Run r : runs.values())
      if (inside(r, e.getTo())
          && membership.get(e.getPlayer().getUniqueId()) != r
          && !r.watchers.contains(e.getPlayer().getUniqueId())) {
        e.setCancelled(true);
        return;
      }
  }

  // ---- Puzzles ----

  private static final int[][] MIMIC_SPOTS = {{-8, -7}, {8, -7}, {-8, 5}, {8, 5}, {0, -9}};
  private static final Material LAMP_ON = Material.SEA_LANTERN, LAMP_OFF = Material.COAL_BLOCK;

  private Random puzzleRandom(Run r, DungeonPlan.Room room) {
    return new Random(r.id.getLeastSignificantBits() ^ room.index * 0x9E3779B97F4A7C15L);
  }

  private void clickable(Run r, Location at, String action) {
    r.clickables.put(at.getBlock(), action);
  }

  /** Static puzzle parts are placed while the dungeon is built; state lives in the run. */
  private void setupPuzzle(Run r, DungeonPlan.Room room) {
    Random rnd = puzzleRandom(r, room);
    switch (room.puzzle) {
      case RUNES -> {
        for (int i = 0; i < 4; i++) {
          in(r, room, -9 + i * 6, 0, -6).getBlock().setType(RUNES[i], false);
          in(r, room, -9 + i * 6, -1, -6).getBlock().setType(Material.SEA_LANTERN, false);
          clickable(r, in(r, room, -9 + i * 6, 0, -6), "rune:" + i);
        }
        r.puzzleStates.put(room.index, DungeonRules.sequence(r.id, room.index, r.mode));
        puzzleSign(r, room, 0, 2.5, -6, "RUNENWAND\nFarben merken, dann in Reihenfolge anklicken", NamedTextColor.AQUA);
      }
      case SEALS -> {
        for (int i = 0; i < 3; i++)
          in(r, room, -6 + i * 6, -1, 3).getBlock().setType(Material.WAXED_OXIDIZED_CUT_COPPER, false);
        puzzleSign(r, room, 0, 2.5, 3, "GRUPPENSIEGEL\nAlle Platten gleichzeitig besetzen", NamedTextColor.AQUA);
      }
      case LEVERS -> {
        DungeonPuzzles.Levers levers = new DungeonPuzzles.Levers(rnd, r.mode);
        r.puzzleStates.put(room.index, levers);
        for (int i = 0; i < DungeonPuzzles.Levers.COUNT; i++) {
          Location lever = in(r, room, -8 + i * 4, 0, -5);
          lever
              .getBlock()
              .setBlockData(
                  Bukkit.createBlockData("minecraft:lever[face=floor,facing=north,powered=false]"),
                  false);
          clickable(r, lever, "lever:" + i);
          in(r, room, -8 + i * 4, 0, -8).getBlock().setType(Material.CHISELED_STONE_BRICKS, false);
        }
        drawLamps(r, room, levers);
        puzzleSign(r, room, 0, 3, -8, "HEBELRÄTSEL\nJeder Hebel schaltet seine Lampe und die Nachbarn um.\nAlle Lampen an = offen", NamedTextColor.AQUA);
      }
      case PLATES -> {
        r.puzzleStates.put(room.index, new DungeonPuzzles.Plates(rnd, r.level, r.mode));
        for (int k = 0; k < 9; k++)
          plate(r, room, k).getBlock().setType(Material.GRAY_CONCRETE, false);
        puzzleSign(r, room, 0, 3, -8, "PLATTENLAUF\nImmer auf die leuchtende Platte – bevor die Zeit abläuft", NamedTextColor.AQUA);
      }
      case LIGHT -> {
        DungeonPuzzles.Light light = new DungeonPuzzles.Light(rnd, r.mode);
        r.puzzleStates.put(room.index, light);
        in(r, room, -9, 0, lightZ(light.sourceZ)).getBlock().setType(Material.SEA_LANTERN, false);
        in(r, room, lightX(light.targetX), 0, lightZ(light.targetZ))
            .getBlock()
            .setType(Material.AMETHYST_BLOCK, false);
        label(r, room, -9, 1.8, lightZ(light.sourceZ), "Lichtquelle", NamedTextColor.YELLOW);
        label(r, room, lightX(light.targetX), 1.8, lightZ(light.targetZ), "Kristall", NamedTextColor.LIGHT_PURPLE);
        for (var mirror : light.mirrors.entrySet()) {
          int cell = mirror.getKey();
          Location base = in(r, room, lightX(cell % DungeonPuzzles.Light.N), 0, lightZ(cell / DungeonPuzzles.Light.N));
          base.getBlock().setType(Material.POLISHED_ANDESITE, false);
          clickable(r, base, "mirror:" + cell);
          ItemDisplay glass =
              plugin
                  .mines()
                  .world()
                  .spawn(
                      base.clone().add(0, 1.1, 0),
                      ItemDisplay.class,
                      d -> {
                        d.setItemStack(new ItemStack(Material.LIGHT_BLUE_STAINED_GLASS_PANE));
                        d.setPersistent(false);
                      });
          r.decorations.add(glass);
          r.mirrors.put(cell, glass);
          turnMirror(glass, mirror.getValue());
        }
        puzzleSign(r, room, 0, 3.5, -10, "LICHTSTRAHL\nSockel anklicken dreht den Spiegel.\nLenke das Licht auf den Kristall", NamedTextColor.AQUA);
      }
      case TRAPS -> {
        int length = room.out.alongX() ? room.hw : room.hd;
        int stripes = DungeonPuzzles.Traps.stripes(length * 2);
        for (int k = 0; k < stripes; k++) {
          int a = trapStripe(room, k);
          for (int lateral = -3; lateral <= 3; lateral++)
            trapLocation(r, room, a, lateral, -1).getBlock().setType(Material.CHISELED_POLISHED_BLACKSTONE, false);
        }
        puzzleSign(r, room, 0, 3, 0, "FALLENGANG\nDie Glutdüsen feuern im Takt – durch die Lücken zum anderen Ende!", NamedTextColor.AQUA);
      }
      case BELLS -> {
        r.puzzleStates.put(room.index, new DungeonPuzzles.Bells(rnd, r.level, r.mode));
        for (int i = 0; i < 4; i++) {
          Location bell = in(r, room, -6 + i * 4, 0, -6);
          bell.getBlock()
              .setBlockData(Bukkit.createBlockData("minecraft:bell[attachment=floor,facing=south]"), false);
          clickable(r, bell, "bell:" + i);
        }
        puzzleSign(r, room, 0, 2.5, -6, "GLOCKENMELODIE\nZuhören, dann die Glocken in derselben Reihenfolge anschlagen", NamedTextColor.AQUA);
      }
      case MIMICS -> {
        r.puzzleStates.put(room.index, new DungeonPuzzles.Mimics(rnd));
        for (int i = 0; i < DungeonPuzzles.Mimics.COUNT; i++) {
          Location chest = in(r, room, MIMIC_SPOTS[i][0], 0, MIMIC_SPOTS[i][1]);
          chest.getBlock().setBlockData(Bukkit.createBlockData("minecraft:chest[facing=south]"), false);
          clickable(r, chest, "chest:" + i);
        }
        label(r, room, 0, 3, -2, "FALSCHE TRUHEN\nNur eine hat den Schlüssel – die anderen beißen", NamedTextColor.AQUA);
      }
    }
  }

  private static int lightX(int cell) {
    return -6 + cell * 3;
  }

  private static int lightZ(int cell) {
    return -8 + cell * 3;
  }

  private static void turnMirror(ItemDisplay glass, boolean slash) {
    glass.setTransformation(
        new org.bukkit.util.Transformation(
            new org.joml.Vector3f(),
            new org.joml.Quaternionf().rotateY((float) (slash ? Math.PI / 4 : -Math.PI / 4)),
            new org.joml.Vector3f(1.4f, 1.4f, 1.4f),
            new org.joml.Quaternionf()));
  }

  private Location plate(Run r, DungeonPlan.Room room, int k) {
    return in(r, room, -4 + 4 * (k % 3), -1, -4 + 4 * (k / 3));
  }

  private void drawLamps(Run r, DungeonPlan.Room room, DungeonPuzzles.Levers levers) {
    for (int i = 0; i < DungeonPuzzles.Levers.COUNT; i++)
      in(r, room, -8 + i * 4, 1, -8).getBlock().setType(levers.lit[i] ? LAMP_ON : LAMP_OFF, false);
  }

  /** Position of trap stripe k along the gauntlet (distance from the centre toward the exit). */
  private static int trapStripe(DungeonPlan.Room room, int k) {
    int length = room.out.alongX() ? room.hw : room.hd;
    return -length + 5 + 4 * k;
  }

  private Location trapLocation(Run r, DungeonPlan.Room room, double along, double lateral, double y) {
    DungeonPlan.Dir d = room.out;
    double x = d.dx * along + (d.alongX() ? 0 : lateral), z = d.dz * along + (d.alongX() ? lateral : 0);
    return in(r, room, x, y, z);
  }

  private double along(Run r, DungeonPlan.Room room, Location l) {
    double x = l.getX() - r.x - room.cx - .5, z = l.getZ() + 512 - room.cz - .5;
    return x * room.out.dx + z * room.out.dz;
  }

  private void startPuzzle(Run r) {
    DungeonPlan.Room room = room(r);
    r.stage = Stage.PUZZLE;
    r.puzzleStarted = tick;
    r.memoryStep = 0;
    r.sealTicks = 0;
    int limit = DungeonPuzzles.timeLimit(r.mode);
    if (DungeonPuzzles.silent(r.mode)) {
      say(r, "Ein STILLES RÄTSEL – keine Erklärung. Der Raum selbst verrät, was zu tun ist. Zeitlimit: " + limit / 20 + " s.");
      silentPuzzle(r, room);
      return;
    }
    if (limit > 0) say(r, "Veteran: " + limit / 20 + " Sekunden Zeit. Fehler und Zeitüberschreitung rufen Monster!");
    switch (room.puzzle) {
      case RUNES -> {
        @SuppressWarnings("unchecked")
        List<Integer> sequence = (List<Integer>) r.puzzleStates.get(room.index);
        r.sequence = sequence;
        r.deadline = tick + 160;
        say(r, "Runenrätsel: Merkt euch die Farbfolge oben in der Leiste. Danach die Runen an der Wand in dieser Reihenfolge anklicken. /df dungeon hint zeigt sie nochmal.");
      }
      case SEALS -> say(r, "Siegelrätsel: Besetzt die türkisfarbenen Platten gleichzeitig für 3 Sekunden. Solo reicht die linke, zu zweit die linken zwei, ab drei alle.");
      case LEVERS -> say(r, "Hebelrätsel: Jeder Hebel schaltet seine Lampe und die beiden daneben um. Bringt alle fünf Lampen zum Leuchten!");
      case PLATES -> {
        r.plateDeadline = tick + 60 + ((DungeonPuzzles.Plates) r.puzzleStates.get(room.index)).window;
        showPlate(r, room);
        say(r, "Plattenlauf: Lauft immer auf die leuchtende Platte, bevor sie erlischt.");
      }
      case LIGHT -> say(r, "Lichtstrahl: Dreht die Spiegel (Sockel anklicken), bis das Licht den Kristall trifft.");
      case TRAPS -> say(r, "Fallengang: Die Glutdüsen feuern im Takt. Wartet auf die Lücke und erreicht alle das andere Ende!");
      case BELLS -> {
        replayPuzzle(r);
        say(r, "Glockenmelodie: Hört genau hin und spielt die Melodie danach auf den Glocken nach. /df dungeon hint spielt sie nochmal.");
      }
      case MIMICS -> say(r, "Falsche Truhen: Nur eine Truhe hat den Schlüssel. Die anderen sind Mimics und greifen an!");
    }
  }

  /** Puzzle sign: title and explanation; on Albtraum (silent puzzles) only the title. */
  private void puzzleSign(
      Run r, DungeonPlan.Room room, double x, double y, double z, String text, NamedTextColor color) {
    String shown = DungeonPuzzles.silent(r.mode) ? text.split("\n")[0] : text;
    label(r, room, x, y, z, shown, color);
  }

  /** Veteran/Albtraum: a mistake or running out of time costs life and calls monsters. */
  private void puzzlePenalty(Run r, String why) {
    if (r.mode <= 0) return;
    say(r, why + " Die Wächter des Rätsels erwachen!");
    for (Player member : living(r))
      hurt(r, member, DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * (.6 + .3 * r.mode));
    int adds = r.mode + Math.max(0, r.size - 1);
    DungeonPlan.Room room = room(r);
    for (int i = 0; i < adds; i++) {
      double a = i * 2.1 + tick * .01;
      spawnAt(r, false, i % 4, at(r, Math.cos(a) * 6, 0, Math.sin(a) * 6), room.index);
    }
  }

  /** Albtraum: same puzzle state as normal, but no chat instructions at all. */
  private void silentPuzzle(Run r, DungeonPlan.Room room) {
    switch (room.puzzle) {
      case RUNES -> {
        @SuppressWarnings("unchecked")
        List<Integer> sequence = (List<Integer>) r.puzzleStates.get(room.index);
        r.sequence = sequence;
        r.deadline = tick + 160;
      }
      case PLATES ->
          r.plateDeadline = tick + 60 + ((DungeonPuzzles.Plates) r.puzzleStates.get(room.index)).window;
      case BELLS -> replayPuzzle(r);
      default -> {}
    }
    if (room.puzzle == DungeonPlan.Puzzle.PLATES) showPlate(r, room);
  }

  /** Shows the rune colours or plays the melody again. */
  private void replayPuzzle(Run r) {
    DungeonPlan.Room room = room(r);
    if (room.puzzle == DungeonPlan.Puzzle.RUNES) {
      r.deadline = tick + 100;
      r.memoryStep = 0;
      say(r, "Runenfolge wird erneut angezeigt. Danach bei der ersten Rune beginnen.");
    } else if (room.puzzle == DungeonPlan.Puzzle.BELLS) {
      DungeonPuzzles.Bells bells = (DungeonPuzzles.Bells) r.puzzleStates.get(room.index);
      bells.step = 0;
      r.puzzleStarted = tick + 20;
      r.deadline = r.puzzleStarted + bells.melody.length * 14L + 10;
    }
  }

  private void completePuzzle(Run r) {
    DungeonPlan.Room room = room(r);
    if (room.puzzle == DungeonPlan.Puzzle.RUNES)
      for (Player member : online(r)) {
        Profile data = plugin.profile(member);
        data.discovered.add("tutorial/runes");
        plugin.commit(member, data);
      }
    for (Player member : online(r)) {
      member.playSound(member.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, .6f, 1.2f);
      plugin.passXp(member, DeepPass.XP_PUZZLE);
      plugin.commit(member, plugin.profile(member));
    }
    say(r, room.puzzle.title + " gelöst!");
    travel(r);
  }

  private String puzzleLabel(Run r) {
    DungeonPlan.Room room = room(r);
    Object state = r.puzzleStates.get(room.index);
    return switch (room.puzzle) {
      case RUNES ->
          tick < r.deadline
              ? "Merken: " + String.join(" → ", r.sequence.stream().map(i -> NAMES[i]).toList())
              : "Runenwand: " + r.memoryStep + "/" + r.sequence.size() + " · Anklicken";
      case SEALS -> "Siegel: auf die Platten stellen · " + (r.sealTicks / 20) + "/" + DungeonPuzzles.sealTicks(r.mode) / 20 + " s";
      case LEVERS -> {
        DungeonPuzzles.Levers l = (DungeonPuzzles.Levers) state;
        int lit = 0;
        for (boolean b : l.lit) if (b) lit++;
        yield "Hebelrätsel: " + lit + "/" + DungeonPuzzles.Levers.COUNT + " Lampen an";
      }
      case PLATES -> {
        DungeonPuzzles.Plates pl = (DungeonPuzzles.Plates) state;
        yield "Plattenlauf: " + pl.step + "/" + pl.order.length + " · " + Math.max(0, (r.plateDeadline - tick) / 20) + " s";
      }
      case LIGHT -> "Lichtstrahl: Spiegel drehen, Kristall treffen";
      case TRAPS -> "Fallengang: alle zum anderen Ende";
      case BELLS ->
          tick < r.deadline
              ? "Hört zu …"
              : "Glocken: " + ((DungeonPuzzles.Bells) state).step + "/" + ((DungeonPuzzles.Bells) state).melody.length;
      case MIMICS ->
          r.mimicKey
              ? "Schlüssel gefunden · besiegt die Mimics (" + r.mobs.size() + ")"
              : "Falsche Truhen: Schlüssel suchen";
    };
  }

  private void showPlate(Run r, DungeonPlan.Room room) {
    DungeonPuzzles.Plates plates = (DungeonPuzzles.Plates) r.puzzleStates.get(room.index);
    for (int k = 0; k < 9; k++)
      plate(r, room, k)
          .getBlock()
          .setType(
              plates.step < plates.order.length && k == plates.current()
                  ? Material.SEA_LANTERN
                  : Material.GRAY_CONCRETE,
              false);
  }

  private void puzzleTick(Run r) {
    DungeonPlan.Room room = room(r);
    Object state = r.puzzleStates.get(room.index);
    int limit = DungeonPuzzles.timeLimit(r.mode);
    if (limit > 0 && tick - r.puzzleStarted > limit && room.puzzle != DungeonPlan.Puzzle.TRAPS) {
      r.puzzleStarted = tick;
      puzzlePenalty(r, "ZEIT ABGELAUFEN!");
    }
    switch (room.puzzle) {
      case SEALS -> {
        int needed = Math.max(1, Math.min(3, living(r).size()));
        Set<UUID> used = new HashSet<>();
        for (int i = 0; i < needed; i++) {
          Location pad = at(r, -6 + i * 6, 0, 3);
          for (Player p : living(r))
            if (!used.contains(p.getUniqueId()) && p.getLocation().distanceSquared(pad) < 2.2) {
              used.add(p.getUniqueId());
              break;
            }
          circle(pad, 1, Color.AQUA);
        }
        r.sealTicks = used.size() == needed ? r.sealTicks + 2 : 0;
        if (r.sealTicks >= DungeonPuzzles.sealTicks(r.mode)) completePuzzle(r);
      }
      case PLATES -> {
        DungeonPuzzles.Plates plates = (DungeonPuzzles.Plates) state;
        Location target = plate(r, room, plates.current()).add(0, 1, 0);
        if (tick % 6 == 0) circle(target, .8, Color.YELLOW);
        boolean on =
            living(r).stream()
                .anyMatch(
                    p ->
                        Math.abs(p.getX() - target.getX()) < .9
                            && Math.abs(p.getZ() - target.getZ()) < .9
                            && Math.abs(p.getY() - target.getY()) < 1.2);
        if (on) {
          for (Player p : online(r)) p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, .8f, .8f + plates.step * .15f);
          if (plates.stepOn(plates.current())) {
            showPlate(r, room);
            completePuzzle(r);
            return;
          }
          r.plateDeadline = tick + plates.window;
          showPlate(r, room);
        } else if (tick > r.plateDeadline) {
          plates.step = 0;
          r.plateDeadline = tick + 40 + plates.window;
          showPlate(r, room);
          say(r, "Zu langsam! Der Plattenlauf beginnt von vorn.");
          for (Player p : living(r)) hurt(r, p, 1 + r.mode);
        }
      }
      case LIGHT -> {
        if (tick % 6 != 0) break;
        DungeonPuzzles.Light light = (DungeonPuzzles.Light) state;
        Location from = in(r, room, -9, 1.2, lightZ(light.sourceZ));
        for (int[] cell : light.beam()) {
          Location to = in(r, room, lightX(cell[0]), 1.2, lightZ(cell[1]));
          Vector step = to.toVector().subtract(from.toVector()).multiply(1 / 6.0);
          Location dot = from.clone();
          for (int i = 0; i < 6; i++) {
            dot.add(step);
            dot.getWorld().spawnParticle(Particle.DUST, dot, 1, 0, 0, 0, 0, new Particle.DustOptions(Color.YELLOW, 1.1f));
          }
          from = to;
        }
      }
      case TRAPS -> {
        int length = room.out.alongX() ? room.hw : room.hd;
        int stripes = DungeonPuzzles.Traps.stripes(length * 2);
        double damage = DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * 1.2;
        for (int k = 0; k < stripes; k++) {
          int stateNow = DungeonPuzzles.Traps.state(k, tick);
          int a = trapStripe(room, k);
          if (stateNow == 0 || tick % 4 != 0 && stateNow == 1) continue;
          for (int lateral = -3; lateral <= 3; lateral++) {
            Location l = trapLocation(r, room, a, lateral, .2);
            if (stateNow == 1)
              l.getWorld().spawnParticle(Particle.DUST, l, 1, .2, 0, .2, 0, new Particle.DustOptions(Color.RED, 1.3f));
            else if (tick % 4 == 0) l.getWorld().spawnParticle(Particle.FLAME, l, 3, .3, .5, .3, .02);
          }
          if (stateNow == 2)
            for (Player p : living(r))
              if (Math.abs(along(r, room, p.getLocation()) - a) < 1.3
                  && tick - r.trapHits.getOrDefault(p.getUniqueId(), -100L) > 12) {
                r.trapHits.put(p.getUniqueId(), tick);
                hurt(r, p, damage);
                p.setFireTicks(20);
              }
        }
        if (living(r).stream().allMatch(p -> along(r, room, p.getLocation()) >= length - 4))
          completePuzzle(r);
      }
      case BELLS -> {
        DungeonPuzzles.Bells bells = (DungeonPuzzles.Bells) state;
        long since = tick - r.puzzleStarted;
        if (tick < r.deadline && since >= 0 && since % 14 == 0 && since / 14 < bells.melody.length)
          ringBell(r, room, bells.melody[(int) (since / 14)]);
      }
      case MIMICS -> {
        if (r.mimicKey && r.mobs.isEmpty()) completePuzzle(r);
      }
      default -> {}
    }
  }

  private void ringBell(Run r, DungeonPlan.Room room, int bell) {
    Location at = in(r, room, -6 + bell * 4, 1.4, -6);
    at.getWorld().playSound(at, Sound.BLOCK_NOTE_BLOCK_BELL, 1.2f, DungeonPuzzles.Bells.PITCH[bell]);
    at.getWorld().spawnParticle(Particle.NOTE, at.clone().add(0, .6, 0), 3, .2, .1, .2, 1);
  }

  private void puzzleClick(Run r, Player p, org.bukkit.block.Block block, String action) {
    DungeonPlan.Room room = room(r);
    String[] part = action.split(":");
    int i = Integer.parseInt(part[1]);
    Object state = r.puzzleStates.get(room.index);
    switch (part[0]) {
      case "rune" -> {
        if (room.puzzle != DungeonPlan.Puzzle.RUNES || tick < r.deadline) return;
        if (r.sequence.get(r.memoryStep) == i) {
          r.memoryStep++;
          p.getWorld().playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1, .7f + r.memoryStep * .3f);
          if (r.memoryStep == r.sequence.size()) completePuzzle(r);
        } else {
          r.memoryStep = 0;
          r.mistakes++;
          r.deadline = tick + 100;
          say(r, "Falsche Rune! Die Reihenfolge wird nochmals angezeigt; die Runen entladen sich.");
          for (Player member : living(r)) hurt(r, member, 2 + r.mode);
          puzzlePenalty(r, "Falsche Rune!");
        }
      }
      case "lever" -> {
        if (room.puzzle != DungeonPlan.Puzzle.LEVERS) return;
        DungeonPuzzles.Levers levers = (DungeonPuzzles.Levers) state;
        levers.pull(i);
        var data = (org.bukkit.block.data.Powerable) block.getBlockData();
        data.setPowered(!data.isPowered());
        block.setBlockData(data, false);
        drawLamps(r, room, levers);
        p.getWorld().playSound(block.getLocation(), Sound.BLOCK_LEVER_CLICK, 1, 1);
        if (levers.solved()) completePuzzle(r);
      }
      case "mirror" -> {
        if (room.puzzle != DungeonPlan.Puzzle.LIGHT) return;
        DungeonPuzzles.Light light = (DungeonPuzzles.Light) state;
        light.rotate(i);
        ItemDisplay glass = r.mirrors.get(i);
        if (glass != null) turnMirror(glass, light.mirrors.get(i));
        p.getWorld().playSound(block.getLocation(), Sound.BLOCK_GRINDSTONE_USE, .6f, 1.4f);
        if (light.solved()) {
          in(r, room, lightX(light.targetX), 0, lightZ(light.targetZ)).getBlock().setType(Material.BEACON, false);
          completePuzzle(r);
        }
      }
      case "bell" -> {
        if (room.puzzle != DungeonPlan.Puzzle.BELLS || tick < r.deadline) return;
        DungeonPuzzles.Bells bells = (DungeonPuzzles.Bells) state;
        ringBell(r, room, i);
        int result = bells.ring(i);
        if (result == 2) completePuzzle(r);
        else if (result == 0) {
          say(r, "Falscher Ton! Die Melodie wird noch einmal gespielt.");
          for (Player member : living(r)) hurt(r, member, 1 + r.mode);
          puzzlePenalty(r, "Falscher Ton!");
          replayPuzzle(r);
        }
      }
      case "chest" -> {
        if (room.puzzle != DungeonPlan.Puzzle.MIMICS) return;
        DungeonPuzzles.Mimics mimics = (DungeonPuzzles.Mimics) state;
        if (mimics.opened[i]) return;
        mimics.opened[i] = true;
        Location at = block.getLocation().add(.5, 0, .5);
        block.setType(Material.AIR, false);
        r.clickables.remove(block);
        if (i == mimics.key) {
          r.mimicKey = true;
          p.getWorld().playSound(at, Sound.BLOCK_CHEST_OPEN, 1, 1);
          say(r, "Schlüssel gefunden!" + (r.mobs.isEmpty() ? "" : " Besiegt noch die Mimics."));
        } else {
          p.getWorld().playSound(at, Sound.ENTITY_EVOKER_FANGS_ATTACK, 1, .7f);
          spawnAt(r, false, random.nextInt(4), at, room.index);
          Enemy e = r.mobs.getLast();
          e.elite = true;
          e.hp = e.max = DungeonRules.health(r.zone, r.mode, r.size, Math.max(1, r.wave), false, r.level) * 1.2;
          e.mob.customName(Component.text("Mimic", NamedTextColor.RED));
          health(e);
          say(r, "Ein Mimic! Diese Truhe war falsch.");
        }
      }
      default -> {}
    }
  }

  // ---- Self test (/df verify) ----

  private void diagnose(Run r) {
    List<String> problems = new ArrayList<>();
    for (DungeonPlan.Corridor c : r.plan.corridors)
      for (int t = 1; t < c.tiles.size() - 1; t++) {
        DungeonPlan.Tile tile = c.tiles.get(t);
        Location l = worldAt(r, tile.x(), tile.floor(), tile.z());
        if (!l.getBlock().isPassable()
            || !l.clone().add(0, 1, 0).getBlock().isPassable()
            || !l.clone().add(0, -1, 0).getBlock().getType().isSolid())
          problems.add("corridor " + c.index + " blocked at " + tile);
      }
    int puzzles = 0;
    for (DungeonPlan.Room room : r.plan.rooms) {
      Location center = in(r, room, room.shape == DungeonPlan.Shape.BRIDGE ? 0 : 1, 0, 0);
      if (!center.clone().add(0, -1, 0).getBlock().getType().isSolid()) problems.add("room " + room.index + " floor");
      if (room.puzzle != null) puzzles++;
    }
    // Every clickable puzzle part must still be there, and every mirror has its glass.
    for (var entry : r.clickables.entrySet()) {
      Material type = entry.getKey().getType();
      String kind = entry.getValue().split(":")[0];
      boolean ok =
          switch (kind) {
            case "rune" -> type.name().endsWith("_CONCRETE");
            case "lever" -> type == Material.LEVER;
            case "bell" -> type == Material.BELL;
            case "chest", "treasure" -> type == Material.CHEST;
            case "mirror" -> type == Material.POLISHED_ANDESITE;
            case "key" -> type == Material.BARREL;
            case "lock" -> type == Material.LODESTONE;
            default -> type != Material.AIR;
          };
      if (!ok) problems.add(entry.getValue() + " is " + type);
    }
    for (DungeonPlan.Room room : r.plan.rooms)
      if (room.puzzle == DungeonPlan.Puzzle.LIGHT) {
        DungeonPuzzles.Light light = (DungeonPuzzles.Light) r.puzzleStates.get(room.index);
        if (r.mirrors.size() != light.mirrors.size()) problems.add("mirror displays " + r.mirrors.size() + "/" + light.mirrors.size());
        long bases = r.clickables.values().stream().filter(v -> v.startsWith("mirror:")).count();
        if (bases != light.mirrors.size()) problems.add("mirror bases " + bases + "/" + light.mirrors.size());
      }
    int expected = 0, checked = 0;
    Set<Integer> kinds = new HashSet<>();
    boolean boss = false;
    for (int w = 1; w <= r.totalWaves; w++) {
      r.room = w == r.totalWaves ? r.plan.mainRooms - 1 : 0;
      r.wave = w - 1;
      beginWave(r);
      expected += DungeonRules.count(w, r.size, r.level);
      for (int guard = 0; guard < 100 && (!r.mobs.isEmpty() || r.pending > 0); guard++) {
        for (Enemy e : new ArrayList<>(r.mobs)) {
          checked++;
          kinds.add(e.kind);
          boss |= e.boss;
          removeEnemy(e);
        }
        refill(r);
      }
    }
    if (checked != expected) problems.add("enemies " + checked + "/" + expected);
    if (!boss) problems.add("no boss");
    List<Chunk> chunks =
        r.chunks.stream()
            .map(key -> plugin.mines().world().getChunkAt((int) (long) key, (int) (key >> 32)))
            .toList();
    String summary =
        r.plan.mainRooms + " rooms, " + (r.plan.rooms.size() - r.plan.mainRooms) + " side rooms, "
            + r.plan.corridors.size() + " corridors, " + puzzles + " puzzles, " + checked
            + " enemies, " + kinds.size() + " kinds";
    finish(r, false, "");
    if (plugin.mines().world().getEntities().stream().anyMatch(e -> inside(r, e.getLocation())))
      problems.add("entities left");
    if (chunks.stream().anyMatch(c -> c.getPluginChunkTickets().contains(plugin)))
      problems.add("chunk tickets left");
    verification = problems.isEmpty() ? "OK: " + summary : "FAILED: " + problems + " · " + summary;
  }

  /** Where a member may be moved to: this room, the way on while travelling, an open side room. */
  private boolean allowed(Run r, Location to) {
    int bx = (int) Math.floor(to.getX() - r.x), bz = (int) Math.floor(to.getZ() + 512);
    DungeonPlan.Room at = r.plan.roomAt(bx, bz);
    if (at != null)
      return at.index == r.room
          || r.stage == Stage.TRAVEL && at.index == r.room + 1
          || at.role == DungeonPlan.Role.SIDE && at.parent == r.room && r.branchOpen[r.room];
    int c = r.plan.corridorAt(bx, bz);
    if (c < 0) return false;
    DungeonPlan.Corridor corridor = r.plan.corridors.get(c);
    if (corridor.from != r.room) return false;
    return r.stage == Stage.TRAVEL && corridor.to == r.room + 1
        || r.plan.rooms.get(corridor.to).role == DungeonPlan.Role.SIDE && r.branchOpen[r.room];
  }

  public void disconnect(Player p) {
    if (watching(p)) stopWatching(p, null);
    Run r = membership.get(p.getUniqueId());
    if (r != null) {
      r.disconnected.put(p.getUniqueId(), tick);
      p.hideBossBar(r.bar);
      say(r, p.getName() + " hat 60 Sekunden zum Wiederbeitreten.");
    } else if (!parties.networkMode()) parties.leave(p.getUniqueId());
  }

  public void resume(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r == null) return;
    if (tick - r.disconnected.getOrDefault(p.getUniqueId(), tick) > 1200) {
      remove(r, p.getUniqueId());
      return;
    }
    r.disconnected.remove(p.getUniqueId());
    p.showBossBar(r.bar);
    if (r.stage != Stage.BUILDING) p.teleport(checkpoint(r, r.down.contains(p.getUniqueId())));
  }

  public void withdraw(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r == null) return;
    if (r.stage == Stage.VICTORY) {
      leaveHall(r, p);
      return;
    }
    remove(r, p.getUniqueId());
    p.hideBossBar(r.bar);
    plugin.goHome(p);
    plugin.tell(
        p,
        r.endless
            ? "Tiefengang verlassen. Erreicht: Ebene " + (r.floor - 1) + " – alle Belohnungen sind ausgezahlt."
            : "Dungeon verlassen. Keine Abschlussbeute für diesen Lauf.");
    if (r.members.isEmpty()) finish(r, false, "");
  }

  private void remove(Run r, UUID id) {
    Player gone = Bukkit.getPlayer(id);
    if (gone != null) thaw(gone);
    r.frost.remove(id);
    r.members.remove(id);
    r.down.remove(id);
    r.disconnected.remove(id);
    membership.remove(id, r);
    // The party stays together after the dungeon; only players who left the server drop out.
    if (gone == null && !parties.networkMode()) parties.leave(id);
    clicks.remove(id);
  }

  private void removeEnemy(Enemy e) {
    enemies.remove(e.mob.getUniqueId());
    e.run.mobs.remove(e);
    if (e.rig != null) e.rig.close();
    if (e.health != null) e.health.close();
    e.mob.remove();
  }

  private void finish(Run r, boolean win, String message) {
    if (r.ended) return;
    r.ended = true;
    r.clearTicks = tick - r.started;
    boolean hall = false;
    try {
      Map<String, RewardDiff> gains =
          win && !r.endless
              ? plugin.rewardDungeon(
                  List.copyOf(r.members),
                  r.id,
                  r.zone,
                  r.mode,
                  tick - r.started,
                  r.level,
                  r.optionalFlags,
                  r.variant)
              : Map.of();
      if (!message.isBlank()) say(r, message);
      if (win && !r.endless)
        for (Player player : online(r)) {
          plugin.items().refresh(player, plugin.profile(player));
          RewardDiff gain = gains.get(player.getUniqueId().toString());
          if (gain == null) {
            plugin.tell(player, "Diese Belohnung hast du für diesen Lauf bereits erhalten.");
            continue;
          }
          plugin.passXp(player, DeepPass.XP_DUNGEON);
          Alchemy.gain(plugin.profile(player), Alchemy.Ingredient.ESSENZ, 2 + r.mode);
          Companions.Egg egg =
              Companions.maybeDrop(
                  plugin.profile(player), Companions.DUNGEON, random, System.currentTimeMillis());
          plugin.commit(player, plugin.profile(player));
          if (egg != null) plugin.pets().found(player, egg);
          if (r.bossFought) plugin.relicDrop(player, Relics.Part.SIEGEL, r.mode);
          plugin.guilds().progress(player, Guilds.Task.DUNGEONS, 1);
          plugin.tell(player, "━━━━━━━ DUNGEON-BEUTE ━━━━━━━");
          for (String line : gain.lines()) plugin.tell(player, "  " + line);
          long day = plugin.today().toEpochDay();
          plugin.change(
              player,
              data -> {
                String bonus = DungeonRules.dailyBonus(data, day, r.zone, r.mode, r.level);
                return bonus == null ? "  Tagesbonus heute schon abgeholt – morgen wieder." : "  " + bonus;
              });
          if (r.bossFought && !r.bossStruck.contains(player.getUniqueId())) {
            long bonus = DungeonRules.coins(r.zone, r.mode, r.level) / 4;
            plugin.change(
                player,
                data -> {
                  data.money += bonus;
                  data.lifetimeRevenue += bonus;
                  data.flawlessBosses++;
                  return "  MAKELLOS! Keinem großen Bossangriff getroffen: +" + bonus + " $";
                });
          }
          plugin.tell(player, "Alles ansehen: /df reward · Ausrüsten: /df loot");
          plugin.tell(
              player,
              "Gewölbekisten: bis zu 3 für diesen Sieg, gleich hier in der Siegeshalle (erste "
                  + Hud.money(LootChests.price(plugin.profile(player)))
                  + ")");
          player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
        }
      hall = win && !online(r).isEmpty();
    } finally {
      r.stage = Stage.COMPLETE;
      for (UUID id : new ArrayList<>(r.watchers)) {
        Player w = Bukkit.getPlayer(id);
        if (w != null)
          stopWatching(w, win ? "Der Lauf ist vorbei – Sieg!" : "Der Lauf ist vorbei.");
        else watching.remove(id, r);
      }
      r.watchers.clear();
      for (Enemy e : new ArrayList<>(r.mobs)) removeEnemy(e);
      boolean opened = false;
      if (hall)
        try {
          startVictory(r);
          opened = true;
        } catch (RuntimeException ex) {
          plugin.getLogger().log(java.util.logging.Level.SEVERE, "Victory hall failed", ex);
        }
      if (!opened) teardown(r);
    }
  }

  /** Removes the instance: decorations, hall blocks, camera; everyone still inside goes home. */
  private void teardown(Run r) {
    r.stage = Stage.COMPLETE;
    r.decorations.forEach(Entity::remove);
    r.decorations.clear();
    if (r.camera != null) r.camera.remove();
    r.camera = null;
    for (org.bukkit.block.Block b : r.hallBlocks) {
      r.clickables.remove(b);
      b.setType(Material.AIR, false);
    }
    r.hallBlocks.clear();
    runs.remove(r.slot, r);
    for (UUID id : new ArrayList<>(r.members)) {
      membership.remove(id, r);
      clicks.remove(id);
      Player p = Bukkit.getPlayer(id);
      if (p != null) {
        thaw(p);
        p.hideBossBar(r.bar);
        if (r.filming.remove(id)) {
          p.setSpectatorTarget(null);
          SpectatorState.restore(p);
        }
        plugin.goHome(p);
      } else if (!parties.networkMode()) parties.leave(id);
    }
    for (long key : r.chunks)
      plugin
          .mines()
          .world()
          .getChunkAt((int) key, (int) (key >> 32))
          .removePluginChunkTicket(plugin);
    r.chunks.clear();
  }

  // ---- Victory hall (0.9.2) ----

  /** Camera flight length and how long the hall stays open (game ticks). */
  static final int FILM_TICKS = 160, HALL_TICKS = 3600;

  private static net.kyori.adventure.title.Title bigTitle(
      String title, NamedTextColor color, String subtitle, int stayTicks) {
    return net.kyori.adventure.title.Title.title(
        Component.text(title, color),
        Component.text(subtitle, NamedTextColor.YELLOW),
        net.kyori.adventure.title.Title.Times.times(
            java.time.Duration.ofMillis(250),
            java.time.Duration.ofMillis(stayTicks * 50L),
            java.time.Duration.ofMillis(400)));
  }

  private static String clock(long ticks) {
    long seconds = Math.max(0, ticks / 20);
    return seconds / 60 + ":" + String.format("%02d", seconds % 60);
  }

  private void startVictory(Run r) {
    r.stage = Stage.VICTORY;
    r.victoryAt = tick;
    revive(r);
    Location center = at(r, 0, 1, 0);
    r.camera =
        center.getWorld()
            .spawn(
                cameraSpot(r, 0),
                ArmorStand.class,
                a -> {
                  a.setInvisible(true);
                  a.setMarker(true);
                  a.setGravity(false);
                  a.setInvulnerable(true);
                  a.setSilent(true);
                  a.setPersistent(false);
                });
    for (Player p : online(r)) {
      p.closeInventory();
      SpectatorState.enter(p);
      p.setSpectatorTarget(r.camera);
      r.filming.add(p.getUniqueId());
      p.showTitle(
          r.endless
              ? bigTitle(
                  "TIEFENGANG",
                  NamedTextColor.AQUA,
                  "Ebene " + r.floor + " erreicht · Wochenrekord: Ebene "
                      + DeepDescent.weekBest(plugin.profile(p), DeepDescent.currentWeek())
                      + " · "
                      + clock(r.clearTicks),
                  50)
              : bigTitle(
                  "SIEG!",
                  NamedTextColor.GOLD,
                  r.variant.title + " · Level " + r.level + " · " + clock(r.clearTicks),
                  50));
      p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1, 1);
    }
    center.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, center, 160, 3, 2, 3, .5);
    center.getWorld().spawnParticle(Particle.FIREWORK, center.clone().add(0, 3, 0), 80, 4, 2, 4, .08);
    r.bar.name(Component.text("SIEG! · Auswertung …", NamedTextColor.GOLD));
    r.bar.color(BossBar.Color.YELLOW);
    r.bar.progress(1);
  }

  /** Slow half circle around the boss arena, rising and always looking at its centre. */
  private Location cameraSpot(Run r, double t) {
    DungeonPlan.Room room = room(r);
    double radius = Math.max(4, Math.min(room.hw, room.hd) - 3);
    double angle = Math.PI * (.2 + 1.1 * t);
    double height = Math.min(room.height - 2.5, 2.5 + 3.5 * t);
    Location focus = at(r, 0, 1.2, 0);
    Location l = focus.clone().add(Math.cos(angle) * radius, height, Math.sin(angle) * radius);
    l.setDirection(focus.toVector().subtract(l.toVector()));
    return l;
  }

  private void victoryTick(Run r) {
    long age = tick - r.victoryAt;
    // Rewards were paid on the win: whoever leaves the server simply leaves the hall.
    for (UUID id : new ArrayList<>(r.members)) {
      Player p = Bukkit.getPlayer(id);
      if (p == null || !p.isOnline()) {
        r.filming.remove(id);
        remove(r, id);
      }
    }
    if (r.members.isEmpty()) {
      teardown(r);
      return;
    }
    if (age < FILM_TICKS) {
      if (r.camera != null && r.camera.isValid())
        r.camera.teleport(cameraSpot(r, age / (double) FILM_TICKS));
      for (Player p : online(r))
        if (r.filming.contains(p.getUniqueId()) && p.getSpectatorTarget() != r.camera) {
          if (p.getGameMode() != GameMode.SPECTATOR) SpectatorState.enter(p);
          p.setSpectatorTarget(r.camera);
        }
      if (age == 50) announceMvp(r);
      if (age == 104) announceAwards(r);
      if (age % 20 == 0) {
        Location c = at(r, 0, 1.5, 0);
        c.getWorld().spawnParticle(Particle.FIREWORK, c.clone().add(0, 2, 0), 30, 3, 1.5, 3, .05);
        c.getWorld().spawnParticle(Particle.END_ROD, c, 20, 4, 2, 4, .02);
      }
      return;
    }
    if (!r.filming.isEmpty() || r.hallBlocks.isEmpty()) openHall(r);
    long left = HALL_TICKS - age;
    if (left <= 0) {
      say(r, "Die Siegeshalle schließt – ab ins Dorf!");
      teardown(r);
      return;
    }
    if (age % 20 == 0) {
      r.bar.name(
          Component.text(
              "SIEGESHALLE · Kisten kaufen · Ausgang: Rechtsklick oder /df dungeon leave · "
                  + clock(left),
              NamedTextColor.GOLD));
      r.bar.progress((float) Math.clamp(left / (double) (HALL_TICKS - FILM_TICKS), 0, 1));
      for (org.bukkit.block.Block b : r.hallBlocks)
        b.getWorld()
            .spawnParticle(
                "vexit".equals(r.clickables.get(b)) ? Particle.PORTAL : Particle.WAX_OFF,
                b.getLocation().add(.5, 1.2, .5),
                "vexit".equals(r.clickables.get(b)) ? 30 : 6,
                .3,
                .4,
                .3,
                .2);
    }
  }

  private void announceMvp(Run r) {
    UUID mvp = r.stats.mvp(r.members);
    if (mvp == null) return;
    DungeonStats.Line l = r.stats.of(mvp);
    String subtitle =
        r.members.size() == 1
            ? DungeonStats.fmt(l.damage) + " Schaden · " + l.kills + " Gegner · beste Kombo " + l.bestCombo
            : "Schadenskönig · "
                + DungeonStats.fmt(l.damage)
                + " Schaden ("
                + Math.round(r.stats.share(mvp) * 100)
                + " % der Gruppe)";
    for (Player p : online(r)) {
      p.showTitle(bigTitle("★ " + name(mvp) + " ★", NamedTextColor.GOLD, subtitle, 45));
      p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1.2f);
    }
  }

  private void announceAwards(Run r) {
    List<DungeonStats.Award> awards = r.stats.awards(r.members);
    for (Player p : online(r)) {
      DungeonStats.Award own =
          awards.stream()
              .filter(a -> a.player().equals(p.getUniqueId()) && !a.title().equals("Schadenskönig"))
              .findFirst()
              .orElse(null);
      DungeonStats.Line l = r.stats.of(p.getUniqueId());
      p.showTitle(
          own != null
              ? bigTitle(own.title(), NamedTextColor.AQUA, own.detail(), 45)
              : bigTitle(
                  "Gut gekämpft!",
                  NamedTextColor.AQUA,
                  DungeonStats.fmt(l.damage) + " Schaden · " + l.kills + " Gegner",
                  45));
      p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1, 1.4f);
    }
  }

  private void openHall(Run r) {
    Location stand = standable(at(r, 0, 0, 2));
    for (UUID id : new ArrayList<>(r.filming)) {
      Player p = Bukkit.getPlayer(id);
      if (p == null) continue;
      p.setSpectatorTarget(null);
      SpectatorState.restore(p);
      Location to = stand.clone();
      to.setDirection(at(r, 0, 1, -4).toVector().subtract(to.toVector()));
      p.teleport(to);
    }
    r.filming.clear();
    if (r.camera != null) r.camera.remove();
    r.camera = null;
    if (!r.hallBlocks.isEmpty()) return;
    DungeonPlan.Room room = room(r);
    if (!r.endless) {
      for (int[] c : new int[][] {{-3, -4}, {0, -5}, {3, -4}}) placeHall(r, at(r, c[0], 0, c[1]), "vchest");
      label(r, room, 0, 2.3, -4.5, "GEWÖLBEKISTEN\nRechtsklick: kaufen · bis zu 3 pro Spieler", NamedTextColor.GOLD);
    }
    placeHall(r, at(r, 0, 0, 6), "vexit");
    label(r, room, 0, 2.2, 6, "AUSGANG\nRechtsklick: zurück ins Dorf", NamedTextColor.AQUA);
    summary(r);
    for (Player p : online(r)) {
      Profile data = plugin.profile(p);
      if (r.endless) {
        plugin.tell(
            p,
            "Tiefengang: Ebene "
                + (r.floor - 1)
                + " geschafft · Wochenrekord Ebene "
                + DeepDescent.weekBest(data, DeepDescent.currentWeek())
                + " · Allzeit Ebene "
                + data.deepBest
                + " · Rangliste: /df top");
        plugin.tell(p, "Ausgang: Seelenanker oder /df dungeon leave · Halle schließt in 3 Minuten.");
        continue;
      }
      plugin.tell(
          p,
          LootChests.available(data)
              ? "Gewölbekiste für dich: "
                  + Hud.money(LootChests.price(data))
                  + " (noch "
                  + (LootChests.MAX - data.chestBought)
                  + ") · Rechtsklick auf eine Kiste."
              : "Die Kisten dieses Laufs hast du schon geöffnet.");
      plugin.tell(p, "Du gehst, wann du willst: Ausgang oder /df dungeon leave · Halle schließt in 3 Minuten.");
    }
  }

  private void placeHall(Run r, Location at, String action) {
    org.bukkit.block.Block b = standable(at).getBlock();
    if (!b.isPassable() || !b.getType().isAir()) return;
    if (action.equals("vchest")) {
      b.setType(Material.CHEST, false);
      if (b.getBlockData() instanceof org.bukkit.block.data.Directional d) {
        d.setFacing(org.bukkit.block.BlockFace.SOUTH);
        b.setBlockData(d, false);
      }
    } else b.setType(Material.RESPAWN_ANCHOR, false);
    r.hallBlocks.add(b);
    r.clickables.put(b, action);
  }

  /** The end screen in chat: every player's numbers and the awards. */
  private void summary(Run r) {
    List<String> out = new ArrayList<>();
    out.add(
        r.endless
            ? "━━━━━━ TIEFENGANG · Ebene " + (r.floor - 1) + " geschafft ━━━━━━"
            : "━━━━━━ ABSCHLUSS · " + r.variant.title + " L" + r.level + " ━━━━━━");
    out.add(
        "Zeit "
            + clock(r.clearTicks)
            + " · "
            + r.members.size()
            + (r.members.size() == 1 ? " Spieler" : " Spieler")
            + " · Gesamtschaden "
            + DungeonStats.fmt(r.stats.total()));
    int place = 1;
    for (UUID id : r.stats.ranking(r.members)) {
      DungeonStats.Line l = r.stats.of(id);
      out.add(
          "#"
              + place++
              + " "
              + name(id)
              + " · "
              + DungeonStats.fmt(l.damage)
              + " Schaden ("
              + Math.round(r.stats.share(id) * 100)
              + " %) · Boss "
              + DungeonStats.fmt(l.bossDamage)
              + " · "
              + l.kills
              + " Kills · "
              + l.crits
              + " Krits · Kombo "
              + l.bestCombo);
      out.add(
          "     eingesteckt "
              + DungeonStats.fmt(l.taken)
              + " · geheilt "
              + DungeonStats.fmt(l.healed)
              + " · "
              + l.downs
              + "× K.O.");
      String hits = r.stats.hitsOf(id);
      if (!hits.isEmpty()) out.add("     getroffen von: " + hits);
    }
    Map.Entry<String, Integer> nemesis = r.stats.nemesis();
    if (nemesis != null)
      out.add("☠ Gefährlichster Angriff: " + nemesis.getKey() + " (" + nemesis.getValue() + " Treffer)");
    for (DungeonStats.Award a : r.stats.awards(r.members))
      out.add("★ " + a.title() + ": " + name(a.player()) + " – " + a.detail());
    for (String line : out) say(r, line);
  }

  private void leaveHall(Run r, Player p) {
    UUID id = p.getUniqueId();
    if (r.filming.remove(id)) {
      p.setSpectatorTarget(null);
      SpectatorState.restore(p);
    }
    remove(r, id);
    p.hideBossBar(r.bar);
    plugin.goHome(p);
    plugin.tell(p, "Siegeshalle verlassen. Deine Beute liegt im Beutel (/df loot).");
    // At home the reward window shows every new item with its values.
    Bukkit.getScheduler()
        .runTaskLater(
            plugin,
            () -> {
              Player back = Bukkit.getPlayer(id);
              if (back != null && plugin.playing(back) && !active(back))
                plugin.menus().open(back, "reward");
            },
            30);
    if (r.members.isEmpty()) teardown(r);
    else say(r, p.getName() + " hat die Siegeshalle verlassen.");
  }

  @EventHandler(priority = EventPriority.LOW)
  public void hallClick(PlayerInteractEvent e) {
    Player p = e.getPlayer();
    Run r = membership.get(p.getUniqueId());
    if (r == null || r.stage != Stage.VICTORY || e.getClickedBlock() == null) return;
    String action = r.clickables.get(e.getClickedBlock());
    if (action == null || !action.startsWith("v")) return;
    e.setCancelled(true);
    if (e.getHand() != EquipmentSlot.HAND || !e.getAction().isRightClick()) return;
    if (p.getLocation().distanceSquared(e.getClickedBlock().getLocation()) > 42) return;
    if (action.equals("vexit")) {
      Bukkit.getScheduler().runTask(plugin, () -> {
        if (p.isOnline() && membership.get(p.getUniqueId()) == r) leaveHall(r, p);
      });
      return;
    }
    int before = plugin.profile(p).chestBought;
    plugin.change(p, LootChests::buy);
    if (plugin.profile(p).chestBought > before) {
      Location l = e.getClickedBlock().getLocation().add(.5, 1, .5);
      p.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, l, 40, .3, .5, .3, .3);
      p.playSound(l, Sound.BLOCK_CHEST_OPEN, 1, 1);
      p.playSound(l, Sound.ENTITY_PLAYER_LEVELUP, .6f, 1.6f);
      plugin.items().refresh(p, plugin.profile(p));
    } else p.playSound(p.getLocation(), Sound.BLOCK_CHEST_LOCKED, .8f, 1);
  }

  // ---- Spectating ----

  public boolean watching(Player p) {
    return watching.containsKey(p.getUniqueId());
  }

  /** Watch the run of {@code target}, or the next running dungeon when no name is given. */
  public void spectate(Player p, String target) {
    if (active(p))
      throw new IllegalArgumentException("Du bist selbst im Dungeon – zuschauen geht danach.");
    if (plugin.combat().fighting(p))
      throw new IllegalArgumentException("Zuerst den Kampf beenden.");
    Run r;
    if (target != null) {
      Player t = Bukkit.getPlayerExact(target);
      r = t == null ? null : membership.get(t.getUniqueId());
      if (r == null || r.ended)
        throw new IllegalArgumentException(target + " ist gerade in keinem Dungeon.");
    } else {
      List<Run> open =
          runs.values().stream()
              .filter(x -> !x.ended)
              .sorted(Comparator.comparingInt(x -> x.slot))
              .toList();
      if (open.isEmpty()) throw new IllegalArgumentException("Gerade läuft kein Dungeon.");
      Run current = watching.get(p.getUniqueId());
      r = open.get(current == null ? 0 : (open.indexOf(current) + 1) % open.size());
    }
    watch(p, r);
  }

  /** Admin view: watch the run in instance slot {@code slot}. */
  public void watchSlot(Player p, int slot) {
    Run r = runs.get(slot);
    if (r == null || r.ended) throw new IllegalArgumentException("Dieser Lauf ist schon vorbei.");
    if (active(p)) throw new IllegalArgumentException("Du bist selbst im Dungeon.");
    watch(p, r);
  }

  private void watch(Player p, Run r) {
    UUID id = p.getUniqueId();
    Run before = watching.put(id, r);
    if (before != null) {
      before.watchers.remove(id);
      p.hideBossBar(before.bar);
    }
    r.watchers.add(id);
    p.closeInventory();
    SpectatorState.enter(p);
    p.setSpectatorTarget(null);
    p.showBossBar(r.bar);
    p.teleport(watchPoint(r));
    plugin.tell(
        p,
        "Du schaust zu: "
            + names(r)
            + " · "
            + r.variant.title
            + " · "
            + DungeonRules.MODES[r.mode]
            + ". Spieler anklicken = ihre Sicht · /df dungeon zuschauen = nächster Dungeon ·"
            + " /df dungeon leave = beenden.");
    if (before != r)
      for (Player m : online(r)) plugin.tell(m, p.getName() + " schaut euch zu.");
  }

  private Location watchPoint(Run r) {
    DungeonPlan.Room room = room(r);
    Location l = at(r, 0, Math.min(7, room.height - 2), room.hd - 3);
    l.setPitch(25);
    return l;
  }

  private String names(Run r) {
    return r.members.stream().map(this::name).reduce((a, b) -> a + ", " + b).orElse("?");
  }

  public void stopWatching(Player p, String message) {
    Run r = watching.remove(p.getUniqueId());
    if (r == null) return;
    r.watchers.remove(p.getUniqueId());
    p.hideBossBar(r.bar);
    if (p.getGameMode() == GameMode.SPECTATOR) p.setSpectatorTarget(null);
    SpectatorState.restore(p);
    if (message != null) plugin.tell(p, message);
  }

  /** Watchers stay inside the dungeon they watch. */
  private void keepWatchers() {
    for (Map.Entry<UUID, Run> w : new ArrayList<>(watching.entrySet())) {
      Player p = Bukkit.getPlayer(w.getKey());
      Run r = w.getValue();
      if (p == null) {
        watching.remove(w.getKey());
        r.watchers.remove(w.getKey());
        continue;
      }
      if (p.getGameMode() != GameMode.SPECTATOR) {
        // Someone changed the gamemode by hand: treat it as leaving.
        stopWatching(p, "Zuschauen beendet.");
        continue;
      }
      if (p.getSpectatorTarget() == null && !inside(r, p.getLocation()))
        p.teleport(watchPoint(r));
    }
  }

  /** One line per running dungeon, for the admin overview. */
  public record RunInfo(int slot, String title, List<String> lines) {}

  public List<RunInfo> overview() {
    List<RunInfo> out = new ArrayList<>();
    for (Run r : runs.values().stream().sorted(Comparator.comparingInt(x -> x.slot)).toList()) {
      if (r.ended) continue;
      long seconds = (tick - r.started) / 20;
      out.add(
          new RunInfo(
              r.slot,
              r.variant.title + " · " + Zone.at(r.zone).title + " · " + DungeonRules.MODES[r.mode],
              List.of(
                  "Spieler: " + names(r),
                  "Level " + r.level + " · " + r.stage.name() + " · Welle " + r.wave + "/" + r.totalWaves,
                  "Läuft seit " + seconds / 60 + ":" + String.format("%02d", seconds % 60),
                  "Zuschauer: " + r.watchers.size())));
    }
    return out;
  }

  /** Admin: close a run without rewards (for stuck or abused runs). */
  public void closeRun(int slot, String by) {
    Run r = runs.get(slot);
    if (r != null && r.stage == Stage.VICTORY) {
      say(r, "Die Siegeshalle wurde von " + by + " geschlossen. Deine Beute ist im Beutel.");
      closeHall(r);
      return;
    }
    if (r == null || r.ended) throw new IllegalArgumentException("Dieser Lauf ist schon vorbei.");
    finish(r, false, "Dieser Dungeon wurde von " + by + " beendet. Deine Ausrüstung bleibt erhalten.");
  }

  /** Admin or shutdown: a victory hall is simply closed; its rewards were paid on the win. */
  private void closeHall(Run r) {
    if (r.stage == Stage.VICTORY) teardown(r);
  }

  public String verify() {
    if (verification.startsWith("RUNNING")) return verification;
    int slot = 0;
    while (runs.containsKey(slot)) slot++;
    if (slot >= 4) return "BUSY";
    Run r =
        new Run(
            slot,
            0,
            0,
            List.of(UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID()),
            31);
    r.diagnostic = true;
    runs.put(slot, r);
    verification = "RUNNING: arena and model lifecycle";
    return verification;
  }

  public String verification() {
    return verification;
  }

  @Override
  public void close() {
    task.cancel();
    for (Run r : new ArrayList<>(runs.values()))
      if (r.ended) closeHall(r);
      else finish(r, false, "Serverneustart: Dungeon beendet, keine Ausrüstung verloren.");
  }
}
