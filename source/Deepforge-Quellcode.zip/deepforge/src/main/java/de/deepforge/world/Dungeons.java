package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import java.util.*;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

/**
 * Bounded, private cooperative instances in the plugin-owned world. All state runs on the main
 * thread.
 */
public final class Dungeons implements Listener, AutoCloseable {
  private final DeepforgePlugin plugin;
  private final PartyBook parties = new PartyBook();
  private final Map<UUID, Run> membership = new HashMap<>();
  private final Map<Integer, Run> runs = new HashMap<>();
  private final Map<UUID, Enemy> enemies = new HashMap<>();
  private final Map<UUID, Long> clicks = new HashMap<>();
  private final Random random = new Random();
  private final BukkitTask task;
  private long tick;
  private String verification = "Noch nicht gestartet";
  private static final Material[] RUNES = {
    Material.RED_CONCRETE, Material.BLUE_CONCRETE, Material.LIME_CONCRETE, Material.YELLOW_CONCRETE
  };
  private static final String[] NAMES = {"Rot", "Blau", "Grün", "Gelb"};

  private enum Stage {
    BUILDING,
    COUNTDOWN,
    WAVE,
    TRAVEL,
    SIDE,
    MEMORY,
    SEALS,
    COMPLETE
  }

  private static final class Run {
    final UUID id = UUID.randomUUID();
    final int slot, zone, mode, x, level, totalWaves;
    // Players currently taking part; follows leaves and disconnects during the run.
    int size;
    final LinkedHashSet<UUID> members;
    final Map<UUID, Long> disconnected = new HashMap<>();
    final Set<UUID> down = new HashSet<>();
    final Map<UUID, Integer> healingDrops = new HashMap<>();
    final DungeonBlessings blessings = new DungeonBlessings();
    final Set<Long> chunks = new HashSet<>();
    final List<Enemy> mobs = new ArrayList<>();
    final List<Entity> decorations = new ArrayList<>();
    final BossBar bar =
        BossBar.bossBar(
            Component.text("Gewölbe wird vorbereitet"),
            1,
            BossBar.Color.PURPLE,
            BossBar.Overlay.PROGRESS);
    Stage stage = Stage.BUILDING;
    long deadline, started, sealTicks;
    int room, cursor, wave, memoryStep, mistakes, pending, spawned, reinforcements;
    int optionalFlags, pendingOptional, diagnosticExtra;
    boolean challengeAttempted, key;
    final boolean[] branchOpen = new boolean[3];
    final Set<Integer> shrinesBuilt = new HashSet<>();
    Villager captive;
    boolean diagnostic, ended;
    boolean diagnosticValid = true, diagnosticElite, diagnosticBoss;
    int diagnosticChecked;
    final Set<Integer> diagnosticKinds = new HashSet<>();
    List<Integer> sequence = List.of();

    Run(int slot, int zone, int mode, List<UUID> ids) {
      this(slot, zone, mode, ids, 1);
    }

    Run(int slot, int zone, int mode, List<UUID> ids, int level) {
      this.slot = slot;
      this.zone = zone;
      this.mode = mode;
      this.level = level;
      totalWaves = DungeonRules.waves(level);
      size = Math.max(1, ids.size());
      x = -512 - slot * 128;
      members = new LinkedHashSet<>(ids);
    }
  }

  private static final class Enemy {
    Run run;
    Mob mob;
    MonsterRig rig;
    MonsterHealthIndicator health;
    int kind;
    boolean boss, elite;
    double hp, max;
    long attackAt, resolveAt, recoilAt;
    final BossPressure pressure = new BossPressure();
    Location sweepOrigin;
    int spell;
    Location marker, secondary;
    Vector direction;
  }

  public Dungeons(DeepforgePlugin plugin) {
    this.plugin = plugin;
    Bukkit.getPluginManager().registerEvents(this, plugin);
    task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1, 2);
  }

  public boolean active(Player p) {
    return membership.containsKey(p.getUniqueId());
  }

  public PartyBook parties() {
    return parties;
  }

  public boolean down(Player p) {
    Run r = membership.get(p.getUniqueId());
    return r != null && r.down.contains(p.getUniqueId());
  }

  public boolean shrineBlock(Player p, org.bukkit.block.Block block) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || block == null) return false;
    if (optionalBlock(r, block)) return true;
    if (r.stage != Stage.TRAVEL) return false;
    for (int i = 0; i < 3; i++) if (block.equals(at(r, -8 + i * 8, 0, -10).getBlock())) return true;
    return false;
  }

  private Location at(Run r, double x, double y, double z) {
    return worldAt(r, x, y, z + DungeonLayout.roomZ(r.room));
  }

  private Location worldAt(Run r, double x, double y, double z) {
    return new Location(plugin.mines().world(), r.x + x + .5, 65 + y, -512 + z + .5, 180, 0);
  }

  public boolean contains(Player p) {
    Run r = membership.get(p.getUniqueId());
    return r != null && inside(r, p.getLocation());
  }

  private boolean inside(Run r, Location l) {
    return l.getWorld().equals(plugin.mines().world())
        && DungeonLayout.contains(l.getX() - r.x - .5, l.getY() - 65, l.getZ() + 511.5);
  }

  private List<Player> online(Run r) {
    return r.members.stream()
        .map(Bukkit::getPlayer)
        .filter(Objects::nonNull)
        .filter(Player::isOnline)
        .toList();
  }

  private List<Player> living(Run r) {
    return online(r).stream()
        .filter(
            p ->
                !r.down.contains(p.getUniqueId())
                    && plugin.playing(p)
                    && !p.isDead()
                    && inside(r, p.getLocation()))
        .toList();
  }

  private void say(Run r, String text) {
    online(r).forEach(p -> plugin.tell(p, text));
  }

  private void partySay(PartyBook.Party party, String text) {
    for (UUID id : party.members) {
      Player p = Bukkit.getPlayer(id);
      if (p != null) plugin.tell(p, text);
    }
  }

  public void command(Player p, String[] args) {
    if (!plugin.playing(p)) {
      plugin.tell(p, "Zuerst /df start.");
      return;
    }
    try {
      if (args[0].equalsIgnoreCase("dungeon")) {
        if (args.length > 1 && args[1].equalsIgnoreCase("hint")) {
          Run r = membership.get(p.getUniqueId());
          if (r != null && r.stage == Stage.MEMORY) {
            r.deadline = tick + 100;
            r.memoryStep = 0;
            say(r, "Runenfolge wird erneut angezeigt. Danach bei der ersten Rune beginnen.");
          }
          return;
        }
        if (args.length > 1 && args[1].equalsIgnoreCase("leave")) {
          withdraw(p);
          return;
        }
        if (args.length > 1 && args[1].equalsIgnoreCase("start")) {
          int mode = args.length > 2 ? Integer.parseInt(args[2]) - 1 : 0;
          int zone = args.length > 3 ? Integer.parseInt(args[3]) - 1 : commonZone(p);
          start(p, zone, mode);
          return;
        }
        open(p, commonZone(p));
        return;
      }
      String action = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "status";
      UUID id = p.getUniqueId();
      if (active(p) && !action.equals("status"))
        throw new IllegalArgumentException(
            "Während des Laufs ist die Party fest. /df dungeon leave zum Aussteigen.");
      switch (action) {
        case "create" -> {
          parties.create(id);
          plugin.tell(p, "Party erstellt. /df party invite <Spieler> · maximal 4 Spieler.");
        }
        case "invite" -> {
          Player guest = args.length > 2 ? Bukkit.getPlayerExact(args[2]) : null;
          if (guest == null || !plugin.playing(guest) || active(guest))
            throw new IllegalArgumentException("Der Spieler muss online und in Deepforge sein.");
          parties.invite(id, guest.getUniqueId(), System.currentTimeMillis());
          plugin.tell(
              guest,
              p.getName() + " lädt dich ins Gewölbe ein. /df party accept (60 Sekunden gültig).");
          plugin.tell(p, "Einladung an " + guest.getName() + " gesendet.");
        }
        case "accept" -> {
          // An invitation is invalidated when its leader starts a run.
          PartyBook.Party joined = parties.accept(id, System.currentTimeMillis());
          if (joined.members.stream().anyMatch(membership::containsKey)) {
            parties.leave(id);
            throw new IllegalArgumentException("Die Gruppe ist schon im Dungeon.");
          }
          partySay(
              joined, p.getName() + " ist beigetreten. Alle bestätigen neu mit /df party ready.");
        }
        case "ready" -> {
          boolean ready = parties.ready(id);
          partySay(
              parties.get(id), p.getName() + (ready ? " ist bereit." : " ist nicht mehr bereit."));
        }
        case "leave" -> {
          parties.leave(id);
          plugin.tell(p, "Party verlassen.");
        }
        default -> {
          PartyBook.Party party = parties.get(id);
          if (party == null)
            plugin.tell(
                p, "/df party create · invite <Name> · accept · ready · leave. Solo: /df dungeon.");
          else {
            plugin.tell(p, "Party: " + party.members.size() + "/4 · Leiter: " + name(party.leader));
            for (UUID member : party.members)
              plugin.tell(
                  p, name(member) + (party.ready.contains(member) ? " · Bereit" : " · Wartet"));
          }
        }
      }
    } catch (IllegalArgumentException e) {
      plugin.tell(p, DeepforgePlugin.readable(e, e.getMessage() == null ? "Ungültige Eingabe." : e.getMessage()));
    }
  }

  private String name(UUID id) {
    Player p = Bukkit.getPlayer(id);
    return p == null ? "Offline" : p.getName();
  }

  private int commonZone(Player p) {
    PartyBook.Party party = parties.get(p.getUniqueId());
    int zone = plugin.profile(p).zone;
    if (party != null)
      for (UUID id : party.members) {
        Player m = Bukkit.getPlayer(id);
        if (m != null) zone = Math.min(zone, plugin.profile(m).zone);
      }
    return zone;
  }

  private int previewLevel(Player p) {
    PartyBook.Party party = parties.get(p.getUniqueId());
    List<Profile> profiles = new ArrayList<>();
    profiles.add(plugin.profile(p));
    if (party != null)
      for (UUID id : party.members) {
        Player member = Bukkit.getPlayer(id);
        if (member != null && !id.equals(p.getUniqueId())) profiles.add(plugin.profile(member));
      }
    return DungeonRules.groupLevel(profiles);
  }

  private static final class Menu implements InventoryHolder {
    Inventory inventory;
    int zone;
    UUID owner;

    public Inventory getInventory() {
      return inventory;
    }
  }

  private ItemStack icon(Material material, String title, String... lore) {
    String model =
        switch (material) {
          case LIME_DYE -> "relic";
          case PLAYER_HEAD -> "gear_helmet";
          case OAK_DOOR, BARRIER -> "close";
          case IRON_SWORD -> "weapon_sword";
          case DIAMOND_SWORD -> "weapon_spear";
          case NETHERITE_SWORD -> "weapon_hammer";
          case ARROW -> "back";
          case AMETHYST_SHARD -> "healing_crystal";
          case CHEST -> "crate";
          case CLOCK -> "clock";
          default -> "handbook";
        };
    return plugin.items().button(material, model, title, lore);
  }

  public void open(Player p, int zone) {
    int level = active(p) ? membership.get(p.getUniqueId()).level : previewLevel(p);
    Menu m = new Menu();
    m.zone = Math.clamp(zone, 0, commonZone(p));
    m.owner = p.getUniqueId();
    m.inventory =
        Bukkit.createInventory(m, 54, plugin.menus().styledTitle(p, "GEWÖLBE · L" + level));

    PartyBook.Party party = parties.get(p.getUniqueId());
    m.inventory.setItem(
        11,
        icon(
            Material.LIME_DYE,
            "Bereitschaft ändern",
            party == null
                ? "Solo: direkt Schwierigkeit anklicken"
                : party.ready.size() + "/" + party.members.size() + " bereit"));
    m.inventory.setItem(
        13,
        icon(
            Material.PLAYER_HEAD,
            "Deine Party",
            party == null
                ? "Solo (1 Spieler)"
                : party.members.stream().map(this::name).reduce((a, b) -> a + ", " + b).orElse(""),
            "/df party invite <Name>",
            DungeonRules.waves(level)
                + " Wellen · 2 Rätsel · "
                + DungeonRules.TIME_MINUTES
                + " Minuten",
            "Gruppenlevel = höchstes Dungeonlevel",
            "Bedingung: " + DungeonRules.conditionName(level),
            "Niederlage: alle gleichzeitig besiegt",
            "Wiederbelebung nach geschaffter Phase"));
    m.inventory.setItem(
        15,
        icon(
            Material.OAK_DOOR,
            "Dungeon / Party verlassen",
            "Im Lauf verfällt dein Abschlussanspruch"));
    for (int mode = 0; mode < 3; mode++)
      m.inventory.setItem(
          20 + mode * 2,
          icon(
              mode == 0
                  ? Material.IRON_SWORD
                  : mode == 1 ? Material.DIAMOND_SWORD : Material.NETHERITE_SWORD,
              DungeonRules.MODES[mode] + " starten",
              "Level " + level + " · " + DungeonRules.coins(m.zone, mode, level) + " $ pro Person",
              "Levelausrüstung + 2 Lebenssplitter + Materialien",
              "Mythisch: "
                  + DungeonRules.mythicThreshold(mode, level) / 10.
                  + "% · Legendär: "
                  + (DungeonRules.legendaryThreshold(mode, level)
                          - DungeonRules.mythicThreshold(mode, level))
                      / 10.
                  + "%",
              "Nach jedem Sieg: dein Dungeonlevel +1",
              "Boss: "
                  + (int)
                      DungeonRules.health(
                          m.zone,
                          mode,
                          party == null ? 1 : party.members.size(),
                          DungeonRules.waves(level),
                          true,
                          level)
                  + " LP",
              mode == 0
                  ? "Alle Mitglieder müssen bereit sein"
                  : "Vorherige Schwierigkeit für alle erforderlich"));
    m.inventory.setItem(
        4,
        icon(
            Material.BOOK,
            Zone.at(m.zone).title,
            "3 verbundene Hallen · echte Tore und Laufwege",
            "Gruppe: " + (party == null ? 1 : party.members.size()) + "/4",
            "Runenwand → Siegelgalerie → Bossheiligtum"));
    m.inventory.setItem(29, icon(Material.ARROW, "Vorheriges Gebiet"));
    m.inventory.setItem(33, icon(Material.ARROW, "Nächstes Gebiet"));
    int wins = Arrays.stream(plugin.profile(p).dungeonWins).sum();
    m.inventory.setItem(
        40,
        icon(
            Material.BOOK,
            "Dein Dungeonlevel: " + DungeonRules.level(plugin.profile(p)),
            "Siege: " + wins + " · Lebenssplitter: " + plugin.profile(p).healingCharges + "/12",
            "Beute bleibt im Beutebeutel: /df loot",
            "Keine normale Bossfreischaltung durch Dungeons",
            "Abbruch und Wiederanmeldung: 60 Sekunden Kulanz"));
    m.inventory.setItem(
        31,
        icon(
            Material.CHEST,
            "Route durch das Gewölbe",
            "Halle 1: zwei Wellen + Runenfolge",
            "Halle 2: zwei Wellen + Gruppensiegel",
            "Halle 3: " + (DungeonRules.waves(level) - 4) + " Wellen mit Endboss",
            "Tore öffnen sich durch gelöste Rätsel.",
            "Optional: Eliteprüfung / Fluchprüfung, Rettung, Schlüsselschatz",
            "Bonusbeute gibt es erst nach dem Endboss.",
            "Gemeinsam zu Fuß zur nächsten Halle gehen."));
    m.inventory.setItem(45, icon(Material.ARROW, "Zurück: Kampf & Ausrüstung"));
    m.inventory.setItem(47, icon(Material.BOOK, "Hauptmenü"));
    m.inventory.setItem(49, icon(Material.BARRIER, "Schließen"));
    m.inventory.setItem(
        53,
        icon(
            Material.AMETHYST_SHARD,
            "Heilung im Kampf",
            "Lebenssplitter: Rechtsklick oder /df heal",
            "4 LP + 35% Leben · 20 Sekunden Pause"));
    p.openInventory(m.inventory);
  }

  @EventHandler
  public void click(InventoryClickEvent e) {
    if (!(e.getView().getTopInventory().getHolder() instanceof Menu m)) return;
    e.setCancelled(true);
    if (!(e.getWhoClicked() instanceof Player p) || !m.owner.equals(p.getUniqueId())) return;
    int slot = e.getRawSlot();
    try {
      if (slot == 49) p.closeInventory();
      else if (slot == 45 || slot == 47) plugin.menus().open(p, slot == 45 ? "combat" : "main");
      else if (slot == 11) {
        if (active(p)) throw new IllegalArgumentException("Die Gruppe ist bereits im Dungeon.");
        if (parties.get(p.getUniqueId()) == null) parties.create(p.getUniqueId());
        parties.ready(p.getUniqueId());
        open(p, m.zone);
      } else if (slot == 15) {
        p.closeInventory();
        if (active(p)) withdraw(p);
        else parties.leave(p.getUniqueId());
      } else if (slot == 29 || slot == 33) open(p, m.zone + (slot == 29 ? -1 : 1));
      else if (slot == 20 || slot == 22 || slot == 24) start(p, m.zone, (slot - 20) / 2);
    } catch (IllegalArgumentException ex) {
      plugin.tell(p, ex.getMessage());
    }
  }

  @EventHandler
  public void drag(InventoryDragEvent e) {
    if (e.getView().getTopInventory().getHolder() instanceof Menu) e.setCancelled(true);
  }

  private void start(Player leader, int zone, int mode) {
    if (zone < 0 || zone > 6 || mode < 0 || mode > 2)
      throw new IllegalArgumentException("/df dungeon start <1..3 Schwierigkeit> <1..7 Gebiet>");
    if (parties.get(leader.getUniqueId()) == null) {
      parties.create(leader.getUniqueId());
      parties.ready(leader.getUniqueId());
    }
    List<UUID> roster = parties.roster(leader.getUniqueId());
    for (UUID id : roster) {
      Player p = Bukkit.getPlayer(id);
      if (p == null
          || !plugin.playing(p)
          || p.isDead()
          || p.getGameMode() != GameMode.SURVIVAL
          || plugin.combat().fighting(p))
        throw new IllegalArgumentException(
            "Alle müssen online, im Überlebensmodus und außerhalb eines Kampfes sein.");
      Profile data = plugin.profile(p);
      if (data.zone < zone || mode > 0 && data.dungeonWins[zone * 3 + mode - 1] == 0)
        throw new IllegalArgumentException(
            p.getName() + " hat Gebiet oder Schwierigkeit noch nicht freigeschaltet.");
    }
    int slot = 0;
    while (runs.containsKey(slot)) slot++;
    if (slot >= 4)
      throw new IllegalArgumentException("Alle vier Gewölbe sind belegt. Bitte kurz warten.");
    int level =
        DungeonRules.groupLevel(
            roster.stream().map(Bukkit::getPlayer).map(plugin::profile).toList());
    Run r = new Run(slot, zone, mode, roster, level);
    r.started = tick;
    runs.put(slot, r);
    for (UUID id : roster) {
      Player p = Bukkit.getPlayer(id);
      plugin.combat().clear(p, false);
      p.closeInventory();
      membership.put(id, r);
      p.showBossBar(r.bar);
    }
    parties.get(leader.getUniqueId()).ready.clear();
    say(
        r,
        "Runengewölbe wird aufgebaut. Gruppe: "
            + roster.size()
            + " · "
            + DungeonRules.MODES[mode]
            + " · Level "
            + level
            + " · "
            + DungeonRules.conditionName(level)
            + ".");
  }

  private void tick() {
    tick += 2;
    for (Run r : new ArrayList<>(runs.values())) {
      try {
        step(r);
      } catch (RuntimeException ex) {
        plugin.getLogger().log(java.util.logging.Level.SEVERE, "Dungeon instance failed", ex);
        finish(r, false, "Gewölbe wegen eines Fehlers geschlossen; dein Inventar bleibt erhalten.");
        if (r.diagnostic) verification = "FAILED: " + ex.getMessage();
      }
    }
  }

  /** Enemy health keeps its percentage when the party shrinks or grows mid-run. */
  private void resize(Run r) {
    int now =
        Math.max(
            1,
            (int)
                r.members.stream()
                    .filter(id -> !r.disconnected.containsKey(id) && Bukkit.getPlayer(id) != null)
                    .count());
    if (now == r.size) return;
    double ratio = RapidCombat.partyHealth(now) / RapidCombat.partyHealth(r.size);
    for (Enemy e : r.mobs) {
      e.max *= ratio;
      e.hp *= ratio;
    }
    say(
        r,
        "Gewölbe passt sich an: "
            + now
            + " Spieler – Gegner werden "
            + (now < r.size ? "schwächer." : "stärker."));
    r.size = now;
  }

  private void step(Run r) {
    if (r.stage == Stage.BUILDING) {
      build(r);
      return;
    }
    if (!r.diagnostic) resize(r);
    if (r.diagnostic) {
      if (tick >= r.deadline) {
        r.diagnosticValid &=
            r.mobs.size() <= DungeonRules.activeLimit(r.size)
                && r.mobs.stream().allMatch(m -> m.mob.isValid());
        for (Enemy enemy : new ArrayList<>(r.mobs)) {
          r.diagnosticChecked++;
          r.diagnosticKinds.add(enemy.kind);
          r.diagnosticElite |= enemy.elite;
          r.diagnosticBoss |= enemy.boss;
          removeEnemy(enemy);
        }
        refill(r);
        if (r.mobs.isEmpty() && r.wave < r.totalWaves) {
          if (r.wave == 2) {
            memory(r);
            r.diagnosticValid &= r.sequence.size() == 3;
          }
          if (r.wave == 4) {
            seals(r);
            r.diagnosticValid &= r.stage == Stage.SEALS;
          }
          if (r.wave == 2 || r.wave == 4) {
            r.diagnosticValid &=
                worldAt(r, 0, 1, DungeonLayout.roomZ(r.room) - 20).getBlock().getType()
                    == Material.IRON_BARS;
            travel(r);
            for (int z = DungeonLayout.roomZ(r.room) - 19;
                z >= DungeonLayout.roomZ(r.room) - 40;
                z--)
              r.diagnosticValid &=
                  worldAt(r, 0, 0, z).getBlock().isPassable()
                      && worldAt(r, 0, 1, z).getBlock().isPassable()
                      && worldAt(r, 0, -1, z).getBlock().getType().isSolid();
            if (r.wave == 2) {
              startChallenge(r, true);
              r.diagnosticExtra = r.mobs.size();
              for (Enemy extra : new ArrayList<>(r.mobs)) {
                r.diagnosticValid &= extra.mob.isValid() && extra.elite;
                r.diagnosticChecked++;
                removeEnemy(extra);
              }
              completeChallenge(r);
            } else {
              rescue(r);
              takeKey(r);
            }
            enterNextRoom(r);
            if (r.room == 2) {
              sideGate(r, true);
              takeTreasure(r);
            }
          }
          beginWave(r);
        }
        if (!r.mobs.isEmpty()) {
          r.deadline = tick + 20;
          return;
        }
        int expected = r.diagnosticExtra;
        for (int wave = 1; wave <= r.totalWaves; wave++)
          expected += DungeonRules.count(wave, r.size, r.level);
        boolean valid =
            r.diagnosticValid
                && r.diagnosticChecked == expected
                && r.diagnosticKinds.size() == 4
                && r.diagnosticElite
                && r.diagnosticBoss
                && r.optionalFlags
                    == (AdventureRewards.CURSE
                        | AdventureRewards.RESCUE
                        | AdventureRewards.TREASURE)
                && r.key
                && r.room == 2
                && at(r, 0, -1, 0).getBlock().getType().isSolid()
                && at(r, -9, 0, -16).getBlock().getType() == RUNES[0];
        String diagnosticDetail =
            "checks="
                + r.diagnosticValid
                + ", count="
                + r.diagnosticChecked
                + "/"
                + expected
                + ", kinds="
                + r.diagnosticKinds
                + ", elite="
                + r.diagnosticElite
                + ", boss="
                + r.diagnosticBoss
                + ", floor="
                + at(r, 0, -1, 0).getBlock().getType()
                + ", rune="
                + at(r, -9, 0, -16).getBlock().getType();
        List<Chunk> checkedChunks =
            r.chunks.stream()
                .map(key -> plugin.mines().world().getChunkAt((int) (long) key, (int) (key >> 32)))
                .toList();
        finish(r, false, "");
        valid &=
            enemies.values().stream().noneMatch(e -> e.run == r)
                && plugin.mines().world().getEntities().stream()
                    .noneMatch(e -> inside(r, e.getLocation()))
                && checkedChunks.stream()
                    .noneMatch(c -> c.getPluginChunkTickets().contains(plugin));
        verification =
            valid
                ? "OK: level "
                    + r.level
                    + ", party "
                    + r.size
                    + ", "
                    + r.totalWaves
                    + " waves, "
                    + r.diagnosticChecked
                    + " enemies, 4 kinds, elites, boss, queued spawns, runes, healing item, 3"
                    + " connected rooms, walkable gates, optional challenge, rescue, key chest,"
                    + " cleanup, chunk tickets"
                : "FAILED: "
                    + diagnosticDetail
                    + ", remaining="
                    + plugin.mines().world().getEntities().stream()
                        .filter(e -> inside(r, e.getLocation()))
                        .map(e -> e.getType().name())
                        .toList()
                    + ", tickets="
                    + checkedChunks.stream()
                        .filter(c -> c.getPluginChunkTickets().contains(plugin))
                        .count();
      } else {
        for (Enemy e : r.mobs) e.rig.animate(e.mob.getLocation(), tick, true, false, false);
        circle(at(r, 0, 0, 0), 4, Color.RED);
        beam(at(r, -8, 0, -8), new Vector(0, 0, 1));
        circle(at(r, 8, 0, 0), 5, Color.LIME);
      }
      return;
    }
    for (UUID id : new ArrayList<>(r.members)) {
      Player p = Bukkit.getPlayer(id);
      if (p == null) {
        r.disconnected.putIfAbsent(id, tick);
        if (tick - r.disconnected.get(id) > 1200) remove(r, id);
      } else if (r.disconnected.containsKey(id)) {
        if (tick - r.disconnected.get(id) > 1200) {
          remove(r, id);
          p.hideBossBar(r.bar);
          plugin.goHome(p);
        }
      } else if (!plugin.playing(p)) {
        remove(r, id);
        p.hideBossBar(r.bar);
      } else if (!inside(r, p.getLocation())) p.teleport(checkpoint(r, r.down.contains(id)));
    }
    if (r.members.isEmpty()) {
      finish(r, false, "Gruppe aufgelöst.");
      return;
    }
    if (tick - r.started > DungeonRules.TIME_TICKS) {
      finish(r, false, "Zeitlimit erreicht. Neuer Versuch im Dungeonmenü.");
      return;
    }
    if (r.members.stream().allMatch(r.down::contains)) {
      finish(r, false, "Die Gruppe wurde besiegt. Eure Ausrüstung bleibt erhalten.");
      return;
    }
    if (living(r).isEmpty()) return;
    if (r.stage == Stage.TRAVEL) {
      int nextRoom = DungeonLayout.nextRoom(r.wave);
      if (living(r).stream()
          .allMatch(p -> DungeonLayout.arrived(nextRoom, p.getX() - r.x - .5, p.getZ() + 511.5)))
        enterNextRoom(r);
      else if (tick % 20 == 0)
        circle(worldAt(r, 0, .1, DungeonLayout.roomZ(nextRoom) + 10), 2, Color.AQUA);
    }
    if (r.stage == Stage.COUNTDOWN && tick >= r.deadline) beginWave(r);
    if (r.stage == Stage.SIDE) {
      for (Enemy e : new ArrayList<>(r.mobs)) enemyTick(e);
      if (r.mobs.isEmpty()) completeChallenge(r);
    }
    if (r.stage == Stage.WAVE) {
      for (Enemy e : new ArrayList<>(r.mobs)) enemyTick(e);
      refill(r);
      if (r.mobs.isEmpty() && r.pending == 0) {
        revive(r);
        if (r.wave == r.totalWaves) {
          finish(r, true, "Runengewölbe bezwungen!");
          return;
        }
        if (r.wave == 2) memory(r);
        else if (r.wave == 4) seals(r);
        else countdown(r);
      }
    } else if (r.stage == Stage.SEALS) {
      int needed = Math.max(1, Math.min(3, living(r).size()));
      Set<UUID> used = new HashSet<>();
      for (int i = 0; i < needed; i++) {
        Location pad = at(r, -6 + i * 6, 0, 0);
        for (Player p : living(r))
          if (!used.contains(p.getUniqueId()) && p.getLocation().distanceSquared(pad) < 2.2) {
            used.add(p.getUniqueId());
            break;
          }
        circle(pad, 1, Color.AQUA);
      }
      r.sealTicks = used.size() == needed ? r.sealTicks + 2 : 0;
      if (r.sealTicks >= 60) {
        say(r, "Siegel stabilisiert. Das Tor zum Heiligtum öffnet sich!");
        travel(r);
      }
    }
    if (tick % 20 == 0) {
      String label =
          switch (r.stage) {
            case TRAVEL ->
                "Tor offen: gemeinsam in " + DungeonLayout.name(DungeonLayout.nextRoom(r.wave));
            case SIDE -> "Optionale Prüfung · " + r.mobs.size() + " Elitegegner";
            case MEMORY -> "Runenwand: " + r.memoryStep + "/3 · Linksklick";
            case SEALS ->
                "Siegel: auf türkisfarbene Platten stellen · " + (r.sealTicks / 20) + "/3 s";
            case COUNTDOWN -> "Nächste Welle in " + Math.max(0, (r.deadline - tick) / 20) + " s";
            default ->
                "Welle "
                    + r.wave
                    + "/"
                    + r.totalWaves
                    + " · Gegner "
                    + r.mobs.size()
                    + " +"
                    + r.pending;
          };
      // Sequence text stays visible only during the memory window.
      if (r.stage == Stage.MEMORY && tick < r.deadline)
        label = "Merken: " + String.join(" → ", r.sequence.stream().map(i -> NAMES[i]).toList());
      r.bar.name(
          Component.text(
              DungeonLayout.name(r.room)
                  + " · L"
                  + r.level
                  + " · "
                  + label
                  + " · "
                  + Math.max(0, (DungeonRules.TIME_TICKS - tick + r.started) / 1200)
                  + " Min"));
      r.bar.progress(
          (float)
              Math.clamp(
                  (r.wave - 1 + (r.stage == Stage.WAVE ? 0.5 : 1)) / (double) r.totalWaves, 0, 1));
    }
  }

  private void build(Run r) {
    for (int n = 0; n < 900 && r.cursor < DungeonLayout.SIZE; n++, r.cursor++) {
      int x = r.cursor % DungeonLayout.WIDTH - 48;
      int z = 20 - r.cursor / DungeonLayout.WIDTH % DungeonLayout.LENGTH;
      int y = r.cursor / (DungeonLayout.WIDTH * DungeonLayout.LENGTH) - 1;
      Location loc = worldAt(r, x, y, z);
      var chunk = loc.getChunk();
      if (r.chunks.add(chunk.getChunkKey())) chunk.addPluginChunkTicket(plugin);
      loc.getBlock().setType(DungeonLayout.material(r.zone, x, y, z), false);
    }
    if (r.cursor < DungeonLayout.SIZE) return;
    for (int room = 0; room < 3; room++) {
      int center = DungeonLayout.roomZ(room);
      for (int i = 0; i < 4; i++) {
        worldAt(r, -9 + i * 6, 0, center - 16).getBlock().setType(RUNES[i], false);
        worldAt(r, -9 + i * 6, -1, center - 16).getBlock().setType(Material.SEA_LANTERN, false);
      }
      for (int i = 0; i < 3; i++)
        worldAt(r, -6 + i * 6, -1, center)
            .getBlock()
            .setType(Material.WAXED_OXIDIZED_CUT_COPPER, false);
      final int index = room;
      r.decorations.add(
          plugin
              .mines()
              .world()
              .spawn(
                  worldAt(r, 0, 4, center + 16),
                  TextDisplay.class,
                  display -> {
                    display.text(Component.text(DungeonLayout.name(index), NamedTextColor.GOLD));
                    display.setBillboard(Display.Billboard.CENTER);
                    display.setPersistent(false);
                  }));
    }
    worldAt(r, -10, 0, DungeonLayout.roomZ(1) + 11).getBlock().setType(Material.BARREL, false);
    worldAt(r, -19, 0, DungeonLayout.roomZ(2) + 4).getBlock().setType(Material.LODESTONE, false);
    r.captive =
        plugin
            .mines()
            .world()
            .spawn(
                worldAt(r, -44, 0, DungeonLayout.roomZ(1)),
                Villager.class,
                false,
                v -> {
                  v.setAI(false);
                  v.setAdult();
                  v.setInvulnerable(true);
                  v.setSilent(true);
                  v.setPersistent(false);
                  v.customName(Component.text("Gefangener Bergarbeiter", NamedTextColor.GOLD));
                  v.setCustomNameVisible(true);
                });
    r.decorations.add(r.captive);
    branchLabel(r, 0, -38, -3, "ELITEPRÜFUNG · 1 Bonusfund\nRechtsklick · Gruppenleiter startet");
    branchLabel(
        r, 0, -38, 3, "FLUCHPRÜFUNG · 2 Bonusfunde\nDoppelte Gegner-LP · nur eine Prüfung wählbar");
    branchLabel(
        r,
        1,
        -38,
        -3,
        "ZELLENSCHLOSS · Rechtsklick\nRettung: Bonusfund + dauerhafter Händlerrabatt");
    branchLabel(r, 1, -10, 11, "Verstaubtes Fass · untersuchen");
    branchLabel(r, 2, -19, 4, "SCHATZKAMMER · Schlüssel benötigt\nRechtsklick zum Öffnen");
    branchLabel(r, 2, -38, -3, "VERSIEGELTE BEUTE\nRechtsklick · Auszahlung erst nach dem Sieg");
    if (r.diagnostic) {
      r.stage = Stage.WAVE;
      Profile probeProfile = new Profile();
      probeProfile.healingCharges = 12;
      var crystal = plugin.items().healingCrystal(probeProfile);
      r.diagnosticValid &=
          crystal.getAmount() == 12
              && plugin.items().kind(crystal).equals("heal")
              && new NamespacedKey("deepforge", "healing_crystal")
                  .equals(crystal.getItemMeta().getItemModel());
      r.decorations.add(
          plugin
              .mines()
              .world()
              .spawn(
                  at(r, 0, 2, 10),
                  ItemDisplay.class,
                  display -> {
                    display.setItemStack(crystal);
                    display.setPersistent(false);
                  }));
      r.wave = 0;
      beginWave(r);
      r.deadline = tick + 20;
      return;
    }
    for (Player p : online(r)) {
      if (!plugin.playing(p)) continue;
      p.teleport(at(r, 0, 0, 12));
      plugin.combat().applyStats(p);
      p.setHealth(Gear.stats(plugin.profile(p)).health());
      p.setFoodLevel(20);
    }
    say(
        r,
        "Rote Kreise und orange Strahlen kündigen Angriffe an. Ausweichen: Sneak + Rechtsklick mit"
            + " Waffe. /df dungeon leave beendet deinen Lauf.");
    countdown(r);
  }

  private Location checkpoint(Run r, boolean down) {
    return at(r, down ? 17 : 0, 0, down ? 2 : 12);
  }

  private void gate(Run r, int z, boolean open) {
    for (int x = -3; x <= 3; x++)
      for (int y = 0; y < 5; y++)
        worldAt(r, x, y, z).getBlock().setType(open ? Material.AIR : Material.IRON_BARS, false);
    worldAt(r, 0, 1, z)
        .getWorld()
        .playSound(worldAt(r, 0, 1, z), Sound.BLOCK_IRON_DOOR_OPEN, 1, .6f);
  }

  private void travel(Run r) {
    r.stage = Stage.TRAVEL;
    gate(r, DungeonLayout.roomZ(r.room) - 20, true);
    gate(r, DungeonLayout.roomZ(DungeonLayout.nextRoom(r.wave)) + 20, true);
    sideGate(r, true);
    if (!r.shrinesBuilt.add(r.room)) return;
    for (int i = 0; i < 3; i++) {
      at(r, -8 + i * 8, 0, -10)
          .getBlock()
          .setType(
              new Material[] {
                    Material.RED_GLAZED_TERRACOTTA,
                    Material.BLUE_GLAZED_TERRACOTTA,
                    Material.LIME_GLAZED_TERRACOTTA
                  }
                  [i],
              false);
      final String title =
          new String[] {
                "KRAFT · +8% Schaden",
                "SCHUTZ · -8% erlittener Schaden",
                "QUELLE · 35% Leben heilen"
              }
              [i];
      r.decorations.add(
          plugin
              .mines()
              .world()
              .spawn(
                  at(r, -8 + i * 8, 2, -10),
                  TextDisplay.class,
                  display -> {
                    display.text(
                        Component.text(
                            title + "\nEin Segen pro Halle · Rechtsklick", NamedTextColor.AQUA));
                    display.setBillboard(Display.Billboard.CENTER);
                    display.setPersistent(false);
                  }));
    }
    say(r, "Das Tor ist offen! Geht gemeinsam durch die Galerie zur nächsten Halle.");
    say(r, "Die drei Runenschreine sind aktiv: Jeder darf einen Segen für diesen Lauf wählen.");
  }

  private void branchLabel(Run r, int room, int x, int z, String text) {
    r.decorations.add(
        plugin
            .mines()
            .world()
            .spawn(
                worldAt(r, x, 2.5, DungeonLayout.roomZ(room) + z),
                TextDisplay.class,
                d -> {
                  d.text(Component.text(text, NamedTextColor.GOLD));
                  d.setBillboard(Display.Billboard.CENTER);
                  d.setPersistent(false);
                }));
  }

  private void sideGate(Run r, boolean open) {
    r.branchOpen[r.room] = open;
    for (int z = -2; z <= 2; z++)
      for (int y = 0; y < 5; y++)
        at(r, -20, y, z).getBlock().setType(open ? Material.AIR : Material.IRON_BARS, false);
  }

  private boolean optionalBlock(Run r, org.bukkit.block.Block b) {
    return b.equals(at(r, -38, 0, -3).getBlock())
        || r.room == 0 && b.equals(at(r, -38, 0, 3).getBlock())
        || r.room == 1 && b.equals(at(r, -10, 0, 11).getBlock())
        || r.room == 2 && b.equals(at(r, -19, 0, 4).getBlock());
  }

  private void startChallenge(Run r, boolean curse) {
    r.challengeAttempted = true;
    r.pendingOptional = curse ? AdventureRewards.CURSE : AdventureRewards.ELITE;
    r.stage = Stage.SIDE;
    gate(r, DungeonLayout.roomZ(r.room) - 20, false);
    gate(r, DungeonLayout.roomZ(r.room + 1) + 20, false);
    for (int i = 0; i < r.size + 2; i++) {
      spawn(r, false, i % 4, -34 - i % 3 * 3, -6 + i * 2);
      Enemy e = r.mobs.getLast();
      e.elite = true;
      e.hp =
          e.max =
              DungeonRules.health(r.zone, r.mode, r.size, r.wave, false, r.level)
                  * (curse ? 2 : 1.4);
      e.mob.customName(Component.text(enemyName(e), NamedTextColor.RED));
      health(e);
    }
    say(
        r,
        curse
            ? "Fluchprüfung gestartet! Besiegt die Elite für zwei Bonusfunde."
            : "Eliteprüfung gestartet! Besiegt die Elite für einen Bonusfund.");
  }

  private void completeChallenge(Run r) {
    r.optionalFlags |= r.pendingOptional;
    r.pendingOptional = 0;
    revive(r);
    travel(r);
    say(r, "Prüfung bestanden! Die Beute wird nach dem Endboss ausgezahlt.");
  }

  private void rescue(Run r) {
    if ((r.optionalFlags & AdventureRewards.RESCUE) != 0) return;
    for (int z = -1; z <= 1; z++)
      for (int y = 0; y < 3; y++) at(r, -42, y, z).getBlock().setType(Material.AIR, false);
    r.captive.teleport(at(r, -40, 0, 0));
    r.captive.customName(Component.text("Bergarbeiter gerettet!", NamedTextColor.GREEN));
    r.optionalFlags |= AdventureRewards.RESCUE;
    say(r, "Bergarbeiter befreit! Bei Abschluss: Bonusfund und dauerhaft 20% Händlerrabatt.");
  }

  private void takeKey(Run r) {
    r.key = true;
    at(r, -10, 0, 11).getBlock().setType(Material.AIR, false);
    say(r, "Gruppenschlüssel gefunden! Er öffnet die Schatzkammer in der letzten Halle.");
  }

  private void takeTreasure(Run r) {
    if (!r.key || (r.optionalFlags & AdventureRewards.TREASURE) != 0) return;
    r.optionalFlags |= AdventureRewards.TREASURE;
    at(r, -38, 0, -3).getBlock().setType(Material.BARREL, false);
    say(r, "Schatz gesichert! Ein zusätzlicher Bonusfund wartet nach dem Endboss.");
  }

  @EventHandler
  public void captiveInteraction(PlayerInteractEntityEvent e) {
    if (runs.values().stream().anyMatch(r -> r.captive == e.getRightClicked())) {
      e.setCancelled(true);
      plugin.tell(
          e.getPlayer(), "Das Zellenschloss neben dem Käfig öffnet die Tür nach dem Siegelrätsel.");
    }
  }

  @EventHandler(priority = EventPriority.LOW)
  public void optional(PlayerInteractEvent e) {
    Player p = e.getPlayer();
    Run r = membership.get(p.getUniqueId());
    if (r == null
        || down(p)
        || e.getHand() != EquipmentSlot.HAND
        || !e.getAction().isRightClick()
        || e.getClickedBlock() == null
        || !optionalBlock(r, e.getClickedBlock())) return;
    e.setCancelled(true);
    if (p.getLocation().distanceSquared(e.getClickedBlock().getLocation()) > 36) return;
    if (r.room == 0) {
      if (r.stage != Stage.TRAVEL || r.challengeAttempted) {
        plugin.tell(p, "Diese Prüfung ist noch nicht verfügbar oder bereits gewählt.");
        return;
      }
      PartyBook.Party party = parties.get(p.getUniqueId());
      if (party != null && !party.leader.equals(p.getUniqueId())) {
        plugin.tell(p, "Nur der Gruppenleiter startet die Prüfung.");
        return;
      }
      if (living(r).stream().anyMatch(m -> Math.abs(m.getZ() - at(r, 0, 0, 0).getZ()) >= 19)) {
        plugin.tell(p, "Alle müssen zuerst in diese Halle zurückkehren.");
        return;
      }
      startChallenge(r, e.getClickedBlock().equals(at(r, -38, 0, 3).getBlock()));
    } else if (r.room == 1) {
      if (e.getClickedBlock().equals(at(r, -10, 0, 11).getBlock())) {
        if (!r.key) takeKey(r);
      } else if (r.stage == Stage.TRAVEL && r.branchOpen[1]) rescue(r);
    } else {
      if (!r.key) {
        plugin.tell(
            p,
            "Der Schlüssel liegt in der Siegelgalerie. Beim nächsten Lauf nach dem Fass suchen!");
        return;
      }
      if (e.getClickedBlock().equals(at(r, -19, 0, 4).getBlock())) {
        sideGate(r, true);
        plugin.tell(p, "Schatzkammer geöffnet!");
      } else if (r.branchOpen[2]) takeTreasure(r);
    }
  }

  private void enterNextRoom(Run r) {
    gate(r, DungeonLayout.roomZ(r.room) - 20, false);
    r.room = DungeonLayout.nextRoom(r.wave);
    gate(r, DungeonLayout.roomZ(r.room) + 20, false);
    say(r, DungeonLayout.name(r.room) + " erreicht. Bereitet euch vor!");
    countdown(r);
  }

  private void countdown(Run r) {
    r.stage = Stage.COUNTDOWN;
    r.deadline = tick + 100;
  }

  private void beginWave(Run r) {
    r.wave++;
    r.stage = Stage.WAVE;
    r.spawned = 0;
    r.reinforcements = 0;
    r.pending = DungeonRules.count(r.wave, r.size, r.level);
    refill(r);
    say(
        r,
        r.wave == r.totalWaves
            ? "ENDWELLE · Runenwächter mit Verstärkung! Unter 50% Leben beschleunigt er seine"
                + " Zauber."
            : "Welle "
                + r.wave
                + "/"
                + r.totalWaves
                + " · "
                + DungeonRules.conditionName(r.level)
                + (r.level >= 4 ? " · Jäger lauern auf euch!" : ""));
  }

  private void refill(Run r) {
    while (r.pending > 0 && r.mobs.size() < DungeonRules.activeLimit(r.size)) {
      int ordinal = r.spawned;
      double angle = (ordinal * 2.4 + r.wave) % (Math.PI * 2);
      int kind = DungeonRules.kind(r.level, r.wave, ordinal, r.id.getLeastSignificantBits());
      spawn(
          r,
          r.wave == r.totalWaves && ordinal == 0,
          kind,
          Math.cos(angle) * 11,
          Math.sin(angle) * 10);
      r.pending--;
      r.spawned++;
    }
  }

  private void spawn(Run r, boolean boss, int kind, double x, double z) {
    Enemy e = new Enemy();
    e.run = r;
    e.boss = boss;
    e.kind = kind;
    e.elite = !boss && DungeonRules.elite(r.level, r.spawned);
    e.hp =
        e.max =
            DungeonRules.health(r.zone, r.mode, r.size, r.wave, boss, r.level)
                * (e.elite ? 1.6 : 1);
    e.attackAt = tick + 50 + random.nextInt(40);
    e.mob =
        plugin
            .mines()
            .world()
            .spawn(
                at(r, x, 0, z),
                Husk.class,
                false,
                mob -> {
                  mob.setAdult();
                  mob.getEquipment().clear();
                  mob.setPersistent(false);
                  mob.setSilent(true);
                  mob.setInvisible(true);
                  mob.setShouldBurnInDay(false);
                  mob.setRemoveWhenFarAway(false);
                  mob.setCanPickupItems(false);
                  mob.getAttribute(Attribute.MOVEMENT_SPEED)
                      .setBaseValue(
                          (boss ? .24 : kind == 3 ? .34 : .28)
                              * (DungeonRules.condition(r.level) == 1 ? 1.1 : 1));
                  mob.getAttribute(Attribute.SCALE).setBaseValue(boss ? 1.55 : kind == 1 ? 1 : .8);
                  mob.getAttribute(Attribute.KNOCKBACK_RESISTANCE).setBaseValue(0);
                  mob.customName(
                      Component.text(enemyName(e) + " · L" + r.level, NamedTextColor.RED));
                  mob.setCustomNameVisible(false);
                });
    r.mobs.add(e);
    enemies.put(e.mob.getUniqueId(), e);
    RailNavigation.allowRails(e.mob);
    e.rig = new MonsterRig(plugin, e.mob.getLocation(), (r.zone + kind) % 7, boss, kind);
    e.health = new MonsterHealthIndicator(plugin, e.mob.getLocation(), r.members, boss);
    health(e);
  }

  private void health(Enemy e) {
    if (e.health != null)
      e.health.update(
          e.mob.getLocation(),
          e.rig.labelHeight(),
          enemyName(e) + " · L" + e.run.level,
          e.hp,
          e.max,
          e.boss);
  }

  private String enemyName(Enemy e) {
    return (e.elite ? "ELITE · " : "")
        + (e.boss
            ? "Runenwächter"
            : switch (e.kind) {
              case 0 -> "Sprenger";
              case 1 -> "Strahlenwirker";
              case 2 -> "Heilrufer";
              default -> "Rissjäger";
            });
  }

  private void enemyTick(Enemy e) {
    Run r = e.run;
    health(e);
    if (!e.mob.isValid()) throw new IllegalStateException("Dungeon enemy disappeared");
    List<Player> targets = living(r);
    if (targets.isEmpty()) return;
    Player target =
        targets.stream()
            .min(
                Comparator.comparingDouble(
                    p -> p.getLocation().distanceSquared(e.mob.getLocation())))
            .orElseThrow();
    if (e.boss && r.level >= 6) {
      int phase = e.hp < e.max * .33 ? 2 : e.hp < e.max * .66 ? 1 : 0;
      if (phase > r.reinforcements) {
        r.pending += (phase - r.reinforcements) * (1 + r.size);
        r.reinforcements = phase;
        say(r, "Der Wächter ruft Verstärkung! Noch " + r.pending + " Gegner im Anmarsch.");
      }
    }
    if (e.elite && tick % 10 == 0)
      e.mob
          .getWorld()
          .spawnParticle(Particle.ENCHANT, e.mob.getLocation().add(0, 1.5, 0), 5, .4, .6, .4, 0);
    if (!inside(r, e.mob.getLocation())
        || Math.abs(e.mob.getZ() - at(r, 0, 0, 0).getZ()) > 19
        || e.mob.getX() > r.x + 15) e.mob.teleport(at(r, 0, 0, -8));
    e.mob.setTarget(target);
    if (e.boss && rearCounter(e, targets)) return;
    e.mob.setAware(e.resolveAt == 0 && tick >= e.recoilAt);
    e.rig.animate(
        e.mob.getLocation(),
        tick,
        e.resolveAt > 0,
        tick < e.recoilAt,
        e.mob.getVelocity().lengthSquared() > .001);
    if (e.resolveAt > 0) {
      if (e.spell == 0) circle(e.marker, e.boss ? 4 : 2.7, Color.RED);
      else if (e.spell == 1 || e.spell == 3) beam(e.marker, e.direction, e.spell == 3 ? 7 : 18);
      else circle(e.marker, 5, Color.LIME);
      if (e.secondary != null) circle(e.secondary, 2.7, Color.RED);
      if (tick >= e.resolveAt) {
        for (Player p : targets) {
          Vector d = p.getLocation().toVector().subtract(e.marker.toVector());
          boolean hit =
              e.spell == 0
                  ? d.clone().setY(0).lengthSquared() <= (e.boss ? 16 : 7.29)
                  : (e.spell == 1 || e.spell == 3)
                      && d.dot(e.direction) >= 0
                      && d.dot(e.direction) < (e.spell == 3 ? 7 : 18)
                      && Math.abs(d.getX() * e.direction.getZ() - d.getZ() * e.direction.getX())
                          < 1.2;
          if ((e.spell == 1 || e.spell == 3) && !p.hasLineOfSight(e.mob)) hit = false;
          if (e.secondary != null
              && p.getLocation().toVector().subtract(e.secondary.toVector()).setY(0).lengthSquared()
                  <= 7.29) hit = true;
          if (hit)
            hurt(
                r,
                p,
                DungeonRules.damage(r.zone, r.mode, e.boss, r.level, r.size)
                    * (e.elite ? 1.25 : 1));
        }
        if (e.spell == 3) KnockbackMotion.push(e.mob, e.direction.clone().multiply(4));
        if (e.spell == 2)
          for (Enemy ally : r.mobs)
            if (ally != e && ally.mob.getLocation().distanceSquared(e.marker) < 25) {
              ally.hp = Math.min(ally.max, ally.hp + ally.max * .12);
              health(ally);
            }
        e.resolveAt = 0;
        e.secondary = null;
        e.attackAt = tick + DungeonRules.recovery(r.level, e.boss && e.hp < e.max * .5);
      }
    } else if (tick >= e.attackAt) {
      e.spell = e.boss ? (e.spell + 1) % 3 : e.kind;
      e.marker = e.spell == 0 ? target.getLocation().clone() : e.mob.getLocation().clone();
      e.direction = target.getLocation().toVector().subtract(e.marker.toVector()).setY(0);
      if (e.direction.lengthSquared() < .001) e.direction = new Vector(0, 0, 1);
      else e.direction.normalize();
      if (e.boss && e.spell == 0 && DungeonRules.condition(r.level) == 3) {
        e.secondary =
            targets.size() > 1
                ? targets.get((targets.indexOf(target) + 1) % targets.size()).getLocation().clone()
                : target.getLocation().clone().add(target.getX() > r.x ? -4 : 4, 0, 0);
      }
      e.resolveAt = tick + DungeonRules.warning(r.level, e.boss && e.hp < e.max * .5);
      Vector aim = target.getLocation().toVector().subtract(e.mob.getLocation().toVector()).setY(0);
      if (aim.lengthSquared() > .001)
        e.mob.setRotation(e.mob.getLocation().setDirection(aim).getYaw(), 0);
      e.mob
          .getWorld()
          .playSound(
              e.mob.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, .5f, e.spell == 2 ? 1.5f : .6f);
    }
    // Contact pressure is independently rate limited by CombatEngine's hurt protection.
    if (tick % 30 == 0 && target.getLocation().distanceSquared(e.mob.getLocation()) < 3.5)
      hurt(
          r,
          target,
          DungeonRules.damage(r.zone, r.mode, false, r.level, r.size) * .7 * (e.elite ? 1.25 : 1));
  }

  private boolean rearCounter(Enemy e, List<Player> targets) {
    BossPressure.Step step = e.pressure.step(tick, e.resolveAt == 0);
    if (step == BossPressure.Step.NONE) return false;
    e.mob.setAware(false);
    e.mob.setVelocity(new Vector());
    e.attackAt = Math.max(e.attackAt, tick + 20);
    if (step == BossPressure.Step.START) {
      e.sweepOrigin = e.mob.getLocation().clone();
      say(e.run, "RUNDUMSCHLAG! Raus aus dem roten Kreis – auch hinter dem Wächter!");
      e.mob.getWorld().playSound(e.sweepOrigin, Sound.BLOCK_NOTE_BLOCK_BASS, 1, .5f);
    }
    circle(e.sweepOrigin, BossPressure.RADIUS, Color.RED);
    e.rig.animate(e.mob.getLocation(), tick, true, false, false);
    if (step == BossPressure.Step.STRIKE) {
      for (Player p : targets) {
        Vector d = p.getLocation().toVector().subtract(e.sweepOrigin.toVector());
        if (BossPressure.inSweep(d.getX(), d.getY(), d.getZ()) && e.mob.hasLineOfSight(p))
          hurt(
              e.run,
              p,
              DungeonRules.damage(e.run.zone, e.run.mode, true, e.run.level, e.run.size) * 1.35);
      }
      e.mob
          .getWorld()
          .spawnParticle(
              Particle.SWEEP_ATTACK, e.sweepOrigin.clone().add(0, 1, 0), 14, 2, .4, 2, 0);
      e.mob.getWorld().playSound(e.sweepOrigin, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1, .6f);
      e.sweepOrigin = null;
    }
    return true;
  }

  private void circle(Location l, double radius, Color color) {
    for (int i = 0; i < 18; i++) {
      double a = i * Math.PI / 9;
      l.getWorld()
          .spawnParticle(
              Particle.DUST,
              l.clone().add(Math.cos(a) * radius, .15, Math.sin(a) * radius),
              1,
              0,
              0,
              0,
              0,
              new Particle.DustOptions(color, 1.2f));
    }
  }

  private void beam(Location l, Vector direction) {
    beam(l, direction, 18);
  }

  private void beam(Location l, Vector direction, int length) {
    for (int i = 0; i < length; i++)
      l.getWorld()
          .spawnParticle(
              Particle.DUST,
              l.clone().add(direction.clone().multiply(i)).add(0, .3, 0),
              1,
              .12,
              0,
              .12,
              0,
              new Particle.DustOptions(Color.ORANGE, 1.5f));
  }

  private void hurt(Run r, Player p, double amount) {
    if (r.down.contains(p.getUniqueId())) return;
    plugin
        .combat()
        .dungeonDamage(
            p,
            amount * r.blessings.incoming(p.getUniqueId()),
            () -> {
              r.down.add(p.getUniqueId());
              p.setHealth(Math.min(Gear.stats(plugin.profile(p)).health(), 4));
              p.teleport(checkpoint(r, true));
              say(r, p.getName() + " wurde besiegt. Überlebt die Phase für seine Rückkehr!");
            });
  }

  private void revive(Run r) {
    for (Player p : online(r)) {
      if (!plugin.playing(p) || p.isDead()) continue;
      plugin.combat().applyStats(p);
      boolean revived = r.down.remove(p.getUniqueId());
      double max = Gear.stats(plugin.profile(p)).health();
      p.setHealth(revived ? max * .5 : Math.min(max, p.getHealth() + max * .15));
      if (revived) p.teleport(checkpoint(r, false));
    }
    r.down.clear();
  }

  @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
  public void hit(EntityDamageByEntityEvent event) {
    Enemy source = enemies.get(event.getDamager().getUniqueId());
    if (source != null) {
      event.setCancelled(true);
      return;
    }
    Enemy e = enemies.get(event.getEntity().getUniqueId());
    if (e == null) return;
    event.setCancelled(true);
    if (!(event.getDamager() instanceof Player p)
        || membership.get(p.getUniqueId()) != e.run
        || down(p)
        || !plugin.items().kind(p.getInventory().getItemInMainHand()).equals("sword")
        || !p.hasLineOfSight(e.mob)
        || p.getLocation().distanceSquared(e.mob.getLocation()) > 25) return;
    long now = Bukkit.getCurrentTick();
    if (clicks.getOrDefault(p.getUniqueId(), -1L) == now) return;
    clicks.put(p.getUniqueId(), now);
    strike(e, p, RapidCombat.damage(Gear.stats(plugin.profile(p))));
  }

  private void strike(Enemy e, Player p, double damage) {
    strike(e, p, damage, true);
  }

  private void strike(Enemy e, Player p, double damage, boolean procAllowed) {
    if (e.hp <= 0) return;
    ArtifactCombat.Proc proc =
        procAllowed
            ? plugin.adventure().hit(p, e.mob.getUniqueId())
            : new ArtifactCombat.Proc(false, false);
    if (plugin.adventure().fractured(e.mob.getUniqueId())) damage *= 1.15;
    damage *= e.run.blessings.damage(p.getUniqueId());
    Gear.Stats stats = Gear.stats(plugin.profile(p));
    Gear.Item weapon = Gear.equipped(plugin.profile(p), Gear.Slot.WEAPON);
    String style = weapon == null ? "sword" : weapon.style;
    Vector delta = p.getLocation().toVector().subtract(e.mob.getLocation().toVector());
    Vector facing = e.mob.getLocation().getDirection();
    double alignment = WeaponRules.facing(delta.getX(), delta.getZ(), facing.getX(), facing.getZ());
    if (e.boss) e.pressure.hit(tick, alignment, delta.clone().setY(0).lengthSquared());
    boolean backstab = style.equals("dagger") && alignment <= -.5;
    damage *= WeaponRules.multiplier(style, WeaponRules.rearBonus(weapon), false, false, alignment);
    boolean crit = random.nextDouble() < stats.crit();
    if (crit) damage *= stats.critDamage();
    double dealt = Math.min(e.hp, damage);
    e.hp -= dealt;
    health(e);
    e.rig.hurt(tick);
    plugin
        .combat()
        .showDamage(
            p, e.mob.getLocation().add(0, e.boss ? 3.4 : 2, 0), dealt, crit, backstab, false);
    p.playSound(
        p.getLocation(),
        crit ? Sound.ENTITY_PLAYER_ATTACK_CRIT : Sound.ENTITY_PLAYER_ATTACK_STRONG,
        .65f,
        1.2f);
    if (tick >= e.recoilAt + 8 && e.sweepOrigin == null) {
      Vector away = e.mob.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
      if (away.lengthSquared() > .01)
        e.mob.setVelocity(
            away.normalize().multiply(HitFeedback.knockback(style, e.boss, false)).setY(.18));
      e.recoilAt = tick + (e.boss ? 2 : 5);
    }
    if (proc.lightning()) {
      Location origin = e.mob.getLocation().add(0, 1, 0);
      for (Enemy other :
          e.run.mobs.stream()
              .filter(
                  v ->
                      v != e
                          && v.hp > 0
                          && v.mob.getLocation().distanceSquared(origin) < 36
                          && e.mob.hasLineOfSight(v.mob))
              .limit(3)
              .toList()) {
        plugin.adventure().arc(p, origin, other.mob.getLocation().add(0, 1, 0));
        strike(other, p, plugin.adventure().arcDamage(p), false);
      }
    }
    if (proc.fracture())
      plugin.tell(p, "Runenhammer: Ziel 4 Sekunden lang verwundbar (+15% Schaden)!");
    if (e.hp <= 0) {
      plugin.adventure().kill(p, e.mob.getLocation());
      if (!e.boss && random.nextDouble() < (e.elite ? .4 : .12)) {
        living(e.run).stream()
            .filter(
                member ->
                    e.run.healingDrops.getOrDefault(member.getUniqueId(), 0) < 3
                        && plugin.profile(member).healingCharges < Healing.CAPACITY)
            .min(Comparator.comparingInt(member -> plugin.profile(member).healingCharges))
            .ifPresent(
                member -> {
                  e.run.healingDrops.merge(member.getUniqueId(), 1, Integer::sum);
                  plugin.healing().found(member, 1);
                });
      }
      removeEnemy(e);
    }
  }

  public void ability(Player p, String style, Vector facing) {
    Run r = membership.get(p.getUniqueId());
    if (r == null || down(p)) return;
    for (Enemy e : new ArrayList<>(r.mobs)) {
      Vector d = e.mob.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
      double length = d.length();
      boolean hit =
          style.equals("crossbow")
              ? length < 13 && (length < .1 || d.clone().normalize().dot(facing) > .96)
              : style.equals("spear")
                  ? length < 8 && (length < .1 || d.clone().normalize().dot(facing) > .8)
                  : length < 4;
      double bonus =
          style.equals("hammer") && Gear.hasEffect(plugin.profile(p), 4)
              ? 1.35
              : style.equals("spear") && Gear.hasEffect(plugin.profile(p), 3) ? 1.4 : 1;
      if (hit && p.hasLineOfSight(e.mob))
        strike(
            e,
            p,
            Gear.stats(plugin.profile(p)).damage() * (style.equals("hammer") ? 2.1 : 1.5) * bonus);
    }
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void damage(EntityDamageEvent e) {
    if (enemies.containsKey(e.getEntity().getUniqueId())) e.setCancelled(true);
    if (e.getEntity() instanceof Player p && active(p)) e.setCancelled(true);
  }

  @EventHandler
  public void targeting(EntityTargetLivingEntityEvent e) {
    Enemy enemy = enemies.get(e.getEntity().getUniqueId());
    if (enemy != null
        && e.getTarget() != null
        && (!(e.getTarget() instanceof Player p)
            || membership.get(p.getUniqueId()) != enemy.run
            || down(p))) e.setCancelled(true);
  }

  @EventHandler
  public void died(PlayerDeathEvent e) {
    Run r = membership.get(e.getEntity().getUniqueId());
    if (r == null) return;
    r.down.add(e.getEntity().getUniqueId());
    e.setKeepInventory(true);
    e.getDrops().clear();
    e.setKeepLevel(true);
    e.setDroppedExp(0);
  }

  public Location respawnLocation(Player p) {
    Run r = membership.get(p.getUniqueId());
    return r == null ? null : checkpoint(r, r.down.contains(p.getUniqueId()));
  }

  private void memory(Run r) {
    r.stage = Stage.MEMORY;
    r.sequence = DungeonRules.sequence(r.id, 0);
    r.memoryStep = 0;
    r.deadline = tick + 160;
    say(
        r,
        "Runenrätsel: Merkt euch die drei Farben oben. Danach die farbigen Blöcke an der Nordwand"
            + " in dieser Reihenfolge LINKSKLICKEN. /df dungeon hint wiederholt den Hinweis.");
  }

  private void seals(Run r) {
    r.stage = Stage.SEALS;
    r.sealTicks = 0;
    say(
        r,
        "Siegelrätsel: Besetzt die leuchtenden Bodenplatten gleichzeitig für 3 Sekunden. Solo"
            + " reicht die linke Platte, zu zweit die linken zwei, ab drei alle drei.");
  }

  @EventHandler(priority = EventPriority.LOW)
  public void shrine(PlayerInteractEvent e) {
    Player p = e.getPlayer();
    Run r = membership.get(p.getUniqueId());
    if (r == null
        || r.stage != Stage.TRAVEL
        || down(p)
        || e.getHand() != EquipmentSlot.HAND
        || !e.getAction().isRightClick()
        || e.getClickedBlock() == null) return;
    for (int i = 0; i < 3; i++)
      if (e.getClickedBlock().equals(at(r, -8 + i * 8, 0, -10).getBlock())) {
        e.setCancelled(true);
        if (p.getLocation().distanceSquared(e.getClickedBlock().getLocation()) > 36) return;
        double max = Gear.stats(plugin.profile(p)).health();
        if (i == 2 && p.getHealth() >= max) {
          plugin.tell(p, "Du bist bereits vollständig geheilt. Wähle Kraft oder Schutz.");
          return;
        }
        if (!r.blessings.choose(p.getUniqueId(), r.room, i)) {
          plugin.tell(p, "Du hast den Segen dieser Halle bereits gewählt.");
          return;
        }
        if (i == 2) p.setHealth(Math.min(max, p.getHealth() + max * .35));
        plugin.tell(
            p,
            new String[] {
                  "Kraftsegen: +8% Schaden für diesen Lauf.",
                  "Schutzsegen: -8% erlittener Schaden für diesen Lauf.",
                  "Die Quelle heilt 35% deines maximalen Lebens."
                }
                [i]);
        p.playSound(p.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1, 1.2f);
        return;
      }
  }

  @EventHandler(priority = EventPriority.LOW)
  public void puzzle(PlayerInteractEvent e) {
    Player p = e.getPlayer();
    Run r = membership.get(p.getUniqueId());
    if (r == null
        || r.stage != Stage.MEMORY
        || e.getClickedBlock() == null
        || down(p)
        || e.getHand() != EquipmentSlot.HAND) return;
    if (!e.getAction().isLeftClick()) return;
    for (int i = 0; i < 4; i++)
      if (e.getClickedBlock().equals(at(r, -9 + i * 6, 0, -16).getBlock())) {
        e.setCancelled(true);
        if (tick < r.deadline
            || p.getLocation().distanceSquared(e.getClickedBlock().getLocation()) > 36) return;
        if (r.sequence.get(r.memoryStep) == i) {
          r.memoryStep++;
          p.getWorld()
              .playSound(
                  p.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1, .7f + r.memoryStep * .3f);
          if (r.memoryStep == 3) {
            for (Player member : online(r)) {
              Profile data = plugin.profile(member);
              data.discovered.add("tutorial/runes");
              plugin.commit(member, data);
            }
            say(r, "Runenschloss geöffnet!");
            travel(r);
          }
        } else {
          r.memoryStep = 0;
          r.mistakes++;
          r.deadline = tick + 100;
          say(r, "Falsche Rune! Die Reihenfolge wird nochmals angezeigt; die Runen entladen sich.");
          for (Player member : living(r)) hurt(r, member, 2 + r.mode);
        }
        return;
      }
  }

  @EventHandler
  public void move(PlayerMoveEvent e) {
    if (e instanceof PlayerTeleportEvent || !down(e.getPlayer()) || e.getTo() == null) return;
    Location from = e.getFrom(), to = e.getTo();
    if (from.distanceSquared(to) > .0001) {
      Location lock = from.clone();
      lock.setYaw(to.getYaw());
      lock.setPitch(to.getPitch());
      e.setTo(lock);
    }
  }

  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  public void teleport(PlayerTeleportEvent e) {
    if (e.getTo() == null) return;
    Run own = membership.get(e.getPlayer().getUniqueId());
    if (own != null
        && inside(own, e.getTo())
        && !DungeonLayout.accessible(
            own.room, own.stage == Stage.TRAVEL, e.getTo().getZ() + 511.5)) {
      e.setCancelled(true);
      return;
    }
    if (own != null
        && inside(own, e.getTo())
        && e.getTo().getX() < own.x - 19.5
        && !own.branchOpen[own.room]) {
      e.setCancelled(true);
      return;
    }
    for (Run r : runs.values())
      if (inside(r, e.getTo()) && membership.get(e.getPlayer().getUniqueId()) != r) {
        e.setCancelled(true);
        return;
      }
  }

  public void disconnect(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r != null) {
      r.disconnected.put(p.getUniqueId(), tick);
      p.hideBossBar(r.bar);
      say(r, p.getName() + " hat 60 Sekunden zum Wiederbeitreten.");
    } else parties.leave(p.getUniqueId());
  }

  public void resume(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r == null) return;
    if (tick - r.disconnected.getOrDefault(p.getUniqueId(), tick) > 1200) {
      remove(r, p.getUniqueId());
      return;
    }
    r.disconnected.remove(p.getUniqueId());
    p.showBossBar(r.bar);
    if (r.stage != Stage.BUILDING) p.teleport(checkpoint(r, r.down.contains(p.getUniqueId())));
  }

  public void withdraw(Player p) {
    Run r = membership.get(p.getUniqueId());
    if (r == null) return;
    remove(r, p.getUniqueId());
    p.hideBossBar(r.bar);
    plugin.goHome(p);
    plugin.tell(p, "Dungeon verlassen. Keine Abschlussbeute für diesen Lauf.");
    if (r.members.isEmpty()) finish(r, false, "");
  }

  private void remove(Run r, UUID id) {
    r.members.remove(id);
    r.down.remove(id);
    r.disconnected.remove(id);
    membership.remove(id, r);
    parties.leave(id);
    clicks.remove(id);
  }

  private void removeEnemy(Enemy e) {
    enemies.remove(e.mob.getUniqueId());
    e.run.mobs.remove(e);
    if (e.rig != null) e.rig.close();
    if (e.health != null) e.health.close();
    e.mob.remove();
  }

  private void finish(Run r, boolean win, String message) {
    if (r.ended) return;
    r.ended = true;
    try {
      Map<String, RewardDiff> gains =
          win
              ? plugin.rewardDungeon(
                  List.copyOf(r.members),
                  r.id,
                  r.zone,
                  r.mode,
                  tick - r.started,
                  r.level,
                  r.optionalFlags)
              : Map.of();
      if (!message.isBlank()) say(r, message);
      if (win)
        for (Player player : online(r)) {
          plugin.items().refresh(player, plugin.profile(player));
          RewardDiff gain = gains.get(player.getUniqueId().toString());
          if (gain == null) {
            plugin.tell(player, "Diese Belohnung hast du für diesen Lauf bereits erhalten.");
            continue;
          }
          plugin.tell(player, "━━━━━━━ DUNGEON-BEUTE ━━━━━━━");
          for (String line : gain.lines()) plugin.tell(player, "  " + line);
          plugin.tell(player, "Alles ansehen: /df reward · Ausrüsten: /df loot");
          player.showTitle(
              net.kyori.adventure.title.Title.title(
                  net.kyori.adventure.text.Component.text(
                      "SIEG!", net.kyori.adventure.text.format.NamedTextColor.GOLD),
                  net.kyori.adventure.text.Component.text(
                      gain.headline(), net.kyori.adventure.text.format.NamedTextColor.YELLOW)));
          player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
          UUID id = player.getUniqueId();
          // After the teleport home the reward window shows every new item with its values.
          Bukkit.getScheduler()
              .runTaskLater(
                  plugin,
                  () -> {
                    Player back = Bukkit.getPlayer(id);
                    if (back != null && plugin.playing(back) && !active(back))
                      plugin.menus().open(back, "reward");
                  },
                  50);
        }
    } finally {
      r.stage = Stage.COMPLETE;
      for (Enemy e : new ArrayList<>(r.mobs)) removeEnemy(e);
      r.decorations.forEach(Entity::remove);
      r.decorations.clear();
      runs.remove(r.slot, r);
      for (UUID id : new ArrayList<>(r.members)) {
        membership.remove(id, r);
        clicks.remove(id);
        Player p = Bukkit.getPlayer(id);
        if (p != null) {
          p.hideBossBar(r.bar);
          plugin.goHome(p);
        } else parties.leave(id);
      }
      for (long key : r.chunks)
        plugin
            .mines()
            .world()
            .getChunkAt((int) key, (int) (key >> 32))
            .removePluginChunkTicket(plugin);
      r.chunks.clear();
    }
  }

  public String verify() {
    if (verification.startsWith("RUNNING")) return verification;
    int slot = 0;
    while (runs.containsKey(slot)) slot++;
    if (slot >= 4) return "BUSY";
    Run r =
        new Run(
            slot,
            0,
            0,
            List.of(UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID()),
            31);
    r.diagnostic = true;
    runs.put(slot, r);
    verification = "RUNNING: arena and model lifecycle";
    return verification;
  }

  public String verification() {
    return verification;
  }

  @Override
  public void close() {
    task.cancel();
    for (Run r : new ArrayList<>(runs.values()))
      finish(r, false, "Serverneustart: Dungeon beendet, keine Ausrüstung verloren.");
  }
}
