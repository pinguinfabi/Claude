package de.deepforge.world;

import java.util.*;

/** Deterministic, enclosed cave network; coordinates use a zone-relative floor height. */
public final class MineBlueprint {
  public static final int MIN_X = -48, MAX_X = 48, MIN_Z = 24, MAX_Z = 100, MIN_H = -4, MAX_H = 19;
  public static final int ENTRY_X = 0, ENTRY_Z = 35, LIFT_X = 0, LIFT_Z = 32;
  public static final int BOSS_X = 2, BOSS_Z = 85, ALTAR_X = 2, ALTAR_Z = 92;
  private static final int WIDTH = MAX_X - MIN_X + 1, DEPTH = MAX_Z - MIN_Z + 1;

  public record Point(int x, int h, int z) {}

  private record Room(double x, double z, double rx, double rz) {}

  private record Tunnel(double ax, double az, double bx, double bz, double radius) {}

  private final int zone;
  private final String[] cells = new String[WIDTH * DEPTH * (MAX_H - MIN_H + 1)];
  private final int[] floors = new int[WIDTH * DEPTH], ceilings = new int[WIDTH * DEPTH];
  private final boolean[] passages = new boolean[WIDTH * DEPTH];
  private final LinkedHashSet<Integer> oreCells = new LinkedHashSet<>();
  private final List<Point> ores = new ArrayList<>();
  private final List<Point> route = new ArrayList<>();
  private final Set<Integer> safeRoute = new HashSet<>();
  private final List<Room> rooms = new ArrayList<>();
  private final List<Tunnel> tunnels = new ArrayList<>();
  private static final String[][] ROCK = {
    {"stone", "stone", "andesite", "tuff", "cobblestone", "deepslate"},
    {"stone", "calcite", "smooth_basalt", "tuff", "calcite", "andesite"},
    {"tuff", "stone", "mossy_cobblestone", "andesite", "moss_block", "mud"},
    {"deepslate", "stone", "tuff", "prismarine", "dark_prismarine", "andesite"},
    {"basalt", "blackstone", "deepslate", "polished_basalt", "tuff", "blackstone"},
    {"sandstone", "stone", "tuff", "mossy_stone_bricks", "andesite", "sandstone"},
    {"deepslate", "blackstone", "end_stone", "obsidian", "tuff", "deepslate"}
  };

  private MineBlueprint(int zone) {
    this.zone = zone;
  }

  public static MineBlueprint create(int zone) {
    if (zone < 0 || zone > 6) throw new IllegalArgumentException("zone");
    MineBlueprint b = new MineBlueprint(zone);
    b.plan();
    b.excavate();
    b.workings();
    b.theme();
    b.finishRoutes();
    b.placeOres();
    b.stations();
    return b;
  }

  public int size() {
    return cells.length;
  }

  public String state(int i) {
    return cells[i];
  }

  public Set<String> palette() {
    return new HashSet<>(Arrays.asList(cells));
  }

  public List<Point> ores() {
    return Collections.unmodifiableList(ores);
  }

  public List<Point> route() {
    return Collections.unmodifiableList(route);
  }

  public static int index(int x, int h, int z) {
    return ((h - MIN_H) * DEPTH + z - MIN_Z) * WIDTH + x - MIN_X;
  }

  public static Point point(int i) {
    return new Point(i % WIDTH + MIN_X, i / (WIDTH * DEPTH) + MIN_H, (i / WIDTH) % DEPTH + MIN_Z);
  }

  public static boolean inside(int x, int h, int z) {
    return x >= MIN_X && x <= MAX_X && z >= MIN_Z && z <= MAX_Z && h >= MIN_H && h <= MAX_H;
  }

  private int column(int x, int z) {
    return (z - MIN_Z) * WIDTH + x - MIN_X;
  }

  public String at(int x, int h, int z) {
    return inside(x, h, z) ? cells[index(x, h, z)] : "outside";
  }

  public boolean isOre(int x, int h, int z) {
    return inside(x, h, z) && oreCells.contains(index(x, h, z));
  }

  public int floorAt(int x, int z) {
    return floors[column(x, z)];
  }

  private int roofAt(int x, int z) {
    return ceilings[column(x, z)];
  }

  private void put(int x, int h, int z, String state) {
    if (inside(x, h, z)) cells[index(x, h, z)] = state;
  }

  private void box(int x1, int h1, int z1, int x2, int h2, int z2, String state) {
    for (int x = x1; x <= x2; x++)
      for (int z = z1; z <= z2; z++) for (int h = h1; h <= h2; h++) put(x, h, z, state);
  }

  private static int hash(int x, int z, int salt) {
    int h = x * 374761393 + z * 668265263 + salt * 1274126177;
    h = (h ^ (h >>> 13)) * 1274126177;
    return (h ^ (h >>> 16)) & Integer.MAX_VALUE;
  }

  private String rock(int x, int h, int z) {
    // Correlated strata rather than a uniformly speckled wall.
    int layer =
        (int) (h * .43 + Math.sin(x * .19 + z * .08) * 1.5 + Math.cos(z * .21) * 1.8 + zone * 2);
    if (hash(x + h, z, zone) % 13 == 0) layer++;
    return ROCK[zone][Math.floorMod(layer, ROCK[zone].length)];
  }

  private void chain(double radius, int... p) {
    for (int i = 2; i < p.length; i += 2)
      tunnels.add(new Tunnel(p[i - 2], p[i - 1], p[i], p[i + 1], radius));
  }

  private void plan() {
    int shift = (zone % 3 - 1) * 3;
    rooms.add(new Room(0, 34, 5.8, 6.2));
    rooms.add(new Room(shift, 57, 15 + (zone % 2) * 2, 12));
    rooms.add(new Room(-26, 51 + shift, 10, 9 + zone % 3));
    rooms.add(new Room(26, 65 - shift, 11, 10));
    rooms.add(new Room(2, 85, 14, 11));
    if (zone % 2 == 0) rooms.add(new Room(-24, 76, 8, 6));
    else rooms.add(new Room(29, 83, 7, 7));
    chain(3.2, 0, 34, 0, 41, -3, 41, -3, 47, 2, 47, 2, 60, -4, 60, -4, 69, 0, 69, 0, 79, 2, 85);
    chain(3.1, shift, 55, -13, 54, -20, 48, -26, 51 + shift);
    chain(3.0, shift + 8, 60, 17, 61, 26, 65 - shift);
    chain(2.8, -26, 51 + shift, -28, 64, -24, 76, -10, 75, 0, 79);
    chain(2.8, 26, 65 - shift, 29, 78, 29, 83, 17, 83, 2, 85);
  }

  private static double dist(double x, double z, Tunnel t) {
    double dx = t.bx - t.ax, dz = t.bz - t.az;
    double u = Math.clamp(((x - t.ax) * dx + (z - t.az) * dz) / (dx * dx + dz * dz), 0, 1);
    return Math.hypot(x - (t.ax + dx * u), z - (t.az + dz * u));
  }

  private void excavate() {
    for (int x = MIN_X; x <= MAX_X; x++)
      for (int z = MIN_Z; z <= MAX_Z; z++) {
        double r = -10, t = -10;
        double rough =
            .075 * Math.sin(x * .63 + z * .28 + zone) + .06 * Math.sin(z * .71 - x * .14);
        for (Room a : rooms)
          r =
              Math.max(
                  r, 1 - Math.pow((x - a.x) / a.rx, 2) - Math.pow((z - a.z) / a.rz, 2) + rough);
        for (Tunnel a : tunnels)
          t = Math.max(t, 1 - dist(x, z, a) / (a.radius + .3 * Math.sin(z * .47 + x * .3)));
        boolean open = Math.max(r, t) > 0;
        int ground = 0;
        if (open && r > 0 && t < .3)
          ground = (int) Math.floor(1.2 + Math.sin(x * .25 + zone) * .7 + Math.cos(z * .29) * .6);
        int top =
            r > 0
                ? 6
                    + (int) (9 * Math.sqrt(Math.max(0, r)))
                    + (int) Math.round(Math.sin(x * .37 + z * .23))
                : 5 + (int) Math.round(t * 2);
        top = Math.clamp(top, 5, 17);
        floors[column(x, z)] = ground;
        ceilings[column(x, z)] = top;
        passages[column(x, z)] = open;
        for (int h = MIN_H; h <= MAX_H; h++)
          put(x, h, z, open && h > ground && h < top ? "air" : rock(x, h, z));
      }
    // Level, connected service routes coexist with natural ledges at the chamber margins.
    for (Tunnel t : tunnels) {
      int steps = (int) Math.ceil(Math.hypot(t.bx - t.ax, t.bz - t.az) * 2);
      for (int i = 0; i <= steps; i++) {
        int cx = (int) Math.round(t.ax + (t.bx - t.ax) * i / steps),
            cz = (int) Math.round(t.az + (t.bz - t.az) * i / steps);
        for (int dx = -1; dx <= 1; dx++)
          for (int dz = -1; dz <= 1; dz++) {
            int x = cx + dx, z = cz + dz;
            safeRoute.add(column(x, z));
            floors[column(x, z)] = 0;
            put(x, 0, z, hash(x, z, 4) % 3 == 0 ? "coarse_dirt" : "gravel");
            box(x, 1, z, x, 3, z, "air");
          }
      }
    }
    // Combat needs a broad, level space, with rocks and columns around its perimeter.
    for (int x = -7; x <= 11; x++)
      for (int z = 77; z <= 94; z++)
        if (Math.pow((x - 2) / 9.0, 2) + Math.pow((z - 85) / 9.0, 2) <= 1) {
          safeRoute.add(column(x, z));
          floors[column(x, z)] = 0;
          put(x, 0, z, zone == 5 ? "cracked_stone_bricks" : rock(x, 0, z));
          box(x, 1, z, x, 4, z, "air");
        }
  }

  private void frame(int cx, int z, int halfWidth) {
    int beam = 6;
    for (int x : new int[] {cx - halfWidth, cx + halfWidth}) {
      box(x, 0, z, x, 1, z, "cobblestone");
      box(x, 2, z, x, beam, z, "stripped_spruce_log");
      put(x, beam - 1, z - 1, "spruce_stairs[facing=" + (x < cx ? "east" : "west") + ",half=top]");
      put(x, 2, z - 1, "stone_button[face=wall,facing=north]");
    }
    box(cx - halfWidth, beam, z, cx + halfWidth, beam, z, "spruce_log[axis=x]");
    put(cx, beam - 1, z, "lantern[hanging=true]");
  }

  private void workings() {
    // Entry hoist cage and a hand-built, timber-lined access adit.
    box(-3, 0, 30, 3, 0, 38, "spruce_planks");
    for (int x : new int[] {-3, 3})
      for (int z : new int[] {30, 37}) box(x, 1, z, x, 7, z, "dark_oak_log");
    box(-3, 7, 30, 3, 7, 37, "spruce_slab[type=top]");
    for (int x : new int[] {-2, 2}) box(x, 8, 32, x, 10, 32, "chain[axis=y]");
    for (int z : new int[] {38, 44, 72, 78}) frame(z == 44 ? -3 : 0, z, 3);
    frame(-17, 52, 3);
    frame(18, 62, 3);
    // Two large timber trusses, hung from the ceiling with chains.
    for (int z : new int[] {52, 64}) {
      for (int x : new int[] {-11, 11}) {
        int floor = floorAt(x, z);
        box(x, floor + 1, z, x, 8, z, "spruce_log");
        put(x, 9, z, "dark_oak_slab");
      }
      box(-11, 8, z, 11, 8, z, "spruce_log[axis=x]");
      for (int x : new int[] {-7, 0, 7}) {
        box(x, 9, z, x, Math.max(9, roofAt(x, z) - 1), z, "chain[axis=y]");
        put(x, 7, z, "lantern[hanging=true]");
      }
    }
    // Walkable upper viewing gallery on the west side, with a proper staircase.
    box(-12, 4, 53, -8, 4, 64, "spruce_planks");
    for (int z = 53; z <= 64; z++) {
      put(-12, 5, z, "spruce_fence[north=true,south=true]");
      put(-8, 5, z, "spruce_fence[north=true,south=true]");
    }
    for (int z : new int[] {53, 58, 64}) {
      box(-12, 0, z, -12, 3, z, "spruce_log");
      put(-12, 6, z, "lantern");
    }
    for (int i = 0; i < 4; i++) {
      int z = 49 + i;
      box(-11, 0, z, -9, i, z, "spruce_planks");
      box(-11, i + 1, z, -9, 7, z, "air");
      for (int x = -11; x <= -9; x++) put(x, i + 1, z, "spruce_stairs[facing=south]");
    }
    // Work bays: tools, supplies, broken rail stock and ore-loaded carts.
    for (int[] p : new int[][] {{-23, 49}, {23, 63}, {-22, 74}, {25, 81}}) {
      int x = p[0], z = p[1], h = floorAt(x, z);
      if (!at(x, h + 1, z).equals("air")) continue;
      put(x, h + 1, z, "barrel[facing=up]");
      put(x, h + 2, z, "lantern");
      if (at(x + 1, h + 1, z).equals("air")) put(x + 1, h + 1, z, "crafting_table");
    }
    box(6, 0, 48, 8, 0, 51, "spruce_planks");
    put(7, 1, 49, "grindstone[face=floor,facing=south]");
    for (int z = 55; z <= 59; z++) put(7, 1, z, "rail[shape=north_south]");
    box(6, 1, 56, 8, 1, 58, "spruce_slab[type=top]");
    put(7, 2, 57, "raw_iron_block");
    for (int x : new int[] {6, 8})
      for (int z : new int[] {56, 58})
        put(
            x,
            1,
            z,
            "polished_blackstone_button[face=wall,facing=" + (x == 6 ? "west" : "east") + "]");
    // Rock teeth, cracks and hanging dripstone break up the roof silhouette.
    for (int x = -37; x <= 37; x += 5)
      for (int z = 40; z <= 94; z += 5) {
        if (!passages[column(x, z)] || safeRoute.contains(column(x, z))) continue;
        int roof = roofAt(x, z), floor = floorAt(x, z);
        if (roof - floor < 8) continue;
        int length = 2 + hash(x, z, zone) % 3;
        for (int i = 1; i <= length; i++)
          put(
              x,
              roof - i,
              z,
              "pointed_dripstone[vertical_direction=down,thickness="
                  + (i == length ? "tip" : i == 1 ? "base" : "frustum")
                  + "]");
        if (hash(x, z, 9) % 3 == 0)
          put(x, floor + 1, z, "pointed_dripstone[vertical_direction=up,thickness=tip]");
      }
    // Light at junctions and in branch galleries; no mandatory full-bright potion effect.
    for (Tunnel t : tunnels) {
      int steps = Math.max(1, (int) Math.ceil(Math.hypot(t.bx - t.ax, t.bz - t.az) / 7));
      for (int i = 0; i < steps; i++) {
        int x = (int) Math.round(t.ax + (t.bx - t.ax) * i / steps),
            z = (int) Math.round(t.az + (t.bz - t.az) * i / steps);
        int top = roofAt(x, z);
        box(x, 5, z, x, Math.max(5, top - 1), z, "chain[axis=y]");
        put(x, 4, z, "lantern[hanging=true]");
      }
    }
  }

  private void crystal(int x, int z, int height, String block, String lamp) {
    int floor = floorAt(x, z);
    if (!passages[column(x, z)] || safeRoute.contains(column(x, z))) return;
    for (int h = 0; h < height; h++) {
      int radius = h < height / 2 ? 1 : 0;
      for (int dx = -radius; dx <= radius; dx++)
        for (int dz = -radius; dz <= radius; dz++)
          if (!safeRoute.contains(column(x + dx, z + dz)))
            put(x + dx, floor + h + 1, z + dz, h == height - 1 ? lamp : block);
    }
    put(x, floor + 1, z, lamp);
  }

  private void mushroom(int x, int z, int height) {
    int h = floorAt(x, z);
    if (!passages[column(x, z)] || safeRoute.contains(column(x, z))) return;
    box(x, h + 1, z, x, h + height, z, "mushroom_stem");
    for (int dx = -2; dx <= 2; dx++)
      for (int dz = -2; dz <= 2; dz++)
        if (Math.abs(dx) + Math.abs(dz) < 4) {
          put(x + dx, h + height + 1, z + dz, "red_mushroom_block");
          if ((dx + dz) % 3 == 0) put(x + dx, h + height, z + dz, "shroomlight");
        }
  }

  private void pool(int cx, int cz, int radius, boolean lava) {
    for (int x = cx - radius; x <= cx + radius; x++)
      for (int z = cz - radius; z <= cz + radius; z++) {
        if (Math.hypot(x - cx, z - cz) > radius + .3 * Math.sin(x) || !passages[column(x, z)])
          continue;
        if (safeRoute.contains(column(x, z))) continue;
        box(x, -3, z, x, -2, z, lava ? "blackstone" : "clay");
        put(x, -1, z, lava ? "lava[level=0]" : "water[level=0]");
        box(x, 0, z, x, 2, z, "air");
        floors[column(x, z)] = -2;
        if (!lava && hash(x, z, zone) % 5 == 0) put(x, 0, z, "lily_pad");
      }
  }

  private void theme() {
    switch (zone) {
      case 0 -> {
        for (int[] p : new int[][] {{-32, 48}, {30, 70}, {-21, 78}}) {
          int x = p[0], z = p[1], h = floorAt(x, z);
          for (int i = 0; i < 4; i++)
            if (!safeRoute.contains(column(x + i, z)))
              put(x + i, h + 1, z, i % 2 == 0 ? "raw_copper_block" : "coal_block");
        }
        for (int x = -6; x <= 6; x += 6) {
          put(x, 2, 87, "iron_bars[east=true,west=true]");
          put(x, 3, 87, "lantern");
        }
      }
      case 1 -> {
        for (int[] p :
            new int[][] {
              {-12, 60}, {9, 53}, {-29, 45}, {-31, 55}, {30, 60}, {32, 69}, {-9, 85}, {11, 88}
            }) crystal(p[0], p[1], 5 + hash(p[0], p[1], 1) % 5, "amethyst_block", "sea_lantern");
        for (int x = -36; x <= 36; x += 3)
          for (int z = 43; z < 93; z += 4)
            if (passages[column(x, z)] && !safeRoute.contains(column(x, z))) {
              int h = floorAt(x, z);
              if (at(x, h + 1, z).equals("air")) put(x, h + 1, z, "amethyst_cluster[facing=up]");
            }
      }
      case 2 -> {
        for (int[] p : new int[][] {{-11, 60}, {10, 53}, {-29, 45}, {30, 70}, {-8, 86}, {11, 88}})
          mushroom(p[0], p[1], 5);
        for (int x = -37; x < 38; x += 3)
          for (int z = 42; z < 96; z += 3)
            if (passages[column(x, z)] && !safeRoute.contains(column(x, z))) {
              int h = floorAt(x, z), top = roofAt(x, z);
              if (at(x, h + 1, z).equals("air")) put(x, h, z, "moss_block");
              if (top > 7 && hash(x, z, 2) % 2 == 0) {
                box(x, top - 4, z, x, top - 1, z, "cave_vines_plant[berries=true]");
                put(x, top - 5, z, "cave_vines[berries=true]");
              }
            }
        pool(28, 67, 3, false);
      }
      case 3 -> {
        pool(-25, 51, 6, false);
        pool(26, 65, 7, false);
        pool(8, 56, 4, false);
        for (int[] p : new int[][] {{-31, 52}, {31, 61}, {11, 62}, {-8, 85}})
          crystal(p[0], p[1], 3, "prismarine_bricks", "sea_lantern");
        // Cascading seep above the lake; falling water ends below the surrounding floor.
        box(30, 0, 64, 30, 10, 64, "water[level=8]");
        put(30, 11, 64, "water[level=0]");
        box(29, 11, 63, 31, 11, 63, "prismarine");
        for (int x : new int[] {29, 31}) box(x, 11, 64, x, 12, 65, "prismarine");
        put(30, 11, 65, "prismarine");
      }
      case 4 -> {
        for (int z = 51; z <= 66; z += 4) pool(9 + (int) Math.round(Math.sin(z * .3)), z, 3, true);
        pool(-27, 52, 5, true);
        pool(28, 66, 5, true);
        for (int[] p : new int[][] {{-10, 59}, {12, 54}, {-32, 48}, {33, 64}, {-9, 86}, {12, 88}})
          crystal(p[0], p[1], 6, "basalt", "shroomlight");
        box(5, 0, 59, 13, 0, 61, "polished_blackstone_bricks");
        box(5, 1, 59, 13, 3, 61, "air");
        for (int x = 5; x <= 13; x++) {
          put(x, 1, 59, "polished_blackstone_wall[east=low,west=low]");
          put(x, 1, 61, "polished_blackstone_wall[east=low,west=low]");
        }
      }
      case 5 -> {
        for (int[] p : new int[][] {{-9, 80}, {12, 80}, {-9, 91}, {12, 91}, {-29, 47}, {30, 63}}) {
          int x = p[0], z = p[1], h = floorAt(x, z);
          if (safeRoute.contains(column(x, z))) continue;
          box(x - 1, h, z - 1, x + 1, h + 1, z + 1, "chiseled_stone_bricks");
          box(x, h + 2, z, x, h + 7, z, "sandstone");
          box(x - 1, h + 8, z - 1, x + 1, h + 8, z + 1, "cut_sandstone_slab");
          put(x, h + 9, z, "lantern");
        }
        for (int x = -6; x <= 10; x++)
          for (int z = 80; z <= 91; z++)
            if (Math.abs(x - 2) == Math.abs(z - 85)) put(x, 0, z, "chiseled_sandstone");
        put(-6, 1, 91, "decorated_pot");
        put(10, 1, 91, "decorated_pot");
      }
      case 6 -> {
        for (int[] p : new int[][] {{-11, 61}, {10, 52}, {-30, 46}, {32, 67}, {-9, 85}, {12, 88}})
          crystal(p[0], p[1], 8, "obsidian", "pearlescent_froglight");
        for (int x = -6; x <= 10; x += 4) {
          put(x, 6, 87, "amethyst_block");
          put(x, 7, 87, "end_rod[facing=up]");
          box(x, 8, 87, x, roofAt(x, 87) - 1, 87, "chain[axis=y]");
        }
        for (int x = -36; x <= 36; x += 4)
          for (int z = 44; z <= 94; z += 4)
            if (passages[column(x, z)] && !safeRoute.contains(column(x, z))) {
              int h = floorAt(x, z);
              if (at(x, h + 1, z).equals("air")) put(x, h, z, "sculk");
            }
      }
      default -> throw new IllegalStateException();
    }
  }

  private void finishRoutes() {
    // Restore a three-block-high service route after set dressing. Decorative pools cannot cut it.
    for (int col : safeRoute) {
      int x = col % WIDTH + MIN_X, z = col / WIDTH + MIN_Z;
      put(x, 0, z, hash(x, z, 5) % 5 == 0 ? "coarse_dirt" : "gravel");
      box(x, 1, z, x, 3, z, "air");
      floors[col] = 0;
    }
    // A continuous, correctly connected rail track gives the winding main adit a clear direction.
    int[][] points = {
      {0, 35}, {0, 41}, {-3, 41}, {-3, 47}, {2, 47}, {2, 60}, {-4, 60}, {-4, 69}, {0, 69}, {0, 79}
    };
    for (int i = 1; i < points.length; i++) {
      int x = points[i - 1][0], z = points[i - 1][1], tx = points[i][0], tz = points[i][1];
      while (x != tx || z != tz) {
        route.add(new Point(x, 1, z));
        x += Integer.signum(tx - x);
        z += Integer.signum(tz - z);
      }
    }
    route.add(new Point(0, 1, 79));
    for (int i = 0; i < route.size(); i++) {
      Point p = route.get(i),
          a = route.get(Math.max(0, i - 1)),
          b = route.get(Math.min(route.size() - 1, i + 1));
      boolean n = a.z < p.z || b.z < p.z,
          s = a.z > p.z || b.z > p.z,
          w = a.x < p.x || b.x < p.x,
          e = a.x > p.x || b.x > p.x;
      String shape =
          n && e
              ? "north_east"
              : n && w
                  ? "north_west"
                  : s && e
                      ? "south_east"
                      : s && w ? "south_west" : e || w ? "east_west" : "north_south";
      put(p.x, 0, p.z, i % 4 == 0 ? "spruce_planks" : "gravel");
      put(p.x, 1, p.z, "rail[shape=" + shape + "]");
    }
    // A theme's crystals or mushroom canopy must never seal the upper gallery.
    // Its lower landing gets its own side passage, even when a zone's main cavern shifts east.
    box(-14, 0, 47, -12, 0, 55, "gravel");
    box(-14, 1, 47, -12, 3, 55, "air");
    box(-12, 0, 47, -9, 0, 48, "gravel");
    box(-12, 1, 47, -9, 3, 48, "air");
    for (int x = -14; x <= -9; x++)
      for (int z = 47; z <= 55; z++) if (x <= -12 || z <= 48) floors[column(x, z)] = 0;
    box(-12, 4, 53, -8, 4, 64, "spruce_planks");
    box(-11, 5, 53, -9, 7, 64, "air");
    for (int i = 0; i < 4; i++) {
      int z = 49 + i;
      box(-11, 0, z, -9, i, z, "spruce_planks");
      box(-11, i + 2, z, -9, i + 4, z, "air");
      for (int x = -11; x <= -9; x++) put(x, i + 1, z, "spruce_stairs[facing=south]");
    }
  }

  public static boolean passable(String s) {
    return s.equals("air")
        || s.startsWith("rail[")
        || s.startsWith("cave_vines")
        || s.equals("glow_lichen");
  }

  private boolean host(String s) {
    return Arrays.asList(ROCK[zone]).contains(s);
  }

  private void placeOres() {
    Set<Integer> reachable = reachableFloor();
    // Mineable blocks are irregular exposed seams, never rectangular, solid ore cuboids.
    for (int x = -39; x <= 39; x++)
      for (int z = 43; z <= 95; z++) {
        int h = floorAt(x, z);
        if (!reachable.contains(column(x, z))) continue;
        if (!passable(at(x, h + 1, z)) || !passable(at(x, h + 2, z)) || h < 0) continue;
        for (int[] dir : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
          int bx = x + dir[0], bz = z + dir[1];
          double patch =
              Math.sin(bx * .42 + zone)
                  + Math.cos(bz * .49 - zone * .7)
                  + Math.sin((bx + bz) * .31);
          if (patch < .05) continue;
          for (int dy = 1; dy <= 3; dy++) {
            int y = h + dy;
            if (!host(at(bx, y, bz)) || hash(bx + y, bz, zone) % 5 == 0) continue;
            int k = index(bx, y, bz);
            if (oreCells.add(k)) {
              put(bx, y, bz, "note_block[instrument=bass,note=" + zone + ",powered=false]");
              ores.add(new Point(bx, y, bz));
            }
          }
        }
      }
  }

  private Set<Integer> reachableFloor() {
    Set<Integer> seen = new HashSet<>();
    ArrayDeque<int[]> queue = new ArrayDeque<>();
    queue.add(new int[] {ENTRY_X, ENTRY_Z});
    seen.add(column(ENTRY_X, ENTRY_Z));
    while (!queue.isEmpty()) {
      int[] p = queue.remove();
      int oldHeight = floorAt(p[0], p[1]);
      for (int[] d : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
        int x = p[0] + d[0], z = p[1] + d[1];
        if (x <= MIN_X || x >= MAX_X || z <= MIN_Z || z >= MAX_Z) continue;
        int h = floorAt(x, z);
        if (h < 0
            || Math.abs(oldHeight - h) > 1
            || !passable(at(x, h + 1, z))
            || !passable(at(x, h + 2, z))) continue;
        if (seen.add(column(x, z))) queue.add(new int[] {x, z});
      }
    }
    return seen;
  }

  private void stations() {
    box(-1, 0, 31, 1, 0, 36, "spruce_planks");
    box(-1, 1, 33, 1, 3, 36, "air");
    put(LIFT_X, 1, LIFT_Z, "lectern[facing=south]");
    box(ALTAR_X - 1, 0, ALTAR_Z - 1, ALTAR_X + 1, 0, ALTAR_Z + 1, "chiseled_deepslate");
    put(ALTAR_X, 1, ALTAR_Z, "lodestone");
    for (int x : new int[] {ALTAR_X - 2, ALTAR_X + 2}) {
      put(x, 1, ALTAR_Z, "deepslate_brick_wall");
      put(x, 2, ALTAR_Z, "soul_lantern");
    }
  }
}
