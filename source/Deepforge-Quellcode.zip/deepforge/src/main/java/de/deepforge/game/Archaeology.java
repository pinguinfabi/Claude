package de.deepforge.game;

import java.util.*;
import java.util.random.RandomGenerator;

/**
 * Archäologie (0.14.0): every mine hides four finds – three common ones and one rare (★). They turn
 * up while mining, get donated to the museum for money and dust, and every complete mine collection
 * gives a permanent bonus. The Sammlungsbuch shows which ones are still missing.
 */
public final class Archaeology {
  private Archaeology() {}

  /** Look of a find: b = bone/fossil, g = gem/crystal, t = tool/object, r = rare. */
  public record Find(int zone, int index, String name, char look, String story) {
    public boolean rare() {
      return index == 3;
    }

    public String id() {
      return zone + ":" + index;
    }

    public String model() {
      return switch (look) {
        case 'b' -> "find_bone";
        case 'g' -> "find_gem";
        case 'r' -> "find_rare";
        default -> "find_tool";
      };
    }
  }

  private static final String[][] NAMES = {
    {"Rostige Spitzhacke|t|Das Werkzeug eines Bergmanns, der vor hundert Jahren hier grub.", "Alte Grubenlampe|t|Das Glas ist noch heil.", "Versteinerter Farn|b|Älter als jeder Stollen.", "Zwergenhelm|r|Man sagt, die Eisenmine wurde von Zwergen angelegt."},
    {"Kristalldruse|g|Innen funkelt es in allen Farben.", "Leuchtender Käferpanzer|b|Leuchtet noch schwach im Dunkeln.", "Klingende Geode|g|Klingt wie eine kleine Glocke.", "Herz des Kristalls|r|Pulsiert, wenn man es in der Hand hält."},
    {"Versteinerter Riesenpilz|b|So groß wie ein Mensch.", "Sporenfossil|b|Die Sporen darin sind noch keimfähig.", "Myzelamulett|t|Aus Pilzfäden geflochten.", "Uralte Pilzkrone|r|Gehörte dem König der Pilztiefen."},
    {"Ammonit|b|Aus der Zeit, als hier ein Meer war.", "Wasserpumpe der Alten|t|Sie haben versucht, die Schächte trocken zu halten.", "Muschelkette|t|Hübsch – und sehr alt.", "Glocke der Tiefe|r|Läutet von selbst, wenn das Wasser steigt."},
    {"Obsidianklinge|t|Scharf genug, um Papier zu schneiden.", "Erstarrte Lavaträne|g|Tropfenform, schwarz glänzend.", "Glutkäfer in Bernstein|b|Eingeschlossen seit Jahrtausenden.", "Salamanderschuppe|r|Brennt nicht, egal wie heiß es wird."},
    {"Runentafel|t|Die Schrift ist noch nicht entziffert.", "Tonscherbe mit Inschrift|t|Ein Teil eines Kruges.", "Bronzemünze|t|Mit dem Kopf eines unbekannten Königs.", "Siegel des Königs|r|Das Siegel der vergessenen Herrscher."},
    {"Leerensplitter|g|Man sieht durch ihn hindurch – ins Nichts.", "Verzerrter Kompass|t|Zeigt überallhin, nur nicht nach Norden.", "Schwebender Stein|g|Fällt nicht herunter.", "Auge der Leere|r|Es schaut zurück."},
    {"Geschmolzene Zahnräder|t|Von einer Maschine, die niemand kennt.", "Hitzeschild-Platte|t|Hielt einmal unglaubliche Hitze ab.", "Kernschlacke|g|Noch immer warm.", "Ewige Glut|r|Erlischt nie."},
    {"Spiegelscherbe|g|Zeigt ein Spiegelbild, das sich zu spät bewegt.", "Doppelte Münze|t|Zwei gleiche Seiten – beide Kopf.", "Prismenlinse|g|Bricht das Licht in zwölf Farben.", "Spiegel ohne Bild|r|Zeigt alles – außer dir."},
    {"Säurezerfressener Helm|t|Der Besitzer hatte weniger Glück.", "Giftdrüse im Harz|b|Bitte nicht anfassen.", "Grüner Kristallzahn|g|Von einem Tier, das Gift trank.", "Phiole des Alchemisten|r|Der erste Trank der Welt?"},
    {"Fulgurit|g|Vom Blitz geformtes Glas.", "Sturmfeder|b|Von einem Vogel, groß wie ein Haus.", "Rostiger Blitzableiter|t|Hat viel mitgemacht.", "Donnerstein|r|Grollt leise vor jedem Gewitter."},
    {"Saurierzahn|b|So lang wie ein Unterarm.", "Rippenbogen|b|Hier lag ein Riese.", "Versteinertes Ei|b|Was wohl darin gewesen wäre?", "Schädel des Urdrachen|r|Der Grund, warum es Knochengrund heißt."},
    {"Ätherfeder|b|Fällt nach oben.", "Schwebende Laterne|t|Brennt ohne Öl.", "Kristallharfe|g|Spielt, wenn Wind durch die Hallen geht.", "Krone der Himmelswächter|r|Wiegt nichts."},
    {"Schattenmaske|t|Wer sie trägt, wirft keinen Schatten.", "Kerze ohne Licht|t|Brennt schwarz.", "Schwarzer Spiegel|g|Zeigt nur Dunkelheit.", "Umhang des Schattenfürsten|r|Kalt wie die Nacht."},
    {"Meteoritensplitter|g|Nicht von dieser Welt.", "Sternkarte|t|Zeigt Sterne, die es nicht mehr gibt.", "Sternenstaub-Phiole|g|Glitzert auch im Dunkeln.", "Stück eines Kometen|r|Hat einmal die Welt getroffen."},
    {"Faustkeil|t|Das älteste Werkzeug der Welt.", "Höhlenmalerei-Platte|t|Zeigt Bergleute – vor 50.000 Jahren.", "Knochenflöte|b|Spielt noch drei Töne.", "Totem der Ersten|r|Die Ersten, die hier gruben."},
    {"Kernkristall-Nadel|g|So spitz, dass sie Stein durchsticht.", "Uralter Kompass|t|Zeigt zum Weltenkern.", "Weltgesteinsprobe|g|Aus dem Herzen der Welt.", "Samen der Welt|r|Aus ihm ist alles gewachsen."}
  };

  public static final List<Find> ALL;

  static {
    List<Find> all = new ArrayList<>();
    for (int z = 0; z < NAMES.length; z++)
      for (int i = 0; i < 4; i++) {
        String[] part = NAMES[z][i].split("\\|");
        all.add(new Find(z, i, part[0], part[1].charAt(0), part[2]));
      }
    ALL = List.copyOf(all);
  }

  /** Chance per ore block for any find; of those, 12 % are the rare one. */
  public static final double CHANCE = .008, RARE_SHARE = .12;

  public static Find find(int zone, int index) {
    return ALL.get(zone * 4 + index);
  }

  public static Find byId(String id) {
    String[] p = id.split(":");
    return find(Integer.parseInt(p[0]), Integer.parseInt(p[1]));
  }

  /** Roll for one mined ore block; null when nothing turned up. */
  public static Find dig(Profile p, int zone, RandomGenerator r) {
    if (zone < 0 || zone >= Zone.COUNT || r.nextDouble() >= CHANCE) return null;
    Find f = r.nextDouble() < RARE_SHARE ? find(zone, 3) : find(zone, r.nextInt(3));
    if (p.finds == null) p.finds = new HashMap<>();
    p.finds.merge(f.id(), 1, Integer::sum);
    return f;
  }

  public static int owned(Profile p, Find f) {
    return p.finds == null ? 0 : p.finds.getOrDefault(f.id(), 0);
  }

  public static boolean donated(Profile p, Find f) {
    return p.museum != null && p.museum.contains(f.id());
  }

  public static long donationReward(Find f) {
    return Zone.at(f.zone()).orePrice * 40L * (f.rare() ? 5 : 1);
  }

  public static long saleValue(Find f) {
    return Zone.at(f.zone()).orePrice * 10L * (f.rare() ? 5 : 1);
  }

  public static boolean complete(Profile p, int zone) {
    for (int i = 0; i < 4; i++) if (!donated(p, find(zone, i))) return false;
    return true;
  }

  public static int completeZones(Profile p) {
    int n = 0;
    for (int z = 0; z < Zone.COUNT; z++) if (complete(p, z)) n++;
    return n;
  }

  public static int donatedCount(Profile p) {
    return p.museum == null ? 0 : p.museum.size();
  }

  /** Permanent museum bonus: +1 % per complete mine, +5 % more for the whole museum. */
  public static double bonus(Profile p) {
    if (p.museum == null || p.museum.isEmpty()) return 0;
    int done = completeZones(p);
    return .01 * done + (done == Zone.COUNT ? .05 : 0);
  }

  public static String donate(Profile p, Find f) {
    if (donated(p, f)) return f.name() + " steht schon im Museum. Doppelte kannst du verkaufen (Rechtsklick).";
    if (owned(p, f) <= 0) return "Du hast " + f.name() + " noch nicht gefunden.";
    p.finds.merge(f.id(), -1, Integer::sum);
    if (p.museum == null) p.museum = new HashSet<>();
    p.museum.add(f.id());
    long money = donationReward(f), dust = f.rare() ? 25 : 5;
    p.money += money;
    p.lifetimeRevenue += money;
    p.dust += dust;
    String done =
        complete(p, f.zone())
            ? " SAMMLUNG " + Zone.at(f.zone()).title.toUpperCase(Locale.ROOT) + " VOLLSTÄNDIG! Museumsbonus jetzt +" + Math.round(bonus(p) * 100) + " %."
            : "";
    return f.name() + " dem Museum gestiftet: +" + String.format(Locale.GERMAN, "%,d", money) + " $, +" + dust + " Staub." + done;
  }

  public static String sell(Profile p, Find f) {
    int spare = owned(p, f) - (donated(p, f) ? 0 : 1);
    if (spare <= 0)
      return donated(p, f) ? "Keine doppelten " + f.name() + "." : "Das erste Exemplar gehört ins Museum (Linksklick).";
    p.finds.merge(f.id(), -spare, Integer::sum);
    long money = saleValue(f) * spare;
    p.money += money;
    p.lifetimeRevenue += money;
    return spare + "× " + f.name() + " verkauft: +" + String.format(Locale.GERMAN, "%,d", money) + " $.";
  }
}
