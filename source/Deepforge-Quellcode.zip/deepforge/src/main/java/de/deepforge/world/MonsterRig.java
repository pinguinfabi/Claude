package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/** Seven independently animated model bones carried by a normal server-side hitbox. */
final class MonsterRig implements AutoCloseable {
  private final List<ItemDisplay> parts = new ArrayList<>();
  private final float scale;
  private final DeepforgePlugin plugin;
  private final int zone;
  private final float width, height, reach;
  private long hitUntil, animatedAt = Long.MIN_VALUE;
  private boolean red;
  // Personal monsters: bones are hidden by default and shown to their fighters only.
  private final boolean personal;

  void hurt(long tick) {
    hitUntil = tick + 6;
  }

  double labelHeight() {
    return scale * height * 3.1 + .45;
  }

  private static final String[] BONES = {"body", "head", "arm", "arm", "leg", "leg", "core"};
  private static final float[][] OFFSET = {
    {0, 1.3f, 0},
    {0, 2.25f, 0},
    {-.7f, 1.2f, 0},
    {.7f, 1.2f, 0},
    {-.34f, .5f, 0},
    {.34f, .5f, 0},
    {0, 1.35f, -.5f}
  };

  MonsterRig(DeepforgePlugin plugin, Location at, int zone, boolean boss, int kind) {
    this(plugin, at, zone, boss, kind, null);
  }

  /** With viewers set, the bones are only shown to those players (personal monsters). */
  MonsterRig(
      DeepforgePlugin plugin,
      Location at,
      int zone,
      boolean boss,
      int kind,
      Collection<UUID> viewers) {
    this.plugin = plugin;
    this.zone = zone;
    personal = viewers != null;
    float[][] shapes = {
      {1.3f, .92f, 1.05f},
      {.8f, 1.2f, 1.1f},
      {1.25f, .8f, .8f},
      {.9f, 1.03f, 1.4f},
      {1.4f, 1f, .9f},
      {1f, 1.16f, 1.1f},
      {.75f, 1.25f, 1.3f}
    };
    width = boss ? shapes[zone][0] : kind == 1 ? 1.15f : .92f;
    height = boss ? shapes[zone][1] : kind == 2 ? 1.1f : 1;
    reach = boss ? shapes[zone][2] : 1;
    scale = boss ? 1.15f : kind == 0 ? .52f : kind == 1 ? .72f : .62f;
    try {
      for (String bone : BONES)
        parts.add(
            at.getWorld()
                .spawn(
                    at,
                    ItemDisplay.class,
                    e -> {
                      e.setItemStack(
                          plugin.items().model(Material.PAPER, "mob_" + zone + "_" + bone, ""));
                      e.setPersistent(false);
                      e.setInvulnerable(true);
                      e.setSilent(true);
                      e.setViewRange(.8f);
                      e.setTeleportDuration(2);
                      e.setInterpolationDuration(2);
                      e.setBrightness(new Display.Brightness(12, 0));
                      if (viewers != null) e.setVisibleByDefault(false);
                    }));
      if (viewers != null)
        for (UUID id : viewers) {
          Player viewer = Bukkit.getPlayer(id);
          if (viewer != null) for (ItemDisplay part : parts) viewer.showEntity(plugin, part);
        }
    } catch (RuntimeException ex) {
      close();
      throw ex;
    }
  }

  boolean animatedAt(long tick) {
    return animatedAt == tick;
  }

  /**
   * Personal monsters: shows the bones to every current fighter. Players who join the fight later
   * or log in again would otherwise see neither the bones nor the (invisible) mob.
   */
  void showTo(Collection<UUID> viewers) {
    if (!personal) return;
    for (UUID id : viewers) {
      Player viewer = Bukkit.getPlayer(id);
      if (viewer == null) continue;
      for (ItemDisplay part : parts) if (!viewer.canSee(part)) viewer.showEntity(plugin, part);
    }
  }

  void animate(Location root, long tick, boolean windup, boolean broken, boolean moving) {
    animatedAt = tick;
    boolean flash = tick < hitUntil;
    if (flash != red) {
      red = flash;
      for (int i = 0; i < parts.size(); i++)
        parts
            .get(i)
            .setItemStack(
                plugin
                    .items()
                    .model(
                        Material.PAPER,
                        "mob_" + zone + "_" + BONES[i] + (flash ? "_hit" : ""),
                        ""));
    }
    // Mesh eyes face model north; Bukkit yaw zero points south.
    root = root.clone();
    root.setYaw(root.getYaw() + 180);
    root.setPitch(0);
    for (int i = 0; i < parts.size(); i++) {
      float[] p = OFFSET[i];
      float wave = moving ? (float) Math.sin(tick * .24) * .45f : 0;
      Quaternionf rotation = new Quaternionf();
      if (flash && (i == 0 || i == 1)) rotation.rotateZ(-.10f);
      if (i == 2 || i == 3)
        rotation.rotateX(broken ? 1.7f : windup ? 2.3f : wave * (i == 2 ? 1 : -1));
      if (i == 4 || i == 5) rotation.rotateX(wave * (i == 4 ? 1 : -1));
      if (i == 1) rotation.rotateZ(broken ? .28f : 0);
      float pulse = i == 6 ? 1 + (float) Math.sin(tick * .17) * .08f : 1;
      parts.get(i).teleport(root);
      parts.get(i).setInterpolationDelay(0);
      parts
          .get(i)
          .setTransformation(
              new Transformation(
                  new Vector3f(p[0] * scale * width, p[1] * scale * height, p[2] * scale),
                  rotation,
                  new Vector3f(
                      scale * pulse * width,
                      scale * pulse * height * (i == 2 || i == 3 ? reach : 1),
                      scale * pulse),
                  new Quaternionf()));
    }
  }

  @Override
  public void close() {
    parts.forEach(Entity::remove);
    parts.clear();
  }
}
