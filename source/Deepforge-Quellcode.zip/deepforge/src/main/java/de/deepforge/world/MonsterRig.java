package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/** Seven independently animated model bones carried by a normal server-side hitbox. */
final class MonsterRig implements AutoCloseable {
  private final List<ItemDisplay> parts = new ArrayList<>();

  /** Champions shine in their trait colour. */
  void glow(Color color) {
    for (ItemDisplay part : parts) {
      part.setGlowing(true);
      part.setGlowColorOverride(color);
    }
  }
  private final float scale;
  private final DeepforgePlugin plugin;
  private final int zone;
  private final float width, height, reach;
  private long hitUntil, animatedAt = Long.MIN_VALUE;
  private boolean red;
  // Personal monsters: bones are hidden by default and shown to their fighters only.
  private final boolean personal;

  void hurt(long tick) {
    hitUntil = tick + 6;
  }

  double labelHeight() {
    return scale * height * 3.1 + .45;
  }

  private static final String[] BONES = {"body", "head", "arm", "arm", "leg", "leg", "core"};
  private static final float[][] OFFSET = {
    {0, 1.3f, 0},
    {0, 2.25f, 0},
    {-.7f, 1.2f, 0},
    {.7f, 1.2f, 0},
    {-.34f, .5f, 0},
    {.34f, .5f, 0},
    {0, 1.35f, -.5f}
  };

  MonsterRig(DeepforgePlugin plugin, Location at, int zone, boolean boss, int kind) {
    this(plugin, at, zone, boss, kind, null);
  }

  /** With viewers set, the bones are only shown to those players (personal monsters). */
  MonsterRig(
      DeepforgePlugin plugin,
      Location at,
      int zone,
      boolean boss,
      int kind,
      Collection<UUID> viewers) {
    this.plugin = plugin;
    this.zone = zone;
    personal = viewers != null;
    float[][] shapes = {
      {1.3f, .92f, 1.05f},
      {.8f, 1.2f, 1.1f},
      {1.25f, .8f, .8f},
      {.9f, 1.03f, 1.4f},
      {1.4f, 1f, .9f},
      {1f, 1.16f, 1.1f},
      {.75f, 1.25f, 1.3f}
    };
    width = boss ? shapes[zone % 7][0] : kind == 1 ? 1.15f : .92f;
    height = boss ? shapes[zone % 7][1] : kind == 2 ? 1.1f : 1;
    reach = boss ? shapes[zone % 7][2] : 1;
    scale = boss ? 1.15f : kind == 0 ? .52f : kind == 1 ? .72f : .62f;
    try {
      for (String bone : BONES)
        parts.add(
            at.getWorld()
                .spawn(
                    at,
                    ItemDisplay.class,
                    e -> {
                      e.setItemStack(
                          plugin.items().model(Material.PAPER, "mob_" + zone + "_" + bone, ""));
                      e.setPersistent(false);
                      e.setInvulnerable(true);
                      e.setSilent(true);
                      e.setViewRange(.8f);
                      e.setTeleportDuration(2);
                      e.setInterpolationDuration(2);
                      e.setBrightness(new Display.Brightness(12, 0));
                      if (viewers != null) e.setVisibleByDefault(false);
                    }));
      if (viewers != null)
        for (UUID id : viewers) {
          Player viewer = Bukkit.getPlayer(id);
          if (viewer != null) for (ItemDisplay part : parts) viewer.showEntity(plugin, part);
        }
    } catch (RuntimeException ex) {
      close();
      throw ex;
    }
  }

  boolean animatedAt(long tick) {
    return animatedAt == tick;
  }

  /**
   * Personal monsters: shows the bones to every current fighter. Players who join the fight later
   * or log in again would otherwise see neither the bones nor the (invisible) mob.
   */
  void showTo(Collection<UUID> viewers) {
    if (!personal) return;
    for (UUID id : viewers) {
      Player viewer = Bukkit.getPlayer(id);
      if (viewer == null) continue;
      for (ItemDisplay part : parts) if (!viewer.canSee(part)) viewer.showEntity(plugin, part);
    }
  }

  /** A blow that lands now: arms slam forward (called when the monster deals damage). */
  void strike(long tick) {
    if (tick - strikeAt > STRIKE) strikeAt = tick;
  }

  private static final int STRIKE = 7;
  private long strikeAt = Long.MIN_VALUE / 2;
  private boolean wasWindup;

  /**
   * Skeleton with joints (0.17.0): head and arms hang on the body and follow its lean, arms swing
   * from the shoulder and legs from the hip. Before, every bone turned around its own centre, so a
   * flinch moved the body away under the head ("loose heads") and arms spun in place.
   */
  void animate(Location root, long tick, boolean windup, boolean broken, boolean moving) {
    animatedAt = tick;
    boolean flash = tick < hitUntil;
    if (flash != red) {
      red = flash;
      for (int i = 0; i < parts.size(); i++)
        parts
            .get(i)
            .setItemStack(
                plugin
                    .items()
                    .model(
                        Material.PAPER,
                        "mob_" + zone + "_" + BONES[i] + (flash ? "_hit" : ""),
                        ""));
    }
    // The wind-up ending (without being stunned) is the moment the blow lands.
    if (wasWindup && !windup && !broken) strike(tick);
    wasWindup = windup;
    Pose pose = pose(tick, windup, broken, moving, flash, tick - strikeAt);
    // Mesh eyes face model north; Bukkit yaw zero points south.
    root = root.clone();
    root.setYaw(root.getYaw() + 180);
    root.setPitch(0);
    Vector3f size = new Vector3f(scale * width, scale * height, scale);
    Matrix4f[] bones = skeleton(pose, size, scale, reach);
    for (int i = 0; i < parts.size(); i++) {
      ItemDisplay part = parts.get(i);
      part.teleport(root);
      part.setInterpolationDelay(0);
      part.setTransformationMatrix(bones[i]);
    }
  }

  /**
   * Joint angles in radians. Positive lean/pitch tips the body/head forward (model front is -z),
   * positive arm/leg angles swing the limb forward.
   */
  record Pose(
      float bodyLean, float bodyRoll, float headPitch, float headRoll, float armL, float armR,
      float legL, float legR, float bob, float pulse) {}

  static Pose pose(long tick, boolean windup, boolean broken, boolean moving, boolean flash, long sinceStrike) {
    float walk = moving ? (float) Math.sin(tick * .24) : 0;
    float breathe = (float) Math.sin(tick * .07);
    float lean = moving ? .06f : .015f * breathe, roll = 0, headPitch = -.02f * breathe, headRoll = 0;
    float armL = walk * .45f + .04f * breathe, armR = -walk * .45f + .04f * breathe;
    float legL = walk * .5f, legR = -walk * .5f;
    float bob = moving ? Math.abs(walk) * .05f : .012f * breathe;
    if (windup) {
      // Rearing back with both arms high above the head.
      lean = -.22f;
      headPitch = -.18f;
      armL = armR = 2.75f;
    }
    if (sinceStrike >= 0 && sinceStrike < STRIKE) {
      // Slam: arms come down fast, the body throws itself forward, then eases back.
      float t = sinceStrike / (float) STRIKE;
      float swing = t < .3f ? t / .3f : 1 - (t - .3f) / .7f;
      lean = .32f * swing;
      headPitch = .15f * swing;
      armL = armR = t < .3f ? 2.75f - 2.1f * (t / .3f) : .65f * (1 - (t - .3f) / .7f);
      bob = -.05f * swing;
    }
    if (broken) {
      // Stunned: slumped forward, head hanging to the side, arms limp.
      lean = .28f;
      headPitch = .3f;
      headRoll = .3f;
      armL = .25f;
      armR = .15f;
      legL = legR = 0;
    }
    if (flash) {
      // Flinch away from the hit.
      lean -= .14f;
      roll = .08f;
      headPitch -= .12f;
    }
    float pulse = 1 + (float) Math.sin(tick * .17) * .08f;
    return new Pose(lean, roll, headPitch, headRoll, armL, armR, legL, legR, bob, pulse);
  }

  /**
   * Bone matrices in display space. Pivots: hip at the bottom of the body, neck at the bottom of
   * the head, shoulders near the top of the arms (model y 13 of -7..14), hips at the top of the
   * legs. Item models are centred, so model y maps to (y - 8) / 16 of the bone's size.
   */
  static Matrix4f[] skeleton(Pose p, Vector3f size, float scale, float reach) {
    Vector3f[] at = new Vector3f[OFFSET.length];
    for (int i = 0; i < OFFSET.length; i++)
      // Legs stay on the ground; everything above the hip bobs.
      at[i] = new Vector3f(OFFSET[i][0] * size.x, OFFSET[i][1] * size.y + (i == 4 || i == 5 ? 0 : p.bob()), OFFSET[i][2] * scale);
    Vector3f hip = new Vector3f(at[0]).add(0, -.5f * size.y, 0);
    Matrix4f body = new Matrix4f().translate(hip).rotateX(-p.bodyLean()).rotateZ(p.bodyRoll()).translate(hip.negate(new Vector3f()));
    Matrix4f[] out = new Matrix4f[OFFSET.length];
    out[0] = new Matrix4f(body).translate(at[0]).scale(size);
    Vector3f neck = new Vector3f(at[1]).add(0, -.5f * size.y, 0);
    out[1] = joint(body, neck, new Matrix4f().rotateX(-p.headPitch()).rotateZ(p.headRoll()), at[1], size);
    Vector3f arm = new Vector3f(size.x, size.y * reach, size.z);
    for (int i = 2; i <= 3; i++) {
      Vector3f shoulder = new Vector3f(at[i]).add(0, 5 / 16f * arm.y, 0);
      out[i] = joint(body, shoulder, new Matrix4f().rotateX(i == 2 ? p.armL() : p.armR()), at[i], arm);
    }
    for (int i = 4; i <= 5; i++) {
      Vector3f joint = new Vector3f(at[i]).add(0, 6 / 16f * size.y, 0);
      out[i] = joint(new Matrix4f(), joint, new Matrix4f().rotateX(i == 4 ? p.legL() : p.legR()), at[i], size);
    }
    out[6] = new Matrix4f(body).translate(at[6]).scale(new Vector3f(size).mul(p.pulse()));
    return out;
  }

  private static Matrix4f joint(Matrix4f parent, Vector3f pivot, Matrix4f rotation, Vector3f centre, Vector3f size) {
    return new Matrix4f(parent)
        .translate(pivot)
        .mul(rotation)
        .translate(new Vector3f(centre).sub(pivot))
        .scale(size);
  }

  @Override
  public void close() {
    parts.forEach(Entity::remove);
    parts.clear();
  }
}
