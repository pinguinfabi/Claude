package de.deepforge.game;

/** Stored charges and cooldown are authoritative; inventory crystals are only visual proxies. */
public final class Healing {
  public static final int CAPACITY = 12;
  public static final long COOLDOWN_MS = 20_000;

  private Healing() {}

  public static int grant(Profile p, int amount) {
    if (amount < 0) throw new IllegalArgumentException();
    int added = Math.min(amount, CAPACITY - p.healingCharges);
    p.healingCharges += added;
    return added;
  }

  public static double amount(double maximum) {
    return 4 + maximum * .35;
  }

  public static double consume(Profile p, double health, double maximum, long now) {
    if (!Double.isFinite(health)
        || !Double.isFinite(maximum)
        || health <= 0
        || maximum <= 0
        || health >= maximum
        || now < 0) return 0;
    if (p.healingCharges <= 0 || now < p.healingReadyAt) return 0;
    double restored = Math.min(maximum - health, amount(maximum));
    p.healingCharges--;
    p.healingReadyAt = Math.addExact(now, COOLDOWN_MS);
    return restored;
  }
}
