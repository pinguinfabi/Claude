package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import java.util.*;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

/** In-world guide, collection goals, personal healing pickups and visible earned milestones. */
public final class AdventureSystem implements Listener, AutoCloseable {
  private final DeepforgePlugin plugin;
  private final ArtifactCombat procs = new ArtifactCombat();
  private final Map<UUID, BossBar> lessons = new HashMap<>();
  private final Map<UUID, String> decorated = new HashMap<>();
  private final Map<UUID, Long> guidance = new HashMap<>();
  private final List<Orb> orbs = new ArrayList<>();
  private final NamespacedKey role, owner, decor;
  private final BukkitTask task;

  private record Orb(UUID player, ItemDisplay entity, double health, long expires) {}

  private static final class Menu implements InventoryHolder {
    Inventory inventory;
    UUID owner;
    String page;
    Map<Integer, String> actions = new HashMap<>();

    public Inventory getInventory() {
      return inventory;
    }
  }

  public AdventureSystem(DeepforgePlugin plugin) {
    this.plugin = plugin;
    role = new NamespacedKey(plugin, "adventure_role");
    owner = new NamespacedKey(plugin, "adventure_owner");
    decor = new NamespacedKey(plugin, "decor");
    Bukkit.getPluginManager().registerEvents(this, plugin);
    task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20, 10);
  }

  public ArtifactCombat.Proc hit(Player p, UUID target) {
    Profile data = plugin.profile(p);
    Gear.Item weapon = Gear.equipped(data, Gear.Slot.WEAPON);
    return procs.hit(
        p.getUniqueId(),
        target,
        weapon == null ? -1 : weapon.archetype,
        Bukkit.getCurrentTick(),
        AdventureGear.setCount(data, 0));
  }

  public boolean fractured(UUID target) {
    return procs.fractured(target, Bukkit.getCurrentTick());
  }

  public double arcDamage(Player p) {
    Profile data = plugin.profile(p);
    return RapidCombat.damage(Gear.stats(data))
        * 1.5
        * (AdventureGear.setCount(data, 0) >= 4 ? 1.25 : 1);
  }

  public void arc(Player p, Location from, Location to) {
    var d = to.toVector().subtract(from.toVector());
    for (int n = 0; n <= 12; n++)
      from.getWorld()
          .spawnParticle(
              Particle.ELECTRIC_SPARK,
              from.clone().add(d.clone().multiply(n / 12.)),
              1,
              .04,
              .04,
              .04,
              0);
    p.playSound(from, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, .5f, 1.7f);
  }

  public void kill(Player p, Location at) {
    Profile data = plugin.profile(p);
    if (!AdventureGear.has(data, 1) && AdventureGear.setCount(data, 1) < 4) return;
    if (orbs.stream().filter(o -> o.player.equals(p.getUniqueId())).count() >= 6) return;
    ItemDisplay display =
        at.getWorld()
            .spawn(
                at.clone().add(0, .8, 0),
                ItemDisplay.class,
                e -> {
                  e.setItemStack(
                      plugin
                          .items()
                          .model(
                              Material.AMETHYST_SHARD, "healing_crystal", "Blutstahl-Heilkugel"));
                  e.setPersistent(false);
                });
    orbs.add(
        new Orb(
            p.getUniqueId(),
            display,
            AdventureGear.setCount(data, 1) >= 2 ? 6 : 4,
            System.currentTimeMillis() + 8000));
  }

  public static boolean merchantUnlocked(Profile p) {
    return p.bosses[0] || Arrays.stream(p.dungeonWins).sum() > 0;
  }

  public String verify(List<Profile> saved) {
    int guides = 0, merchants = 0, trophies = 0;
    for (Profile p : saved) {
      plugin.mines().decorate(p);
      var entities =
          plugin.mines().world().getEntities().stream()
              .filter(e -> plugin.mines().belongs(e, p))
              .toList();
      long guideCount =
          entities.stream()
              .filter(
                  e ->
                      "tutorial"
                          .equals(
                              e.getPersistentDataContainer().get(role, PersistentDataType.STRING)))
              .count();
      long merchantCount =
          entities.stream()
              .filter(
                  e ->
                      "merchant"
                          .equals(
                              e.getPersistentDataContainer().get(role, PersistentDataType.STRING)))
              .count();
      if (guideCount != 1 || merchantCount != (merchantUnlocked(p) ? 1 : 0))
        throw new IllegalStateException(
            "Adventure NPC mismatch for "
                + p.name
                + ": guides="
                + guideCount
                + " merchants="
                + merchantCount);
      guides += guideCount;
      merchants += merchantCount;
      for (boolean won : p.bosses) if (won) trophies++;
      long trophyCount =
          entities.stream()
              .filter(
                  e ->
                      e instanceof ItemDisplay d
                          && d.getItemStack().getItemMeta().getItemModel() != null
                          && d.getItemStack()
                              .getItemMeta()
                              .getItemModel()
                              .getKey()
                              .startsWith("unique_"))
              .count();
      int expected = 0;
      for (boolean won : p.bosses) if (won) expected++;
      if (trophyCount != expected) throw new IllegalStateException("Trophy mismatch");
      for (var station : CampBlueprint.STATIONS)
        if (plugin.mines().local(p, station.x(), 201, station.z()).getBlock().getType().isAir())
          throw new IllegalStateException("Station blocked");
    }
    for (int type = 0; type < 4; type++) {
      Gear.Item item = AdventureGear.artifact(type, type, new Random(3));
      ItemStack stack =
          plugin.items().button(Material.PAPER, item.model(), item.name, AdventureGear.lore(item));
      if (!new NamespacedKey("deepforge", item.model()).equals(stack.getItemMeta().getItemModel()))
        throw new IllegalStateException("Item model mismatch");
    }
    return "OK: "
        + guides
        + " guides, "
        + merchants
        + " merchants, "
        + trophies
        + " trophies, 4 artifact item models, village stations intact";
  }

  private void npc(Profile p, String job, double x, double z, String name) {
    plugin.mines().personal(p, plugin
        .mines()
        .world()
        .spawn(
            plugin.mines().local(p, x, 201, z),
            Villager.class,
            false,
            e -> {
              e.setAI(false);
              e.setInvulnerable(true);
              e.setCollidable(false);
              e.setSilent(true);
              e.setPersistent(false);
              e.setAdult();
              e.setProfession(
                  job.equals("tutorial")
                      ? Villager.Profession.TOOLSMITH
                      : Villager.Profession.CARTOGRAPHER);
              e.customName(Component.text(name, NamedTextColor.GOLD));
              e.setCustomNameVisible(true);
              e.getPersistentDataContainer().set(role, PersistentDataType.STRING, job);
              e.getPersistentDataContainer().set(owner, PersistentDataType.STRING, p.id);
              e.getPersistentDataContainer().set(decor, PersistentDataType.INTEGER, plugin.plot(p));
            }));
  }

  public void decorate(Profile p) {
    npc(p, "tutorial", 5.5, -5.5, "Vorarbeiter Jorin · Lernziele");
    if (merchantUnlocked(p))
      npc(p, "merchant", 6.5, -30.5, "Relikthändlerin Mira · freigeschaltet");
    // Trophy plinths exist for the first seven bosses; the deep shaft has its own boss labels.
    int[] xs = {-16, -12, -8, 8, 12, 16, 20};
    for (int zone = 0; zone < 7; zone++) {
      int x = xs[zone];
      for (int dx = -1; dx <= 1; dx++)
        for (int dz = -1; dz <= 1; dz++) {
          plugin
              .mines()
              .local(p, x + dx, 200, -40 + dz)
              .getBlock()
              .setType(Material.STONE_BRICKS, false);
          for (int y = 201; y <= 205; y++)
            plugin.mines().local(p, x + dx, y, -40 + dz).getBlock().setType(Material.AIR, false);
        }
      plugin
          .mines()
          .local(p, x, 201, -40)
          .getBlock()
          .setType(
              // Real blocks are seen by everyone in the shared camp; the trophy shows progress.
              p.bosses[zone] && !plugin.mines().shared()
                  ? Material.GILDED_BLACKSTONE
                  : Material.CHISELED_STONE_BRICKS,
              false);
      final int z = zone;
      if (p.bosses[zone])
        plugin.mines().personal(p, plugin
            .mines()
            .world()
            .spawn(
                plugin.mines().local(p, x + .5, 202.4, -39.5),
                ItemDisplay.class,
                e -> {
                  e.setItemStack(plugin.items().model(Material.PAPER, "unique_" + z, "Trophäe"));
                  e.setPersistent(false);
                  e.getPersistentDataContainer().set(decor, PersistentDataType.INTEGER, plugin.plot(p));
                }));
      label(p, x + .5, 204, -39.5, (p.bosses[zone] ? "✓ " : "? ") + BossRules.NAMES[zone]);
    }
    label(p, -22, 205, -7, "WERKSTATT · RANG " + (1 + p.tool / 5));
    for (int n = 0; n < Math.min(4, 1 + p.tool / 5); n++) {
      plugin.mines().personal(p, plugin
          .mines()
          .world()
          .spawn(
              plugin.mines().local(p, -26 + n, 202, -10),
              ItemDisplay.class,
              e -> {
                e.setItemStack(plugin.items().model(Material.PAPER, "drill", "Werkstattrang"));
                e.setPersistent(false);
                e.getPersistentDataContainer().set(decor, PersistentDataType.INTEGER, plugin.plot(p));
              }));
    }
  }

  private void label(Profile p, double x, double y, double z, String title) {
    plugin.mines().personal(p, plugin
        .mines()
        .world()
        .spawn(
            plugin.mines().local(p, x, y, z),
            TextDisplay.class,
            e -> {
              e.text(Component.text(title, NamedTextColor.GOLD));
              e.setBillboard(Display.Billboard.CENTER);
              e.setPersistent(false);
              e.getPersistentDataContainer().set(decor, PersistentDataType.INTEGER, plugin.plot(p));
            }));
  }

  @EventHandler
  public void talk(PlayerInteractEntityEvent e) {
    if (e.getHand() != EquipmentSlot.HAND) return;
    String page =
        e.getRightClicked().getPersistentDataContainer().get(role, PersistentDataType.STRING);
    if (page == null) return;
    e.setCancelled(true);
    if (e.getPlayer()
        .getUniqueId()
        .toString()
        .equals(
            e.getRightClicked().getPersistentDataContainer().get(owner, PersistentDataType.STRING)))
      open(e.getPlayer(), page);
  }

  /** Set-Schmiede page: one row per set, one button per piece. */
  private void setForge(Menu m, Profile data) {
    List<Gear.Item> spare = AdventureGear.spares(data);
    boolean ready = spare.size() >= 2;
    long money =
        ready ? AdventureGear.reforgeMoney(Math.max(spare.get(0).zone, spare.get(1).zone)) : 0;
    String cost =
        ready
            ? "Kosten: " + AdventureGear.REFORGE_DUST + " Staub · " + money + " $ · 2 doppelte Teile"
            : "Du brauchst 2 doppelte Set-Teile (du hast " + spare.size() + ")";
    button(
        m,
        4,
        "blade",
        "SET-SCHMIEDE",
        null,
        "Schmilzt 2 doppelte Set-Teile ein und schmiedet",
        "genau das Teil, das dir noch fehlt.",
        "Doppelt = gleiches Set und gleicher Platz; getragene",
        "und favorisierte Teile werden nie eingeschmolzen.",
        ready
            ? "Wird eingeschmolzen: " + spare.get(0).name + " + " + spare.get(1).name
            : "Doppelte Teile: " + spare.size() + " / 2",
        cost);
    for (int set = 0; set < AdventureGear.SETS.length; set++) {
      // Set in column 3, its four pieces in columns 4–7: one centred row per set.
      int row = 11 + set * 9;
      button(
          m,
          row,
          "gear_chest",
          AdventureGear.SETS[set] + " · getragen " + AdventureGear.setCount(data, set) + "/4",
          null,
          AdventureGear.SET_TWO[set],
          AdventureGear.SET_FOUR[set]);
      for (int k = 0; k < AdventureGear.SET_SLOTS.length; k++) {
        Gear.Slot slot = AdventureGear.SET_SLOTS[k];
        int have = AdventureGear.owned(data, set, slot);
        button(
            m,
            row + 1 + k,
            "gear_" + slot.name().toLowerCase(Locale.ROOT),
            (have > 0 ? "✓ " : "FEHLT · ") + AdventureGear.SETS[set] + " · " + Gear.slotName(slot),
            ready ? "forge:" + set + ":" + k : null,
            "Im Beutel: " + have + "×",
            cost,
            ready ? "Klick: schmieden" : "Doppelte Teile aus Dungeons und Minenbossen sammeln");
      }
    }
  }

  private void button(Menu m, int slot, String model, String name, String action, String... lore) {
    m.inventory.setItem(slot, plugin.items().button(Material.PAPER, model, name, lore));
    if (action != null) m.actions.put(slot, action);
  }

  public void open(Player p, String page) {
    if (!plugin.playing(p)) return;
    Profile data = plugin.profile(p);
    Menu m = new Menu();
    m.owner = p.getUniqueId();
    m.page = page;
    m.inventory =
        Bukkit.createInventory(
            m,
            54,
            plugin
                .menus()
                .styledTitle(
                    p,
                    page.equals("tutorial")
                        ? "VORARBEITER"
                        : page.equals("merchant")
                            ? "RELIKTHANDEL"
                            : page.equals("setforge") ? "SET-SCHMIEDE" : "ABENTEUERBUCH"));
    button(m, 45, "back", "Zurück: Aufträge & Abenteuer", "goals");
    button(m, 47, "handbook", "Hauptmenü", "home");
    button(m, 49, "close", "Schließen", "close");
    if (page.equals("setforge")) {
      setForge(m, data);
      m.actions.put(45, "journal");
      plugin.items().forViewer(m.inventory, p);
      p.openInventory(m.inventory);
      return;
    }
    if (page.equals("tutorial")) {
      button(
          m,
          4,
          "worker",
          "Vorarbeiter Jorin",
          null,
          "Ein Ziel zur Zeit. Schritte und Prämien bleiben gespeichert.");
      button(
          m,
          13,
          "handbook",
          Tutorial.title(data),
          null,
          Tutorial.help(data),
          "Schritt " + Math.min(12, data.tutorialStep + 1) + " / 12");
      button(
          m,
          28,
          "back",
          "30 Sekunden Wegweiser",
          "guide",
          "Partikel zeigen die Richtung zur passenden Station.");
      button(
          m,
          30,
          "clock",
          data.tutorialPaused ? "Tutorial fortsetzen" : "Tutorial pausieren",
          "pause");
      button(
          m,
          32,
          "close",
          "Diesen Schritt überspringen",
          "skip",
          "Keine Prämie; übersprungene Schritte können nicht erneut belohnt werden.");
      button(m, 34, "relic", "Zu den Sammelzielen", "journal");
      for (int n = 0; n < 7; n++) {
        int i = Math.min(Math.max(0, Tutorial.TITLES.length - 7), Math.max(0, data.tutorialStep - 2)) + n;
        if (i < Tutorial.TITLES.length)
          button(
              m,
              19 + n,
              "handbook",
              (i < data.tutorialStep ? "✓ " : "") + Tutorial.TITLES[i],
              null,
              Tutorial.HELP[i]);
      }
    } else if (page.equals("merchant")) {
      if (!merchantUnlocked(data))
        button(
            m,
            22,
            "close",
            "Händlerin noch gesperrt",
            null,
            "Besiege den ersten Minenboss oder einen Dungeon.");
      else {
        int unit = Healing.price(data), missing = Math.max(0, Healing.capacity(data) - data.healingCharges);
        button(
            m,
            19,
            "healing_crystal",
            "1 Lebenssplitter · " + unit + " $",
            "buyheal:1",
            "Vorrat: " + data.healingCharges + "/" + Healing.capacity(data));
        button(
            m,
            20,
            "healing_crystal",
            "5 Lebenssplitter · " + 5 * unit + " $",
            "buyheal:5",
            "Kauft weniger, wenn Platz oder Geld fehlt.");
        button(
            m,
            21,
            "healing_crystal",
            missing > 0 ? "Auffüllen · " + missing * unit + " $" : "Heilvorrat voll",
            "buyheal:12",
            "Füllt den Vorrat auf, so weit das Geld reicht.",
            "Überall: /df heal kaufen [Anzahl|voll]");
        button(m, 24, "relic", "5 Schmiedestaub · 750 $", "buydust");
        button(
            m,
            31,
            "worker",
            "Gerettete Bergarbeiter: " + data.adventureRescues,
            null,
            data.adventureRescues > 0
                ? "Rettungsrabatt: 20% auf beide Angebote"
                : "Rette einen Bergarbeiter im Dungeon für 20% Rabatt.");
      }
    } else {
      button(
          m,
          4,
          "relic",
          "Artefakte: " + data.artifactCollection.size() + " / 4",
          null,
          "Fundorte und Rezepte: Gegenstand ansehen / anklicken.",
          "Optionalziele: "
              + data.adventureChallenges
              + " Prüfungen · "
              + data.adventureRescues
              + " Rettungen · "
              + data.adventureTreasures
              + " Schätze");
      for (int i = 0; i < 4; i++) {
        boolean found = data.artifactCollection.contains(i);
        button(
            m,
            19 + i * 2,
            new String[] {"unique_1", "unique_6", "unique_0", "drill"}[i],
            (found ? "✓ " : "FEHLT · ") + AdventureGear.NAMES[i],
            "craft:" + i,
            AdventureGear.EFFECTS[i],
            "Fundort: " + Zone.at(i).title + (i < 3 ? " / " + Zone.at(i + 4).title : ""),
            "Minenboss: 2% · Dungeon-Sieg: 4% · Bonusbeute: 20% Artefakt",
            "Rezept nach Gebietssieg: 40 Bossfragmente, 30 Teile, " + (2000 * (i + 1)) + " $",
            "Besitz: "
                + data.bossTokens[i]
                + "/40 Fragmente · "
                + data.monsterParts[i]
                + "/30 Teile",
            "Klick: gezielt herstellen");
      }
      for (int set = 0; set < 3; set++) {
        int count = AdventureGear.setCount(data, set);
        final int type = set;
        long known =
            data.discovered.stream().filter(s -> s.startsWith("set/" + type + "/")).count();
        String two = AdventureGear.SET_TWO[set];
        String four = AdventureGear.SET_FOUR[set];
        button(
            m,
            38 + set * 2,
            "gear_chest",
            AdventureGear.SETS[set] + " · entdeckt " + known + "/4",
            null,
            "Ausgerüstet: " + count + "/4",
            two,
            four,
            "Fundort: alle Dungeon-Abschlüsse / Bonuskammern, Minenbosse");
      }
      button(m, 29, "worker", "Relikthändlerin", "merchant");
      button(
          m,
          31,
          "blade",
          "Set-Schmiede",
          "setforge",
          "2 doppelte Set-Teile → 1 Teil deiner Wahl",
          "Doppelte Teile gerade: " + AdventureGear.spares(data).size());
      button(m, 33, "handbook", "Tutorial", "tutorial");
    }
    plugin.items().forViewer(m.inventory, p);
    p.openInventory(m.inventory);
  }

  @EventHandler
  public void click(InventoryClickEvent e) {
    if (!(e.getView().getTopInventory().getHolder() instanceof Menu m)) return;
    e.setCancelled(true);
    if (!(e.getWhoClicked() instanceof Player p) || !m.owner.equals(p.getUniqueId())) return;
    String a = m.actions.get(e.getRawSlot());
    if (a == null) return;
    if (a.equals("close")) {
      p.closeInventory();
      return;
    }
    if (a.equals("home") || a.equals("goals")) {
      plugin.menus().open(p, a.equals("goals") ? "goals" : "main");
      return;
    }
    if (Set.of("tutorial", "journal", "merchant", "setforge").contains(a)) {
      open(p, a);
      return;
    }
    if (a.equals("guide")) {
      guidance.put(p.getUniqueId(), System.currentTimeMillis() + 30000);
      p.closeInventory();
      plugin.tell(p, Tutorial.help(plugin.profile(p)));
      return;
    }
    if (a.startsWith("buyheal:")) {
      // A double click also sends a normal click first; never buy twice by accident.
      if (e.getClick() == org.bukkit.event.inventory.ClickType.DOUBLE_CLICK) return;
      plugin.healing().buy(p, Integer.parseInt(a.substring(8)));
      if (plugin.isEnabled()) open(p, m.page);
      return;
    }
    if (plugin.combat().fighting(p)) {
      plugin.tell(p, "Herstellen und Handel sind nach dem Kampf verfügbar.");
      return;
    }
    plugin.change(
        p,
        data -> {
          if (a.equals("pause")) {
            data.tutorialPaused = !data.tutorialPaused;
            return data.tutorialPaused ? "Tutorial pausiert." : "Tutorial fortgesetzt.";
          }
          if (a.equals("skip")) return Tutorial.skip(data);
          if (a.startsWith("craft:"))
            return AdventureGear.craft(data, Integer.parseInt(a.substring(6)));
          if (a.startsWith("forge:")) {
            String[] part = a.split(":");
            return AdventureGear.reforge(
                data,
                Integer.parseInt(part[1]),
                AdventureGear.SET_SLOTS[Integer.parseInt(part[2])],
                java.util.concurrent.ThreadLocalRandom.current());
          }
          if (!merchantUnlocked(data)) return "Händlerin noch gesperrt.";
          if (!a.equals("buydust")) return "Unbekanntes Angebot.";
          int cost = 750 * (data.adventureRescues > 0 ? 80 : 100) / 100;
          if (data.money < cost) return "Nicht genug Geld.";
          data.money -= cost;
          data.dust += 5;
          return "Gekauft für " + cost + " $.";
        });
    if (!plugin.isEnabled()) return;
    plugin.items().refresh(p, plugin.profile(p));
    open(p, m.page);
  }

  @EventHandler
  public void drag(InventoryDragEvent e) {
    if (e.getView().getTopInventory().getHolder() instanceof Menu) e.setCancelled(true);
  }

  private void tick() {
    for (UUID id : new ArrayList<>(lessons.keySet())) {
      Player player = Bukkit.getPlayer(id);
      if (player == null || !plugin.playing(player) || player.getWorld() != plugin.mines().world())
        clear(id);
    }
    for (Player p : plugin.mines().world().getPlayers())
      if (plugin.playing(p)) {
        Profile data = plugin.profile(p);
        UUID id = p.getUniqueId();
        String state =
            Arrays.toString(data.bosses) + ":" + (data.tool / 5) + ":" + merchantUnlocked(data);
        boolean guideMissing =
            Bukkit.getCurrentTick() % 100 < 10
                && p.getY() > 180
                && plugin
                    .mines()
                    .world()
                    .getNearbyEntities(plugin.mines().local(data, 5.5, 201, -5.5), 2, 3, 2)
                    .stream()
                    .noneMatch(
                        e ->
                            "tutorial"
                                    .equals(
                                        e.getPersistentDataContainer()
                                            .get(role, PersistentDataType.STRING))
                                && data.id.equals(
                                    e.getPersistentDataContainer()
                                        .get(owner, PersistentDataType.STRING)));
        if (plugin.mines().isReady(data)
            && (!state.equals(decorated.put(id, state)) || guideMissing))
          plugin.mines().decorate(data);
        if (!data.tutorialPaused && data.tutorialStep < Tutorial.TITLES.length) {
          BossBar bar =
              lessons.computeIfAbsent(
                  id,
                  k -> {
                    BossBar b =
                        BossBar.bossBar(
                            Component.text("Vorarbeiter"),
                            0,
                            BossBar.Color.YELLOW,
                            BossBar.Overlay.PROGRESS);
                    p.showBossBar(b);
                    return b;
                  });
          bar.name(
              Component.text(
                  "Lernziel "
                      + (data.tutorialStep + 1)
                      + "/12 · "
                      + Tutorial.title(data)
                      + " · /df tutorial"));
          bar.progress(data.tutorialStep / 12f);
        } else {
          BossBar old = lessons.remove(id);
          if (old != null) p.hideBossBar(old);
        }
        if (guidance.getOrDefault(id, 0L) > System.currentTimeMillis()) guide(p, data);
      }
    Iterator<Orb> it = orbs.iterator();
    while (it.hasNext()) {
      Orb o = it.next();
      Player p = Bukkit.getPlayer(o.player);
      if (p == null
          || !plugin.playing(p)
          || o.expires < System.currentTimeMillis()
          || !o.entity.isValid()) {
        o.entity.remove();
        it.remove();
        continue;
      }
      if (!p.isDead()
          && !plugin.dungeons().down(p)
          && p.getWorld() == o.entity.getWorld()
          && p.getLocation().distanceSquared(o.entity.getLocation()) < 2.6
          && p.getHealth() < Gear.stats(plugin.profile(p)).health()) {
        p.setHealth(Math.min(Gear.stats(plugin.profile(p)).health(), p.getHealth() + o.health));
        p.spawnParticle(Particle.HEART, p.getLocation().add(0, 1, 0), 4, .3, .3, .3, 0);
        o.entity.remove();
        it.remove();
      }
    }
  }

  private void guide(Player p, Profile data) {
    int step = data.tutorialStep, zone = plugin.mines().zoneAt(data, p.getLocation());
    double x = 0, z = 36, y = 201;
    if (zone >= 0) {
      x = MineBlueprint.LIFT_X;
      z = MineBlueprint.LIFT_Z;
      y = plugin.mines().floor(zone) + 1;
      if (step == 8) {
        x = MineBlueprint.ALTAR_X;
        z = MineBlueprint.ALTAR_Z;
      }
      if (step == 0) {
        final int floor = plugin.mines().floor(zone);
        MineBlueprint.Point ore =
            plugin.mines().blueprint(zone).ores().stream()
                .filter(
                    o ->
                        plugin.mines().mine(data, zone, o.x(), o.h(), o.z()).getBlock().getType()
                            == Material.NOTE_BLOCK)
                .min(
                    Comparator.comparingDouble(
                        o ->
                            plugin
                                .mines()
                                .local(data, o.x() + MineWorld.shift(zone), floor + o.h(), o.z())
                                .distanceSquared(p.getLocation())))
                .orElse(null);
        if (ore != null) {
          x = ore.x();
          z = ore.z();
          y = floor + ore.h();
        }
      }
    } else if (step == 1) {
      x = 22;
      z = -8;
    } else if (step == 2 || step == 3) {
      x = -23;
      z = 8;
    } else if (step == 4) {
      z = -25;
    } else if (step == 5) {
      x = -22;
      z = -8;
    } else if (step == 9) {
      x = 23;
      z = 9;
    } else if (step >= 10) {
      z = -52;
    }
    if (zone >= 0) x += MineWorld.shift(zone);
    Location target = plugin.mines().local(data, x, y + 1, z);
    var direction = target.toVector().subtract(p.getLocation().toVector());
    double distance = direction.length();
    if (distance < .1) return;
    direction.normalize();
    for (double d = 1; d <= Math.min(9, distance); d += .7)
      p.spawnParticle(
          Particle.HAPPY_VILLAGER,
          p.getLocation().add(direction.clone().multiply(d)).add(0, .4, 0),
          1,
          0,
          0,
          0,
          0);
  }

  public void clear(UUID id) {
    BossBar bar = lessons.remove(id);
    Player p = Bukkit.getPlayer(id);
    if (p != null && bar != null) p.hideBossBar(bar);
    decorated.remove(id);
    guidance.remove(id);
    procs.clear(id);
  }

  public void close() {
    task.cancel();
    for (UUID id : new ArrayList<>(lessons.keySet())) clear(id);
    orbs.forEach(o -> o.entity.remove());
    orbs.clear();
  }
}
