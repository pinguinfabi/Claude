package de.deepforge.game;

import java.util.*;

/** Main-thread party membership; invitations never move a player without acceptance. */
public final class PartyBook {
  public static final int LIMIT = 4;

  public static final class Party {
    public UUID leader;
    public final LinkedHashSet<UUID> members = new LinkedHashSet<>();
    public final Set<UUID> ready = new HashSet<>();
    // Shared camp and mines; fixed once so a leader change does not move everyone.
    public int plot = -1;

    private Party(UUID id) {
      leader = id;
      members.add(id);
    }
  }

  private record Invite(UUID leader, long expires) {}

  private final Map<UUID, Party> parties = new HashMap<>();
  private final Map<UUID, Invite> invitations = new HashMap<>();

  public Party get(UUID id) {
    return parties.get(id);
  }

  public Party create(UUID id) {
    if (parties.containsKey(id))
      throw new IllegalArgumentException("Du bist bereits in einer Party.");
    Party p = new Party(id);
    parties.put(id, p);
    return p;
  }

  public void invite(UUID leader, UUID guest, long now) {
    Party p = get(leader);
    if (p == null || !p.leader.equals(leader))
      throw new IllegalArgumentException("Nur der Partyleiter kann einladen.");
    if (p.members.size() >= LIMIT || parties.containsKey(guest))
      throw new IllegalArgumentException("Party voll oder Spieler bereits in einer Party.");
    invitations.put(guest, new Invite(leader, now + 60_000));
  }

  public Party accept(UUID guest, long now) {
    Invite i = invitations.remove(guest);
    Party p = i == null ? null : get(i.leader);
    if (i == null
        || i.expires <= now
        || p == null
        || !p.leader.equals(i.leader)
        || p.members.size() >= LIMIT
        || parties.containsKey(guest))
      throw new IllegalArgumentException("Einladung abgelaufen oder Party nicht mehr verfügbar.");
    p.members.add(guest);
    p.ready.clear();
    parties.put(guest, p);
    return p;
  }

  public boolean ready(UUID id) {
    Party p = get(id);
    if (p == null) throw new IllegalArgumentException("Zuerst /df party create.");
    if (p.ready.remove(id)) return false;
    p.ready.add(id);
    return true;
  }

  public void leave(UUID id) {
    invitations.remove(id);
    Party p = parties.remove(id);
    if (p == null) return;
    p.members.remove(id);
    p.ready.clear();
    if (!p.members.isEmpty() && p.leader.equals(id)) p.leader = p.members.iterator().next();
  }

  public List<UUID> roster(UUID leader) {
    Party p = get(leader);
    if (p == null || !p.leader.equals(leader))
      throw new IllegalArgumentException("Nur der Partyleiter kann starten.");
    if (!p.ready.containsAll(p.members))
      throw new IllegalArgumentException("Alle müssen zuerst /df party ready bestätigen.");
    return List.copyOf(p.members);
  }
}
