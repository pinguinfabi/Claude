package de.deepforge.game;

/**
 * 0.23.0 build mode: a block position inside a dungeon room, stored so it fits rooms of other
 * sizes. Near a wall (within 3 blocks) it is anchored to that wall, otherwise to the room centre;
 * near the ceiling it hangs from the ceiling. A banner on the east wall of a 9-wide room thus ends
 * up on the east wall of a 13-wide room too, a pillar 2 blocks from the centre stays there.
 *
 * <p>Key format: "x3|y0|z-2", "E1|y2|z0" (1 block inside the east wall), "x0|T1|W2" …
 */
public final class RoomAnchor {
  private RoomAnchor() {}

  /** How close to a wall or the ceiling a block must be to be anchored to it. */
  public static final int EDGE = 3;

  /**
   * @param dx, dz offset from the room centre; dy from the floor (0 = where players stand)
   * @param hw, hd half width / depth of the room; height its height
   */
  public static String encode(int dx, int dy, int dz, int hw, int hd, int height) {
    return axis(dx, hw, 'E', 'W', 'x') + "|" + (dy >= height - EDGE ? "T" + (height - dy) : "y" + dy) + "|" + axis(dz, hd, 'S', 'N', 'z');
  }

  private static String axis(int d, int half, char plus, char minus, char centre) {
    if (d >= half - EDGE) return plus + Integer.toString(half - d);
    if (d <= -half + EDGE) return minus + Integer.toString(d + half);
    return centre + Integer.toString(d);
  }

  /** The offset in a room of this size, or null when it does not fit (e.g. a smaller room). */
  public static int[] decode(String key, int hw, int hd, int height) {
    String[] part = key.split("\\|");
    if (part.length != 3) return null;
    try {
      Integer dx = axis(part[0], hw, 'E', 'W', 'x'), dz = axis(part[2], hd, 'S', 'N', 'z');
      if (dx == null || dz == null) return null;
      int dy =
          part[1].charAt(0) == 'T'
              ? height - Integer.parseInt(part[1].substring(1))
              : Integer.parseInt(part[1].substring(1));
      if (dy < -2 || dy > height + 1) return null;
      return new int[] {dx, dy, dz};
    } catch (NumberFormatException | StringIndexOutOfBoundsException ex) {
      return null;
    }
  }

  private static Integer axis(String s, int half, char plus, char minus, char centre) {
    int v = Integer.parseInt(s.substring(1));
    char c = s.charAt(0);
    int d = c == plus ? half - v : c == minus ? v - half : c == centre ? v : Integer.MIN_VALUE;
    if (d == Integer.MIN_VALUE) return null;
    // Centre-anchored blocks must stay inside the walls of a smaller room.
    if (c == centre && Math.abs(d) >= half) return null;
    if (Math.abs(d) > half + 1) return null;
    return d;
  }
}
