package de.deepforge.game;

/** Deterministic 60-second production steps, identical online and offline. */
public final class Production {
  public record Report(
      long minutes,
      long mined,
      long smelted,
      long revenue,
      long costs,
      String stopped,
      long dust,
      long relics,
      long notes,
      long chopped) {
    public Report(long minutes, long mined, long smelted, long revenue, long costs, String stopped) {
      this(minutes, mined, smelted, revenue, costs, stopped, 0, 0, 0, 0);
    }

    public long profit() {
      return revenue - costs;
    }
  }

  public static Report settle(Profile p, long now) {
    if (p.lastSettled == 0) {
      p.lastSettled = now;
      return new Report(0, 0, 0, 0, 0, "");
    }
    if (now <= p.lastSettled) return new Report(0, 0, 0, 0, 0, "");
    long elapsed = now - p.lastSettled;
    long cap = p.offlineHours() * 3_600_000L;
    long minutes = Math.min(elapsed, cap) / 60_000;
    long mined = 0, smelted = 0, revenue = 0, costs = 0, dust = 0, relics = 0, notes = 0;
    long chopped = 0, breaks = 0;
    String stopped = "";
    // Jobs run in pipeline order, independent of hiring order.
    for (long m = 0; m < minutes; m++)
      for (Profile.Job job : Profile.Job.values())
        for (Profile.Worker w : p.workers) {
          if (w.job != job || w.paused) continue;
          int z = Math.clamp(w.zone, 0, p.zone);
          // Breaks: 10 minutes rest after every 50 minutes on shift (online and offline alike).
          if (w.rest > 0) {
            w.rest--;
            continue;
          }
          if (++w.shift > Industry.SHIFT_MINUTES) {
            w.shift = 0;
            w.rest = Industry.BREAK_MINUTES - 1;
            breaks++;
            continue;
          }
          if (Industry.usesFuel(job) && p.fuel < 1) {
            stopped = "Brennstoff leer";
            continue;
          }
          w.carry += Industry.rate(p, w);
          long amount = (long) w.carry;
          // Still working on the first piece: no goods yet, so no wage either.
          if (amount <= 0) continue;
          boolean worked = false;
          long wage = 0;
          switch (job) {
            case MINER -> {
              amount = Math.min(amount, p.stockCapacity() - p.stockUsed());
              if (amount <= 0) {
                stopped = "Lager voll";
                break;
              }
              wage = Industry.wage(w, amount * Zone.at(z).orePrice);
              if (p.budget < wage) {
                stopped = "Betriebsbudget leer";
                break;
              }
              p.stock[z] += amount;
              mined += amount;
              worked = true;
            }
            case SMELTER -> {
              if (p.furnace == 0) {
                stopped = "Schmelze nicht gebaut";
                break;
              }
              amount = Math.min(amount, Math.min(p.stock[z] / 2, p.furnace * 2L));
              if (amount == 0) {
                stopped = "Schmelze wartet auf Erz";
                break;
              }
              wage = Industry.wage(w, amount * (Zone.at(z).barPrice - 2L * Zone.at(z).orePrice));
              if (p.budget < wage) {
                stopped = "Betriebsbudget leer";
                break;
              }
              p.stock[z] -= amount * 2;
              p.bars[z] += amount;
              smelted += amount;
              worked = true;
            }
            case LUMBERJACK -> {
              int species = Industry.woodType(p, w);
              amount = Math.min(amount, Forestry.capacity(p) - Forestry.used(p));
              if (amount <= 0) {
                stopped = "Holzlager voll";
                break;
              }
              wage = Industry.wage(w, amount * Forestry.PRICES[species]);
              if (p.budget < wage) {
                stopped = "Betriebsbudget leer";
                break;
              }
              p.wood[species] += amount;
              p.woodChopped += amount;
              chopped += amount;
              worked = true;
            }
            case TRADER -> {
              long barAmount = Math.min(amount, Industry.sellableBars(p, z));
              long oreAmount = Math.min(amount - barAmount, p.stock[z]);
              long earned = barAmount * Zone.at(z).barPrice + oreAmount * Zone.at(z).orePrice;
              earned = Math.round(earned * (1 + p.research[3] * .05));
              if (earned == 0) {
                stopped = "Händler wartet auf Ware";
                break;
              }
              wage = Industry.wage(w, earned);
              if (p.budget < wage) {
                stopped = "Betriebsbudget leer";
                break;
              }
              p.bars[z] -= barAmount;
              p.stock[z] -= oreAmount;
              p.money += earned;
              p.lifetimeRevenue += earned;
              revenue += earned;
              worked = true;
            }
          }
          // Goods that could not be delivered are lost; only the fraction carries over.
          w.carry = worked ? w.carry - amount : w.carry - Math.floor(w.carry);
          if (!worked) continue;
          {
            p.budget -= wage;
            costs += wage;
            if (Industry.usesFuel(job)) p.fuel--;
            w.workMinutes++;
            String find = Industry.workerFind(p, w);
            if (find.equals("dust")) dust++;
            else if (find.equals("relic")) relics++;
            else if (find.equals("note")) notes++;
            else if (find.startsWith("bonus:")) revenue += Long.parseLong(find.substring(6));
          }
        }
    // Keep sub-minute remainder; discard time beyond the explicit offline cap.
    p.lastSettled = elapsed > cap ? now : p.lastSettled + minutes * 60_000;
    return new Report(
        minutes, mined, smelted, revenue, costs, stopped, dust, relics, notes, chopped);
  }

  private Production() {}
}
