package de.deepforge.game;

import java.util.List;

/** Deterministic 60-second production steps, identical online and offline. */
public final class Production {
  public record Report(
      long minutes,
      long mined,
      long smelted,
      long revenue,
      long costs,
      String stopped,
      long dust,
      long relics,
      long notes,
      long chopped) {
    public Report(long minutes, long mined, long smelted, long revenue, long costs, String stopped) {
      this(minutes, mined, smelted, revenue, costs, stopped, 0, 0, 0, 0);
    }

    public long profit() {
      return revenue - costs;
    }
  }

  public static Report settle(Profile p, long now) {
    if (p.lastSettled == 0) {
      p.lastSettled = now;
      return new Report(0, 0, 0, 0, 0, "");
    }
    if (now <= p.lastSettled) return new Report(0, 0, 0, 0, 0, "");
    long elapsed = now - p.lastSettled;
    long cap = p.offlineHours() * 3_600_000L;
    long minutes = Math.min(elapsed, cap) / 60_000;
    long mined = 0, smelted = 0, revenue = 0, costs = 0, dust = 0, relics = 0, notes = 0;
    long chopped = 0, breaks = 0;
    String stopped = "";
    // Jobs run in pipeline order, independent of hiring order.
    for (long m = 0; m < minutes; m++)
      for (Profile.Job job : Profile.Job.values())
        for (Profile.Worker w : p.workers) {
          if (w.job != job || w.paused) continue;
          int z = Math.clamp(w.zone, 0, p.zone);
          // Breaks: 10 minutes rest after every 50 minutes on shift (online and offline alike).
          if (w.rest > 0) {
            w.rest--;
            continue;
          }
          if (++w.shift > Industry.SHIFT_MINUTES) {
            w.shift = 0;
            w.rest = Industry.BREAK_MINUTES - 1;
            breaks++;
            continue;
          }
          if (Industry.usesFuel(job) && p.fuel < 1 && !buyFuel(p)) {
            stopped = "Brennstoff leer";
            w.blocked = "Brennstoff fehlt";
            continue;
          }
          w.carry += Industry.rate(p, w);
          long amount = (long) w.carry;
          // Still working on the first piece: no goods yet, so no wage either.
          if (amount <= 0) continue;
          boolean worked = false;
          long wage = 0;
          switch (job) {
            case MINER -> {
              amount = Math.min(amount, p.stockCapacity() - p.stockUsed());
              if (amount <= 0) {
                stopped = "Lager voll"; w.blocked = "Lager voll";
                break;
              }
              wage = Industry.wage(w, amount * Zone.at(z).orePrice);
              if (!pay(p, wage)) {
                stopped = "Betriebsbudget leer"; w.blocked = "Betriebsbudget fehlt";
                break;
              }
              p.stock[z] += amount;
              mined += amount;
              worked = true;
            }
            case SMELTER -> {
              if (p.furnace == 0) {
                stopped = "Schmelze nicht gebaut"; w.blocked = "Schmelze nicht gebaut";
                break;
              }
              amount = Math.min(amount, Math.min(p.stock[z] / 2, p.furnace * 2L));
              if (amount == 0) {
                stopped = "Schmelze wartet auf Erz"; w.blocked = "Wartet auf Schmelze/Erz";
                break;
              }
              wage = Industry.wage(w, amount * (Zone.at(z).barPrice - 2L * Zone.at(z).orePrice));
              if (!pay(p, wage)) {
                stopped = "Betriebsbudget leer"; w.blocked = "Betriebsbudget fehlt";
                break;
              }
              p.stock[z] -= amount * 2;
              p.bars[z] += amount;
              smelted += amount;
              worked = true;
            }
            case LUMBERJACK -> {
              int species = Industry.woodType(p, w);
              amount = Math.min(amount, Forestry.capacity(p) - Forestry.used(p));
              if (amount <= 0) {
                stopped = "Holzlager voll"; w.blocked = "Holzlager voll";
                break;
              }
              wage = Industry.wage(w, amount * Forestry.PRICES[species]);
              if (!pay(p, wage)) {
                stopped = "Betriebsbudget leer"; w.blocked = "Betriebsbudget fehlt";
                break;
              }
              p.wood[species] += amount;
              p.woodChopped += amount;
              chopped += amount;
              worked = true;
            }
            case TRADER -> {
              long barAmount = Math.min(amount, Industry.sellableBars(p, z));
              long oreAmount = Math.min(amount - barAmount, p.stock[z]);
              long earned = barAmount * Zone.at(z).barPrice + oreAmount * Zone.at(z).orePrice;
              earned = Math.round(earned * (1 + p.research[3] * .05) * Prestige.income(p)
                  * (1 + Alchemy.bonus(p, Alchemy.Potion.GOLD))
                  * (1 + Archaeology.bonus(p)));
              if (earned == 0) {
                stopped = "Händler wartet auf Ware"; w.blocked = "Wartet auf Ware";
                break;
              }
              wage = Industry.wage(w, earned);
              if (!pay(p, wage)) {
                stopped = "Betriebsbudget leer"; w.blocked = "Betriebsbudget fehlt";
                break;
              }
              p.bars[z] -= barAmount;
              p.stock[z] -= oreAmount;
              p.money += earned;
              p.lifetimeRevenue += earned;
              revenue += earned;
              worked = true;
            }
          }
          // Goods that could not be delivered are lost; only the fraction carries over.
          w.carry = worked ? w.carry - amount : w.carry - Math.floor(w.carry);
          if (!worked) continue;
          w.blocked = "";
          {
            p.budget -= wage;
            costs += wage;
            if (Industry.usesFuel(job)) p.fuel--;
            w.workMinutes++;
            String find = Industry.workerFind(p, w);
            if (find.equals("dust")) dust++;
            else if (find.equals("relic")) relics++;
            else if (find.equals("note")) notes++;
            else if (find.startsWith("bonus:")) revenue += Long.parseLong(find.substring(6));
          }
        }
    // Keep sub-minute remainder; discard time beyond the explicit offline cap.
    p.lastSettled = elapsed > cap ? now : p.lastSettled + minutes * 60_000;
    return new Report(
        minutes, mined, smelted, revenue, costs, stopped, dust, relics, notes, chopped);
  }

  /**
   * 0.22.4: pays a wage from the operating budget; with auto pay the missing part comes from the
   * player's money, so workers keep going in the deep mines where wages are high.
   */
  static boolean pay(Profile p, long wage) {
    if (p.budget >= wage) return true;
    if (!p.autoBudget) return false;
    long need = wage - p.budget;
    if (p.money < need) return false;
    p.money -= need;
    p.budget += need;
    return true;
  }

  /** Auto pay also buys fuel: 60 units (one hour for one worker) at 1 $ each. */
  static boolean buyFuel(Profile p) {
    if (!p.autoBudget || p.money < 60) return false;
    p.money -= 60;
    p.fuel += 60;
    return true;
  }

  /**
   * 0.22.4: workers on the same shift rhythm all rested at the same moment and the whole crew
   * stood still. This spreads them over the shift (only the timing, not how long they work).
   */
  public static void staggerShifts(Profile p) {
    List<Profile.Worker> working = new java.util.ArrayList<>();
    for (Profile.Worker w : p.workers) if (w.rest == 0) working.add(w);
    boolean together = false;
    for (int i = 1; i < working.size() && !together; i++)
      for (int j = 0; j < i; j++)
        if (Math.abs(working.get(i).shift - working.get(j).shift) < 5) together = true;
    if (!together) return;
    int base = working.getFirst().shift, n = working.size();
    for (int k = 1; k < n; k++)
      working.get(k).shift = (base + k * Industry.SHIFT_MINUTES / n) % Industry.SHIFT_MINUTES;
  }

  private Production() {}
}
