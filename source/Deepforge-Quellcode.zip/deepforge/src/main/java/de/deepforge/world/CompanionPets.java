package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import java.util.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Vector;

/** The active companion follows its owner as a small, harmless creature everyone can see. */
public final class CompanionPets implements Listener {
  private final DeepforgePlugin plugin;
  private final NamespacedKey key;
  private final Map<UUID, Mob> pets = new HashMap<>();
  private final Map<UUID, String> shown = new HashMap<>();
  private long tick;

  public CompanionPets(DeepforgePlugin plugin) {
    this.plugin = plugin;
    key = new NamespacedKey(plugin, "companion_pet");
    for (World w : Bukkit.getWorlds())
      for (Entity e : w.getEntities()) if (e.getPersistentDataContainer().has(key)) e.remove();
    Bukkit.getPluginManager().registerEvents(this, plugin);
    Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20, 2);
  }

  /** Brooding happens at the camp: on the surface of your own plot, outside any fight. */
  public boolean atCamp(Player p) {
    Profile data = plugin.profile(p);
    return plugin.mines().owns(data, p.getLocation())
        && p.getLocation().getY() >= 190
        && !plugin.dungeons().active(p)
        && !plugin.combat().fighting(p);
  }

  private static EntityType type(Companions.Species s) {
    return switch (s) {
      case PANZERKAEFER -> EntityType.ARMADILLO;
      case FLINKLING -> EntityType.FOX;
      case BLUTEGEL -> EntityType.BAT;
      case GLUTLING -> EntityType.MAGMA_CUBE;
      case FROSTLING -> EntityType.POLAR_BEAR;
      case FELSRIESE -> EntityType.IRON_GOLEM;
      case ERZSCHNUEFFLER -> EntityType.SNIFFER;
    };
  }

  private static double scale(Companions.Species s) {
    return switch (s) {
      case FELSRIESE -> .32;
      case ERZSCHNUEFFLER -> .3;
      case FROSTLING -> .6;
      default -> .7;
    };
  }

  private Location spot(Player p) {
    Vector back = p.getLocation().getDirection().setY(0);
    if (back.lengthSquared() < .01) back = new Vector(0, 0, 1);
    back.normalize();
    Vector side = new Vector(-back.getZ(), 0, back.getX());
    Location at = p.getLocation().clone().subtract(back.multiply(1.3)).add(side.multiply(.9));
    at.add(0, .15 + Math.sin(tick / 6.0) * .08, 0);
    at.setYaw(p.getLocation().getYaw());
    at.setPitch(0);
    return at;
  }

  private void tick() {
    tick += 2;
    Set<UUID> seen = new HashSet<>();
    for (Player p : Bukkit.getOnlinePlayers()) {
      if (!plugin.playing(p) || p.isDead() || p.getGameMode() == GameMode.SPECTATOR) continue;
      Companions.Companion c = Companions.active(plugin.profile(p));
      if (c == null) continue;
      UUID id = p.getUniqueId();
      seen.add(id);
      String signature = c.id + ":" + c.level;
      Mob pet = pets.get(id);
      if (pet == null || !pet.isValid() || pet.getWorld() != p.getWorld() || !signature.equals(shown.get(id))) {
        if (pet != null) pet.remove();
        pet = spawn(p, c);
        pets.put(id, pet);
        shown.put(id, signature);
      }
      Location target = spot(p);
      if (pet.getLocation().distanceSquared(target) > .0025) pet.teleport(target);
    }
    for (Iterator<Map.Entry<UUID, Mob>> it = pets.entrySet().iterator(); it.hasNext(); ) {
      Map.Entry<UUID, Mob> e = it.next();
      if (seen.contains(e.getKey())) continue;
      e.getValue().remove();
      shown.remove(e.getKey());
      it.remove();
    }
  }

  private Mob spawn(Player p, Companions.Companion c) {
    Location at = spot(p);
    return (Mob)
        at.getWorld()
            .spawn(
                at,
                type(c.species).getEntityClass(),
                false,
                e -> {
                  Mob m = (Mob) e;
                  m.getPersistentDataContainer().set(key, PersistentDataType.STRING, p.getUniqueId().toString());
                  m.setAI(false);
                  m.setInvulnerable(true);
                  m.setSilent(true);
                  m.setGravity(false);
                  m.setPersistent(false);
                  m.setCollidable(false);
                  m.setRemoveWhenFarAway(false);
                  m.setCanPickupItems(false);
                  if (m instanceof Ageable a) a.setBaby();
                  if (m instanceof MagmaCube cube) cube.setSize(1);
                  var scale = m.getAttribute(Attribute.SCALE);
                  if (scale != null) scale.setBaseValue(scale(c.species));
                  m.customName(
                      Component.text(
                          Companions.name(c) + " · St. " + c.level,
                          c.rarity.ordinal() >= Gear.Rarity.LEGENDARY.ordinal()
                              ? NamedTextColor.GOLD
                              : c.rarity == Gear.Rarity.EPIC ? NamedTextColor.LIGHT_PURPLE : NamedTextColor.AQUA));
                  m.setCustomNameVisible(true);
                  m.setGlowing(c.rarity.ordinal() >= Gear.Rarity.LEGENDARY.ordinal());
                });
  }

  /** Egg found: title, sound, and a server message for legendary and mythic eggs. */
  public void found(Player p, Companions.Egg egg) {
    p.showTitle(
        Title.title(
            Component.text("EIN EI!", NamedTextColor.LIGHT_PURPLE),
            Component.text(egg.rarity.title + "es Ei · /df begleiter", NamedTextColor.YELLOW)));
    p.playSound(p.getLocation(), Sound.ENTITY_CHICKEN_EGG, 1, .8f);
    p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, .7f, 1.4f);
    plugin.tell(
        p,
        "Du hast ein " + egg.rarity.title.toLowerCase(Locale.ROOT) + "es Ei gefunden! Ausbrüten in der Brutstätte am Camp: /df begleiter");
    if (egg.rarity.ordinal() >= Gear.Rarity.LEGENDARY.ordinal())
      for (Player other : Bukkit.getOnlinePlayers())
        if (other != p && plugin.playing(other))
          plugin.tell(other, p.getName() + " hat ein " + egg.rarity.title.toLowerCase(Locale.ROOT) + "es Ei gefunden!");
  }

  /** Blutegel: heals its owner by a share of their life after every win. */
  public void victory(Player p) {
    double heal = Companions.bonus(plugin.profile(p), Companions.Species.BLUTEGEL);
    if (heal <= 0 || p.isDead()) return;
    double max = p.getAttribute(Attribute.MAX_HEALTH).getValue();
    p.setHealth(Math.min(max, p.getHealth() + max * heal));
  }

  @EventHandler(ignoreCancelled = true)
  public void damage(EntityDamageEvent e) {
    if (e.getEntity().getPersistentDataContainer().has(key)) e.setCancelled(true);
  }

  @EventHandler(ignoreCancelled = true)
  public void target(EntityTargetEvent e) {
    if (e.getEntity().getPersistentDataContainer().has(key)) e.setCancelled(true);
  }

  @EventHandler
  public void quit(PlayerQuitEvent e) {
    Mob pet = pets.remove(e.getPlayer().getUniqueId());
    shown.remove(e.getPlayer().getUniqueId());
    if (pet != null) pet.remove();
  }

  public void close() {
    pets.values().forEach(Entity::remove);
    pets.clear();
    shown.clear();
  }
}
