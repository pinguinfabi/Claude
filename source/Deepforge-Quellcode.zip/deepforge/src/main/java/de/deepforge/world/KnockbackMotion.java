package de.deepforge.world;

import org.bukkit.Location;
import org.bukkit.entity.Mob;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

/** Bosses have vanilla AI disabled; move their impulse explicitly without crossing solid blocks. */
final class KnockbackMotion {
  static boolean push(Mob mob, Vector displacement) {
    int steps = Math.max(1, (int) Math.ceil(displacement.length() / .12));
    Vector step = displacement.clone().multiply(1.0 / steps);
    boolean moved = false;
    for (int i = 0; i < steps; i++) {
      Location next = mob.getLocation().add(step);
      BoundingBox box = mob.getBoundingBox().shift(step);
      if (next.clone().add(0, -.1, 0).getBlock().isPassable()) break;
      boolean blocked = false;
      for (int x = (int) Math.floor(box.getMinX()); x <= Math.floor(box.getMaxX() - .0001); x++)
        for (int y = (int) Math.floor(box.getMinY() + .0001);
            y <= Math.floor(box.getMaxY() - .0001);
            y++)
          for (int z = (int) Math.floor(box.getMinZ());
              z <= Math.floor(box.getMaxZ() - .0001);
              z++) {
            var block = mob.getWorld().getBlockAt(x, y, z);
            if (!block.isPassable() && block.getBoundingBox().overlaps(box)) blocked = true;
          }
      if (blocked) break;
      mob.teleport(next);
      moved = true;
    }
    return moved;
  }

  private KnockbackMotion() {}
}
