package de.deepforge.game;

public enum Zone {
  IRON("Eisenmine", "Eisenerz", "iron", 12, 32, 0, 0, 40),
  CRYSTAL("Kristallhöhle", "Kristallerz", "crystal", 28, 74, 3000, 2, 90),
  SPORE("Pilztiefen", "Sporenerz", "spore", 55, 145, 12000, 4, 160),
  ABYSS("Versunkene Schächte", "Tiefenerz", "abyss", 100, 265, 40000, 6, 250),
  EMBER("Magmaschlucht", "Gluterz", "ember", 185, 490, 110000, 8, 400),
  RELIC("Vergessene Ruinen", "Relikterz", "relic", 330, 875, 300000, 10, 650),
  VOID("Leerenbruch", "Leerenerz", "void", 600, 1600, 800000, 12, 1000),
  // 0.9.0: ten deeper mines in a second shaft beside the first.
  CORE("Kernschmelze", "Kernerz", "core", 1020, 2720, 2_400_000, 14, 0),
  MIRROR("Spiegelgrotten", "Spiegelerz", "mirror", 1730, 4620, 5_400_000, 16, 0),
  TOXIC("Giftschlund", "Toxerz", "toxic", 2950, 7850, 12_000_000, 17, 0),
  STORM("Sturmklüfte", "Sturmerz", "storm", 5000, 13350, 27_000_000, 18, 0),
  FOSSIL("Knochengrund", "Fossilerz", "fossil", 8500, 22700, 61_000_000, 20, 0),
  AETHER("Ätherhallen", "Äthererz", "aether", 14500, 38600, 138_000_000, 22, 0),
  SHADOW("Schattenreich", "Schattenerz", "shadow", 24600, 65600, 310_000_000, 24, 0),
  STAR("Sternenbruch", "Sternerz", "star", 41800, 111500, 700_000_000L, 26, 0),
  PRIMAL("Urzeitkammern", "Urerz", "primal", 71000, 189600, 1_600_000_000L, 28, 0),
  WORLDCORE("Weltenkern", "Kernkristall", "worldcore", 120800, 322300, 3_600_000_000L, 30, 0);

  /** Number of mines; zone-indexed profile arrays have this length (× 3 for zone/mode pairs). */
  public static final int COUNT = 17, LAST = COUNT - 1, FIRST_DEEP = 7;
  public final String title, oreName, key;
  public final long orePrice, barPrice, unlockCost;
  public final int toolRequired, bossHealth;

  Zone(
      String title,
      String oreName,
      String key,
      long orePrice,
      long barPrice,
      long unlockCost,
      int toolRequired,
      int bossHealth) {
    this.title = title;
    this.oreName = oreName;
    this.key = key;
    this.orePrice = orePrice;
    this.barPrice = barPrice;
    this.unlockCost = unlockCost;
    this.toolRequired = toolRequired;
    this.bossHealth = bossHealth;
  }

  /** Schutztraining level that protects against the zone's air; 0 = harmless. */
  public static int hazardArmor(int zone) {
    return switch (zone) {
      case 2 -> 2;
      case 3 -> 4;
      case 9 -> 12;
      case 13 -> 16;
      default -> 0;
    };
  }

  public String hazard() {
    return switch (this) {
      case SPORE -> "Sporenluft in den Pilztiefen";
      case TOXIC -> "Giftdämpfe im Giftschlund";
      case SHADOW -> "Lebensraubende Schatten im Schattenreich";
      default -> "Giftiges Grubenwasser in den Versunkenen Schächten";
    };
  }

  /** Cash rewards of the deep shaft grow like its ore prices: ×1,7 per mine after the seventh. */
  public static double deepFactor(int zone) {
    return Math.pow(1.7, Math.max(0, zone - 6));
  }

  public static Zone at(int i) {
    return values()[Math.clamp(i, 0, values().length - 1)];
  }
}
