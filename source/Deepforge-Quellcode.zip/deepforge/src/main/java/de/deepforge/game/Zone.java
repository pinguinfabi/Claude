package de.deepforge.game;

public enum Zone {
  IRON("Eisenmine", "Eisenerz", "iron", 12, 32, 0, 0, 40),
  CRYSTAL("Kristallhöhle", "Kristallerz", "crystal", 28, 74, 3000, 2, 90),
  SPORE("Pilztiefen", "Sporenerz", "spore", 55, 145, 12000, 4, 160),
  ABYSS("Versunkene Schächte", "Tiefenerz", "abyss", 100, 265, 40000, 6, 250),
  EMBER("Magmaschlucht", "Gluterz", "ember", 185, 490, 110000, 8, 400),
  RELIC("Vergessene Ruinen", "Relikterz", "relic", 330, 875, 300000, 10, 650),
  VOID("Leerenbruch", "Leerenerz", "void", 600, 1600, 800000, 12, 1000);
  public final String title, oreName, key;
  public final long orePrice, barPrice, unlockCost;
  public final int toolRequired, bossHealth;

  Zone(
      String title,
      String oreName,
      String key,
      long orePrice,
      long barPrice,
      long unlockCost,
      int toolRequired,
      int bossHealth) {
    this.title = title;
    this.oreName = oreName;
    this.key = key;
    this.orePrice = orePrice;
    this.barPrice = barPrice;
    this.unlockCost = unlockCost;
    this.toolRequired = toolRequired;
    this.bossHealth = bossHealth;
  }

  public static Zone at(int i) {
    return values()[Math.clamp(i, 0, values().length - 1)];
  }
}
