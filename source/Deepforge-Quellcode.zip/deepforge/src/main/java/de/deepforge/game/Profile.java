package de.deepforge.game;

import java.util.*;

/** One aggregate per player: inventory, money and last settlement commit together. */
public final class Profile {
  public String id, name;
  public int schema = 2, plot, zone, tool, sword, armor, bagLevel, warehouse, furnace, housing;
  public int module, relics, quest, orders, workerSerial;
  public long money = 250, budget, fuel, mined, kills, lifetimeRevenue, lastSettled;
  public long[] bag = new long[Zone.COUNT], stock = new long[Zone.COUNT], bars = new long[Zone.COUNT];
  public long[] collected = new long[Zone.COUNT];
  public boolean[] bosses = new boolean[Zone.COUNT], collectionClaimed = new boolean[Zone.COUNT];
  public List<Worker> workers = new ArrayList<>();
  public List<Gear.Item> gear = new ArrayList<>();
  public Map<String, String> equipped = new HashMap<>();
  // Saved loadouts; see GearPresets.
  public List<GearPresets.Preset> gearPresets = new ArrayList<>();
  // Rune bag: one counter per rune code (see Runes), and champions slain.
  public long[] runes = new long[30];
  public long champions;
  // Meisterschaft: permanent mastery XP and learnt talent ranks (node name → rank).
  public long talentXp;
  public Map<String, Integer> talents = new HashMap<>();
  // Begleiter: eggs (brooding or waiting), hatched companions and the one following you.
  public List<Companions.Egg> eggs = new ArrayList<>();
  public List<Companions.Companion> companions = new ArrayList<>();
  public String activeCompanion;
  // Sternensteine: +11 (one above max) with 10 %, otherwise the item breaks.
  public long starStones, urbossKills;
  // Guild membership (id) and money paid into the guild bank.
  public String guild;
  public long guildContributed;
  public long dust;
  // Relikt-Schmiede (0.20.0): rare boss parts (order of Relics.Part) and relics forged.
  public int[] relicParts = new int[6];
  public int relicsForged;
  public long[] bossTokens = new long[Zone.COUNT], monsterParts = new long[Zone.COUNT];
  public int[] bossWins = new int[Zone.COUNT * 3], dryStreak = new int[Zone.COUNT];
  public long[] huntKills = new long[Zone.COUNT], huntsCompleted = new long[Zone.COUNT];
  public List<String> rewardReceipts = new ArrayList<>();
  public Set<String> discovered = new HashSet<>();
  public int[] research = new int[5], contracts = new int[3], collectionTiers = new int[Zone.COUNT];
  public long researchNotes;
  public boolean[] expeditions = new boolean[Zone.COUNT * 3];
  public int[] dungeonWins = new int[Zone.COUNT * 3];
  public long[] dungeonBestTicks = new long[Zone.COUNT * 3];
  // Wins per dungeon (Runengewölbe, Glutschmiede, Frostkrypta).
  public int[] variantWins = new int[3];
  public List<String> dungeonReceipts = new ArrayList<>();
  // Zero means a pre-progression save; migrated from recorded victories on load.
  public int dungeonLevel;
  // Dungeon level per zone (0 = not yet derived from that zone's wins).
  public int[] zoneLevels = new int[Zone.COUNT];
  public int healingCharges = 1;
  // "Heiltasche" upgrade level: carry 3 + level healing shards (max 12).
  public int healStock;
  public long healingReadyAt;
  public String returnWorld;
  public double returnX, returnY, returnZ;
  public float returnYaw, returnPitch;
  public boolean enrolled;
  public int tutorialStep;
  public boolean tutorialPaused;
  public long manualSmelted, soldBars, depositedOre, dodges, healsUsed;
  public int adventureRescues, adventureChallenges, adventureTreasures;
  public Set<Integer> artifactCollection = new HashSet<>();
  // Claimed milestone tiers as "goal:tier".
  public Set<String> milestones = new HashSet<>();
  // Daily tasks: date they were handed out, task ids, counters at that moment and targets.
  public String dailyDate = "", dailyStreakDate = "";
  public List<String> dailyTasks = new ArrayList<>();
  public long[] dailyBase = new long[3], dailyTarget = new long[3];
  public boolean[] dailyClaimed = new boolean[3];
  public boolean dailyBonusClaimed;
  public int dailyStreak, dailyBestStreak;
  public long richVeins, bestCombo;
  // Tiefenpass: season number, XP this season, claimed tiers and bonus tiers taken after 30.
  public int passSeason, passBonus;
  public long passXp;
  public Set<Integer> passClaimed = new HashSet<>();
  // Loot the player has looked at in the bag; everything else is marked NEU.
  public Set<String> seenGear = new HashSet<>();
  public boolean gearSeenInit;
  // 0 = automatic (game HUD once the server-sent pack is loaded), 1 = game HUD, 2 = text HUD.
  public int hudStyle;
  public boolean critDamageMigrated;
  // 0.9.1: loot bag order – 0 newest first, 1 by kind (slot), 2 by rarity.
  public int lootSort;
  // 0.9.3 Tiefengang: deepest Ebene ever, and the best of the ISO week deepWeek (yyyyww).
  public int deepBest, deepWeek, deepWeekBest, deepRuns;
  // 0.10.0: epoch day of the last "first dungeon win of the day" bonus.
  public long dailyDungeonDay;
  // Vault chests offered for the last won dungeon run.
  public String chestRun = "";
  public int chestZone, chestMode, chestLevel, chestBought;
  // 0.12.0 Prestige: current prestige, highest ever, unspent Tiefenglut and learnt Glut talents.
  public int prestige, bestPrestige, glut;
  public Map<String, Integer> prestigeNodes = new HashMap<>();
  // 0.13.0 Alchemie: ingredients (see Alchemy.Ingredient), brewing XP, potions in stock and the
  // expiry time (ms) of every active potion.
  public long[] ingredients = new long[3];
  public long alchemyXp;
  public Map<String, Long> potions = new HashMap<>(), activePotions = new HashMap<>();
  // 0.14.0 Archäologie: finds in hand (id "zone:index" → count) and the ones given to the museum.
  public Map<String, Integer> finds = new HashMap<>();
  public Set<String> museum = new HashSet<>();
  // 0.15.0 Glänzende Monster: kinds caught ("zone:kind"), total caught and Glanzsplitter.
  public Set<String> shinyDex = new HashSet<>();
  public long shinyKills, glanz;
  // Steam drone "Funke": 0 = not built.
  public int droneLevel, droneModule, droneSkin;
  public boolean droneHidden;
  public long droneOre, droneShots, droneHealed, flawlessBosses;
  public int oreLuck, axe, woodLuck, woodStorage, sawmill, forestTier, resin, woodOrders;
  public long woodChopped, woodTrees;
  public long[] wood = new long[3], planks = new long[3];

  public static final class Worker {
    public String id, name;
    public Job job = Job.MINER;
    public int level = 1, zone, specialization;
    public long workMinutes;
    public boolean paused;
    // Fractional goods carried over between production minutes.
    public double carry;
    // Shift minutes since the last break, and break minutes still to rest.
    public int shift, rest;

    public Worker() {}

    public Worker(String name, Job job, int zone) {
      id = UUID.randomUUID().toString();
      this.name = name;
      this.job = job;
      this.zone = zone;
    }
  }

  public enum Job {
    MINER,
    SMELTER,
    TRADER,
    // Chops trees in the forest; its "zone" is the wood type (0 oak, 1 birch, 2 spruce).
    LUMBERJACK
  }

  public long bagCapacity() {
    return 200L + bagLevel * 150L;
  }

  public long stockCapacity() {
    return 960L + warehouse * 960L + research[4] * 240L;
  }

  public int workerSlots() {
    return 1 + housing;
  }

  public int offlineHours() {
    // 0.8.1: at most 12 h of offline work (was 24 h) so workers support play instead of replacing it.
    return Math.min(12, 6 + warehouse + research[4]);
  }

  public long bagUsed() {
    return Arrays.stream(bag).sum();
  }

  public long stockUsed() {
    return Arrays.stream(stock).sum() + Arrays.stream(bars).sum();
  }

  public long power() {
    return Math.round(
        (20 + tool * 8L)
            * Prestige.miningBonus(this)
            * (1 + Alchemy.bonus(this, Alchemy.Potion.BERGMANN)));
  }
}
