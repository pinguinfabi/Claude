package de.deepforge.game;

import java.util.*;

/** One aggregate per player: inventory, money and last settlement commit together. */
public final class Profile {
  public String id, name;
  public int schema = 2, plot, zone, tool, sword, armor, bagLevel, warehouse, furnace, housing;
  public int module, relics, quest, orders, workerSerial;
  public long money = 250, budget, fuel, mined, kills, lifetimeRevenue, lastSettled;
  public long[] bag = new long[7], stock = new long[7], bars = new long[7];
  public long[] collected = new long[7];
  public boolean[] bosses = new boolean[7], collectionClaimed = new boolean[7];
  public List<Worker> workers = new ArrayList<>();
  public List<Gear.Item> gear = new ArrayList<>();
  public Map<String, String> equipped = new HashMap<>();
  public long dust;
  public long[] bossTokens = new long[7], monsterParts = new long[7];
  public int[] bossWins = new int[21], dryStreak = new int[7];
  public long[] huntKills = new long[7], huntsCompleted = new long[7];
  public List<String> rewardReceipts = new ArrayList<>();
  public Set<String> discovered = new HashSet<>();
  public int[] research = new int[5], contracts = new int[3], collectionTiers = new int[7];
  public long researchNotes;
  public boolean[] expeditions = new boolean[21];
  public int[] dungeonWins = new int[21];
  public long[] dungeonBestTicks = new long[21];
  public List<String> dungeonReceipts = new ArrayList<>();
  // Zero means a pre-progression save; migrated from recorded victories on load.
  public int dungeonLevel;
  public int healingCharges = 1;
  public long healingReadyAt;
  public String returnWorld;
  public double returnX, returnY, returnZ;
  public float returnYaw, returnPitch;
  public boolean enrolled;
  public int tutorialStep;
  public boolean tutorialPaused;
  public long manualSmelted, soldBars, depositedOre, dodges, healsUsed;
  public int adventureRescues, adventureChallenges, adventureTreasures;
  public Set<Integer> artifactCollection = new HashSet<>();
  // Claimed milestone tiers as "goal:tier".
  public Set<String> milestones = new HashSet<>();
  // Daily tasks: date they were handed out, task ids, counters at that moment and targets.
  public String dailyDate = "", dailyStreakDate = "";
  public List<String> dailyTasks = new ArrayList<>();
  public long[] dailyBase = new long[3], dailyTarget = new long[3];
  public boolean[] dailyClaimed = new boolean[3];
  public boolean dailyBonusClaimed;
  public int dailyStreak, dailyBestStreak;
  public long richVeins, bestCombo;
  // Loot the player has looked at in the bag; everything else is marked NEU.
  public Set<String> seenGear = new HashSet<>();
  public boolean gearSeenInit;
  public int oreLuck, axe, woodLuck, woodStorage, sawmill, forestTier, resin, woodOrders;
  public long woodChopped, woodTrees;
  public long[] wood = new long[3], planks = new long[3];

  public static final class Worker {
    public String id, name;
    public Job job = Job.MINER;
    public int level = 1, zone, specialization;
    public long workMinutes;
    public boolean paused;

    public Worker() {}

    public Worker(String name, Job job, int zone) {
      id = UUID.randomUUID().toString();
      this.name = name;
      this.job = job;
      this.zone = zone;
    }
  }

  public enum Job {
    MINER,
    SMELTER,
    TRADER
  }

  public long bagCapacity() {
    return 200L + bagLevel * 150L;
  }

  public long stockCapacity() {
    return 960L + warehouse * 960L + research[4] * 240L;
  }

  public int workerSlots() {
    return 1 + housing;
  }

  public int offlineHours() {
    return Math.min(24, 8 + warehouse * 2 + research[4]);
  }

  public long bagUsed() {
    return Arrays.stream(bag).sum();
  }

  public long stockUsed() {
    return Arrays.stream(stock).sum() + Arrays.stream(bars).sum();
  }

  public long power() {
    return 20 + tool * 8L;
  }
}
