package de.deepforge.game;

import java.util.*;

/** One aggregate per player: inventory, money and last settlement commit together. */
public final class Profile {
  public String id, name;
  public int schema = 2, plot, zone, tool, sword, armor, bagLevel, warehouse, furnace, housing;
  public int module, relics, quest, orders, workerSerial;
  public long money = 250, budget, fuel, mined, kills, lifetimeRevenue, lastSettled;
  public long[] bag = new long[7], stock = new long[7], bars = new long[7];
  public long[] collected = new long[7];
  public boolean[] bosses = new boolean[7], collectionClaimed = new boolean[7];
  public List<Worker> workers = new ArrayList<>();
  public List<Gear.Item> gear = new ArrayList<>();
  public Map<String, String> equipped = new HashMap<>();
  // Saved loadouts; see GearPresets.
  public List<GearPresets.Preset> gearPresets = new ArrayList<>();
  // Rune bag: one counter per rune code (see Runes), and champions slain.
  public long[] runes = new long[30];
  public long champions;
  // Meisterschaft: permanent mastery XP and learnt talent ranks (node name → rank).
  public long talentXp;
  public Map<String, Integer> talents = new HashMap<>();
  // Begleiter: eggs (brooding or waiting), hatched companions and the one following you.
  public List<Companions.Egg> eggs = new ArrayList<>();
  public List<Companions.Companion> companions = new ArrayList<>();
  public String activeCompanion;
  // Sternensteine: +12 with 10 %, otherwise the item breaks.
  public long starStones;
  public long dust;
  public long[] bossTokens = new long[7], monsterParts = new long[7];
  public int[] bossWins = new int[21], dryStreak = new int[7];
  public long[] huntKills = new long[7], huntsCompleted = new long[7];
  public List<String> rewardReceipts = new ArrayList<>();
  public Set<String> discovered = new HashSet<>();
  public int[] research = new int[5], contracts = new int[3], collectionTiers = new int[7];
  public long researchNotes;
  public boolean[] expeditions = new boolean[21];
  public int[] dungeonWins = new int[21];
  public long[] dungeonBestTicks = new long[21];
  // Wins per dungeon (Runengewölbe, Glutschmiede, Frostkrypta).
  public int[] variantWins = new int[3];
  public List<String> dungeonReceipts = new ArrayList<>();
  // Zero means a pre-progression save; migrated from recorded victories on load.
  public int dungeonLevel;
  // Dungeon level per zone (0 = not yet derived from that zone's wins).
  public int[] zoneLevels = new int[7];
  public int healingCharges = 1;
  // "Heiltasche" upgrade level: carry 3 + level healing shards (max 12).
  public int healStock;
  public long healingReadyAt;
  public String returnWorld;
  public double returnX, returnY, returnZ;
  public float returnYaw, returnPitch;
  public boolean enrolled;
  public int tutorialStep;
  public boolean tutorialPaused;
  public long manualSmelted, soldBars, depositedOre, dodges, healsUsed;
  public int adventureRescues, adventureChallenges, adventureTreasures;
  public Set<Integer> artifactCollection = new HashSet<>();
  // Claimed milestone tiers as "goal:tier".
  public Set<String> milestones = new HashSet<>();
  // Daily tasks: date they were handed out, task ids, counters at that moment and targets.
  public String dailyDate = "", dailyStreakDate = "";
  public List<String> dailyTasks = new ArrayList<>();
  public long[] dailyBase = new long[3], dailyTarget = new long[3];
  public boolean[] dailyClaimed = new boolean[3];
  public boolean dailyBonusClaimed;
  public int dailyStreak, dailyBestStreak;
  public long richVeins, bestCombo;
  // Tiefenpass: season number, XP this season, claimed tiers and bonus tiers taken after 30.
  public int passSeason, passBonus;
  public long passXp;
  public Set<Integer> passClaimed = new HashSet<>();
  // Loot the player has looked at in the bag; everything else is marked NEU.
  public Set<String> seenGear = new HashSet<>();
  public boolean gearSeenInit;
  // 0 = automatic (game HUD once the server-sent pack is loaded), 1 = game HUD, 2 = text HUD.
  public int hudStyle;
  public boolean critDamageMigrated;
  // Vault chests offered for the last won dungeon run.
  public String chestRun = "";
  public int chestZone, chestMode, chestLevel, chestBought;
  // Steam drone "Funke": 0 = not built.
  public int droneLevel, droneModule, droneSkin;
  public boolean droneHidden;
  public long droneOre, droneShots, droneHealed, flawlessBosses;
  public int oreLuck, axe, woodLuck, woodStorage, sawmill, forestTier, resin, woodOrders;
  public long woodChopped, woodTrees;
  public long[] wood = new long[3], planks = new long[3];

  public static final class Worker {
    public String id, name;
    public Job job = Job.MINER;
    public int level = 1, zone, specialization;
    public long workMinutes;
    public boolean paused;
    // Fractional goods carried over between production minutes.
    public double carry;
    // Shift minutes since the last break, and break minutes still to rest.
    public int shift, rest;

    public Worker() {}

    public Worker(String name, Job job, int zone) {
      id = UUID.randomUUID().toString();
      this.name = name;
      this.job = job;
      this.zone = zone;
    }
  }

  public enum Job {
    MINER,
    SMELTER,
    TRADER,
    // Chops trees in the forest; its "zone" is the wood type (0 oak, 1 birch, 2 spruce).
    LUMBERJACK
  }

  public long bagCapacity() {
    return 200L + bagLevel * 150L;
  }

  public long stockCapacity() {
    return 960L + warehouse * 960L + research[4] * 240L;
  }

  public int workerSlots() {
    return 1 + housing;
  }

  public int offlineHours() {
    // 0.8.1: at most 12 h of offline work (was 24 h) so workers support play instead of replacing it.
    return Math.min(12, 6 + warehouse + research[4]);
  }

  public long bagUsed() {
    return Arrays.stream(bag).sum();
  }

  public long stockUsed() {
    return Arrays.stream(stock).sum() + Arrays.stream(bars).sum();
  }

  public long power() {
    return 20 + tool * 8L;
  }
}
