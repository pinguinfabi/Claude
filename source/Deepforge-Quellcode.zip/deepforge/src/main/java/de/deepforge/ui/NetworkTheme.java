package de.deepforge.ui;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;

/**
 * Einheitliches Design-System für Scoreboard/Sidebar, Tabliste (Header/Footer) und ähnliche
 * Text-UI-Elemente über alle Fabiderpinguin-Network-Plugins hinweg.
 *
 * <p>Diese Klasse hat bewusst KEINE Abhängigkeit zu Varo-spezifischem Code (nur Adventure). Sie ist
 * 1:1 aus EventCore/LPVP übernommen, damit Sidebar/ Tabliste/Broadcasts überall gleich aussehen,
 * ohne dass die Plugins voneinander abhängen müssen.
 *
 * <p>Design-Regeln: - Domain immer im Gold-Verlauf (#ffb300 -> #ff7300) + fett - derselbe Verlauf,
 * den LobbySystem im Tabliste-/Scoreboard-Titel schon nutzt - Plugin-Name immer WEISS + fett -
 * Trenner-Glyphe für "Label -> Wert" ist IMMER {@link #SEPARATOR} ("▸"), nirgendwo abweichend
 * "»"/"┃" verwenden - Divider-Linien nutzen {@link #DIVIDER_CHAR} ("─") - Labels sind GRAU,
 * statische Werte WEISS, dynamische Werte (Status, Teamfarbe, ...) bekommen ihre eigene
 * Bedeutungsfarbe - Social/Community-Links sind immer LIGHT_PURPLE
 */
public final class NetworkTheme {

  private NetworkTheme() {}

  /** Einheitliche Trenner-Glyphe zwischen Label und Wert, netzwerkweit. */
  public static final String SEPARATOR = "▸";

  /**
   * Einheitlicher Bullet-Punkt zwischen zwei gleichrangigen Begriffen (z. B. "Domain ● Plugin").
   */
  public static final String DOT = "●";

  /** Zeichen für horizontale Divider-Linien. */
  public static final char DIVIDER_CHAR = '─';

  /**
   * Flache Gold-Farbe für Stellen, die den Marken-Verlauf nicht abbilden können (z. B. Hologramme).
   */
  public static final NamedTextColor BRAND_COLOR = NamedTextColor.GOLD;

  public static final NamedTextColor PLUGIN_NAME_COLOR = NamedTextColor.WHITE;
  public static final NamedTextColor SUBTITLE_COLOR = NamedTextColor.GRAY;
  public static final NamedTextColor DIVIDER_COLOR = NamedTextColor.DARK_GRAY;
  public static final NamedTextColor LABEL_COLOR = NamedTextColor.GRAY;
  public static final NamedTextColor VALUE_COLOR = NamedTextColor.WHITE;
  public static final NamedTextColor MUTED_COLOR = NamedTextColor.DARK_GRAY;
  public static final NamedTextColor SOCIAL_COLOR = NamedTextColor.LIGHT_PURPLE;

  private static final MiniMessage MINI = MiniMessage.miniMessage();
  private static final String DOMAIN_TEMPLATE =
      "<gradient:#ffb300:#ff7300><bold><domain></bold></gradient>";

  /**
   * "Pinguin Netzwerk ● Varo" - der Standard-Titel-Baustein für Sidebar-Überschrift und
   * Tabliste-Kopfzeile. Domain im Gold-Verlauf fett, Plugin-Name fett weiß.
   */
  public static Component brandTitle(String domain, String pluginName) {
    Component domainComponent =
        MINI.deserialize(DOMAIN_TEMPLATE, Placeholder.unparsed("domain", domain));

    return domainComponent
        .append(dot())
        .append(Component.text(pluginName, PLUGIN_NAME_COLOR).decorate(TextDecoration.BOLD));
  }

  /** Nur der Netzwerkname, z. B. als Titel der Seitenleiste. */
  public static Component networkTitle(String domain) {
    return MINI.deserialize(DOMAIN_TEMPLATE, Placeholder.unparsed("domain", domain));
  }

  /** Optionaler Untertitel direkt unter dem Brand-Titel. */
  public static Component subtitle(String text) {
    return Component.text(text, SUBTITLE_COLOR).decoration(TextDecoration.BOLD, false);
  }

  /** Der netzwerkweit einheitliche Bullet-Punkt " ● " zwischen zwei gleichrangigen Begriffen. */
  public static Component dot() {
    return Component.text(" " + DOT + " ", MUTED_COLOR).decoration(TextDecoration.BOLD, false);
  }

  /** Eine horizontale Divider-Linie fester Breite. */
  public static Component divider(int width) {
    return Component.text(String.valueOf(DIVIDER_CHAR).repeat(Math.max(1, width)), DIVIDER_COLOR);
  }

  /** Eine "Label ▸ Wert"-Zeile mit dem netzwerkweit einheitlichen Trenner. */
  public static Component keyValue(String label, Component value) {
    return Component.text(label, LABEL_COLOR)
        .append(Component.text(" " + SEPARATOR + " ", MUTED_COLOR))
        .append(value);
  }

  public static Component keyValue(String label, String value, NamedTextColor valueColor) {
    return keyValue(label, Component.text(value, valueColor));
  }

  /** Ein einzelnes Social-/Community-Link, z. B. für den Footer. */
  public static Component socialLine(String text) {
    return Component.text(text, SOCIAL_COLOR);
  }
}
