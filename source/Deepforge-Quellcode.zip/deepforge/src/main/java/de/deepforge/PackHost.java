package de.deepforge;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.logging.Level;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * The resource pack bundled in the plugin jar: copied to plugins/Deepforge/ on start and, when
 * enabled, served over HTTP so players always get exactly the pack this plugin version needs.
 */
public final class PackHost implements AutoCloseable {
  public static final String FILE = "Deepforge-ResourcePack.zip";
  private final JavaPlugin plugin;
  private final byte[] data;
  private final String sha1;
  private Object server;
  private int port;

  PackHost(JavaPlugin plugin) {
    this.plugin = plugin;
    byte[] bytes = null;
    try (InputStream in = plugin.getResource("pack/" + FILE)) {
      if (in != null) bytes = in.readAllBytes();
    } catch (IOException e) {
      plugin.getLogger().log(Level.WARNING, "Bundled resource pack unreadable", e);
    }
    data = bytes;
    sha1 = bytes == null ? "" : sha1(bytes);
    if (bytes != null)
      try {
        Path out = plugin.getDataFolder().toPath().resolve(FILE);
        if (!Files.exists(out) || !sha1.equals(sha1(Files.readAllBytes(out))))
          Files.write(out, bytes);
      } catch (IOException e) {
        plugin.getLogger().log(Level.WARNING, "Could not write " + FILE, e);
      }
  }

  static String sha1(byte[] bytes) {
    try {
      return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-1").digest(bytes));
    } catch (java.security.NoSuchAlgorithmException e) {
      throw new IllegalStateException(e);
    }
  }

  /** SHA-1 of the bundled pack, or "" when the jar has none. */
  public String sha1() {
    return sha1;
  }

  public boolean available() {
    return data != null;
  }

  public boolean serving() {
    return server != null;
  }

  /** Starts the small built-in web server; false when the port is taken or HTTP is missing. */
  boolean start(int port) {
    if (data == null) return false;
    try {
      var http = com.sun.net.httpserver.HttpServer.create(new InetSocketAddress(port), 0);
      http.createContext(
          "/",
          exchange -> {
            try (exchange) {
              String path = exchange.getRequestURI().getPath();
              if (!path.startsWith("/Deepforge-ResourcePack") || !path.endsWith(".zip")) {
                exchange.sendResponseHeaders(404, -1);
                return;
              }
              exchange.getResponseHeaders().set("Content-Type", "application/zip");
              exchange.sendResponseHeaders(200, data.length);
              exchange.getResponseBody().write(data);
            }
          });
      http.start();
      server = http;
      this.port = port;
      plugin.getLogger().info("Resource pack served on port " + port + " (SHA-1 " + sha1 + ")");
      return true;
    } catch (IOException | LinkageError e) {
      plugin.getLogger().warning("Resource pack web server not started: " + e);
      return false;
    }
  }

  /** Download address for this player: the host name they connected with, unless configured. */
  public String url(Player player, String publicAddress) {
    String host = publicAddress == null || publicAddress.isBlank() ? null : publicAddress.trim();
    if (host == null && player.getVirtualHost() != null)
      host = player.getVirtualHost().getHostString();
    if (host == null || host.isBlank()) host = "localhost";
    return "http://" + host + ":" + port + "/Deepforge-ResourcePack-" + sha1.substring(0, 8) + ".zip";
  }

  @Override
  public void close() {
    if (server != null) ((com.sun.net.httpserver.HttpServer) server).stop(0);
    server = null;
  }
}
