package de.deepforge.game;

import java.util.Arrays;

/** Stored forestry resources are separate from the ore bag. All actions mutate one profile. */
public final class Forestry {
  private Forestry() {}

  public static String act(Profile p, String action) {
    if (action.equals("sell")) return "Holz und Bretter verkauft: +" + sell(p) + " $.";
    if (action.startsWith("sell:")) {
      int species = Integer.parseInt(action.substring(5));
      if (species < 0 || species >= WOODS.length) return "Unbekannte Holzart.";
      long money = sell(p, species);
      return money > 0
          ? WOODS[species] + " (Holz und Bretter) verkauft: +" + money + " $."
          : "Du hast kein " + WOODS[species] + "-Holz.";
    }
    if (action.equals("unlock")) return unlock(p);
    if (action.equals("charcoal")) return charcoal(p);
    if (action.startsWith("saw:")) return saw(p, Integer.parseInt(action.substring(4)));
    if (action.startsWith("contract:")) return contract(p, Integer.parseInt(action.substring(9)));
    return upgrade(p, action);
  }

  public static final String[] WOODS = {"Eiche", "Birke", "Fichte"};
  public static final int[] PRICES = {6, 10, 16}, PLANK_PRICES = {4, 7, 11};

  public static long capacity(Profile p) {
    return 400L + p.woodStorage * 200L;
  }

  public static long used(Profile p) {
    return Arrays.stream(p.wood).sum() + Arrays.stream(p.planks).sum();
  }

  public static double doubleChance(Profile p) {
    return p.woodLuck * .1;
  }

  public static double speed(Profile p) {
    return 2 + p.axe * .65;
  }

  public static int level(Profile p) {
    return 1 + (int) Math.min(99, p.woodChopped / 128);
  }

  public static long cost(Profile p, String action) {
    int n =
        switch (action) {
          case "axe" -> p.axe;
          case "woodLuck" -> p.woodLuck;
          case "woodStorage" -> p.woodStorage;
          case "sawmill" -> p.sawmill;
          default -> -1;
        };
    return n < 0
        ? 0
        : (action.equals("sawmill") ? 800L : action.equals("woodLuck") ? 400L : 250L)
            * (n + 1)
            * (n + 1);
  }

  public static String upgrade(Profile p, String action) {
    int n =
        switch (action) {
          case "axe" -> p.axe;
          case "woodLuck" -> p.woodLuck;
          case "woodStorage" -> p.woodStorage;
          case "sawmill" -> p.sawmill;
          default -> -1;
        };
    if (n < 0) return "Unbekanntes Forstupgrade.";
    if (n >= (action.equals("sawmill") ? 3 : 10)) return "Maximale Stufe erreicht.";
    long cost = cost(p, action);
    if (p.money < cost) return "Benötigt " + cost + " $.";
    if (action.equals("axe") && n >= 5 && p.resin < 1)
      return "Ab Axtstufe 6 wird außerdem 1 Harz benötigt.";
    p.money -= cost;
    if (action.equals("axe") && n >= 5) p.resin--;
    switch (action) {
      case "axe" -> p.axe++;
      case "woodLuck" -> p.woodLuck++;
      case "woodStorage" -> p.woodStorage++;
      case "sawmill" -> p.sawmill++;
    }
    return "Forstupgrade gekauft für " + cost + " $.";
  }

  public static String unlock(Profile p) {
    if (p.forestTier >= 2) return "Alle drei Haine freigeschaltet.";
    int next = p.forestTier + 1, axe = next == 1 ? 2 : 5;
    long wood = next == 1 ? 64 : 256, cost = next == 1 ? 1000 : 4000;
    if (p.axe < axe || p.woodChopped < wood || p.money < cost)
      return "Benötigt Axt " + axe + ", " + wood + " gefälltes Holz und " + cost + " $.";
    p.money -= cost;
    p.forestTier = next;
    return WOODS[next] + " freigeschaltet!";
  }

  public static long harvest(Profile p, int species, double bonusRoll, double resinRoll) {
    if (species < 0 || species > p.forestTier || species > 2) return 0;
    long amount = (6 + species * 2L) * (bonusRoll < doubleChance(p) ? 2 : 1);
    if (capacity(p) - used(p) < amount) return 0;
    p.wood[species] += amount;
    p.woodChopped += amount;
    p.woodTrees++;
    if (resinRoll < .04) p.resin++;
    return amount;
  }

  public static String saw(Profile p, int species) {
    if (species < 0 || species > 2) return "Ungültige Holzart.";
    int yield = 2 + p.sawmill;
    long n = Math.min(16, Math.min(p.wood[species], p.fuel));
    n = Math.min(n, Math.max(0, capacity(p) - used(p)) / (yield - 1));
    if (n <= 0) return "Benötigt Holz, Brennstoff und freien Holzlagerplatz.";
    p.wood[species] -= n;
    p.fuel -= n;
    p.planks[species] += n * yield;
    return n + " Holz zu " + n * yield + " Brettern verarbeitet.";
  }

  public static long sell(Profile p) {
    long money = 0;
    for (int i = 0; i < 3; i++) money += sell(p, i);
    return money;
  }

  /** Sells logs and planks of one wood type; the others stay in storage. */
  public static long sell(Profile p, int species) {
    long money = value(p, species);
    p.wood[species] = p.planks[species] = 0;
    p.money = Math.addExact(p.money, money);
    p.lifetimeRevenue = Math.addExact(p.lifetimeRevenue, money);
    return money;
  }

  public static long value(Profile p, int species) {
    return p.wood[species] * PRICES[species] + p.planks[species] * PLANK_PRICES[species];
  }

  public static String charcoal(Profile p) {
    if (Arrays.stream(p.wood).sum() < 10) return "Benötigt 10 Holz für 20 Brennstoff.";
    long need = 10;
    for (int i = 0; i < 3; i++) {
      long n = Math.min(need, p.wood[i]);
      p.wood[i] -= n;
      need -= n;
    }
    p.fuel += 20;
    return "10 Holz zu 20 Brennstoff verkohlt.";
  }

  public static String contract(Profile p, int sequence) {
    if (sequence != p.woodOrders) return "Auftrag bereits abgeschlossen. Menü aktualisieren.";
    int species = p.woodOrders % (p.forestTier + 1);
    long amount = 24 + (p.woodOrders % 4) * 8L;
    if (p.wood[species] < amount) return "Benötigt " + amount + " " + WOODS[species] + ".";
    p.wood[species] -= amount;
    long reward = amount * PRICES[species] * 3 / 2;
    p.money += reward;
    p.lifetimeRevenue += reward;
    p.woodOrders++;
    if (p.woodOrders % 5 == 0) p.resin++;
    return "Holzlieferung: +" + reward + " $. Jeder fünfte Auftrag gibt Harz.";
  }
}
