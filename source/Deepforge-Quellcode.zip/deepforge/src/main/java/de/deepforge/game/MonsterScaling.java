package de.deepforge.game;

/**
 * Mine monsters and bosses grow exponentially with depth so better gear never trivialises the
 * lower mines: every zone deeper has clearly more life and hits clearly harder.
 */
public final class MonsterScaling {
  private MonsterScaling() {}

  /** Normal monster life: 65 in the first mine, +55 % per zone (about 900 in the Leerenbruch). */
  public static double health(int zone, int kind) {
    return 65 * Math.pow(1.55, Math.max(0, zone)) * (kind == 1 ? 1.8 : 1);
  }

  /** Damage multiplier for normal monsters: +40 % per zone. */
  public static double monsterDamage(int zone) {
    return Math.pow(1.4, Math.max(0, zone));
  }

  /** Damage multiplier for bosses (their attacks are telegraphed): +30 % per zone. */
  public static double bossDamage(int zone) {
    return Math.pow(1.3, Math.max(0, zone));
  }

  public static double touch(int zone) {
    return 2.5 * monsterDamage(zone);
  }

  public static double attack(boolean boss, int zone, int mode) {
    return (boss ? 5.5 * bossDamage(zone) : 3.5 * monsterDamage(zone)) * (1 + mode * .3);
  }

  public static double sweep(int zone, int mode) {
    return 8 * bossDamage(zone) * (1 + mode * .3);
  }

  public static double hazard(int zone) {
    return 2 * bossDamage(zone);
  }
}
