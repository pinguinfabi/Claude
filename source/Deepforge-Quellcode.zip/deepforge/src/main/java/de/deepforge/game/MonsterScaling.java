package de.deepforge.game;

/**
 * Mine monsters and bosses grow exponentially with depth so better gear never trivialises the
 * lower mines: every zone deeper has clearly more life and hits clearly harder.
 */
public final class MonsterScaling {
  private MonsterScaling() {}

  /** Normal monster life (0.8.5): 100 in the first mine, +60 % per zone (about 1.700 in the last). */
  public static double health(int zone, int kind) {
    return 100 * Math.pow(1.6, shallow(zone)) * Math.pow(1.2, deep(zone)) * (kind == 1 ? 1.8 : 1);
  }

  /** Damage multiplier for normal monsters: +45 % per zone, +14 % per mine of the deep shaft. */
  public static double monsterDamage(int zone) {
    return Math.pow(1.45, shallow(zone)) * Math.pow(1.14, deep(zone));
  }

  /** Damage multiplier for bosses (their attacks are telegraphed): +35 % per zone, then +14 %. */
  public static double bossDamage(int zone) {
    return Math.pow(1.35, shallow(zone)) * Math.pow(1.14, deep(zone));
  }

  /**
   * 0.9.0: the ten deep mines (zone 7+) grow slower per step than the first seven, otherwise the
   * last mine would need thousands of times the first mine's gear. Item power grows +12 % per deep
   * mine, monsters +20 % life / +14 % damage, so every deeper mine still is clearly harder.
   */
  static int shallow(int zone) {
    return Math.clamp(zone, 0, 6);
  }

  static int deep(int zone) {
    return Math.max(0, zone - 6);
  }

  public static double touch(int zone) {
    return 3 * monsterDamage(zone);
  }

  public static double attack(boolean boss, int zone, int mode) {
    return (boss ? 7 * bossDamage(zone) : 4.5 * monsterDamage(zone)) * (1 + mode * .3);
  }

  public static double sweep(int zone, int mode) {
    return 10 * bossDamage(zone) * (1 + mode * .3);
  }

  public static double hazard(int zone) {
    return 2.5 * bossDamage(zone);
  }

  /** Ticks between contact hits of ordinary monsters. */
  public static final int TOUCH_COOLDOWN = 22;

  /** Monsters per player in a mine and ticks between spawn attempts. */
  public static final int MAX_MONSTERS = 5, SPAWN_TICKS = 160;
}
