package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;

/** Sternengeschmiedete (+11) gear shows: a star spiral around its owner, gold sparks on weapons. */
public final class StarAura {
  private final DeepforgePlugin plugin;
  private long tick;

  public StarAura(DeepforgePlugin plugin) {
    this.plugin = plugin;
    Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 40, 4);
  }

  private void tick() {
    tick += 4;
    for (Player p : Bukkit.getOnlinePlayers()) {
      if (!plugin.playing(p) || p.isDead() || p.getGameMode() == GameMode.SPECTATOR) continue;
      Profile data = plugin.profile(p);
      int stars = 0;
      boolean weapon = false;
      for (Gear.Item i : data.gear)
        if (i.level >= StarStones.LEVEL && data.equipped.containsValue(i.id)) {
          stars++;
          if (i.slot == Gear.Slot.WEAPON) weapon = true;
        }
      if (stars == 0) continue;
      World w = p.getWorld();
      Location base = p.getLocation();
      for (int arm = 0; arm < Math.min(3, stars); arm++) {
        double angle = tick * .18 + arm * Math.PI * 2 / Math.min(3, stars);
        double height = (tick % 40) / 20.0;
        w.spawnParticle(Particle.END_ROD, base.clone().add(Math.cos(angle) * .8, height, Math.sin(angle) * .8), 1, 0, 0, 0, 0);
      }
      if (tick % 20 == 0)
        w.spawnParticle(Particle.FIREWORK, base.clone().add(0, .1, 0), 6, .4, 0, .4, .02);
      if (weapon)
        w.spawnParticle(
            Particle.DUST,
            p.getEyeLocation().add(p.getLocation().getDirection().multiply(.6)).add(0, -.5, 0),
            3,
            .15,
            .15,
            .15,
            0,
            new Particle.DustOptions(Color.fromRGB(255, 205, 60), 1.1f));
    }
  }

  /** The big moment: the Sternenstein worked. */
  public void celebrate(Player p, String itemName) {
    Location at = p.getLocation();
    p.getWorld().strikeLightningEffect(at);
    p.playEffect(EntityEffect.TOTEM_RESURRECT);
    Firework fw = p.getWorld().spawn(at.clone().add(0, 1, 0), Firework.class);
    FireworkMeta meta = fw.getFireworkMeta();
    meta.addEffect(
        FireworkEffect.builder()
            .with(FireworkEffect.Type.STAR)
            .withColor(Color.fromRGB(255, 205, 60), Color.WHITE)
            .withFade(Color.fromRGB(140, 90, 255))
            .flicker(true)
            .trail(true)
            .build());
    meta.setPower(0);
    fw.setFireworkMeta(meta);
    fw.setSilent(true);
    Bukkit.getScheduler().runTaskLater(plugin, fw::detonate, 2);
    p.getWorld().spawnParticle(Particle.END_ROD, at.clone().add(0, 1, 0), 120, .6, 1.2, .6, .25);
    for (Player other : Bukkit.getOnlinePlayers())
      if (plugin.playing(other)) {
        other.sendMessage(
            Component.text("✦ STERNENGESCHMIEDET ✦ ", NamedTextColor.GOLD)
                .append(Component.text(p.getName() + " hat " + itemName + " über das Maximum geschmiedet (+" + StarStones.LEVEL + ")!", NamedTextColor.YELLOW)));
        other.playSound(other.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, .8f, .8f);
      }
  }

  /** 90 %: the piece shatters. */
  public void shatter(Player p) {
    Location at = p.getLocation().add(0, 1.2, 0);
    p.getWorld().spawnParticle(Particle.ITEM, at, 60, .3, .3, .3, .2, new org.bukkit.inventory.ItemStack(Material.NETHER_STAR));
    p.getWorld().spawnParticle(Particle.SMOKE, at, 30, .3, .3, .3, .05);
    p.playSound(at, Sound.BLOCK_ANVIL_DESTROY, 1, .7f);
    p.playSound(at, Sound.ENTITY_ITEM_BREAK, 1, .6f);
  }
}
