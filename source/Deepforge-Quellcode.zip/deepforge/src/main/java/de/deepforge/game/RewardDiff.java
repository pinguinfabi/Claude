package de.deepforge.game;

import java.text.NumberFormat;
import java.util.*;

/** What a player actually gained between two snapshots of their profile. */
public final class RewardDiff {
  public final long money, dust, relics, notes, parts, fragments, healing;
  public final int levelBefore, levelAfter;
  // Zone whose dungeon level went up, or -1 (then the levels are the overall level).
  public final int levelZone;
  public final List<Gear.Item> items;
  // Rune codes gained (one entry per rune).
  public final List<Integer> runes;

  private RewardDiff(Profile before, Profile after) {
    money = after.money - before.money;
    dust = after.dust - before.dust;
    relics = after.relics - before.relics;
    notes = after.researchNotes - before.researchNotes;
    parts = sum(after.monsterParts) - sum(before.monsterParts);
    fragments = sum(after.bossTokens) - sum(before.bossTokens);
    healing = after.healingCharges - before.healingCharges;
    int zone = -1;
    if (before.zoneLevels != null && after.zoneLevels != null)
      for (int z = 0; z < Math.min(before.zoneLevels.length, after.zoneLevels.length); z++)
        if (after.zoneLevels[z] > before.zoneLevels[z] && before.zoneLevels[z] > 0) zone = z;
    levelZone = zone;
    levelBefore = zone < 0 ? Math.max(1, before.dungeonLevel) : before.zoneLevels[zone];
    levelAfter = zone < 0 ? Math.max(1, after.dungeonLevel) : after.zoneLevels[zone];
    Set<String> old = new HashSet<>();
    for (Gear.Item i : before.gear) old.add(i.id);
    List<Gear.Item> gained = new ArrayList<>();
    for (Gear.Item i : after.gear) if (!old.contains(i.id)) gained.add(i);
    items = List.copyOf(gained);
    List<Integer> found = new ArrayList<>();
    if (after.runes != null)
      for (int c = 0; c < after.runes.length; c++) {
        long had = before.runes != null && c < before.runes.length ? before.runes[c] : 0;
        for (long n = had; n < after.runes[c]; n++) found.add(c);
      }
    runes = List.copyOf(found);
  }

  public static RewardDiff between(Profile before, Profile after) {
    return new RewardDiff(before, after);
  }

  private static long sum(long[] values) {
    long n = 0;
    if (values != null) for (long v : values) n += v;
    return n;
  }

  private static String n(long v) {
    return NumberFormat.getIntegerInstance(Locale.GERMANY).format(v);
  }

  /** One line per non-zero gain, items last. */
  public List<String> lines() {
    List<String> out = new ArrayList<>();
    if (money != 0) out.add("+" + n(money) + " $");
    if (dust != 0) out.add("+" + n(dust) + " Schmiedestaub");
    if (relics != 0) out.add("+" + n(relics) + " Relikt" + (relics == 1 ? "" : "e"));
    if (notes != 0) out.add("+" + n(notes) + " Forschungsunterlage" + (notes == 1 ? "" : "n"));
    if (fragments != 0) out.add("+" + n(fragments) + " Bossfragment" + (fragments == 1 ? "" : "e"));
    if (parts != 0) out.add("+" + n(parts) + " Monsterteil" + (parts == 1 ? "" : "e"));
    if (healing > 0) out.add("+" + healing + " Lebenssplitter");
    for (int code : runes) out.add("Rune: " + Runes.name(code) + " (" + Runes.effect(code) + ")");
    if (levelAfter > levelBefore)
      out.add(
          (levelZone < 0 ? "Dungeonlevel " : "Dungeonlevel Gebiet " + (levelZone + 1) + ": ")
              + levelBefore
              + " → "
              + levelAfter);
    for (Gear.Item i : items) out.add(item(i));
    return out;
  }

  public static String item(Gear.Item i) {
    return i.rarity.title + " · " + i.name + (i.level > 0 ? " +" + i.level : "");
  }

  public String headline() {
    List<String> parts = new ArrayList<>();
    if (money != 0) parts.add("+" + n(money) + " $");
    if (!items.isEmpty())
      parts.add(items.size() + (items.size() == 1 ? " neuer Gegenstand" : " neue Gegenstände"));
    if (levelAfter > levelBefore) parts.add("Level " + levelAfter);
    return parts.isEmpty() ? "Keine neue Beute" : String.join(" · ", parts);
  }

  public boolean empty() {
    return lines().isEmpty();
  }
}
