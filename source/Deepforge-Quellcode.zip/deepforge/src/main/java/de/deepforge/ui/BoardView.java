package de.deepforge.ui;

import de.deepforge.game.*;
import java.text.NumberFormat;
import java.util.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

public final class BoardView {
  private BoardView() {}

  public static final int LINES = 13;

  private static String number(long value) {
    return NumberFormat.getIntegerInstance(Locale.GERMAN).format(value);
  }

  private static Component stat(String label, String value) {
    return NetworkTheme.keyValue(label, value, NamedTextColor.WHITE);
  }

  /** Dungeon level of the highest unlocked zone; every zone has its own level. */
  private static Component dungeon(Profile p) {
    return stat("Gewölbe", "Level " + DungeonRules.level(p, p.zone) + " · Gebiet " + (p.zone + 1));
  }

  public static Component header(String network) {
    return Component.newline()
        .append(NetworkTheme.brandTitle(network, "Deepforge"))
        .append(Component.newline())
        .append(NetworkTheme.subtitle("BERGBAU • ABENTEUER • AUFSTIEG"))
        .append(Component.newline())
        .append(NetworkTheme.divider(30));
  }

  /** Network style: big DEEPFORGE logo, network name, orange divider. */
  public static Component netzHeader(String network) {
    return Component.newline()
        .append(NetzFont.logo())
        .append(Component.newline())
        .append(Component.newline())
        .append(NetworkTheme.networkTitle(network.toUpperCase(Locale.ROOT)))
        .append(Component.newline())
        .append(NetzFont.divider());
  }

  /** Network style footer: the same infos, each with its icon. */
  public static Component netzFooter(Profile p, int ping, int online, boolean ready, String social) {
    Gear.Stats combat = Gear.stats(p);
    Component result =
        Component.newline()
            .append(NetzFont.divider())
            .append(Component.newline())
            .append(NetzFont.icon(NetzFont.Icon.PLAYER))
            .append(NetworkTheme.keyValue("Spieler", Integer.toString(online), NamedTextColor.GREEN))
            .append(NetworkTheme.dot())
            .append(NetzFont.icon(NetzFont.Icon.CLOCK))
            .append(stat("Ping", Math.max(0, ping) + " ms"))
            .append(Component.newline())
            .append(HudFont.icon(HudFont.Icon.COIN))
            .append(stat("Geld", number(p.money) + " $"))
            .append(NetworkTheme.dot())
            .append(NetzFont.icon(NetzFont.Icon.CROWN))
            .append(dungeon(p))
            .append(Component.newline())
            .append(NetzFont.icon(NetzFont.Icon.SWORD))
            .append(
                stat("Treffer", String.format(Locale.GERMAN, "%.1f LP", RapidCombat.damage(combat))))
            .append(NetworkTheme.dot())
            .append(NetzFont.icon(NetzFont.Icon.BOLT))
            .append(stat("Krit", String.format(Locale.GERMAN, "%.1f %%", combat.crit() * 100)))
            .append(Component.newline())
            .append(
                Component.text(
                    ready ? "Handbuch • /df menu" : "Dein Gelände wird vorbereitet …",
                    NamedTextColor.AQUA));
    if (!social.isBlank())
      result =
          result
              .append(Component.newline())
              .append(NetzFont.icon(NetzFont.Icon.TWITCH))
              .append(NetworkTheme.socialLine(social));
    return result.append(Component.newline());
  }

  public static Component footer(Profile p, int ping, int online, boolean ready, String social) {
    Gear.Stats combat = Gear.stats(p);
    Component result =
        Component.newline()
            .append(NetworkTheme.divider(30))
            .append(Component.newline())
            .append(
                NetworkTheme.keyValue("Spieler", Integer.toString(online), NamedTextColor.GREEN))
            .append(NetworkTheme.dot())
            .append(stat("Ping", Math.max(0, ping) + " ms"))
            .append(Component.newline())
            .append(stat("Geld", number(p.money) + " $"))
            .append(NetworkTheme.dot())
            .append(dungeon(p))
            .append(Component.newline())
            .append(
                stat(
                    "Treffer",
                    String.format(Locale.GERMAN, "%.1f LP", RapidCombat.damage(combat))))
            .append(NetworkTheme.dot())
            .append(stat("Krit", String.format(Locale.GERMAN, "%.1f %%", combat.crit() * 100)))
            .append(Component.newline())
            .append(
                Component.text(
                    ready ? "Handbuch • /df menu" : "Dein Gelände wird vorbereitet …",
                    NamedTextColor.AQUA));
    if (!social.isBlank())
      result = result.append(Component.newline()).append(NetworkTheme.socialLine(social));
    return result.append(Component.newline());
  }

  public static List<Component> lines(Profile p, boolean ready) {
    return lines(p, ready, false);
  }

  /**
   * Sidebar lines; with the resource pack each value gets its icon (network icons where the
   * network pack has one, Deepforge icons otherwise) and the spacers become orange dividers.
   */
  public static List<Component> lines(Profile p, boolean ready, boolean icons) {
    java.util.function.BiFunction<HudFont.Icon, Component, Component> row =
        (icon, line) -> {
          if (!icons) return line;
          NetzFont.Icon netz =
              switch (icon) {
                case STAR -> NetzFont.Icon.STAR;
                case PICK -> NetzFont.Icon.ZONE;
                case CASTLE -> NetzFont.Icon.CROWN;
                case SKULL -> NetzFont.Icon.SKULL;
                case WORKER -> NetzFont.Icon.TEAM;
                case CRYSTAL -> NetzFont.Icon.HEART;
                default -> null;
              };
          return Component.text()
              .append(netz != null ? NetzFont.icon(netz) : HudFont.icon(icon))
              .append(line)
              .build();
        };
    Component spacer = icons ? NetzFont.divider() : Component.empty();
    return List.of(
        ready
            ? row.apply(HudFont.Icon.COIN, stat("Geld", number(p.money) + " $"))
            : Component.text("Gelände wird gebaut …", NamedTextColor.YELLOW),
        row.apply(HudFont.Icon.STAR, stat("Schmiedestaub", number(p.dust))),
        row.apply(HudFont.Icon.PICK, stat("Gebiet", (p.zone + 1) + " / " + de.deepforge.game.Zone.COUNT)),
        row.apply(HudFont.Icon.CASTLE, dungeon(p)),
        row.apply(
            HudFont.Icon.SKULL,
            stat(
                "Tiefenpass",
                "Stufe " + DeepPass.tier(p) + (DeepPass.claimableCount(p) > 0 ? " ✔" : ""))),
        spacer,
        row.apply(HudFont.Icon.BAG, stat("Erzrucksack", number(p.bagUsed()) + " / " + number(p.bagCapacity()))),
        row.apply(HudFont.Icon.LOG, stat("Holzlager", number(Forestry.used(p)) + " / " + number(Forestry.capacity(p)))),
        row.apply(HudFont.Icon.WORKER, stat("Arbeiter", p.workers.size() + " / " + p.workerSlots())),
        row.apply(HudFont.Icon.CRYSTAL, stat("Heilsplitter", p.healingCharges + " / " + Healing.capacity(p))),
        row.apply(
            HudFont.Icon.SCROLL,
            stat(
                "Tagesaufträge",
                Dailies.claimedCount(p) + " / " + Dailies.COUNT
                    + (Dailies.readyCount(p) > 0 ? " ✔" : ""))),
        spacer,
        Component.text("Handbuch • /df menu", NamedTextColor.AQUA));
  }
}
