package de.deepforge.ui;

import de.deepforge.game.*;
import java.text.NumberFormat;
import java.util.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

public final class BoardView {
  private BoardView() {}

  private static String number(long value) {
    return NumberFormat.getIntegerInstance(Locale.GERMAN).format(value);
  }

  private static Component stat(String label, String value) {
    return NetworkTheme.keyValue(label, value, NamedTextColor.WHITE);
  }

  public static Component header(String network) {
    return Component.newline()
        .append(NetworkTheme.brandTitle(network, "Deepforge"))
        .append(Component.newline())
        .append(NetworkTheme.subtitle("BERGBAU • ABENTEUER • AUFSTIEG"))
        .append(Component.newline())
        .append(NetworkTheme.divider(30));
  }

  public static Component footer(Profile p, int ping, int online, boolean ready, String social) {
    Component result =
        Component.newline()
            .append(NetworkTheme.divider(30))
            .append(Component.newline())
            .append(
                NetworkTheme.keyValue("Spieler", Integer.toString(online), NamedTextColor.GREEN))
            .append(NetworkTheme.dot())
            .append(stat("Ping", Math.max(0, ping) + " ms"))
            .append(Component.newline())
            .append(stat("Geld", number(p.money) + " $"))
            .append(NetworkTheme.dot())
            .append(stat("Gewölbe", "Level " + Math.max(1, p.dungeonLevel)))
            .append(Component.newline())
            .append(
                Component.text(
                    ready ? "Handbuch • /df menu" : "Dein Gelände wird vorbereitet …",
                    NamedTextColor.AQUA));
    if (!social.isBlank())
      result = result.append(Component.newline()).append(NetworkTheme.socialLine(social));
    return result.append(Component.newline());
  }

  public static List<Component> lines(Profile p, boolean ready) {
    return List.of(
        Component.text(ready ? "DEIN FORTSCHRITT" : "GELÄNDE WIRD GEBAUT", NamedTextColor.YELLOW),
        Component.empty(),
        stat("Geld", number(p.money) + " $"),
        stat("Gebiet", (p.zone + 1) + " / 7"),
        stat("Gewölbe", "Level " + Math.max(1, p.dungeonLevel)),
        stat("Besiegte Gegner", number(p.kills)),
        Component.empty(),
        stat("Erzrucksack", number(p.bagUsed()) + " / " + number(p.bagCapacity())),
        stat("Holzlager", number(Forestry.used(p)) + " / " + number(Forestry.capacity(p))),
        stat("Arbeiter", p.workers.size() + " / " + p.workerSlots()),
        stat("Heilsplitter", p.healingCharges + " / 12"),
        Component.empty(),
        Component.text("Handbuch • /df menu", NamedTextColor.AQUA));
  }
}
