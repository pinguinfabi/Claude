package de.deepforge.ui;

import de.deepforge.game.*;
import java.text.NumberFormat;
import java.util.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

public final class BoardView {
  private BoardView() {}

  public static final int LINES = 13;

  private static String number(long value) {
    return NumberFormat.getIntegerInstance(Locale.GERMAN).format(value);
  }

  private static Component stat(String label, String value) {
    return NetworkTheme.keyValue(label, value, NamedTextColor.WHITE);
  }

  public static Component header(String network) {
    return Component.newline()
        .append(NetworkTheme.brandTitle(network, "Deepforge"))
        .append(Component.newline())
        .append(NetworkTheme.subtitle("BERGBAU • ABENTEUER • AUFSTIEG"))
        .append(Component.newline())
        .append(NetworkTheme.divider(30));
  }

  public static Component footer(Profile p, int ping, int online, boolean ready, String social) {
    Gear.Stats combat = Gear.stats(p);
    Component result =
        Component.newline()
            .append(NetworkTheme.divider(30))
            .append(Component.newline())
            .append(
                NetworkTheme.keyValue("Spieler", Integer.toString(online), NamedTextColor.GREEN))
            .append(NetworkTheme.dot())
            .append(stat("Ping", Math.max(0, ping) + " ms"))
            .append(Component.newline())
            .append(stat("Geld", number(p.money) + " $"))
            .append(NetworkTheme.dot())
            .append(stat("Gewölbe", "Level " + Math.max(1, p.dungeonLevel)))
            .append(Component.newline())
            .append(
                stat(
                    "Treffer",
                    String.format(Locale.GERMAN, "%.1f LP", RapidCombat.damage(combat))))
            .append(NetworkTheme.dot())
            .append(stat("Krit", String.format(Locale.GERMAN, "%.1f %%", combat.crit() * 100)))
            .append(Component.newline())
            .append(
                Component.text(
                    ready ? "Handbuch • /df menu" : "Dein Gelände wird vorbereitet …",
                    NamedTextColor.AQUA));
    if (!social.isBlank())
      result = result.append(Component.newline()).append(NetworkTheme.socialLine(social));
    return result.append(Component.newline());
  }

  public static List<Component> lines(Profile p, boolean ready) {
    return lines(p, ready, false);
  }

  /** Sidebar lines; with the resource pack each value gets its own HUD icon. */
  public static List<Component> lines(Profile p, boolean ready, boolean icons) {
    java.util.function.BiFunction<HudFont.Icon, Component, Component> row =
        (icon, line) ->
            icons ? Component.text().append(HudFont.icon(icon)).append(line).build() : line;
    return List.of(
        ready
            ? row.apply(HudFont.Icon.COIN, stat("Geld", number(p.money) + " $"))
            : Component.text("Gelände wird gebaut …", NamedTextColor.YELLOW),
        row.apply(HudFont.Icon.STAR, stat("Schmiedestaub", number(p.dust))),
        row.apply(HudFont.Icon.PICK, stat("Gebiet", (p.zone + 1) + " / 7")),
        row.apply(HudFont.Icon.CASTLE, stat("Gewölbe", "Level " + Math.max(1, p.dungeonLevel))),
        row.apply(HudFont.Icon.SKULL, stat("Besiegte Gegner", number(p.kills))),
        Component.empty(),
        row.apply(HudFont.Icon.BAG, stat("Erzrucksack", number(p.bagUsed()) + " / " + number(p.bagCapacity()))),
        row.apply(HudFont.Icon.LOG, stat("Holzlager", number(Forestry.used(p)) + " / " + number(Forestry.capacity(p)))),
        row.apply(HudFont.Icon.WORKER, stat("Arbeiter", p.workers.size() + " / " + p.workerSlots())),
        row.apply(HudFont.Icon.CRYSTAL, stat("Heilsplitter", p.healingCharges + " / 12")),
        row.apply(
            HudFont.Icon.SCROLL,
            stat(
                "Tagesaufträge",
                Dailies.claimedCount(p) + " / " + Dailies.COUNT
                    + (Dailies.readyCount(p) > 0 ? " ✔" : ""))),
        Component.empty(),
        Component.text("Handbuch • /df menu", NamedTextColor.AQUA));
  }
}
