package de.deepforge.game;

import java.util.*;

/** Personal, run-local choices. Leaving or restarting discards them, with no persistent payout. */
public final class DungeonBlessings {
  private final Map<UUID, int[]> choices = new HashMap<>();

  public boolean choose(UUID player, int room, int kind) {
    if (room < 0 || room > 1 || kind < 0 || kind > 2) return false;
    int[] selected = choices.computeIfAbsent(player, key -> new int[] {-1, -1});
    if (selected[room] != -1) return false;
    selected[room] = kind;
    return true;
  }

  private int count(UUID player, int kind) {
    return (int)
        Arrays.stream(choices.getOrDefault(player, new int[] {-1, -1}))
            .filter(n -> n == kind)
            .count();
  }

  public double damage(UUID player) {
    return 1 + .08 * count(player, 0);
  }

  public double incoming(UUID player) {
    return 1 - .08 * count(player, 1);
  }
}
