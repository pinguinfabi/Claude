package de.deepforge.game;

import java.util.*;

/**
 * Personal, run-local choices: one blessing per cleared room. Leaving or restarting discards them,
 * with no persistent payout. Generated dungeons have up to 8 rooms, so the same blessing counts at
 * most {@link #STACK} times.
 */
public final class DungeonBlessings {
  public static final int ROOMS = 16, STACK = 3;
  private final Map<UUID, Map<Integer, Integer>> choices = new HashMap<>();

  public boolean choose(UUID player, int room, int kind) {
    if (room < 0 || room >= ROOMS || kind < 0 || kind > 2) return false;
    return choices.computeIfAbsent(player, key -> new HashMap<>()).putIfAbsent(room, kind) == null;
  }

  public boolean chosen(UUID player, int room) {
    return choices.getOrDefault(player, Map.of()).containsKey(room);
  }

  private int count(UUID player, int kind) {
    return (int)
        Math.min(
            STACK,
            choices.getOrDefault(player, Map.of()).values().stream().filter(n -> n == kind).count());
  }

  public double damage(UUID player) {
    return 1 + .08 * count(player, 0);
  }

  public double incoming(UUID player) {
    return 1 - .08 * count(player, 1);
  }
}
