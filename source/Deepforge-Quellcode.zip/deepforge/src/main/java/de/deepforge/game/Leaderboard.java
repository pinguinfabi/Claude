package de.deepforge.game;

import java.util.*;
import java.util.function.ToLongFunction;

/** Server rankings computed from saved profiles. */
public final class Leaderboard {
  public record Board(String id, String title, String unit, ToLongFunction<Profile> score) {}

  public record Entry(String id, String name, long score) {}

  public static final List<Board> BOARDS =
      List.of(
          new Board("revenue", "Reichste Unternehmer", "$ Umsatz", p -> p.lifetimeRevenue),
          new Board("ore", "Fleißigste Bergleute", "Erz", p -> p.mined),
          new Board("kills", "Monsterjäger", "Gegner", p -> p.kills),
          new Board(
              "bosses",
              "Bossbezwinger",
              "Bosssiege",
              p -> Arrays.stream(p.bossWins).asLongStream().sum()),
          new Board(
              "dungeons",
              "Gewölbegänger",
              "Dungeon-Siege",
              p -> Arrays.stream(p.dungeonWins).asLongStream().sum()),
          new Board("trees", "Holzfäller", "Bäume", p -> p.woodTrees),
          new Board("streak", "Treueste Spieler", "Tage Serie (Rekord)", p -> p.dailyBestStreak),
          new Board("combo", "Kombo-Könige", "Treffer Kombo (Rekord)", p -> p.bestCombo),
          new Board(
              "deepweek",
              "Tiefengang · diese Woche",
              "Ebene",
              p -> DeepDescent.weekBest(p, DeepDescent.currentWeek())),
          new Board("deep", "Tiefengang · Rekord", "Ebene", p -> p.deepBest));

  public static List<Entry> top(Collection<Profile> profiles, Board board, int n) {
    return ranked(profiles, board).stream().limit(n).toList();
  }

  /** 1-based rank of the player, or 0 when they have no score on this board yet. */
  public static int rank(Collection<Profile> profiles, Board board, String id) {
    List<Entry> all = ranked(profiles, board);
    for (int i = 0; i < all.size(); i++) if (all.get(i).id().equals(id)) return i + 1;
    return 0;
  }

  private static List<Entry> ranked(Collection<Profile> profiles, Board board) {
    Map<String, Entry> best = new LinkedHashMap<>();
    for (Profile p : profiles) {
      if (p == null || p.id == null) continue;
      long score = board.score().applyAsLong(p);
      if (score <= 0) continue;
      best.put(p.id, new Entry(p.id, p.name == null ? "?" : p.name, score));
    }
    List<Entry> out = new ArrayList<>(best.values());
    out.sort(
        Comparator.comparingLong(Entry::score).reversed().thenComparing(Entry::name));
    return out;
  }

  private Leaderboard() {}
}
