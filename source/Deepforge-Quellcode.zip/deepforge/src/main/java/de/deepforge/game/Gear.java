package de.deepforge.game;

import java.util.*;
import java.util.random.RandomGenerator;

/** Persistent equipment is owned by the profile; inventory items are replaceable visual proxies. */
public final class Gear {
  public enum Slot {
    WEAPON,
    OFFHAND,
    HELMET,
    CHEST,
    LEGS,
    BOOTS,
    RING,
    RING2,
    AMULET,
    TOOL
  }

  public enum Rarity {
    UNCOMMON("Ungewöhnlich", 1),
    RARE("Selten", 1.3),
    EPIC("Episch", 1.65),
    LEGENDARY("Legendär", 2),
    MYTHIC("Mythisch", 2.2);
    public final String title;
    public final double factor;

    Rarity(String t, double f) {
      title = t;
      factor = f;
    }
  }

  public static final String[] UNIQUE = {
    "Granitspalter",
    "Prismenklinge",
    "Myzelmantel",
    "Gezeitenspeer",
    "Glutbrecher",
    "Runenschild",
    "Rissklinge"
  };
  public static final String[] WEAPONS = {"sword", "hammer", "dagger", "spear", "crossbow"};
  public static final String[] MATERIALS = {
    "Panzerplatten",
    "Kristallsplitter",
    "Pilzkerne",
    "Tiefenfasern",
    "Glutherzen",
    "Runenstaub",
    "Leerenfragmente"
  };

  public static final class Item {
    public String id = UUID.randomUUID().toString(), name, style = "sword";
    public Slot slot = Slot.WEAPON;
    public Rarity rarity = Rarity.UNCOMMON;
    public int zone, level, quality = 85, signature = -1;
    public int archetype = -1, adventureSet = -1;
    public int dungeonRank;
    public double damage, health, defense, crit, haste, stagger, mining, yield, efficiency;
    public boolean favorite;

    public long value() {
      return Math.round((80 + zone * 100) * (rarity.ordinal() + 1) * (1 + level * .15));
    }

    public String model() {
      if (archetype >= 0)
        return new String[] {"unique_1", "unique_6", "unique_0", "drill"}[archetype];
      if (signature >= 0) return "unique_" + signature;
      return slot == Slot.WEAPON
          ? "weapon_" + style
          : slot == Slot.TOOL ? "drill" : "gear_" + slot.name().toLowerCase(Locale.ROOT);
    }
  }

  public record Stats(
      double damage,
      double health,
      double defense,
      double crit,
      double critDamage,
      double speed,
      double stagger,
      double mining,
      double yield,
      double efficiency) {
    public double reduction() {
      return Math.min(.65, defense / (defense + 80));
    }
  }

  public static void migrate(Profile p) {
    if (p.gear == null) p.gear = new ArrayList<>();
    if (p.equipped == null) p.equipped = new HashMap<>();
    if (p.bossTokens == null) p.bossTokens = new long[7];
    if (p.monsterParts == null) p.monsterParts = new long[7];
    if (p.bossWins == null) p.bossWins = new int[21];
    if (p.dryStreak == null) p.dryStreak = new int[7];
    if (p.huntKills == null) p.huntKills = new long[7];
    if (p.huntsCompleted == null) p.huntsCompleted = new long[7];
    if (p.rewardReceipts == null) p.rewardReceipts = new ArrayList<>();
    if (p.discovered == null) p.discovered = new HashSet<>();
    p.schema = 2;
  }

  public static Item equipped(Profile p, Slot slot) {
    return find(p, p.equipped.get(slot.name()));
  }

  public static boolean hasEffect(Profile p, int signature) {
    return p.gear.stream()
        .anyMatch(i -> i.signature == signature && p.equipped.containsValue(i.id));
  }

  public static Item find(Profile p, String id) {
    if (id == null) return null;
    return p.gear.stream().filter(i -> i.id.equals(id)).findFirst().orElse(null);
  }

  public static Stats stats(Profile p) {
    double damage = 6 + Math.min(20, p.sword) * .7,
        health = 20,
        defense = p.armor * 3,
        crit = .05,
        speed = 1.6,
        stagger = 9,
        mining = 0,
        yield = 0,
        efficiency = 0;
    Set<String> ids = new HashSet<>(p.equipped.values());
    Item weapon = equipped(p, Slot.WEAPON);
    for (Item i : p.gear)
      if (ids.contains(i.id)) {
        double scale = 1 + i.level * .08;
        damage += i.damage * scale;
        health += i.health * scale;
        defense += i.defense * scale;
        crit += i.crit;
        speed += i.haste;
        stagger += i.stagger;
        mining += i.mining;
        yield += i.yield;
        efficiency += i.efficiency;
      }
    Map<Integer, Long> sets = new HashMap<>();
    for (Item i : p.gear)
      if (ids.contains(i.id) && i.slot != Slot.WEAPON && i.slot != Slot.TOOL)
        sets.merge(i.zone, 1L, Long::sum);
    for (long count : sets.values()) {
      if (count >= 2) defense += 6;
      if (count >= 4) {
        damage += 3;
        health += 2;
      }
    }
    if (AdventureGear.setCount(p, 2) >= 2) yield += .10;
    if (AdventureGear.setCount(p, 2) >= 4) mining += .15;
    return new Stats(
        damage,
        Math.min(
            Math.min(
                1024,
                60
                    + p.gear.stream()
                            .filter(i -> ids.contains(i.id))
                            .mapToInt(i -> i.dungeonRank)
                            .max()
                            .orElse(0)
                        * 2.),
            health),
        defense,
        Math.min(.5, crit),
        weapon != null && weapon.signature == 1 ? 2.1 : 1.75,
        Math.min(3.2, speed),
        stagger,
        Math.min(.65, mining),
        Math.min(.5, yield),
        Math.min(.5, efficiency));
  }

  public static Item roll(int zone, Rarity rarity, RandomGenerator r) {
    Item i = new Item();
    i.zone = zone;
    i.rarity = rarity;
    i.slot = Slot.values()[r.nextInt(Slot.values().length)];
    i.style = WEAPONS[r.nextInt(WEAPONS.length)];
    i.quality = 80 + r.nextInt(21);
    double power = (1 + zone * .5) * rarity.factor * i.quality / 100.;
    i.name = rarity.title + " " + slotName(i.slot) + " · " + Zone.at(zone).title;
    if (i.slot == Slot.WEAPON) {
      i.damage = power * (i.style.equals("hammer") ? 4.5 : 2.7);
      i.stagger = power * (i.style.equals("hammer") ? 12 : 3);
    } else if (i.slot == Slot.TOOL) {
      i.mining = power * .025;
      i.yield = power * .015;
    } else {
      i.defense = power * 3;
      i.health = power * .65;
    }
    for (int n = 0; n < Math.min(3, 1 + rarity.ordinal()); n++)
      switch (r.nextInt(6)) {
        case 0 -> i.crit += .008 * power;
        case 1 -> i.haste += .025 * power;
        case 2 -> i.health += power * .5;
        case 3 -> i.stagger += power * 2;
        case 4 -> i.yield += power * .009;
        case 5 -> i.efficiency += power * .015;
      }
    return i;
  }

  public static Item unique(int zone, Rarity rarity, RandomGenerator r) {
    Item i = roll(zone, rarity, r);
    i.signature = zone;
    i.name = UNIQUE[zone];
    i.slot = zone == 2 ? Slot.CHEST : zone == 5 ? Slot.OFFHAND : Slot.WEAPON;
    i.style =
        switch (zone) {
          case 0, 4 -> "hammer";
          case 3 -> "spear";
          default -> "sword";
        };
    double power = (1 + zone * .5) * rarity.factor;
    if (i.slot == Slot.WEAPON) {
      i.damage = power * 3.5;
      i.stagger += power * 5;
    } else {
      i.damage = 0;
      i.defense += power * 4;
    }
    return i;
  }

  public static List<Item> bossLoot(
      Profile p, String receipt, int zone, int mode, RandomGenerator r) {
    if (zone < 0 || zone > 6 || mode < 0 || mode > 2) throw new IllegalArgumentException();
    if (p.rewardReceipts.contains(receipt)) return List.of();
    p.rewardReceipts.add(receipt);
    while (p.rewardReceipts.size() > 256) p.rewardReceipts.removeFirst();
    int roll = r.nextInt(10000);
    Rarity rarity =
        roll < 6000
            ? Rarity.UNCOMMON
            : roll < 9000 ? Rarity.RARE : roll < 9900 ? Rarity.EPIC : Rarity.LEGENDARY;
    if (p.dryStreak[zone] >= 9 && rarity.ordinal() < 2) rarity = Rarity.EPIC;
    p.dryStreak[zone] = rarity.ordinal() >= 2 ? 0 : p.dryStreak[zone] + 1;
    List<Item> result = new ArrayList<>();
    result.add(roll(zone, rarity, r));
    if (r.nextDouble() < .02) result.add(unique(zone, Rarity.LEGENDARY, r));
    if (mode == 2 && r.nextDouble() < .002) result.add(unique(zone, Rarity.MYTHIC, r));
    for (Item i : result) {
      p.gear.add(i);
      p.discovered.add(
          i.signature >= 0 ? UNIQUE[i.signature] : i.slot.name() + "/" + i.rarity.name());
    }
    p.bossTokens[zone] += 2 + mode;
    if (r.nextDouble() < .25) {
      Item extra = AdventureGear.drop(zone, r, .08);
      AdventureGear.grant(p, extra);
      result.add(extra);
    }
    p.monsterParts[zone] += 4 + mode * 2;
    p.bossWins[zone * 3 + mode]++;
    p.bosses[zone] = true;
    p.kills++;
    p.relics += 2 + zone + mode;
    long cash = (500L + zone * 350L) * (mode + 1);
    p.money += cash;
    p.lifetimeRevenue += cash;
    return result;
  }

  public static String equip(Profile p, String id) {
    Item i = find(p, id);
    if (i == null) return "Gegenstand nicht gefunden.";
    if (i.zone > p.zone) return "Gebiet noch gesperrt.";
    if (id.equals(p.equipped.get(i.slot.name()))) p.equipped.remove(i.slot.name());
    else p.equipped.put(i.slot.name(), id);
    return "Ausrüstung aktualisiert.";
  }

  public static String sell(Profile p, String id, boolean salvage) {
    Item i = find(p, id);
    if (i == null) return "Gegenstand nicht gefunden.";
    if (i.favorite || p.equipped.containsValue(id))
      return "Favorisierte/ausgerüstete Beute ist geschützt.";
    p.gear.remove(i);
    if (salvage) {
      long n = 1 + i.rarity.ordinal() * 2 + i.level;
      p.dust += n;
      return "+" + n + " Schmiedestaub.";
    }
    p.money += i.value();
    p.lifetimeRevenue += i.value();
    return "+" + i.value() + " $.";
  }

  public static String upgrade(Profile p, String id) {
    Item i = find(p, id);
    if (i == null) return "Gegenstand nicht gefunden.";
    if (i.level >= 10) return "Maximale Verbesserung erreicht.";
    long cost = 250L * (i.zone + 1) * (i.level + 1), dust = 2L + i.level;
    if (p.money < cost || p.dust < dust)
      return "Benötigt " + cost + " $ und " + dust + " Schmiedestaub.";
    p.money -= cost;
    p.dust -= dust;
    i.level++;
    return "Verbessert auf +" + i.level + ".";
  }

  public static String craft(Profile p, int zone) {
    if (zone < 0 || zone > 6 || zone > p.zone) return "Gebiet gesperrt.";
    long cost = 2000L * (zone + 1);
    if (p.bossTokens[zone] < 40 || p.monsterParts[zone] < 30 || p.money < cost)
      return "Benötigt 40 Bossfragmente, 30 Monsterteile und " + cost + " $.";
    p.bossTokens[zone] -= 40;
    p.monsterParts[zone] -= 30;
    p.money -= cost;
    Item i = unique(zone, Rarity.LEGENDARY, RandomGenerator.getDefault());
    p.gear.add(i);
    p.discovered.add(UNIQUE[zone]);
    return "Hergestellt: " + i.name;
  }

  public static String claimHunt(Profile p, int zone) {
    if (zone < 0 || zone > 6 || zone > p.zone) return "Gebiet gesperrt.";
    if (p.huntKills[zone] < 15)
      return "Besiege 15 reguläre Gegner dieses Gebiets. Beschworene Helfer zählen nicht.";
    p.huntKills[zone] -= 15;
    p.huntsCompleted[zone]++;
    long cash = 450L * (zone + 1);
    p.money += cash;
    p.lifetimeRevenue += cash;
    p.dust += 3;
    p.monsterParts[zone] += 6;
    return "Jagdauftrag erfüllt: +"
        + cash
        + " $, +3 Schmiedestaub, +6 Monsterteile. Nächster Auftrag verfügbar.";
  }

  public static String reroll(Profile p, String id, RandomGenerator r) {
    Item i = find(p, id);
    if (i == null) return "Gegenstand nicht gefunden.";
    long cost = 500L * (i.zone + 1);
    if (p.money < cost || p.dust < 5) return "Benötigt " + cost + " $ und 5 Schmiedestaub.";
    p.money -= cost;
    p.dust -= 5;
    double before = i.crit,
        power = (1 + i.zone * .5) * i.rarity.factor * i.quality / 100.;
    i.crit = (.005 + r.nextDouble() * .025) * power;
    return String.format(
        Locale.GERMAN,
        "Krit neu geschmiedet: %.1f %% → %.1f %% (Bereich %.1f–%.1f %%). Andere Werte bleiben.",
        before * 100,
        i.crit * 100,
        .5 * power,
        3 * power);
  }

  public static String effect(int signature) {
    return switch (signature) {
      case 0 -> "Nach Ausweichen: +50 % Haltungsschaden";
      case 1 -> "Kritische Treffer verursachen 210 % Schaden";
      case 2 -> "35 % weniger Schaden von Sporenmonstern";
      case 3 -> "Speerfähigkeit: +40 % Schaden";
      case 4 -> "Hammerfähigkeit: +35 % Schaden";
      case 5 -> "Paradefenster um 0,5 Sekunden verlängert";
      case 6 -> "Fähigkeit: sicherer kurzer Risssprung";
      default -> "Kein einzigartiger Effekt";
    };
  }

  public static String slotName(Slot s) {
    return switch (s) {
      case WEAPON -> "Waffe";
      case OFFHAND -> "Nebenhand";
      case HELMET -> "Helm";
      case CHEST -> "Brustschutz";
      case LEGS -> "Beinschutz";
      case BOOTS -> "Stiefel";
      case RING -> "Ring I";
      case RING2 -> "Ring II";
      case AMULET -> "Amulett";
      case TOOL -> "Bergbaumodul";
    };
  }

  private Gear() {}
}
