package de.deepforge.game;

import java.text.NumberFormat;
import java.util.*;
import java.util.random.RandomGenerator;

/** Persistent equipment is owned by the profile; inventory items are replaceable visual proxies. */
public final class Gear {
  public enum Slot {
    WEAPON,
    OFFHAND,
    HELMET,
    CHEST,
    LEGS,
    BOOTS,
    RING,
    RING2,
    AMULET,
    TOOL
  }

  public enum Rarity {
    UNCOMMON("Ungewöhnlich", 1),
    RARE("Selten", 1.3),
    EPIC("Episch", 1.65),
    LEGENDARY("Legendär", 2),
    MYTHIC("Mythisch", 2.2);
    public final String title;
    public final double factor;

    Rarity(String t, double f) {
      title = t;
      factor = f;
    }
  }

  public static final String[] UNIQUE = {
    "Granitspalter",
    "Prismenklinge",
    "Myzelmantel",
    "Gezeitenspeer",
    "Glutbrecher",
    "Runenschild",
    "Rissklinge",
    "Kernspalter",
    "Spiegelschneide",
    "Giftzahn",
    "Donnerspeer",
    "Knochenbrecher",
    "Ätherwall",
    "Schattenklinge",
    "Sternensplitter",
    "Urzeithammer",
    "Weltenklinge"
  };
  public static final String[] WEAPONS = {"sword", "hammer", "dagger", "spear", "crossbow"};
  public static final String[] MATERIALS = {
    "Panzerplatten",
    "Kristallsplitter",
    "Pilzkerne",
    "Tiefenfasern",
    "Glutherzen",
    "Runenstaub",
    "Leerenfragmente",
    "Kernschlacke",
    "Spiegelscherben",
    "Giftdrüsen",
    "Sturmfedern",
    "Uralte Knochen",
    "Ätherfäden",
    "Schattenessenz",
    "Sternenstaub",
    "Urzeitschuppen",
    "Weltenkristalle"
  };

  public static final class Item {
    public String id = UUID.randomUUID().toString(), name, style = "sword";
    public Slot slot = Slot.WEAPON;
    public Rarity rarity = Rarity.UNCOMMON;
    public int zone, level, quality = 85, signature = -1;
    public int archetype = -1, adventureSet = -1;
    public int dungeonRank;
    public double damage, health, defense, crit, haste, stagger, mining, yield, efficiency;
    // Extra crit damage on top of the weapon type's base (0.25 = +25 percentage points).
    public double critDamage;
    // How often crit chance / crit damage were reforged; each time costs more.
    public int critRerolls, critDamageRerolls;
    public boolean favorite;
    // Rune sockets (-1 = empty); null or empty until rolled or drilled. See Runes.
    public int[] runeSockets;

    public long value() {
      return Math.round((80 + zone * 100) * (rarity.ordinal() + 1) * (1 + level * .15));
    }

    public String model() {
      if (archetype >= 0)
        return new String[] {"unique_1", "unique_6", "unique_0", "drill"}[archetype];
      if (signature >= 0) return "unique_" + signature;
      return slot == Slot.WEAPON
          ? "weapon_" + style
          : slot == Slot.TOOL ? "drill" : "gear_" + slot.name().toLowerCase(Locale.ROOT);
    }
  }

  public record Stats(
      double damage,
      double health,
      double defense,
      double crit,
      double critDamage,
      double speed,
      double stagger,
      double mining,
      double yield,
      double efficiency) {
    public double reduction() {
      return Math.min(.6, defense / (defense + 100));
    }
  }

  static long[] pad(long[] a, int n) {
    return a == null ? new long[n] : a.length >= n ? a : Arrays.copyOf(a, n);
  }

  static int[] pad(int[] a, int n) {
    return a == null ? new int[n] : a.length >= n ? a : Arrays.copyOf(a, n);
  }

  static boolean[] pad(boolean[] a, int n) {
    return a == null ? new boolean[n] : a.length >= n ? a : Arrays.copyOf(a, n);
  }

  public static void migrate(Profile p) {
    if (p.gear == null) p.gear = new ArrayList<>();
    if (p.equipped == null) p.equipped = new HashMap<>();
    // 0.9.0: 17 mines instead of 7 – older saves get their zone arrays widened, nothing is lost.
    int n = Zone.COUNT, m = Zone.COUNT * 3;
    p.bag = pad(p.bag, n);
    p.stock = pad(p.stock, n);
    p.bars = pad(p.bars, n);
    p.collected = pad(p.collected, n);
    p.bossTokens = pad(p.bossTokens, n);
    p.monsterParts = pad(p.monsterParts, n);
    p.huntKills = pad(p.huntKills, n);
    p.huntsCompleted = pad(p.huntsCompleted, n);
    p.dungeonBestTicks = pad(p.dungeonBestTicks, m);
    p.bossWins = pad(p.bossWins, m);
    p.dryStreak = pad(p.dryStreak, n);
    p.collectionTiers = pad(p.collectionTiers, n);
    p.dungeonWins = pad(p.dungeonWins, m);
    p.zoneLevels = pad(p.zoneLevels, n);
    p.bosses = pad(p.bosses, n);
    p.collectionClaimed = pad(p.collectionClaimed, n);
    p.expeditions = pad(p.expeditions, m);
    // Older saves could bank hundreds of kills and claim the hunt again and again.
    for (int z = 0; z < p.huntKills.length; z++)
      p.huntKills[z] = Math.min(HUNT_TARGET, p.huntKills[z]);
    if (p.rewardReceipts == null) p.rewardReceipts = new ArrayList<>();
    if (p.discovered == null) p.discovered = new HashSet<>();
    p.schema = 2;
    if (!p.critDamageMigrated) {
      // Weapons from before per-weapon crit damage get the middle of their range once.
      for (Item i : p.gear)
        if (i.slot == Slot.WEAPON && i.critDamage == 0) {
          double[] range = critDamageRange(i);
          i.critDamage = (range[0] + range[1]) / 2;
        }
      p.critDamageMigrated = true;
    }
  }

  /** Sternengeschmiedet (+11): the item's base values count double on top of its level bonus. */
  public static double starForged(Item i) {
    return i.level >= StarStones.LEVEL ? 2 : 1;
  }

  /** Blade training scales all melee damage (+4 % per level), not just the small base value. */
  public static double swordMultiplier(int sword) {
    return 1 + Math.min(Economy.MAX_COMBAT, Math.max(0, sword)) * .04;
  }

  /** Crit chance above this cap turns into extra crit damage instead (at most +100 %). */
  public static final double CRIT_CAP = .6;

  /** Base crit multiplier of each weapon type: fast, precise weapons crit harder. */
  public static double baseCritDamage(Item weapon) {
    if (weapon == null) return 1.75;
    if (weapon.signature == 1) return 2.1;
    return switch (weapon.style) {
      case "dagger" -> 2.0;
      case "crossbow" -> 1.9;
      case "spear" -> 1.8;
      case "hammer" -> 1.5;
      default -> 1.75;
    };
  }

  /** Rolled extra crit damage on weapons by rarity and quality. */
  public static double[] critDamageRange(Item i) {
    double q = i.quality / 100.;
    double[] range =
        switch (i.rarity) {
          case UNCOMMON -> new double[] {.05, .15};
          case RARE -> new double[] {.10, .25};
          case EPIC -> new double[] {.15, .35};
          case LEGENDARY -> new double[] {.20, .45};
          case MYTHIC -> new double[] {.30, .60};
        };
    return new double[] {range[0] * q, range[1] * q};
  }

  public static Item equipped(Profile p, Slot slot) {
    return find(p, p.equipped.get(slot.name()));
  }

  public static boolean hasEffect(Profile p, int signature) {
    return p.gear.stream()
        .anyMatch(i -> i.signature == signature && p.equipped.containsValue(i.id));
  }

  public static Item find(Profile p, String id) {
    if (id == null) return null;
    return p.gear.stream().filter(i -> i.id.equals(id)).findFirst().orElse(null);
  }

  public static Stats stats(Profile p) {
    double damage = 6 + Math.min(Economy.MAX_COMBAT, p.sword) * .7,
        health = 20,
        defense = p.armor * 3,
        crit = .05,
        critDamage = baseCritDamage(equipped(p, Slot.WEAPON)),
        speed = 1.6,
        stagger = 9,
        mining = 0,
        yield = 0,
        efficiency = 0;
    Set<String> ids = new HashSet<>(p.equipped.values());
    Item weapon = equipped(p, Slot.WEAPON);
    for (Item i : p.gear)
      if (ids.contains(i.id)) {
        double scale = (1 + i.level * .08) * starForged(i);
        damage += i.damage * scale;
        health += i.health * scale;
        defense += i.defense * scale;
        crit += i.crit;
        critDamage += i.critDamage;
        speed += i.haste;
        stagger += i.stagger;
        mining += i.mining;
        yield += i.yield;
        efficiency += i.efficiency;
      }
    Map<Integer, Long> sets = new HashMap<>();
    for (Item i : p.gear)
      if (ids.contains(i.id) && i.slot != Slot.WEAPON && i.slot != Slot.TOOL)
        sets.merge(i.zone, 1L, Long::sum);
    for (long count : sets.values()) {
      if (count >= 2) defense += 6;
      if (count >= 4) {
        damage += 3;
        health += 2;
      }
    }
    if (AdventureGear.setCount(p, 2) >= 2) yield += .10;
    if (AdventureGear.setCount(p, 2) >= 4) mining += .15;
    // Socketed runes (see Runes) add onto the base stats; Leben on top of the health cap.
    damage += Runes.bonus(p, ids, Runes.Kind.KRAFT);
    damage *= swordMultiplier(p.sword);
    damage *= Talents.damage(p);
    damage *= Guilds.damage(p);
    damage *= 1 + Companions.bonus(p, Companions.Species.GLUTLING);
    defense += Companions.bonus(p, Companions.Species.PANZERKAEFER);
    speed += Companions.bonus(p, Companions.Species.FLINKLING);
    crit += Companions.bonus(p, Companions.Species.FROSTLING);
    defense += Runes.bonus(p, ids, Runes.Kind.STEIN);
    speed += Runes.bonus(p, ids, Runes.Kind.WIND);
    crit += Runes.bonus(p, ids, Runes.Kind.GLUECK);
    mining += Runes.bonus(p, ids, Runes.Kind.TIEFE);
    return new Stats(
        damage,
        Math.min(
                Math.min(
                    1024,
                    60
                        + p.gear.stream()
                                .filter(i -> ids.contains(i.id))
                                .mapToInt(i -> i.dungeonRank)
                                .max()
                                .orElse(0)
                            * 2.),
                health)
            + Runes.bonus(p, ids, Runes.Kind.LEBEN)
            + Talents.health(p)
            + Guilds.health(p)
            + Companions.bonus(p, Companions.Species.FELSRIESE),
        defense,
        Math.min(CRIT_CAP, crit),
        critDamage + Math.min(1, Math.max(0, crit - CRIT_CAP)),
        Math.min(3.2, speed),
        stagger,
        Math.min(.65, mining),
        Math.min(.5, yield),
        Math.min(.5, efficiency));
  }

  public static Item roll(int zone, Rarity rarity, RandomGenerator r) {
    Item i = new Item();
    i.zone = zone;
    i.rarity = rarity;
    // Epic loot comes with one empty rune socket, legendary and mythic with two.
    int sockets = rarity.ordinal() >= Rarity.LEGENDARY.ordinal() ? 2 : rarity == Rarity.EPIC ? 1 : 0;
    i.runeSockets = new int[sockets];
    Arrays.fill(i.runeSockets, -1);
    i.slot = Slot.values()[r.nextInt(Slot.values().length)];
    i.style = WEAPONS[r.nextInt(WEAPONS.length)];
    i.quality = 80 + r.nextInt(21);
    double power = power(zone) * rarity.factor * i.quality / 100.;
    i.name = rarity.title + " " + slotName(i.slot) + " · " + Zone.at(zone).title;
    if (i.slot == Slot.WEAPON) {
      i.damage = power * (i.style.equals("hammer") ? 4.5 : 2.7);
      i.stagger = power * (i.style.equals("hammer") ? 12 : 3);
      double[] cd = critDamageRange(i);
      i.critDamage = cd[0] + r.nextDouble() * (cd[1] - cd[0]);
    } else if (i.slot == Slot.TOOL) {
      i.mining = power * .025;
      i.yield = power * .015;
    } else {
      i.defense = power * 3;
      i.health = power * .65;
    }
    for (int n = 0; n < Math.min(3, 1 + rarity.ordinal()); n++)
      switch (r.nextInt(7)) {
        case 6 -> i.critDamage += .012 * power;
        case 0 -> i.crit += .008 * power;
        case 1 -> i.haste += .025 * power;
        case 2 -> i.health += power * .5;
        case 3 -> i.stagger += power * 2;
        case 4 -> i.yield += power * .009;
        case 5 -> i.efficiency += power * .015;
      }
    return i;
  }

  /**
   * Base item power of a zone: +50 % per zone in the first seven mines, then +12 % per deeper mine
   * (zone 7 ≈ 4,5×, Weltenkern ≈ 12,4×).
   */
  public static double power(int zone) {
    return zone <= 6 ? 1 + zone * .5 : 4 * Math.pow(1.12, zone - 6);
  }

  public static Item unique(int zone, Rarity rarity, RandomGenerator r) {
    Item i = roll(zone, rarity, r);
    // The deeper mines reuse the seven unique effects (and their textures) under new names.
    int sig = zone % 7;
    i.signature = sig;
    i.name = UNIQUE[zone];
    i.slot = sig == 2 ? Slot.CHEST : sig == 5 ? Slot.OFFHAND : Slot.WEAPON;
    i.style =
        switch (sig) {
          case 0, 4 -> "hammer";
          case 3 -> "spear";
          default -> "sword";
        };
    double power = power(zone) * rarity.factor;
    if (i.slot == Slot.WEAPON) {
      i.damage = power * 3.5;
      i.stagger += power * 5;
    } else {
      i.damage = 0;
      i.defense += power * 4;
    }
    return i;
  }

  public static List<Item> bossLoot(
      Profile p, String receipt, int zone, int mode, RandomGenerator r) {
    if (zone < 0 || zone > Zone.LAST || mode < 0 || mode > 2) throw new IllegalArgumentException();
    if (p.rewardReceipts.contains(receipt)) return List.of();
    p.rewardReceipts.add(receipt);
    while (p.rewardReceipts.size() > 256) p.rewardReceipts.removeFirst();
    int roll = r.nextInt(10000);
    Rarity rarity =
        roll < 6000
            ? Rarity.UNCOMMON
            : roll < 9000 ? Rarity.RARE : roll < 9900 ? Rarity.EPIC : Rarity.LEGENDARY;
    if (p.dryStreak[zone] >= 9 && rarity.ordinal() < 2) rarity = Rarity.EPIC;
    p.dryStreak[zone] = rarity.ordinal() >= 2 ? 0 : p.dryStreak[zone] + 1;
    List<Item> result = new ArrayList<>();
    result.add(roll(zone, rarity, r));
    if (r.nextDouble() < .02) result.add(unique(zone, Rarity.LEGENDARY, r));
    if (mode == 2 && r.nextDouble() < .002) result.add(unique(zone, Rarity.MYTHIC, r));
    for (Item i : result) {
      p.gear.add(i);
      p.discovered.add(
          i.signature >= 0 ? i.name : i.slot.name() + "/" + i.rarity.name());
    }
    p.bossTokens[zone] += 2 + mode;
    if (r.nextDouble() < .25) {
      Item extra = AdventureGear.drop(zone, r, .08);
      AdventureGear.grant(p, extra);
      result.add(extra);
    }
    p.monsterParts[zone] += 4 + mode * 2;
    p.bossWins[zone * 3 + mode]++;
    p.bosses[zone] = true;
    p.kills++;
    p.relics += 2 + zone + mode;
    long cash = Math.round((500L + zone * 350L) * (mode + 1) * Zone.deepFactor(zone));
    p.money += cash;
    p.lifetimeRevenue += cash;
    return result;
  }

  public static String equip(Profile p, String id) {
    Item i = find(p, id);
    if (i == null) return "Gegenstand nicht gefunden.";
    if (i.zone > p.zone) return "Gebiet noch gesperrt.";
    if (id.equals(p.equipped.get(i.slot.name()))) p.equipped.remove(i.slot.name());
    else p.equipped.put(i.slot.name(), id);
    return "Ausrüstung aktualisiert.";
  }

  /** True when the item may not be sold or salvaged (favourite, equipped or in a gear set). */
  public static boolean isProtected(Profile p, Item i) {
    return i.favorite || p.equipped.containsValue(i.id) || GearPresets.usedBy(p, i.id) != null;
  }

  /**
   * Sells or salvages several items at once; protected ones are skipped. Returns {done, skipped,
   * money, dust}.
   */
  public static long[] sellMany(Profile p, Collection<String> ids, boolean salvage) {
    long done = 0, skipped = 0, money = p.money, dust = p.dust;
    for (String id : new ArrayList<>(ids)) {
      Item i = find(p, id);
      if (i == null) continue;
      if (isProtected(p, i)) {
        skipped++;
        continue;
      }
      sell(p, id, salvage);
      done++;
    }
    return new long[] {done, skipped, p.money - money, p.dust - dust};
  }

  public static String sell(Profile p, String id, boolean salvage) {
    Item i = find(p, id);
    if (i == null) return "Gegenstand nicht gefunden.";
    if (i.favorite || p.equipped.containsValue(id))
      return "Favorisierte/ausgerüstete Beute ist geschützt.";
    String preset = GearPresets.usedBy(p, id);
    if (preset != null)
      return "Teil des Sets „" + preset + "“ – erst das Set ohne dieses Teil neu speichern.";
    p.gear.remove(i);
    if (salvage) {
      long n = Math.round((1 + i.rarity.ordinal() * 2 + i.level) * Talents.dust(p));
      p.dust += n;
      return "+" + n + " Schmiedestaub.";
    }
    p.money += i.value();
    p.lifetimeRevenue += i.value();
    return "+" + i.value() + " $.";
  }

  public static String upgrade(Profile p, String id) {
    Item i = find(p, id);
    if (i == null) return "Gegenstand nicht gefunden.";
    if (i.level >= StarStones.MAX_ENHANCE) return "Maximale Verbesserung erreicht.";
    long cost = Math.round(250L * (i.zone + 1) * (i.level + 1) * Zone.deepFactor(i.zone)),
        dust = 2L + i.level;
    if (p.money < cost || p.dust < dust)
      return "Benötigt " + cost + " $ und " + dust + " Schmiedestaub.";
    p.money -= cost;
    p.dust -= dust;
    i.level++;
    return "Verbessert auf +" + i.level + ".";
  }

  public static String craft(Profile p, int zone) {
    if (zone < 0 || zone > Zone.LAST || zone > p.zone) return "Gebiet gesperrt.";
    long cost = craftCost(zone);
    if (p.bossTokens[zone] < 40 || p.monsterParts[zone] < 30 || p.money < cost)
      return "Benötigt 40 Bossfragmente, 30 Monsterteile und " + cost + " $.";
    p.bossTokens[zone] -= 40;
    p.monsterParts[zone] -= 30;
    p.money -= cost;
    Item i = unique(zone, Rarity.LEGENDARY, java.util.concurrent.ThreadLocalRandom.current());
    p.gear.add(i);
    p.discovered.add(UNIQUE[zone]);
    return "Hergestellt: " + i.name;
  }

  public static final String[] SORTS = {"Neueste zuerst", "Nach Art", "Nach Rarität"};

  /** The loot bag in the player's chosen order (menu pages and page selection use the same). */
  public static List<Item> sorted(Profile p) {
    List<Item> ordered = new ArrayList<>(p.gear);
    Collections.reverse(ordered);
    Comparator<Item> rarity = Comparator.comparingInt((Item i) -> -i.rarity.ordinal());
    Comparator<Item> slot = Comparator.comparingInt((Item i) -> i.slot.ordinal());
    Comparator<Item> strength =
        Comparator.comparingInt((Item i) -> -i.level).thenComparingInt(i -> -i.zone);
    switch (Math.floorMod(p.lootSort, SORTS.length)) {
      case 1 -> ordered.sort(slot.thenComparing(rarity).thenComparing(strength));
      case 2 -> ordered.sort(rarity.thenComparing(slot).thenComparing(strength));
      default -> {}
    }
    return ordered;
  }

  public static long huntCash(int zone) {
    return Math.round(450L * (zone + 1) * Zone.deepFactor(zone));
  }

  public static long craftCost(int zone) {
    return Math.round(2000L * (zone + 1) * Math.pow(1.7, Math.max(0, zone - 6)));
  }

  public static final int HUNT_TARGET = 15;

  /** Counts a kill toward the zone's hunt; progress stops at the target until it is claimed. */
  public static void huntKill(Profile p, int zone) {
    p.huntKills[zone] = Math.min(HUNT_TARGET, p.huntKills[zone] + 1);
  }

  public static String claimHunt(Profile p, int zone) {
    if (zone < 0 || zone > Zone.LAST || zone > p.zone) return "Gebiet gesperrt.";
    if (p.huntKills[zone] < HUNT_TARGET)
      return "Besiege 15 reguläre Gegner dieses Gebiets. Beschworene Helfer zählen nicht.";
    // A new hunt always starts at zero; kills beyond the target are never banked.
    p.huntKills[zone] = 0;
    p.huntsCompleted[zone]++;
    long cash = huntCash(zone);
    p.money += cash;
    p.lifetimeRevenue += cash;
    p.dust += 3;
    p.monsterParts[zone] += 6;
    return "Jagdauftrag erfüllt: +"
        + cash
        + " $, +3 Schmiedestaub, +6 Monsterteile. Neuer Auftrag startet bei 0 / "
        + HUNT_TARGET
        + ".";
  }

  /** Crit reroll range (min, max) by rarity and quality; zone depth does not inflate crit. */
  public static double[] critRange(Item i) {
    double q = i.quality / 100.;
    double[] range =
        switch (i.rarity) {
          case UNCOMMON -> new double[] {.01, .06};
          case RARE -> new double[] {.02, .08};
          case EPIC -> new double[] {.03, .10};
          case LEGENDARY -> new double[] {.04, .12};
          case MYTHIC -> new double[] {.05, .15};
        };
    return new double[] {range[0] * q, range[1] * q};
  }

  /** Reforges at a fair price per value; after that it stays possible, but priced out. */
  public static final int FAIR_REROLLS = 3;

  /** 500 $ × (zone + 1), tripling: ×1, ×3, ×9. After that the value is final (unbezahlbar). */
  public static long rerollCost(Item i, int done) {
    long base = 500L * (i.zone + 1);
    if (done < FAIR_REROLLS) return base * (long) Math.pow(3, done);
    return Long.MAX_VALUE;
  }

  /** After the three fair reforges a value can never be reforged again. */
  public static boolean rerollLocked(int done) {
    return done >= FAIR_REROLLS;
  }

  /** Forge dust: 5, 10, 20. */
  public static long rerollDust(int done) {
    return done < FAIR_REROLLS ? 5L << done : Long.MAX_VALUE;
  }

  public static long rerollCost(Item i) {
    return rerollCost(i, i.critRerolls);
  }

  /** Lore line for a reforge button: price and how many fair reforges are left. */
  public static String rerollPrice(Item i, int done) {
    if (rerollLocked(done)) return "Kosten: UNBEZAHLBAR · alle " + FAIR_REROLLS + " Versuche verbraucht";
    NumberFormat nf = NumberFormat.getIntegerInstance(Locale.GERMANY);
    return "Kosten: "
        + nf.format(rerollCost(i, done))
        + " $ und "
        + nf.format(rerollDust(done))
        + " Staub · "
        + (done < FAIR_REROLLS
            ? (FAIR_REROLLS - done) + " von " + FAIR_REROLLS + " günstigen Versuchen übrig"
            : "keine günstigen Versuche mehr");
  }

  private static String payReroll(Profile p, Item i, int done) {
    if (rerollLocked(done))
      return "Unbezahlbar: Alle "
          + FAIR_REROLLS
          + " Versuche für diesen Wert sind verbraucht. Der Wert bleibt jetzt so.";
    long cost = rerollCost(i, done), dust = rerollDust(done);
    if (p.money < cost || p.dust < dust) {
      NumberFormat nf = NumberFormat.getIntegerInstance(Locale.GERMANY);
      return "Benötigt "
          + nf.format(cost)
          + " $ und "
          + nf.format(dust)
          + " Schmiedestaub (du hast "
          + nf.format(p.money)
          + " $ und "
          + nf.format(p.dust)
          + " Staub). Staub gibt es beim Zerlegen. Nach "
          + FAIR_REROLLS
          + " Versuchen ist der Wert endgültig.";
    }
    p.money -= cost;
    p.dust -= dust;
    return null;
  }

  public static String reroll(Profile p, String id, RandomGenerator r) {
    Item i = find(p, id);
    if (i == null) return "Gegenstand nicht gefunden.";
    String refused = payReroll(p, i, i.critRerolls);
    if (refused != null) return refused;
    i.critRerolls++;
    double before = i.crit;
    double[] range = critRange(i);
    i.crit = range[0] + r.nextDouble() * (range[1] - range[0]);
    return String.format(
        Locale.GERMAN,
        "Krit neu geschmiedet: %.1f %% → %.1f %% (Bereich %.1f–%.1f %%). Andere Werte bleiben. %s",
        before * 100,
        i.crit * 100,
        range[0] * 100,
        range[1] * 100,
        nextPrice(i, i.critRerolls));
  }

  public static String rerollCritDamage(Profile p, String id, RandomGenerator r) {
    Item i = find(p, id);
    if (i == null) return "Gegenstand nicht gefunden.";
    if (i.slot != Slot.WEAPON) return "Krit-Schaden lässt sich nur auf Waffen neu schmieden.";
    String refused = payReroll(p, i, i.critDamageRerolls);
    if (refused != null) return refused;
    i.critDamageRerolls++;
    double before = i.critDamage;
    double[] range = critDamageRange(i);
    i.critDamage = range[0] + r.nextDouble() * (range[1] - range[0]);
    return String.format(
        Locale.GERMAN,
        "Krit-Schaden neu geschmiedet: +%.0f %% → +%.0f %% (Bereich %.0f–%.0f %%). Andere Werte bleiben. %s",
        before * 100,
        i.critDamage * 100,
        range[0] * 100,
        range[1] * 100,
        nextPrice(i, i.critDamageRerolls));
  }

  private static String nextPrice(Item i, int done) {
    return done < FAIR_REROLLS
        ? "Nächstes Mal: " + NumberFormat.getIntegerInstance(Locale.GERMANY).format(rerollCost(i, done)) + " $."
        : "Das war der letzte günstige Versuch – ab jetzt kostet es "
            + NumberFormat.getIntegerInstance(Locale.GERMANY).format(rerollCost(i, done))
            + " $.";
  }

  public static String effect(int signature) {
    return switch (signature) {
      case 0 -> "Nach Ausweichen: +50 % Haltungsschaden";
      case 1 -> "Grund-Krit-Schaden 210 % statt 175 %";
      case 2 -> "35 % weniger Schaden von Sporenmonstern";
      case 3 -> "Speerfähigkeit: +40 % Schaden";
      case 4 -> "Hammerfähigkeit: +35 % Schaden";
      case 5 -> "Paradefenster um 0,5 Sekunden verlängert";
      case 6 -> "Fähigkeit: sicherer kurzer Risssprung";
      default -> "Kein einzigartiger Effekt";
    };
  }

  public static String slotName(Slot s) {
    return switch (s) {
      case WEAPON -> "Waffe";
      case OFFHAND -> "Nebenhand";
      case HELMET -> "Helm";
      case CHEST -> "Brustschutz";
      case LEGS -> "Beinschutz";
      case BOOTS -> "Stiefel";
      case RING -> "Ring I";
      case RING2 -> "Ring II";
      case AMULET -> "Amulett";
      case TOOL -> "Bergbaumodul";
    };
  }

  private Gear() {}
}
