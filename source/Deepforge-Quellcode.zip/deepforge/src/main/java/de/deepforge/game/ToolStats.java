package de.deepforge.game;

/** One source for the actual mining values and the visible held-tool tooltip. */
public record ToolStats(
    double speed,
    double extraOre,
    double relicChance,
    double heatPerOre,
    double cooling,
    long capacity) {
  public static ToolStats of(Profile p, int zone, boolean overloaded) {
    Gear.Stats gear = Gear.stats(p);
    return new ToolStats(
        (.55 + p.tool * .065)
            / (1 + Math.max(0, zone) * .3)
            * (1 + gear.mining())
            * (1 + p.research[0] * .08)
            * (p.module == 1 ? 1.35 : 1)
            * (overloaded ? 2 : 1),
        OreYield.doubleChance(p, gear.yield()),
        p.module == 2 ? .015 : .003,
        (p.module == 1 ? 9 : 5) - p.research[1] * .4,
        7 + p.research[1],
        p.bagCapacity());
  }
}
