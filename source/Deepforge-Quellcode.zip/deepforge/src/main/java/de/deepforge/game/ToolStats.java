package de.deepforge.game;

/** One source for the actual mining values and the visible held-tool tooltip. */
public record ToolStats(
    double speed,
    double extraOre,
    double relicChance,
    double heatPerOre,
    double cooling,
    long capacity) {
  public static ToolStats of(Profile p, int zone, boolean overloaded) {
    Gear.Stats gear = Gear.stats(p);
    return new ToolStats(
        drillPower(p.tool)
            / (1 + Math.max(0, zone) * .3)
            * (1 + gear.mining())
            * (1 + p.research[0] * .08)
            * (p.module == 1 ? 1.35 : 1)
            * (overloaded ? 2 : 1)
            * Talents.mining(p),
        OreYield.doubleChance(p, gear.yield()) + Talents.yield(p),
        p.module == 2 ? .015 : .003,
        ((p.module == 1 ? 9 : 5) - p.research[1] * .4) * heatFactor(p.tool) * Talents.heat(p),
        7 + p.research[1],
        p.bagCapacity());
  }

  /** Each drill level is +12 % on top of the last, so every upgrade is felt (level 10 ≈ 3×). */
  public static double drillPower(int tool) {
    return .55 * Math.pow(1.12, Math.max(0, tool));
  }

  /** Better drills also run cooler, so the extra speed is not eaten by overheating. */
  public static double heatFactor(int tool) {
    return Math.pow(.97, Math.max(0, tool));
  }

  /** Seconds to break one ore block (note block, hardness 0.8) at this speed. */
  public static double seconds(double speed) {
    return Math.ceil(.8 * 30 / Math.max(.01, speed)) / 20;
  }
}
