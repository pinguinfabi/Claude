package de.deepforge.game;

import java.util.*;

/**
 * Per-player numbers of one dungeon run, shown in the victory hall (0.9.2): who dealt the most
 * damage, who took the hits, who kept the group alive.
 */
public final class DungeonStats {
  public static final class Line {
    public double damage, bossDamage, taken, healed;
    public int kills, crits, downs, bestCombo, hits;
    /** Boss attacks that landed on this player, by attack title (0.11.0). */
    public final Map<String, Integer> hitBy = new LinkedHashMap<>();
  }

  public record Award(String title, UUID player, String detail) {}

  private final Map<UUID, Line> lines = new LinkedHashMap<>();

  public Line of(UUID id) {
    return lines.computeIfAbsent(id, k -> new Line());
  }

  public boolean isEmpty() {
    return lines.isEmpty();
  }

  public void hit(UUID id, double dealt, boolean boss, boolean crit, int combo, boolean kill) {
    Line l = of(id);
    l.damage += dealt;
    if (boss) l.bossDamage += dealt;
    l.hits++;
    if (crit) l.crits++;
    if (kill) l.kills++;
    l.bestCombo = Math.max(l.bestCombo, combo);
  }

  public void hitBy(UUID id, String attack) {
    of(id).hitBy.merge(attack, 1, Integer::sum);
  }

  /** The boss attack that hit the group most often, with the count; null if none landed. */
  public Map.Entry<String, Integer> nemesis() {
    Map<String, Integer> all = new LinkedHashMap<>();
    for (Line l : lines.values()) l.hitBy.forEach((k, v) -> all.merge(k, v, Integer::sum));
    return all.entrySet().stream().max(Map.Entry.comparingByValue()).orElse(null);
  }

  /** "Meteoritenhagel 3× · Blitzkette 1×", most frequent first. */
  public String hitsOf(UUID id) {
    StringBuilder b = new StringBuilder();
    of(id).hitBy.entrySet().stream()
        .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
        .forEach(e -> b.append(b.isEmpty() ? "" : " · ").append(e.getKey()).append(' ').append(e.getValue()).append('×'));
    return b.toString();
  }

  public double total() {
    return lines.values().stream().mapToDouble(l -> l.damage).sum();
  }

  /** Share of the group's damage, 0..1. */
  public double share(UUID id) {
    double total = total();
    return total <= 0 ? 0 : of(id).damage / total;
  }

  /** Players by damage dealt, highest first (ties: more kills first). */
  public List<UUID> ranking(Collection<UUID> players) {
    List<UUID> out = new ArrayList<>(players);
    out.sort(
        Comparator.comparingDouble((UUID id) -> -of(id).damage)
            .thenComparingInt(id -> -of(id).kills));
    return out;
  }

  public UUID mvp(Collection<UUID> players) {
    return players.isEmpty() ? null : ranking(players).getFirst();
  }

  /**
   * Titles for the victory screen. With one player only the solo titles are handed out; the
   * "Fels in der Brandung" needs at least two players to compare.
   */
  public List<Award> awards(Collection<UUID> players) {
    List<Award> out = new ArrayList<>();
    if (players.isEmpty()) return out;
    UUID mvp = mvp(players);
    out.add(
        new Award(
            "Schadenskönig",
            mvp,
            fmt(of(mvp).damage) + " Schaden · " + Math.round(share(mvp) * 100) + " %"));
    best(players, l -> l.kills, "Schlächter", " Gegner besiegt").ifPresent(out::add);
    best(players, l -> l.bossDamage, "Bossbrecher", " Schaden am Boss").ifPresent(out::add);
    best(players, l -> l.bestCombo, "Kombo-Meister", "er Kombo").ifPresent(out::add);
    best(players, l -> l.healed, "Zäh wie Leder", " Leben geheilt").ifPresent(out::add);
    if (players.size() > 1) {
      UUID tank =
          players.stream()
              .max(Comparator.comparingDouble((UUID id) -> of(id).taken))
              .orElseThrow();
      if (of(tank).taken > 0)
        out.add(new Award("Fels in der Brandung", tank, fmt(of(tank).taken) + " Schaden eingesteckt"));
    }
    return out;
  }

  private Optional<Award> best(
      Collection<UUID> players,
      java.util.function.ToDoubleFunction<Line> value,
      String title,
      String unit) {
    UUID top =
        players.stream().max(Comparator.comparingDouble(id -> value.applyAsDouble(of(id)))).orElse(null);
    if (top == null || value.applyAsDouble(of(top)) <= 0) return Optional.empty();
    return Optional.of(new Award(title, top, fmt(value.applyAsDouble(of(top))) + unit));
  }

  public static String fmt(double v) {
    long n = Math.round(v);
    if (n >= 1_000_000) return String.format(Locale.GERMAN, "%.1f Mio.", n / 1e6);
    return String.format(Locale.GERMAN, "%,d", n);
  }
}
