package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import java.util.Locale;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

public final class HealingItems implements Listener {
  private final DeepforgePlugin plugin;

  public HealingItems(DeepforgePlugin plugin) {
    this.plugin = plugin;
    Bukkit.getPluginManager().registerEvents(this, plugin);
  }

  @EventHandler(priority = EventPriority.LOW)
  public void click(PlayerInteractEvent e) {
    if (e.getHand() != EquipmentSlot.HAND
        || !e.getAction().isRightClick()
        || !plugin.items().kind(e.getItem()).equals("heal")) return;
    e.setCancelled(true);
    use(e.getPlayer());
  }

  public void use(Player p) {
    if (!plugin.playing(p) || p.isDead() || plugin.dungeons().down(p)) return;
    Profile data = plugin.profile(p);
    long now = System.currentTimeMillis();
    double maximum = p.getAttribute(Attribute.MAX_HEALTH).getValue();
    if (p.getHealth() >= maximum) {
      plugin.tell(p, "Leben bereits voll – kein Splitter verbraucht.");
      return;
    }
    if (data.healingCharges <= 0) {
      plugin.tell(
          p, "Keine Lebenssplitter. Monster können sie fallen lassen; Dungeon-Siege geben zwei.");
      offer(p);
      return;
    }
    if (now < data.healingReadyAt) {
      plugin.tell(p, "Heilung bereit in " + ((data.healingReadyAt - now + 999) / 1000) + " s.");
      return;
    }
    double restored = Healing.consume(data, p.getHealth(), maximum, now);
    if (restored > 0) data.healsUsed++;
    if (restored == 0 || !plugin.commit(p, data)) return;
    p.setHealth(Math.min(maximum, p.getHealth() + restored));
    plugin.items().refreshHealing(p, data);
    p.getWorld().spawnParticle(Particle.HEART, p.getLocation().add(0, 1.3, 0), 6, .4, .4, .4, 0);
    p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1, 1.5f);
    plugin.tell(
        p,
        String.format(
            Locale.GERMAN, "+%.1f Leben · %d Lebenssplitter übrig", restored, data.healingCharges));
  }

  public void found(Player p, int amount) {
    Profile data = plugin.profile(p);
    int granted = Healing.grant(data, amount);
    if (granted == 0 || !plugin.commit(p, data)) return;
    announce(p, granted);
  }

  public void announce(Player p, int amount) {
    plugin.items().refreshHealing(p, plugin.profile(p));
    p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, .7f, 1.5f);
    plugin.tell(
        p, "BEUTE · +" + amount + " Lebenssplitter. Rechtsklick mit dem Kristall oder /df heal.");
  }

  /** Quick buy from anywhere outside a fight: {@code want} shards, or fewer if space or money run out. */
  public void buy(Player p, int want) {
    if (!plugin.playing(p)) return;
    // 0.9.1: a dungeon run is fought with the shards you brought – no restocking inside.
    if (plugin.dungeons().active(p)) {
      plugin.tell(p, "Im Dungeon kannst du keine Lebenssplitter nachkaufen. Fülle vor dem Start auf!");
      return;
    }
    if (plugin.combat().fighting(p)) {
      plugin.tell(p, "Nachkaufen geht nach dem Kampf (vor dem Dungeon oder danach).");
      return;
    }
    Profile data = plugin.profile(p);
    if (!AdventureSystem.merchantUnlocked(data)) {
      plugin.tell(p, "Schnellkauf ab dem ersten Minenboss oder Dungeon-Sieg (Händlerin).");
      return;
    }
    int unit = Healing.price(data);
    if (data.healingCharges >= Healing.capacity(data)) {
      plugin.tell(
          p,
          "Heilvorrat voll (" + data.healingCharges + "/" + Healing.capacity(data)
              + "). Mehr Platz: Upgrade „Heiltasche“ unter Bergbau → Grund-Upgrades.");
      return;
    }
    if (data.money < unit) {
      plugin.tell(p, "Nicht genug Geld: ein Lebenssplitter kostet " + unit + " $.");
      return;
    }
    int bought = Healing.buy(data, want);
    if (bought == 0 || !plugin.commit(p, data)) return;
    plugin.items().refreshHealing(p, data);
    p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, .7f, 1.3f);
    plugin.tell(
        p,
        "Gekauft: "
            + bought
            + " Lebenssplitter für "
            + bought * unit
            + " $ · Vorrat "
            + data.healingCharges
            + "/" + Healing.capacity(data));
  }

  /** Clickable quick-buy line: one shard or fill up. */
  public void offer(Player p) {
    Profile data = plugin.profile(p);
    if (plugin.dungeons().active(p)
        || !AdventureSystem.merchantUnlocked(data)
        || data.healingCharges >= Healing.capacity(data)) return;
    int unit = Healing.price(data), missing = Healing.capacity(data) - data.healingCharges;
    p.sendMessage(
        Component.text("Schnellkauf » ", NamedTextColor.GOLD)
            .append(chip("[1 kaufen · " + unit + " $]", "/df heal kaufen 1"))
            .append(Component.text(" "))
            .append(chip("[Auffüllen · " + missing * unit + " $]", "/df heal kaufen voll")));
  }

  private static Component chip(String text, String command) {
    return Component.text(text, NamedTextColor.GREEN)
        .clickEvent(ClickEvent.runCommand(command))
        .hoverEvent(HoverEvent.showText(Component.text(command, NamedTextColor.GRAY)));
  }
}
