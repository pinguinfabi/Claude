package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import java.util.Locale;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

public final class HealingItems implements Listener {
  private final DeepforgePlugin plugin;

  public HealingItems(DeepforgePlugin plugin) {
    this.plugin = plugin;
    Bukkit.getPluginManager().registerEvents(this, plugin);
  }

  @EventHandler(priority = EventPriority.LOW)
  public void click(PlayerInteractEvent e) {
    if (e.getHand() != EquipmentSlot.HAND
        || !e.getAction().isRightClick()
        || !plugin.items().kind(e.getItem()).equals("heal")) return;
    e.setCancelled(true);
    use(e.getPlayer());
  }

  public void use(Player p) {
    if (!plugin.playing(p) || p.isDead() || plugin.dungeons().down(p)) return;
    Profile data = plugin.profile(p);
    long now = System.currentTimeMillis();
    double maximum = p.getAttribute(Attribute.MAX_HEALTH).getValue();
    if (p.getHealth() >= maximum) {
      plugin.tell(p, "Leben bereits voll – kein Splitter verbraucht.");
      return;
    }
    if (data.healingCharges <= 0) {
      plugin.tell(
          p, "Keine Lebenssplitter. Monster können sie fallen lassen; Dungeon-Siege geben zwei.");
      return;
    }
    if (now < data.healingReadyAt) {
      plugin.tell(p, "Heilung bereit in " + ((data.healingReadyAt - now + 999) / 1000) + " s.");
      return;
    }
    double restored = Healing.consume(data, p.getHealth(), maximum, now);
    if (restored > 0) data.healsUsed++;
    if (restored == 0 || !plugin.commit(p, data)) return;
    p.setHealth(Math.min(maximum, p.getHealth() + restored));
    plugin.items().refreshHealing(p, data);
    p.getWorld().spawnParticle(Particle.HEART, p.getLocation().add(0, 1.3, 0), 6, .4, .4, .4, 0);
    p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1, 1.5f);
    plugin.tell(
        p,
        String.format(
            Locale.GERMAN, "+%.1f Leben · %d Lebenssplitter übrig", restored, data.healingCharges));
  }

  public void found(Player p, int amount) {
    Profile data = plugin.profile(p);
    int granted = Healing.grant(data, amount);
    if (granted == 0 || !plugin.commit(p, data)) return;
    announce(p, granted);
  }

  public void announce(Player p, int amount) {
    plugin.items().refreshHealing(p, plugin.profile(p));
    p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, .7f, 1.5f);
    plugin.tell(
        p, "BEUTE · +" + amount + " Lebenssplitter. Rechtsklick mit dem Kristall oder /df heal.");
  }
}
