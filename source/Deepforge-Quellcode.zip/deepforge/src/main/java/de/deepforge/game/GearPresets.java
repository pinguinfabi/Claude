package de.deepforge.game;

import java.util.*;

/** Named equipment loadouts ("Dungeon", "Mining", ...) that swap all slots in one click. */
public final class GearPresets {
  public static final int SLOTS = 4;
  public static final String[] DEFAULT_NAMES = {"Dungeon", "Mining", "Boss", "Frei"};

  public static final class Preset {
    public String name;
    public Map<String, String> items = new HashMap<>();
  }

  private GearPresets() {}

  /** Old saves have no presets; broken entries are repaired rather than failing the load. */
  public static List<Preset> of(Profile p) {
    if (p.gearPresets == null) p.gearPresets = new ArrayList<>();
    while (p.gearPresets.size() < SLOTS) p.gearPresets.add(null);
    while (p.gearPresets.size() > SLOTS) p.gearPresets.removeLast();
    for (int i = 0; i < SLOTS; i++) {
      Preset preset = p.gearPresets.get(i);
      if (preset == null) p.gearPresets.set(i, preset = new Preset());
      if (preset.name == null || preset.name.isBlank()) preset.name = DEFAULT_NAMES[i];
      if (preset.items == null) preset.items = new HashMap<>();
    }
    return p.gearPresets;
  }

  private static String parts(int n) {
    return n + (n == 1 ? " Teil" : " Teile");
  }

  public static boolean empty(Profile p, int index) {
    return of(p).get(index).items.isEmpty();
  }

  public static String save(Profile p, int index) {
    if (index < 0 || index >= SLOTS) return "Unbekanntes Set.";
    Preset preset = of(p).get(index);
    if (p.equipped.isEmpty())
      return "Du trägst gerade keine Ausrüstung – erst Teile anlegen, dann speichern.";
    preset.items = new HashMap<>();
    for (Map.Entry<String, String> e : p.equipped.entrySet())
      if (Gear.find(p, e.getValue()) != null) preset.items.put(e.getKey(), e.getValue());
    return "Set „" + preset.name + "“ gespeichert (" + parts(preset.items.size()) + ").";
  }

  /** Puts one piece into the preset slot it belongs to (replacing what was there). */
  public static String setItem(Profile p, int index, String itemId) {
    if (index < 0 || index >= SLOTS) return "Unbekanntes Set.";
    Gear.Item item = Gear.find(p, itemId);
    if (item == null) return "Gegenstand nicht gefunden.";
    Preset preset = of(p).get(index);
    preset.items.put(item.slot.name(), item.id);
    return item.name + " ist jetzt im Set „" + preset.name + "“ (" + Gear.slotName(item.slot) + ").";
  }

  /** Takes one slot out of the preset; the gear itself is not touched. */
  public static String removeItem(Profile p, int index, Gear.Slot slot) {
    if (index < 0 || index >= SLOTS) return "Unbekanntes Set.";
    Preset preset = of(p).get(index);
    if (preset.items.remove(slot.name()) == null)
      return Gear.slotName(slot) + " ist in diesem Set schon leer.";
    return Gear.slotName(slot) + " aus dem Set „" + preset.name + "“ entfernt.";
  }

  /** Empties the preset (keeps its name); the gear itself stays equipped and loses its protection. */
  public static String clear(Profile p, int index) {
    if (index < 0 || index >= SLOTS) return "Unbekanntes Set.";
    Preset preset = of(p).get(index);
    if (preset.items.isEmpty()) return "Set „" + preset.name + "“ ist schon leer.";
    preset.items = new HashMap<>();
    return "Set „" + preset.name + "“ geleert. Deine Ausrüstung bleibt angelegt.";
  }

  /** Puts on every piece of the preset; slots the preset leaves empty are emptied too. */
  public static String apply(Profile p, int index) {
    if (index < 0 || index >= SLOTS) return "Unbekanntes Set.";
    Preset preset = of(p).get(index);
    if (preset.items.isEmpty())
      return "Set „" + preset.name + "“ ist noch leer – erst Ausrüstung anlegen und speichern.";
    Map<String, String> next = new HashMap<>();
    int missing = 0, locked = 0;
    for (Map.Entry<String, String> e : preset.items.entrySet()) {
      Gear.Item item = Gear.find(p, e.getValue());
      if (item == null || !item.slot.name().equals(e.getKey())) missing++;
      else if (item.zone > p.zone) locked++;
      else next.put(e.getKey(), e.getValue());
    }
    p.equipped.clear();
    p.equipped.putAll(next);
    return "Set „"
        + preset.name
        + "“ angelegt ("
        + parts(next.size())
        + ")"
        + (missing > 0 ? " · " + missing + " fehlen (verkauft/zerlegt)" : "")
        + (locked > 0 ? " · " + locked + " Gebiet gesperrt" : "")
        + ".";
  }

  /** Index of the preset matching the current equipment exactly, or -1. */
  public static int active(Profile p) {
    List<Preset> presets = of(p);
    for (int i = 0; i < SLOTS; i++)
      if (!presets.get(i).items.isEmpty() && presets.get(i).items.equals(p.equipped)) return i;
    return -1;
  }

  public static String rename(Profile p, int index, String name) {
    if (index < 0 || index >= SLOTS) return "Unbekanntes Set.";
    String clean = name == null ? "" : name.replaceAll("[^\\p{L}\\p{N} _-]", "").trim();
    if (clean.isEmpty()) return "Bitte einen Namen aus Buchstaben oder Zahlen angeben.";
    if (clean.length() > 16) clean = clean.substring(0, 16);
    of(p).get(index).name = clean;
    return "Set " + (index + 1) + " heißt jetzt „" + clean + "“.";
  }

  /** Name of the first preset containing the item, or null; such items are protected. */
  public static String usedBy(Profile p, String itemId) {
    if (p.gearPresets == null) return null;
    for (Preset preset : p.gearPresets)
      if (preset != null && preset.items != null && preset.items.containsValue(itemId))
        return preset.name;
    return null;
  }

  /** Accepts "1".."4" or a preset name (case-insensitive); -1 when nothing matches. */
  public static int find(Profile p, String key) {
    List<Preset> presets = of(p);
    try {
      int n = Integer.parseInt(key.trim());
      return n >= 1 && n <= SLOTS ? n - 1 : -1;
    } catch (NumberFormatException e) {
      for (int i = 0; i < SLOTS; i++) if (presets.get(i).name.equalsIgnoreCase(key.trim())) return i;
      return -1;
    }
  }
}
