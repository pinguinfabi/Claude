package de.deepforge.ui;

import java.text.NumberFormat;
import java.util.Locale;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;

/** Mining action bar: money, backpack and a coloured heat gauge. */
public final class Hud {
  private static final NamedTextColor SEP = NamedTextColor.DARK_GRAY;

  private Hud() {}

  public static String money(long amount) {
    return NumberFormat.getIntegerInstance(Locale.GERMANY).format(amount) + " $";
  }

  /** Ten segments; each is lit once the heat passes its share of 100. */
  public static String gauge(double heat) {
    int lit = (int) Math.round(Math.max(0, Math.min(100, heat)) / 10);
    return "▮".repeat(lit) + "▯".repeat(10 - lit);
  }

  public static TextColor heatColor(double heat) {
    return heat >= 85 ? NamedTextColor.RED : heat >= 60 ? NamedTextColor.GOLD : NamedTextColor.GREEN;
  }

  public static Component mining(long money, long bagUsed, long bagCapacity, double heat) {
    boolean full = bagUsed >= bagCapacity;
    return Component.text(money(money), NamedTextColor.GOLD)
        .append(Component.text("  ·  ", SEP))
        .append(Component.text("Rucksack ", NamedTextColor.GRAY))
        .append(
            Component.text(
                bagUsed + "/" + bagCapacity + (full ? " VOLL" : ""),
                full ? NamedTextColor.RED : NamedTextColor.WHITE))
        .append(Component.text("  ·  ", SEP))
        .append(Component.text("Hitze ", NamedTextColor.GRAY))
        .append(Component.text(gauge(heat), heatColor(heat)))
        .append(Component.text(" " + (int) heat + " %", heatColor(heat)));
  }
}
