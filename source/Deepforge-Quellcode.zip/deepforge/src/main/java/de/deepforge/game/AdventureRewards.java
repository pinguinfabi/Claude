package de.deepforge.game;

import java.util.*;

/**
 * Flags belong to the run, and are awarded inside the existing once-only completion transaction.
 */
public final class AdventureRewards {
  private AdventureRewards() {}

  public static final int ELITE = 1, CURSE = 2, RESCUE = 4, TREASURE = 8;

  public static void apply(Profile p, UUID receipt, int zone, int level, int flags) {
    if (flags < 0 || flags > 15 || (flags & 3) == 3)
      throw new IllegalArgumentException("Invalid optional objectives");
    Random r = new Random(receipt.getMostSignificantBits() ^ p.id.hashCode() ^ 0x6a39);
    AdventureGear.grant(p, rank(AdventureGear.drop(zone, r, .04), level));
    int count = Integer.bitCount(flags) + ((flags & CURSE) != 0 ? 1 : 0);
    for (int n = 0; n < count; n++)
      AdventureGear.grant(p, rank(AdventureGear.drop(zone, r, .20), level));
    long money = Math.round((250L + zone * 100L) * count * Zone.deepFactor(zone));
    p.money = Math.addExact(p.money, money);
    p.lifetimeRevenue = Math.addExact(p.lifetimeRevenue, money);
    p.dust += count * 8L;
    p.researchNotes += count * 2L;
    if ((flags & 3) != 0) p.adventureChallenges++;
    if ((flags & RESCUE) != 0) p.adventureRescues++;
    if ((flags & TREASURE) != 0) p.adventureTreasures++;
    p.bossTokens[zone] += 2;
  }

  private static Gear.Item rank(Gear.Item item, int level) {
    item.dungeonRank = level;
    double growth = 1 + .075 * (level - 1);
    item.damage *= growth;
    item.health *= growth;
    item.defense *= growth;
    item.name = "Gewölbe L" + level + ": " + item.name;
    return item;
  }
}
