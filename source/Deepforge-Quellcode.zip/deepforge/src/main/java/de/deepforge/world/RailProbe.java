package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import java.util.*;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.*;
import org.bukkit.scheduler.BukkitTask;

/** Temporary enclosed test lanes, fully restored after actual native mob movement. */
final class RailProbe implements AutoCloseable {
  private final Map<Block, BlockData> saved = new LinkedHashMap<>();
  private final List<Mob> mobs = new ArrayList<>();
  private final List<Location> goals = new ArrayList<>();
  private final Set<Chunk> tickets = new HashSet<>();
  private final Set<Chunk> forced = new HashSet<>();
  private final DeepforgePlugin plugin;
  private BukkitTask task;
  private int ticks;
  private int recoilTick;
  private final List<Location> recoilStarts = new ArrayList<>();
  private int railTicks;
  private String result = "RUNNING";

  RailProbe(DeepforgePlugin plugin) {
    this.plugin = plugin;
    World world = plugin.mines().world();
    Location origin = world.getSpawnLocation().clone().add(32, 40, 0);
    try {
      for (int lane = 0; lane < 3; lane++) {
        int ox = origin.getBlockX() + lane * 7, y = origin.getBlockY(), oz = origin.getBlockZ();
        for (int cx = (ox - 2) >> 4; cx <= (ox + 2) >> 4; cx++)
          for (int cz = (oz - 1) >> 4; cz <= (oz + 10) >> 4; cz++) {
            Chunk chunk = world.getChunkAt(cx, cz);
            if (!chunk.isForceLoaded()) {
              chunk.setForceLoaded(true);
              forced.add(chunk);
            }
            if (chunk.addPluginChunkTicket(plugin)) tickets.add(chunk);
          }
        for (int x = -2; x <= 2; x++)
          for (int z = -1; z <= 10; z++)
            for (int h = -1; h <= 4; h++) {
              Block block = world.getBlockAt(ox + x, y + h, oz + z);
              saved.put(block, block.getBlockData());
              block.setType(
                  h == -1 || h == 4 || Math.abs(x) == 2 || z == -1 || z == 10
                      ? Material.STONE
                      : Material.AIR,
                  false);
            }
        for (int z : new int[] {2, 4, 6})
          for (int x = -1; x <= 1; x++)
            world
                .getBlockAt(ox + x, y, oz + z)
                .setBlockData(
                    Bukkit.createBlockData("minecraft:rail[shape=east_west,waterlogged=false]"),
                    false);
        double scale = new double[] {.7, 1, 1.65}[lane];
        Husk mob =
            world.spawn(
                new Location(world, ox + .5, y, oz + .5),
                Husk.class,
                e -> {
                  e.setAdult();
                  e.setSilent(true);
                  e.setInvulnerable(true);
                  e.setPersistent(false);
                  e.setRemoveWhenFarAway(false);
                  e.setShouldBurnInDay(false);
                  e.getAttribute(Attribute.SCALE).setBaseValue(scale);
                  e.getAttribute(Attribute.MOVEMENT_SPEED).setBaseValue(.3);
                });
        mobs.add(mob);
        try {
          // Diagnostics run without nearby players; otherwise Paper deactivates test mobs.
          Object handle = mob.getClass().getMethod("getHandle").invoke(mob);
          handle.getClass().getField("activatedTick").setLong(handle, Long.MAX_VALUE);
        } catch (ReflectiveOperationException ex) {
          throw new IllegalStateException("Cannot activate rail probe", ex);
        }
        Bukkit.getMobGoals().removeAllGoals(mob);
        RailNavigation.allowRails(mob);
        Location goal = new Location(world, ox + .5, y, oz + 8.5);
        goals.add(goal);
      }
      task =
          Bukkit.getScheduler()
              .runTaskTimer(
                  plugin,
                  () -> {
                    try {
                      ticks++;
                      if (recoilTick > 0) {
                        if (ticks - recoilTick < 8) return;
                        for (int i = 0; i < mobs.size(); i++) {
                          double moved =
                              recoilStarts.get(i).getZ() - mobs.get(i).getLocation().getZ();
                          if (moved < .5)
                            throw new IllegalStateException(
                                "Native recoil too small for lane " + i + ": " + moved);
                        }
                        Mob boss = mobs.get(2);
                        boss.setAI(false);
                        boss.setVelocity(new org.bukkit.util.Vector());
                        Location before = boss.getLocation();
                        if (!KnockbackMotion.push(boss, new org.bukkit.util.Vector(0, 0, -.45))
                            || before.distance(boss.getLocation()) < .4)
                          throw new IllegalStateException("Boss recoil did not move");
                        KnockbackMotion.push(boss, new org.bukkit.util.Vector(0, 0, -20));
                        if (boss.getBoundingBox().getMinZ() < origin.getBlockZ() - .001)
                          throw new IllegalStateException("Boss recoil crossed wall");
                        result =
                            "RAILS OK: 3/3 mobs physically crossed 3 rail strips; ticks="
                                + railTicks
                                + "; RECOIL OK: 3/3 native impulses, boss impulse and wall"
                                + " collision";
                        close();
                        return;
                      }
                      int crossed = 0;
                      for (int i = 0; i < mobs.size(); i++) {
                        if (mobs.get(i).getLocation().distanceSquared(goals.get(i)) < 1.5)
                          crossed++;
                        else if (ticks % 10 == 0
                            && mobs.get(i).isTicking()
                            && mobs.get(i).isOnGround()) {
                          // Newly spawned mobs need a physics tick before native pathfinding
                          // accepts a ground path.
                          var path = mobs.get(i).getPathfinder().findPath(goals.get(i));
                          if (path != null) mobs.get(i).getPathfinder().moveTo(path, 1.1);
                        }
                      }
                      if (crossed == 3) {
                        railTicks = ticks;
                        recoilTick = ticks;
                        for (Mob mob : mobs) {
                          recoilStarts.add(mob.getLocation());
                          mob.getPathfinder().stopPathfinding();
                          mob.setAware(false);
                          mob.setVelocity(new org.bukkit.util.Vector(0, .17, -.40));
                        }
                      } else if (ticks >= 600) {
                        result =
                            "RAILS FAILED: only "
                                + crossed
                                + "/3 mobs crossed; "
                                + mobs.stream()
                                    .map(
                                        m ->
                                            "ground="
                                                + m.isOnGround()
                                                + ",ticking="
                                                + m.isTicking()
                                                + ",position="
                                                + m.getLocation())
                                    .toList();
                        close();
                      }
                    } catch (RuntimeException ex) {
                      result = "RAILS FAILED: " + ex.getMessage();
                      close();
                    }
                  },
                  1,
                  1);
    } catch (RuntimeException ex) {
      result = "RAILS FAILED: " + ex.getMessage();
      close();
      throw ex;
    }
  }

  String result() {
    return result;
  }

  @Override
  public void close() {
    if (task != null) task.cancel();
    mobs.forEach(Entity::remove);
    mobs.clear();
    // Restore floor/walls before non-solid decorations.
    saved.forEach((block, data) -> block.setBlockData(data, false));
    saved.clear();
    tickets.forEach(chunk -> chunk.removePluginChunkTicket(plugin));
    tickets.clear();
    forced.forEach(chunk -> chunk.setForceLoaded(false));
    forced.clear();
  }
}
