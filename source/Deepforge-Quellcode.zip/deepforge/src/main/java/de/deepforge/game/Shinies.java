package de.deepforge.game;

import java.util.*;
import java.util.random.RandomGenerator;

/**
 * Glänzende Monster (0.15.0): very rarely a mine monster sparkles in gold. It has double life and
 * flees after 30 seconds – but whoever catches it gets a sure item, lots of money and Glanzsplitter
 * to polish gear. Every kind in every mine counts for the Glanzbuch (51 entries).
 */
public final class Shinies {
  private Shinies() {}

  public static final double CHANCE = 1 / 500.0, HEALTH = 2;
  /** Combat ticks (server ticks) before a shiny escapes: 30 s. */
  public static final int FLEE_TICKS = 600;
  public static final int POLISH_COST = 5;
  public static final double POLISH = 1.10;
  public static final String[] KINDS = {"Erzkrabbler", "Panzerwächter", "Spaltenwerfer"};

  public static int dexSize() {
    return Zone.COUNT * KINDS.length;
  }

  public static String id(int zone, int kind) {
    return zone + ":" + kind;
  }

  public static int dex(Profile p) {
    return p.shinyDex == null ? 0 : p.shinyDex.size();
  }

  public static boolean caught(Profile p, int zone, int kind) {
    return p.shinyDex != null && p.shinyDex.contains(id(zone, kind));
  }

  /** Glanzbuch milestones raise the chance: 10 kinds ×1,5 · 25 ×2 · all 51 ×3. */
  public static double multiplier(Profile p) {
    int n = dex(p);
    return n >= dexSize() ? 3 : n >= 25 ? 2 : n >= 10 ? 1.5 : 1;
  }

  public static double chance(Profile p) {
    return CHANCE * multiplier(p);
  }

  public static String name(int kind) {
    return "✧ Glänzender " + KINDS[Math.floorMod(kind, KINDS.length)];
  }

  public record Loot(Gear.Item item, long cash, int shards, boolean firstOfKind, List<String> lines) {}

  public static Loot reward(Profile p, int zone, int kind, RandomGenerator r) {
    if (p.shinyDex == null) p.shinyDex = new HashSet<>();
    boolean first = p.shinyDex.add(id(zone, kind));
    p.shinyKills++;
    int shards = first ? 3 : 1;
    p.glanz += shards;
    long cash = Zone.at(zone).orePrice * 60L;
    p.money += cash;
    p.lifetimeRevenue += cash;
    double roll = r.nextDouble();
    Gear.Rarity rarity =
        roll < .05 ? Gear.Rarity.LEGENDARY : roll < .30 ? Gear.Rarity.EPIC : Gear.Rarity.RARE;
    Gear.Item item = Gear.roll(zone, rarity, r);
    item.name = "Glanz-" + item.name;
    p.discovered.add(item.slot.name() + "/" + item.rarity.name());
    List<String> lines = new ArrayList<>();
    if (p.gear.size() < 120) {
      p.gear.add(item);
      lines.add(RewardDiff.item(item));
    } else {
      p.dust += 40L * (rarity.ordinal() + 1);
      lines.add("Beutel voll – Schmiedestaub statt Gegenstand");
    }
    Alchemy.gain(p, Alchemy.Ingredient.ESSENZ, 3);
    lines.add("+" + String.format(Locale.GERMAN, "%,d", cash) + " $");
    lines.add("+" + shards + " Glanzsplitter" + (first ? " (neu im Glanzbuch!)" : ""));
    lines.add("+3 Schattenessenz");
    return new Loot(item, cash, shards, first, lines);
  }

  /** Glanzveredelung: once per item, +10 % damage, health and defense for 5 Glanzsplitter. */
  public static String polish(Profile p, String itemId) {
    Gear.Item i = Gear.find(p, itemId);
    if (i == null) return "Gegenstand nicht gefunden.";
    if (i.polished) return i.name + " glänzt schon.";
    if (p.glanz < POLISH_COST)
      return "Benötigt " + POLISH_COST + " Glanzsplitter (du hast " + p.glanz + "). Glänzende Monster jagen!";
    p.glanz -= POLISH_COST;
    i.polished = true;
    i.damage *= POLISH;
    i.health *= POLISH;
    i.defense *= POLISH;
    i.name = "✧ " + i.name;
    return i.name + " veredelt: +10 % Schaden, Leben und Rüstung.";
  }
}
