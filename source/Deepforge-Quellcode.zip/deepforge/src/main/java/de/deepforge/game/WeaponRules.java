package de.deepforge.game;

/** Attacker position relative to the target's facing, independent of Bukkit entities. */
public final class WeaponRules {
  public static double facing(double dx, double dz, double fx, double fz) {
    double length = Math.hypot(dx, dz) * Math.hypot(fx, fz);
    return length < .001 ? 0 : (dx * fx + dz * fz) / length;
  }

  public static double multiplier(String weapon, boolean armored, boolean exposed, double facing) {
    double factor = weapon.equals("dagger") && facing <= -.5 ? 1.65 : 1;
    return factor * (armored && !exposed && facing >= .3 ? .45 : 1);
  }

  private WeaponRules() {}
}
