package de.deepforge.game;

/** Attacker position relative to the target's facing, independent of Bukkit entities. */
public final class WeaponRules {
  public static double facing(double dx, double dz, double fx, double fz) {
    double length = Math.hypot(dx, dz) * Math.hypot(fx, fz);
    return length < .001 ? 0 : (dx * fx + dz * fz) / length;
  }

  /** Dagger rear bonus grows with rarity, so a starter dagger is not a late-game weapon. */
  public static double rearBonus(Gear.Item weapon) {
    if (weapon == null) return 0;
    return switch (weapon.rarity) {
      case UNCOMMON -> .20;
      case RARE -> .35;
      case EPIC -> .50;
      case LEGENDARY -> .65;
      case MYTHIC -> .75;
    };
  }

  public static double multiplier(
      String weapon, double rearBonus, boolean armored, boolean exposed, double facing) {
    double factor = weapon.equals("dagger") && facing <= -.5 ? 1 + rearBonus : 1;
    return factor * (armored && !exposed && facing >= .3 ? .45 : 1);
  }

  private WeaponRules() {}
}
