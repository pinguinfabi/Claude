package de.deepforge;

import de.deepforge.game.*;
import de.deepforge.storage.Profiles;
import de.deepforge.ui.*;
import de.deepforge.world.*;
import java.net.URI;
import java.util.*;
import java.util.function.Function;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.plugin.java.JavaPlugin;

public final class DeepforgePlugin extends JavaPlugin
    implements Listener, CommandExecutor, TabCompleter {
  private Profiles profiles;
  private MineWorld mines;
  private Items items;
  private Menus menus;
  private Gameplay gameplay;
  private CombatEngine combat;
  private Workers workers;
  private Expeditions expeditions;
  private Dungeons dungeons;
  private de.deepforge.ui.AdminMenu admin;
  private HealingItems healing;
  private WorldEvents events;
  private AdventureSystem adventure;
  private ForestryWorld forestry;
  private ServerBoards boards;
  private final Set<UUID> autoEntryPending = new HashSet<>();
  private final Set<UUID> sessions = new HashSet<>(), packLoaded = new HashSet<>();
  // Players whose client loaded the exact pack bundled with this plugin (sent by the server).
  private final Set<UUID> packVerified = new HashSet<>(), sentCurrentPack = new HashSet<>();
  private PackHost packHost;
  private Drones drones;
  private final Map<UUID, Production.Report> reports = new HashMap<>();
  private final Map<UUID, Integer> shownPlot = new HashMap<>();
  private final Map<UUID, Long> shownMilestones = new HashMap<>();
  private boolean shuttingDown;

  @Override
  public void onEnable() {
    saveDefaultConfig();
    packHost = new PackHost(this);
    if (getConfig().getBoolean("resource-pack.self-host.enabled", false))
      packHost.start(getConfig().getInt("resource-pack.self-host.port", 8765));
    if (!Bukkit.getMinecraftVersion().equals("1.21.8")) {
      getLogger().severe("This release targets Paper 1.21.8. Refusing unsupported server version.");
      Bukkit.getPluginManager().disablePlugin(this);
      return;
    }
    try {
      profiles = new Profiles(getDataFolder().toPath().resolve("profiles.db"));
      items = new Items(this);
      mines = new MineWorld(this);
      mines.init();
      for (Profile saved : profiles.saved())
        if (mines.needsMigration(saved)) mines.ensure(saved, () -> {});
      menus = new Menus(this);
      combat = new CombatEngine(this);
      gameplay = new Gameplay(this);
      expeditions = new Expeditions(this);
      dungeons = new Dungeons(this);
      admin = new de.deepforge.ui.AdminMenu(this);
      healing = new HealingItems(this);
      events = new WorldEvents(this);
      adventure = new AdventureSystem(this);
      forestry = new ForestryWorld(this);
      boards = new ServerBoards(this);
      Bukkit.getPluginManager().registerEvents(new de.deepforge.ui.ChatFormat(this, boards), this);
      drones = new Drones(this);
      for (Profile saved : profiles.saved())
        if (!mines.needsMigration(saved)) forestry.ensure(saved);
      Bukkit.getPluginManager().registerEvents(this, this);
      Bukkit.getPluginManager().registerEvents(menus, this);
      Bukkit.getPluginManager().registerEvents(gameplay, this);
      Objects.requireNonNull(getCommand("deepforge")).setExecutor(this);
      getCommand("deepforge").setTabCompleter(this);
      if (Bukkit.getPluginManager().isPluginEnabled("Citizens"))
        try {
          workers = new Workers(this);
        } catch (LinkageError | RuntimeException e) {
          getLogger().warning("Citizens integration disabled: " + e);
        }
      if (workers == null)
        getLogger()
            .warning(
                "Citizens with 1.21.8 support is missing. Worker hiring is disabled; other systems"
                    + " remain available.");
      Bukkit.getScheduler()
          .runTaskTimer(
              this,
              () -> {
                for (UUID id : new ArrayList<>(sessions)) {
                  Player p = Bukkit.getPlayer(id);
                  if (p == null) continue;
                  Profile data = profile(p);
                  Production.settle(data, System.currentTimeMillis());
                  if (!commit(p, data)) return;
                }
              },
              1200,
              1200);
      Bukkit.getScheduler().runTaskTimer(this, this::hud, 20, 5);
      Bukkit.getScheduler().runTaskTimer(this, this::updatePresentation, 20, 20);
      Bukkit.getScheduler().runTask(this, () -> Bukkit.getOnlinePlayers().forEach(this::login));
      getLogger()
          .info(
              "Deepforge "
                  + getPluginMeta().getVersion()
                  + (mines.shared()
                      ? " ready. Shared camp and mines; monsters and bosses stay personal."
                      : " ready. /df start creates a personal mine."));
    } catch (Exception e) {
      getLogger().log(java.util.logging.Level.SEVERE, "Deepforge initialization failed", e);
      Bukkit.getPluginManager().disablePlugin(this);
    }
  }

  @Override
  public void onDisable() {
    shuttingDown = true;
    if (packHost != null) packHost.close();
    if (boards != null) boards.close();
    if (events != null) events.shutdown();
    autoEntryPending.clear();
    if (admin != null) admin.close();
    if (dungeons != null) dungeons.close();
    if (adventure != null) adventure.close();
    if (forestry != null) forestry.close();
    if (drones != null) drones.close();
    if (combat != null) combat.close();
    if (gameplay != null) gameplay.close();
    if (items != null)
      for (Player online : Bukkit.getOnlinePlayers()) items.resetMiningSpeed(online);
    if (workers != null) workers.close();
    if (expeditions != null) expeditions.close();
    if (profiles != null) {
      for (UUID id : new ArrayList<>(sessions)) {
        Player player = Bukkit.getPlayer(id);
        if (player != null)
          try {
            Profile p = profile(player);
            Production.settle(p, System.currentTimeMillis());
            profiles.save(p);
          } catch (Exception ex) {
            getLogger().severe("Final save failed for " + id + ": " + ex);
          }
      }
      try {
        profiles.close();
      } catch (Exception ex) {
        getLogger().severe("Database close failed: " + ex);
      }
    }
    sessions.clear();
  }

  public MineWorld mines() {
    return mines;
  }

  public Drones drones() {
    return drones;
  }

  public Gameplay gameplay() {
    return gameplay;
  }

  public CombatEngine combat() {
    return combat;
  }

  public de.deepforge.ui.AdminMenu admin() {
    return admin;
  }

  public Dungeons dungeons() {
    return dungeons;
  }

  public void rewardDungeon(List<UUID> ids, UUID run, int zone, int mode, long ticks, int level) {
    rewardDungeon(ids, run, zone, mode, ticks, level, 0);
  }

  private final Map<UUID, RewardDiff> lastRewards = new HashMap<>();

  public Map<String, RewardDiff> rewardDungeon(
      List<UUID> ids, UUID run, int zone, int mode, long ticks, int level, int flags) {
    return rewardDungeon(
        ids, run, zone, mode, ticks, level, flags, de.deepforge.game.DungeonVariant.GEWOELBE);
  }

  public Map<String, RewardDiff> rewardDungeon(
      List<UUID> ids,
      UUID run,
      int zone,
      int mode,
      long ticks,
      int level,
      int flags,
      de.deepforge.game.DungeonVariant variant) {
    Map<String, RewardDiff> gains =
        profiles.rewardDungeon(ids, run, zone, mode, ticks, level, flags, variant);
    gains.forEach((id, diff) -> lastRewards.put(UUID.fromString(id), diff));
    return gains;
  }

  /** What the player got from their last dungeon, for the reward window. */
  public RewardDiff lastReward(Player p) {
    return lastRewards.get(p.getUniqueId());
  }

  public WorldEvents events() {
    return events;
  }

  /**
   * Tiefenpass XP for something the player did; doubled during Tiefenfieber. Announces new tiers.
   * The caller commits the profile as part of its own change.
   */
  public void passXp(Player player, long xp) {
    if (player == null || !playing(player) || xp <= 0) return;
    Profile p = profile(player);
    if (events != null && events.active(WorldEvents.Kind.TIEFENFIEBER)) xp *= 2;
    int gained = DeepPass.add(p, xp, today());
    if (gained <= 0) return;
    int tier = DeepPass.tier(p);
    player.showTitle(
        net.kyori.adventure.title.Title.title(
            Component.text(
                tier >= DeepPass.TIERS && DeepPass.bonusEarned(p) > 0
                    ? "TIEFENPASS BONUS"
                    : "TIEFENPASS STUFE " + tier,
                NamedTextColor.GOLD),
            Component.text(
                tier >= 1 ? "Belohnung: " + DeepPass.describe(p, Math.min(tier, DeepPass.TIERS)) : "",
                NamedTextColor.YELLOW)));
    player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, .6f, 1.2f);
    player.sendMessage(
        Component.text("Deepforge » ", NamedTextColor.GOLD)
            .append(Component.text("Neue Tiefenpass-Stufe! ", NamedTextColor.YELLOW))
            .append(
                Component.text("[Belohnung abholen]", NamedTextColor.GREEN)
                    .clickEvent(net.kyori.adventure.text.event.ClickEvent.runCommand("/df pass"))
                    .hoverEvent(
                        net.kyori.adventure.text.event.HoverEvent.showText(
                            Component.text("Öffnet den Tiefenpass", NamedTextColor.GRAY)))));
  }

  public HealingItems healing() {
    return healing;
  }

  public AdventureSystem adventure() {
    return adventure;
  }

  public ForestryWorld forestry() {
    return forestry;
  }

  public Items items() {
    return items;
  }

  public Menus menus() {
    return menus;
  }

  public boolean inWorld(Player p) {
    return mines != null && mines.contains(p.getLocation());
  }

  public boolean playing(Player p) {
    return sessions.contains(p.getUniqueId()) && inWorld(p) && mines.isReady(profile(p));
  }

  public boolean workersAvailable() {
    return workers != null;
  }

  public String workerStatus(Player player, int index) {
    return workers == null ? "Citizens fehlt" : workers.status(player.getUniqueId(), index);
  }

  public boolean packApplied(Player p) {
    return packLoaded.contains(p.getUniqueId());
  }

  public Profile profile(Player p) {
    return profiles.get(
        p.getUniqueId(), p.getName(), getConfig().getLong("game.starter-money", 250));
  }

  /**
   * Shared world: everyone uses one camp and mine. Otherwise party members share the plot the party
   * was founded on.
   */
  public int plot(Profile p) {
    if (mines != null && mines.shared()) return getConfig().getInt("game.shared-plot", 0);
    if (dungeons == null || p.id == null) return p.plot;
    PartyBook.Party party;
    try {
      party = dungeons.parties().get(UUID.fromString(p.id));
    } catch (IllegalArgumentException e) {
      return p.plot;
    }
    if (party == null) return p.plot;
    if (party.plot < 0) {
      Player leader = Bukkit.getPlayer(party.leader);
      if (leader == null) return p.plot;
      party.plot = profile(leader).plot;
    }
    return party.plot;
  }

  public java.time.LocalDate today() {
    String zone = getConfig().getString("game.timezone", "Europe/Berlin");
    try {
      return java.time.LocalDate.now(java.time.ZoneId.of(zone));
    } catch (java.time.DateTimeException e) {
      return java.time.LocalDate.now();
    }
  }

  private List<Profile> ranking = List.of();
  private long rankingAt;

  /** Saved profiles for the leaderboard, read at most every 30 seconds. */
  public List<Profile> rankingProfiles() {
    long now = System.currentTimeMillis();
    if (now - rankingAt > 30_000) {
      try {
        ranking = profiles.saved();
      } catch (RuntimeException e) {
        getLogger().warning("Leaderboard unavailable: " + e.getMessage());
      }
      rankingAt = now;
    }
    return ranking;
  }

  private final Map<UUID, Integer> shownDailies = new HashMap<>();

  private void announceDailies() {
    shownDailies.keySet().retainAll(sessions);
    java.time.LocalDate today = today();
    for (UUID id : new ArrayList<>(sessions)) {
      Player player = Bukkit.getPlayer(id);
      if (player == null || !playing(player)) continue;
      Profile p = profile(player);
      if (Dailies.ensure(p, today) && commit(player, p))
        tell(player, "Neue Tagesaufträge sind da! /df daily");
      int ready = Dailies.readyCount(p);
      Integer before = shownDailies.put(id, ready);
      if (before != null && ready > before) {
        notice(player, "✔ Tagesauftrag erfüllt! /df daily", NamedTextColor.GREEN);
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, .6f, 1.5f);
      }
    }
  }

  private void announceMilestones() {
    shownMilestones.keySet().retainAll(sessions);
    for (UUID id : new ArrayList<>(sessions)) {
      Player player = Bukkit.getPlayer(id);
      if (player == null || !playing(player)) continue;
      long ready = Milestones.claimableCount(profile(player));
      Long before = shownMilestones.put(id, ready);
      if (before != null && ready > before) {
        tell(player, "Meilenstein erreicht! Belohnung abholen: /df milestones");
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, .6f, 1.2f);
      }
    }
  }

  private void syncPartyPlots() {
    shownPlot.keySet().retainAll(sessions);
    for (UUID id : new ArrayList<>(sessions)) {
      Player player = Bukkit.getPlayer(id);
      if (player == null || !inWorld(player)) continue;
      Profile p = profile(player);
      int now = plot(p);
      Integer before = shownPlot.put(id, now);
      if (before == null || before == now || dungeons.active(player)) continue;
      mines.ensure(
          p,
          () -> {
            if (!player.isOnline() || plot(p) != now) return;
            goHome(player);
            refreshWorkers(player);
            tell(
                player,
                now == p.plot
                    ? "Du bist zurück in deinem eigenen Lager."
                    : "Party: Spawn und Minen werden jetzt mit deiner Party geteilt.");
          });
    }
  }

  private final Map<UUID, Map.Entry<Component, Long>> notices = new HashMap<>();

  /** Short action-bar hint that the HUD keeps visible for a moment instead of overwriting it. */
  public void notice(Player p, String text, NamedTextColor color) {
    Component c = Component.text(text, color).font(Key.key("minecraft", "default"));
    notices.put(p.getUniqueId(), Map.entry(c, System.currentTimeMillis() + 2500));
    p.sendActionBar(c);
  }

  /** Player-facing sentences pass through; parser and internal messages get a fallback. */
  public static String readable(IllegalArgumentException ex, String fallback) {
    if (ex instanceof NumberFormatException) return "Bitte eine ganze Zahl angeben.";
    String m = ex.getMessage();
    return m != null && m.contains(" ") && (m.endsWith(".") || m.endsWith("!")) ? m : fallback;
  }

  /** Shows HUD glyphs next to plain text; players pick the HUD that renders correctly. */
  private void hudTest(Player player) {
    player.sendMessage(
        Component.text("HUD-Test: ", NamedTextColor.GOLD)
            .append(HudFont.icon(HudFont.Icon.COIN))
            .append(HudFont.icon(HudFont.Icon.HEART))
            .append(HudFont.icon(HudFont.Icon.STAR))
            .append(Component.text(" ← Münze, Herz und Stern zu sehen?", NamedTextColor.GRAY)));
    player.sendMessage(
        Component.text("  [Ja → Spiel-HUD]", NamedTextColor.GREEN)
            .clickEvent(net.kyori.adventure.text.event.ClickEvent.runCommand("/df hud spiel"))
            .append(Component.text("   "))
            .append(
                Component.text("[Nur Kästchen → Text-HUD]", NamedTextColor.RED)
                    .clickEvent(
                        net.kyori.adventure.text.event.ClickEvent.runCommand("/df hud text"))));
  }

  public void tell(Player p, String text) {
    p.sendMessage(
        Component.text("Deepforge » ", NamedTextColor.GOLD)
            .append(Component.text(text, NamedTextColor.GRAY)));
  }

  public boolean commit(Player player, Profile p) {
    try {
      int lessons = Tutorial.advance(p);
      profiles.save(p);
      if (lessons > 0)
        tell(player, "Lernziel erfüllt! Prämie erhalten. Nächstes Ziel: " + Tutorial.title(p));
      return true;
    } catch (RuntimeException e) {
      getLogger().log(java.util.logging.Level.SEVERE, "State commit failed", e);
      tell(player, "Speicherfehler. Das Spiel wurde angehalten, um deinen Stand zu schützen.");
      Bukkit.getPluginManager().disablePlugin(this);
      return false;
    }
  }

  /** Applies a profile action and returns its message (null when nothing ran). */
  public String change(Player player, Function<Profile, String> action) {
    if (!playing(player)) return null;
    Profile p = profile(player);
    Production.settle(p, System.currentTimeMillis());
    String message = action.apply(p);
    if (!commit(player, p)) return null;
    tell(player, message);
    return message;
  }

  private void presetCommand(Player player, String[] args) {
    if (args.length < 2) {
      menus.open(player, "presets");
      return;
    }
    if (combat.fighting(player)) {
      tell(player, "Sets wechseln geht nach dem Kampf.");
      return;
    }
    String op = args[1].toLowerCase(Locale.ROOT);
    Profile profile = profile(player);
    boolean indexed = Set.of("speichern", "save", "name", "leeren", "clear").contains(op);
    if (indexed && args.length < 3) {
      tell(player, "Nutzung: /df sets speichern|leeren <1-4> · /df sets name <1-4> <Name>");
      return;
    }
    int index =
        GearPresets.find(
            profile,
            indexed ? args[2] : String.join(" ", Arrays.copyOfRange(args, 1, args.length)));
    if (index < 0) {
      tell(player, "Set nicht gefunden. /df sets öffnet die Übersicht.");
      return;
    }
    change(
        player,
        p ->
            switch (op) {
              case "speichern", "save" -> GearPresets.save(p, index);
              case "leeren", "clear" -> GearPresets.clear(p, index);
              case "name" ->
                  GearPresets.rename(
                      p, index, args.length < 4 ? "" : String.join(" ", Arrays.copyOfRange(args, 3, args.length)));
              default -> GearPresets.apply(p, index);
            });
    items.refresh(player, profile(player));
    combat.applyStats(player);
  }

  public void refreshWorkers(Player p) {
    if (workers != null) workers.spawn(p);
  }

  private void login(Player player) {
    if (!isEnabled()) return;
    try {
      Profile p = profile(player);
      Production.Report r = Production.settle(p, System.currentTimeMillis());
      if (!commit(player, p)) return;
      reports.put(player.getUniqueId(), r);
      JoinFlow.Route route =
          JoinFlow.route(
              player.hasPermission("deepforge.play"),
              sessions.contains(player.getUniqueId()),
              p.enrolled,
              inWorld(player),
              getConfig().getBoolean("game.auto-join", true));
      if (route == JoinFlow.Route.START) {
        start(player, true);
      } else if (route == JoinFlow.Route.RESUME) {
        sessions.add(player.getUniqueId());
        if (!mines.isReady(p)) player.teleport(mines.world().getSpawnLocation().add(.5, 0, .5));
        mines.ensure(
            p,
            () -> {
              if (player.isOnline() && sessions.contains(player.getUniqueId())) {
                items.refresh(player, p);
                if (dungeons.active(player)) dungeons.resume(player);
                else goHome(player);
                refreshWorkers(player);
                report(player);
                sendPack(player);
              }
            });
      }
    } catch (RuntimeException ex) {
      getLogger().log(java.util.logging.Level.SEVERE, "Profile load failed", ex);
      tell(player, "Spielerstand konnte nicht geladen werden. Bitte Administrator kontaktieren.");
    }
  }

  @EventHandler
  public void join(PlayerJoinEvent e) {
    // Left in spectator mode by a crash or restart while watching a dungeon or moderating.
    if (de.deepforge.world.SpectatorState.restore(e.getPlayer()))
      getLogger().info(e.getPlayer().getName() + ": Zuschauer-/Adminmodus nach Neustart beendet.");
    Bukkit.getScheduler()
        .runTaskLater(
            this,
            () -> {
              if (e.getPlayer().isOnline()) login(e.getPlayer());
            },
            20);
  }

  @EventHandler
  public void quit(PlayerQuitEvent e) {
    Player player = e.getPlayer();
    autoEntryPending.remove(player.getUniqueId());
    if (menus != null) menus.forget(player.getUniqueId());
    notices.remove(player.getUniqueId());
    if (boards != null) {
      boards.remove(player);
      boards.forget(player.getUniqueId());
    }
    if (admin != null) admin.leaveMode(player);
    dungeons.disconnect(player);
    if (adventure != null) adventure.clear(player.getUniqueId());
    if (mines != null) mines.clearPersonal(player.getUniqueId());
    expeditions.clear(player.getUniqueId());
    if (sessions.remove(player.getUniqueId())) {
      Profile p = profile(player);
      Production.settle(p, System.currentTimeMillis());
      commit(player, p);
      gameplay.clear(player);
      if (workers != null) workers.remove(player.getUniqueId());
    }
    packLoaded.remove(player.getUniqueId());
    reports.remove(player.getUniqueId());
    profiles.evict(player.getUniqueId());
  }

  @EventHandler
  public void resourcePack(PlayerResourcePackStatusEvent e) {
    UUID id = e.getPlayer().getUniqueId();
    if (e.getStatus() == PlayerResourcePackStatusEvent.Status.SUCCESSFULLY_LOADED) {
      packLoaded.add(id);
      if (sentCurrentPack.contains(id)) packVerified.add(id);
      // The kit was handed out with plain items while the pack was loading.
      if (playing(e.getPlayer())) items.refresh(e.getPlayer(), profile(e.getPlayer()));
    } else if (e.getStatus() == PlayerResourcePackStatusEvent.Status.FAILED_DOWNLOAD
        || e.getStatus() == PlayerResourcePackStatusEvent.Status.DECLINED) {
      packLoaded.remove(id);
      packVerified.remove(id);
      if (e.getStatus() == PlayerResourcePackStatusEvent.Status.FAILED_DOWNLOAD)
        tell(
            e.getPlayer(),
            "Ressourcenpaket konnte nicht geladen werden. Manuell: Datei "
                + PackHost.FILE
                + " vom Server-Admin holen, einfügen und /df pack local.");
    }
  }

  private void start(Player player) {
    start(player, false);
  }

  private void start(Player player, boolean automatic) {
    if (dungeons.active(player)) {
      tell(player, "Du bist bereits im Dungeon. /df dungeon leave zum Aussteigen.");
      return;
    }
    Profile p = profile(player);
    if (sessions.contains(player.getUniqueId())) return;
    if (!items.refresh(player, p)) {
      if (!automatic || autoEntryPending.add(player.getUniqueId()))
        tell(
            player,
            automatic
                ? "Bitte vier Inventarplätze freimachen. Dein automatischer Einstieg beginnt dann"
                      + " von selbst."
                : "Bitte vier freie Inventarplätze für Bohrer, Axt, Waffe und Handbuch schaffen.");
      return;
    }
    autoEntryPending.remove(player.getUniqueId());
    if (!inWorld(player)) {
      Location l = player.getLocation();
      p.returnWorld = l.getWorld().getName();
      p.returnX = l.getX();
      p.returnY = l.getY();
      p.returnZ = l.getZ();
      p.returnYaw = l.getYaw();
      p.returnPitch = l.getPitch();
    }
    p.enrolled = true;
    Production.settle(p, System.currentTimeMillis());
    if (!commit(player, p)) return;
    sessions.add(player.getUniqueId());
    tell(player, "Dein Minengelände wird vorbereitet. Beim ersten Besuch dauert das kurz.");
    mines.ensure(
        p,
        () -> {
          if (player.isOnline() && sessions.contains(player.getUniqueId())) {
            goHome(player);
            refreshWorkers(player);
            sendPack(player);
            tell(
                player,
                "Willkommen! Aufzug im Süden, Werkbank im Nordwesten. /df help zeigt die"
                    + " Steuerung.");
            report(player);
          }
        });
  }

  public void goHome(Player player) {
    if (!sessions.contains(player.getUniqueId())) return;
    if (dungeons != null && dungeons.watching(player)) dungeons.stopWatching(player, "Zuschauen beendet.");
    if (admin != null) admin.leaveMode(player);
    if (dungeons != null && dungeons.active(player)) {
      dungeons.withdraw(player);
      return;
    }
    combat.clear(player, false);
    expeditions.clear(player.getUniqueId());
    player.closeInventory();
    Profile p = profile(player);
    player.teleport(
        mines.isReady(p) ? mines.home(p) : mines.world().getSpawnLocation().add(.5, 0, .5));
  }

  public void travel(Player player, int zone) {
    if (dungeons.watching(player)) dungeons.stopWatching(player, "Zuschauen beendet.");
    if (admin != null) admin.leaveMode(player);
    if (dungeons.active(player)) {
      tell(player, "Zuerst /df dungeon leave.");
      return;
    }
    Profile p = profile(player);
    if (zone < 0 || zone > p.zone) {
      tell(player, "Dieses Gebiet ist noch gesperrt.");
      return;
    }
    gameplay.restoreOres(p, zone);
    combat.clear(player, false);
    player.teleport(mines.entrance(p, zone));
    expeditions.show(player, zone);
    items.refresh(player, p);
    tell(player, Zone.at(zone).title + " · Erzadern in den Stollen; Gleise führen zur Bosskammer.");
    if (zone == 2) tell(player, "Sporen belasten dich ohne Schutztraining Stufe 2.");
    if (zone == 3) tell(player, "Der Wasserdruck verlangt Schutztraining Stufe 4.");
  }

  private void leave(Player player) {
    autoEntryPending.remove(player.getUniqueId());
    if (boards != null) boards.remove(player);
    if (dungeons.active(player)) dungeons.withdraw(player);
    expeditions.clear(player.getUniqueId());
    Profile p = profile(player);
    World target = p.returnWorld == null ? null : Bukkit.getWorld(p.returnWorld);
    Location destination =
        target == null
            ? Bukkit.getWorlds().stream()
                .filter(w -> !w.equals(mines.world()))
                .findFirst()
                .orElseThrow()
                .getSpawnLocation()
            : new Location(target, p.returnX, p.returnY, p.returnZ, p.returnYaw, p.returnPitch);
    Production.settle(p, System.currentTimeMillis());
    p.enrolled = false;
    if (!commit(player, p)) return;
    player.closeInventory();
    gameplay.clear(player);
    if (workers != null) workers.remove(player.getUniqueId());
    sessions.remove(player.getUniqueId());
    items.removeKit(player);
    player.teleport(destination);
    tell(player, "Deine Mine produziert innerhalb ihrer Versorgung weiter.");
  }

  public void report(Player player) {
    Production.Report r = reports.get(player.getUniqueId());
    if (r == null || r.minutes() == 0) {
      tell(
          player,
          "Noch keine Offline-Abrechnung. Arbeiter benötigen Brennstoff und Betriebsbudget.");
      return;
    }
    tell(
        player,
        "Seit der letzten Abrechnung: "
            + r.minutes()
            + " Min. · "
            + r.mined()
            + " Erz · "
            + r.smelted()
            + " Barren · "
            + (r.chopped() > 0 ? r.chopped() + " Holz · " : "")
            + "Einnahmen "
            + r.revenue()
            + " $ · Kosten "
            + r.costs()
            + " $."
            + (r.dust() + r.relics() + r.notes() > 0
                ? " Funde: "
                    + r.dust()
                    + " Staub, "
                    + r.relics()
                    + " Relikte, "
                    + r.notes()
                    + " Unterlagen."
                : "")
            + (r.stopped().isEmpty() ? "" : " Hinweis: " + r.stopped()));
  }

  private void sendPack(Player player) {
    String bundled = packHost == null ? "" : packHost.sha1();
    try {
      String url, sha;
      if (packHost != null && packHost.serving()) {
        url = packHost.url(player, getConfig().getString("resource-pack.self-host.public-address", ""));
        sha = bundled;
      } else {
        url = getConfig().getString("resource-pack.url", "");
        if (url.isBlank()) {
          tell(
              player,
              "Ressourcenpaket: Datei plugins/Deepforge/"
                  + PackHost.FILE
                  + " in den resourcepacks-Ordner legen, aktivieren und /df pack local.");
          return;
        }
        URI uri = URI.create(url);
        boolean localHttp =
            "http".equalsIgnoreCase(uri.getScheme())
                && Set.of("localhost", "127.0.0.1", "[::1]").contains(uri.getHost());
        if (!"https".equalsIgnoreCase(uri.getScheme()) && !localHttp)
          throw new IllegalArgumentException("HTTPS required (HTTP allowed only on localhost)");
        sha = getConfig().getString("resource-pack.sha1", "");
        // An empty SHA-1 means: the hosted file is the pack bundled with this plugin.
        if (sha.isBlank()) sha = bundled;
        if (!sha.matches("[a-fA-F0-9]{40}"))
          throw new IllegalArgumentException("SHA-1 missing/invalid");
        if (!bundled.isBlank() && !sha.equalsIgnoreCase(bundled))
          getLogger()
              .warning(
                  "resource-pack.sha1 differs from the pack bundled with this plugin ("
                      + bundled
                      + "). Players may see an outdated pack.");
      }
      if (sha.equalsIgnoreCase(bundled)) sentCurrentPack.add(player.getUniqueId());
      else sentCurrentPack.remove(player.getUniqueId());
      player.setResourcePack(
          url,
          HexFormat.of().parseHex(sha),
          Component.text("Deepforge: eigene Erze, Modelle, Menüs und HUD"),
          getConfig().getBoolean("resource-pack.required"));
    } catch (IllegalArgumentException ex) {
      tell(player, "Ressourcenpaket ist noch nicht korrekt konfiguriert.");
      getLogger().warning("Pack configuration: " + ex.getMessage());
    }
  }

  /**
   * Game HUD glyphs only exist in the current pack; with an old or missing pack they would show
   * as boxes. Automatic mode therefore requires the verified pack; players can force either style.
   */
  public boolean gameHud(Player p) {
    UUID id = p.getUniqueId();
    return switch (profile(p).hudStyle) {
      case 1 -> packLoaded.contains(id);
      case 2 -> false;
      default -> packVerified.contains(id);
    };
  }

  private void updatePresentation() {
    if (!isEnabled() || shuttingDown) return;
    for (UUID id : new ArrayList<>(autoEntryPending)) {
      Player player = Bukkit.getPlayer(id);
      if (player == null
          || !player.hasPermission("deepforge.play")
          || !getConfig().getBoolean("game.auto-join", true)) {
        autoEntryPending.remove(id);
        continue;
      }
      try {
        start(player, true);
      } catch (RuntimeException ex) {
        autoEntryPending.remove(id);
        getLogger().log(java.util.logging.Level.SEVERE, "Automatic entry failed", ex);
        tell(player, "Automatischer Einstieg fehlgeschlagen. Bitte Administrator kontaktieren.");
      }
    }
    for (Player player : Bukkit.getOnlinePlayers()) {
      boards.snapshot(player);
      if (sessions.contains(player.getUniqueId()))
        boards.update(player, profile(player), playing(player));
      else boards.remove(player);
    }
  }

  private long hudTicks;

  /** Runs every 5 ticks; bookkeeping only once per second. */
  private void hud() {
    if (hudTicks++ % 4 == 0) {
      syncPartyPlots();
      announceMilestones();
      announceDailies();
    }
    long now = System.currentTimeMillis();
    for (UUID id : new ArrayList<>(sessions)) {
      Player player = Bukkit.getPlayer(id);
      if (player == null || !playing(player)) continue;
      Profile p = profile(player);
      Map.Entry<Component, Long> notice = notices.get(id);
      boolean fancy = gameHud(player);
      boolean fight =
          combat.fighting(player)
              || items.kind(player.getInventory().getItemInMainHand()).equals("sword");
      int healSeconds = (int) Math.max(0, (p.healingReadyAt - now + 999) / 1000);
      Component c;
      double maxHealth =
          player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue();
      Component life =
          Component.text(
              "❤ " + (int) Math.ceil(player.getHealth()) + "/" + (int) Math.ceil(maxHealth) + "  ·  ",
              NamedTextColor.RED);
      boolean noticing = notice != null && notice.getValue() > now;
      if (noticing) {
        // Notices only need resending before the client fades them out.
        if (hudTicks % 4 != 1) continue;
        c =
            fancy
                ? HudFont.withHealth(player.getHealth(), maxHealth, notice.getKey())
                : life.append(notice.getKey());
      } else if (fancy && fight)
        c =
            HudFont.combat(
                player.getHealth(),
                Gear.stats(p).health(),
                combat.stamina(player),
                combat.abilitySeconds(player),
                p.healingCharges,
                healSeconds,
                combat.combo(player));
      else if (fancy) {
        Location vein = gameplay.veinTarget(player);
        Location me = player.getLocation();
        c =
            HudFont.mining(
                player.getHealth(),
                maxHealth,
                p.money,
                p.bagUsed(),
                p.bagCapacity(),
                gameplay.heat(player),
                vein == null ? null : Math.round(vein.distance(me)) + "M",
                vein == null
                    ? null
                    : HudFont.arrow(me.getYaw(), vein.getX() - me.getX(), vein.getZ() - me.getZ()));
      } else if (fight)
        c =
            Component.text(
                combat.hud(player)
                    + " | Heilung "
                    + p.healingCharges
                    + (healSeconds > 0 ? " (" + healSeconds + "s)" : ""),
                NamedTextColor.GOLD);
      else {
        c =
            life.append(
                Hud.mining(p.money, p.bagUsed(), p.bagCapacity(), gameplay.heat(player)));
        String vein = gameplay.veinHint(player);
        if (vein != null)
          c = c.append(Component.text("  ·  ✦ " + vein, NamedTextColor.YELLOW));
      }
      // Private-use glyphs in minecraft:default can belong to the player's other packs.
      if (!fancy) c = c.font(Key.key("minecraft", "default"));
      player.sendActionBar(c);
    }
  }

  @Override
  public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
    if (!(sender instanceof Player player)) {
      if (args.length == 1 && args[0].equals("verify-boards")) {
        sender.sendMessage(boards.verify());
        return true;
      }
      if (args.length == 1 && args[0].equals("verify-menus")) {
        sender.sendMessage(menus.verify());
        return true;
      }
      if (args.length == 1 && args[0].equals("verify-forest")) {
        sender.sendMessage(forestry.verify(profiles.saved()));
        return true;
      }
      if (args.length == 1 && args[0].equals("verify-adventure")) {
        sender.sendMessage(adventure.verify(profiles.saved()));
        return true;
      }
      if (args.length == 1 && args[0].equals("verify-dungeon")) {
        sender.sendMessage(dungeons.verify());
        return true;
      }
      if (args.length == 1 && args[0].equals("dungeon-status")) {
        sender.sendMessage(dungeons.verification());
        return true;
      }
      if (args.length == 1 && args[0].equals("verify-expeditions")) {
        var saved = profiles.saved();
        sender.sendMessage(
            saved.isEmpty() ? "No saved plot" : expeditions.verify(saved.getFirst()));
        return true;
      }
      if (args.length == 1 && args[0].equals("verify-workers")) {
        var saved = profiles.saved();
        sender.sendMessage(
            workers == null
                ? "Citizens unavailable"
                : saved.isEmpty() ? "No saved plot" : workers.verify(saved.getFirst()));
        return true;
      }
      if (args.length == 1 && args[0].equals("verify-rails")) {
        sender.sendMessage(combat.verifyRails());
        return true;
      }
      if (args.length == 1 && args[0].equals("verify-models")) {
        sender.sendMessage(combat.verifyModels());
        return true;
      }
      sender.sendMessage("Deepforge: /df start im Spiel. Paper 1.21.8 + Java 21.");
      return true;
    }
    if (!player.hasPermission("deepforge.play")) {
      tell(player, "Keine Berechtigung.");
      return true;
    }
    String sub = args.length == 0 ? "menu" : args[0].toLowerCase(Locale.ROOT);
    try {
      switch (sub) {
        case "heal" -> {
          if (args.length > 1 && Set.of("kaufen", "buy").contains(args[1].toLowerCase(Locale.ROOT)))
            healing.buy(
                player,
                args.length < 3 || args[2].equalsIgnoreCase("voll") || args[2].equalsIgnoreCase("max")
                    ? Healing.CAPACITY
                    : Integer.parseInt(args[2]));
          else healing.use(player);
        }
        case "party", "dungeon" -> dungeons.command(player, args);
        case "tutorial", "journal", "merchant" -> {
          if (playing(player)) adventure.open(player, sub);
        }
        case "start" -> start(player);
        case "help" -> {
          tell(
              player,
              "/df heal oder Lebenssplitter rechtsklicken: Heilung auch im Bosskampf; 20 s"
                  + " Abklingzeit.");
          tell(
              player,
              "/df dungeon = Runengewölbe, Glutschmiede, Frostkrypta · /df party create|invite <Name>|accept|ready|leave");
          tell(player, "/df start · /df home · /df menu · /df leave · /df pack");
          tell(player, "/df stats = alle Spielerwerte · /df loot = Beutebeutel");
          tell(player, "/df milestones = Meilensteine mit Belohnungen");
          tell(player, "/df daily = Tagesaufträge mit Serienbonus · /df top = Rangliste");
          tell(player, "/df lager = Lager (einlagern von überall) · /df reward = letzte Dungeon-Beute");
          tell(player, "/df hud spiel|text|auto = HUD-Stil (Text, falls nur Kästchen erscheinen)");
          tell(player, "/df drohne = Dampfdrohne Funke bauen, verbessern, Modul und Aussehen");
          tell(
              player,
              "Waffe: Rechtsklick = Fähigkeit; Sneak+Rechtsklick = Ausweichen. Bossaltar:"
                  + " Schwierigkeit wählen.");
          tell(
              player,
              "Bohrer: Linksklick halten = abbauen; Rechtsklick = Überladung; Sneak+Rechtsklick ="
                  + " Scanner.");
          tell(
              player,
              "Arbeitsstationen und Arbeiter per Rechtsklick öffnen. Bosse am Lodestone starten.");
        }
        case "pack" -> {
          if (args.length > 1 && args[1].equals("local")) {
            packLoaded.add(player.getUniqueId());
            if (playing(player)) items.refresh(player, profile(player));
            tell(
                player,
                "Deepforge-Modelle und Menüs aktiviert. Das lokale Ressourcenpaket muss bereits"
                    + " geladen sein – sonst erscheinen lila-schwarze Kästchen.");
            hudTest(player);
          } else sendPack(player);
        }
        case "hud" -> {
          String mode = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "";
          int style =
              switch (mode) {
                case "spiel", "game" -> 1;
                case "text" -> 2;
                case "auto" -> 0;
                default -> -1;
              };
          if (style < 0) {
            hudTest(player);
            return true;
          }
          change(
              player,
              p -> {
                p.hudStyle = style;
                return switch (style) {
                  case 1 -> "Spiel-HUD aktiv (braucht das aktuelle Ressourcenpaket).";
                  case 2 -> "Text-HUD aktiv – funktioniert mit jedem Ressourcenpaket.";
                  default -> "HUD automatisch: Spiel-HUD, sobald der Server das Paket geladen hat.";
                };
              });
          if (style == 1) packLoaded.add(player.getUniqueId());
        }
        case "home" -> {
          if (playing(player)) goHome(player);
          else start(player);
        }
        case "leave" -> {
          autoEntryPending.remove(player.getUniqueId());
          if (playing(player)) leave(player);
        }
        case "menu" -> {
          if (playing(player)) menus.open(player, "main");
          else tell(player, "Mit /df start beginnen.");
        }
        case "loot" -> {
          if (playing(player)) menus.open(player, "loot/0");
        }
        case "stats" -> {
          if (playing(player)) menus.open(player, "character");
        }
        case "research", "contracts", "expeditions", "crew", "forestry", "milestones", "daily",
            "top", "reward" -> {
          if (playing(player)) menus.open(player, sub);
        }
        case "pass", "tiefenpass", "season" -> {
          if (playing(player)) menus.open(player, "pass/" + Math.min(3, DeepPass.tier(profile(player)) / 9));
        }
        case "event", "events", "ereignis" -> {
          if (playing(player)) tell(player, events.status());
        }
        case "sets", "set", "preset", "presets" -> {
          if (playing(player)) presetCommand(player, args);
        }
        case "setschmiede", "setforge", "schmiede" -> {
          if (playing(player)) adventure().open(player, "setforge");
        }
        case "drohne", "drone", "funke" -> {
          if (playing(player)) menus.open(player, "drone");
        }
        case "lager", "storage" -> {
          if (playing(player)) menus.open(player, "storage");
        }
        case "admin" -> {
          if (!player.hasPermission("deepforge.admin")) {
            tell(player, "Keine Berechtigung.");
            return true;
          }
          if (args.length == 1) {
            admin.open(player);
            return true;
          }
          if (args.length == 2 && (args[1].equals("mode") || args[1].equals("modus"))) {
            admin.toggleMode(player);
            return true;
          }
          if (args.length == 3 && args[1].equals("money") && playing(player)) {
            long amount = Long.parseLong(args[2]);
            if (amount < 0 || amount > 1_000_000_000) throw new IllegalArgumentException();
            change(
                player,
                p -> {
                  p.money = Math.addExact(p.money, amount);
                  return "Testgeld: +" + amount + " $.";
                });
          } else if (args.length == 2 && args[1].equals("boss")) tell(player, dungeons.debugBoss(player));
          else if (args.length == 2 && args[1].equals("skip")) tell(player, dungeons.debugSkip(player));
          else if (args.length >= 3 && args[1].equals("event")) {
            if (args[2].equalsIgnoreCase("stop")) tell(player, events.stop());
            else
              tell(
                  player,
                  events.start(
                      WorldEvents.Kind.valueOf(args[2].toUpperCase(Locale.ROOT)),
                      args.length > 3 ? Integer.parseInt(args[3]) : 10));
          } else if (args.length == 3 && args[1].equals("passxp") && playing(player)) {
            passXp(player, Long.parseLong(args[2]));
            commit(player, profile(player));
          }
          else if (args.length == 2 && args[1].equals("plan")) tell(player, dungeons.debugPlan(player));
          else if (args.length == 2 && args[1].equals("dungeons") && playing(player))
            change(
                player,
                p -> {
                  if (p.variantWins == null || p.variantWins.length < 3) p.variantWins = new int[3];
                  p.dungeonWins[0] = Math.max(1, p.dungeonWins[0]);
                  p.variantWins[1] = Math.max(1, p.variantWins[1]);
                  return "Testfreischaltung: Glutschmiede und Frostkrypta offen.";
                });
          else
            tell(
                player,
                "/df admin (Moderationsmenü) · /df admin mode (Admin-Modus) · /df admin money"
                    + " <0..1000000000> · /df admin boss (im Dungeon: direkt zum Endboss) · /df admin"
                    + " dungeons (alle Dungeons freischalten)");
        }
        default -> tell(player, "Unbekannter Befehl. /df help");
      }
    } catch (IllegalArgumentException ex) {
      tell(player, readable(ex, "Ungültige Eingabe. /df help"));
    } catch (RuntimeException ex) {
      getLogger().log(java.util.logging.Level.SEVERE, "Command failed", ex);
      tell(player, "Aktion fehlgeschlagen. Details im Server-Log.");
    }
    return true;
  }

  @Override
  public List<String> onTabComplete(
      CommandSender sender, Command command, String alias, String[] args) {
    return args.length == 1
        ? List.of(
                "start",
                "home",
                "menu",
                "leave",
                "pack",
                "help",
                "loot",
                "stats",
                "crew",
                "milestones",
                "daily",
                "top",
                "reward",
                "lager",
                "drohne",
                "setschmiede",
                "sets",
                "pass",
                "event",
                "hud",
                "research",
                "contracts",
                "party",
                "dungeon",
                "heal",
                "tutorial",
                "journal",
                "merchant",
                "forestry",
                "expeditions")
            .stream()
            .filter(s -> s.startsWith(args[0]))
            .toList()
        : List.of();
  }
}
