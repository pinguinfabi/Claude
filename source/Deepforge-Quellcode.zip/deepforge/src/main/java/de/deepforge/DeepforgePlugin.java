package de.deepforge;

import de.deepforge.game.*;
import de.deepforge.storage.Profiles;
import de.deepforge.ui.*;
import de.deepforge.world.*;
import java.net.URI;
import java.util.*;
import java.util.function.Function;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.plugin.java.JavaPlugin;

public final class DeepforgePlugin extends JavaPlugin
    implements Listener, CommandExecutor, TabCompleter {
  private Profiles profiles;
  private MineWorld mines;
  private Items items;
  private Menus menus;
  private Gameplay gameplay;
  private CombatEngine combat;
  private Workers workers;
  private Expeditions expeditions;
  private Dungeons dungeons;
  private HealingItems healing;
  private AdventureSystem adventure;
  private ForestryWorld forestry;
  private ServerBoards boards;
  private final Set<UUID> autoEntryPending = new HashSet<>();
  private final Set<UUID> sessions = new HashSet<>(), packLoaded = new HashSet<>();
  private final Map<UUID, Production.Report> reports = new HashMap<>();
  private final Map<UUID, Integer> shownPlot = new HashMap<>();
  private final Map<UUID, Long> shownMilestones = new HashMap<>();
  private boolean shuttingDown;

  @Override
  public void onEnable() {
    saveDefaultConfig();
    if (!Bukkit.getMinecraftVersion().equals("1.21.8")) {
      getLogger().severe("This release targets Paper 1.21.8. Refusing unsupported server version.");
      Bukkit.getPluginManager().disablePlugin(this);
      return;
    }
    try {
      profiles = new Profiles(getDataFolder().toPath().resolve("profiles.db"));
      items = new Items(this);
      mines = new MineWorld(this);
      mines.init();
      for (Profile saved : profiles.saved())
        if (mines.needsMigration(saved)) mines.ensure(saved, () -> {});
      menus = new Menus(this);
      combat = new CombatEngine(this);
      gameplay = new Gameplay(this);
      expeditions = new Expeditions(this);
      dungeons = new Dungeons(this);
      healing = new HealingItems(this);
      adventure = new AdventureSystem(this);
      forestry = new ForestryWorld(this);
      boards = new ServerBoards(this);
      for (Profile saved : profiles.saved())
        if (!mines.needsMigration(saved)) forestry.ensure(saved);
      Bukkit.getPluginManager().registerEvents(this, this);
      Bukkit.getPluginManager().registerEvents(menus, this);
      Bukkit.getPluginManager().registerEvents(gameplay, this);
      Objects.requireNonNull(getCommand("deepforge")).setExecutor(this);
      getCommand("deepforge").setTabCompleter(this);
      if (Bukkit.getPluginManager().isPluginEnabled("Citizens"))
        try {
          workers = new Workers(this);
        } catch (LinkageError | RuntimeException e) {
          getLogger().warning("Citizens integration disabled: " + e);
        }
      if (workers == null)
        getLogger()
            .warning(
                "Citizens with 1.21.8 support is missing. Worker hiring is disabled; other systems"
                    + " remain available.");
      Bukkit.getScheduler()
          .runTaskTimer(
              this,
              () -> {
                for (UUID id : new ArrayList<>(sessions)) {
                  Player p = Bukkit.getPlayer(id);
                  if (p == null) continue;
                  Profile data = profile(p);
                  Production.settle(data, System.currentTimeMillis());
                  if (!commit(p, data)) return;
                }
              },
              1200,
              1200);
      Bukkit.getScheduler().runTaskTimer(this, this::hud, 20, 20);
      Bukkit.getScheduler().runTaskTimer(this, this::updatePresentation, 20, 20);
      Bukkit.getScheduler().runTask(this, () -> Bukkit.getOnlinePlayers().forEach(this::login));
      getLogger()
          .info(
              "Deepforge "
                  + getPluginMeta().getVersion()
                  + (mines.shared()
                      ? " ready. Shared camp and mines; monsters and bosses stay personal."
                      : " ready. /df start creates a personal mine."));
    } catch (Exception e) {
      getLogger().log(java.util.logging.Level.SEVERE, "Deepforge initialization failed", e);
      Bukkit.getPluginManager().disablePlugin(this);
    }
  }

  @Override
  public void onDisable() {
    shuttingDown = true;
    if (boards != null) boards.close();
    autoEntryPending.clear();
    if (dungeons != null) dungeons.close();
    if (adventure != null) adventure.close();
    if (forestry != null) forestry.close();
    if (combat != null) combat.close();
    if (gameplay != null) gameplay.close();
    if (workers != null) workers.close();
    if (expeditions != null) expeditions.close();
    if (profiles != null) {
      for (UUID id : new ArrayList<>(sessions)) {
        Player player = Bukkit.getPlayer(id);
        if (player != null)
          try {
            Profile p = profile(player);
            Production.settle(p, System.currentTimeMillis());
            profiles.save(p);
          } catch (Exception ex) {
            getLogger().severe("Final save failed for " + id + ": " + ex);
          }
      }
      try {
        profiles.close();
      } catch (Exception ex) {
        getLogger().severe("Database close failed: " + ex);
      }
    }
    sessions.clear();
  }

  public MineWorld mines() {
    return mines;
  }

  public CombatEngine combat() {
    return combat;
  }

  public Dungeons dungeons() {
    return dungeons;
  }

  public void rewardDungeon(List<UUID> ids, UUID run, int zone, int mode, long ticks, int level) {
    profiles.rewardDungeon(ids, run, zone, mode, ticks, level);
  }

  public void rewardDungeon(
      List<UUID> ids, UUID run, int zone, int mode, long ticks, int level, int flags) {
    profiles.rewardDungeon(ids, run, zone, mode, ticks, level, flags);
  }

  public HealingItems healing() {
    return healing;
  }

  public AdventureSystem adventure() {
    return adventure;
  }

  public ForestryWorld forestry() {
    return forestry;
  }

  public Items items() {
    return items;
  }

  public Menus menus() {
    return menus;
  }

  public boolean inWorld(Player p) {
    return mines != null && mines.contains(p.getLocation());
  }

  public boolean playing(Player p) {
    return sessions.contains(p.getUniqueId()) && inWorld(p) && mines.isReady(profile(p));
  }

  public boolean workersAvailable() {
    return workers != null;
  }

  public String workerStatus(Player player, int index) {
    return workers == null ? "Citizens fehlt" : workers.status(player.getUniqueId(), index);
  }

  public boolean packApplied(Player p) {
    return packLoaded.contains(p.getUniqueId());
  }

  public Profile profile(Player p) {
    return profiles.get(
        p.getUniqueId(), p.getName(), getConfig().getLong("game.starter-money", 250));
  }

  /**
   * Shared world: everyone uses one camp and mine. Otherwise party members share the plot the party
   * was founded on.
   */
  public int plot(Profile p) {
    if (mines != null && mines.shared()) return getConfig().getInt("game.shared-plot", 0);
    if (dungeons == null || p.id == null) return p.plot;
    PartyBook.Party party;
    try {
      party = dungeons.parties().get(UUID.fromString(p.id));
    } catch (IllegalArgumentException e) {
      return p.plot;
    }
    if (party == null) return p.plot;
    if (party.plot < 0) {
      Player leader = Bukkit.getPlayer(party.leader);
      if (leader == null) return p.plot;
      party.plot = profile(leader).plot;
    }
    return party.plot;
  }

  private void announceMilestones() {
    shownMilestones.keySet().retainAll(sessions);
    for (UUID id : new ArrayList<>(sessions)) {
      Player player = Bukkit.getPlayer(id);
      if (player == null || !playing(player)) continue;
      long ready = Milestones.claimableCount(profile(player));
      Long before = shownMilestones.put(id, ready);
      if (before != null && ready > before) {
        tell(player, "Meilenstein erreicht! Belohnung abholen: /df milestones");
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, .6f, 1.2f);
      }
    }
  }

  private void syncPartyPlots() {
    shownPlot.keySet().retainAll(sessions);
    for (UUID id : new ArrayList<>(sessions)) {
      Player player = Bukkit.getPlayer(id);
      if (player == null || !inWorld(player)) continue;
      Profile p = profile(player);
      int now = plot(p);
      Integer before = shownPlot.put(id, now);
      if (before == null || before == now || dungeons.active(player)) continue;
      mines.ensure(
          p,
          () -> {
            if (!player.isOnline() || plot(p) != now) return;
            goHome(player);
            refreshWorkers(player);
            tell(
                player,
                now == p.plot
                    ? "Du bist zurück in deinem eigenen Lager."
                    : "Party: Spawn und Minen werden jetzt mit deiner Party geteilt.");
          });
    }
  }

  public void tell(Player p, String text) {
    p.sendMessage(
        Component.text("Deepforge » ", NamedTextColor.GOLD)
            .append(Component.text(text, NamedTextColor.GRAY)));
  }

  public boolean commit(Player player, Profile p) {
    try {
      int lessons = Tutorial.advance(p);
      profiles.save(p);
      if (lessons > 0)
        tell(player, "Lernziel erfüllt! Prämie erhalten. Nächstes Ziel: " + Tutorial.title(p));
      return true;
    } catch (RuntimeException e) {
      getLogger().log(java.util.logging.Level.SEVERE, "State commit failed", e);
      tell(player, "Speicherfehler. Das Spiel wurde angehalten, um deinen Stand zu schützen.");
      Bukkit.getPluginManager().disablePlugin(this);
      return false;
    }
  }

  /** Applies a profile action and returns its message (null when nothing ran). */
  public String change(Player player, Function<Profile, String> action) {
    if (!playing(player)) return null;
    Profile p = profile(player);
    Production.settle(p, System.currentTimeMillis());
    String message = action.apply(p);
    if (!commit(player, p)) return null;
    tell(player, message);
    return message;
  }

  public void refreshWorkers(Player p) {
    if (workers != null) workers.spawn(p);
  }

  private void login(Player player) {
    if (!isEnabled()) return;
    try {
      Profile p = profile(player);
      Production.Report r = Production.settle(p, System.currentTimeMillis());
      if (!commit(player, p)) return;
      reports.put(player.getUniqueId(), r);
      JoinFlow.Route route =
          JoinFlow.route(
              player.hasPermission("deepforge.play"),
              sessions.contains(player.getUniqueId()),
              p.enrolled,
              inWorld(player),
              getConfig().getBoolean("game.auto-join", true));
      if (route == JoinFlow.Route.START) {
        start(player, true);
      } else if (route == JoinFlow.Route.RESUME) {
        sessions.add(player.getUniqueId());
        if (!mines.isReady(p)) player.teleport(mines.world().getSpawnLocation().add(.5, 0, .5));
        mines.ensure(
            p,
            () -> {
              if (player.isOnline() && sessions.contains(player.getUniqueId())) {
                items.refresh(player, p);
                if (dungeons.active(player)) dungeons.resume(player);
                else goHome(player);
                refreshWorkers(player);
                report(player);
                sendPack(player);
              }
            });
      }
    } catch (RuntimeException ex) {
      getLogger().log(java.util.logging.Level.SEVERE, "Profile load failed", ex);
      tell(player, "Spielerstand konnte nicht geladen werden. Bitte Administrator kontaktieren.");
    }
  }

  @EventHandler
  public void join(PlayerJoinEvent e) {
    Bukkit.getScheduler()
        .runTaskLater(
            this,
            () -> {
              if (e.getPlayer().isOnline()) login(e.getPlayer());
            },
            20);
  }

  @EventHandler
  public void quit(PlayerQuitEvent e) {
    Player player = e.getPlayer();
    autoEntryPending.remove(player.getUniqueId());
    if (boards != null) boards.remove(player);
    dungeons.disconnect(player);
    if (adventure != null) adventure.clear(player.getUniqueId());
    if (mines != null) mines.clearPersonal(player.getUniqueId());
    expeditions.clear(player.getUniqueId());
    if (sessions.remove(player.getUniqueId())) {
      Profile p = profile(player);
      Production.settle(p, System.currentTimeMillis());
      commit(player, p);
      gameplay.clear(player);
      if (workers != null) workers.remove(player.getUniqueId());
    }
    packLoaded.remove(player.getUniqueId());
    reports.remove(player.getUniqueId());
    profiles.evict(player.getUniqueId());
  }

  @EventHandler
  public void resourcePack(PlayerResourcePackStatusEvent e) {
    if (e.getStatus() == PlayerResourcePackStatusEvent.Status.SUCCESSFULLY_LOADED)
      packLoaded.add(e.getPlayer().getUniqueId());
    else if (e.getStatus() == PlayerResourcePackStatusEvent.Status.FAILED_DOWNLOAD
        || e.getStatus() == PlayerResourcePackStatusEvent.Status.DECLINED)
      packLoaded.remove(e.getPlayer().getUniqueId());
  }

  private void start(Player player) {
    start(player, false);
  }

  private void start(Player player, boolean automatic) {
    if (dungeons.active(player)) {
      tell(player, "Du bist bereits im Dungeon. /df dungeon leave zum Aussteigen.");
      return;
    }
    Profile p = profile(player);
    if (sessions.contains(player.getUniqueId())) return;
    if (!items.refresh(player, p)) {
      if (!automatic || autoEntryPending.add(player.getUniqueId()))
        tell(
            player,
            automatic
                ? "Bitte vier Inventarplätze freimachen. Dein automatischer Einstieg beginnt dann"
                      + " von selbst."
                : "Bitte vier freie Inventarplätze für Bohrer, Axt, Waffe und Handbuch schaffen.");
      return;
    }
    autoEntryPending.remove(player.getUniqueId());
    if (!inWorld(player)) {
      Location l = player.getLocation();
      p.returnWorld = l.getWorld().getName();
      p.returnX = l.getX();
      p.returnY = l.getY();
      p.returnZ = l.getZ();
      p.returnYaw = l.getYaw();
      p.returnPitch = l.getPitch();
    }
    p.enrolled = true;
    Production.settle(p, System.currentTimeMillis());
    if (!commit(player, p)) return;
    sessions.add(player.getUniqueId());
    tell(player, "Dein Minengelände wird vorbereitet. Beim ersten Besuch dauert das kurz.");
    mines.ensure(
        p,
        () -> {
          if (player.isOnline() && sessions.contains(player.getUniqueId())) {
            goHome(player);
            refreshWorkers(player);
            sendPack(player);
            tell(
                player,
                "Willkommen! Aufzug im Süden, Werkbank im Nordwesten. /df help zeigt die"
                    + " Steuerung.");
            report(player);
          }
        });
  }

  public void goHome(Player player) {
    if (!sessions.contains(player.getUniqueId())) return;
    if (dungeons != null && dungeons.active(player)) {
      dungeons.withdraw(player);
      return;
    }
    combat.clear(player, false);
    expeditions.clear(player.getUniqueId());
    player.closeInventory();
    Profile p = profile(player);
    player.teleport(
        mines.isReady(p) ? mines.home(p) : mines.world().getSpawnLocation().add(.5, 0, .5));
  }

  public void travel(Player player, int zone) {
    if (dungeons.active(player)) {
      tell(player, "Zuerst /df dungeon leave.");
      return;
    }
    Profile p = profile(player);
    if (zone < 0 || zone > p.zone) {
      tell(player, "Dieses Gebiet ist noch gesperrt.");
      return;
    }
    gameplay.restoreOres(p, zone);
    combat.clear(player, false);
    player.teleport(mines.entrance(p, zone));
    expeditions.show(player, zone);
    items.refresh(player, p);
    tell(player, Zone.at(zone).title + " · Erzadern in den Stollen; Gleise führen zur Bosskammer.");
    if (zone == 2) tell(player, "Sporen belasten dich ohne Schutztraining Stufe 2.");
    if (zone == 3) tell(player, "Der Wasserdruck verlangt Schutztraining Stufe 4.");
  }

  private void leave(Player player) {
    autoEntryPending.remove(player.getUniqueId());
    if (boards != null) boards.remove(player);
    if (dungeons.active(player)) dungeons.withdraw(player);
    expeditions.clear(player.getUniqueId());
    Profile p = profile(player);
    World target = p.returnWorld == null ? null : Bukkit.getWorld(p.returnWorld);
    Location destination =
        target == null
            ? Bukkit.getWorlds().stream()
                .filter(w -> !w.equals(mines.world()))
                .findFirst()
                .orElseThrow()
                .getSpawnLocation()
            : new Location(target, p.returnX, p.returnY, p.returnZ, p.returnYaw, p.returnPitch);
    Production.settle(p, System.currentTimeMillis());
    p.enrolled = false;
    if (!commit(player, p)) return;
    player.closeInventory();
    gameplay.clear(player);
    if (workers != null) workers.remove(player.getUniqueId());
    sessions.remove(player.getUniqueId());
    items.removeKit(player);
    player.teleport(destination);
    tell(player, "Deine Mine produziert innerhalb ihrer Versorgung weiter.");
  }

  public void report(Player player) {
    Production.Report r = reports.get(player.getUniqueId());
    if (r == null || r.minutes() == 0) {
      tell(
          player,
          "Noch keine Offline-Abrechnung. Arbeiter benötigen Brennstoff und Betriebsbudget.");
      return;
    }
    tell(
        player,
        "Seit der letzten Abrechnung: "
            + r.minutes()
            + " Min. · "
            + r.mined()
            + " Erz · "
            + r.smelted()
            + " Barren · Einnahmen "
            + r.revenue()
            + " $ · Kosten "
            + r.costs()
            + " $."
            + (r.dust() + r.relics() + r.notes() > 0
                ? " Funde: "
                    + r.dust()
                    + " Staub, "
                    + r.relics()
                    + " Relikte, "
                    + r.notes()
                    + " Unterlagen."
                : "")
            + (r.stopped().isEmpty() ? "" : " Hinweis: " + r.stopped()));
  }

  private void sendPack(Player player) {
    String url = getConfig().getString("resource-pack.url", "");
    if (url.isBlank()) {
      tell(
          player,
          "Ressourcenpaket lokal aktivieren; danach /df pack local. Die ZIP liegt im Release.");
      return;
    }
    try {
      URI uri = URI.create(url);
      boolean localHttp =
          "http".equalsIgnoreCase(uri.getScheme())
              && Set.of("localhost", "127.0.0.1", "[::1]").contains(uri.getHost());
      if (!"https".equalsIgnoreCase(uri.getScheme()) && !localHttp)
        throw new IllegalArgumentException("HTTPS required (HTTP allowed only on localhost)");
      String sha = getConfig().getString("resource-pack.sha1", "");
      if (!sha.matches("[a-fA-F0-9]{40}"))
        throw new IllegalArgumentException("SHA-1 missing/invalid");
      player.setResourcePack(
          url,
          HexFormat.of().parseHex(sha),
          Component.text("Deepforge: eigene Erze, Modelle und Menüs"),
          getConfig().getBoolean("resource-pack.required"));
    } catch (IllegalArgumentException ex) {
      tell(player, "Ressourcenpaket ist noch nicht korrekt konfiguriert.");
      getLogger().warning("Pack configuration: " + ex.getMessage());
    }
  }

  private void updatePresentation() {
    if (!isEnabled() || shuttingDown) return;
    for (UUID id : new ArrayList<>(autoEntryPending)) {
      Player player = Bukkit.getPlayer(id);
      if (player == null
          || !player.hasPermission("deepforge.play")
          || !getConfig().getBoolean("game.auto-join", true)) {
        autoEntryPending.remove(id);
        continue;
      }
      try {
        start(player, true);
      } catch (RuntimeException ex) {
        autoEntryPending.remove(id);
        getLogger().log(java.util.logging.Level.SEVERE, "Automatic entry failed", ex);
        tell(player, "Automatischer Einstieg fehlgeschlagen. Bitte Administrator kontaktieren.");
      }
    }
    for (Player player : Bukkit.getOnlinePlayers()) {
      if (sessions.contains(player.getUniqueId()))
        boards.update(player, profile(player), playing(player));
      else boards.remove(player);
    }
  }

  private void hud() {
    syncPartyPlots();
    announceMilestones();
    for (UUID id : new ArrayList<>(sessions)) {
      Player player = Bukkit.getPlayer(id);
      if (player == null || !playing(player)) continue;
      Profile p = profile(player);
      String text =
          p.money
              + " $   |   Erz "
              + p.bagUsed()
              + "/"
              + p.bagCapacity()
              + "   |   Hitze "
              + (int) gameplay.heat(player)
              + " %";
      // Private-use glyphs in minecraft:default can belong to the player's other packs.
      if (combat.fighting(player)
          || items.kind(player.getInventory().getItemInMainHand()).equals("sword"))
        text =
            combat.hud(player)
                + " | Heilung "
                + p.healingCharges
                + (p.healingReadyAt > System.currentTimeMillis()
                    ? " (" + ((p.healingReadyAt - System.currentTimeMillis() + 999) / 1000) + "s)"
                    : "");
      Component c = Component.text(text, NamedTextColor.GOLD).font(Key.key("minecraft", "default"));
      player.sendActionBar(c);
    }
  }

  @Override
  public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
    if (!(sender instanceof Player player)) {
      if (args.length == 1 && args[0].equals("verify-boards")) {
        sender.sendMessage(boards.verify());
        return true;
      }
      if (args.length == 1 && args[0].equals("verify-menus")) {
        sender.sendMessage(menus.verify());
        return true;
      }
      if (args.length == 1 && args[0].equals("verify-forest")) {
        sender.sendMessage(forestry.verify(profiles.saved()));
        return true;
      }
      if (args.length == 1 && args[0].equals("verify-adventure")) {
        sender.sendMessage(adventure.verify(profiles.saved()));
        return true;
      }
      if (args.length == 1 && args[0].equals("verify-dungeon")) {
        sender.sendMessage(dungeons.verify());
        return true;
      }
      if (args.length == 1 && args[0].equals("dungeon-status")) {
        sender.sendMessage(dungeons.verification());
        return true;
      }
      if (args.length == 1 && args[0].equals("verify-expeditions")) {
        var saved = profiles.saved();
        sender.sendMessage(
            saved.isEmpty() ? "No saved plot" : expeditions.verify(saved.getFirst()));
        return true;
      }
      if (args.length == 1 && args[0].equals("verify-workers")) {
        var saved = profiles.saved();
        sender.sendMessage(
            workers == null
                ? "Citizens unavailable"
                : saved.isEmpty() ? "No saved plot" : workers.verify(saved.getFirst()));
        return true;
      }
      if (args.length == 1 && args[0].equals("verify-rails")) {
        sender.sendMessage(combat.verifyRails());
        return true;
      }
      if (args.length == 1 && args[0].equals("verify-models")) {
        sender.sendMessage(combat.verifyModels());
        return true;
      }
      sender.sendMessage("Deepforge: /df start im Spiel. Paper 1.21.8 + Java 21.");
      return true;
    }
    if (!player.hasPermission("deepforge.play")) {
      tell(player, "Keine Berechtigung.");
      return true;
    }
    String sub = args.length == 0 ? "menu" : args[0].toLowerCase(Locale.ROOT);
    try {
      switch (sub) {
        case "heal" -> healing.use(player);
        case "party", "dungeon" -> dungeons.command(player, args);
        case "tutorial", "journal", "merchant" -> {
          if (playing(player)) adventure.open(player, sub);
        }
        case "start" -> start(player);
        case "help" -> {
          tell(
              player,
              "/df heal oder Lebenssplitter rechtsklicken: Heilung auch im Bosskampf; 20 s"
                  + " Abklingzeit.");
          tell(
              player,
              "/df dungeon = Runengewölbe · /df party create|invite <Name>|accept|ready|leave");
          tell(player, "/df start · /df home · /df menu · /df leave · /df pack");
          tell(player, "/df stats = alle Spielerwerte · /df loot = Beutebeutel");
          tell(player, "/df milestones = Meilensteine mit Belohnungen");
          tell(
              player,
              "Waffe: Rechtsklick = Fähigkeit; Sneak+Rechtsklick = Ausweichen. Bossaltar:"
                  + " Schwierigkeit wählen.");
          tell(
              player,
              "Bohrer: Linksklick halten = abbauen; Rechtsklick = Überladung; Sneak+Rechtsklick ="
                  + " Scanner.");
          tell(
              player,
              "Arbeitsstationen und Arbeiter per Rechtsklick öffnen. Bosse am Lodestone starten.");
        }
        case "pack" -> {
          if (args.length > 1 && args[1].equals("local")) {
            packLoaded.add(player.getUniqueId());
            tell(
                player,
                "Texturierte Menüs aktiviert. Das lokale Ressourcenpaket muss bereits geladen"
                    + " sein.");
          } else sendPack(player);
        }
        case "home" -> {
          if (playing(player)) goHome(player);
          else start(player);
        }
        case "leave" -> {
          autoEntryPending.remove(player.getUniqueId());
          if (playing(player)) leave(player);
        }
        case "menu" -> {
          if (playing(player)) menus.open(player, "main");
          else tell(player, "Mit /df start beginnen.");
        }
        case "loot" -> {
          if (playing(player)) menus.open(player, "loot/0");
        }
        case "stats" -> {
          if (playing(player)) menus.open(player, "character");
        }
        case "research", "contracts", "expeditions", "crew", "forestry", "milestones" -> {
          if (playing(player)) menus.open(player, sub);
        }
        case "admin" -> {
          if (!player.hasPermission("deepforge.admin")) {
            tell(player, "Keine Berechtigung.");
            return true;
          }
          if (args.length == 3 && args[1].equals("money") && playing(player)) {
            long amount = Long.parseLong(args[2]);
            if (amount < 0 || amount > 1_000_000_000) throw new IllegalArgumentException();
            change(
                player,
                p -> {
                  p.money = Math.addExact(p.money, amount);
                  return "Testgeld: +" + amount + " $.";
                });
          } else tell(player, "/df admin money <0..1000000000> gibt dir Testgeld.");
        }
        default -> tell(player, "Unbekannter Befehl. /df help");
      }
    } catch (IllegalArgumentException ex) {
      tell(player, "Ungültige Eingabe. /df help");
    } catch (RuntimeException ex) {
      getLogger().log(java.util.logging.Level.SEVERE, "Command failed", ex);
      tell(player, "Aktion fehlgeschlagen. Details im Server-Log.");
    }
    return true;
  }

  @Override
  public List<String> onTabComplete(
      CommandSender sender, Command command, String alias, String[] args) {
    return args.length == 1
        ? List.of(
                "start",
                "home",
                "menu",
                "leave",
                "pack",
                "help",
                "loot",
                "stats",
                "crew",
                "milestones",
                "research",
                "contracts",
                "party",
                "dungeon",
                "heal",
                "tutorial",
                "journal",
                "merchant",
                "forestry",
                "expeditions")
            .stream()
            .filter(s -> s.startsWith(args[0]))
            .toList()
        : List.of();
  }
}
