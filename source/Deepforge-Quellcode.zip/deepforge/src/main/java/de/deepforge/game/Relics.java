package de.deepforge.game;

import java.util.*;
import java.util.random.RandomGenerator;

/**
 * Relikt-Schmiede (0.20.0): six weapons nobody finds – they are forged from rare parts that only
 * certain bosses drop now and then. Every relic needs several different parts, so a relic means
 * many boss fights across mines, dungeons, the Tiefengang and the forest.
 */
public final class Relics {
  private Relics() {}

  public enum Part {
    ERZKERN("Ur-Erzkern", "Gebietsbosse in den Minen", "RAW_GOLD_BLOCK"),
    WAECHTERZAHN("Wächterzahn", "Wächter in den Dungeons", "BONE"),
    SIEGEL("Gewölbesiegel", "Endbosse der Dungeons", "ENCHANTED_BOOK"),
    PERLE("Tiefenperle", "Boss-Ebenen im Tiefengang", "HEART_OF_THE_SEA"),
    WALDHERZ("Waldherz", "Champions im Holzwald", "MOSS_BLOCK"),
    URAUGE("Urauge", "der Urboss im Weltenkern", "ENDER_EYE");

    public final String title, source, icon;

    Part(String title, String source, String icon) {
      this.title = title;
      this.source = source;
      this.icon = icon;
    }
  }

  /** Drop chance of a part for one kill; mode 0..2 = Normal, Veteran, Albtraum. */
  public static double chance(Part part, int mode) {
    int m = Math.max(0, Math.min(2, mode));
    return switch (part) {
      case ERZKERN -> .04 + .02 * m;
      case WAECHTERZAHN -> .06 + .02 * m;
      case SIEGEL -> new double[] {.05, .08, .12}[m];
      case PERLE -> .10;
      case WALDHERZ -> .03;
      case URAUGE -> .35;
    };
  }

  public enum Relic {
    ERZFUERST(
        "Erzfürst", "hammer", Gear.Slot.WEAPON, 7,
        "Haltungsschaden ×1,6 · Hammerfähigkeit +50 %",
        new int[] {6, 3, 0, 0, 0, 1}),
    GEWOELBESCHWUR(
        "Gewölbeschwur", "sword", Gear.Slot.WEAPON, 8,
        "Lebensraub: 4 % des Schadens heilen dich",
        new int[] {2, 4, 5, 0, 0, 0}),
    TIEFENSEUFZER(
        "Tiefenseufzer", "spear", Gear.Slot.WEAPON, 9,
        "+30 % Schaden gegen Bosse und Wächter",
        new int[] {3, 0, 3, 4, 0, 0}),
    WALDLAEUFER(
        "Waldläufer", "crossbow", Gear.Slot.WEAPON, 10,
        "25 % Chance: jeder Schuss trifft ein zweites Mal",
        new int[] {3, 2, 0, 0, 5, 0}),
    SCHATTENZAHN(
        "Schattenzahn", "dagger", Gear.Slot.WEAPON, 11,
        "Grund-Krit-Schaden 260 % statt 200 %",
        new int[] {0, 6, 0, 2, 2, 0}),
    WELTENSCHILD(
        "Weltenschild", "sword", Gear.Slot.OFFHAND, 12,
        "20 % weniger Schaden aus jeder Quelle",
        new int[] {0, 0, 4, 4, 0, 2});

    public final String title, style, effect;
    public final Gear.Slot slot;
    public final int signature;
    /** Parts needed, in the order of {@link Part}. */
    public final int[] recipe;

    Relic(String title, String style, Gear.Slot slot, int signature, String effect, int[] recipe) {
      this.title = title;
      this.style = style;
      this.slot = slot;
      this.signature = signature;
      this.effect = effect;
      this.recipe = recipe;
    }

    public static Relic of(int signature) {
      for (Relic r : values()) if (r.signature == signature) return r;
      return null;
    }
  }

  public static final long MONEY = 250_000, DUST = 200;

  public static int[] parts(Profile p) {
    if (p.relicParts == null || p.relicParts.length < Part.values().length)
      p.relicParts = p.relicParts == null ? new int[Part.values().length] : Arrays.copyOf(p.relicParts, Part.values().length);
    return p.relicParts;
  }

  /** Rolls a part for one kill; true when it dropped (already added to the profile). */
  public static boolean roll(Profile p, Part part, int mode, RandomGenerator r) {
    if (r.nextDouble() >= chance(part, mode)) return false;
    parts(p)[part.ordinal()]++;
    return true;
  }

  public static boolean canForge(Profile p, Relic relic) {
    int[] have = parts(p);
    for (int i = 0; i < relic.recipe.length; i++) if (have[i] < relic.recipe[i]) return false;
    return p.money >= MONEY && p.dust >= DUST;
  }

  /** Forges the relic at the strength of the player's deepest mine. */
  public static String forge(Profile p, Relic relic, RandomGenerator r) {
    if (!canForge(p, relic)) return "Es fehlen noch Teile, " + MONEY + " $ oder " + DUST + " Schmiedestaub.";
    int[] have = parts(p);
    for (int i = 0; i < relic.recipe.length; i++) have[i] -= relic.recipe[i];
    p.money -= MONEY;
    p.dust -= DUST;
    Gear.Item i = Gear.roll(Math.max(0, p.zone), Gear.Rarity.MYTHIC, r);
    i.signature = relic.signature;
    i.name = relic.title;
    i.slot = relic.slot;
    i.style = relic.style;
    i.quality = 100;
    double power = Gear.power(Math.max(0, p.zone)) * Gear.Rarity.MYTHIC.factor * 1.3;
    if (relic.slot == Gear.Slot.WEAPON) {
      i.damage = power * 3.8;
      i.stagger += power * 5;
      i.crit = Math.max(i.crit, .12);
    } else {
      i.damage = 0;
      i.health = power * 2;
      i.defense = power * 5;
    }
    p.gear.add(i);
    p.discovered.add(relic.title);
    p.relicsForged++;
    return "RELIKT GESCHMIEDET: " + relic.title + " · " + relic.effect + " · liegt im Beutel";
  }

  // ---- effects, looked up from the equipped gear ----
  private static boolean wears(Profile p, Relic relic) {
    return Gear.hasEffect(p, relic.signature);
  }

  public static double posture(Profile p) {
    return wears(p, Relic.ERZFUERST) ? 1.6 : 1;
  }

  public static double hammerAbility(Profile p) {
    return wears(p, Relic.ERZFUERST) ? 1.5 : 1;
  }

  public static double lifesteal(Profile p) {
    return wears(p, Relic.GEWOELBESCHWUR) ? .04 : 0;
  }

  public static double bossDamage(Profile p) {
    return wears(p, Relic.TIEFENSEUFZER) ? 1.3 : 1;
  }

  public static double doubleShot(Profile p) {
    return wears(p, Relic.WALDLAEUFER) ? .25 : 0;
  }

  public static double damageTaken(Profile p) {
    return wears(p, Relic.WELTENSCHILD) ? .8 : 1;
  }
}
