package de.deepforge.ui;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.EquipmentLore;
import de.deepforge.game.Gear;
import de.deepforge.game.Profile;
import java.util.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class Items {
  private final NamespacedKey kind;
  private final DeepforgePlugin plugin;

  public Items(DeepforgePlugin plugin) {
    this.plugin = plugin;
    kind = new NamespacedKey(plugin, "kind");
  }

  public ItemStack model(Material base, String model, String title) {
    ItemStack item = new ItemStack(base);
    ItemMeta m = item.getItemMeta();
    m.itemName(Component.text(title, NamedTextColor.GOLD));
    m.setItemModel(new NamespacedKey("deepforge", model));
    item.setItemMeta(m);
    return item;
  }

  /**
   * Deepforge item models exist only in the resource pack. Players without it would see the
   * purple-black missing texture, so they get the plain base item (pickaxe, sword, compass …).
   */
  public ItemStack forViewer(ItemStack item, Player viewer) {
    if (item == null || viewer == null || plugin.packApplied(viewer) || !item.hasItemMeta()) return item;
    ItemMeta m = item.getItemMeta();
    NamespacedKey key = m.getItemModel();
    if (key == null || !key.getNamespace().equals("deepforge")) return item;
    m.setItemModel(null);
    item.setItemMeta(m);
    return item;
  }

  public void forViewer(org.bukkit.inventory.Inventory inventory, Player viewer) {
    for (ItemStack item : inventory.getContents()) forViewer(item, viewer);
  }

  public ItemStack button(Material base, String model, String title, String... lines) {
    ItemStack item = model(base, model, title);
    ItemMeta m = item.getItemMeta();
    m.lore(Arrays.stream(lines).map(l -> Component.text(l, NamedTextColor.GRAY)).toList());
    item.setItemMeta(m);
    return item;
  }

  private ItemStack kit(String type, Profile p, int zone) {
    if (type.equals("axe")) return axe(p);
    Material base =
        switch (type) {
          case "tool" -> Material.IRON_PICKAXE;
          case "sword" -> Material.IRON_SWORD;
          // A plain book: lobby/navigator plugins often react to compass clicks and teleport.
          default -> Material.BOOK;
        };
    String title =
        switch (type) {
          case "tool" -> "Dampfbohrer · Stufe " + p.tool;
          case "sword" -> "Grubenklinge · Stufe " + p.sword;
          default -> "Bergbau-Handbuch · Rechtsklick";
        };
    Gear.Item gear =
        type.equals("sword")
            ? Gear.equipped(p, Gear.Slot.WEAPON)
            : type.equals("tool") ? Gear.equipped(p, Gear.Slot.TOOL) : null;
    if (gear != null) title = gear.name + " +" + gear.level + " · " + gear.rarity.title;
    ItemStack i =
        model(
            base,
            type.equals("tool")
                ? "drill"
                : type.equals("sword")
                    ? (gear == null ? "weapon_sword" : gear.model())
                    : "handbook",
            title);
    ItemMeta m = i.getItemMeta();
    m.setUnbreakable(true);
    m.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
    m.lore(
        EquipmentLore.lines(type, p, zone).stream()
            .map(
                line ->
                    Component.text(line, NamedTextColor.GRAY)
                        .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false))
            .toList());
    m.getPersistentDataContainer().set(kind, PersistentDataType.STRING, type);
    // Fixed drill component; the real ore speed comes from the player's attributes.
    if (type.equals("tool")) drillComponent(m);
    i.setItemMeta(m);
    return i;
  }

  public String kind(ItemStack item) {
    return item == null || !item.hasItemMeta()
        ? ""
        : item.getItemMeta()
            .getPersistentDataContainer()
            .getOrDefault(kind, PersistentDataType.STRING, "");
  }

  private ItemStack axe(Profile p) {
    ItemStack item = new ItemStack(Material.IRON_AXE);
    ItemMeta m = item.getItemMeta();
    m.itemName(Component.text("Forstaxt · Stufe " + p.axe, NamedTextColor.GOLD));
    m.setUnbreakable(true);
    m.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
    m.lore(
        List.of(
                "Holzfällen: Linksklick halten am Stamm",
                "Fällt den ganzen markierten Baum",
                "Tempo: " + de.deepforge.game.Forestry.speed(p) + "×",
                String.format(
                    Locale.GERMAN,
                    "Holzglück: %.1f× · %.0f %% Doppelernte",
                    de.deepforge.game.OreYield.multiplier(p.woodLuck),
                    de.deepforge.game.Forestry.doubleChance(p) * 100),
                "Holzlager: " + de.deepforge.game.Forestry.capacity(p),
                "Sägewerk östlich des Dorfes · /df forestry")
            .stream()
            .map(v -> Component.text(v, NamedTextColor.GRAY))
            .toList());
    m.getPersistentDataContainer().set(kind, PersistentDataType.STRING, "axe");
    var tool = m.getTool();
    tool.setDefaultMiningSpeed((float) de.deepforge.game.Forestry.speed(p));
    tool.setDamagePerBlock(0);
    tool.setRules(new ArrayList<>());
    for (Material log : List.of(Material.OAK_LOG, Material.BIRCH_LOG, Material.SPRUCE_LOG))
      tool.addRule(log, (float) de.deepforge.game.Forestry.speed(p), true);
    m.setTool(tool);
    item.setItemMeta(m);
    return item;
  }

  public void axeSpeed(Player player, double speed) {
    ItemStack item = player.getInventory().getItemInMainHand();
    if (!kind(item).equals("axe")) return;
    ItemMeta meta = item.getItemMeta();
    if (Math.abs(meta.getTool().getDefaultMiningSpeed() - speed) < .001) return;
    var tool = meta.getTool();
    tool.setDefaultMiningSpeed((float) speed);
    tool.setRules(new ArrayList<>());
    for (Material log : List.of(Material.OAK_LOG, Material.BIRCH_LOG, Material.SPRUCE_LOG))
      tool.addRule(log, (float) speed, true);
    meta.setTool(tool);
    item.setItemMeta(meta);
  }

  public boolean refresh(Player player, Profile p) {
    int current = plugin.mines().zoneAt(p, player.getLocation());
    int zone = current < 0 ? p.zone : current;
    int missing = 0;
    for (String type : List.of("tool", "sword", "book", "axe")) {
      boolean found = false;
      for (ItemStack i : player.getInventory().getStorageContents())
        if (kind(i).equals(type)) found = true;
      if (!found) missing++;
    }
    long free =
        Arrays.stream(player.getInventory().getStorageContents())
            .filter(i -> i == null || i.getType().isAir())
            .count();
    if (free < missing) return false;
    for (String type : List.of("tool", "sword", "book", "axe")) {
      int first = -1;
      for (int s = 0; s < 36; s++)
        if (kind(player.getInventory().getItem(s)).equals(type)) {
          if (first == -1) first = s;
          else player.getInventory().setItem(s, null);
        }
      ItemStack fresh = forViewer(kit(type, p, zone), player);
      // Unchanged items are left alone: replacing the held drill would restart the ore.
      if (first >= 0) {
        if (!fresh.equals(player.getInventory().getItem(first)))
          player.getInventory().setItem(first, fresh);
      } else player.getInventory().addItem(fresh);
    }
    refreshHealing(player, p);
    return true;
  }

  public void refreshHealing(Player player, Profile p) {
    int first = -1;
    for (int slot = 0; slot < player.getInventory().getSize(); slot++) {
      if (!kind(player.getInventory().getItem(slot)).equals("heal")) continue;
      if (first < 0 && (slot < 36 || slot == 40)) first = slot;
      else player.getInventory().setItem(slot, null);
    }
    if (kind(player.getItemOnCursor()).equals("heal")) player.setItemOnCursor(null);
    ItemStack crystal = forViewer(healingCrystal(p), player);
    if (first >= 0) player.getInventory().setItem(first, crystal);
    else if (player.getInventory().firstEmpty() >= 0) player.getInventory().addItem(crystal);
  }

  public ItemStack healingCrystal(Profile p) {
    ItemStack crystal =
        button(
            Material.AMETHYST_SHARD,
            "healing_crystal",
            "Lebenssplitter · " + p.healingCharges + "/12",
            "Heilt 4 LP + 35 % deines maximalen Lebens",
            "20 Sekunden Abklingzeit · auch im Bosskampf",
            "Vorrat bleibt beim Ausloggen erhalten",
            "Monsterbeute · Dungeon-Sieg: +2",
            "Rechtsklick oder /df heal");
    crystal.setAmount(Math.max(1, p.healingCharges));
    ItemMeta meta = crystal.getItemMeta();
    meta.getPersistentDataContainer().set(kind, PersistentDataType.STRING, "heal");
    crystal.setItemMeta(meta);
    return crystal;
  }

  public void removeKit(Player player) {
    for (int i = 0; i < player.getInventory().getSize(); i++)
      if (!kind(player.getInventory().getItem(i)).isEmpty()) player.getInventory().setItem(i, null);
  }

  /** Native tool component keeps vanilla hold-to-mine and crack animation. */
  /**
   * Drill speed lives on the player's block-break-speed attribute. The drill item itself stays
   * unchanged: any change to the held item makes the client restart the block being broken, which
   * used to reset the ore whenever the overcharge boost ended or the zone changed.
   */
  public void miningSpeed(Player player, float speed) {
    ItemStack item = player.getInventory().getItemInMainHand();
    boolean tool = kind(item).equals("tool");
    if (!tool) {
      resetMiningSpeed(player);
      return;
    }
    breakSpeed(player, speed);
    ItemMeta meta = item.getItemMeta();
    var component = meta.getTool();
    if (Math.abs(component.getDefaultMiningSpeed() - 1) < .001
        && component.getDamagePerBlock() == 0
        && component.getRules().size() == 1
        && Math.abs(component.getRules().getFirst().getSpeed() - ORE_RULE) < .001) return;
    drillComponent(meta);
    item.setItemMeta(meta);
  }

  /**
   * Ore veins get a tool speed just above 1 so vanilla adds the mining-efficiency attribute to
   * them – and only to them. Every other block keeps the normal hand speed.
   */
  static final float ORE_RULE = 1.01f;

  private static void drillComponent(ItemMeta meta) {
    var component = meta.getTool();
    component.setDefaultMiningSpeed(1);
    component.setDamagePerBlock(0);
    component.setRules(new ArrayList<>());
    component.addRule(Material.NOTE_BLOCK, ORE_RULE, true);
    meta.setTool(component);
  }

  /** Vanilla break speed again, e.g. when leaving Deepforge. */
  public void resetMiningSpeed(Player player) {
    set(player, org.bukkit.attribute.Attribute.BLOCK_BREAK_SPEED, 1);
    set(player, org.bukkit.attribute.Attribute.MINING_EFFICIENCY, 0);
  }

  /**
   * Ore speed = (ORE_RULE + mining efficiency) × block break speed. Efficiency only applies to
   * blocks the drill is "correct" for (ore veins), so stone and walls stay slow. Speeds below 1
   * use the break-speed factor instead, which only ever slows things down.
   */
  private static void breakSpeed(Player player, double value) {
    if (value >= ORE_RULE) {
      set(player, org.bukkit.attribute.Attribute.MINING_EFFICIENCY, value - ORE_RULE);
      set(player, org.bukkit.attribute.Attribute.BLOCK_BREAK_SPEED, 1);
    } else {
      set(player, org.bukkit.attribute.Attribute.MINING_EFFICIENCY, 0);
      set(player, org.bukkit.attribute.Attribute.BLOCK_BREAK_SPEED, Math.min(1, value / ORE_RULE));
    }
  }

  private static void set(Player player, org.bukkit.attribute.Attribute type, double value) {
    var attribute = player.getAttribute(type);
    if (attribute != null && Math.abs(attribute.getBaseValue() - value) > .001)
      attribute.setBaseValue(value);
  }
}
