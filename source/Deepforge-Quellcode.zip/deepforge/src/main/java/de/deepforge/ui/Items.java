package de.deepforge.ui;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.EquipmentLore;
import de.deepforge.game.Gear;
import de.deepforge.game.Profile;
import java.util.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class Items {
  private final NamespacedKey kind;
  private final DeepforgePlugin plugin;

  public Items(DeepforgePlugin plugin) {
    this.plugin = plugin;
    kind = new NamespacedKey(plugin, "kind");
  }

  public ItemStack model(Material base, String model, String title) {
    ItemStack item = new ItemStack(base);
    ItemMeta m = item.getItemMeta();
    m.itemName(Component.text(title, NamedTextColor.GOLD));
    m.setItemModel(new NamespacedKey("deepforge", model));
    item.setItemMeta(m);
    return item;
  }

  public ItemStack button(Material base, String model, String title, String... lines) {
    ItemStack item = model(base, model, title);
    ItemMeta m = item.getItemMeta();
    m.lore(Arrays.stream(lines).map(l -> Component.text(l, NamedTextColor.GRAY)).toList());
    item.setItemMeta(m);
    return item;
  }

  private ItemStack kit(String type, Profile p, int zone) {
    if (type.equals("axe")) return axe(p);
    Material base =
        switch (type) {
          case "tool" -> Material.IRON_PICKAXE;
          case "sword" -> Material.IRON_SWORD;
          default -> Material.COMPASS;
        };
    String title =
        switch (type) {
          case "tool" -> "Dampfbohrer · Stufe " + p.tool;
          case "sword" -> "Grubenklinge · Stufe " + p.sword;
          default -> "Bergbau-Handbuch · Rechtsklick";
        };
    Gear.Item gear =
        type.equals("sword")
            ? Gear.equipped(p, Gear.Slot.WEAPON)
            : type.equals("tool") ? Gear.equipped(p, Gear.Slot.TOOL) : null;
    if (gear != null) title = gear.name + " +" + gear.level + " · " + gear.rarity.title;
    ItemStack i =
        model(
            base,
            type.equals("tool")
                ? "drill"
                : type.equals("sword")
                    ? (gear == null ? "weapon_sword" : gear.model())
                    : "handbook",
            title);
    ItemMeta m = i.getItemMeta();
    m.setUnbreakable(true);
    m.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
    m.lore(
        EquipmentLore.lines(type, p, zone).stream()
            .map(
                line ->
                    Component.text(line, NamedTextColor.GRAY)
                        .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false))
            .toList());
    m.getPersistentDataContainer().set(kind, PersistentDataType.STRING, type);
    i.setItemMeta(m);
    return i;
  }

  public String kind(ItemStack item) {
    return item == null || !item.hasItemMeta()
        ? ""
        : item.getItemMeta()
            .getPersistentDataContainer()
            .getOrDefault(kind, PersistentDataType.STRING, "");
  }

  private ItemStack axe(Profile p) {
    ItemStack item = new ItemStack(Material.IRON_AXE);
    ItemMeta m = item.getItemMeta();
    m.itemName(Component.text("Forstaxt · Stufe " + p.axe, NamedTextColor.GOLD));
    m.setUnbreakable(true);
    m.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
    m.lore(
        List.of(
                "Holzfällen: Linksklick halten am Stamm",
                "Fällt den ganzen markierten Baum",
                "Tempo: " + de.deepforge.game.Forestry.speed(p) + "×",
                String.format(
                    Locale.GERMAN,
                    "Holzglück: %.1f× · %.0f %% Doppelernte",
                    de.deepforge.game.OreYield.multiplier(p.woodLuck),
                    de.deepforge.game.Forestry.doubleChance(p) * 100),
                "Holzlager: " + de.deepforge.game.Forestry.capacity(p),
                "Sägewerk östlich des Dorfes · /df forestry")
            .stream()
            .map(v -> Component.text(v, NamedTextColor.GRAY))
            .toList());
    m.getPersistentDataContainer().set(kind, PersistentDataType.STRING, "axe");
    var tool = m.getTool();
    tool.setDefaultMiningSpeed((float) de.deepforge.game.Forestry.speed(p));
    tool.setDamagePerBlock(0);
    tool.setRules(new ArrayList<>());
    for (Material log : List.of(Material.OAK_LOG, Material.BIRCH_LOG, Material.SPRUCE_LOG))
      tool.addRule(log, (float) de.deepforge.game.Forestry.speed(p), true);
    m.setTool(tool);
    item.setItemMeta(m);
    return item;
  }

  public void axeSpeed(Player player, double speed) {
    ItemStack item = player.getInventory().getItemInMainHand();
    if (!kind(item).equals("axe")) return;
    ItemMeta meta = item.getItemMeta();
    if (Math.abs(meta.getTool().getDefaultMiningSpeed() - speed) < .001) return;
    var tool = meta.getTool();
    tool.setDefaultMiningSpeed((float) speed);
    tool.setRules(new ArrayList<>());
    for (Material log : List.of(Material.OAK_LOG, Material.BIRCH_LOG, Material.SPRUCE_LOG))
      tool.addRule(log, (float) speed, true);
    meta.setTool(tool);
    item.setItemMeta(meta);
  }

  public boolean refresh(Player player, Profile p) {
    int current = plugin.mines().zoneAt(p, player.getLocation());
    int zone = current < 0 ? p.zone : current;
    int missing = 0;
    for (String type : List.of("tool", "sword", "book", "axe")) {
      boolean found = false;
      for (ItemStack i : player.getInventory().getStorageContents())
        if (kind(i).equals(type)) found = true;
      if (!found) missing++;
    }
    long free =
        Arrays.stream(player.getInventory().getStorageContents())
            .filter(i -> i == null || i.getType().isAir())
            .count();
    if (free < missing) return false;
    for (String type : List.of("tool", "sword", "book", "axe")) {
      int first = -1;
      for (int s = 0; s < 36; s++)
        if (kind(player.getInventory().getItem(s)).equals(type)) {
          if (first == -1) first = s;
          else player.getInventory().setItem(s, null);
        }
      if (first >= 0) player.getInventory().setItem(first, kit(type, p, zone));
      else player.getInventory().addItem(kit(type, p, zone));
    }
    refreshHealing(player, p);
    return true;
  }

  public void refreshHealing(Player player, Profile p) {
    int first = -1;
    for (int slot = 0; slot < player.getInventory().getSize(); slot++) {
      if (!kind(player.getInventory().getItem(slot)).equals("heal")) continue;
      if (first < 0 && (slot < 36 || slot == 40)) first = slot;
      else player.getInventory().setItem(slot, null);
    }
    if (kind(player.getItemOnCursor()).equals("heal")) player.setItemOnCursor(null);
    ItemStack crystal = healingCrystal(p);
    if (first >= 0) player.getInventory().setItem(first, crystal);
    else if (player.getInventory().firstEmpty() >= 0) player.getInventory().addItem(crystal);
  }

  public ItemStack healingCrystal(Profile p) {
    ItemStack crystal =
        button(
            Material.AMETHYST_SHARD,
            "healing_crystal",
            "Lebenssplitter · " + p.healingCharges + "/12",
            "Heilt 4 LP + 35 % deines maximalen Lebens",
            "20 Sekunden Abklingzeit · auch im Bosskampf",
            "Vorrat bleibt beim Ausloggen erhalten",
            "Monsterbeute · Dungeon-Sieg: +2",
            "Rechtsklick oder /df heal");
    crystal.setAmount(Math.max(1, p.healingCharges));
    ItemMeta meta = crystal.getItemMeta();
    meta.getPersistentDataContainer().set(kind, PersistentDataType.STRING, "heal");
    crystal.setItemMeta(meta);
    return crystal;
  }

  public void removeKit(Player player) {
    for (int i = 0; i < player.getInventory().getSize(); i++)
      if (!kind(player.getInventory().getItem(i)).isEmpty()) player.getInventory().setItem(i, null);
  }

  /** Native tool component keeps vanilla hold-to-mine and crack animation. */
  public void miningSpeed(Player player, float speed) {
    ItemStack item = player.getInventory().getItemInMainHand();
    if (!kind(item).equals("tool")) return;
    ItemMeta meta = item.getItemMeta();
    var tool = meta.getTool();
    if (Math.abs(tool.getDefaultMiningSpeed() - speed) < .001 && tool.getDamagePerBlock() == 0)
      return;
    tool.setDefaultMiningSpeed(speed);
    tool.setDamagePerBlock(0);
    tool.setRules(new ArrayList<>());
    tool.addRule(Material.NOTE_BLOCK, speed, true);
    meta.setTool(tool);
    item.setItemMeta(meta);
  }
}
