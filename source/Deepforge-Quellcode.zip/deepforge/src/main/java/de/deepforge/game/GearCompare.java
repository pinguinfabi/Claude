package de.deepforge.game;

import java.util.*;

/** Stat-by-stat comparison of a loot item with what is equipped in the same slot. */
public final class GearCompare {
  private GearCompare() {}

  private static double lvl(Gear.Item i) {
    return 1 + i.level * .08;
  }

  private static String f(double v) {
    String s = String.format(Locale.GERMANY, "%.1f", Math.abs(v));
    return s.endsWith(",0") ? s.substring(0, s.length() - 2) : s;
  }

  /** e.g. "▲ Schaden +2,1 · ▼ Leben −4 · ▲ Krit +1 %"; null when both are identical. */
  public static String diff(Gear.Item item, Gear.Item equipped) {
    if (equipped == null) return "▲ Slot ist leer – jede Ausrüstung hilft";
    if (equipped.id.equals(item.id)) return null;
    List<String> parts = new ArrayList<>();
    add(parts, "Schaden", item.damage * lvl(item) - equipped.damage * lvl(equipped), "");
    add(parts, "Leben", item.health * lvl(item) - equipped.health * lvl(equipped), "");
    add(parts, "Rüstung", item.defense * lvl(item) - equipped.defense * lvl(equipped), "");
    add(parts, "Krit", (item.crit - equipped.crit) * 100, " %");
    add(parts, "Tempo", item.haste - equipped.haste, "");
    add(parts, "Haltung", item.stagger - equipped.stagger, "");
    add(parts, "Abbau", (item.mining - equipped.mining) * 100, " %");
    add(parts, "Extra-Erz", (item.yield - equipped.yield) * 100, " %");
    add(parts, "Brennstoff", (item.efficiency - equipped.efficiency) * 100, " %");
    return parts.isEmpty() ? "= gleiche Werte wie ausgerüstet" : String.join(" · ", parts);
  }

  private static void add(List<String> parts, String label, double delta, String unit) {
    if (Math.abs(delta) < .05) return;
    parts.add((delta > 0 ? "▲ " : "▼ ") + label + " " + (delta > 0 ? "+" : "−") + f(delta) + unit);
  }
}
