package de.deepforge.game;

import java.util.*;

/** Stat-by-stat comparison of a loot item with what is equipped in the same slot. */
public final class GearCompare {
  private GearCompare() {}

  private static double lvl(Gear.Item i) {
    return (1 + i.level * .08) * Gear.starForged(i);
  }

  /** An item's stat including what its socketed runes add (0.9.3). */
  private static double total(Gear.Item i, double base, Runes.Kind kind) {
    return base + Runes.itemBonus(i, kind);
  }

  private static String f(double v) {
    String s = String.format(Locale.GERMANY, "%.1f", Math.abs(v));
    return s.endsWith(",0") ? s.substring(0, s.length() - 2) : s;
  }

  /** e.g. "▲ Schaden +2,1 · ▼ Leben −4 · ▲ Krit +1 %"; null when both are identical. */
  public static String diff(Gear.Item item, Gear.Item equipped) {
    if (equipped == null) return "▲ Slot ist leer – jede Ausrüstung hilft";
    if (equipped.id.equals(item.id)) return null;
    List<String> parts = new ArrayList<>();
    add(parts, "Schaden", total(item, item.damage * lvl(item), Runes.Kind.KRAFT) - total(equipped, equipped.damage * lvl(equipped), Runes.Kind.KRAFT), "");
    add(parts, "Leben", total(item, item.health * lvl(item), Runes.Kind.LEBEN) - total(equipped, equipped.health * lvl(equipped), Runes.Kind.LEBEN), "");
    add(parts, "Rüstung", total(item, item.defense * lvl(item), Runes.Kind.STEIN) - total(equipped, equipped.defense * lvl(equipped), Runes.Kind.STEIN), "");
    add(parts, "Krit", (total(item, item.crit, Runes.Kind.GLUECK) - total(equipped, equipped.crit, Runes.Kind.GLUECK)) * 100, " %");
    add(
        parts,
        "Krit-Schaden",
        (critMultiplier(item) - critMultiplier(equipped)) * 100,
        " %");
    add(parts, "Tempo", total(item, item.haste, Runes.Kind.WIND) - total(equipped, equipped.haste, Runes.Kind.WIND), "");
    add(parts, "Haltung", item.stagger - equipped.stagger, "");
    add(parts, "Abbau", (total(item, item.mining, Runes.Kind.TIEFE) - total(equipped, equipped.mining, Runes.Kind.TIEFE)) * 100, " %");
    add(parts, "Extra-Erz", (item.yield - equipped.yield) * 100, " %");
    add(parts, "Brennstoff", (item.efficiency - equipped.efficiency) * 100, " %");
    return parts.isEmpty() ? "= gleiche Werte wie ausgerüstet" : String.join(" · ", parts);
  }

  /** Weapons compare their full crit multiplier (type base + roll), other gear only the roll. */
  private static double critMultiplier(Gear.Item i) {
    return (i.slot == Gear.Slot.WEAPON ? Gear.baseCritDamage(i) : 0) + i.critDamage;
  }

  private static void add(List<String> parts, String label, double delta, String unit) {
    if (Math.abs(delta) < .05) return;
    parts.add((delta > 0 ? "▲ " : "▼ ") + label + " " + (delta > 0 ? "+" : "−") + f(delta) + unit);
  }
}
