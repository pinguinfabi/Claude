package de.deepforge.game;

import java.util.*;

/** Stat-by-stat comparison of a loot item with what is equipped in the same slot. */
public final class GearCompare {
  private GearCompare() {}

  private static double lvl(Gear.Item i) {
    return (1 + i.level * .08) * Gear.starForged(i);
  }

  private static double rune(Gear.Item i, Runes.Kind kind) {
    return Runes.itemBonus(i, kind);
  }

  private static String f(double v) {
    String s = String.format(Locale.GERMANY, "%.1f", Math.abs(v));
    return s.endsWith(",0") ? s.substring(0, s.length() - 2) : s;
  }

  /**
   * e.g. "▲ Schaden +2,1 (+1,5 Runen) · ▼ Leben −4 · ▲ Krit +1 %"; null when both are identical.
   * 0.22.3: the item's own values and what its runes add are shown apart, so a better item with
   * fewer runes is recognisable (runes can be moved to it).
   */
  public static String diff(Gear.Item item, Gear.Item equipped) {
    if (equipped == null) return "▲ Slot ist leer – jede Ausrüstung hilft";
    if (equipped.id.equals(item.id)) return null;
    List<String> parts = new ArrayList<>();
    add(parts, "Schaden", item.damage * lvl(item) - equipped.damage * lvl(equipped), runeDelta(item, equipped, Runes.Kind.KRAFT, 1), "");
    add(parts, "Leben", item.health * lvl(item) - equipped.health * lvl(equipped), runeDelta(item, equipped, Runes.Kind.LEBEN, 1), "");
    add(parts, "Rüstung", item.defense * lvl(item) - equipped.defense * lvl(equipped), runeDelta(item, equipped, Runes.Kind.STEIN, 1), "");
    add(parts, "Krit", (item.crit - equipped.crit) * 100, runeDelta(item, equipped, Runes.Kind.GLUECK, 100), " %");
    add(parts, "Krit-Schaden", (critMultiplier(item) - critMultiplier(equipped)) * 100, 0, " %");
    add(parts, "Tempo", item.haste - equipped.haste, runeDelta(item, equipped, Runes.Kind.WIND, 1), "");
    add(parts, "Haltung", item.stagger - equipped.stagger, 0, "");
    add(parts, "Abbau", (item.mining - equipped.mining) * 100, runeDelta(item, equipped, Runes.Kind.TIEFE, 100), " %");
    add(parts, "Extra-Erz", (item.yield - equipped.yield) * 100, 0, " %");
    add(parts, "Brennstoff", (item.efficiency - equipped.efficiency) * 100, 0, " %");
    return parts.isEmpty() ? "= gleiche Werte wie ausgerüstet" : String.join(" · ", parts);
  }

  private static double runeDelta(Gear.Item item, Gear.Item equipped, Runes.Kind kind, double scale) {
    return (rune(item, kind) - rune(equipped, kind)) * scale;
  }

  /** Weapons compare their full crit multiplier (type base + roll), other gear only the roll. */
  private static double critMultiplier(Gear.Item i) {
    return (i.slot == Gear.Slot.WEAPON ? Gear.baseCritDamage(i) : 0) + i.critDamage;
  }

  private static void add(List<String> parts, String label, double base, double runes, String unit) {
    if (Math.abs(base) < .05 && Math.abs(runes) < .05) return;
    double total = base + runes;
    String arrow = total > .049 ? "▲ " : total < -.049 ? "▼ " : "= ";
    String value = Math.abs(base) < .05 ? "±0" : (base > 0 ? "+" : "−") + f(base) + unit;
    String rune = Math.abs(runes) < .05 ? "" : " (" + (runes > 0 ? "+" : "−") + f(runes) + unit + " Runen)";
    parts.add(arrow + label + " " + value + rune);
  }
}
