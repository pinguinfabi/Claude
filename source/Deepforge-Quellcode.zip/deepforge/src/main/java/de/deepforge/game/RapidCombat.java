package de.deepforge.game;

/** Every click hits; weapon tempo contributes to damage instead of imposing a waiting period. */
public final class RapidCombat {
  private RapidCombat() {}

  public static final int BOSS_TIME_MINUTES = 12;

  public static boolean canBuildPosture(long tick, long brokenUntil) {
    return brokenUntil == 0 || tick >= brokenUntil + 120;
  }

  public static double damage(Gear.Stats stats) {
    return stats.damage() * .65 * stats.speed() / 1.6;
  }

  public static double posture(Gear.Stats stats) {
    return stats.stagger() * .45;
  }

  public static double bossHealth(int zone, int mode) {
    // Deeper bosses also got tougher relative to the old linear curve (x1.15 in zone 1, x1.75 in 7).
    return (700 + zone * 380) * (1 + mode * .65) * 12.8 * (1.15 + zone * .1);
  }

  /** Hits closer together than this (game ticks) keep the combo alive. */
  public static final int COMBO_WINDOW_TICKS = 40;

  public static int nextCombo(int combo, long lastHitTick, long now) {
    return combo > 0 && now - lastHitTick <= COMBO_WINDOW_TICKS ? Math.min(999, combo + 1) : 1;
  }

  /** +3 % per chained hit after the first, capped at +30 % from the 11th hit on. */
  public static double comboMultiplier(int combo) {
    return 1 + .03 * Math.min(10, Math.max(0, combo - 1));
  }

  /** Group health factor of party dungeons (matches DungeonRules.health). */
  public static double partyHealth(int players) {
    return 1 + (Math.max(1, players) - 1) * .85;
  }
}
