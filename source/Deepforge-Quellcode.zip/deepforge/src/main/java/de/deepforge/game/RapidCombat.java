package de.deepforge.game;

/** Every click hits; weapon tempo contributes to damage instead of imposing a waiting period. */
public final class RapidCombat {
  private RapidCombat() {}

  public static final int BOSS_TIME_MINUTES = 12;

  public static boolean canBuildPosture(long tick, long brokenUntil) {
    return brokenUntil == 0 || tick >= brokenUntil + 120;
  }

  public static double damage(Gear.Stats stats) {
    return stats.damage() * .65 * stats.speed() / 1.6;
  }

  public static double posture(Gear.Stats stats) {
    return stats.stagger() * .45;
  }

  public static double bossHealth(int zone, int mode) {
    return (700 + zone * 380) * (1 + mode * .65) * 12.8;
  }

  /** Same group factors as party dungeons (DungeonRules). */
  public static double partyHealth(int players) {
    return 1 + (Math.max(1, players) - 1) * .85;
  }

  public static double partyDamage(int players) {
    return 1 + (Math.max(1, players) - 1) * .06;
  }
}
