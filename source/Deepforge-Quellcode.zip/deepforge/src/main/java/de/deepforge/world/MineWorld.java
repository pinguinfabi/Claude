package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import java.nio.file.*;
import java.util.*;
import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.block.data.type.NoteBlock;
import org.bukkit.entity.*;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class MineWorld {
  private final DeepforgePlugin plugin;
  private World world;
  private final Map<Integer, List<Runnable>> waiting = new HashMap<>();
  private final ArrayDeque<Runnable> blocks = new ArrayDeque<>();
  private final Set<Integer> ready = new HashSet<>();
  private final NamespacedKey decorKey, decorOwner;
  private CampBlueprint camp;
  private final MineBlueprint[] minePlans = new MineBlueprint[Zone.COUNT];
  private final Map<String, org.bukkit.block.data.BlockData> palette = new HashMap<>();

  public MineWorld(DeepforgePlugin plugin) {
    this.plugin = plugin;
    decorKey = new NamespacedKey(plugin, "decor");
    decorOwner = new NamespacedKey(plugin, "decor_owner");
  }

  /** One camp and one mine for the whole server; progress displays stay per player. */
  public boolean shared() {
    return plugin.getConfig().getBoolean("game.shared-world", true);
  }

  /** In the shared world a decoration showing personal progress is only visible to its owner. */
  public void personal(Profile p, Entity e) {
    if (!shared() || p.id == null) return;
    e.getPersistentDataContainer().set(decorOwner, PersistentDataType.STRING, p.id);
    e.setVisibleByDefault(false);
    Player viewer = Bukkit.getPlayer(UUID.fromString(p.id));
    if (viewer != null) viewer.showEntity(plugin, e);
  }

  public boolean belongs(Entity e, Profile p) {
    PersistentDataContainer data = e.getPersistentDataContainer();
    if (data.getOrDefault(decorKey, PersistentDataType.INTEGER, -1) != plugin.plot(p)) return false;
    String owner = data.get(decorOwner, PersistentDataType.STRING);
    return owner == null || owner.equals(p.id);
  }

  public void clearPersonal(UUID id) {
    for (Entity e : world.getEntities())
      if (id.toString().equals(e.getPersistentDataContainer().get(decorOwner, PersistentDataType.STRING)))
        e.remove();
  }

  public void init() throws Exception {
    String name = plugin.getConfig().getString("world-name", "deepforge");
    if (!name.matches("[a-zA-Z0-9_-]+")) throw new IllegalArgumentException("Invalid world-name");
    Path dir = Bukkit.getWorldContainer().toPath().resolve(name),
        marker = dir.resolve("deepforge-owned.txt");
    if (Files.exists(dir.resolve("level.dat")) && !Files.exists(marker))
      throw new IllegalStateException("Existing world is not owned by Deepforge: " + name);
    Files.createDirectories(dir);
    Files.writeString(marker, "Deepforge game world v1\n");
    world =
        new WorldCreator(name)
            .generator(
                new ChunkGenerator() {
                  @Override
                  public boolean shouldGenerateNoise() {
                    return false;
                  }

                  @Override
                  public boolean shouldGenerateSurface() {
                    return false;
                  }

                  @Override
                  public boolean shouldGenerateCaves() {
                    return false;
                  }

                  @Override
                  public boolean shouldGenerateDecorations() {
                    return false;
                  }

                  @Override
                  public boolean shouldGenerateMobs() {
                    return false;
                  }

                  @Override
                  public boolean shouldGenerateStructures() {
                    return false;
                  }
                })
            .createWorld();
    if (world == null) throw new IllegalStateException("World creation failed");
    world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
    world.setGameRule(GameRule.NATURAL_REGENERATION, false);
    world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
    world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
    world.setGameRule(GameRule.MOB_GRIEFING, false);
    world.setGameRule(GameRule.DO_FIRE_TICK, false);
    world.setTime(9000);
    world.setSpawnLocation(0, 201, 0);
    for (int x = -8; x <= 8; x++)
      for (int z = -8; z <= 8; z++)
        world.getBlockAt(x, 200, z).setType(Material.DEEPSLATE_BRICKS, false);
    // Persistent custom entities are reconstructed from player state, never duplicated.
    world.getEntities().stream()
        .filter(e -> e.getPersistentDataContainer().has(decorKey))
        .forEach(Entity::remove);
    Bukkit.getScheduler()
        .runTaskTimer(
            plugin,
            () -> {
              int n = plugin.getConfig().getInt("game.build-blocks-per-tick", 1400);
              for (int i = 0; i < n && !blocks.isEmpty(); i++) blocks.poll().run();
            },
            1,
            1);
  }

  public World world() {
    return world;
  }

  public boolean contains(Location l) {
    return l.getWorld().equals(world);
  }

  public int ox(Profile p) {
    return 512 + (plugin.plot(p) % 16) * 320;
  }

  public int oz(Profile p) {
    return (plugin.plot(p) / 16) * 320;
  }

  public Location home(Profile p) {
    return new Location(world, ox(p) + 0.5, 201, oz(p) - 5.5, 0, 0);
  }

  public Location local(Profile p, double x, double y, double z) {
    return new Location(world, ox(p) + x, y, oz(p) + z);
  }

  /**
   * 0.9.0: the first seven mines stack below the camp; the ten deep mines (Gebiet 8–17) stack in
   * a second shaft {@link #DEEP_X} blocks east of it, under the forest.
   */
  public static final int DEEP_X = 110;

  /**
   * Layout marker under the camp. v3 was netherite (7 mines); v4 (0.9.0: 17 redesigned mines)
   * rebuilds every mine once on the next visit.
   */
  // 0.17.0: mines v5 (timbered drifts, individual floor plans), camp v3 (the village quarter).
  private static final Material MINES_VERSION = Material.CRYING_OBSIDIAN;
  private static final Material CAMP_VERSION = Material.NETHERITE_BLOCK;

  public static int shift(int zone) {
    return zone >= Zone.FIRST_DEEP ? DEEP_X : 0;
  }

  public int floor(int zone) {
    return 168 - (zone >= Zone.FIRST_DEEP ? zone - Zone.FIRST_DEEP : zone) * 24;
  }

  /** A point of a mine: blueprint x/z plus height {@code h} above the mine's floor. */
  public Location mine(Profile p, int zone, double x, double h, double z) {
    return local(p, x + shift(zone), floor(zone) + h, z);
  }

  public Location entrance(Profile p, int zone) {
    return mine(p, zone, MineBlueprint.ENTRY_X + .5, 1, MineBlueprint.ENTRY_Z + .5);
  }

  public Location arena(Profile p, int zone) {
    return mine(p, zone, MineBlueprint.BOSS_X + .5, 1, MineBlueprint.BOSS_Z + .5);
  }

  public boolean owns(Profile p, Location l) {
    return contains(l)
        && (Math.abs(l.getX() - ox(p)) <= 86
            || l.getY() < 190 && Math.abs(l.getX() - ox(p) - DEEP_X) <= 56
            || l.getY() >= 190
                && l.getX() - ox(p) > 86
                && l.getX() - ox(p) <= 126
                && l.getZ() - oz(p) >= -39
                && l.getZ() - oz(p) <= 38)
        && l.getZ() - oz(p) >= -80
        && l.getZ() - oz(p) <= 102;
  }

  public int zoneAt(Profile p, Location l) {
    if (!owns(p, l)) return -1;
    int dz = l.getBlockZ() - oz(p);
    if (dz < MineBlueprint.MIN_Z || dz > MineBlueprint.MAX_Z) return -1;
    for (int z = 0; z < Zone.COUNT; z++) {
      int x = l.getBlockX() - ox(p) - shift(z);
      if (x >= MineBlueprint.MIN_X
          && x <= MineBlueprint.MAX_X
          && l.getY() >= floor(z) + MineBlueprint.MIN_H
          && l.getY() < floor(z) + MineBlueprint.MAX_H + 1) return z;
    }
    return -1;
  }

  public MineBlueprint blueprint(int zone) {
    if (minePlans[zone] == null) minePlans[zone] = MineBlueprint.create(zone);
    return minePlans[zone];
  }

  public boolean orePosition(Profile p, Location l) {
    int zone = zoneAt(p, l);
    return zone >= 0
        && blueprint(zone)
            .isOre(
                l.getBlockX() - ox(p) - shift(zone),
                l.getBlockY() - floor(zone),
                l.getBlockZ() - oz(p));
  }

  public void ensure(Profile owner, Runnable done) {
    // Frozen plot (no id => no party lookup): a party change mid-build cannot move the build.
    Profile p = new Profile();
    p.plot = plugin.plot(owner);
    if (ready.contains(plugin.plot(p))) {
      done.run();
      return;
    }
    if (waiting.containsKey(plugin.plot(p))) {
      waiting.get(plugin.plot(p)).add(done);
      return;
    }
    waiting.put(plugin.plot(p), new ArrayList<>(List.of(done)));
    // Surface and underground have independent, commit-last layout markers.
    Material version = world.getBlockAt(ox(p), 199, oz(p)).getType();
    if (version != CAMP_VERSION) {
      boolean existingMine =
          version == Material.EMERALD_BLOCK
              || version == Material.GOLD_BLOCK
              || version == Material.DIAMOND_BLOCK;
      // Validate the entire palette before changing anything in the world.
      if (camp == null) {
        camp = CampBlueprint.create();
        for (String state : new HashSet<>(camp.blocks().values()))
          palette.put(state, Bukkit.createBlockData("minecraft:" + state));
        plugin
            .getLogger()
            .info(
                "Camp v3 blueprint: "
                    + camp.blocks().size()
                    + " blocks, "
                    + palette.size()
                    + " states validated.");
      }
      // GOLD records that the underground rooms already exist during interrupted migration.
      if (existingMine) world.getBlockAt(ox(p), 199, oz(p)).setType(Material.GOLD_BLOCK, false);
      generateCamp(p);

      blocks.add(
          () -> {
            world.getBlockAt(ox(p), 199, oz(p)).setType(CAMP_VERSION, false);
            plugin
                .getLogger()
                .info("Camp v3 ready for plot " + plugin.plot(p) + "; surface layout complete.");
          });
    }
    if (version != CAMP_VERSION
        || world.getBlockAt(ox(p), 198, oz(p)).getType() != MINES_VERSION) {
      generateMines(p);
      blocks.add(
          () -> {
            world.getBlockAt(ox(p), 198, oz(p)).setType(MINES_VERSION, false);
            plugin
                .getLogger()
                .info(
                    "Mines v5 ready for plot "
                        + plugin.plot(p)
                        + "; "
                        + Zone.COUNT
                        + " cave networks complete; profile preserved.");
          });
    }
    if (world.getBlockAt(ox(p), 197, oz(p)).getType() != Material.LAPIS_BLOCK) {
      CampBlueprint entrance = CampBlueprint.dungeonEntrance();
      for (String state : new HashSet<>(entrance.blocks().values()))
        palette.computeIfAbsent(state, v -> Bukkit.createBlockData("minecraft:" + v));
      Iterator<Map.Entry<Integer, String>> additions = entrance.blocks().entrySet().iterator();
      blocks.add(
          new Runnable() {
            public void run() {
              var entry = additions.next();
              int k = entry.getKey();
              world
                  .getBlockAt(
                      ox(p) + CampBlueprint.x(k), CampBlueprint.y(k), oz(p) + CampBlueprint.z(k))
                  .setBlockData(palette.get(entry.getValue()), false);
              if (additions.hasNext()) blocks.addFirst(this);
            }
          });
      blocks.add(() -> world.getBlockAt(ox(p), 197, oz(p)).setType(Material.LAPIS_BLOCK, false));
    }
    blocks.add(
        () -> {
          ready.add(plugin.plot(p));
          decorate(owner);
          // 0.23.0: admin changes from the build mode go back on top of the rebuilt plot.
          if (plugin.build() != null) plugin.build().applyWorld(p);
          List<Runnable> callbacks = waiting.remove(plugin.plot(p));
          callbacks.forEach(Runnable::run);
        });
  }

  private void generateMines(Profile p) {
    // Validate every zone before applying the first block; the cursor respects the existing tick
    // budget.
    for (int zone = 0; zone < Zone.COUNT; zone++) {
      MineBlueprint plan = blueprint(zone);
      for (String state : plan.palette())
        palette.computeIfAbsent(state, value -> Bukkit.createBlockData("minecraft:" + value));
      plugin
          .getLogger()
          .info(
              "Mine "
                  + zone
                  + ": "
                  + plan.size()
                  + " blocks, "
                  + plan.ores().size()
                  + " exposed ore blocks; palette validated.");
    }
    for (int zone = 0; zone < Zone.COUNT; zone++) {
      final int z = zone;
      MineBlueprint plan = blueprint(z);
      blocks.add(
          new Runnable() {
            int cursor;

            @Override
            public void run() {
              MineBlueprint.Point at = MineBlueprint.point(cursor);
              world
                  .getBlockAt(ox(p) + shift(z) + at.x(), floor(z) + at.h(), oz(p) + at.z())
                  .setBlockData(palette.get(plan.state(cursor)), false);
              if (++cursor < plan.size()) blocks.addFirst(this);
            }
          });
    }
  }

  public boolean isReady(Profile p) {
    return ready.contains(plugin.plot(p));
  }

  public boolean needsMigration(Profile p) {
    Material marker = world.getBlockAt(ox(p), 199, oz(p)).getType();
    return marker == Material.EMERALD_BLOCK
        || marker == Material.GOLD_BLOCK
        || marker == Material.DIAMOND_BLOCK
        || (marker == CAMP_VERSION
            && (world.getBlockAt(ox(p), 198, oz(p)).getType() != MINES_VERSION
                || world.getBlockAt(ox(p), 197, oz(p)).getType() != Material.LAPIS_BLOCK));
  }

  private void generateCamp(Profile p) {
    Iterator<Map.Entry<Integer, String>> it = camp.blocks().entrySet().iterator();
    // A single cursor keeps the build queue bounded even for large terrain blueprints.
    blocks.add(
        new Runnable() {
          @Override
          public void run() {
            var entry = it.next();
            int key = entry.getKey();
            // Do not overwrite the in-progress migration marker with terrain.
            if (!(CampBlueprint.x(key) == 0
                && CampBlueprint.y(key) == 199
                && CampBlueprint.z(key) == 0))
              world
                  .getBlockAt(
                      ox(p) + CampBlueprint.x(key),
                      CampBlueprint.y(key),
                      oz(p) + CampBlueprint.z(key))
                  .setBlockData(palette.get(entry.getValue()), false);
            if (it.hasNext()) blocks.addFirst(this);
          }
        });
  }

  public static Material wall(int z) {
    return switch (z) {
      case 1 -> Material.CALCITE;
      case 2 -> Material.MOSS_BLOCK;
      case 3 -> Material.PRISMARINE_BRICKS;
      case 4 -> Material.POLISHED_BLACKSTONE_BRICKS;
      case 5 -> Material.CHISELED_STONE_BRICKS;
      case 6 -> Material.END_STONE_BRICKS;
      default -> Material.DEEPSLATE_BRICKS;
    };
  }

  public static NoteBlock oreData(int zone) {
    NoteBlock n = (NoteBlock) Bukkit.createBlockData(Material.NOTE_BLOCK);
    n.setInstrument(Instrument.BASS_GUITAR);
    n.setNote(new Note(zone));
    n.setPowered(false);
    return n;
  }

  public void decorate(Profile p) {
    for (Entity e : world.getEntities()) if (belongs(e, p)) e.remove();
    for (CampBlueprint.Station s : CampBlueprint.STATIONS) {
      String detail =
          switch (s.id()) {
            case "gear" -> "Ausrüstung verbessern";
            case "storage" -> "Kapazität " + p.stockCapacity();
            case "factory" -> "Stufe " + p.furnace;
            case "crew" -> p.workers.size() + " / " + p.workerSlots() + " Arbeiter";
            case "trade" -> "Verkaufen & Aufträge";
            case "dungeon" -> "Solo & Party · Level " + DungeonRules.level(p, p.zone);
            default -> "Gebiete betreten";
          };
      label(p, s.x() + .5, 203.1, s.z() + .5, s.title() + "\n" + detail + " · Rechtsklick");
    }
    if (plugin.adventure() != null) plugin.adventure().decorate(p);
    label(p, 0.5, 212, 33, "D E E P F O R G E\nBERGWERK 01");
    label(p, .5, 208, -53, "R U N E N G E W Ö L B E\nDrei Hallen · Rätsel · Bossbeute");
    label(p, 3.5, 203, -36, "GEWÖLBE ↑\nDem dunklen Steinweg folgen");
    model(p, -21, 201, 19, "machine_crusher", 1.8f);
    for (int i = 0; i < Math.max(1, Math.min(3, p.furnace)); i++)
      model(p, -26 + i * 2, 201, 22, "machine_furnace", 1.3f);
    for (int i = 0; i <= Math.min(6, p.warehouse); i++)
      model(p, 26 + (i % 3) * 1.4, 201 + (i / 3), -10, "crate", 1.1f);
    for (int z = 0; z < Zone.COUNT; z++) {
      int dx = shift(z);
      model(p, dx + 2.5, floor(z) + 1, 35.5, "crate", .8f);
      label(p, dx + 2.5, floor(z) + 2.5, 35.5, "GRUBENDEPOT\nErzlieferung ins Betriebslager");
      label(
          p,
          dx + MineBlueprint.ALTAR_X + .5,
          floor(z) + 3,
          MineBlueprint.ALTAR_Z + .5,
          "BOSS · " + Zone.at(z).title);
      label(
          p,
          dx + MineBlueprint.LIFT_X + .5,
          floor(z) + 3,
          MineBlueprint.LIFT_Z + .5,
          "AUFZUG · Zum Dorf");
    }
  }

  private void label(Profile p, double x, double y, double z, String name) {
    Entity shown =
        world.spawn(
        local(p, x, y, z),
        TextDisplay.class,
        e -> {
          e.text(
              Component.text(name, net.kyori.adventure.text.format.NamedTextColor.GOLD)
                  .font(net.kyori.adventure.key.Key.key("minecraft", "default")));
          e.setAlignment(TextDisplay.TextAlignment.CENTER);
          e.setBackgroundColor(Color.fromARGB(175, 19, 26, 29));
          e.setShadowed(true);
          e.setLineWidth(260);
          e.setViewRange(0.65f);
          e.setBillboard(Display.Billboard.CENTER);
          e.setPersistent(false);
          e.getPersistentDataContainer().set(decorKey, PersistentDataType.INTEGER, plugin.plot(p));
        });
    personal(p, shown);
  }

  private void model(Profile p, double x, double y, double z, String key, float scale) {
    Entity shown =
        world.spawn(
        local(p, x, y, z),
        ItemDisplay.class,
        e -> {
          ItemStack item = plugin.items().model(Material.PAPER, key, key);
          e.setItemStack(item);
          e.setTransformation(
              new Transformation(
                  new Vector3f(0, scale / 2, 0),
                  new Quaternionf(),
                  new Vector3f(scale),
                  new Quaternionf()));
          e.setPersistent(false);
          e.getPersistentDataContainer().set(decorKey, PersistentDataType.INTEGER, plugin.plot(p));
        });
    personal(p, shown);
  }

  public String station(Profile p, Location l) {
    if (!owns(p, l)) return null;
    int x = l.getBlockX() - ox(p), z = l.getBlockZ() - oz(p);
    if (l.getBlockY() == 201) {
      for (CampBlueprint.Station s : CampBlueprint.STATIONS)
        if (x == s.x() && z == s.z()) return s.id();
    }
    int zone = zoneAt(p, l);
    if (zone >= 0) x -= shift(zone);
    if (zone >= 0 && l.getBlockY() == floor(zone) + 1) {
      if (x == MineBlueprint.LIFT_X && z == MineBlueprint.LIFT_Z) return "home";
      if (x == MineBlueprint.ALTAR_X && z == MineBlueprint.ALTAR_Z) return "boss";
    }
    return null;
  }
}
