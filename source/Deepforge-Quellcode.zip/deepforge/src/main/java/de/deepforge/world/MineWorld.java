package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import java.nio.file.*;
import java.util.*;
import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.block.data.type.NoteBlock;
import org.bukkit.entity.*;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class MineWorld {
  private final DeepforgePlugin plugin;
  private World world;
  private final Map<Integer, List<Runnable>> waiting = new HashMap<>();
  private final ArrayDeque<Runnable> blocks = new ArrayDeque<>();
  private final Set<Integer> ready = new HashSet<>();
  private final NamespacedKey decorKey;
  private CampBlueprint camp;
  private final MineBlueprint[] minePlans = new MineBlueprint[7];
  private final Map<String, org.bukkit.block.data.BlockData> palette = new HashMap<>();

  public MineWorld(DeepforgePlugin plugin) {
    this.plugin = plugin;
    decorKey = new NamespacedKey(plugin, "decor");
  }

  public void init() throws Exception {
    String name = plugin.getConfig().getString("world-name", "deepforge");
    if (!name.matches("[a-zA-Z0-9_-]+")) throw new IllegalArgumentException("Invalid world-name");
    Path dir = Bukkit.getWorldContainer().toPath().resolve(name),
        marker = dir.resolve("deepforge-owned.txt");
    if (Files.exists(dir.resolve("level.dat")) && !Files.exists(marker))
      throw new IllegalStateException("Existing world is not owned by Deepforge: " + name);
    Files.createDirectories(dir);
    Files.writeString(marker, "Deepforge game world v1\n");
    world =
        new WorldCreator(name)
            .generator(
                new ChunkGenerator() {
                  @Override
                  public boolean shouldGenerateNoise() {
                    return false;
                  }

                  @Override
                  public boolean shouldGenerateSurface() {
                    return false;
                  }

                  @Override
                  public boolean shouldGenerateCaves() {
                    return false;
                  }

                  @Override
                  public boolean shouldGenerateDecorations() {
                    return false;
                  }

                  @Override
                  public boolean shouldGenerateMobs() {
                    return false;
                  }

                  @Override
                  public boolean shouldGenerateStructures() {
                    return false;
                  }
                })
            .createWorld();
    if (world == null) throw new IllegalStateException("World creation failed");
    world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
    world.setGameRule(GameRule.NATURAL_REGENERATION, false);
    world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
    world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
    world.setGameRule(GameRule.MOB_GRIEFING, false);
    world.setGameRule(GameRule.DO_FIRE_TICK, false);
    world.setTime(9000);
    world.setSpawnLocation(0, 201, 0);
    for (int x = -8; x <= 8; x++)
      for (int z = -8; z <= 8; z++)
        world.getBlockAt(x, 200, z).setType(Material.DEEPSLATE_BRICKS, false);
    // Persistent custom entities are reconstructed from player state, never duplicated.
    world.getEntities().stream()
        .filter(e -> e.getPersistentDataContainer().has(decorKey))
        .forEach(Entity::remove);
    Bukkit.getScheduler()
        .runTaskTimer(
            plugin,
            () -> {
              int n = plugin.getConfig().getInt("game.build-blocks-per-tick", 1400);
              for (int i = 0; i < n && !blocks.isEmpty(); i++) blocks.poll().run();
            },
            1,
            1);
  }

  public World world() {
    return world;
  }

  public boolean contains(Location l) {
    return l.getWorld().equals(world);
  }

  public int ox(Profile p) {
    return 512 + (plugin.plot(p) % 16) * 320;
  }

  public int oz(Profile p) {
    return (plugin.plot(p) / 16) * 320;
  }

  public Location home(Profile p) {
    return new Location(world, ox(p) + 0.5, 201, oz(p) - 5.5, 0, 0);
  }

  public Location local(Profile p, double x, double y, double z) {
    return new Location(world, ox(p) + x, y, oz(p) + z);
  }

  public int floor(int zone) {
    return 168 - zone * 24;
  }

  public Location entrance(Profile p, int zone) {
    return local(p, MineBlueprint.ENTRY_X + .5, floor(zone) + 1, MineBlueprint.ENTRY_Z + .5);
  }

  public Location arena(Profile p, int zone) {
    return local(p, MineBlueprint.BOSS_X + .5, floor(zone) + 1, MineBlueprint.BOSS_Z + .5);
  }

  public boolean owns(Profile p, Location l) {
    return contains(l)
        && (Math.abs(l.getX() - ox(p)) <= 86
            || l.getY() >= 190
                && l.getX() - ox(p) > 86
                && l.getX() - ox(p) <= 126
                && l.getZ() - oz(p) >= -39
                && l.getZ() - oz(p) <= 38)
        && l.getZ() - oz(p) >= -80
        && l.getZ() - oz(p) <= 102;
  }

  public int zoneAt(Profile p, Location l) {
    if (!owns(p, l)) return -1;
    int x = l.getBlockX() - ox(p), dz = l.getBlockZ() - oz(p);
    if (x < MineBlueprint.MIN_X
        || x > MineBlueprint.MAX_X
        || dz < MineBlueprint.MIN_Z
        || dz > MineBlueprint.MAX_Z) return -1;
    for (int z = 0; z < 7; z++)
      if (l.getY() >= floor(z) + MineBlueprint.MIN_H
          && l.getY() < floor(z) + MineBlueprint.MAX_H + 1) return z;
    return -1;
  }

  public MineBlueprint blueprint(int zone) {
    if (minePlans[zone] == null) minePlans[zone] = MineBlueprint.create(zone);
    return minePlans[zone];
  }

  public boolean orePosition(Profile p, Location l) {
    int zone = zoneAt(p, l);
    return zone >= 0
        && blueprint(zone)
            .isOre(l.getBlockX() - ox(p), l.getBlockY() - floor(zone), l.getBlockZ() - oz(p));
  }

  public void ensure(Profile owner, Runnable done) {
    // Frozen plot (no id => no party lookup): a party change mid-build cannot move the build.
    Profile p = new Profile();
    p.plot = plugin.plot(owner);
    if (ready.contains(plugin.plot(p))) {
      done.run();
      return;
    }
    if (waiting.containsKey(plugin.plot(p))) {
      waiting.get(plugin.plot(p)).add(done);
      return;
    }
    waiting.put(plugin.plot(p), new ArrayList<>(List.of(done)));
    // Surface and underground have independent, commit-last layout markers.
    Material version = world.getBlockAt(ox(p), 199, oz(p)).getType();
    if (version != Material.DIAMOND_BLOCK) {
      boolean existingMine = version == Material.EMERALD_BLOCK || version == Material.GOLD_BLOCK;
      // Validate the entire palette before changing anything in the world.
      if (camp == null) {
        camp = CampBlueprint.create();
        for (String state : new HashSet<>(camp.blocks().values()))
          palette.put(state, Bukkit.createBlockData("minecraft:" + state));
        plugin
            .getLogger()
            .info(
                "Camp v2 blueprint: "
                    + camp.blocks().size()
                    + " blocks, "
                    + palette.size()
                    + " states validated.");
      }
      // GOLD records that the underground rooms already exist during interrupted migration.
      if (existingMine) world.getBlockAt(ox(p), 199, oz(p)).setType(Material.GOLD_BLOCK, false);
      generateCamp(p);

      blocks.add(
          () -> {
            world.getBlockAt(ox(p), 199, oz(p)).setType(Material.DIAMOND_BLOCK, false);
            plugin
                .getLogger()
                .info("Camp v2 ready for plot " + plugin.plot(p) + "; surface layout complete.");
          });
    }
    if (version != Material.DIAMOND_BLOCK
        || world.getBlockAt(ox(p), 198, oz(p)).getType() != Material.NETHERITE_BLOCK) {
      generateMines(p);
      blocks.add(
          () -> {
            world.getBlockAt(ox(p), 198, oz(p)).setType(Material.NETHERITE_BLOCK, false);
            plugin
                .getLogger()
                .info(
                    "Mines v3 ready for plot "
                        + plugin.plot(p)
                        + "; 7 cave networks complete; profile preserved.");
          });
    }
    if (world.getBlockAt(ox(p), 197, oz(p)).getType() != Material.LAPIS_BLOCK) {
      CampBlueprint entrance = CampBlueprint.dungeonEntrance();
      for (String state : new HashSet<>(entrance.blocks().values()))
        palette.computeIfAbsent(state, v -> Bukkit.createBlockData("minecraft:" + v));
      Iterator<Map.Entry<Integer, String>> additions = entrance.blocks().entrySet().iterator();
      blocks.add(
          new Runnable() {
            public void run() {
              var entry = additions.next();
              int k = entry.getKey();
              world
                  .getBlockAt(
                      ox(p) + CampBlueprint.x(k), CampBlueprint.y(k), oz(p) + CampBlueprint.z(k))
                  .setBlockData(palette.get(entry.getValue()), false);
              if (additions.hasNext()) blocks.addFirst(this);
            }
          });
      blocks.add(() -> world.getBlockAt(ox(p), 197, oz(p)).setType(Material.LAPIS_BLOCK, false));
    }
    blocks.add(
        () -> {
          ready.add(plugin.plot(p));
          decorate(owner);
          List<Runnable> callbacks = waiting.remove(plugin.plot(p));
          callbacks.forEach(Runnable::run);
        });
  }

  private void generateMines(Profile p) {
    // Validate every zone before applying the first block; the cursor respects the existing tick
    // budget.
    for (int zone = 0; zone < 7; zone++) {
      MineBlueprint plan = blueprint(zone);
      for (String state : plan.palette())
        palette.computeIfAbsent(state, value -> Bukkit.createBlockData("minecraft:" + value));
      plugin
          .getLogger()
          .info(
              "Mine "
                  + zone
                  + ": "
                  + plan.size()
                  + " blocks, "
                  + plan.ores().size()
                  + " exposed ore blocks; palette validated.");
    }
    for (int zone = 0; zone < 7; zone++) {
      final int z = zone;
      MineBlueprint plan = blueprint(z);
      blocks.add(
          new Runnable() {
            int cursor;

            @Override
            public void run() {
              MineBlueprint.Point at = MineBlueprint.point(cursor);
              world
                  .getBlockAt(ox(p) + at.x(), floor(z) + at.h(), oz(p) + at.z())
                  .setBlockData(palette.get(plan.state(cursor)), false);
              if (++cursor < plan.size()) blocks.addFirst(this);
            }
          });
    }
  }

  public boolean isReady(Profile p) {
    return ready.contains(plugin.plot(p));
  }

  public boolean needsMigration(Profile p) {
    Material marker = world.getBlockAt(ox(p), 199, oz(p)).getType();
    return marker == Material.EMERALD_BLOCK
        || marker == Material.GOLD_BLOCK
        || (marker == Material.DIAMOND_BLOCK
            && (world.getBlockAt(ox(p), 198, oz(p)).getType() != Material.NETHERITE_BLOCK
                || world.getBlockAt(ox(p), 197, oz(p)).getType() != Material.LAPIS_BLOCK));
  }

  private void generateCamp(Profile p) {
    Iterator<Map.Entry<Integer, String>> it = camp.blocks().entrySet().iterator();
    // A single cursor keeps the build queue bounded even for large terrain blueprints.
    blocks.add(
        new Runnable() {
          @Override
          public void run() {
            var entry = it.next();
            int key = entry.getKey();
            // Do not overwrite the in-progress migration marker with terrain.
            if (!(CampBlueprint.x(key) == 0
                && CampBlueprint.y(key) == 199
                && CampBlueprint.z(key) == 0))
              world
                  .getBlockAt(
                      ox(p) + CampBlueprint.x(key),
                      CampBlueprint.y(key),
                      oz(p) + CampBlueprint.z(key))
                  .setBlockData(palette.get(entry.getValue()), false);
            if (it.hasNext()) blocks.addFirst(this);
          }
        });
  }

  public static Material wall(int z) {
    return switch (z) {
      case 1 -> Material.CALCITE;
      case 2 -> Material.MOSS_BLOCK;
      case 3 -> Material.PRISMARINE_BRICKS;
      case 4 -> Material.POLISHED_BLACKSTONE_BRICKS;
      case 5 -> Material.CHISELED_STONE_BRICKS;
      case 6 -> Material.END_STONE_BRICKS;
      default -> Material.DEEPSLATE_BRICKS;
    };
  }

  public static NoteBlock oreData(int zone) {
    NoteBlock n = (NoteBlock) Bukkit.createBlockData(Material.NOTE_BLOCK);
    n.setInstrument(Instrument.BASS_GUITAR);
    n.setNote(new Note(zone));
    n.setPowered(false);
    return n;
  }

  public void decorate(Profile p) {
    for (Entity e : world.getEntities())
      if (e.getPersistentDataContainer().getOrDefault(decorKey, PersistentDataType.INTEGER, -1)
          == plugin.plot(p)) e.remove();
    for (CampBlueprint.Station s : CampBlueprint.STATIONS) {
      String detail =
          switch (s.id()) {
            case "gear" -> "Ausrüstung verbessern";
            case "storage" -> "Kapazität " + p.stockCapacity();
            case "factory" -> "Stufe " + p.furnace;
            case "crew" -> p.workers.size() + " / " + p.workerSlots() + " Arbeiter";
            case "trade" -> "Verkaufen & Aufträge";
            case "dungeon" -> "Solo & Party · Level " + DungeonRules.level(p);
            default -> "Gebiete betreten";
          };
      label(p, s.x() + .5, 203.1, s.z() + .5, s.title() + "\n" + detail + " · Rechtsklick");
    }
    if (plugin.adventure() != null) plugin.adventure().decorate(p);
    label(p, 0.5, 212, 33, "D E E P F O R G E\nBERGWERK 01");
    label(p, .5, 208, -53, "R U N E N G E W Ö L B E\nDrei Hallen · Rätsel · Bossbeute");
    label(p, 3.5, 203, -36, "GEWÖLBE ↑\nDem dunklen Steinweg folgen");
    model(p, -21, 201, 19, "machine_crusher", 1.8f);
    for (int i = 0; i < Math.max(1, Math.min(3, p.furnace)); i++)
      model(p, -26 + i * 2, 201, 22, "machine_furnace", 1.3f);
    for (int i = 0; i <= Math.min(6, p.warehouse); i++)
      model(p, 26 + (i % 3) * 1.4, 201 + (i / 3), -10, "crate", 1.1f);
    for (int z = 0; z < 7; z++) {
      model(p, 2.5, floor(z) + 1, 35.5, "crate", .8f);
      label(p, 2.5, floor(z) + 2.5, 35.5, "GRUBENDEPOT\nErzlieferung ins Betriebslager");
      label(
          p,
          MineBlueprint.ALTAR_X + .5,
          floor(z) + 3,
          MineBlueprint.ALTAR_Z + .5,
          "BOSS · " + Zone.at(z).title);
      label(
          p,
          MineBlueprint.LIFT_X + .5,
          floor(z) + 3,
          MineBlueprint.LIFT_Z + .5,
          "AUFZUG · Zum Dorf");
    }
  }

  private void label(Profile p, double x, double y, double z, String name) {
    world.spawn(
        local(p, x, y, z),
        TextDisplay.class,
        e -> {
          e.text(
              Component.text(name, net.kyori.adventure.text.format.NamedTextColor.GOLD)
                  .font(net.kyori.adventure.key.Key.key("minecraft", "default")));
          e.setAlignment(TextDisplay.TextAlignment.CENTER);
          e.setBackgroundColor(Color.fromARGB(175, 19, 26, 29));
          e.setShadowed(true);
          e.setLineWidth(260);
          e.setViewRange(0.65f);
          e.setBillboard(Display.Billboard.CENTER);
          e.setPersistent(false);
          e.getPersistentDataContainer().set(decorKey, PersistentDataType.INTEGER, plugin.plot(p));
        });
  }

  private void model(Profile p, double x, double y, double z, String key, float scale) {
    world.spawn(
        local(p, x, y, z),
        ItemDisplay.class,
        e -> {
          ItemStack item = plugin.items().model(Material.PAPER, key, key);
          e.setItemStack(item);
          e.setTransformation(
              new Transformation(
                  new Vector3f(0, scale / 2, 0),
                  new Quaternionf(),
                  new Vector3f(scale),
                  new Quaternionf()));
          e.setPersistent(false);
          e.getPersistentDataContainer().set(decorKey, PersistentDataType.INTEGER, plugin.plot(p));
        });
  }

  public String station(Profile p, Location l) {
    if (!owns(p, l)) return null;
    int x = l.getBlockX() - ox(p), z = l.getBlockZ() - oz(p);
    if (l.getBlockY() == 201) {
      for (CampBlueprint.Station s : CampBlueprint.STATIONS)
        if (x == s.x() && z == s.z()) return s.id();
    }
    int zone = zoneAt(p, l);
    if (zone >= 0 && l.getBlockY() == floor(zone) + 1) {
      if (x == MineBlueprint.LIFT_X && z == MineBlueprint.LIFT_Z) return "home";
      if (x == MineBlueprint.ALTAR_X && z == MineBlueprint.ALTAR_Z) return "boss";
    }
    return null;
  }
}
