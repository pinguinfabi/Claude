package de.deepforge.game;

import java.time.LocalDate;
import java.time.temporal.IsoFields;
import java.util.*;

/**
 * Gilden: groups of up to 15 players with a shared bank, a Stützpunkt (buildings that give every
 * member a bonus) and three weekly guild tasks. Guild state lives outside the player profiles; a
 * profile only remembers its guild id.
 */
public final class Guilds {
  public static final long FOUND_COST = 25_000;
  public static final int BASE_MEMBERS = 5;

  public enum Rank {
    ANFUEHRER("Anführer"),
    OFFIZIER("Offizier"),
    MITGLIED("Mitglied");
    public final String title;

    Rank(String title) {
      this.title = title;
    }
  }

  public enum Building {
    KASERNE("Kaserne", "+2 % Schaden"),
    LAZARETT("Lazarett", "+4 Leben"),
    WERKSTATT("Werkstatt", "+3 % Abbautempo"),
    SCHATZKAMMER("Schatzkammer", "+2 % Verkaufspreis für Erz und Barren"),
    HALLE("Gildenhalle", "+2 Mitgliederplätze");
    public final String title, perLevel;

    Building(String title, String perLevel) {
      this.title = title;
      this.perLevel = perLevel;
    }
  }

  public static final int MAX_BUILDING = 5;

  public enum Task {
    ERZ("Erz abbauen", 1500),
    MONSTER("Minenmonster besiegen", 150),
    CHAMPIONS("Champions besiegen", 10),
    DUNGEONS("Dungeons gewinnen", 5),
    BAEUME("Bäume fällen", 60);
    public final String title;
    public final int perMember;

    Task(String title, int perMember) {
      this.title = title;
      this.perMember = perMember;
    }
  }

  public static final class Guild {
    public String id = UUID.randomUUID().toString(), name, tag, owner;
    public Map<String, Rank> members = new LinkedHashMap<>();
    public Map<String, String> names = new HashMap<>();
    public Set<String> invites = new HashSet<>();
    public long bank, xp, created;
    public int[] buildings = new int[Building.values().length];
    public String week = "";
    public List<String> tasks = new ArrayList<>();
    public long[] progress = new long[3], target = new long[3];
    public boolean[] done = new boolean[3];
    // Colour of the [TAG] in chat, name tags and tab list (key of COLORS; 0.16.1).
    public String color = "aqua";
  }

  /** Selectable guild colours: Minecraft colour name → German title. */
  public static final Map<String, String> COLORS = new LinkedHashMap<>();

  static {
    String[][] c = {
      {"aqua", "Türkis"}, {"dark_aqua", "Petrol"}, {"blue", "Blau"}, {"dark_blue", "Dunkelblau"},
      {"green", "Hellgrün"}, {"dark_green", "Grün"}, {"yellow", "Gelb"}, {"gold", "Gold"},
      {"red", "Rot"}, {"dark_red", "Dunkelrot"}, {"light_purple", "Rosa"}, {"dark_purple", "Lila"},
      {"white", "Weiß"}, {"gray", "Grau"}
    };
    for (String[] e : c) COLORS.put(e[0], e[1]);
  }

  /** Colour key of a guild, falling back to aqua for old saves or unknown values. */
  public static String color(Guild g) {
    return g == null || g.color == null || !COLORS.containsKey(g.color) ? "aqua" : g.color;
  }

  /** Changes the guild colour; accepts the key ("dark_red") or the German name ("Dunkelrot"). */
  public static String setColor(Guild g, String by, String wanted) {
    if (!canManage(g, by)) return "Nur Anführer und Offiziere können die Gildenfarbe ändern.";
    String key = null;
    for (Map.Entry<String, String> e : COLORS.entrySet())
      if (e.getKey().equalsIgnoreCase(wanted.replace(' ', '_'))
          || e.getValue().equalsIgnoreCase(wanted)
          || e.getValue().replace("ü", "ue").replace("ß", "ss").equalsIgnoreCase(wanted)) key = e.getKey();
    if (key == null) return "Unbekannte Farbe. Möglich: " + String.join(", ", COLORS.values()) + ".";
    if (key.equals(color(g))) return "Die Gilde hat schon die Farbe " + COLORS.get(key) + ".";
    g.color = key;
    return "Gildenfarbe ist jetzt " + COLORS.get(key) + ".";
  }

  /** In-memory guild registry (filled by the plugin from storage). */
  private static final Map<String, Guild> REGISTRY = new HashMap<>();

  private Guilds() {}

  public static void register(Guild g) {
    REGISTRY.put(g.id, g);
  }

  public static void unregister(String id) {
    REGISTRY.remove(id);
  }

  public static Collection<Guild> all() {
    return REGISTRY.values();
  }

  public static void clear() {
    REGISTRY.clear();
  }

  public static Guild of(Profile p) {
    if (p.guild == null) return null;
    Guild g = REGISTRY.get(p.guild);
    return g != null && g.members.containsKey(p.id) ? g : null;
  }

  public static Guild byTag(String tag) {
    for (Guild g : REGISTRY.values()) if (g.tag.equalsIgnoreCase(tag)) return g;
    return null;
  }

  public static int level(Guild g) {
    int level = 1;
    long xp = g.xp;
    while (xp >= 1000L * level) xp -= 1000L * level++;
    return level;
  }

  public static int maxMembers(Guild g) {
    return BASE_MEMBERS + 2 * g.buildings[Building.HALLE.ordinal()];
  }

  public static long buildingCost(Guild g, Building b) {
    long next = g.buildings[b.ordinal()] + 1;
    return 20_000L * next * next;
  }

  // --- membership ---
  public static String found(Profile p, String name, String tag, long now) {
    if (of(p) != null) return "Du bist schon in einer Gilde.";
    String cleanName = name == null ? "" : name.replaceAll("[^\\p{L}\\p{N} _-]", "").trim();
    String cleanTag = tag == null ? "" : tag.replaceAll("[^A-Za-z0-9]", "").toUpperCase(Locale.ROOT);
    if (cleanName.length() < 3 || cleanName.length() > 20) return "Gildenname: 3 bis 20 Zeichen.";
    if (cleanTag.length() < 2 || cleanTag.length() > 4) return "Kürzel: 2 bis 4 Buchstaben oder Zahlen.";
    for (Guild g : REGISTRY.values())
      if (g.name.equalsIgnoreCase(cleanName) || g.tag.equals(cleanTag))
        return "Name oder Kürzel ist schon vergeben.";
    if (p.money < FOUND_COST) return "Eine Gilde zu gründen kostet " + FOUND_COST + " $.";
    p.money -= FOUND_COST;
    Guild g = new Guild();
    g.name = cleanName;
    g.tag = cleanTag;
    g.owner = p.id;
    g.created = now;
    g.members.put(p.id, Rank.ANFUEHRER);
    g.names.put(p.id, p.name == null ? "?" : p.name);
    register(g);
    p.guild = g.id;
    return "Gilde „" + g.name + "“ [" + g.tag + "] gegründet!";
  }

  public static boolean canManage(Guild g, String id) {
    Rank r = g.members.get(id);
    return r == Rank.ANFUEHRER || r == Rank.OFFIZIER;
  }

  public static String invite(Guild g, String inviter, String target) {
    if (!canManage(g, inviter)) return "Nur Anführer und Offiziere können einladen.";
    if (g.members.containsKey(target)) return "Schon Mitglied.";
    if (g.members.size() >= maxMembers(g)) return "Die Gilde ist voll (" + maxMembers(g) + ") – Gildenhalle ausbauen.";
    g.invites.add(target);
    return "Einladung verschickt.";
  }

  public static String join(Profile p, Guild g) {
    if (of(p) != null) return "Du bist schon in einer Gilde.";
    if (!g.invites.contains(p.id)) return "Du hast keine Einladung von [" + g.tag + "].";
    if (g.members.size() >= maxMembers(g)) return "Die Gilde ist voll.";
    g.invites.remove(p.id);
    g.members.put(p.id, Rank.MITGLIED);
    g.names.put(p.id, p.name == null ? "?" : p.name);
    p.guild = g.id;
    return "Willkommen in „" + g.name + "“ [" + g.tag + "]!";
  }

  /** Leaving; the leader hands over to the longest officer/member, or the guild dissolves. */
  public static String leave(Profile p) {
    Guild g = of(p);
    if (g == null) return "Du bist in keiner Gilde.";
    g.members.remove(p.id);
    p.guild = null;
    if (g.members.isEmpty()) {
      unregister(g.id);
      return "Du hast die Gilde verlassen. Sie hatte keine Mitglieder mehr und wurde aufgelöst.";
    }
    if (p.id.equals(g.owner)) {
      String heir =
          g.members.entrySet().stream()
              .filter(e -> e.getValue() == Rank.OFFIZIER)
              .map(Map.Entry::getKey)
              .findFirst()
              .orElse(g.members.keySet().iterator().next());
      g.owner = heir;
      g.members.put(heir, Rank.ANFUEHRER);
      return "Du hast die Gilde verlassen. Neue Leitung: " + g.names.getOrDefault(heir, "?") + ".";
    }
    return "Du hast die Gilde „" + g.name + "“ verlassen.";
  }

  public static String kick(Guild g, String by, String target) {
    if (!canManage(g, by)) return "Nur Anführer und Offiziere können entfernen.";
    Rank r = g.members.get(target);
    if (r == null) return "Kein Mitglied.";
    if (r == Rank.ANFUEHRER || r == Rank.OFFIZIER && g.members.get(by) != Rank.ANFUEHRER)
      return "Diesen Rang kannst du nicht entfernen.";
    g.members.remove(target);
    return g.names.getOrDefault(target, "?") + " wurde aus der Gilde entfernt.";
  }

  public static String promote(Guild g, String by, String target, boolean up) {
    if (g.members.get(by) != Rank.ANFUEHRER) return "Nur der Anführer vergibt Ränge.";
    Rank r = g.members.get(target);
    if (r == null || r == Rank.ANFUEHRER) return "Das geht nicht.";
    g.members.put(target, up ? Rank.OFFIZIER : Rank.MITGLIED);
    return g.names.getOrDefault(target, "?") + " ist jetzt " + g.members.get(target).title + ".";
  }

  // --- bank & buildings ---
  public static String deposit(Profile p, long amount) {
    Guild g = of(p);
    if (g == null) return "Du bist in keiner Gilde.";
    if (amount <= 0) return "Betrag muss positiv sein.";
    if (p.money < amount) return "Nicht genug Geld.";
    p.money -= amount;
    g.bank = Math.addExact(g.bank, amount);
    p.guildContributed += amount;
    return amount + " $ in die Gildenkasse eingezahlt (Kasse: " + g.bank + " $).";
  }

  public static String build(Guild g, String by, Building b) {
    if (!canManage(g, by)) return "Nur Anführer und Offiziere bauen aus.";
    int lvl = g.buildings[b.ordinal()];
    if (lvl >= MAX_BUILDING) return b.title + " ist voll ausgebaut.";
    if (lvl >= level(g)) return "Benötigt Gildenlevel " + (lvl + 1) + " (Wochenaufträge erfüllen).";
    long cost = buildingCost(g, b);
    if (g.bank < cost) return "Die Kasse braucht " + cost + " $.";
    g.bank -= cost;
    g.buildings[b.ordinal()]++;
    return b.title + " auf Stufe " + g.buildings[b.ordinal()] + " ausgebaut: " + b.perLevel + " je Stufe für alle.";
  }

  public static int building(Profile p, Building b) {
    Guild g = of(p);
    return g == null ? 0 : g.buildings[b.ordinal()];
  }

  public static double damage(Profile p) {
    return 1 + .02 * building(p, Building.KASERNE);
  }

  public static double health(Profile p) {
    return 4 * building(p, Building.LAZARETT);
  }

  public static double mining(Profile p) {
    return 1 + .03 * building(p, Building.WERKSTATT);
  }

  public static double sale(Profile p) {
    return 1 + .02 * building(p, Building.SCHATZKAMMER);
  }

  // --- weekly tasks ---
  public static String week(LocalDate day) {
    return day.get(IsoFields.WEEK_BASED_YEAR) + "-W" + day.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR);
  }

  /** New tasks every ISO week; targets grow with the member count. */
  public static boolean ensureWeek(Guild g, LocalDate day) {
    String week = week(day);
    if (week.equals(g.week) && g.tasks.size() == 3) return false;
    g.week = week;
    List<Task> pool = new ArrayList<>(List.of(Task.values()));
    Collections.shuffle(pool, new Random((g.id + week).hashCode()));
    g.tasks = new ArrayList<>();
    for (int i = 0; i < 3; i++) {
      g.tasks.add(pool.get(i).name());
      g.target[i] = (long) pool.get(i).perMember * Math.max(1, g.members.size());
      g.progress[i] = 0;
      g.done[i] = false;
    }
    return true;
  }

  /** Counts a member's activity; returns the index of a task that was just completed, or -1. */
  public static int progress(Guild g, Task task, long amount, LocalDate day) {
    ensureWeek(g, day);
    for (int i = 0; i < 3; i++) {
      if (!g.tasks.get(i).equals(task.name()) || g.done[i]) continue;
      g.progress[i] = Math.min(g.target[i], g.progress[i] + amount);
      if (g.progress[i] >= g.target[i]) {
        g.done[i] = true;
        g.xp += 600;
        g.bank += 10_000L * Math.max(1, g.members.size());
        return i;
      }
    }
    return -1;
  }
}
