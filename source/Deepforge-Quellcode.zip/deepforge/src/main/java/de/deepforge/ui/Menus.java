package de.deepforge.ui;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import de.deepforge.world.GuildService;
import java.util.*;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;

public final class Menus implements Listener {
  public static final class Screen implements InventoryHolder {
    Inventory inv;
    final UUID owner;
    final String page;
    final Map<Integer, String> actions = new HashMap<>();

    Screen(UUID owner, String page) {
      this.owner = owner;
      this.page = page;
    }

    @Override
    public Inventory getInventory() {
      return inv;
    }
  }

  private final DeepforgePlugin plugin;
  private final Map<UUID, Long> lastClick = new HashMap<>();
  // Loot bag multi-select (shift-click) and the armed "really?" state of the bulk buttons.
  private final Map<UUID, Set<String>> selected = new HashMap<>();
  private final Map<UUID, Long> bulkArmed = new HashMap<>();

  public Menus(DeepforgePlugin plugin) {
    this.plugin = plugin;
  }

  private void b(
      Screen s,
      int slot,
      Material material,
      String model,
      String name,
      String action,
      String... lore) {
    ItemStack item =
        plugin.items().button(material, model == null ? "handbook" : model, name, lore);
    var meta = item.getItemMeta();
    if (model == null) meta.setItemModel(null);
    List<Component> lines = new ArrayList<>(meta.hasLore() ? meta.lore() : List.of());
    if (action != null) {
      lines.add(Component.empty());
      lines.add(
          Component.text(
              action.startsWith("open:") || action.startsWith("adventure:")
                  ? "▶ Linksklick: öffnen"
                  : "▶ Linksklick: ausführen",
              NamedTextColor.AQUA));
    }
    meta.itemName(Component.text(name, action == null ? NamedTextColor.GRAY : NamedTextColor.WHITE));
    meta.lore(lines);
    item.setItemMeta(meta);
    s.inv.setItem(slot, item);
    s.actions.remove(slot);
    if (action != null) s.actions.put(slot, action);
  }

  private static long unseen(Profile p) {
    return p.gear.stream().filter(i -> !p.seenGear.contains(i.id)).count();
  }

  public Component styledTitle(Player player, String label) {
    Component title = Component.text("DEEPFORGE · " + label, NamedTextColor.DARK_GRAY);
    if (player != null
        && plugin.packApplied(player)
        && plugin.getConfig().getBoolean("resource-pack.textured-menus"))
      return Component.text("\uE0FF\uE100\uE0FE", NamedTextColor.WHITE)
          .font(Key.key("deepforge", "ui"))
          .append(title);
    return title;
  }

  // 0.10.0: pages the player came through, so "Zurück" really goes to the previous menu.
  private final Map<UUID, Deque<String>> history = new HashMap<>();

  /** Opens a page from outside the menus (command, NPC, item): starts a new back history. */
  public void openFresh(Player player, String page) {
    history.remove(player.getUniqueId());
    open(player, page);
  }

  /** Where "Zurück" leads from this page: the last different page opened, else its parent. */
  private String backTarget(UUID owner, String page) {
    Deque<String> d = history.get(owner);
    if (d != null) for (String previous : d) if (!previous.equals(page)) return previous;
    return parent(page);
  }

  private void navigate(Player player, Screen from, String target) {
    Deque<String> d = history.computeIfAbsent(player.getUniqueId(), k -> new ArrayDeque<>());
    if (target.equals("main")) d.clear();
    else if (!target.equals(from.page)) {
      d.push(from.page);
      while (d.size() > 30) d.removeLast();
    }
    open(player, target);
  }

  private void goBack(Player player, Screen from) {
    Deque<String> d = history.get(player.getUniqueId());
    while (d != null && !d.isEmpty()) {
      String previous = d.pop();
      if (!previous.equals(from.page)) {
        open(player, previous);
        return;
      }
    }
    open(player, parent(from.page));
  }

  public void open(Player player, String page) {
    if (!plugin.playing(player)) return;
    Inventory inv = create(player, plugin.profile(player), page).inv;
    plugin.items().forViewer(inv, player);
    player.openInventory(inv);
  }

  private Screen create(Player player, Profile p, String page) {
    Screen s = new Screen(UUID.fromString(p.id), page);
    Component title = styledTitle(player, title(page));
    s.inv = Bukkit.createInventory(s, 54, title);
    b(
        s,
        4,
        Material.GOLD_INGOT,
        "coin",
        p.money + " $ · " + p.relics + " Relikte",
        null,
        "Rucksack " + p.bagUsed() + " / " + p.bagCapacity(),
        "Lager " + p.stockUsed() + " / " + p.stockCapacity());
    String back = backTarget(s.owner, page);
    b(s, 45, Material.ARROW, "back", "Zurück: " + title(back), "back", "Zum vorherigen Menü");
    b(s, 47, Material.BOOK, "handbook", "Hauptmenü", "open:main");
    List<String> helpLines = new ArrayList<>(List.of(help(page)));
    helpLines.add("Klick: passende Seite im Wiki öffnen");
    b(s, 53, Material.KNOWLEDGE_BOOK, "wiki", "Hilfe & Wiki: " + title(page), "wiki:" + WikiDialog.pageFor(page), helpLines.toArray(String[]::new));
    b(s, 49, Material.BARRIER, "close", "Schließen", "close");
    if (page.equals("main")) b(s, 45, Material.OAK_DOOR, null, "Zum Dorf zurückkehren", "home");
    if (page.startsWith("assignment/") || page.startsWith("specialty/")) {
      int index = Integer.parseInt(page.substring(page.indexOf('/') + 1));
      if (index < 0 || index >= p.workers.size()) return create(player, p, "crew");
      Profile.Worker worker = p.workers.get(index);
      b(
          s,
          4,
          Material.PLAYER_HEAD,
          "worker",
          worker.name + " · Auftrag wählen",
          null,
          "Eine Auswahl übernimmt den Auftrag sofort.");
      if (page.startsWith("assignment/") && worker.job == Profile.Job.LUMBERJACK) {
        Material[] logs = {Material.OAK_LOG, Material.BIRCH_LOG, Material.SPRUCE_LOG};
        for (int species = 0; species < Forestry.WOODS.length; species++) {
          boolean open = species <= p.forestTier;
          b(
              s,
              20 + species * 2,
              open ? logs[species] : Material.BARRIER,
              open ? null : "close",
              Forestry.WOODS[species] + (species == worker.zone ? " · AKTIV" : ""),
              open && species != worker.zone ? "assign:" + index + ":" + species : null,
              open
                  ? "Holzwert: " + Forestry.PRICES[species] + " $ pro Stamm"
                  : "Zuerst am Sägewerk freischalten");
        }
      } else if (page.startsWith("assignment/")) {
        for (int zone = 0; zone < Zone.COUNT; zone++)
          b(
              s,
              9 + zone,
              zone <= p.zone ? Material.MINECART : Material.BARRIER,
              zone <= p.zone ? "ore_" + Zone.at(zone).key : "close",
              Zone.at(zone).title + (zone == worker.zone ? " · AKTIV" : ""),
              zone <= p.zone && zone != worker.zone ? "assign:" + index + ":" + zone : null,
              zone > p.zone
                  ? "Zuerst dieses Gebiet im Aufzug freischalten"
                  : "Arbeiter diesem Gebiet zuweisen");
      } else {
        for (int spec = 0; spec < 3; spec++)
          b(
              s,
              20 + spec * 2,
              Material.BOOK,
              "handbook",
              new String[] {"Allrounder", "Ertrag", "Sparsam"}[spec]
                  + (spec == worker.specialization ? " · AKTIV" : ""),
              worker.level >= 2 && spec != worker.specialization
                  ? "spec:" + index + ":" + spec
                  : null,
              new String[] {
                    "Ausgewogene Arbeitsweise",
                    "+0,4 Waren pro Minute",
                    "25 % weniger Lohnanteil am Warenwert"
                  }
                  [spec],
              worker.level >= 2 ? "Kostenlos wechseln" : "Zuerst Arbeiter auf Stufe 2 ausbilden");
      }
      return s;
    }
    if (page.startsWith("loot/")) {
      int pageNumber = Math.max(0, Integer.parseInt(page.substring(5)));
      List<Gear.Item> ordered = Gear.sorted(p);
      int pages = Math.max(1, (ordered.size() + 26) / 27);
      pageNumber = Math.min(pageNumber, pages - 1);
      Set<String> picked = selected.computeIfAbsent(UUID.fromString(p.id), k -> new HashSet<>());
      picked.removeIf(id -> Gear.find(p, id) == null);
      for (int n = 0; n < 27 && pageNumber * 27 + n < ordered.size(); n++) {
        Gear.Item item = ordered.get(pageNumber * 27 + n);
        boolean on = picked.contains(item.id);
        List<String> lore = new ArrayList<>();
        if (on) lore.add("✔ AUSGEWÄHLT · Shift-Klick: abwählen");
        lore.addAll(Arrays.asList(gearLore(p, item)));
        lore.add(
            Gear.isProtected(p, item)
                ? "Geschützt (Favorit / angelegt / im Set)"
                : on ? "" : "Shift-Klick: auswählen");
        b(
            s,
            9 + n,
            on ? Material.LIME_STAINED_GLASS_PANE : Material.PAPER,
            on ? null : item.model(),
            (on ? "✔ " : "") + (p.seenGear.contains(item.id) ? "" : "✦ NEU · ") + item.name + " +" + item.level,
            "open:item/" + item.id,
            lore.toArray(String[]::new));
      }
      long money = 0, dust = 0;
      for (String id : picked) {
        Gear.Item item = Gear.find(p, id);
        if (item == null || Gear.isProtected(p, item)) continue;
        money += item.value();
        dust += 1 + item.rarity.ordinal() * 2L + item.level;
      }
      boolean armed = bulkArmed.getOrDefault(UUID.fromString(p.id), 0L) > System.currentTimeMillis();
      b(
          s,
          38,
          picked.isEmpty() ? Material.GRAY_DYE : Material.HOPPER,
          picked.isEmpty() ? null : "fuel",
          picked.isEmpty()
              ? "Ausgewählte zerlegen"
              : armed ? "WIRKLICH " + picked.size() + " zerlegen? Nochmal klicken" : picked.size() + " ausgewählte zerlegen",
          picked.isEmpty() ? null : "bulk:dust",
          picked.isEmpty() ? "Shift-Klick auf Gegenstände wählt sie aus" : "+" + dust + " Schmiedestaub",
          "Geschützte Teile werden übersprungen");
      b(
          s,
          40,
          picked.isEmpty() ? Material.GRAY_DYE : Material.GOLD_INGOT,
          picked.isEmpty() ? null : "coin",
          picked.isEmpty()
              ? "Ausgewählte verkaufen"
              : armed ? "WIRKLICH " + picked.size() + " verkaufen? Nochmal klicken" : picked.size() + " ausgewählte verkaufen",
          picked.isEmpty() ? null : "bulk:sell",
          picked.isEmpty() ? "Shift-Klick auf Gegenstände wählt sie aus" : "+" + money + " $",
          "Geschützte Teile werden übersprungen");
      b(
          s,
          42,
          Material.BARRIER,
          "close",
          "Auswahl aufheben",
          picked.isEmpty() ? null : "bulk:clear",
          picked.size() + " ausgewählt");
      b(
          s,
          36,
          Material.LIME_DYE,
          "select_all",
          "Ganze Seite auswählen",
          "bulk:page:" + pageNumber,
          "Wählt alle ungeschützten Teile dieser Seite aus");
      int sort = Math.floorMod(p.lootSort, Gear.SORTS.length);
      b(
          s,
          44,
          Material.COMPARATOR,
          "sort",
          "Sortierung: " + Gear.SORTS[sort],
          "lootsort",
          (sort == 0 ? "» " : "  ") + "Neueste zuerst",
          (sort == 1 ? "» " : "  ") + "Nach Art: Waffe, Schild, Rüstung, Schmuck … (je Art beste Rarität zuerst)",
          (sort == 2 ? "» " : "  ") + "Nach Rarität: mythisch → ungewöhnlich (je Rarität nach Art)",
          "Klick: nächste Sortierung");
      long fresh = unseen(p);
      b(
          s,
          4,
          Material.CHEST,
          "crate",
          "BEUTE · " + p.gear.size() + " Gegenstände" + (fresh > 0 ? " · " + fresh + " NEU" : ""),
          null,
          "Seite " + (pageNumber + 1) + " / " + pages,
          "Dauerhaft gespeichert; kein Inventarplatz nötig",
          "Schmiedestaub: " + p.dust + " (für Krit-Reroll, aus Zerlegen)");
      if (pageNumber > 0)
        b(s, 46, Material.ARROW, "back", "Vorherige Seite", "open:loot/" + (pageNumber - 1));
      if (pageNumber + 1 < pages)
        b(s, 52, Material.ARROW, "next", "Nächste Seite", "open:loot/" + (pageNumber + 1));
      b(s, 48, Material.ARMOR_STAND, "gear_chest", "Charakter", "open:character");
      b(s, 50, Material.BOOK, "handbook", "Beutebuch & Rezepte", "open:codex");
      b(
          s,
          51,
          Material.AMETHYST_CLUSTER,
          "rune_bag",
          "Runen · " + Runes.total(p) + " im Beutel",
          "open:runes",
          "Rune in einen Gegenstand setzen: Gegenstand anklicken → Sockel",
          "Runen addieren direkt auf die Grundwerte");
      // Items shown on this page count as seen from now on; the NEU marks stay until reopening.
      boolean changed = false;
      for (int n = 0; n < 27 && pageNumber * 27 + n < ordered.size(); n++)
        changed |= p.seenGear.add(ordered.get(pageNumber * 27 + n).id);
      if (changed) plugin.commit(player, p);
      return s;
    }
    if (page.startsWith("preset/")) {
      int index = Integer.parseInt(page.substring(7));
      GearPresets.Preset preset = GearPresets.of(p).get(index);
      b(
          s,
          4,
          Material.ARMOR_STAND,
          "gear_chest",
          "SET BEARBEITEN · " + (index + 1) + " · " + preset.name,
          null,
          "Platz anklicken: Teil aus dem Beutel wählen",
          "Darunter: Teil aus dem Set entfernen",
          "Umbenennen: /df sets name " + (index + 1) + " <Name>");
      Gear.Slot[] slots = Gear.Slot.values();
      for (int n = 0; n < slots.length; n++) {
        Gear.Slot slot = slots[n];
        int at = n < 5 ? 11 + n : 29 + n - 5;
        String id = preset.items.get(slot.name());
        Gear.Item item = id == null ? null : Gear.find(p, id);
        List<String> lore = new ArrayList<>();
        if (item != null) lore.addAll(Arrays.asList(gearLore(p, item)));
        else lore.add(id == null ? "Leer" : "Fehlt (verkauft oder zerlegt)");
        lore.add("");
        lore.add("Klick: Teil für diesen Platz wählen");
        b(
            s,
            at,
            item == null ? Material.GRAY_STAINED_GLASS_PANE : Material.PAPER,
            item == null ? null : item.model(),
            Gear.slotName(slot) + ": " + (item == null ? "leer" : item.name + " +" + item.level),
            "open:presetpick/" + index + "/" + slot.name(),
            lore.toArray(String[]::new));
        b(
            s,
            at + 9,
            id == null ? Material.GRAY_DYE : Material.RED_DYE,
            null,
            id == null ? "—" : "Aus dem Set entfernen",
            id == null ? null : "preset:remove:" + index + ":" + slot.name(),
            id == null ? "Nichts gespeichert" : "Nur das Set ändert sich, das Teil bleibt im Beutel.");
      }
      b(
          s,
          8,
          Material.EMERALD,
          "preset_active",
          "Auf aktiv stellen",
          preset.items.isEmpty() ? null : "preset:apply:" + index,
          "Legt alle Teile dieses Sets an.");
      return s;
    }
    if (page.startsWith("presetpick/")) {
      String[] part = page.split("/");
      int index = Integer.parseInt(part[1]);
      Gear.Slot slot = Gear.Slot.valueOf(part[2]);
      GearPresets.Preset preset = GearPresets.of(p).get(index);
      List<Gear.Item> items =
          p.gear.stream()
              .filter(i -> i.slot == slot)
              .sorted(
                  Comparator.comparingInt((Gear.Item i) -> i.rarity.ordinal())
                      .thenComparingInt(i -> i.level)
                      .thenComparingInt(i -> i.zone)
                      .reversed())
              .limit(36)
              .toList();
      b(
          s,
          4,
          Material.CHEST,
          "crate",
          Gear.slotName(slot) + " für „" + preset.name + "“ wählen",
          null,
          items.isEmpty() ? "Du hast kein Teil für diesen Platz." : items.size() + " passende Teile, beste zuerst.");
      for (int n = 0; n < items.size(); n++) {
        Gear.Item item = items.get(n);
        boolean chosen = item.id.equals(preset.items.get(slot.name()));
        List<String> lore = new ArrayList<>(Arrays.asList(gearLore(p, item)));
        lore.add("");
        lore.add(chosen ? "✔ Schon in diesem Set" : "Klick: ins Set übernehmen");
        b(
            s,
            9 + n,
            chosen ? Material.EMERALD : Material.PAPER,
            chosen ? null : item.model(),
            item.name + " +" + item.level,
            chosen ? null : "preset:set:" + index + ":" + item.id,
            lore.toArray(String[]::new));
      }
      return s;
    }
    if (page.startsWith("pass/")) {
      DeepPass.ensure(p, plugin.today());
      int view = Math.max(0, Math.min(3, Integer.parseInt(page.substring(5))));
      int tier = DeepPass.tier(p);
      long[] progress = DeepPass.progress(p);
      b(
          s,
          4,
          Material.NETHER_STAR,
          "relic",
          "TIEFENPASS · Saison " + DeepPass.season(plugin.today()) + " · Stufe " + tier + " / " + DeepPass.TIERS,
          null,
          "XP: " + progress[0] + " / " + progress[1] + (tier >= DeepPass.TIERS ? " bis zur nächsten Bonusstufe" : " bis Stufe " + (tier + 1)),
          "Saison endet in " + DeepPass.daysLeft(plugin.today()) + " Tagen (dann startet Saison " + (DeepPass.season(plugin.today()) + 1) + ")",
          "",
          "XP gibt es für: Erz (1) · Baum (8) · Monster (4)",
          "Rätsel (25) · Auftrag (40) · Boss (60) · Tagesaufgabe (80)",
          "Dungeon-Sieg (200) · Tiefenfieber-Event: doppelte XP");
      for (int n = 0; n < 9; n++) {
        int t = view * 9 + n + 1;
        if (t > DeepPass.TIERS) break;
        DeepPass.Reward reward = DeepPass.reward(t);
        boolean claimed = p.passClaimed.contains(t), open = DeepPass.claimable(p, t);
        String model =
            switch (reward.kind()) {
              case MONEY -> "coin";
              case DUST -> "relic";
              case HEAL -> "healing_crystal";
              case RELIC -> "relic";
              case NOTES -> "handbook";
              case GEAR -> "gear_chest";
            };
        b(
            s,
            18 + n,
            reward.kind() == DeepPass.Kind.GEAR ? Material.CHEST : Material.PAPER,
            model,
            "Stufe " + t + " · " + DeepPass.describe(p, t),
            open ? "pass:" + t : null,
            claimed ? "✔ Abgeholt" : open ? "Klick: abholen!" : "Ab " + DeepPass.total(t) + " XP (du: " + p.passXp + ")");
        b(
            s,
            27 + n,
            claimed ? Material.LIME_STAINED_GLASS_PANE : open ? Material.YELLOW_STAINED_GLASS_PANE : Material.GRAY_STAINED_GLASS_PANE,
            claimed ? "pass_claimed" : open ? "pass_open" : "locked",
            claimed ? "Abgeholt" : open ? "Bereit!" : "Gesperrt",
            open ? "pass:" + t : null);
      }
      if (view == 3) {
        int bonus = DeepPass.bonusEarned(p) - p.passBonus;
        b(
            s,
            25,
            Material.ENDER_CHEST,
            "crate",
            "Bonusstufen ab Stufe 30",
            bonus > 0 ? "pass:all" : null,
            "Alle " + DeepPass.BONUS_XP + " XP nach Stufe 30:",
            "10 Schmiedestaub + 2 Lebenssplitter",
            bonus > 0 ? bonus + " offen – Klick: abholen" : "Noch keine offen");
      }
      int claimable = DeepPass.claimableCount(p);
      b(
          s,
          40,
          claimable > 0 ? Material.EMERALD : Material.GRAY_DYE,
          claimable > 0 ? "pass_open" : "pass_claimed",
          claimable > 0 ? "Alle abholen (" + claimable + ")" : "Nichts abzuholen",
          claimable > 0 ? "pass:all" : null,
          "Holt alle erreichten Stufen auf einmal ab.");
      if (view > 0) b(s, 46, Material.ARROW, "back", "Stufen " + ((view - 1) * 9 + 1) + "–" + (view * 9), "open:pass/" + (view - 1));
      if (view < 3) b(s, 52, Material.ARROW, "next", "Stufen " + ((view + 1) * 9 + 1) + "–" + Math.min(DeepPass.TIERS, (view + 2) * 9), "open:pass/" + (view + 1));
      return s;
    }
    if (page.startsWith("item/")) {
      Gear.Item item = Gear.find(p, page.substring(5));
      if (item == null) {
        return create(player, p, "loot/0");
      }
      b(
          s,
          13,
          Material.PAPER,
          item.model(),
          item.name + " +" + item.level,
          null,
          gearLore(p, item));
      b(
          s,
          28,
          Material.IRON_SWORD,
          "weapon_sword",
          p.equipped.containsValue(item.id) ? "Ablegen" : "Ausrüsten",
          "equip:" + item.id);
      b(
          s,
          29,
          Material.NETHER_STAR,
          "relic",
          item.favorite ? "Favorit entfernen" : "Als Favorit schützen",
          "favorite:" + item.id);
      b(
          s,
          30,
          Material.ANVIL,
          "machine_furnace",
          "Verbessern +" + (item.level + 1),
          "enhance:" + item.id,
          "Kosten: "
              + 250L * (item.zone + 1) * (item.level + 1)
              + " $ + "
              + (2 + item.level)
              + " Staub",
          "+8 % Basiswerte pro Stufe; maximal +10");
      b(
          s,
          31,
          Material.AMETHYST_SHARD,
          "relic",
          Gear.rerollLocked(item.critRerolls) ? "Krit-Wert · UNBEZAHLBAR" : "Krit-Wert neu schmieden",
          Gear.rerollLocked(item.critRerolls) ? null : "reroll:" + item.id,
          "Aktuell: " + fmt(item.crit * 100) + " % Krit",
          "Möglich: "
              + fmt(Gear.critRange(item)[0] * 100)
              + " – "
              + fmt(Gear.critRange(item)[1] * 100)
              + " % (Seltenheit und Qualität)",
          "Das gilt pro Teil: die Krit-Chance aller Teile wird addiert, keine Obergrenze",
          "Deine Krit-Chance gesamt: " + fmt(Gear.stats(p).crit() * 100) + " %",
          Gear.rerollPrice(item, item.critRerolls),
          "Du hast " + p.money + " $ / " + p.dust + " Staub",
          "Nur Krit-Chance wird neu gewürfelt");
      if (item.slot == Gear.Slot.WEAPON)
        b(
            s,
            34,
            Material.BLAZE_POWDER,
            "relic",
            Gear.rerollLocked(item.critDamageRerolls)
                ? "Krit-Schaden · UNBEZAHLBAR"
                : "Krit-Schaden neu schmieden",
            Gear.rerollLocked(item.critDamageRerolls) ? null : "rerollcd:" + item.id,
            "Aktuell: "
                + fmt((Gear.baseCritDamage(item) + item.critDamage) * 100)
                + " % ("
                + fmt(Gear.baseCritDamage(item) * 100)
                + " % Waffentyp + "
                + fmt(item.critDamage * 100)
                + " % Bonus)",
            "Bonus möglich: "
                + fmt(Gear.critDamageRange(item)[0] * 100)
                + " – "
                + fmt(Gear.critDamageRange(item)[1] * 100)
                + " %",
            Gear.rerollPrice(item, item.critDamageRerolls),
            "Nur der Krit-Schaden-Bonus wird neu gewürfelt");
      b(
          s,
          32,
          Material.HOPPER,
          "fuel",
          "Zerlegen",
          "open:confirm/dust/" + item.id,
          "Ertrag: " + (1 + item.rarity.ordinal() * 2 + item.level) + " Staub",
          "Ausgerüstete/Favoriten sind geschützt");
      b(
          s,
          33,
          Material.GOLD_INGOT,
          "coin",
          "Verkaufen: " + item.value() + " $",
          "open:confirm/sell/" + item.id,
          "Ausgerüstete/Favoriten sind geschützt");
      b(
          s,
          43,
          p.starStones > 0 && item.level < StarStones.LEVEL ? Material.NETHER_STAR : Material.GRAY_DYE,
          "star_stone",
          "Sternenstein · " + p.starStones + " im Besitz",
          p.starStones > 0 && item.level < StarStones.LEVEL ? "starstone:" + item.id : null,
          "10 % Chance: Gegenstand wird +" + StarStones.LEVEL,
          "90 % Chance: Gegenstand ZERBRICHT und ist weg!",
          item.level >= StarStones.LEVEL ? "Schon +" + item.level : "SHIFT-Klick zum Anwenden",
          "Sternensteine: 2 % nur vom Urboss (1 % nach Weltenkern-Boss auf Albtraum)");
      b(
          s,
          35,
          item.polished ? Material.GOLD_BLOCK : p.glanz >= Shinies.POLISH_COST ? Material.GOLD_NUGGET : Material.GRAY_DYE,
          "shiny_shard",
          item.polished ? "✧ Glanzveredelt" : "Glanzveredelung · " + p.glanz + " Splitter",
          item.polished || p.glanz < Shinies.POLISH_COST ? null : "polish:" + item.id,
          item.polished ? "Dieser Gegenstand glänzt schon (+10 %)." : "+10 % Schaden, Leben und Rüstung – einmal pro Gegenstand",
          "Kosten: " + Shinies.POLISH_COST + " Glanzsplitter (von glänzenden Monstern)");
      int[] sockets = Runes.sockets(item);
      boolean drillable = sockets.length < Runes.maxSockets(item);
      b(
          s,
          37,
          drillable ? Material.IRON_PICKAXE : Material.GRAY_DYE,
          drillable ? "drill" : null,
          "Sockel bohren · " + sockets.length + " / " + Runes.maxSockets(item),
          drillable ? "rune:drill:" + item.id : null,
          drillable
              ? "Kosten: " + Runes.drillMoney(item) + " $ und " + Runes.drillDust(item) + " Staub"
              : "Alle Sockel gebohrt",
          "Ungewöhnlich/Selten: 1 Sockel · Episch und besser: 2",
          "Runen in Sockeln geben Schaden, Rüstung, Leben, Tempo, Krit oder Abbau");
      for (int n = 0; n < sockets.length; n++) {
        int code = sockets[n];
        b(
            s,
            39 + n * 2,
            code < 0 ? Material.GLASS_PANE : RUNE_ICONS[Runes.kind(code).ordinal()],
            RUNE_MODELS[Runes.kind(code).ordinal()],
            "Sockel " + (n + 1) + ": " + (code < 0 ? "leer" : Runes.name(code)),
            code < 0 ? "open:runesel/" + item.id + "/" + n : "rune:remove:" + item.id + ":" + n,
            code < 0 ? "Klick: Rune aus dem Beutel einsetzen" : Runes.effect(code, item) + " auf die Grundwerte",
            code < 0
                ? Runes.total(p) + " Runen im Beutel"
                : "Klick: herauslösen (" + Runes.removeDust(code) + " Staub, Rune kommt zurück)");
      }
      b(s, 46, Material.CHEST, "crate", "Zum Beutel", "open:loot/0");
      return s;
    }
    if (page.equals("pets") || page.equals("eggs") || page.startsWith("pet/")) {
      long now = System.currentTimeMillis();
      boolean camp = plugin.pets().atCamp(player);
      Companions.Companion active = Companions.active(p);
      b(
          s,
          4,
          Material.SNIFFER_EGG,
          "egg_epic",
          "BEGLEITER · " + p.companions.size() + " geschlüpft · " + p.eggs.size() + " Eier",
          null,
          active == null ? "Kein Begleiter aktiv" : "Aktiv: " + Companions.name(active) + " · " + Companions.describe(active),
          "Eier sind sehr selten: Champions, Minenbosse, Dungeon-Siege",
          "Ausbrüten in der Brutstätte – nur am Camp (oben im Dorf)",
          camp ? "✔ Du bist am Camp" : "✘ Du bist nicht am Camp");
      if (page.equals("pets")) {
        for (int i = 0; i < Companions.INCUBATORS; i++) {
          Companions.Egg egg = Companions.brooding(p, i);
          boolean ready = egg != null && Companions.ready(egg, now);
          b(
              s,
              11 + i * 4,
              egg == null ? Material.HAY_BLOCK : EGG_ICONS[egg.rarity.ordinal()],
              egg == null ? null : eggModel(egg.rarity),
              "Brutnest " + (i + 1) + ": " + (egg == null ? "leer" : egg.rarity.title + "es Ei"),
              egg == null ? "open:eggs" : ready ? "pet:hatch:" + i : null,
              egg == null
                  ? "Klick: ein Ei hineinlegen"
                  : ready ? "SCHLÜPFBEREIT! Klick am Camp" : "Schlüpft in " + Companions.time(egg.hatchAt - now),
              "Brutzeit: ungewöhnlich 30 min · selten 1 h · episch 3 h",
              "legendär 6 h · mythisch 12 h (läuft auch offline)");
        }
        b(s, 13, Material.CHEST, "crate", "Eier · " + p.eggs.size() + " / " + Companions.MAX_EGGS, "open:eggs", "Alle gefundenen Eier ansehen");
        for (int n = 0; n < p.companions.size() && n < 18; n++) {
          Companions.Companion c = p.companions.get(n);
          boolean on = c.id.equals(p.activeCompanion);
          b(
              s,
              27 + n,
              PET_ICONS[c.species.ordinal()],
              "pet_" + c.species.name().toLowerCase(Locale.ROOT),
              (on ? "✔ " : "") + Companions.name(c) + " · St. " + c.level,
              "open:pet/" + c.id,
              Companions.describe(c),
              on ? "Begleitet dich gerade" : "Klick: Details, aktivieren, füttern");
        }
        if (p.companions.isEmpty())
          b(s, 31, Material.GRAY_DYE, null, "Noch keine Begleiter", null, "Finde ein Ei und brüte es aus.");
        return s;
      }
      if (page.equals("eggs")) {
        List<Companions.Egg> eggs = p.eggs;
        for (int n = 0; n < eggs.size() && n < 36; n++) {
          Companions.Egg egg = eggs.get(n);
          boolean brooding = egg.incubator >= 0;
          b(
              s,
              9 + n,
              EGG_ICONS[egg.rarity.ordinal()],
              eggModel(egg.rarity),
              egg.rarity.title + "es Ei" + (brooding ? " · im Nest " + (egg.incubator + 1) : ""),
              brooding ? null : "pet:brood:" + egg.id,
              "Brutzeit: " + Companions.time(Companions.hatchMinutes(egg.rarity) * Companions.MINUTE),
              brooding
                  ? Companions.ready(egg, now) ? "Schlüpfbereit!" : "Noch " + Companions.time(egg.hatchAt - now)
                  : camp ? "Klick: ins freie Brutnest legen" : "Ins Brutnest legen: nur am Camp");
        }
        if (eggs.isEmpty()) b(s, 22, Material.GRAY_DYE, null, "Keine Eier", null, "Eier sind sehr selten – viel Glück!");
        return s;
      }
      Companions.Companion c = Companions.companion(p, page.substring(4));
      if (c == null) return create(player, p, "pets");
      boolean on = c.id.equals(p.activeCompanion);
      b(s, 13, PET_ICONS[c.species.ordinal()], "pet_" + c.species.name().toLowerCase(Locale.ROOT), Companions.name(c) + " · Stufe " + c.level + " / " + Companions.MAX_LEVEL, null,
          "Bonus: " + Companions.describe(c), "Art: " + c.species.title + " (" + c.species.bonus + ")");
      b(s, 29, on ? Material.LIME_DYE : Material.EMERALD, null, on ? "Aktiv · Klick: ausruhen lassen" : "Als Begleiter wählen", "pet:active:" + c.id,
          "Nur ein Begleiter kann dich gleichzeitig begleiten.");
      b(s, 31, c.level >= Companions.MAX_LEVEL ? Material.GRAY_DYE : Material.COOKED_BEEF, null,
          c.level >= Companions.MAX_LEVEL ? "Höchste Stufe" : "Füttern → Stufe " + (c.level + 1),
          c.level >= Companions.MAX_LEVEL ? null : "pet:feed:" + c.id,
          "Kosten: " + Companions.feedParts(c) + " Monsterteile + " + Companions.feedMoney(c) + " $",
          "+10 % Bonus pro Stufe");
      b(s, 33, Material.BARRIER, "close", "Freilassen", "petrelease:" + c.id,
          "SHIFT-Klick: freilassen (endgültig)", "Zum Abschied gibt es Schmiedestaub");
      return s;
    }
    if (page.equals("guild") || page.equals("guildnone")) {
      Guilds.Guild g = Guilds.of(p);
      if (g == null) {
        b(
            s,
            4,
            Material.WHITE_BANNER,
            "guild_banner",
            "GILDEN",
            null,
            "Spiele mit bis zu 15 Freunden in einer Gilde:",
            "gemeinsame Kasse, Stützpunkt mit Boni für alle,",
            "Wochenaufträge, Gildenchat und [KÜRZEL] im Chat.");
        b(
            s,
            22,
            Material.WRITABLE_BOOK,
            "handbook",
            "Gilde gründen · " + Guilds.FOUND_COST + " $",
            null,
            "/df gilde gründen <Kürzel> <Name>",
            "Beispiel: /df gilde gründen PING Pinguin Minenbund",
            "Kürzel 2–4 Zeichen, Name 3–20 Zeichen");
        int n = 0;
        for (Guilds.Guild other : Guilds.all())
          if (other.invites.contains(p.id) && n < 7)
            b(
                s,
                29 + n++,
                Material.LIME_BANNER,
                "guild_invite",
                "Einladung: " + other.name + " [" + other.tag + "]",
                null,
                "Annehmen: /df gilde annehmen " + other.tag,
                other.members.size() + " Mitglieder · Level " + Guilds.level(other));
        return s;
      }
      Guilds.ensureWeek(g, plugin.today());
      int level = Guilds.level(g);
      long toNext = 1000L * level, xpInto = g.xp;
      for (int l = 1; l < level; l++) xpInto -= 1000L * l;
      b(
          s,
          4,
          guildBanner(Guilds.color(g)),
          "guild_banner",
          g.name + " [" + g.tag + "] · Level " + level,
          null,
          "Gilden-XP: " + xpInto + " / " + toNext + " bis Level " + (level + 1),
          "Gildenkasse: " + g.bank + " $",
          "Mitglieder: " + g.members.size() + " / " + Guilds.maxMembers(g),
          "Gildenchat: /df gc <Nachricht>",
          "Einladen: /df gilde einladen <Spieler>");
      int n = 0;
      for (Map.Entry<String, Guilds.Rank> m : g.members.entrySet()) {
        if (n >= 15) break;
        boolean online = Bukkit.getPlayer(UUID.fromString(m.getKey())) != null;
        b(
            s,
            9 + n++,
            m.getValue() == Guilds.Rank.ANFUEHRER
                ? Material.GOLDEN_HELMET
                : m.getValue() == Guilds.Rank.OFFIZIER ? Material.IRON_HELMET : Material.LEATHER_HELMET,
            m.getValue() == Guilds.Rank.ANFUEHRER ? "rank_leader" : m.getValue() == Guilds.Rank.OFFIZIER ? "rank_officer" : "rank_member",
            g.names.getOrDefault(m.getKey(), "?") + (online ? " · online" : ""),
            null,
            m.getValue().title);
      }
      boolean manager = Guilds.canManage(g, p.id);
      String colorKey = Guilds.color(g);
      b(
          s,
          2,
          guildDye(colorKey),
          null,
          "Gildenfarbe: " + Guilds.COLORS.get(colorKey),
          manager ? "open:guildcolor" : null,
          "Farbe des [" + g.tag + "] in Chat, Tab-Liste",
          "und Namensschild aller Mitglieder",
          manager ? "Klick: Farbe wählen" : "Nur Anführer/Offiziere ändern die Farbe");
      tint(s, 2, "Gildenfarbe: " + Guilds.COLORS.get(colorKey), GuildService.textColor(g));
      b(
          s,
          6,
          Material.NAME_TAG,
          null,
          "Mitglieder einladen",
          null,
          "/df gilde einladen <Spieler>",
          "Einladungen gelten, bis sie angenommen werden",
          "Freie Plätze: " + Math.max(0, Guilds.maxMembers(g) - g.members.size()));
      for (Guilds.Building bld : Guilds.Building.values()) {
        int lvl = g.buildings[bld.ordinal()];
        boolean max = lvl >= Guilds.MAX_BUILDING;
        b(
            s,
            29 + bld.ordinal(),
            max ? Material.EMERALD_BLOCK : Material.BRICKS,
            BUILDING_MODELS[bld.ordinal()],
            "Stützpunkt: " + bld.title + " · Stufe " + lvl + " / " + Guilds.MAX_BUILDING,
            max || !manager ? null : "guild:build:" + bld.name(),
            bld.perLevel + " je Stufe (für alle Mitglieder)",
            max ? "Voll ausgebaut" : "Ausbau: " + Guilds.buildingCost(g, bld) + " $ aus der Kasse",
            max ? "" : "Benötigt Gildenlevel " + (lvl + 1),
            manager ? "Klick: ausbauen" : "Nur Anführer/Offiziere bauen aus");
      }
      for (int i = 0; i < 3 && i < g.tasks.size(); i++) {
        Guilds.Task task = Guilds.Task.valueOf(g.tasks.get(i));
        b(
            s,
            38 + i * 2,
            g.done[i] ? Material.LIME_DYE : Material.PAPER,
            g.done[i] ? "talent_done" : "guild_task",
            "Wochenauftrag: " + task.title,
            null,
            g.progress[i] + " / " + g.target[i] + (g.done[i] ? " · ERFÜLLT" : ""),
            "Belohnung: 600 Gilden-XP + " + 10_000L * g.members.size() + " $ Kasse",
            "Neue Aufträge jeden Montag");
      }
      b(s, 46, Material.GOLD_NUGGET, null, "1.000 $ einzahlen", "guild:deposit:1000", "Du hast " + p.money + " $");
      b(s, 48, Material.GOLD_INGOT, null, "10.000 $ einzahlen", "guild:deposit:10000", "Du hast eingezahlt: " + p.guildContributed + " $");
      b(s, 50, Material.GOLD_BLOCK, null, "100.000 $ einzahlen", "guild:deposit:100000", "Beliebiger Betrag: /df gilde einzahlen <Betrag>");
      b(s, 52, Material.BARRIER, "close", "Gilde verlassen", "guild:leave", "SHIFT-Klick zum Verlassen");
      return s;
    }
    if (page.equals("guildcolor")) {
      Guilds.Guild g = Guilds.of(p);
      if (g == null) return create(player, p, "guildnone");
      String current = Guilds.color(g);
      b(
          s,
          4,
          guildBanner(current),
          "guild_banner",
          "GILDENFARBE · [" + g.tag + "]",
          null,
          "Die Farbe des Kürzels in Chat, Tab-Liste",
          "und über dem Kopf aller Mitglieder.",
          "Jetzt: " + Guilds.COLORS.get(current),
          "Auch per Befehl: /df gilde farbe <Farbe>");
      tint(s, 4, "GILDENFARBE · [" + g.tag + "]", GuildService.textColor(g));
      boolean manager = Guilds.canManage(g, p.id);
      int[] slots = {19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
      int i = 0;
      for (Map.Entry<String, String> e : Guilds.COLORS.entrySet()) {
        boolean on = e.getKey().equals(current);
        b(
            s,
            slots[i++],
            guildDye(e.getKey()),
            null,
            e.getValue(),
            on || !manager ? null : "guild:color:" + e.getKey(),
            "Vorschau: [" + g.tag + "]",
            on ? "Aktuelle Farbe" : manager ? "Klick: diese Farbe nehmen" : "Nur Anführer/Offiziere");
        NamedTextColor c = NamedTextColor.NAMES.value(e.getKey());
        tint(s, slots[i - 1], (on ? "» " + e.getValue() + " «" : e.getValue()), c);
        ItemStack item = s.inv.getItem(slots[i - 1]);
        var meta = item.getItemMeta();
        List<Component> lore = new ArrayList<>(meta.lore());
        lore.set(0, Component.text("Vorschau: ", NamedTextColor.GRAY).append(Component.text("[" + g.tag + "]", c)).decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.setEnchantmentGlintOverride(on);
        item.setItemMeta(meta);
      }
      return s;
    }
    if (page.equals("museum")) {
      b(
          s,
          4,
          Material.CHISELED_BOOKSHELF,
          "museum",
          "MUSEUM & SAMMLUNGSBUCH · " + Archaeology.donatedCount(p) + " / " + Archaeology.ALL.size(),
          null,
          "Vollständige Minen: " + Archaeology.completeZones(p) + " / " + Zone.COUNT,
          "Museumsbonus: +" + Math.round(Archaeology.bonus(p) * 100) + " % Schaden und Erz-/Barrenwert",
          "+1 % pro vollständiger Mine · alle 17: nochmal +5 %",
          "Fundstücke gibt es beim Erzabbau (" + String.format(Locale.GERMAN, "%.1f", Archaeology.CHANCE * 100) + " % pro Erzblock).");
      b(
          s,
          40,
          Material.GOLD_NUGGET,
          "shiny_book",
          "Glanzbuch · " + Shinies.dex(p) + "/" + Shinies.dexSize(),
          "open:glanz",
          "Glänzende Monster: selten, golden, fliehen nach 30 s",
          "Glanzsplitter: " + p.glanz);
      int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 29, 31, 33};
      for (int z = 0; z < Zone.COUNT; z++) {
        int got = 0, spare = 0;
        for (int i = 0; i < 4; i++) {
          Archaeology.Find f = Archaeology.find(z, i);
          if (Archaeology.donated(p, f)) got++;
          spare += Archaeology.owned(p, f);
        }
        boolean done = Archaeology.complete(p, z);
        b(
            s,
            slots[z],
            done ? Material.LIME_STAINED_GLASS_PANE : got > 0 || spare > 0 ? Material.BOOK : Material.GRAY_DYE,
            done ? "talent_done" : got > 0 || spare > 0 ? "collection_book" : "locked",
            (z + 1) + " · " + Zone.at(z).title + " · " + got + "/4",
            "open:museum/" + z,
            done ? "Sammlung vollständig ✓" : got + " von 4 im Museum",
            spare > 0 ? spare + " Fundstück(e) zum Stiften oder Verkaufen" : "Keine Fundstücke im Beutel",
            "Klick: Seite im Sammlungsbuch öffnen");
      }
      return s;
    }
    if (page.equals("glanz")) {
      b(
          s,
          4,
          Material.GOLD_NUGGET,
          "shiny_book",
          "GLANZBUCH · " + Shinies.dex(p) + " / " + Shinies.dexSize(),
          null,
          "Gefangen: " + p.shinyKills + " glänzende Monster · Glanzsplitter: " + p.glanz,
          "Chance pro Minenmonster: 1 zu " + Math.round(1 / Shinies.chance(p)) + " (×" + Prestige.fmt(Shinies.multiplier(p)) + ")",
          "10 Arten: ×1,5 · 25 Arten: ×2 · alle 51: ×3",
          "Glanzveredelung: im Gegenstand-Menü, " + Shinies.POLISH_COST + " Splitter = +10 % Werte");
      int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 29, 31, 33};
      for (int z = 0; z < Zone.COUNT; z++) {
        List<String> lore = new ArrayList<>();
        int got = 0;
        for (int k = 0; k < Shinies.KINDS.length; k++) {
          boolean c = Shinies.caught(p, z, k);
          if (c) got++;
          lore.add((c ? "✓ " : "✗ ") + (c ? Shinies.name(k).substring(2) : "???"));
        }
        b(
            s,
            slots[z],
            got == Shinies.KINDS.length ? Material.GOLD_BLOCK : got > 0 ? Material.GOLD_NUGGET : Material.GRAY_DYE,
            got == Shinies.KINDS.length ? "shiny_book" : got > 0 ? "shiny_shard" : "locked",
            (z + 1) + " · " + Zone.at(z).title + " · " + got + "/" + Shinies.KINDS.length,
            null,
            lore.toArray(String[]::new));
      }
      return s;
    }
    if (page.startsWith("museum/")) {
      int z = Math.clamp(Integer.parseInt(page.substring(7)), 0, Zone.LAST);
      b(
          s,
          4,
          Material.BOOK,
          "collection_book",
          "SAMMLUNGSBUCH · " + Zone.at(z).title,
          null,
          Archaeology.complete(p, z) ? "Vollständig! +1 % Museumsbonus" : "Alle 4 stiften: +1 % Schaden und Erzwert",
          "Linksklick: dem Museum stiften (Geld + Staub)",
          "Rechtsklick: doppelte verkaufen");
      int[] slots = {20, 22, 24, 31};
      for (int i = 0; i < 4; i++) {
        Archaeology.Find f = Archaeology.find(z, i);
        int owned = Archaeology.owned(p, f);
        boolean known = owned > 0 || Archaeology.donated(p, f);
        b(
            s,
            slots[i],
            Archaeology.donated(p, f) ? Material.LIME_DYE : known ? Material.BRUSH : Material.GRAY_DYE,
            known ? f.model() : "locked",
            (f.rare() ? "★ " : "") + (known ? f.name() : "???") + (Archaeology.donated(p, f) ? " ✓" : ""),
            known ? "find:" + f.id() : null,
            known ? f.story() : f.rare() ? "Selten – nur 12 % der Funde in dieser Mine" : "Noch nicht gefunden",
            "Im Beutel: " + owned + (Archaeology.donated(p, f) ? " · im Museum ✓" : ""),
            "Stiften: +" + Hud.money(Archaeology.donationReward(f)) + " · Verkaufen: " + Hud.money(Archaeology.saleValue(f)) + " pro Stück");
      }
      return s;
    }
    if (page.equals("alchemy")) {
      long now = System.currentTimeMillis();
      int level = Alchemy.level(p);
      b(
          s,
          4,
          Material.BREWING_STAND,
          "alchemy_table",
          "ALCHEMIE · Braumeister " + level + " / " + Alchemy.MAX_LEVEL,
          null,
          level >= Alchemy.MAX_LEVEL ? "Höchste Stufe" : "XP: " + p.alchemyXp + " / " + Alchemy.nextXp(p) + " (+" + Alchemy.XP_PER_BREW + " pro Brauen)",
          "Trankstärke: +" + Math.round((Alchemy.strength(p) - 1) * 100) + " % · gleichzeitig: " + Alchemy.slots(p) + " Tränke",
          "Aktiv: " + Alchemy.activeCount(p, now) + " / " + Alchemy.slots(p) + (Alchemy.batch(p) > 1 ? " · 2 Tränke pro Brauen" : ""),
          "Ab Stufe 10: 2 Tränke pro Brauen · alle 5 Stufen +1 gleichzeitig");
      int slot = 11;
      for (Alchemy.Ingredient i : Alchemy.Ingredient.values()) {
        b(
            s,
            slot,
            Material.valueOf(i.material),
            i.model,
            i.title + " · " + Alchemy.ingredient(p, i),
            null,
            "Quelle: " + i.source);
        slot += 2;
      }
      int[] slots = {28, 29, 30, 32, 33, 34};
      for (Alchemy.Potion k : Alchemy.Potion.values()) {
        long left = Alchemy.remaining(p, k, now);
        List<String> lore = new ArrayList<>();
        lore.add("Wirkung: +" + Alchemy.describe(p, k) + " · " + k.minutes + " Min.");
        lore.add("Rezept: " + k.recipe[0] + " Essenz · " + k.recipe[1] + " Moos · " + k.recipe[2] + " Kraut · " + Hud.money(Alchemy.price(p, k)));
        lore.add("Vorrat: " + Alchemy.stock(p, k));
        lore.add(left > 0 ? "AKTIV · noch " + (left / 60_000) + ":" + String.format("%02d", left / 1000 % 60) : "nicht aktiv");
        lore.add("Linksklick: brauen · Rechtsklick: trinken");
        b(
            s,
            slots[k.ordinal()],
            left > 0 ? Material.HONEY_BOTTLE : Material.POTION,
            k.model,
            k.title + (left > 0 ? " · AKTIV" : ""),
            "brew:" + k.name(),
            lore.toArray(String[]::new));
      }
      return s;
    }
    if (page.equals("prestige")) {
      int n = p.prestige;
      b(
          s,
          4,
          Material.NETHER_STAR,
          "prestige_star",
          n == 0 ? "PRESTIGE · noch keins" : "PRESTIGE " + Prestige.badge(n),
          null,
          "Gegner jetzt: ×" + Prestige.fmt(Prestige.health(n)) + " Leben · ×" + Prestige.fmt(Prestige.damage(n)) + " Schaden",
          "Erz & Barren: ×" + Prestige.fmt(Prestige.income(p)) + " Wert",
          "Freie Tiefenglut: " + p.glut + " · Höchstes Prestige: " + p.bestPrestige,
          "Keine Obergrenze – irgendwann schaffst du die Bosse nicht mehr.");
      b(
          s,
          20,
          Material.BARRIER,
          "close",
          "Wird zurückgesetzt",
          null,
          "Gebiet → Eisenmine · Geld → " + Hud.money(Prestige.startMoney(p)),
          "Bohrer, Klinge, Schutz, Erzglück, Rucksack, Lager",
          "Erz, Barren, Betriebsbudget · besiegte Gebietsbosse",
          "Arbeiter ziehen mit dir in die Eisenmine");
      b(
          s,
          22,
          Material.CHEST,
          "preset",
          "Bleibt erhalten",
          null,
          "Alle Ausrüstung, Runen, Sternensteine",
          "Begleiter, Eier, Funke, Meisterschaft & Talente",
          "Dungeon-Level, Tiefenpass, Gilde, Wald & Holz",
          "Unterkunft, Schmelze, Heiltasche, Forschung");
      b(
          s,
          24,
          Material.BLAZE_POWDER,
          "glut_ader",
          "Nächstes Prestige (" + Prestige.badge(n + 1) + ")",
          null,
          "Gegner: ×" + Prestige.fmt(Prestige.health(n + 1)) + " Leben · ×" + Prestige.fmt(Prestige.damage(n + 1)) + " Schaden",
          "Neue Beute: ×" + Prestige.fmt(Prestige.loot(n + 1)) + " Werte",
          "Erz & Kampfgeld: +" + Math.round(Prestige.INCOME * (n + 1) * 100) + " %",
          "+" + Prestige.glutFor(n + 1) + " Tiefenglut");
      boolean ready = Prestige.ready(p);
      b(
          s,
          31,
          ready ? Material.NETHER_STAR : Material.GRAY_DYE,
          ready ? "prestige_star" : "locked",
          ready ? "★ PRESTIGE ERREICHEN" : "Prestige gesperrt",
          ready ? "prestige:do" : null,
          ready ? "SHIFT + Klick: neu beginnen – stärker belohnt" : Prestige.requirement(p),
          "Voraussetzung: Weltenkern-Boss besiegt",
          "Deine Ausrüstung bleibt – die Welt wird härter");
      int slot = 38;
      for (Prestige.Node node : Prestige.Node.values()) {
        int rank = Prestige.rank(p, node);
        boolean can = rank < Prestige.MAX_RANK && p.glut > 0;
        b(
            s,
            slot++,
            rank >= Prestige.MAX_RANK ? Material.LIME_STAINED_GLASS_PANE : Material.valueOf(node.material),
            rank >= Prestige.MAX_RANK ? "talent_done" : node.model,
            node.title + " · " + rank + "/" + Prestige.MAX_RANK,
            can ? "prestige:learn:" + node.name() : null,
            node.effect + (node == Prestige.Node.KAPITAL ? "" : " pro Rang"),
            rank >= Prestige.MAX_RANK ? "Voll ausgebaut" : can ? "Klick: 1 Tiefenglut ausgeben" : "Keine Tiefenglut frei");
      }
      return s;
    }
    if (page.equals("talents")) {
      long[] xp = Talents.progress(p);
      b(
          s,
          4,
          Material.EXPERIENCE_BOTTLE,
          "mastery",
          "MEISTERSCHAFT · Stufe " + Talents.level(p) + " / " + Talents.MAX_LEVEL,
          null,
          Talents.level(p) >= Talents.MAX_LEVEL
              ? "Höchste Stufe erreicht"
              : "XP: " + xp[0] + " / " + xp[1] + " bis zur nächsten Stufe",
          "Freie Talentpunkte: " + Talents.free(p),
          "Dauerhaft – unabhängig vom Tiefenpass, keine Saison",
          "XP für alles: Erz, Monster, Champions, Dungeons, Tagesaufgaben …",
          "Schlüsseltalent (rechts): ab " + Talents.KEY_REQUIRES + " Punkten im Baum");
      Material[] icons = {Material.IRON_SWORD, Material.IRON_PICKAXE, Material.GOLD_INGOT};
      for (Talents.Tree tree : Talents.Tree.values()) {
        int row = 9 + tree.ordinal() * 9;
        b(
            s,
            row,
            icons[tree.ordinal()],
            new String[] {"talent_warrior", "talent_miner", "talent_trader"}[tree.ordinal()],
            tree.title.toUpperCase(Locale.ROOT) + " · " + Talents.spent(p, tree) + " Punkte",
            null,
            "Punkte in diesem Baum: " + Talents.spent(p, tree));
        int col = 0;
        for (Talents.Node n : Talents.Node.values()) {
          if (n.tree != tree) continue;
          int rank = Talents.rank(p, n);
          boolean locked = n.key() && Talents.spent(p, tree) < Talents.KEY_REQUIRES;
          boolean can = rank < n.max && Talents.free(p) > 0 && !locked;
          b(
              s,
              row + 2 + col++,
              rank >= n.max
                  ? Material.LIME_STAINED_GLASS_PANE
                  : locked ? Material.GRAY_STAINED_GLASS_PANE : n.key() ? Material.NETHER_STAR : Material.PAPER,
              rank >= n.max ? "talent_done" : locked ? "locked" : n.key() ? "star_stone" : "talent_node",
              (n.key() ? "★ " : "") + n.title + " · " + rank + "/" + n.max,
              can ? "talent:" + n.name() : null,
              n.max == 1 ? n.perRank : n.perRank + " pro Rang",
              rank >= n.max
                  ? "Voll ausgebaut"
                  : locked
                      ? "Gesperrt: " + Talents.KEY_REQUIRES + " Punkte in " + tree.title + " nötig"
                      : can ? "Klick: 1 Punkt verteilen" : "Kein Talentpunkt frei");
        }
      }
      b(
          s,
          40,
          Material.BARRIER,
          "close",
          "Talente zurücksetzen",
          Talents.spent(p) > 0 ? "talent:reset" : null,
          "Kosten: " + Talents.resetCost(p) + " $ (1.000 $ pro verteiltem Punkt)",
          "Alle Punkte werden wieder frei");
      return s;
    }
    if (page.equals("runes") || page.startsWith("runes/")) {
      Runes.count(p, 0);
      b(
          s,
          4,
          Material.AMETHYST_CLUSTER,
          "rune_bag",
          "RUNENBEUTEL · " + Runes.total(p) + " Runen",
          null,
          "Runen fallen von Champions (✦), Minenbossen,",
          "Dungeon-Siegen und selten von normalen Monstern.",
          "Einsetzen: Gegenstand im Beutel öffnen → Sockel",
          "Runenschmiede: 3 gleiche → 1 der nächsten Stufe");
      if (page.equals("runes")) {
        int[] at = {19, 20, 21, 23, 24, 25};
        for (Runes.Kind kind : Runes.Kind.values()) {
          List<String> lore = new ArrayList<>();
          lore.add("Wirkt auf: " + kind.stat);
          for (int t = 1; t <= Runes.TIERS; t++) {
            int code = Runes.code(kind, t);
            lore.add(Runes.ROMAN[t - 1] + ": " + p.runes[code] + "×  (" + Runes.effect(code) + ")");
          }
          lore.add("Klick: Runenschmiede für diese Art");
          b(
              s,
              at[kind.ordinal()],
              RUNE_ICONS[kind.ordinal()],
              RUNE_MODELS[kind.ordinal()],
              kind.title,
              "open:runes/" + kind.ordinal(),
              lore.toArray(String[]::new));
        }
        return s;
      }
      Runes.Kind kind = Runes.Kind.values()[Integer.parseInt(page.substring(6))];
      for (int t = 1; t <= Runes.TIERS; t++) {
        int code = Runes.code(kind, t);
        boolean can = t < Runes.TIERS && p.runes[code] >= Runes.COMBINE;
        b(
            s,
            19 + t,
            RUNE_ICONS[kind.ordinal()],
            RUNE_MODELS[kind.ordinal()],
            Runes.name(code) + " · " + p.runes[code] + "×",
            null,
            Runes.effect(code));
        b(
            s,
            28 + t,
            t == Runes.TIERS ? Material.GRAY_DYE : can ? Material.ANVIL : Material.GRAY_DYE,
            null,
            t == Runes.TIERS ? "Höchste Stufe" : "3× → " + Runes.name(code + 1),
            can ? "rune:combine:" + code : null,
            t == Runes.TIERS
                ? "Stufe V kann nicht weiter verschmolzen werden"
                : "Kosten: 3× " + Runes.name(code) + " + " + 5 * t + " Staub",
            "Du hast " + p.runes[code] + "× · " + p.dust + " Staub");
      }
      return s;
    }
    if (page.startsWith("runesel/")) {
      String[] part = page.split("/");
      Gear.Item item = Gear.find(p, part[1]);
      if (item == null) return create(player, p, "loot/0");
      int socket = Integer.parseInt(part[2]);
      b(
          s,
          4,
          Material.AMETHYST_CLUSTER,
          "rune_bag",
          "Rune für " + item.name + " · Sockel " + (socket + 1),
          null,
          "Klick auf eine Rune setzt sie ein.");
      int n = 0;
      for (int code = Runes.CODES - 1; code >= 0 && n < 36; code--) {
        if (Runes.count(p, code) <= 0) continue;
        b(
            s,
            9 + n++,
            RUNE_ICONS[Runes.kind(code).ordinal()],
            RUNE_MODELS[Runes.kind(code).ordinal()],
            Runes.name(code) + " · " + p.runes[code] + "×",
            "rune:insert:" + item.id + ":" + socket + ":" + code,
            "In diesem Gegenstand: " + Runes.effect(code, item),
            "Wird direkt zu den Grundwerten addiert");
      }
      if (n == 0) b(s, 22, Material.BARRIER, "close", "Keine Runen", null, "Besiege Champions (✦) in den Minen.");
      return s;
    }
    if (page.startsWith("confirm/")) {
      String[] parts = page.split("/");
      Gear.Item item = Gear.find(p, parts[2]);
      if (item == null) {
        return create(player, p, "loot/0");
      }
      b(
          s,
          22,
          Material.PAPER,
          item.model(),
          item.name,
          null,
          "Gegenstand wird aus deinem Beutel entfernt.");
      b(s, 30, Material.LIME_DYE, "coin", "Bestätigen", parts[1] + ":" + item.id);
      b(s, 32, Material.BARRIER, "close", "Abbrechen", "open:item/" + item.id);
      return s;
    }
    switch (page) {
      case "research" -> {
        b(
            s,
            4,
            Material.BOOK,
            "handbook",
            "Forschung · " + p.researchNotes + " Unterlagen",
            null,
            "Unterlagen: Minenfunde und Lieferaufträge");
        for (int i = 0; i < Industry.RESEARCH.length; i++)
          b(
              s,
              20 + i,
              Material.ENCHANTED_BOOK,
              "relic",
              Industry.RESEARCH[i] + " · " + p.research[i] + "/5",
              "research:" + i,
              Industry.EFFECT[i],
              p.research[i] == 0
                  ? "Noch nicht erforscht"
                  : "Aktuell: " + Industry.researchTotal(p, i),
              "Kosten: "
                  + Industry.researchCost(p, i)
                  + " $ + "
                  + Industry.noteCost(p, i)
                  + " Unterlagen",
              "Zusätzlich: "
                  + 4 * (p.research[i] + 1)
                  + " Eisenbarren (du hast "
                  + p.bars[0]
                  + "); Werkzeugstufe "
                  + p.research[i]);
        b(s, 39, Material.PAPER, "handbook", "Unterlagen verdienen", "open:contracts");
        b(s, 41, Material.CHEST, "crate", "Fundstellen erkunden", "open:expeditions");
      }
      case "contracts" -> {
        for (int kind = 0; kind < 3; kind++) {
          Industry.Contract c = Industry.contract(p, kind);
          long have =
              kind == 0
                  ? p.bag[c.zone()] + p.stock[c.zone()]
                  : kind == 1 ? p.bars[c.zone()] : p.monsterParts[c.zone()];
          b(
              s,
              20 + kind * 2,
              kind == 0 ? Material.RAW_IRON : kind == 1 ? Material.IRON_INGOT : Material.BONE,
              kind == 2 ? "relic" : "ore_" + Zone.at(c.zone()).key,
              new String[] {"Erzlieferung", "Barrenauftrag", "Jagdmaterial"}[kind]
                  + " #"
                  + (c.sequence() + 1),
              "contract:" + kind + ":" + c.sequence(),
              Zone.at(c.zone()).title,
              "Fortschritt: " + have + " / " + c.amount(),
              "Belohnung: " + c.money() + " $ + " + c.notes() + " Unterlagen",
              "Klick: Material abgeben. Kein Zeitlimit.");
        }
        b(s, 40, Material.BOOK, "relic", "Forschung öffnen", "open:research");
      }
      case "expeditions" -> {
        for (int z = 0; z < Zone.COUNT; z++) {
          int found = 0;
          for (int n = 0; n < 3; n++) if (p.expeditions[z * 3 + n]) found++;
          b(
              s,
              9 + z,
              Material.CHEST,
              "crate",
              Zone.at(z).title + " · " + found + "/3 Funde",
              z <= p.zone ? "mine:" + z : null,
              "Drei Fundkisten in seitlichen Stollen",
              "Rechtsklick in der Welt zum Bergen",
              "Je Fund: " + 250 * (z + 1) + " $, 3 Unterlagen, " + (2 + z) + " Staub",
              "Alle drei: zusätzlich 1 Relikt");
          int tier = Industry.collectionTier(p, z);
          b(
              s,
              27 + z,
              Material.AMETHYST_SHARD,
              "relic",
              "Erzsammlung · Rang " + tier + "/3",
              "collect:" + z,
              tier == 3
                  ? "Gemeistert"
                  : p.collected[z] + " / " + Industry.COLLECTION[tier] + " selbst geförderte Erze",
              "Ränge: 500 / 2.000 / 10.000 Erze",
              "Klick: erreichte Belohnung abholen");
        }
      }
      case "character" -> {
        b(
            s,
            1,
            Material.IRON_SWORD,
            "weapon_sword",
            "KAMPF",
            null,
            CharacterSheet.combat(p).toArray(String[]::new));
        b(
            s,
            3,
            Material.IRON_PICKAXE,
            "drill",
            "BERGBAU",
            null,
            CharacterSheet.mining(p).toArray(String[]::new));
        b(
            s,
            5,
            Material.GOLD_INGOT,
            "coin",
            "RESSOURCEN",
            null,
            CharacterSheet.resources(p).toArray(String[]::new));
        b(
            s,
            7,
            Material.NETHER_STAR,
            "relic",
            "FORTSCHRITT",
            null,
            CharacterSheet.progress(p).toArray(String[]::new));
        b(
            s,
            43,
            Material.GOAT_HORN,
            "relic",
            "Meilensteine"
                + (Milestones.claimableCount(p) > 0
                    ? " · " + Milestones.claimableCount(p) + " abholbar"
                    : ""),
            "open:milestones",
            "Langfristige Ziele mit Geld, Staub, Relikten und Unterlagen");
        // The ten equipment slots as two centred rows of five.
        int n = 0;
        for (Gear.Slot slot : Gear.Slot.values()) {
          Gear.Item item = Gear.equipped(p, slot);
          int at = n < 5 ? 20 + n : 29 + n - 5;
          n++;
          b(
              s,
              at,
              Material.PAPER,
              item == null ? "shield" : item.model(),
              Gear.slotName(slot) + ": " + (item == null ? "Leer" : item.name),
              item == null ? "open:loot/0" : "open:item/" + item.id,
              item == null ? new String[] {"Ausrüstung im Beutel auswählen"} : gearLore(p, item));
        }
        b(s, 41, Material.CHEST, "crate", "Beutel öffnen", "open:loot/0");
        b(
            s,
            37,
            Material.EXPERIENCE_BOTTLE,
            "mastery",
            "Meisterschaft · Stufe " + Talents.level(p) + (Talents.free(p) > 0 ? " · " + Talents.free(p) + " Punkte frei!" : ""),
            "open:talents",
            "Talentbäume: Krieger · Bergmann · Unternehmer",
            "Dauerhaft, unabhängig vom Tiefenpass");
        int active = GearPresets.active(p);
        b(
            s,
            39,
            Material.ARMOR_STAND,
            "gear_chest",
            "Ausrüstungs-Sets" + (active >= 0 ? " · " + GearPresets.of(p).get(active).name : ""),
            "open:presets",
            "Dungeon-, Mining- und Boss-Ausrüstung speichern",
            "und mit einem Klick wechseln");
      }
      case "presets" -> {
        List<GearPresets.Preset> presets = GearPresets.of(p);
        int active = GearPresets.active(p);
        b(
            s,
            4,
            Material.ARMOR_STAND,
            "gear_chest",
            "AUSRÜSTUNGS-SETS",
            null,
            "Speichere deine Ausrüstung als Set und wechsle mit einem Klick.",
            "Z. B. ein Dungeon-Set (Kampf) und ein Mining-Set (Abbau).",
            "Teile in einem Set sind vor Verkaufen/Zerlegen geschützt.",
            "Befehl: /df sets [1-4|Name] · /df sets name <1-4> <Name>",
            "Leeren: /df sets leeren <1-4>");
        String[] models = {"weapon_sword", "drill", "unique_1", "gear_chest"};
        for (int i = 0; i < GearPresets.SLOTS; i++) {
          GearPresets.Preset preset = presets.get(i);
          List<String> lore = new ArrayList<>();
          if (preset.items.isEmpty()) lore.add("Noch leer – unten „Speichern“ klicken.");
          for (Gear.Slot slot : Gear.Slot.values()) {
            String id = preset.items.get(slot.name());
            if (id == null) continue;
            Gear.Item item = Gear.find(p, id);
            lore.add(Gear.slotName(slot) + ": " + (item == null ? "fehlt (verkauft)" : item.name + " +" + item.level));
          }
          lore.add("");
          lore.add(i == active ? "✔ GERADE AKTIV" : "");
          lore.add("Klick: Set bearbeiten (Teile wählen/entfernen)");
          b(
              s,
              19 + i * 2,
              i == active ? Material.EMERALD : Material.PAPER,
              models[i],
              (i + 1) + " · " + preset.name + (i == active ? " · AKTIV" : ""),
              "open:preset/" + i,
              lore.toArray(String[]::new));
          b(
              s,
              10 + i * 2,
              preset.items.isEmpty() ? Material.GRAY_DYE : Material.BARRIER,
              preset.items.isEmpty() ? null : "close",
              preset.items.isEmpty() ? "Leer" : "Set leeren",
              preset.items.isEmpty() ? null : "preset:clear:" + i,
              preset.items.isEmpty()
                  ? "In diesem Set ist nichts gespeichert."
                  : "Entfernt alle Teile aus „" + preset.name + "“.",
              "Deine Ausrüstung bleibt angelegt; der Verkaufsschutz entfällt.");
          b(
              s,
              28 + i * 2,
              Material.WRITABLE_BOOK,
              "handbook",
              "Aktuelle Ausrüstung speichern",
              "preset:save:" + i,
              "Überschreibt Set " + (i + 1) + " „" + preset.name + "“",
              "mit allem, was du gerade trägst (" + p.equipped.size() + " Teile).");
          b(
              s,
              37 + i * 2,
              i == active ? Material.LIME_DYE : preset.items.isEmpty() ? Material.GRAY_DYE : Material.EMERALD,
              i == active ? "preset_active" : "preset",
              i == active ? "✔ Aktiv" : preset.items.isEmpty() ? "Noch leer" : "Auf aktiv stellen",
              i == active || preset.items.isEmpty() ? null : "preset:apply:" + i,
              i == active
                  ? "Dieses Set trägst du gerade."
                  : preset.items.isEmpty()
                      ? "Erst Ausrüstung anlegen und oben „Speichern“ klicken."
                      : "Legt alle Teile von „" + preset.name + "“ an.");
        }
      }
      case "milestones" -> {
        b(
            s,
            4,
            Material.GOAT_HORN,
            "relic",
            "MEILENSTEINE · " + p.milestones.size() + " / " + Milestones.GOALS.size() * 3,
            null,
            "Jedes Ziel hat drei Stufen. Belohnung per Klick abholen.",
            "Stufe 1: " + Milestones.reward(0),
            "Stufe 2: " + Milestones.reward(1),
            "Stufe 3: " + Milestones.reward(2));
        for (int i = 0; i < Milestones.GOALS.size(); i++) {
          Milestones.Goal g = Milestones.GOALS.get(i);
          int tier = Milestones.claimed(p, g.id());
          long have = Milestones.progress(p, g.id());
          boolean ready = Milestones.claimable(p, g);
          b(
              s,
              18 + i,
              ready ? Material.CHEST : tier >= 3 ? Material.EMERALD : Material.PAPER,
              ready ? "crate" : "relic",
              g.title() + " · Stufe " + Math.min(3, tier + (ready ? 1 : 0)) + " / 3",
              ready ? "milestone:" + g.id() : null,
              tier >= 3
                  ? "Abgeschlossen · " + have + " " + g.unit()
                  : "Fortschritt: " + Math.min(have, g.targets()[tier]) + " / " + g.targets()[tier],
              g.unit(),
              tier >= 3 ? "Alle Stufen abgeholt" : "Belohnung: " + Milestones.reward(tier),
              ready ? "Klick: Belohnung abholen" : tier >= 3 ? "" : "Noch nicht erreicht");
        }
      }
      case "drone" -> {
        if (p.droneLevel <= 0) {
          b(
              s,
              4,
              Material.LANTERN,
              "drone_0",
              "FUNKE · deine Dampfdrohne",
              null,
              "Folgt dir über der Schulter – im Bergwerk und im Gewölbe.",
              "Warnt dich, kurz bevor ein Bossangriff dich trifft.",
              "Piept, wenn eine reiche Ader auf deiner Ebene funkelt.",
              "Module: Sammler (Erz) · Geschütz (Schaden) · Sanitäter (Heilung)");
          b(
              s,
              22,
              Material.ANVIL,
              "drone_0",
              "Funke bauen · " + DroneRules.BUILD_MONEY + " $",
              "drone:build",
              "Dein Geld: " + p.money + " $");
          break;
        }
        b(
            s,
            4,
            Material.LANTERN,
            "drone_" + p.droneSkin,
            "FUNKE · Stufe " + p.droneLevel + " / " + DroneRules.MAX_LEVEL,
            null,
            "Modul: " + DroneRules.MODULES[p.droneModule] + " – " + DroneRules.effect(p.droneModule, p.droneLevel),
            "Aussehen: " + DroneRules.SKINS[p.droneSkin],
            "Bisher: " + p.droneOre + " Erz gefunden · " + p.droneShots + " Bolzen · " + p.droneHealed + "× geheilt",
            "Warnt dich vor Bossangriffen und reichen Adern.");
        int l = p.droneLevel;
        b(
            s,
            20,
            Material.ANVIL,
            "drone_" + p.droneSkin,
            l >= DroneRules.MAX_LEVEL ? "Höchststufe erreicht" : "Verbessern auf Stufe " + (l + 1),
            l >= DroneRules.MAX_LEVEL ? null : "drone:up",
            l >= DroneRules.MAX_LEVEL
                ? "Funke ist voll ausgebaut"
                : "Kosten: " + DroneRules.upgradeMoney(l) + " $ · " + DroneRules.upgradeDust(l) + " Staub"
                    + (DroneRules.upgradeRelics(l) > 0 ? " · " + DroneRules.upgradeRelics(l) + " Relikte" : ""),
            l >= DroneRules.MAX_LEVEL ? "" : "Danach: " + DroneRules.effect(p.droneModule, l + 1));
        b(
            s,
            24,
            p.droneHidden ? Material.GRAY_DYE : Material.LIME_DYE,
            null,
            p.droneHidden ? "Funke rufen" : "Funke ausruhen lassen",
            "drone:toggle",
            p.droneHidden ? "Funke ist gerade in der Werkstatt" : "Funke begleitet dich");
        Material[] icons = {Material.IRON_PICKAXE, Material.CROSSBOW, Material.GLISTERING_MELON_SLICE};
        for (int m = 0; m < DroneRules.MODULES.length; m++)
          b(
              s,
              29 + m * 2,
              icons[m],
              null,
              (m == p.droneModule ? "✔ " : "") + "Modul: " + DroneRules.MODULES[m],
              m == p.droneModule ? null : "drone:module:" + m,
              DroneRules.MODULE_INFO[m],
              DroneRules.effect(m, p.droneLevel));
        for (int k = 0; k < DroneRules.SKINS.length; k++) {
          boolean open = DroneRules.skinUnlocked(l, k);
          b(
              s,
              37 + k * 2,
              open ? Material.LANTERN : Material.BARRIER,
              open ? "drone_" + k : "close",
              (k == p.droneSkin ? "✔ " : "") + "Aussehen: " + DroneRules.SKINS[k],
              open && k != p.droneSkin ? "drone:skin:" + k : null,
              open ? "Freigeschaltet" : "Ab Funke-Stufe " + DroneRules.SKIN_LEVEL[k]);
        }
      }
      case "reward" -> {
        if (LootChests.available(p))
          b(
              s,
              51,
              Material.ENDER_CHEST,
              "crate",
              "Gewölbekiste kaufen · " + Hud.money(LootChests.price(p)),
              "chest:buy",
              "Eine zusätzliche Ausrüstung aus deinem letzten Sieg",
              "(Gebiet " + (p.chestZone + 1) + ", " + DungeonRules.MODES[p.chestMode] + ", Level "
                  + p.chestLevel + ") + Schmiedestaub",
              "Noch " + (LootChests.MAX - p.chestBought) + " von " + LootChests.MAX
                  + " Kisten · jede weitere kostet das Doppelte",
              "Dein Geld: " + Hud.money(p.money));
        RewardDiff gain = plugin.lastReward(player);
        if (gain == null) {
          b(
              s,
              4,
              Material.CHEST,
              "crate",
              "DUNGEON-BEUTE",
              null,
              "Noch keine Dungeon-Beute seit dem Serverstart.",
              "Starte einen Lauf: /df dungeon");
          break;
        }
        List<String> summary = new ArrayList<>();
        for (String line : gain.lines()) if (line.startsWith("+") || line.startsWith("Dungeon")) summary.add(line);
        b(
            s,
            4,
            Material.CHEST,
            "crate",
            "DUNGEON-BEUTE · " + gain.headline(),
            null,
            summary.toArray(String[]::new));
        int slot = 19;
        for (Gear.Item gained : gain.items) {
          Gear.Item item = Gear.find(p, gained.id);
          if (item == null || slot > 43) continue;
          if (slot % 9 == 8) slot += 2;
          b(
              s,
              slot++,
              Material.PAPER,
              item.model(),
              "✦ NEU · " + item.name + " +" + item.level,
              "open:item/" + item.id,
              gearLore(p, item));
        }
        if (gain.items.isEmpty())
          b(s, 22, Material.PAPER, "handbook", "Diesmal keine Ausrüstung", null, "Geld und Materialien stehen oben.");
        b(s, 40, Material.CHEST, "crate", "Zum Beutel", "open:loot/0");
      }
      case "daily" -> {
        java.time.LocalDate today = plugin.today();
        if (Dailies.ensure(p, today)) plugin.commit(player, p);
        int streak = Dailies.liveStreak(p, today);
        b(
            s,
            4,
            Material.CLOCK,
            "clock",
            "TAGESAUFTRÄGE · " + Dailies.claimedCount(p) + " / " + Dailies.COUNT,
            null,
            "Jeden Tag um Mitternacht drei neue Aufträge.",
            "Je Auftrag: " + Dailies.money(p) + " $ + 1 Schmiedestaub",
            "Alle drei: +" + Dailies.bonusMoney(p, streak + (p.dailyBonusClaimed ? 0 : 1)) + " $, 2 Staub,",
            "1 Relikt und 1 Unterlage. Die Serie erhöht den Bonus (bis 7 Tage).");
        String[] icons = {"ore_iron", "worker", "crate"};
        for (int i = 0; i < Dailies.COUNT && i < p.dailyTasks.size(); i++) {
          Dailies.Task t = Dailies.task(p.dailyTasks.get(i));
          if (t == null) continue;
          boolean claimed = p.dailyClaimed[i], ready = !claimed && Dailies.done(p, i);
          b(
              s,
              20 + i * 2,
              claimed ? Material.EMERALD : ready ? Material.CHEST : Material.PAPER,
              claimed ? "relic" : ready ? "crate" : icons[i],
              (claimed ? "✓ " : "") + t.title() + " · " + Dailies.progress(p, i) + " / " + p.dailyTarget[i],
              ready ? "daily:" + i : null,
              t.unit() + " seit Beginn des Tages",
              "Belohnung: " + Dailies.money(p) + " $ + 1 Schmiedestaub",
              claimed ? "Heute erledigt" : ready ? "Klick: Belohnung abholen" : "Noch nicht erreicht");
        }
        b(
            s,
            40,
            Material.BLAZE_POWDER,
            "relic",
            "Serie: " + streak + " Tag" + (streak == 1 ? "" : "e"),
            null,
            "Rekord: " + p.dailyBestStreak + " Tage",
            p.dailyBonusClaimed
                ? "Heute alle drei geschafft – morgen weitermachen!"
                : "Alle drei heute abschließen, sonst reißt die Serie.");
      }
      case "top" -> {
        List<Profile> everyone = plugin.rankingProfiles();
        b(
            s,
            4,
            Material.GOLDEN_HELMET,
            "coin",
            "RANGLISTE · " + everyone.size() + " Spieler",
            null,
            "Alle gespeicherten Spielstände dieses Servers.",
            "Wird alle 30 Sekunden aktualisiert.");
        int[] slots = {10, 12, 14, 16, 19, 25, 28, 30, 32, 34, 22, 40};
        for (int i = 0; i < Leaderboard.BOARDS.size() && i < slots.length; i++) {
          Leaderboard.Board board = Leaderboard.BOARDS.get(i);
          List<String> lore = new ArrayList<>();
          List<Leaderboard.Entry> top = Leaderboard.top(everyone, board, 5);
          for (int r = 0; r < top.size(); r++)
            lore.add((r + 1) + ". " + top.get(r).name() + " – " + Hud.money(top.get(r).score()).replace(" $", "") + " " + board.unit());
          if (top.isEmpty()) lore.add("Noch niemand eingetragen.");
          int rank = Leaderboard.rank(everyone, board, p.id);
          lore.add("");
          lore.add(rank == 0 ? "Du bist noch nicht platziert." : "Dein Platz: #" + rank + " (" + board.score().applyAsLong(p) + ")");
          b(
              s,
              slots[i],
              rank == 1 ? Material.GOLD_BLOCK : rank > 0 && rank <= 3 ? Material.GOLD_INGOT : Material.PAPER,
              rank > 0 && rank <= 3 ? "coin" : "handbook",
              board.title(),
              null,
              lore.toArray(String[]::new));
        }
      }
      case "codex" -> {
        b(
            s,
            4,
            Material.BOOK,
            "handbook",
            "BEUTEBUCH & SCHMIEDE",
            null,
            "Ausrüstungswurf pro Boss: 60 % ungewöhnlich, 30 % selten, 9 % episch, 1 % legendär",
            "Zusätzlich: 2 % benannter Bossgegenstand; Alptraum zusätzlich 0,2 % mythisch",
            "Spätestens der 10. erfolglose Wurf wird episch oder besser",
            "Schmiedestaub: " + p.dust);
        for (int z = 0; z < Zone.COUNT; z++)
          b(
              s,
              9 + z,
              Material.PAPER,
              "ore_" + Zone.at(z).key,
              Gear.UNIQUE[z],
              "craft:" + z,
              "Quelle: " + BossRules.NAMES[z],
              Gear.effect(z % 7),
              "Gefunden: " + (p.discovered.contains(Gear.UNIQUE[z]) ? "Ja" : "Noch nicht"),
              "Fragmente: "
                  + p.bossTokens[z]
                  + " / 40 | "
                  + Gear.MATERIALS[z]
                  + ": "
                  + p.monsterParts[z]
                  + " / 30",
              "Klick: legendär herstellen für Materialien + " + Gear.craftCost(z) + " $",
              "Normal/Veteran/Alptraum-Siege: "
                  + p.bossWins[z * 3]
                  + " / "
                  + p.bossWins[z * 3 + 1]
                  + " / "
                  + p.bossWins[z * 3 + 2]);
        for (int z = 0; z < Zone.COUNT; z++)
          b(
              s,
              27 + z,
              Material.IRON_SWORD,
              "weapon_dagger",
              "Jagd: " + Zone.at(z).title,
              "hunt:" + z,
              "Fortschritt: " + p.huntKills[z] + " / 15 reguläre Gegner",
              "Belohnung: " + Gear.huntCash(z) + " $, 3 Staub, 6 Monsterteile",
              "Erledigte Aufträge: " + p.huntsCompleted[z],
              p.huntKills[z] >= Gear.HUNT_TARGET
                  ? "Klick: abholen – danach startet ein neuer Auftrag bei 0"
                  : "Weitere Gegner zählen erst nach dem Abholen. Helfer zählen nicht.");
      }
      case "boss" -> {
        int zone = player == null ? p.zone : plugin.mines().zoneAt(p, player.getLocation());
        if (zone < 0) {
          return create(player, p, "main");
        }
        b(
            s,
            4,
            Material.NETHER_STAR,
            "relic",
            BossRules.NAMES[zone],
            null,
            "Warnflächen meiden; Haltung brechen und Kernfenster nutzen",
            "Rechtsklick: Waffenfähigkeit | Sneak+Rechtsklick: Ausweichen",
            "Tod, Rückkehr oder Verlassen der Arena beendet den Kampf");
        for (int mode = 0; mode < 3; mode++)
          b(
              s,
              20 + mode * 2,
              Material.IRON_SWORD,
              "weapon_" + (mode == 0 ? "sword" : mode == 1 ? "hammer" : "spear"),
              new String[] {"Normal", "Veteran", "Alptraum"}[mode],
              "fight:" + mode,
              BossRules.unlocked(p, zone, mode)
                  ? "Bereit"
                  : "Zuerst vorherige Schwierigkeit besiegen",
              "Bossleben: " + (int) RapidCombat.bossHealth(zone, mode),
              "Fragmente: "
                  + (2 + mode)
                  + " | Zeitlimit: "
                  + RapidCombat.BOSS_TIME_MINUTES
                  + " Minuten",
              "Rückenangriffe provozieren einen Rundumschlag!");
      }
      case "main" -> {
        DeepPass.ensure(p, plugin.today());
        int passOpen = DeepPass.claimableCount(p);
        long[] passProgress = DeepPass.progress(p);
        b(
            s,
            30,
            Material.NETHER_STAR,
            "relic",
            "Tiefenpass · Stufe " + DeepPass.tier(p) + (passOpen > 0 ? " · " + passOpen + " abholbar!" : ""),
            "open:pass/" + Math.min(3, DeepPass.tier(p) / 9),
            "30 Belohnungsstufen pro Saison (28 Tage)",
            "XP: " + passProgress[0] + " / " + passProgress[1],
            "XP für Erz, Monster, Dungeons, Tagesaufgaben …");
        Guilds.Guild myGuild = Guilds.of(p);
        b(
            s,
            37,
            Material.CYAN_BANNER,
            "guild_banner",
            myGuild == null ? "Gilde" : "Gilde · " + myGuild.name + " [" + myGuild.tag + "]",
            myGuild == null ? "open:guildnone" : "open:guild",
            myGuild == null ? "Gründen oder beitreten: /df gilde" : "Level " + Guilds.level(myGuild) + " · Kasse " + myGuild.bank + " $",
            "Stützpunkt, Wochenaufträge, Gildenchat");
        Companions.Companion pet = Companions.active(p);
        long readyEggs =
            p.eggs.stream().filter(e -> Companions.ready(e, System.currentTimeMillis())).count();
        b(
            s,
            39,
            Material.SNIFFER_EGG,
            "egg_epic",
            "Begleiter & Brutstätte" + (readyEggs > 0 ? " · " + readyEggs + " schlüpfbereit!" : ""),
            "open:pets",
            pet == null ? "Kein Begleiter aktiv" : "Aktiv: " + Companions.name(pet),
            p.eggs.size() + " Eier · " + p.companions.size() + " Begleiter");
        var event = plugin.events().current();
        b(
            s,
            8,
            event != null ? Material.BEACON : Material.CLOCK,
            event != null ? null : "clock",
            event != null ? "WELTEREIGNIS: " + event.title : "Weltereignisse",
            null,
            plugin.events().status(),
            "Goldrausch · Erzrausch · Monsterflut · Tiefenfieber · Championjagd",
            "Gelten für alle Spieler gleichzeitig");
        b(
            s,
            10,
            Material.IRON_PICKAXE,
            "drill",
            "Bergbau",
            "open:mining",
            "Minen betreten · Bohrer verbessern",
            "Erze einlagern, schmelzen und verkaufen");
        b(
            s,
            12,
            Material.IRON_AXE,
            null,
            "Wald & Sägewerk",
            "open:forestry",
            "Bäume fällen · Holz verarbeiten",
            "Axt, Glück und Holzlager verbessern");
        b(
            s,
            19,
            Material.IRON_SWORD,
            "weapon_sword",
            "Kampf & Ausrüstung",
            "open:combat",
            "Charakter · Beute · Dungeons",
            "Gefundene Gegenstände ausrüsten");
        b(
            s,
            14,
            Material.PLAYER_HEAD,
            "worker",
            "Arbeiter & Betrieb",
            "open:business",
            "Arbeiter einstellen und zuweisen",
            "Brennstoff, Budget und Offline-Produktion");
        b(
            s,
            16,
            Material.MAP,
            "handbook",
            "Aufträge & Abenteuer",
            "open:goals",
            "Lieferungen · Sammlungen · Forschung",
            "Beuteziele und Fortschritt ansehen");
        b(
            s,
            47,
            Material.BOOK,
            "handbook",
            "Starthilfe & Tutorial",
            "adventure:tutorial",
            "Schritt für Schritt mit Belohnungen",
            "Du kannst das Tutorial jederzeit fortsetzen");
        b(
            s,
            28,
            Material.MAP,
            "handbook",
            "Nächstes Ziel",
            "quest",
            Economy.questText(p.quest),
            "Klick: Belohnung abholen, sobald erfüllt");
        b(
            s,
            41,
            Material.LANTERN,
            "drone_" + p.droneSkin,
            p.droneLevel > 0 ? "Funke · Stufe " + p.droneLevel : "Funke · Dampfdrohne bauen",
            "open:drone",
            p.droneLevel > 0
                ? "Modul: " + DroneRules.MODULES[p.droneModule]
                : "Begleiter: sammelt Erz, kämpft mit oder heilt dich");
        b(
            s,
            32,
            Material.CLOCK,
            "clock",
            "Tagesaufträge · " + Dailies.claimedCount(p) + "/" + Dailies.COUNT
                + (Dailies.readyCount(p) > 0 ? " · abholbar!" : ""),
            "open:daily",
            "Neue Aufgaben jeden Tag · Serie: " + Dailies.liveStreak(p, plugin.today()) + " Tage");
        b(
            s,
            43,
            Material.AMETHYST_SHARD,
            "healing_crystal",
            "Heilen · " + p.healingCharges + "/" + Healing.capacity(p) + " Splitter",
            "heal",
            "4 LP + 35 % maximales Leben",
            "Verbraucht 1 Splitter · 20 s Pause",
            "Rechtsklick: 1 nachkaufen · " + Healing.price(p) + " $",
            "Shift-Klick: Vorrat auffüllen",
            "Nachkaufen nicht im Dungeon – vorher auffüllen!");
        int week = DeepDescent.currentWeek();
        b(
            s,
            23,
            Material.SCULK_CATALYST,
            "deep_descent",
            "Tiefengang · endlos",
            DeepDescent.unlocked(p) ? "deep" : null,
            "Ebene um Ebene hinab – jede härter, jede 5. mit Boss",
            "Belohnung nach jeder Ebene · Boss-Ebenen: Ausrüstung + Rune",
            "Diese Woche: Ebene " + DeepDescent.weekBest(p, week) + " · Rekord: Ebene " + p.deepBest,
            DeepDescent.unlocked(p)
                ? "Mit Party: alle zusammen · /df tiefengang"
                : "Freischalten: einen Dungeon gewinnen");
        b(
            s,
            25,
            Material.AMETHYST_CLUSTER,
            "rune_bag",
            "Runen · " + Runes.total(p) + " im Beutel",
            "open:runes",
            "Runen in Ausrüstungs-Sockel einsetzen",
            "Jede Rune zählt direkt zu deinen Grundwerten",
            "Runenschmiede: 3 gleiche → 1 höhere");
              b(
            s,
            21,
            Material.CHISELED_STONE_BRICKS,
            "crate",
            "Dungeons",
            "dungeon",
            "Runengewölbe · Glutschmiede · Frostkrypta",
            "Solo oder mit Party · Level frei wählbar",
            "Erster Sieg des Tages: doppeltes Geld");
        b(
            s,
            34,
            Material.GOLD_BLOCK,
            "coin",
            "Rangliste",
            "open:top",
            "Reichste, Fleißigste, Tiefengang der Woche …");
        b(
            s,
            51,
            Material.CHISELED_BOOKSHELF,
            "museum",
            "Museum · " + Archaeology.donatedCount(p) + "/" + Archaeology.ALL.size() + " Fundstücke",
            "open:museum",
            "Fundstücke aus dem Erzabbau stiften",
            "Sammlungsbuch: was fehlt noch?",
            "Bonus: +" + Math.round(Archaeology.bonus(p) * 100) + " % Schaden & Erzwert");
        b(
            s,
            2,
            Material.BREWING_STAND,
            "alchemy_table",
            "Alchemie · " + Alchemy.activeCount(p, System.currentTimeMillis()) + " Tränke aktiv",
            "open:alchemy",
            "Stärke, Zähigkeit, Bergmann, Gold, Flink, Schutz",
            "Zutaten: Monster, Erzabbau, Baumfällen",
            "Braumeister " + Alchemy.level(p) + " · Befehl: /df alchemie");
        b(
            s,
            6,
            Material.NETHER_STAR,
            "prestige_star",
            p.prestige == 0 ? "Prestige" : "Prestige " + Prestige.badge(p.prestige),
            "open:prestige",
            Prestige.ready(p) ? "BEREIT! Neu beginnen – stärker belohnt" : Prestige.requirement(p),
            "Tiefenglut: " + p.glut + " frei",
            "Gegner härter, Beute besser – ohne Obergrenze");
        b(
            s,
            0,
            Material.KNOWLEDGE_BOOK,
            "wiki",
            "WIKI · Alles erklärt",
            "wiki",
            "Jedes Item, jede Chance, jede Mechanik",
            "Öffnet ein Fenster zum Durchblättern",
            "Auch mit /df wiki");
      }
      case "mining" -> {
        b(
            s,
            19,
            Material.IRON_PICKAXE,
            "drill",
            "1 · Mine betreten",
            "mine:" + p.zone,
            Zone.at(p.zone).title);
        b(
            s,
            22,
            Material.BARREL,
            "crate",
            "2 · Einlagern & Schmelzen",
            "open:storage",
            "Erz → Lager → Barren → Verkauf");
        b(
            s,
            25,
            Material.ANVIL,
            "blade",
            "3 · Werkzeuge verbessern",
            "open:gear",
            "Bohrer, Grundwaffe, Schutz, Rucksack und Erzglück");
        b(s, 30, Material.MINECART, "scanner", "Andere Mine / Gebiet freischalten", "open:travel");
        b(s, 32, Material.CHEST, "crate", "Versteckte Fundkisten", "open:expeditions");
      }
      case "combat" -> {
        // Row 3: character, loot, runes, dungeons · row 4: forge, codex, upgrades (+ last reward),
        // centred · row 5: healing in the middle.
        b(
            s,
            19,
            Material.ARMOR_STAND,
            "gear_chest",
            "Charakter & Gesamtwerte",
            "open:character",
            "Aktive Ausrüstung und Kampfwerte");
        b(
            s,
            21,
            Material.CHEST,
            "crate",
            "Gefundene Ausrüstung" + (unseen(p) > 0 ? " · " + unseen(p) + " NEU" : ""),
            "open:loot/0",
            p.gear.size() + " Gegenstände · ausrüsten oder verbessern");
        b(
            s,
            23,
            Material.AMETHYST_CLUSTER,
            "rune_bag",
            "Runen · " + Runes.total(p) + " im Beutel",
            "open:runes",
            "Runen in Ausrüstungs-Sockel einsetzen",
            "Runenschmiede: 3 gleiche → 1 höhere",
            "Champions besiegt: " + p.champions);
        b(
            s,
            25,
            Material.ENDER_EYE,
            "relic",
            "Party & Dungeon",
            "dungeon",
            "Solo oder mit bis zu 4 Spielern");
        boolean reward = plugin.lastReward(player) != null;
        int[] row = reward ? new int[] {28, 30, 32, 34} : new int[] {29, 31, 33};
        b(
            s,
            row[0],
            Material.SMITHING_TABLE,
            "blade",
            "Set-Schmiede",
            "adventure:setforge",
            "2 doppelte Set-Teile → 1 fehlendes Teil deiner Wahl");
        b(s, row[1], Material.BOOK, "handbook", "Bossbeute & Rezepte", "open:codex");
        b(
            s,
            row[2],
            Material.ANVIL,
            "blade",
            "Grundwaffe & Schutz verbessern",
            "open:gear",
            "Dauerhafte Grund-Upgrades; Beute separat im Beutel");
        if (reward)
          b(
              s,
              row[3],
              Material.GOLD_INGOT,
              "coin",
              "Letzte Dungeon-Beute",
              "open:reward",
              plugin.lastReward(player).headline());
        b(
            s,
            40,
            Material.AMETHYST_SHARD,
            "healing_crystal",
            "Heilen · " + p.healingCharges + " Splitter",
            "heal",
            "Verbraucht 1 Splitter · 20 s Pause",
            "Rechtsklick: 1 nachkaufen · " + Healing.price(p) + " $",
            "Shift-Klick: Vorrat auffüllen",
            "Nachkaufen nicht im Dungeon – vorher auffüllen!");
      }
      case "business" -> {
        b(
            s,
            19,
            Material.PLAYER_HEAD,
            "worker",
            "1 · Arbeiter verwalten",
            "open:crew",
            "Anstellen, Mine zuweisen, Schicht und Ausbildung");
        b(
            s,
            22,
            Material.BLAST_FURNACE,
            "machine_furnace",
            "2 · Betrieb versorgen",
            "open:factory",
            "Brennstoff und Lohnbudget bereitstellen");
        b(
            s,
            25,
            Material.BARREL,
            "crate",
            "3 · Waren verwalten",
            "open:storage",
            "Lagerbestände, Schmelzen und Verkauf");
        b(s, 30, Material.ENCHANTED_BOOK, "relic", "Betriebsforschung", "open:research");
        b(s, 32, Material.PAPER, "handbook", "Letzte Offline-Abrechnung", "report");
      }
      case "goals" -> {
        b(
            s,
            19,
            Material.PAPER,
            "handbook",
            "Material liefern",
            "open:contracts",
            "Erze, Barren und Monsterteile gegen Geld & Unterlagen");
        b(s, 22, Material.NETHER_STAR, "relic", "Abenteuerbuch & Artefakte", "adventure:journal");
        b(s, 25, Material.ENCHANTED_BOOK, "relic", "Forschung verbessern", "open:research");
        b(s, 30, Material.EMERALD, "coin", "Erzaufträge & Meilensteine", "open:trade");
        b(s, 32, Material.CHEST, "crate", "Fundkisten & Sammlungen", "open:expeditions");
        b(
            s,
            28,
            Material.CLOCK,
            "clock",
            "Tagesaufträge" + (Dailies.readyCount(p) > 0 ? " · " + Dailies.readyCount(p) + " abholbar" : ""),
            "open:daily",
            "Drei Aufgaben pro Tag mit Serienbonus");
        b(s, 34, Material.GOLDEN_HELMET, "coin", "Rangliste", "open:top", "Wer ist der Beste auf dem Server?");
      }
      case "forestry", "woodwork", "woodupgrades" -> {
        b(
            s,
            4,
            Material.OAK_LOG,
            null,
            "Holzlager · " + Forestry.used(p) + " / " + Forestry.capacity(p),
            null,
            woodLine(p, 0),
            woodLine(p, 1),
            woodLine(p, 2),
            "Stämme und Bretter zählen beide zum Lager",
            "Geld: " + p.money + " $ · Harz: " + p.resin + " · Brennstoff: " + p.fuel);
        // Tabs centred in row 2 (columns 3, 5, 7); the open one glows.
        tab(s, 11, Material.OAK_SAPLING, "1 · Wald", "forestry", page);
        tab(s, 13, Material.STONECUTTER, "2 · Verarbeiten & Verkaufen", "woodwork", page);
        tab(s, 15, Material.IRON_AXE, "3 · Verbessern", "woodupgrades", page);
        if (page.equals("forestry")) {
          b(
              s,
              29,
              Material.IRON_AXE,
              null,
              "Bäume fällen",
              null,
              "Vom Dorf nach Osten dem Kiesweg folgen.",
              "Forstaxt in die Hand nehmen.",
              "Am Stamm Linksklick halten, bis der Baum fällt.",
              "Erntebäume stehen in drei beschrifteten Hainen.",
              "Dekorationsbäume am Waldrand sind geschützt.");
          b(
              s,
              33,
              Material.OAK_SAPLING,
              null,
              p.forestTier == 2
                  ? "Alle Haine freigeschaltet"
                  : "Nächster Hain: " + Forestry.WOODS[p.forestTier + 1],
              p.forestTier == 2 ? null : "forest:unlock",
              "Birke: Axt 2 · 64 gefälltes Holz · 1.000 $",
              "Fichte: Axt 5 · 256 gefälltes Holz · 4.000 $",
              "Dein Fortschritt: Axt " + p.axe + " · " + p.woodChopped + " Holz");
          int species = p.woodOrders % (p.forestTier + 1);
          long amount = 24 + (p.woodOrders % 4) * 8L;
          b(
              s,
              31,
              Material.PAPER,
              "handbook",
              "Holzauftrag #" + (p.woodOrders + 1),
              "forest:contract:" + p.woodOrders,
              Forestry.WOODS[species] + ": " + p.wood[species] + " / " + amount,
              "Abgeben: " + amount + " Holz → " + amount * Forestry.PRICES[species] * 3 / 2 + " $",
              "Jeder fünfte Auftrag: +1 Harz");
          b(
              s,
              40,
              Material.CLOCK,
              "clock",
              "Bäume wachsen nach",
              null,
              "Eiche 45 s · Birke 60 s · Fichte 75 s",
              "Harz: seltener Fund beim Fällen");
        } else if (page.equals("woodwork")) {
          // One row per wood type in columns 2–6: stock · saw · sell logs · sell planks · sell both.
          // Column 8: everything at once, charcoal, fuel. Columns 2–8 sit centred in the menu.
          Material[] logs = {Material.OAK_LOG, Material.BIRCH_LOG, Material.SPRUCE_LOG};
          Material[] boards = {Material.OAK_PLANKS, Material.BIRCH_PLANKS, Material.SPRUCE_PLANKS};
          long value = 0;
          for (int i = 0; i < 3; i++) {
            int row = 19 + i * 9;
            long logValue = p.wood[i] * Forestry.PRICES[i];
            long plankValue = p.planks[i] * Forestry.PLANK_PRICES[i];
            value += logValue + plankValue;
            long batch = Math.min(16, Math.min(p.wood[i], p.fuel));
            batch =
                Math.min(
                    batch, Math.max(0, Forestry.capacity(p) - Forestry.used(p)) / (1 + p.sawmill));
            b(
                s,
                row,
                logs[i],
                null,
                Forestry.WOODS[i].toUpperCase(java.util.Locale.ROOT),
                null,
                p.wood[i] + " Stämme · " + p.planks[i] + " Bretter",
                "Stamm " + Forestry.PRICES[i] + " $ · Brett " + Forestry.PLANK_PRICES[i] + " $",
                "Sägen lohnt sich: 1 Stamm → " + (2 + p.sawmill) + " Bretter");
            b(
                s,
                row + 1,
                Material.STONECUTTER,
                null,
                "Sägen" + (batch > 0 ? " · " + batch + " → " + batch * (2 + p.sawmill) + " Bretter" : ""),
                batch > 0 ? "forest:saw:" + i : null,
                batch > 0
                    ? "Verbraucht " + batch + " Stämme und " + batch + " Brennstoff"
                    : p.wood[i] == 0
                        ? "Keine " + Forestry.WOODS[i] + "-Stämme"
                        : p.fuel == 0 ? "Kein Brennstoff (rechts kaufen)" : "Holzlager voll");
            b(
                s,
                row + 2,
                logs[i],
                null,
                "Stämme verkaufen · +" + logValue + " $",
                p.wood[i] > 0 ? "forest:sellwood:" + i : null,
                p.wood[i] + " × " + Forestry.PRICES[i] + " $",
                "Bretter bleiben im Lager");
            b(
                s,
                row + 3,
                boards[i],
                null,
                "Bretter verkaufen · +" + plankValue + " $",
                p.planks[i] > 0 ? "forest:sellplanks:" + i : null,
                p.planks[i] + " × " + Forestry.PLANK_PRICES[i] + " $",
                "Stämme bleiben im Lager");
            b(
                s,
                row + 4,
                Material.EMERALD,
                "coin",
                "Beides verkaufen · +" + (logValue + plankValue) + " $",
                logValue + plankValue > 0 ? "forest:sell:" + i : null,
                "Stämme und Bretter von " + Forestry.WOODS[i],
                "Die anderen Holzarten bleiben im Lager");
          }
          // Thin divider between the per-wood rows and the "everything" column.
          for (int slot : new int[] {24, 33, 42})
            b(s, slot, Material.GRAY_STAINED_GLASS_PANE, null, " ", null);
          b(
              s,
              25,
              Material.EMERALD_BLOCK,
              "coin",
              "Alles verkaufen · +" + value + " $",
              value > 0 ? "forest:sell" : null,
              "Alle Holzarten, Stämme und Bretter",
              "Holz für Aufträge vorher abgeben.");
          b(
              s,
              34,
              Material.CHARCOAL,
              "fuel",
              "10 Stämme → 20 Brennstoff",
              "forest:charcoal",
              "Verbraucht zuerst Eiche, dann Birke, dann Fichte.");
          b(
              s,
              43,
              Material.COAL,
              "fuel",
              "20 Brennstoff kaufen · 20 $",
              "fuel20",
              "Brennstoff: " + p.fuel + " · zum Sägen nötig");
        } else {
          // One centred row: columns 2, 4, 6, 8.
          forestUpgrade(
              s,
              p,
              28,
              "axe",
              "Forstaxt",
              p.axe,
              10,
              Material.IRON_AXE,
              "Abbaugeschwindigkeit "
                  + fmt(Forestry.speed(p))
                  + "× → "
                  + fmt(Forestry.speed(p) + .65)
                  + "×");
          forestUpgrade(
              s,
              p,
              30,
              "woodLuck",
              "Holzglück",
              p.woodLuck,
              10,
              Material.EMERALD,
              fmt(OreYield.multiplier(p.woodLuck))
                  + "× → "
                  + fmt(OreYield.multiplier(p.woodLuck + 1))
                  + "×",
              "Doppelte Ernte: "
                  + p.woodLuck * 10
                  + " % → "
                  + Math.min(100, (p.woodLuck + 1) * 10)
                  + " %");
          forestUpgrade(
              s,
              p,
              32,
              "woodStorage",
              "Holzlager",
              p.woodStorage,
              10,
              Material.BARREL,
              Forestry.capacity(p) + " → " + (Forestry.capacity(p) + 200) + " Plätze");
          forestUpgrade(
              s,
              p,
              34,
              "sawmill",
              "Sägewerk",
              p.sawmill,
              3,
              Material.STONECUTTER,
              (2 + p.sawmill) + " → " + (3 + p.sawmill) + " Bretter je Stamm");
        }
      }
      case "gear" -> {
        b(
            s,
            37,
            Material.EMERALD,
            "relic",
            String.format(
                Locale.GERMAN,
                "Erzglück %.1f× → %.1f×",
                OreYield.multiplier(p.oreLuck),
                OreYield.multiplier(p.oreLuck + 1)),
            p.oreLuck < 10 && p.money >= Economy.upgradeCost(p, "oreLuck") ? "buy:oreLuck" : null,
            "Aktuell " + p.oreLuck * 10 + " % Chance auf doppelte Beute",
            "Zusätzlich zu Modul- und Ausrüstungsboni",
            p.oreLuck >= 10
                ? "Maximum 2,0× erreicht"
                : "Kosten: " + Economy.upgradeCost(p, "oreLuck") + " $",
            p.oreLuck >= 10 ? "100 % Doppelbeute" : "Dein Geld: " + p.money + " $");
        b(s, 43, Material.IRON_AXE, null, "Holz-Upgrades", "open:woodupgrades");
        upgrade(s, p, 19, "tool", "Bohrer", p.tool, Material.IRON_PICKAXE, "drill");
        upgrade(s, p, 21, "sword", "Grubenklinge", p.sword, Material.IRON_SWORD, "blade");
        upgrade(s, p, 23, "armor", "Schutztraining", p.armor, Material.IRON_CHESTPLATE, "shield");
        upgrade(s, p, 25, "bag", "Rucksack", p.bagLevel, Material.BUNDLE, "crate");
        upgrade(s, p, 39, "potion", "Heiltasche", p.healStock, Material.AMETHYST_SHARD, "healing_crystal");
        b(
            s,
            30,
            Material.IRON_INGOT,
            "ore_iron",
            "Ertragsmodul" + (p.module == 0 ? " · Aktiv" : ""),
            "module:0",
            "Chance auf zusätzliche Erze");
        b(
            s,
            31,
            Material.REDSTONE,
            "drill",
            "Tempomodul" + (p.module == 1 ? " · Aktiv" : ""),
            "module:1",
            "35 % schneller, mehr Hitze");
        b(
            s,
            32,
            Material.AMETHYST_SHARD,
            "relic",
            "Suchermodul" + (p.module == 2 ? " · Aktiv" : ""),
            "module:2",
            "Höhere Chance auf Relikte");
        b(
            s,
            41,
            Material.SPYGLASS,
            "scanner",
            "Scanner / Überladung",
            null,
            "Sneak + Rechtsklick mit Bohrer: Scanner",
            "Rechtsklick: 8 Sek. Überladung, 45 Sek. Abklingzeit");
      }
      case "crew" -> {
        b(
            s,
            13,
            Material.BELL,
            "worker",
            "Mannschaft · " + p.workers.size() + " / " + p.workerSlots(),
            null,
            "Arbeiter anklicken: Auftrag, Ausbildung und Schicht.",
            "Brennstoff: " + p.fuel + " · Lohnbudget: " + p.budget + " $",
            "Neue Einstellung: " + 1500L * (p.workers.size() + 1) + " $");
        b(s, 31, Material.COAL, "fuel", "Brennstoff & Lohnbudget auffüllen", "open:factory");
        int[] places = workerSlots(p.workers.size());
        for (int i = 0; i < p.workers.size(); i++) {
          Profile.Worker w = p.workers.get(i);
          b(
              s,
              places[i],
              Material.PLAYER_HEAD,
              "worker",
              w.name + " · Stufe " + w.level,
              "open:worker/" + i,
              jobName(w.job),
              workplace(p, w),
              "Arbeit: " + w.workMinutes + " Minuten",
              String.format(Locale.GERMAN, "%.2f", Industry.rate(p, w))
                  + " Waren/Min. · ~"
                  + Industry.hourlyValue(p, w)
                  + " $ Warenwert/h",
              "Lohn: " + Industry.wage(w) + " $ je Lieferung + "
                  + (w.job == Profile.Job.TRADER ? "10" : "20")
                  + " % vom Warenwert",
              Industry.nextFind(w));
          var item = s.inv.getItem(places[i]);
          var meta = item.getItemMeta();
          var lore = new ArrayList<>(meta.lore());
          lore.add(
              Component.text(
                  (player == null ? "Bereit" : plugin.workerStatus(player, i)),
                  NamedTextColor.AQUA));
          meta.lore(lore);
          item.setItemMeta(meta);
        }
        b(
            s,
            37,
            Material.IRON_PICKAXE,
            "drill",
            "Bergarbeiter einstellen",
            "hire:MINER",
            "Kosten: " + 1500L * (p.workers.size() + 1) + " $",
            "Voraussetzung: Steinwächter besiegt");
        b(
            s,
            39,
            Material.BLAST_FURNACE,
            "machine_furnace",
            "Schmelzer einstellen",
            "hire:SMELTER",
            "Benötigt eine Schmelze");
        b(
            s,
            41,
            Material.EMERALD,
            "coin",
            "Händler einstellen",
            "hire:TRADER",
            "Benötigt Gebiet 2; verkauft zugewiesene Ware");
        b(
            s,
            43,
            Material.IRON_AXE,
            null,
            "Holzfäller einstellen",
            "hire:LUMBERJACK",
            "Fällt Bäume einer Holzart ins Holzlager",
            "Braucht keinen Brennstoff · findet ab und zu Harz");
      }
      case "factory" -> {
        b(
            s,
            37,
            Material.GOLD_NUGGET,
            "coin",
            "100 $ Betriebsbudget bereitstellen",
            "budget100",
            "Kleine Versorgung für den Anfang");
        b(s, 39, Material.COAL, "fuel", "20 Brennstoff für 20 $", "fuel20");
        b(s, 43, Material.ENCHANTED_BOOK, "relic", "Betriebsforschung", "open:research");
        upgrade(s, p, 20, "warehouse", "Lager", p.warehouse, Material.BARREL, "crate");
        upgrade(
            s, p, 22, "furnace", "Schmelze", p.furnace, Material.BLAST_FURNACE, "machine_furnace");
        upgrade(s, p, 24, "housing", "Unterkunft", p.housing, Material.BELL, "worker");
        b(
            s,
            29,
            Material.COAL,
            "fuel",
            "Brennstoff: " + p.fuel,
            "fuel",
            "+120 Einheiten für 120 $",
            "1 Einheit je arbeitendem Förderer/Schmelzer pro Minute");
        b(
            s,
            31,
            Material.GOLD_INGOT,
            "coin",
            "Betriebsbudget: " + p.budget + " $",
            "budget",
            "1.000 $ aus deinem Geld bereitstellen",
            "Löhne werden nur bei tatsächlicher Arbeit berechnet");
        b(
            s,
            33,
            Material.CLOCK,
            "clock",
            "Offline-Produktion: bis " + p.offlineHours() + " Stunden",
            null,
            "Stoppt bei fehlender Versorgung oder vollem Lager",
            "Händler benötigen keinen Brennstoff");
        b(s, 41, Material.PAPER, "handbook", "Letzte Abrechnung", "report");
      }
      case "storage" -> {
        // Ores fill rows 2–3; actions below in two centred rows.
        b(
            s,
            41,
            Material.OAK_LOG,
            null,
            "Holzlager · " + Forestry.used(p) + " / " + Forestry.capacity(p),
            "open:woodwork",
            woodLine(p, 0),
            woodLine(p, 1),
            woodLine(p, 2),
            "Klick: sägen oder verkaufen");
        for (int z = 0; z < Zone.COUNT; z++)
          b(
              s,
              9 + z,
              Material.IRON_INGOT,
              "ore_" + Zone.at(z).key,
              Zone.at(z).oreName,
              z <= p.zone ? "open:smelt" : null,
              "Rucksack: " + p.bag[z],
              "Lager: " + p.stock[z],
              Industry.barName(z) + ": " + p.bars[z],
              z <= p.zone ? "Klick: Schmelzen öffnen" : "Gebiet noch gesperrt");
        b(s, 28, Material.HOPPER, "crate", "Rucksack einlagern", "deposit");
        b(
            s,
            32,
            Material.RAW_IRON,
            "coin",
            "Nur Erze verkaufen",
            "sellore",
            "Verkauft Rucksack und Lagererz",
            "Barren bleiben für Forschung und Aufträge");
        b(
            s,
            39,
            Material.GOLD_INGOT,
            "coin",
            "Alle Waren verkaufen",
            "sell",
            "Verkauft Rucksack, Lager und Barren",
            "Auftragsmaterial vorher abgeben!");
        b(
            s,
            34,
            Material.GOLD_INGOT,
            "coin",
            "Nur Barren verkaufen",
            "sellbars",
            "Erze bleiben im Lager",
            "Barren für Forschung und Barrenauftrag bleiben liegen");
        b(
            s,
            30,
            Material.FURNACE,
            "machine_furnace",
            "Schmelzen · Erzart wählen",
            "open:smelt",
            "Je Barren: 2 eingelagerte Erze + 1 Brennstoff",
            "Brennstoff: " + p.fuel + (p.furnace == 0 ? " · Schmelze fehlt!" : ""),
            "Forschung braucht " + Industry.barName(0) + " (" + p.bars[0] + " vorhanden)");
      }
      case "smelt" -> {
        for (int z = 0; z < Zone.COUNT; z++) {
          boolean open = z <= p.zone;
          long possible = Math.min(p.stock[z] / 2, p.fuel);
          b(
              s,
              9 + z,
              Material.IRON_INGOT,
              "ore_" + Zone.at(z).key,
              open ? "Bis 32 " + Industry.barName(z) : Zone.at(z).oreName + " · gesperrt",
              open ? "smelt:" + z + ":32" : null,
              "Lager: " + p.stock[z] + " " + Zone.at(z).oreName,
              "Vorhanden: " + p.bars[z] + " " + Industry.barName(z),
              open
                  ? possible > 0
                      ? "Möglich jetzt: " + possible + " Barren"
                      : p.stock[z] < 2 ? "Zu wenig Erz im Lager" : "Kein Brennstoff"
                  : "Gebiet noch nicht freigeschaltet");
          if (open)
            b(
                s,
                27 + z,
                Material.BLAST_FURNACE,
                "machine_furnace",
                "Alles schmelzen: " + Zone.at(z).oreName,
                "smelt:" + z + ":all",
                "Bis Erz oder Brennstoff aufgebraucht sind",
                "Möglich jetzt: " + possible + " Barren");
        }
        b(
            s,
            46,
            Material.COAL,
            "fuel",
            "Brennstoff: " + p.fuel + (p.furnace == 0 ? " · Schmelze fehlt!" : ""),
            "open:factory",
            "Je Barren: 2 eingelagerte Erze + 1 Brennstoff",
            "Schmelze und Brennstoff im Betrieb besorgen");
        b(
            s,
            48,
            Material.BLAST_FURNACE,
            "machine_furnace",
            "Schmelze & Brennstoff besorgen",
            "open:factory");
        long bars = 0, worth = 0;
        for (int z = 0; z < Zone.COUNT; z++) {
          long n = Industry.sellableBars(p, z);
          bars += n;
          worth += n * Zone.at(z).barPrice;
        }
        b(
            s,
            50,
            Material.GOLD_INGOT,
            "coin",
            "Nur Barren verkaufen · +" + worth + " $",
            bars > 0 ? "sellbars" : null,
            bars + " Barren · Erze bleiben im Lager",
            "Barren für Forschung und Barrenauftrag bleiben liegen");
      }
      case "trade" -> {
        b(s, 39, Material.PAPER, "handbook", "Große Auftragstafel", "open:contracts");
        b(s, 41, Material.BOOK, "relic", "Forschung und Funde", "open:research");
        int count = 80 + (p.orders % 4) * 40;
        b(
            s,
            20,
            Material.PAPER,
            "handbook",
            "Lieferauftrag #" + (p.orders + 1),
            "order",
            count + " " + Zone.at(p.zone).oreName,
            "Vergütung: " + count * Zone.at(p.zone).orePrice * 3 / 2 + " $",
            "Jeder fünfte Auftrag: +1 Relikt");
        b(s, 22, Material.BOOK, "relic", "Meilenstein", "quest", Economy.questText(p.quest));
        b(s, 24, Material.GOLD_INGOT, "coin", "Alle Waren verkaufen", "sell");
        b(
            s,
            31,
            Material.AMETHYST_SHARD,
            "relic",
            "Sammlung: " + Zone.at(p.zone).oreName,
            "collection",
            "Selbst gesammelt: " + p.collected[p.zone] + " / 500",
            "Einmalige Belohnung: 3 Relikte");
      }
      case "travel" -> {
        for (int z = 0; z < Zone.COUNT; z++)
          b(
              s,
              9 + z,
              z <= p.zone ? Material.MINECART : Material.BARRIER,
              "ore_" + Zone.at(z).key,
              Zone.at(z).title,
              z <= p.zone ? "mine:" + z : null,
              z <= p.zone ? "Erschlossen" : "Noch gesperrt · " + Zone.at(z).unlockCost + " $",
              "Werkzeugstufe " + Zone.at(z).toolRequired
                  + (z >= Zone.FIRST_DEEP ? " · Tiefer Schacht" : ""),
              "Höhlenform: " + de.deepforge.world.MineBlueprint.LAYOUTS[z % 4],
              Zone.hazardArmor(z) == 0
                  ? z == 4 || z == 7 ? "Hitze: der Bohrer überhitzt schneller" : "Keine Umweltgefahr"
                  : "Gefahr: 1 Leben alle 5 s ohne Schutztraining "
                      + Zone.hazardArmor(z)
                      + (p.armor >= Zone.hazardArmor(z) ? " · du bist geschützt" : " · du hast " + p.armor));
        b(
            s,
            31,
            Material.TRIPWIRE_HOOK,
            "scanner",
            "Nächstes Gebiet erschließen",
            "unlock",
            p.zone >= Zone.LAST ? "Alle Gebiete offen" : Zone.at(p.zone + 1).unlockCost + " $",
            "Aktuellen Boss besiegen und Werkzeug verbessern");
        b(s, 40, Material.OAK_DOOR, "handbook", "Zurück zum Betrieb", "home");
      }
      default -> {
        if (page.startsWith("worker/")) {
          int i = Integer.parseInt(page.substring(7));
          if (i < 0 || i >= p.workers.size()) return create(player, p, "crew");
          Profile.Worker w = p.workers.get(i);
          b(
              s,
              13,
              Material.PLAYER_HEAD,
              "worker",
              w.name + " · " + (player == null ? "Bereit" : plugin.workerStatus(player, i)),
              null,
              "Auftrag: " + workplace(p, w),
              "Leistung: "
                  + String.format(Locale.GERMAN, "%.2f", Industry.rate(p, w))
                  + " Einheiten/Minute vor Produktionsgrenzen",
              "Lohn: " + Industry.wage(w) + " $ je Lieferung + "
                  + (w.job == Profile.Job.TRADER ? "10" : "20")
                  + " % vom Warenwert",
              "Brennstoff und Budget: im Betriebsmenü");
          if (w.job == Profile.Job.LUMBERJACK)
            b(s, 30, Material.OAK_SAPLING, null, "Wald & Holzlager öffnen", "open:forestry");
          else
            b(s, 30, Material.MINECART, "scanner", "Zugewiesene Mine besuchen", "mine:" + w.zone);
          b(
              s,
              32,
              w.paused ? Material.LIME_DYE : Material.RED_DYE,
              "clock",
              w.paused ? "Schicht fortsetzen" : "Schicht pausieren",
              "pause:" + i,
              "Pausierte Arbeiter verbrauchen keine Löhne/Brennstoff");
          b(s, 34, Material.COAL, "fuel", "Versorgung öffnen", "open:factory");
          b(
              s,
              20,
              Material.EXPERIENCE_BOTTLE,
              "worker",
              w.name + " ausbilden",
              "train:" + i,
              "Stufe " + w.level + " / 5",
              "Kosten: " + 1000L * w.level * w.level + " $",
              "Erfahrung: " + w.workMinutes + " / " + w.level * 30 + " Arbeitsminuten");
          b(
              s,
              22,
              Material.MINECART,
              "scanner",
              w.job == Profile.Job.LUMBERJACK ? "Holzart wechseln" : "Gebiet wechseln",
              "open:assignment/" + i,
              "Aktuell: " + workplace(p, w),
              w.job == Profile.Job.LUMBERJACK
                  ? "Klick: Eiche, Birke oder Fichte wählen"
                  : "Klick: gewünschtes Gebiet direkt auswählen");
          b(
              s,
              24,
              Material.BOOK,
              "handbook",
              "Spezialisierung wechseln",
              "open:specialty/" + i,
              "Aktuell: "
                  + switch (w.specialization) {
                    case 1 -> "Ertrag";
                    case 2 -> "Sparsam";
                    default -> "Allrounder";
                  },
              "Ab Stufe 2 frei wechselbar");
          b(s, 39, Material.ARROW, "back", "Zur Mannschaft", "open:crew");
          b(
              s,
              41,
              Material.BARRIER,
              "close",
              w.name + " entlassen",
              "open:fire/" + i,
              "Gibt den Arbeiterplatz frei",
              "Mit Bestätigung – Stufe und Erfahrung gehen verloren");
        }
        if (page.startsWith("fire/")) {
          int i = Integer.parseInt(page.substring(5));
          if (i < 0 || i >= p.workers.size()) return create(player, p, "crew");
          Profile.Worker w = p.workers.get(i);
          b(
              s,
              13,
              Material.PLAYER_HEAD,
              "worker",
              w.name + " wirklich entlassen?",
              null,
              Menus.jobName(w.job) + " · Stufe " + w.level + " · " + w.workMinutes + " Arbeitsminuten",
              "Stufe, Spezialisierung und Erfahrung gehen verloren.",
              "Kein Geld zurück. Der Platz wird sofort frei.");
          b(s, 29, Material.RED_CONCRETE, "close", "Ja, " + w.name + " entlassen", "fire:" + w.id);
          b(s, 33, Material.LIME_CONCRETE, "back", "Nein, behalten", "open:worker/" + i);
        }
      }
    }
    return s;
  }

  private static String parent(String page) {
    if (page.startsWith("assignment/") || page.startsWith("specialty/"))
      return "worker/" + page.substring(page.indexOf('/') + 1);
    if (page.startsWith("worker/")) return "crew";
    if (page.startsWith("fire/")) return "worker/" + page.substring(5);
    if (page.startsWith("item/") || page.startsWith("loot/"))
      return page.startsWith("item/") ? "loot/0" : "combat";
    if (page.startsWith("confirm/")) return "item/" + page.split("/")[2];
    if (page.startsWith("pass/")) return "main";
    if (page.startsWith("preset/")) return "presets";
    if (page.startsWith("runes/")) return "runes";
    if (page.startsWith("pet/")) return "pets";
    if (page.startsWith("runesel/")) return "item/" + page.split("/")[1];
    if (page.startsWith("museum/")) return "museum";
    if (page.startsWith("presetpick/")) return "preset/" + page.split("/")[1];
    return switch (page) {
      case "woodwork", "woodupgrades" -> "forestry";
      case "crew", "factory" -> "business";
      case "storage", "gear", "travel", "expeditions" -> "mining";
      case "smelt" -> "storage";
      case "character", "codex", "boss" -> "combat";
      case "milestones", "presets" -> "character";
      case "runes" -> "combat";
      case "talents" -> "character";
      case "pets", "guild", "guildnone" -> "main";
      case "guildcolor" -> "guild";
      case "eggs" -> "pets";
      case "research", "contracts", "trade", "daily", "top" -> "goals";
      case "reward" -> "combat";
      case "drone" -> "main";
      case "glanz" -> "museum";
      default -> "main";
    };
  }

  private static String[] help(String page) {
    return switch (page) {
      case "storage" ->
          new String[] {
            "1. Rucksack einlagern.",
            "2. Schmelze und Brennstoff im Betrieb besorgen.",
            "3. Unter Schmelzen die Erzart wählen und Barren herstellen.",
            "4. Auftragsmaterial abgeben oder Waren verkaufen."
          };
      case "crew" ->
          new String[] {
            "Arbeiter anklicken, um ihren Auftrag zu ändern.",
            "Arbeit benötigt Lagerplatz, Brennstoff und Lohnbudget.",
            "Versorgung unter Arbeiter & Betrieb → Betrieb."
          };
      case "gear" ->
          new String[] {
            "Hier kaufst du dauerhafte Grund-Upgrades.",
            "Gefundene Waffen verwaltest du unter Kampf → Beute.",
            "Ein Modul ist aktiv; Wechsel ist kostenlos."
          };
      case "forestry", "woodwork", "woodupgrades" ->
          new String[] {
            "Obere Reihe: Wald / Verarbeitung / Upgrades.",
            "Wald: vom Dorf nach Osten laufen.",
            "Holzlager ist getrennt vom Erzlager.",
            "Glück 1,1× bedeutet 10 % Chance auf Doppelernte."
          };
      default ->
          new String[] {
            "Goldene Einträge: anklickbare Aktionen.",
            "Graue Einträge: Informationen oder gesperrte Aktionen.",
            "Maus über ein Symbol: Wirkung und Kosten lesen.",
            "Unten: Zurück / Hauptmenü / Schließen / Hilfe."
          };
    };
  }

  /** Centred places for the worker heads in row 3 (at most six workers). */
  static int[] workerSlots(int count) {
    int[][] cols = {{}, {4}, {3, 5}, {2, 4, 6}, {1, 3, 5, 7}, {0, 2, 4, 6, 8}, {1, 2, 3, 5, 6, 7}};
    int[] out = new int[count];
    for (int i = 0; i < count; i++) out[i] = count < cols.length ? 18 + cols[count][i] : 18 + i;
    return out;
  }

  /** Recolours a button's name (guild colour buttons). */
  private static void tint(Screen s, int slot, String name, NamedTextColor color) {
    ItemStack item = s.inv.getItem(slot);
    var meta = item.getItemMeta();
    meta.itemName(Component.text(name, color));
    item.setItemMeta(meta);
  }

  static Material guildDye(String key) {
    return switch (key) {
      case "dark_aqua" -> Material.CYAN_DYE;
      case "blue" -> Material.BLUE_DYE;
      case "dark_blue" -> Material.LAPIS_LAZULI;
      case "green" -> Material.LIME_DYE;
      case "dark_green" -> Material.GREEN_DYE;
      case "yellow" -> Material.YELLOW_DYE;
      case "gold" -> Material.ORANGE_DYE;
      case "red" -> Material.RED_DYE;
      case "dark_red" -> Material.REDSTONE;
      case "light_purple" -> Material.PINK_DYE;
      case "dark_purple" -> Material.PURPLE_DYE;
      case "white" -> Material.WHITE_DYE;
      case "gray" -> Material.LIGHT_GRAY_DYE;
      default -> Material.LIGHT_BLUE_DYE;
    };
  }

  static Material guildBanner(String key) {
    return switch (key) {
      case "dark_aqua" -> Material.CYAN_BANNER;
      case "blue", "dark_blue" -> Material.BLUE_BANNER;
      case "green" -> Material.LIME_BANNER;
      case "dark_green" -> Material.GREEN_BANNER;
      case "yellow" -> Material.YELLOW_BANNER;
      case "gold" -> Material.ORANGE_BANNER;
      case "red", "dark_red" -> Material.RED_BANNER;
      case "light_purple" -> Material.PINK_BANNER;
      case "dark_purple" -> Material.PURPLE_BANNER;
      case "white" -> Material.WHITE_BANNER;
      case "gray" -> Material.LIGHT_GRAY_BANNER;
      default -> Material.LIGHT_BLUE_BANNER;
    };
  }

  /** A tab button; the page that is open glows and cannot be clicked again. */
  private void tab(Screen s, int slot, Material icon, String name, String target, String page) {
    boolean open = page.equals(target);
    b(s, slot, icon, null, open ? "» " + name + " «" : name, open ? null : "open:" + target,
        open ? "Du bist hier" : "Klick: Seite wechseln");
    ItemStack item = s.inv.getItem(slot);
    var meta = item.getItemMeta();
    meta.setEnchantmentGlintOverride(open);
    if (open) meta.itemName(Component.text("» " + name + " «", NamedTextColor.WHITE));
    item.setItemMeta(meta);
  }

  private void forestUpgrade(
      Screen s,
      Profile p,
      int slot,
      String key,
      String name,
      int level,
      int max,
      Material icon,
      String... effects) {
    List<String> lore = new ArrayList<>();
    long price = Forestry.cost(p, key);
    boolean resin = key.equals("axe") && level >= 5;
    if (level < max) {
      lore.addAll(Arrays.asList(effects));
      lore.add("Kosten: " + price + " $" + (resin ? " + 1 Harz" : ""));
      lore.add(
          p.money < price
              ? "Es fehlen " + (price - p.money) + " $"
              : resin && p.resin < 1 ? "Es fehlt 1 Harz" : "Bereit zum Verbessern");
    } else lore.add("Maximale Stufe erreicht");
    b(
        s,
        slot,
        icon,
        null,
        name + " · " + level + " / " + max,
        level < max && p.money >= price && (!resin || p.resin > 0) ? "forest:" + key : null,
        lore.toArray(String[]::new));
  }

  /** Real seconds per ore block now and after the next level, in the best unlocked mine. */
  private static String drillEffect(Profile p) {
    double now = ToolStats.of(p, p.zone, false).speed();
    double next = now * ToolStats.drillPower(p.tool + 1) / ToolStats.drillPower(p.tool);
    return String.format(
        Locale.GERMAN,
        "%s: %.2f s → %.2f s pro Erz (+12 %%, weniger Hitze)",
        Zone.at(p.zone).title,
        ToolStats.seconds(now),
        ToolStats.seconds(next));
  }

  private static String swordEffect(Profile p) {
    double now = RapidCombat.damage(Gear.stats(p));
    p.sword++;
    double next = RapidCombat.damage(Gear.stats(p));
    p.sword--;
    return String.format(
        Locale.GERMAN, "Trefferschaden %.1f → %.1f (+4 %% auf allen Nahkampfschaden)", now, next);
  }

  private void upgrade(
      Screen s,
      Profile p,
      int slot,
      String key,
      String title,
      int level,
      Material base,
      String model) {
    int max = Economy.max(key);
    long cost = Economy.upgradeCost(p, key);
    boolean relic = (key.equals("tool") || key.equals("sword")) && level >= 4;
    String effect =
        switch (key) {
          case "bag" -> p.bagCapacity() + " → " + (p.bagCapacity() + 150) + " Rucksackplätze";
          case "potion" ->
              "Heilvorrat " + Healing.capacity(p) + " → " + (Healing.capacity(p) + 1) + " Lebenssplitter";
          case "warehouse" ->
              p.stockCapacity() + " → " + (p.stockCapacity() + 960) + " Lagerplätze";
          case "housing" -> p.workerSlots() + " → " + (p.workerSlots() + 1) + " Arbeiterplätze";
          case "furnace" -> "Schmelze freischalten / automatische Verarbeitung verbessern";
          case "tool" -> drillEffect(p);
          case "sword" -> swordEffect(p);
          default -> "Mehr Leben und Schutz im Kampf";
        };
    b(
        s,
        slot,
        base,
        model,
        title + " · Stufe " + level + " / " + max,
        level < max && p.money >= cost && (!relic || p.relics > 0) ? "buy:" + key : null,
        level >= max ? "Maximale Stufe erreicht" : effect,
        level >= max
            ? "Vollständig ausgebaut"
            : "Kosten: " + cost + " $" + (relic ? " + 1 Relikt" : ""),
        level >= max
            ? ""
            : p.money < cost
                ? "Es fehlen " + (cost - p.money) + " $"
                : relic && p.relics < 1 ? "Es fehlt 1 Relikt" : "Bereit zum Verbessern");
  }

  /** Builds real Bukkit inventories without opening a player's screen or mutating a profile. */
  public String verify() {
    Profile p = new Profile();
    p.id = UUID.randomUUID().toString();
    p.name = "Menu diagnostic";
    p.workers.add(new Profile.Worker("Borin", Profile.Job.MINER, 0));
    Set<String> visited = new HashSet<>();
    ArrayDeque<String> pending = new ArrayDeque<>();
    pending.add("main");
    while (!pending.isEmpty()) {
      String page = pending.remove();
      if (!visited.add(page)) continue;
      Screen s = create(null, p, page);
      if (!"open:main".equals(s.actions.get(47))
          || !"close".equals(s.actions.get(49))
          || s.inv.getItem(53) == null)
        throw new IllegalStateException("Navigation missing: " + page);
      for (var e : s.actions.entrySet()) {
        if (s.inv.getItem(e.getKey()) == null)
          throw new IllegalStateException("Empty action: " + page);
        if (e.getValue().startsWith("open:")) pending.add(e.getValue().substring(5));
      }
    }
    if (!visited.containsAll(
        List.of(
            "woodwork",
            "woodupgrades",
            "crew",
            "worker/0",
            "storage",
            "gear",
            "contracts",
            "research",
            "loot/0",
            "character",
            "codex",
            "travel",
            "trade",
            "expeditions"))) throw new IllegalStateException("Unreachable page: " + visited);
    if (create(null, p, "woodwork").actions.containsKey(20))
      throw new IllegalStateException("Empty saw enabled");
    p.money = 1000000;
    p.fuel = 20;
    p.wood[0] = 20;
    if (!"forest:saw:0".equals(create(null, p, "woodwork").actions.get(20)))
      throw new IllegalStateException("Loaded saw disabled");
    if (!"forest:axe".equals(create(null, p, "woodupgrades").actions.get(20)))
      throw new IllegalStateException("Affordable upgrade disabled");
    p.axe = 10;
    if (create(null, p, "woodupgrades").actions.containsKey(20))
      throw new IllegalStateException("Max upgrade enabled");
    return "OK: "
        + visited.size()
        + " reachable menu pages, fixed navigation, empty/ready saw, affordable/max upgrades; no"
        + " player changes";
  }

  private static String fmt(double n) {
    return String.format(java.util.Locale.GERMAN, "%.1f", n);
  }

  private String[] gearLore(Profile p, Gear.Item item) {
    Gear.Item old = Gear.equipped(p, item.slot);
    String compare = GearCompare.diff(item, old);
    return new String[] {
      item.rarity.title + " · " + Gear.slotName(item.slot) + " · Qualität " + item.quality + " %",
      item.dungeonRank > 0
          ? "Dungeon-Beutestufe " + item.dungeonRank + " · Stärke bereits in Werten enthalten"
          : "Ausrüstung aus der Mine",
      "Schaden "
          + fmt(item.damage * (1 + item.level * .08) * Gear.starForged(item)
              + Runes.itemBonus(item, Runes.Kind.KRAFT))
          + runeNote(item, Runes.Kind.KRAFT, 1),
      "Leben +"
          + fmt(item.health * (1 + item.level * .08) * Gear.starForged(item)
              + Runes.itemBonus(item, Runes.Kind.LEBEN))
          + runeNote(item, Runes.Kind.LEBEN, 1)
          + " | Rüstung +"
          + fmt(item.defense * (1 + item.level * .08) * Gear.starForged(item)
              + Runes.itemBonus(item, Runes.Kind.STEIN))
          + runeNote(item, Runes.Kind.STEIN, 1),
      "Krit +"
          + fmt((item.crit + Runes.itemBonus(item, Runes.Kind.GLUECK)) * 100)
          + runeNote(item, Runes.Kind.GLUECK, 100)
          + " % | Krit-Schaden "
          + (item.slot == Gear.Slot.WEAPON
              ? fmt((Gear.baseCritDamage(item) + item.critDamage) * 100) + " %"
              : "+" + fmt(item.critDamage * 100) + " %")
          + " | Tempo +"
          + fmt(item.haste + Runes.itemBonus(item, Runes.Kind.WIND))
          + runeNote(item, Runes.Kind.WIND, 1)
          + " | Haltung +"
          + fmt(item.stagger),
      "Abbau +"
          + fmt((item.mining + Runes.itemBonus(item, Runes.Kind.TIEFE)) * 100)
          + " %"
          + runeNote(item, Runes.Kind.TIEFE, 100)
          + " | Extra-Erz +"
          + fmt(item.yield * 100)
          + " %",
      "Brennstoff sparen +" + fmt(item.efficiency * 100) + " %",
      Gear.effect(item.signature),
      AdventureGear.lore(item),
      socketLine(item),
      item.level >= StarStones.LEVEL ? "✦ STERNENGESCHMIEDET · doppelte Grundwerte · Fähigkeit ×1,5 · "
              + (item.slot == Gear.Slot.WEAPON ? "Sternenschlag" : "Sternenschild") : "",
      item.slot == Gear.Slot.WEAPON ? WeaponAbilities.lore(item) : "",
      compare == null ? "" : "Gegenüber ausgerüstet:",
      compare == null ? "" : compare,
      p.equipped.containsValue(item.id)
          ? "AUSGERÜSTET"
          : item.favorite ? "FAVORIT" : "Klicken zum Verwalten"
    };
  }

  static final Material[] EGG_ICONS = {
    Material.EGG, Material.TURTLE_EGG, Material.SNIFFER_EGG, Material.DRAGON_EGG, Material.DRAGON_EGG
  };
  static final Material[] PET_ICONS = {
    Material.ARMADILLO_SPAWN_EGG, Material.FOX_SPAWN_EGG, Material.BAT_SPAWN_EGG,
    Material.MAGMA_CUBE_SPAWN_EGG, Material.POLAR_BEAR_SPAWN_EGG, Material.IRON_GOLEM_SPAWN_EGG,
    Material.SNIFFER_SPAWN_EGG
  };
  static final String[] RUNE_MODELS = {
    "rune_kraft", "rune_stein", "rune_leben", "rune_wind", "rune_glueck", "rune_tiefe"
  };
  static final String[] BUILDING_MODELS = {
    "building_kaserne", "building_lazarett", "building_werkstatt", "building_schatzkammer",
    "building_gildenhalle"
  };

  static String eggModel(Gear.Rarity rarity) {
    return "egg_" + rarity.name().toLowerCase(Locale.ROOT);
  }

  static final Material[] RUNE_ICONS = {
    Material.REDSTONE, Material.FLINT, Material.GLISTERING_MELON_SLICE,
    Material.FEATHER, Material.EMERALD, Material.LAPIS_LAZULI
  };

  private static String socketLine(Gear.Item item) {
    int[] sockets = Runes.sockets(item);
    if (sockets.length == 0) return "";
    StringJoiner j = new StringJoiner(" ", "Sockel: ", "");
    for (int code : sockets)
      j.add(code < 0 ? "[leer]" : "[" + Runes.name(code) + " " + Runes.effect(code, item) + "]");
    return j.toString();
  }

  /** " (+x Rune)" when runes add to this stat of the item – already counted in the number. */
  private static String runeNote(Gear.Item item, Runes.Kind kind, double scale) {
    double v = Runes.itemBonus(item, kind) * scale;
    return v <= 0 ? "" : " (inkl. +" + fmt(v) + " Rune)";
  }

  private static String woodLine(Profile p, int i) {
    return Forestry.WOODS[i] + ": " + p.wood[i] + " Stämme · " + p.planks[i] + " Bretter";
  }

  /** Where a worker works: the mine zone, or the wood type for lumberjacks. */
  static String workplace(Profile p, Profile.Worker w) {
    return w.job == Profile.Job.LUMBERJACK
        ? "Wald · " + Forestry.WOODS[Industry.woodType(p, w)]
        : Zone.at(w.zone).title;
  }

  public static String jobName(Profile.Job job) {
    return switch (job) {
      case MINER -> "Bergarbeiter";
      case SMELTER -> "Schmelzer";
      case TRADER -> "Händler";
      case LUMBERJACK -> "Holzfäller";
    };
  }

  private String title(String page) {
    if (page.startsWith("assignment/")) return "Arbeitsgebiet wählen";
    if (page.startsWith("specialty/")) return "Arbeitsweise wählen";
    if (page.startsWith("loot/")) return "Beutebeutel";
    if (page.startsWith("item/")) return "Gegenstand";
    if (page.startsWith("confirm/")) return "Bestätigung";
    if (page.startsWith("pass/")) return "Tiefenpass";
    if (page.startsWith("preset/")) return "Set bearbeiten";
    if (page.startsWith("runes/")) return "Runenschmiede";
    if (page.startsWith("pet/")) return "Begleiter";
    if (page.startsWith("museum/")) return "Sammlungsbuch";
    if (page.startsWith("runesel/")) return "Rune einsetzen";
    if (page.startsWith("presetpick/")) return "Teil wählen";
    if (page.startsWith("fire/")) return "Arbeiter entlassen";
    return switch (page) {
      case "main" -> "Hauptmenü";
      case "mining" -> "Bergbau";
      case "combat" -> "Kampf & Ausrüstung";
      case "business" -> "Arbeiter & Betrieb";
      case "goals" -> "Aufträge & Abenteuer";
      case "woodwork" -> "Holz verarbeiten";
      case "woodupgrades" -> "Holz-Upgrades";
      case "character" -> "Charakter";
      case "milestones" -> "Meilensteine";
      case "presets" -> "Ausrüstungs-Sets";
      case "runes" -> "Runenbeutel";
      case "talents" -> "Meisterschaft";
      case "prestige" -> "Prestige";
      case "alchemy" -> "Alchemie";
      case "museum" -> "Museum";
      case "glanz" -> "Glanzbuch";
      case "pets" -> "Begleiter & Brutstätte";
      case "guild", "guildnone" -> "Gilde";
      case "guildcolor" -> "Gildenfarbe";
      case "eggs" -> "Eier";
      case "daily" -> "Tagesaufträge";
      case "reward" -> "Dungeon-Beute";
      case "drone" -> "Funke";
      case "top" -> "Rangliste";
      case "codex" -> "Beutebuch";
      case "boss" -> "Bosskampf";
      case "gear" -> "Grund-Upgrades";
      case "forestry" -> "Holzfäller & Sägewerk";
      case "crew" -> "Mannschaft";
      case "factory" -> "Betrieb";
      case "storage" -> "Lager";
      case "smelt" -> "Schmelzen";
      case "travel" -> "Aufzug";
      case "trade" -> "Handel";
      case "research" -> "Forschung";
      case "contracts" -> "Auftragstafel";
      case "expeditions" -> "Erkundung";
      default -> "Arbeiter";
    };
  }

  /** Loot bag multi-select and bulk salvage/sell; bulk buttons need a second click within 5 s. */
  private void bulk(Player player, Screen screen, String action) {
    UUID id = player.getUniqueId();
    Profile p = plugin.profile(player);
    Set<String> picked = selected.computeIfAbsent(id, k -> new HashSet<>());
    if (action.startsWith("select:")) {
      String item = action.substring(7);
      Gear.Item found = Gear.find(p, item);
      if (found != null && Gear.isProtected(p, found) && !picked.contains(item))
        plugin.tell(player, "Geschützt (Favorit, angelegt oder in einem Set) – nicht auswählbar.");
      else if (!picked.remove(item) && found != null) picked.add(item);
      bulkArmed.remove(id);
    } else if (action.equals("bulk:clear")) {
      picked.clear();
      bulkArmed.remove(id);
    } else if (action.startsWith("bulk:page:")) {
      int page = Integer.parseInt(action.substring(10));
      List<Gear.Item> ordered = Gear.sorted(p);
      for (int n = 0; n < 27 && page * 27 + n < ordered.size(); n++) {
        Gear.Item item = ordered.get(page * 27 + n);
        if (!Gear.isProtected(p, item)) picked.add(item.id);
      }
      bulkArmed.remove(id);
    } else if (plugin.combat().fighting(player)) {
      plugin.tell(player, "Ausrüstung nach dem Kampf verwalten.");
    } else if (bulkArmed.getOrDefault(id, 0L) <= System.currentTimeMillis()) {
      bulkArmed.put(id, System.currentTimeMillis() + 5000);
      player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, .6f, 1.4f);
    } else {
      bulkArmed.remove(id);
      boolean salvage = action.equals("bulk:dust");
      Set<String> ids = new HashSet<>(picked);
      String result =
          plugin.change(
              player,
              data -> {
                long[] r = Gear.sellMany(data, ids, salvage);
                return r[0]
                    + " Gegenstände "
                    + (salvage ? "zerlegt: +" + r[3] + " Schmiedestaub" : "verkauft: +" + r[2] + " $")
                    + (r[1] > 0 ? " · " + r[1] + " geschützte übersprungen" : "")
                    + ".";
              });
      if (result != null) {
        picked.clear();
        plugin.items().refresh(player, plugin.profile(player));
        player.playSound(
            player.getLocation(),
            salvage ? Sound.BLOCK_GRINDSTONE_USE : Sound.ENTITY_EXPERIENCE_ORB_PICKUP,
            .7f,
            1.1f);
      }
    }
    open(player, screen.page.startsWith("loot/") ? screen.page : "loot/0");
  }

  @EventHandler
  public void click(InventoryClickEvent e) {
    if (!(e.getView().getTopInventory().getHolder() instanceof Screen s)) return;
    e.setCancelled(true);
    if (!(e.getWhoClicked() instanceof Player player)
        || !player.getUniqueId().equals(s.owner)
        || !plugin.playing(player)) return;
    String a = s.actions.get(e.getRawSlot());
    if (a == null || e.getClick() == ClickType.DOUBLE_CLICK) return;
    if (a.equals("prestige:do") && !e.isShiftClick()) {
      plugin.tell(player, "Prestige: SHIFT + Klick – Gebiet, Geld und Upgrades werden zurückgesetzt.");
      return;
    }
    if (a.equals("guild:leave") && !e.isShiftClick()) {
      plugin.tell(player, "Gilde verlassen: SHIFT + Klick.");
      return;
    }
    if (a.startsWith("starstone:") && !e.isShiftClick()) {
      plugin.tell(player, "Sternenstein: SHIFT + Klick – 90 % Risiko, dass der Gegenstand zerbricht.");
      return;
    }
    if (a.startsWith("petrelease:")) {
      if (!e.isShiftClick()) {
        plugin.tell(player, "Zum Freilassen SHIFT + Klick – das ist endgültig.");
        return;
      }
      a = "pet:release:" + a.substring(11);
    }
    if (a.startsWith("open:item/") && e.isShiftClick()) a = "select:" + a.substring(10);
    else if (a.equals("heal") && e.isShiftClick()) a = "healbuy:" + de.deepforge.game.Healing.CAPACITY;
    else if (a.equals("heal") && e.isRightClick()) a = "healbuy:1";
    else if (a.startsWith("brew:") && e.isRightClick()) a = "drink:" + a.substring(5);
    else if (a.startsWith("find:") && e.isRightClick()) a = "findsell:" + a.substring(5);
    String action = a;
    // A double click also sends a normal click first; never buy or reroll twice by accident.
    long now = System.currentTimeMillis();
    Long last = lastClick.get(player.getUniqueId());
    if (last != null && now - last < 250) return;
    lastClick.put(player.getUniqueId(), now);
    // Inventory changes and teleports are deferred until after the inventory event.
    Bukkit.getScheduler()
        .runTask(
            plugin,
            () -> {
              if (player.isOnline() && plugin.playing(player)) act(player, s, action);
            });
  }

  public void forget(UUID id) {
    selected.remove(id);
    bulkArmed.remove(id);
  }

  @EventHandler
  public void closed(InventoryCloseEvent e) {
    if (e.getInventory().getHolder() instanceof Screen) lastClick.remove(e.getPlayer().getUniqueId());
  }

  @EventHandler
  public void drag(InventoryDragEvent e) {
    if (e.getView().getTopInventory().getHolder() instanceof Screen) e.setCancelled(true);
  }

  private void act(Player player, Screen screen, String action) {
    if (action.startsWith("adventure:")) {
      plugin.adventure().open(player, action.substring(10));
      return;
    }
    if (action.equals("heal")) {
      player.closeInventory();
      plugin.healing().use(player);
      return;
    }
    if ((action.startsWith("pet:brood:") || action.startsWith("pet:hatch:"))
        && !plugin.pets().atCamp(player)) {
      plugin.tell(player, "Ausbrüten geht nur am Camp (Brutstätte) – nicht in Mine oder Dungeon.");
      return;
    }
    if (action.startsWith("guild:")) {
      plugin.guilds().menuAction(player, action);
      open(
          player,
          Guilds.of(plugin.profile(player)) == null
              ? "guildnone"
              : action.startsWith("guild:color:") ? "guildcolor" : "guild");
      return;
    }
    if (action.startsWith("select:") || action.startsWith("bulk:")) {
      bulk(player, screen, action);
      return;
    }
    if (action.equals("lootsort")) {
      Profile p = plugin.profile(player);
      p.lootSort = Math.floorMod(p.lootSort + 1, Gear.SORTS.length);
      plugin.commit(player, p);
      open(player, "loot/0");
      return;
    }
    if (action.equals("prestige:do")) {
      player.closeInventory();
      plugin.prestige(player);
      return;
    }
    if (action.equals("deep")) {
      player.closeInventory();
      plugin.dungeons().command(player, new String[] {"dungeon", "tiefengang"});
      return;
    }
    if (action.startsWith("healbuy:")) {
      plugin.healing().buy(player, Integer.parseInt(action.substring(8)));
      open(player, screen.page);
      return;
    }
    if (action.equals("dungeon")) {
      plugin.dungeons().command(player, new String[] {"dungeon"});
      return;
    }
    if (action.equals("wiki") || action.startsWith("wiki:")) {
      plugin.wiki().show(player, action.equals("wiki") ? "home" : action.substring(5));
      return;
    }
    if (action.equals("back")) {
      goBack(player, screen);
      return;
    }
    if (action.startsWith("open:")) {
      navigate(player, screen, action.substring(5));
      return;
    }
    if (action.equals("close")) {
      player.closeInventory();
      return;
    }
    if (action.equals("home")) {
      player.closeInventory();
      plugin.goHome(player);
      return;
    }
    if (action.startsWith("mine:")) {
      player.closeInventory();
      plugin.travel(player, Integer.parseInt(action.substring(5)));
      return;
    }
    if (action.startsWith("fight:")) {
      plugin.combat().start(player, Integer.parseInt(action.substring(6)));
      return;
    }
    if (plugin.combat().fighting(player) && !action.startsWith("open:")) {
      plugin.tell(player, "Ausrüstung und Betrieb nach dem Kampf verwalten.");
      return;
    }
    if (action.equals("report")) {
      plugin.report(player);
      return;
    }
    if (action.startsWith("hire:") && !plugin.workersAvailable()) {
      plugin.tell(
          player,
          "Für sichtbare Arbeiter fehlt eine kompatible Citizens-Version. Details in README.");
      return;
    }
    Gear.Item rerolled =
        action.startsWith("reroll:")
            ? Gear.find(plugin.profile(player), action.substring(7))
            : null;
    double critBefore = rerolled == null ? 0 : rerolled.crit;
    long dustBefore = plugin.profile(player).dust;
    String result =
        plugin.change(
        player,
        p -> {
          if (action.startsWith("forest:")) return Forestry.act(p, action.substring(7));
          if (action.startsWith("milestone:"))
            return Milestones.claim(p, action.substring(10));
          if (action.equals("chest:buy")) return LootChests.buy(p);
          if (action.equals("drone:build")) return DroneRules.build(p);
          if (action.equals("drone:up")) return DroneRules.upgrade(p);
          if (action.equals("drone:toggle")) return DroneRules.toggle(p);
          if (action.startsWith("drone:module:"))
            return DroneRules.module(p, Integer.parseInt(action.substring(13)));
          if (action.startsWith("drone:skin:"))
            return DroneRules.skin(p, Integer.parseInt(action.substring(11)));
          if (action.startsWith("daily:")) {
            int before = Dailies.claimedCount(p);
            String message = Dailies.claim(p, Integer.parseInt(action.substring(6)), plugin.today());
            if (Dailies.claimedCount(p) > before) plugin.passXp(player, DeepPass.XP_DAILY);
            return message;
          }
          if (action.equals("pass:all"))
            return DeepPass.claimAll(p, java.util.concurrent.ThreadLocalRandom.current());
          if (action.startsWith("pass:"))
            return DeepPass.claim(
                p, Integer.parseInt(action.substring(5)), java.util.concurrent.ThreadLocalRandom.current());
          if (action.startsWith("research:"))
            return Industry.research(p, Integer.parseInt(action.substring(9)));
          if (action.startsWith("contract:")) {
            String[] a = action.split(":");
            int[] before = p.contracts.clone();
            String message = Industry.fulfill(p, Integer.parseInt(a[1]), Integer.parseInt(a[2]));
            if (!Arrays.equals(before, p.contracts)) plugin.passXp(player, DeepPass.XP_CONTRACT);
            return message;
          }
          if (action.startsWith("collect:"))
            return Industry.collection(p, Integer.parseInt(action.substring(8)));
          if (action.startsWith("fire:")) return Economy.dismiss(p, action.substring(5));
          if (action.startsWith("pause:")) {
            int i = Integer.parseInt(action.substring(6));
            if (i >= p.workers.size()) return "Arbeiter fehlt.";
            p.workers.get(i).paused = !p.workers.get(i).paused;
            return p.workers.get(i).paused ? "Schicht pausiert." : "Schicht fortgesetzt.";
          }
          if (action.equals("budget100")) {
            if (p.money < 100) return "Benötigt 100 $.";
            p.money -= 100;
            p.budget += 100;
            return "100 $ im Betriebsbudget.";
          }
          if (action.equals("fuel20")) {
            if (p.money < 20) return "Benötigt 20 $.";
            p.money -= 20;
            p.fuel += 20;
            return "20 Brennstoff gekauft.";
          }
          if (action.startsWith("pet:")) {
            String[] part = action.split(":");
            long now = System.currentTimeMillis();
            return switch (part[1]) {
              case "brood" -> Companions.brood(p, part[2], now);
              case "hatch" -> Companions.hatch(p, Integer.parseInt(part[2]), now);
              case "active" -> Companions.activate(p, part[2]);
              case "feed" -> Companions.feed(p, part[2]);
              default -> Companions.release(p, part[2]);
            };
          }
          if (action.startsWith("starstone:"))
            return StarStones.use(p, action.substring(10), java.util.concurrent.ThreadLocalRandom.current());
          if (action.startsWith("polish:")) return Shinies.polish(p, action.substring(7));
          if (action.startsWith("find:"))
            return Archaeology.donate(p, Archaeology.byId(action.substring(5)));
          if (action.startsWith("findsell:"))
            return Archaeology.sell(p, Archaeology.byId(action.substring(9)));
          if (action.startsWith("brew:"))
            return Alchemy.brew(p, Alchemy.Potion.valueOf(action.substring(5)));
          if (action.startsWith("drink:"))
            return Alchemy.drink(p, Alchemy.Potion.valueOf(action.substring(6)), System.currentTimeMillis());
          if (action.startsWith("prestige:learn:"))
            return Prestige.learn(p, Prestige.Node.valueOf(action.substring(15)));
          if (action.equals("talent:reset")) return Talents.reset(p);
          if (action.startsWith("talent:"))
            return Talents.learn(p, Talents.Node.valueOf(action.substring(7)));
          if (action.startsWith("rune:")) {
            String[] part = action.split(":");
            return switch (part[1]) {
              case "combine" -> Runes.combine(p, Integer.parseInt(part[2]));
              case "drill" -> Runes.drill(p, part[2]);
              case "insert" ->
                  Runes.insert(p, part[2], Integer.parseInt(part[3]), Integer.parseInt(part[4]));
              default -> Runes.remove(p, part[2], Integer.parseInt(part[3]));
            };
          }
          if (action.startsWith("preset:")) {
            String[] part = action.split(":");
            int i = Integer.parseInt(part[2]);
            return switch (part[1]) {
              case "save" -> GearPresets.save(p, i);
              case "clear" -> GearPresets.clear(p, i);
              case "set" -> GearPresets.setItem(p, i, part[3]);
              case "remove" -> GearPresets.removeItem(p, i, Gear.Slot.valueOf(part[3]));
              default -> GearPresets.apply(p, i);
            };
          }
          if (action.startsWith("equip:")) return Gear.equip(p, action.substring(6));
          if (action.startsWith("favorite:")) {
            Gear.Item i = Gear.find(p, action.substring(9));
            if (i == null) return "Nicht gefunden.";
            i.favorite = !i.favorite;
            return "Favoritenschutz aktualisiert.";
          }
          if (action.startsWith("enhance:")) return Gear.upgrade(p, action.substring(8));
          if (action.startsWith("rerollcd:"))
            return Gear.rerollCritDamage(
                p, action.substring(9), java.util.concurrent.ThreadLocalRandom.current());
          if (action.startsWith("reroll:"))
            return Gear.reroll(
                p, action.substring(7), java.util.concurrent.ThreadLocalRandom.current());
          if (action.startsWith("dust:")) return Gear.sell(p, action.substring(5), true);
          if (action.startsWith("sell:")) return Gear.sell(p, action.substring(5), false);
          if (action.startsWith("craft:"))
            return Gear.craft(p, Integer.parseInt(action.substring(6)));
          if (action.startsWith("hunt:"))
            return Gear.claimHunt(p, Integer.parseInt(action.substring(5)));
          if (action.startsWith("buy:")) return Economy.buy(p, action.substring(4));
          if (action.startsWith("module:")) {
            p.module = Integer.parseInt(action.substring(7));
            return "Modul gewechselt.";
          }
          if (action.startsWith("hire:"))
            return Economy.hire(p, Profile.Job.valueOf(action.substring(5)));
          if (action.equals("sell"))
            return "+" + Economy.sell(p, true, plugin.events().saleBoost() * Talents.sale(p) * Guilds.sale(p)) + " $ durch Verkauf"
                + (plugin.events().saleBoost() > 1 ? " (Goldrausch +50 %)." : ".");
          if (action.equals("sellbars")) {
            long[] kept = new long[1];
            long money = Economy.sellBars(p, kept, plugin.events().saleBoost() * Talents.sale(p) * Guilds.sale(p));
            return money == 0
                ? "Keine Barren zum Verkaufen" + (kept[0] > 0 ? " (" + kept[0] + " für Forschung/Aufträge reserviert)." : ".")
                : "+" + money + " $ durch Barrenverkauf. Erze behalten"
                    + (kept[0] > 0 ? ", " + kept[0] + " Barren für Forschung/Aufträge reserviert." : ".");
          }
          if (action.equals("sellore"))
            return "+" + Economy.sell(p, false, plugin.events().saleBoost() * Talents.sale(p) * Guilds.sale(p)) + " $ durch Erzverkauf. Barren behalten.";
          if (action.equals("deposit")) return Economy.deposit(p) + " Erze eingelagert.";
          if (action.equals("order")) return Economy.order(p);
          if (action.equals("quest")) return Economy.quest(p);
          if (action.equals("unlock")) return Economy.nextZone(p);
          if (action.equals("fuel")) {
            if (p.money < 120) return "Benötigt 120 $.";
            p.money -= 120;
            p.fuel += 120;
            return "120 Brennstoff gekauft.";
          }
          if (action.equals("budget")) {
            if (p.money < 1000) return "Benötigt 1.000 $.";
            p.money -= 1000;
            p.budget += 1000;
            return "1.000 $ Betriebsbudget bereitgestellt.";
          }
          if (action.startsWith("smelt:")) {
            String[] parts = action.split(":");
            return Industry.smelt(
                p,
                Integer.parseInt(parts[1]),
                parts[2].equals("all") ? Long.MAX_VALUE : Long.parseLong(parts[2]),
                Math::random);
          }
          if (action.equals("collection")) {
            if (p.collectionClaimed[p.zone]) return "Sammlungsbelohnung bereits abgeholt.";
            if (p.collected[p.zone] < 500) return "Sammle selbst 500 Erze dieses Gebiets.";
            p.collectionClaimed[p.zone] = true;
            p.relics += 3;
            return "Sammlung vollständig: +3 Relikte!";
          }
          if (action.startsWith("train:")
              || action.startsWith("assign:")
              || action.startsWith("spec:")) {
            String[] parts = action.split(":");
            int index = Integer.parseInt(parts[1]);
            if (index >= p.workers.size()) return "Arbeiter nicht gefunden.";
            Profile.Worker w = p.workers.get(index);
            if (parts[0].equals("assign")) {
              int chosen = Integer.parseInt(parts[2]);
              if (w.job == Profile.Job.LUMBERJACK) {
                if (chosen < 0 || chosen > p.forestTier || chosen >= Forestry.WOODS.length)
                  return "Diese Holzart ist noch nicht freigeschaltet.";
                w.zone = chosen;
                return w.name + " fällt jetzt " + Forestry.WOODS[chosen] + ".";
              }
              if (chosen < 0 || chosen > p.zone) return "Gebiet noch nicht freigeschaltet.";
              w.zone = chosen;
              return "Arbeiter neu zugewiesen.";
            }
            if (parts[0].equals("spec")) {
              if (w.level < 2) return "Spezialisierung ab Stufe 2.";
              int chosen = Integer.parseInt(parts[2]);
              if (chosen < 0 || chosen > 2) return "Unbekannte Spezialisierung.";
              w.specialization = chosen;
              return "Spezialisierung geändert.";
            }
            if (w.level >= 5) return "Maximale Arbeiterstufe erreicht.";
            long cost = 1000L * w.level * w.level;
            if (p.money < cost || w.workMinutes < w.level * 30L)
              return "Noch nicht genug Geld oder Arbeitserfahrung.";
            p.money -= cost;
            w.level++;
            return "Arbeiter ausgebildet.";
          }
          return "Unbekannte Aktion.";
        });
    if (!plugin.isEnabled()) return;
    plugin.items().refresh(player, plugin.profile(player));
    if (action.startsWith("hire:")
        || action.startsWith("train:")
        || action.startsWith("assign:")
        || action.startsWith("fire:")) plugin.refreshWorkers(player);
    if (action.startsWith("buy:") || action.startsWith("hire:"))
      plugin.mines().decorate(plugin.profile(player));
    plugin.combat().applyStats(player);
    if (rerolled != null && plugin.profile(player).dust < dustBefore)
      showReroll(player, rerolled, critBefore);
    else if (action.equals("chest:buy") && result != null && result.startsWith("Gewölbekiste geöffnet")) {
      Profile after = plugin.profile(player);
      Gear.Item opened = after.gear.getLast();
      plugin.event(
          player,
          "KISTE GEÖFFNET",
          DeepforgePlugin.rarityColor(opened.rarity),
          opened.rarity.title + " · " + Gear.slotName(opened.slot) + " · " + opened.name);
      player.playSound(player.getLocation(), Sound.BLOCK_CHEST_OPEN, 1, 1);
      player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, .6f, 1.4f);
    } else if (action.startsWith("starstone:") && result != null && !result.startsWith("Kein")) {
      boolean won = result.startsWith("✦");
      if (won) plugin.stars().celebrate(player, result.substring(10, result.lastIndexOf(" ist jetzt")));
      else if (result.startsWith("ZERBROCHEN")) plugin.stars().shatter(player);
      player.playSound(
          player.getLocation(),
          won ? Sound.UI_TOAST_CHALLENGE_COMPLETE : Sound.ENTITY_ITEM_BREAK,
          1,
          won ? 1.2f : .7f);
    } else if (failed(result)) {
      // The reason is in chat (visible next to the menu); the sound says that it did not work.
      player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, .8f, 1);
    } else if (result != null && action.startsWith("research:"))
      player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, .8f, 1.2f);
    open(
        player,
        action.startsWith("dust:") || action.startsWith("sell:")
            ? "loot/0"
            : action.startsWith("fire:")
                ? "crew"
                : action.startsWith("preset:set:")
                    ? "preset/" + action.split(":")[2]
                    : action.startsWith("rune:insert:") ? "item/" + action.split(":")[2] : screen.page);
  }

  static boolean failed(String message) {
    if (message == null) return false;
    for (String start :
        List.of(
            "Benötigt",
            "Unbezahlbar",
            "Es fehlen",
            "Es fehlt",
            "Zu wenig",
            "Kein ",
            "Keine ",
            "Baue zuerst",
            "Besiege zuerst",
            "Dieses Gebiet",
            "Gebiet gesperrt",
            "Teil des Sets",
            "Gebiet noch",
            "Nicht gefunden",
            "Gegenstand nicht gefunden",
            "Maximale",
            "Unbekannt",
            "Arbeiter nicht gefunden",
            "Arbeiter fehlt",
            "Beutebeutel voll",
            "Favorisierte",
            "Forschung abgeschlossen",
            "Sammle selbst",
            "Sammlungsbelohnung bereits",
            "Gewölbekisten gibt es",
            "Für diesen Lauf",
            "Die Kiste kostet"))
      if (message.startsWith(start)) return true;
    return false;
  }

  private void showReroll(Player player, Gear.Item item, double before) {
    double after = item.crit;
    boolean better = after > before;
    Profile profile = plugin.profile(player);
    boolean equipped = profile.equipped.containsValue(item.id);
    plugin.event(
        player,
        better ? "KRIT VERBESSERT" : "KRIT NEU GESCHMIEDET",
        better ? NamedTextColor.GREEN : NamedTextColor.RED,
        String.format(
            Locale.GERMAN,
            "%.1f %% → %.1f %% (%+.1f) · %s",
            before * 100,
            after * 100,
            (after - before) * 100,
            equipped
                ? String.format(Locale.GERMAN, "Gesamt-Krit %.1f %%", Gear.stats(profile).crit() * 100)
                : "wirkt erst ausgerüstet"));
    player.playSound(
        player.getLocation(),
        better ? Sound.BLOCK_ANVIL_USE : Sound.BLOCK_ANVIL_LAND,
        .8f,
        better ? 1.4f : .7f);
    player
        .getWorld()
        .spawnParticle(
            better ? Particle.HAPPY_VILLAGER : Particle.SMOKE,
            player.getLocation().add(0, 1.2, 0),
            12,
            .4,
            .4,
            .4,
            0);
  }
}
