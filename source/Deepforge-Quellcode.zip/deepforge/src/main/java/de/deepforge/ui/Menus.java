package de.deepforge.ui;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import java.util.*;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;

public final class Menus implements Listener {
  public static final class Screen implements InventoryHolder {
    Inventory inv;
    final UUID owner;
    final String page;
    final Map<Integer, String> actions = new HashMap<>();

    Screen(UUID owner, String page) {
      this.owner = owner;
      this.page = page;
    }

    @Override
    public Inventory getInventory() {
      return inv;
    }
  }

  private final DeepforgePlugin plugin;
  private final Map<UUID, Long> lastClick = new HashMap<>();

  public Menus(DeepforgePlugin plugin) {
    this.plugin = plugin;
  }

  private void b(
      Screen s,
      int slot,
      Material material,
      String model,
      String name,
      String action,
      String... lore) {
    ItemStack item =
        plugin.items().button(material, model == null ? "handbook" : model, name, lore);
    var meta = item.getItemMeta();
    if (model == null) meta.setItemModel(null);
    List<Component> lines = new ArrayList<>(meta.hasLore() ? meta.lore() : List.of());
    if (action != null) {
      lines.add(Component.empty());
      lines.add(
          Component.text(
              action.startsWith("open:") || action.startsWith("adventure:")
                  ? "▶ Linksklick: öffnen"
                  : "▶ Linksklick: ausführen",
              NamedTextColor.AQUA));
    }
    meta.itemName(Component.text(name, action == null ? NamedTextColor.GRAY : NamedTextColor.GOLD));
    meta.lore(lines);
    item.setItemMeta(meta);
    s.inv.setItem(slot, item);
    s.actions.remove(slot);
    if (action != null) s.actions.put(slot, action);
  }

  private static long unseen(Profile p) {
    return p.gear.stream().filter(i -> !p.seenGear.contains(i.id)).count();
  }

  public Component styledTitle(Player player, String label) {
    Component title = Component.text("DEEPFORGE · " + label, NamedTextColor.DARK_GRAY);
    if (player != null
        && plugin.packApplied(player)
        && plugin.getConfig().getBoolean("resource-pack.textured-menus"))
      return Component.text("\uE0FF\uE100\uE0FE", NamedTextColor.WHITE)
          .font(Key.key("deepforge", "ui"))
          .append(title);
    return title;
  }

  public void open(Player player, String page) {
    if (!plugin.playing(player)) return;
    Inventory inv = create(player, plugin.profile(player), page).inv;
    plugin.items().forViewer(inv, player);
    player.openInventory(inv);
  }

  private Screen create(Player player, Profile p, String page) {
    Screen s = new Screen(UUID.fromString(p.id), page);
    Component title = styledTitle(player, title(page));
    s.inv = Bukkit.createInventory(s, 54, title);
    b(
        s,
        4,
        Material.GOLD_INGOT,
        "coin",
        p.money + " $ · " + p.relics + " Relikte",
        null,
        "Rucksack " + p.bagUsed() + " / " + p.bagCapacity(),
        "Lager " + p.stockUsed() + " / " + p.stockCapacity());
    b(s, 45, Material.ARROW, "back", "Zurück: " + title(parent(page)), "open:" + parent(page));
    b(s, 47, Material.BOOK, "handbook", "Hauptmenü", "open:main");
    b(s, 53, Material.BOOK, "handbook", "Hilfe: " + title(page), null, help(page));
    b(s, 49, Material.BARRIER, "close", "Schließen", "close");
    if (page.equals("main")) b(s, 45, Material.OAK_DOOR, null, "Zum Dorf zurückkehren", "home");
    if (page.startsWith("assignment/") || page.startsWith("specialty/")) {
      int index = Integer.parseInt(page.substring(page.indexOf('/') + 1));
      if (index < 0 || index >= p.workers.size()) return create(player, p, "crew");
      Profile.Worker worker = p.workers.get(index);
      b(
          s,
          4,
          Material.PLAYER_HEAD,
          "worker",
          worker.name + " · Auftrag wählen",
          null,
          "Eine Auswahl übernimmt den Auftrag sofort.");
      if (page.startsWith("assignment/") && worker.job == Profile.Job.LUMBERJACK) {
        Material[] logs = {Material.OAK_LOG, Material.BIRCH_LOG, Material.SPRUCE_LOG};
        for (int species = 0; species < Forestry.WOODS.length; species++) {
          boolean open = species <= p.forestTier;
          b(
              s,
              20 + species * 2,
              open ? logs[species] : Material.BARRIER,
              open ? null : "close",
              Forestry.WOODS[species] + (species == worker.zone ? " · AKTIV" : ""),
              open && species != worker.zone ? "assign:" + index + ":" + species : null,
              open
                  ? "Holzwert: " + Forestry.PRICES[species] + " $ pro Stamm"
                  : "Zuerst am Sägewerk freischalten");
        }
      } else if (page.startsWith("assignment/")) {
        for (int zone = 0; zone < 7; zone++)
          b(
              s,
              19 + zone,
              zone <= p.zone ? Material.MINECART : Material.BARRIER,
              zone <= p.zone ? "ore_" + Zone.at(zone).key : "close",
              Zone.at(zone).title + (zone == worker.zone ? " · AKTIV" : ""),
              zone <= p.zone && zone != worker.zone ? "assign:" + index + ":" + zone : null,
              zone > p.zone
                  ? "Zuerst dieses Gebiet im Aufzug freischalten"
                  : "Arbeiter diesem Gebiet zuweisen");
      } else {
        for (int spec = 0; spec < 3; spec++)
          b(
              s,
              20 + spec * 2,
              Material.BOOK,
              "handbook",
              new String[] {"Allrounder", "Ertrag", "Sparsam"}[spec]
                  + (spec == worker.specialization ? " · AKTIV" : ""),
              worker.level >= 2 && spec != worker.specialization
                  ? "spec:" + index + ":" + spec
                  : null,
              new String[] {
                    "Ausgewogene Arbeitsweise",
                    "+1 Einheit je produktiver Minute",
                    "1 $ weniger Lohn je produktiver Minute"
                  }
                  [spec],
              worker.level >= 2 ? "Kostenlos wechseln" : "Zuerst Arbeiter auf Stufe 2 ausbilden");
      }
      return s;
    }
    if (page.startsWith("loot/")) {
      int pageNumber = Math.max(0, Integer.parseInt(page.substring(5)));
      List<Gear.Item> ordered = new ArrayList<>(p.gear);
      Collections.reverse(ordered);
      int pages = Math.max(1, (ordered.size() + 26) / 27);
      pageNumber = Math.min(pageNumber, pages - 1);
      for (int n = 0; n < 27 && pageNumber * 27 + n < ordered.size(); n++) {
        Gear.Item item = ordered.get(pageNumber * 27 + n);
        b(
            s,
            9 + n,
            Material.PAPER,
            item.model(),
            (p.seenGear.contains(item.id) ? "" : "✦ NEU · ") + item.name + " +" + item.level,
            "open:item/" + item.id,
            gearLore(p, item));
      }
      long fresh = unseen(p);
      b(
          s,
          4,
          Material.CHEST,
          "crate",
          "BEUTE · " + p.gear.size() + " Gegenstände" + (fresh > 0 ? " · " + fresh + " NEU" : ""),
          null,
          "Seite " + (pageNumber + 1) + " / " + pages,
          "Dauerhaft gespeichert; kein Inventarplatz nötig",
          "Schmiedestaub: " + p.dust + " (für Krit-Reroll, aus Zerlegen)");
      if (pageNumber > 0)
        b(s, 46, Material.ARROW, "back", "Vorherige Seite", "open:loot/" + (pageNumber - 1));
      if (pageNumber + 1 < pages)
        b(s, 52, Material.ARROW, "next", "Nächste Seite", "open:loot/" + (pageNumber + 1));
      b(s, 48, Material.ARMOR_STAND, "gear_chest", "Charakter", "open:character");
      b(s, 50, Material.BOOK, "handbook", "Beutebuch & Rezepte", "open:codex");
      // Items shown on this page count as seen from now on; the NEU marks stay until reopening.
      boolean changed = false;
      for (int n = 0; n < 27 && pageNumber * 27 + n < ordered.size(); n++)
        changed |= p.seenGear.add(ordered.get(pageNumber * 27 + n).id);
      if (changed) plugin.commit(player, p);
      return s;
    }
    if (page.startsWith("item/")) {
      Gear.Item item = Gear.find(p, page.substring(5));
      if (item == null) {
        return create(player, p, "loot/0");
      }
      b(
          s,
          13,
          Material.PAPER,
          item.model(),
          item.name + " +" + item.level,
          null,
          gearLore(p, item));
      b(
          s,
          28,
          Material.IRON_SWORD,
          "weapon_sword",
          p.equipped.containsValue(item.id) ? "Ablegen" : "Ausrüsten",
          "equip:" + item.id);
      b(
          s,
          29,
          Material.NETHER_STAR,
          "relic",
          item.favorite ? "Favorit entfernen" : "Als Favorit schützen",
          "favorite:" + item.id);
      b(
          s,
          30,
          Material.ANVIL,
          "machine_furnace",
          "Verbessern +" + (item.level + 1),
          "enhance:" + item.id,
          "Kosten: "
              + 250L * (item.zone + 1) * (item.level + 1)
              + " $ + "
              + (2 + item.level)
              + " Staub",
          "+8 % Basiswerte pro Stufe; maximal +10");
      b(
          s,
          31,
          Material.AMETHYST_SHARD,
          "relic",
          "Krit-Wert neu schmieden",
          "reroll:" + item.id,
          "Aktuell: " + fmt(item.crit * 100) + " % Krit",
          "Möglich: "
              + fmt(Gear.critRange(item)[0] * 100)
              + " – "
              + fmt(Gear.critRange(item)[1] * 100)
              + " % (Seltenheit und Qualität)",
          Gear.rerollPrice(item, item.critRerolls),
          "Du hast " + p.money + " $ / " + p.dust + " Staub",
          "Nur Krit-Chance wird neu gewürfelt");
      if (item.slot == Gear.Slot.WEAPON)
        b(
            s,
            34,
            Material.BLAZE_POWDER,
            "relic",
            "Krit-Schaden neu schmieden",
            "rerollcd:" + item.id,
            "Aktuell: "
                + fmt((Gear.baseCritDamage(item) + item.critDamage) * 100)
                + " % ("
                + fmt(Gear.baseCritDamage(item) * 100)
                + " % Waffentyp + "
                + fmt(item.critDamage * 100)
                + " % Bonus)",
            "Bonus möglich: "
                + fmt(Gear.critDamageRange(item)[0] * 100)
                + " – "
                + fmt(Gear.critDamageRange(item)[1] * 100)
                + " %",
            Gear.rerollPrice(item, item.critDamageRerolls),
            "Nur der Krit-Schaden-Bonus wird neu gewürfelt");
      b(
          s,
          32,
          Material.HOPPER,
          "fuel",
          "Zerlegen",
          "open:confirm/dust/" + item.id,
          "Ertrag: " + (1 + item.rarity.ordinal() * 2 + item.level) + " Staub",
          "Ausgerüstete/Favoriten sind geschützt");
      b(
          s,
          33,
          Material.GOLD_INGOT,
          "coin",
          "Verkaufen: " + item.value() + " $",
          "open:confirm/sell/" + item.id,
          "Ausgerüstete/Favoriten sind geschützt");
      b(s, 46, Material.CHEST, "crate", "Zum Beutel", "open:loot/0");
      return s;
    }
    if (page.startsWith("confirm/")) {
      String[] parts = page.split("/");
      Gear.Item item = Gear.find(p, parts[2]);
      if (item == null) {
        return create(player, p, "loot/0");
      }
      b(
          s,
          22,
          Material.PAPER,
          item.model(),
          item.name,
          null,
          "Gegenstand wird aus deinem Beutel entfernt.");
      b(s, 30, Material.LIME_DYE, "coin", "Bestätigen", parts[1] + ":" + item.id);
      b(s, 32, Material.BARRIER, "close", "Abbrechen", "open:item/" + item.id);
      return s;
    }
    switch (page) {
      case "research" -> {
        b(
            s,
            4,
            Material.BOOK,
            "handbook",
            "Forschung · " + p.researchNotes + " Unterlagen",
            null,
            "Unterlagen: Minenfunde und Lieferaufträge");
        for (int i = 0; i < Industry.RESEARCH.length; i++)
          b(
              s,
              20 + i,
              Material.ENCHANTED_BOOK,
              "relic",
              Industry.RESEARCH[i] + " · " + p.research[i] + "/5",
              "research:" + i,
              Industry.EFFECT[i],
              p.research[i] == 0
                  ? "Noch nicht erforscht"
                  : "Aktuell: " + Industry.researchTotal(p, i),
              "Kosten: "
                  + Industry.researchCost(p, i)
                  + " $ + "
                  + Industry.noteCost(p, i)
                  + " Unterlagen",
              "Zusätzlich: "
                  + 4 * (p.research[i] + 1)
                  + " Eisenbarren (du hast "
                  + p.bars[0]
                  + "); Werkzeugstufe "
                  + p.research[i]);
        b(s, 39, Material.PAPER, "handbook", "Unterlagen verdienen", "open:contracts");
        b(s, 41, Material.CHEST, "crate", "Fundstellen erkunden", "open:expeditions");
      }
      case "contracts" -> {
        for (int kind = 0; kind < 3; kind++) {
          Industry.Contract c = Industry.contract(p, kind);
          long have =
              kind == 0
                  ? p.bag[c.zone()] + p.stock[c.zone()]
                  : kind == 1 ? p.bars[c.zone()] : p.monsterParts[c.zone()];
          b(
              s,
              20 + kind * 2,
              kind == 0 ? Material.RAW_IRON : kind == 1 ? Material.IRON_INGOT : Material.BONE,
              kind == 2 ? "relic" : "ore_" + Zone.at(c.zone()).key,
              new String[] {"Erzlieferung", "Barrenauftrag", "Jagdmaterial"}[kind]
                  + " #"
                  + (c.sequence() + 1),
              "contract:" + kind + ":" + c.sequence(),
              Zone.at(c.zone()).title,
              "Fortschritt: " + have + " / " + c.amount(),
              "Belohnung: " + c.money() + " $ + " + c.notes() + " Unterlagen",
              "Klick: Material abgeben. Kein Zeitlimit.");
        }
        b(s, 40, Material.BOOK, "relic", "Forschung öffnen", "open:research");
      }
      case "expeditions" -> {
        for (int z = 0; z < 7; z++) {
          int found = 0;
          for (int n = 0; n < 3; n++) if (p.expeditions[z * 3 + n]) found++;
          b(
              s,
              19 + z,
              Material.CHEST,
              "crate",
              Zone.at(z).title + " · " + found + "/3 Funde",
              z <= p.zone ? "mine:" + z : null,
              "Drei Fundkisten in seitlichen Stollen",
              "Rechtsklick in der Welt zum Bergen",
              "Je Fund: " + 250 * (z + 1) + " $, 3 Unterlagen, " + (2 + z) + " Staub",
              "Alle drei: zusätzlich 1 Relikt");
          int tier = Industry.collectionTier(p, z);
          b(
              s,
              28 + z,
              Material.AMETHYST_SHARD,
              "relic",
              "Erzsammlung · Rang " + tier + "/3",
              "collect:" + z,
              tier == 3
                  ? "Gemeistert"
                  : p.collected[z] + " / " + Industry.COLLECTION[tier] + " selbst geförderte Erze",
              "Ränge: 500 / 2.000 / 10.000 Erze",
              "Klick: erreichte Belohnung abholen");
        }
      }
      case "character" -> {
        b(
            s,
            1,
            Material.IRON_SWORD,
            "weapon_sword",
            "KAMPF",
            null,
            CharacterSheet.combat(p).toArray(String[]::new));
        b(
            s,
            3,
            Material.IRON_PICKAXE,
            "drill",
            "BERGBAU",
            null,
            CharacterSheet.mining(p).toArray(String[]::new));
        b(
            s,
            5,
            Material.GOLD_INGOT,
            "coin",
            "RESSOURCEN",
            null,
            CharacterSheet.resources(p).toArray(String[]::new));
        b(
            s,
            7,
            Material.NETHER_STAR,
            "relic",
            "FORTSCHRITT",
            null,
            CharacterSheet.progress(p).toArray(String[]::new));
        b(
            s,
            42,
            Material.GOAT_HORN,
            "relic",
            "Meilensteine"
                + (Milestones.claimableCount(p) > 0
                    ? " · " + Milestones.claimableCount(p) + " abholbar"
                    : ""),
            "open:milestones",
            "Langfristige Ziele mit Geld, Staub, Relikten und Unterlagen");
        int n = 0;
        for (Gear.Slot slot : Gear.Slot.values()) {
          Gear.Item item = Gear.equipped(p, slot);
          b(
              s,
              18 + n++,
              Material.PAPER,
              item == null ? "shield" : item.model(),
              Gear.slotName(slot) + ": " + (item == null ? "Leer" : item.name),
              item == null ? "open:loot/0" : "open:item/" + item.id,
              item == null ? new String[] {"Ausrüstung im Beutel auswählen"} : gearLore(p, item));
        }
        b(s, 40, Material.CHEST, "crate", "Beutel öffnen", "open:loot/0");
      }
      case "milestones" -> {
        b(
            s,
            4,
            Material.GOAT_HORN,
            "relic",
            "MEILENSTEINE · " + p.milestones.size() + " / " + Milestones.GOALS.size() * 3,
            null,
            "Jedes Ziel hat drei Stufen. Belohnung per Klick abholen.",
            "Stufe 1: " + Milestones.reward(0),
            "Stufe 2: " + Milestones.reward(1),
            "Stufe 3: " + Milestones.reward(2));
        for (int i = 0; i < Milestones.GOALS.size(); i++) {
          Milestones.Goal g = Milestones.GOALS.get(i);
          int tier = Milestones.claimed(p, g.id());
          long have = Milestones.progress(p, g.id());
          boolean ready = Milestones.claimable(p, g);
          b(
              s,
              18 + i,
              ready ? Material.CHEST : tier >= 3 ? Material.EMERALD : Material.PAPER,
              ready ? "crate" : "relic",
              g.title() + " · Stufe " + Math.min(3, tier + (ready ? 1 : 0)) + " / 3",
              ready ? "milestone:" + g.id() : null,
              tier >= 3
                  ? "Abgeschlossen · " + have + " " + g.unit()
                  : "Fortschritt: " + Math.min(have, g.targets()[tier]) + " / " + g.targets()[tier],
              g.unit(),
              tier >= 3 ? "Alle Stufen abgeholt" : "Belohnung: " + Milestones.reward(tier),
              ready ? "Klick: Belohnung abholen" : tier >= 3 ? "" : "Noch nicht erreicht");
        }
      }
      case "drone" -> {
        if (p.droneLevel <= 0) {
          b(
              s,
              4,
              Material.LANTERN,
              "drone_0",
              "FUNKE · deine Dampfdrohne",
              null,
              "Folgt dir über der Schulter – im Bergwerk und im Gewölbe.",
              "Warnt dich, kurz bevor ein Bossangriff dich trifft.",
              "Piept, wenn eine reiche Ader auf deiner Ebene funkelt.",
              "Module: Sammler (Erz) · Geschütz (Schaden) · Sanitäter (Heilung)");
          b(
              s,
              22,
              Material.ANVIL,
              "drone_0",
              "Funke bauen · " + DroneRules.BUILD_MONEY + " $",
              "drone:build",
              "Dein Geld: " + p.money + " $");
          break;
        }
        b(
            s,
            4,
            Material.LANTERN,
            "drone_" + p.droneSkin,
            "FUNKE · Stufe " + p.droneLevel + " / " + DroneRules.MAX_LEVEL,
            null,
            "Modul: " + DroneRules.MODULES[p.droneModule] + " – " + DroneRules.effect(p.droneModule, p.droneLevel),
            "Aussehen: " + DroneRules.SKINS[p.droneSkin],
            "Bisher: " + p.droneOre + " Erz gefunden · " + p.droneShots + " Bolzen · " + p.droneHealed + "× geheilt",
            "Warnt dich vor Bossangriffen und reichen Adern.");
        int l = p.droneLevel;
        b(
            s,
            20,
            Material.ANVIL,
            "drone_" + p.droneSkin,
            l >= DroneRules.MAX_LEVEL ? "Höchststufe erreicht" : "Verbessern auf Stufe " + (l + 1),
            l >= DroneRules.MAX_LEVEL ? null : "drone:up",
            l >= DroneRules.MAX_LEVEL
                ? "Funke ist voll ausgebaut"
                : "Kosten: " + DroneRules.upgradeMoney(l) + " $ · " + DroneRules.upgradeDust(l) + " Staub"
                    + (DroneRules.upgradeRelics(l) > 0 ? " · " + DroneRules.upgradeRelics(l) + " Relikte" : ""),
            l >= DroneRules.MAX_LEVEL ? "" : "Danach: " + DroneRules.effect(p.droneModule, l + 1));
        b(
            s,
            24,
            p.droneHidden ? Material.GRAY_DYE : Material.LIME_DYE,
            null,
            p.droneHidden ? "Funke rufen" : "Funke ausruhen lassen",
            "drone:toggle",
            p.droneHidden ? "Funke ist gerade in der Werkstatt" : "Funke begleitet dich");
        Material[] icons = {Material.IRON_PICKAXE, Material.CROSSBOW, Material.GLISTERING_MELON_SLICE};
        for (int m = 0; m < DroneRules.MODULES.length; m++)
          b(
              s,
              29 + m * 2,
              icons[m],
              null,
              (m == p.droneModule ? "✔ " : "") + "Modul: " + DroneRules.MODULES[m],
              m == p.droneModule ? null : "drone:module:" + m,
              DroneRules.MODULE_INFO[m],
              DroneRules.effect(m, p.droneLevel));
        for (int k = 0; k < DroneRules.SKINS.length; k++) {
          boolean open = DroneRules.skinUnlocked(l, k);
          b(
              s,
              37 + k * 2,
              open ? Material.LANTERN : Material.BARRIER,
              open ? "drone_" + k : "close",
              (k == p.droneSkin ? "✔ " : "") + "Aussehen: " + DroneRules.SKINS[k],
              open && k != p.droneSkin ? "drone:skin:" + k : null,
              open ? "Freigeschaltet" : "Ab Funke-Stufe " + DroneRules.SKIN_LEVEL[k]);
        }
      }
      case "reward" -> {
        if (LootChests.available(p))
          b(
              s,
              51,
              Material.ENDER_CHEST,
              "crate",
              "Gewölbekiste kaufen · " + Hud.money(LootChests.price(p)),
              "chest:buy",
              "Eine zusätzliche Ausrüstung aus deinem letzten Sieg",
              "(Gebiet " + (p.chestZone + 1) + ", " + DungeonRules.MODES[p.chestMode] + ", Level "
                  + p.chestLevel + ") + Schmiedestaub",
              "Noch " + (LootChests.MAX - p.chestBought) + " von " + LootChests.MAX
                  + " Kisten · jede weitere kostet das Doppelte",
              "Dein Geld: " + Hud.money(p.money));
        RewardDiff gain = plugin.lastReward(player);
        if (gain == null) {
          b(
              s,
              4,
              Material.CHEST,
              "crate",
              "DUNGEON-BEUTE",
              null,
              "Noch keine Dungeon-Beute seit dem Serverstart.",
              "Starte einen Lauf: /df dungeon");
          break;
        }
        List<String> summary = new ArrayList<>();
        for (String line : gain.lines()) if (line.startsWith("+") || line.startsWith("Dungeon")) summary.add(line);
        b(
            s,
            4,
            Material.CHEST,
            "crate",
            "DUNGEON-BEUTE · " + gain.headline(),
            null,
            summary.toArray(String[]::new));
        int slot = 19;
        for (Gear.Item gained : gain.items) {
          Gear.Item item = Gear.find(p, gained.id);
          if (item == null || slot > 43) continue;
          if (slot % 9 == 8) slot += 2;
          b(
              s,
              slot++,
              Material.PAPER,
              item.model(),
              "✦ NEU · " + item.name + " +" + item.level,
              "open:item/" + item.id,
              gearLore(p, item));
        }
        if (gain.items.isEmpty())
          b(s, 22, Material.PAPER, "handbook", "Diesmal keine Ausrüstung", null, "Geld und Materialien stehen oben.");
        b(s, 40, Material.CHEST, "crate", "Zum Beutel", "open:loot/0");
      }
      case "daily" -> {
        java.time.LocalDate today = plugin.today();
        if (Dailies.ensure(p, today)) plugin.commit(player, p);
        int streak = Dailies.liveStreak(p, today);
        b(
            s,
            4,
            Material.CLOCK,
            "clock",
            "TAGESAUFTRÄGE · " + Dailies.claimedCount(p) + " / " + Dailies.COUNT,
            null,
            "Jeden Tag um Mitternacht drei neue Aufträge.",
            "Je Auftrag: " + Dailies.money(p) + " $ + 1 Schmiedestaub",
            "Alle drei: +" + Dailies.bonusMoney(p, streak + (p.dailyBonusClaimed ? 0 : 1)) + " $, 2 Staub,",
            "1 Relikt und 1 Unterlage. Die Serie erhöht den Bonus (bis 7 Tage).");
        String[] icons = {"ore_iron", "worker", "crate"};
        for (int i = 0; i < Dailies.COUNT && i < p.dailyTasks.size(); i++) {
          Dailies.Task t = Dailies.task(p.dailyTasks.get(i));
          if (t == null) continue;
          boolean claimed = p.dailyClaimed[i], ready = !claimed && Dailies.done(p, i);
          b(
              s,
              20 + i * 2,
              claimed ? Material.EMERALD : ready ? Material.CHEST : Material.PAPER,
              claimed ? "relic" : ready ? "crate" : icons[i],
              (claimed ? "✓ " : "") + t.title() + " · " + Dailies.progress(p, i) + " / " + p.dailyTarget[i],
              ready ? "daily:" + i : null,
              t.unit() + " seit Beginn des Tages",
              "Belohnung: " + Dailies.money(p) + " $ + 1 Schmiedestaub",
              claimed ? "Heute erledigt" : ready ? "Klick: Belohnung abholen" : "Noch nicht erreicht");
        }
        b(
            s,
            40,
            Material.BLAZE_POWDER,
            "relic",
            "Serie: " + streak + " Tag" + (streak == 1 ? "" : "e"),
            null,
            "Rekord: " + p.dailyBestStreak + " Tage",
            p.dailyBonusClaimed
                ? "Heute alle drei geschafft – morgen weitermachen!"
                : "Alle drei heute abschließen, sonst reißt die Serie.");
      }
      case "top" -> {
        List<Profile> everyone = plugin.rankingProfiles();
        b(
            s,
            4,
            Material.GOLDEN_HELMET,
            "coin",
            "RANGLISTE · " + everyone.size() + " Spieler",
            null,
            "Alle gespeicherten Spielstände dieses Servers.",
            "Wird alle 30 Sekunden aktualisiert.");
        int[] slots = {10, 12, 14, 16, 28, 30, 32, 34};
        for (int i = 0; i < Leaderboard.BOARDS.size() && i < slots.length; i++) {
          Leaderboard.Board board = Leaderboard.BOARDS.get(i);
          List<String> lore = new ArrayList<>();
          List<Leaderboard.Entry> top = Leaderboard.top(everyone, board, 5);
          for (int r = 0; r < top.size(); r++)
            lore.add((r + 1) + ". " + top.get(r).name() + " – " + Hud.money(top.get(r).score()).replace(" $", "") + " " + board.unit());
          if (top.isEmpty()) lore.add("Noch niemand eingetragen.");
          int rank = Leaderboard.rank(everyone, board, p.id);
          lore.add("");
          lore.add(rank == 0 ? "Du bist noch nicht platziert." : "Dein Platz: #" + rank + " (" + board.score().applyAsLong(p) + ")");
          b(
              s,
              slots[i],
              rank == 1 ? Material.GOLD_BLOCK : rank > 0 && rank <= 3 ? Material.GOLD_INGOT : Material.PAPER,
              rank > 0 && rank <= 3 ? "coin" : "handbook",
              board.title(),
              null,
              lore.toArray(String[]::new));
        }
      }
      case "codex" -> {
        b(
            s,
            4,
            Material.BOOK,
            "handbook",
            "BEUTEBUCH & SCHMIEDE",
            null,
            "Ausrüstungswurf pro Boss: 60 % ungewöhnlich, 30 % selten, 9 % episch, 1 % legendär",
            "Zusätzlich: 2 % benannter Bossgegenstand; Alptraum zusätzlich 0,2 % mythisch",
            "Spätestens der 10. erfolglose Wurf wird episch oder besser",
            "Schmiedestaub: " + p.dust);
        for (int z = 0; z < 7; z++)
          b(
              s,
              19 + z,
              Material.PAPER,
              "ore_" + Zone.at(z).key,
              Gear.UNIQUE[z],
              "craft:" + z,
              "Quelle: " + BossRules.NAMES[z],
              Gear.effect(z),
              "Gefunden: " + (p.discovered.contains(Gear.UNIQUE[z]) ? "Ja" : "Noch nicht"),
              "Fragmente: "
                  + p.bossTokens[z]
                  + " / 40 | "
                  + Gear.MATERIALS[z]
                  + ": "
                  + p.monsterParts[z]
                  + " / 30",
              "Klick: legendär herstellen für Materialien + " + 2000L * (z + 1) + " $",
              "Normal/Veteran/Alptraum-Siege: "
                  + p.bossWins[z * 3]
                  + " / "
                  + p.bossWins[z * 3 + 1]
                  + " / "
                  + p.bossWins[z * 3 + 2]);
        for (int z = 0; z < 7; z++)
          b(
              s,
              37 + z,
              Material.IRON_SWORD,
              "weapon_dagger",
              "Jagd: " + Zone.at(z).title,
              "hunt:" + z,
              "Fortschritt: " + p.huntKills[z] + " / 15 reguläre Gegner",
              "Belohnung: " + 450L * (z + 1) + " $, 3 Staub, 6 Monsterteile",
              "Erledigte Aufträge: " + p.huntsCompleted[z],
              p.huntKills[z] >= Gear.HUNT_TARGET
                  ? "Klick: abholen – danach startet ein neuer Auftrag bei 0"
                  : "Weitere Gegner zählen erst nach dem Abholen. Helfer zählen nicht.");
      }
      case "boss" -> {
        int zone = player == null ? p.zone : plugin.mines().zoneAt(p, player.getLocation());
        if (zone < 0) {
          return create(player, p, "main");
        }
        b(
            s,
            4,
            Material.NETHER_STAR,
            "relic",
            BossRules.NAMES[zone],
            null,
            "Warnflächen meiden; Haltung brechen und Kernfenster nutzen",
            "Rechtsklick: Waffenfähigkeit | Sneak+Rechtsklick: Ausweichen",
            "Tod, Rückkehr oder Verlassen der Arena beendet den Kampf");
        for (int mode = 0; mode < 3; mode++)
          b(
              s,
              20 + mode * 2,
              Material.IRON_SWORD,
              "weapon_" + (mode == 0 ? "sword" : mode == 1 ? "hammer" : "spear"),
              new String[] {"Normal", "Veteran", "Alptraum"}[mode],
              "fight:" + mode,
              BossRules.unlocked(p, zone, mode)
                  ? "Bereit"
                  : "Zuerst vorherige Schwierigkeit besiegen",
              "Bossleben: " + (int) RapidCombat.bossHealth(zone, mode),
              "Fragmente: "
                  + (2 + mode)
                  + " | Zeitlimit: "
                  + RapidCombat.BOSS_TIME_MINUTES
                  + " Minuten",
              "Rückenangriffe provozieren einen Rundumschlag!");
      }
      case "main" -> {
        b(
            s,
            19,
            Material.IRON_PICKAXE,
            "drill",
            "Bergbau",
            "open:mining",
            "Minen betreten · Bohrer verbessern",
            "Erze einlagern, schmelzen und verkaufen");
        b(
            s,
            22,
            Material.IRON_AXE,
            null,
            "Wald & Sägewerk",
            "open:forestry",
            "Bäume fällen · Holz verarbeiten",
            "Axt, Glück und Holzlager verbessern");
        b(
            s,
            25,
            Material.IRON_SWORD,
            "weapon_sword",
            "Kampf & Ausrüstung",
            "open:combat",
            "Charakter · Beute · Dungeons",
            "Gefundene Gegenstände ausrüsten");
        b(
            s,
            28,
            Material.PLAYER_HEAD,
            "worker",
            "Arbeiter & Betrieb",
            "open:business",
            "Arbeiter einstellen und zuweisen",
            "Brennstoff, Budget und Offline-Produktion");
        b(
            s,
            31,
            Material.MAP,
            "handbook",
            "Aufträge & Abenteuer",
            "open:goals",
            "Lieferungen · Sammlungen · Forschung",
            "Beuteziele und Fortschritt ansehen");
        b(
            s,
            34,
            Material.BOOK,
            "handbook",
            "Starthilfe & Tutorial",
            "adventure:tutorial",
            "Schritt für Schritt mit Belohnungen",
            "Du kannst das Tutorial jederzeit fortsetzen");
        b(
            s,
            40,
            Material.MAP,
            "handbook",
            "Nächstes Ziel",
            "quest",
            Economy.questText(p.quest),
            "Klick: Belohnung abholen, sobald erfüllt");
        b(
            s,
            36,
            Material.LANTERN,
            "drone_" + p.droneSkin,
            p.droneLevel > 0 ? "Funke · Stufe " + p.droneLevel : "Funke · Dampfdrohne bauen",
            "open:drone",
            p.droneLevel > 0
                ? "Modul: " + DroneRules.MODULES[p.droneModule]
                : "Begleiter: sammelt Erz, kämpft mit oder heilt dich");
        b(
            s,
            38,
            Material.CLOCK,
            "clock",
            "Tagesaufträge · " + Dailies.claimedCount(p) + "/" + Dailies.COUNT
                + (Dailies.readyCount(p) > 0 ? " · abholbar!" : ""),
            "open:daily",
            "Neue Aufgaben jeden Tag · Serie: " + Dailies.liveStreak(p, plugin.today()) + " Tage");
        b(
            s,
            42,
            Material.AMETHYST_SHARD,
            "healing_crystal",
            "Heilen · " + p.healingCharges + "/12 Splitter",
            "heal",
            "4 LP + 35 % maximales Leben",
            "Verbraucht 1 Splitter · 20 s Pause");
      }
      case "mining" -> {
        b(
            s,
            19,
            Material.IRON_PICKAXE,
            "drill",
            "1 · Mine betreten",
            "mine:" + p.zone,
            Zone.at(p.zone).title);
        b(
            s,
            22,
            Material.BARREL,
            "crate",
            "2 · Einlagern & Schmelzen",
            "open:storage",
            "Erz → Lager → Barren → Verkauf");
        b(
            s,
            25,
            Material.ANVIL,
            "blade",
            "3 · Werkzeuge verbessern",
            "open:gear",
            "Bohrer, Grundwaffe, Schutz, Rucksack und Erzglück");
        b(s, 30, Material.MINECART, "scanner", "Andere Mine / Gebiet freischalten", "open:travel");
        b(s, 32, Material.CHEST, "crate", "Versteckte Fundkisten", "open:expeditions");
      }
      case "combat" -> {
        b(
            s,
            19,
            Material.ARMOR_STAND,
            "gear_chest",
            "Charakter & Gesamtwerte",
            "open:character",
            "Aktive Ausrüstung und Kampfwerte");
        b(
            s,
            22,
            Material.CHEST,
            "crate",
            "Gefundene Ausrüstung" + (unseen(p) > 0 ? " · " + unseen(p) + " NEU" : ""),
            "open:loot/0",
            p.gear.size() + " Gegenstände · ausrüsten oder verbessern");
        if (plugin.lastReward(player) != null)
          b(
              s,
              34,
              Material.GOLD_INGOT,
              "coin",
              "Letzte Dungeon-Beute",
              "open:reward",
              plugin.lastReward(player).headline());
        b(
            s,
            25,
            Material.ENDER_EYE,
            "relic",
            "Party & Dungeon",
            "dungeon",
            "Solo oder mit bis zu 4 Spielern");
        b(s, 30, Material.BOOK, "handbook", "Bossbeute & Rezepte", "open:codex");
        b(
            s,
            28,
            Material.SMITHING_TABLE,
            "blade",
            "Set-Schmiede",
            "adventure:setforge",
            "2 doppelte Set-Teile → 1 fehlendes Teil deiner Wahl");
        b(
            s,
            32,
            Material.ANVIL,
            "blade",
            "Grundwaffe & Schutz verbessern",
            "open:gear",
            "Dauerhafte Grund-Upgrades; Beute separat im Beutel");
        b(
            s,
            40,
            Material.AMETHYST_SHARD,
            "healing_crystal",
            "Heilen · " + p.healingCharges + " Splitter",
            "heal",
            "Verbraucht 1 Splitter · 20 s Pause");
      }
      case "business" -> {
        b(
            s,
            19,
            Material.PLAYER_HEAD,
            "worker",
            "1 · Arbeiter verwalten",
            "open:crew",
            "Anstellen, Mine zuweisen, Schicht und Ausbildung");
        b(
            s,
            22,
            Material.BLAST_FURNACE,
            "machine_furnace",
            "2 · Betrieb versorgen",
            "open:factory",
            "Brennstoff und Lohnbudget bereitstellen");
        b(
            s,
            25,
            Material.BARREL,
            "crate",
            "3 · Waren verwalten",
            "open:storage",
            "Lagerbestände, Schmelzen und Verkauf");
        b(s, 30, Material.ENCHANTED_BOOK, "relic", "Betriebsforschung", "open:research");
        b(s, 32, Material.PAPER, "handbook", "Letzte Offline-Abrechnung", "report");
      }
      case "goals" -> {
        b(
            s,
            19,
            Material.PAPER,
            "handbook",
            "Material liefern",
            "open:contracts",
            "Erze, Barren und Monsterteile gegen Geld & Unterlagen");
        b(s, 22, Material.NETHER_STAR, "relic", "Abenteuerbuch & Artefakte", "adventure:journal");
        b(s, 25, Material.ENCHANTED_BOOK, "relic", "Forschung verbessern", "open:research");
        b(s, 30, Material.EMERALD, "coin", "Erzaufträge & Meilensteine", "open:trade");
        b(s, 32, Material.CHEST, "crate", "Fundkisten & Sammlungen", "open:expeditions");
        b(
            s,
            28,
            Material.CLOCK,
            "clock",
            "Tagesaufträge" + (Dailies.readyCount(p) > 0 ? " · " + Dailies.readyCount(p) + " abholbar" : ""),
            "open:daily",
            "Drei Aufgaben pro Tag mit Serienbonus");
        b(s, 34, Material.GOLDEN_HELMET, "coin", "Rangliste", "open:top", "Wer ist der Beste auf dem Server?");
      }
      case "forestry", "woodwork", "woodupgrades" -> {
        b(
            s,
            4,
            Material.OAK_LOG,
            null,
            "Holzlager · " + Forestry.used(p) + " / " + Forestry.capacity(p),
            null,
            "Geld: " + p.money + " $ · Harz: " + p.resin,
            "Brennstoff: " + p.fuel);
        b(
            s,
            9,
            Material.OAK_SAPLING,
            null,
            "1 · Wald",
            page.equals("forestry") ? null : "open:forestry");
        b(
            s,
            12,
            Material.STONECUTTER,
            null,
            "2 · Verarbeiten & Verkaufen",
            page.equals("woodwork") ? null : "open:woodwork");
        b(
            s,
            15,
            Material.IRON_AXE,
            null,
            "3 · Verbessern",
            page.equals("woodupgrades") ? null : "open:woodupgrades");
        if (page.equals("forestry")) {
          b(
              s,
              20,
              Material.IRON_AXE,
              null,
              "Bäume fällen",
              null,
              "Vom Dorf nach Osten dem Kiesweg folgen.",
              "Forstaxt in die Hand nehmen.",
              "Am Stamm Linksklick halten, bis der Baum fällt.",
              "Erntebäume stehen in drei beschrifteten Hainen.",
              "Dekorationsbäume am Waldrand sind geschützt.");
          b(
              s,
              24,
              Material.OAK_SAPLING,
              null,
              p.forestTier == 2
                  ? "Alle Haine freigeschaltet"
                  : "Nächster Hain: " + Forestry.WOODS[p.forestTier + 1],
              p.forestTier == 2 ? null : "forest:unlock",
              "Birke: Axt 2 · 64 gefälltes Holz · 1.000 $",
              "Fichte: Axt 5 · 256 gefälltes Holz · 4.000 $",
              "Dein Fortschritt: Axt " + p.axe + " · " + p.woodChopped + " Holz");
          int species = p.woodOrders % (p.forestTier + 1);
          long amount = 24 + (p.woodOrders % 4) * 8L;
          b(
              s,
              31,
              Material.PAPER,
              "handbook",
              "Holzauftrag #" + (p.woodOrders + 1),
              "forest:contract:" + p.woodOrders,
              Forestry.WOODS[species] + ": " + p.wood[species] + " / " + amount,
              "Abgeben: " + amount + " Holz → " + amount * Forestry.PRICES[species] * 3 / 2 + " $",
              "Jeder fünfte Auftrag: +1 Harz");
          b(
              s,
              40,
              Material.CLOCK,
              "clock",
              "Bäume wachsen nach",
              null,
              "Eiche 45 s · Birke 60 s · Fichte 75 s",
              "Harz: seltener Fund beim Fällen");
        } else if (page.equals("woodwork")) {
          // One row per wood type: stock · saw · sell logs · sell planks · sell both.
          // Right column: everything at once, charcoal, fuel.
          Material[] logs = {Material.OAK_LOG, Material.BIRCH_LOG, Material.SPRUCE_LOG};
          Material[] boards = {Material.OAK_PLANKS, Material.BIRCH_PLANKS, Material.SPRUCE_PLANKS};
          long value = 0;
          for (int i = 0; i < 3; i++) {
            int row = 18 + i * 9;
            long logValue = p.wood[i] * Forestry.PRICES[i];
            long plankValue = p.planks[i] * Forestry.PLANK_PRICES[i];
            value += logValue + plankValue;
            long batch = Math.min(16, Math.min(p.wood[i], p.fuel));
            batch =
                Math.min(
                    batch, Math.max(0, Forestry.capacity(p) - Forestry.used(p)) / (1 + p.sawmill));
            b(
                s,
                row,
                logs[i],
                null,
                Forestry.WOODS[i].toUpperCase(java.util.Locale.ROOT),
                null,
                p.wood[i] + " Stämme · " + p.planks[i] + " Bretter",
                "Stamm " + Forestry.PRICES[i] + " $ · Brett " + Forestry.PLANK_PRICES[i] + " $",
                "Sägen lohnt sich: 1 Stamm → " + (2 + p.sawmill) + " Bretter");
            b(
                s,
                row + 2,
                Material.STONECUTTER,
                null,
                "Sägen" + (batch > 0 ? " · " + batch + " → " + batch * (2 + p.sawmill) + " Bretter" : ""),
                batch > 0 ? "forest:saw:" + i : null,
                batch > 0
                    ? "Verbraucht " + batch + " Stämme und " + batch + " Brennstoff"
                    : p.wood[i] == 0
                        ? "Keine " + Forestry.WOODS[i] + "-Stämme"
                        : p.fuel == 0 ? "Kein Brennstoff (rechts kaufen)" : "Holzlager voll");
            b(
                s,
                row + 4,
                logs[i],
                null,
                "Stämme verkaufen · +" + logValue + " $",
                p.wood[i] > 0 ? "forest:sellwood:" + i : null,
                p.wood[i] + " × " + Forestry.PRICES[i] + " $",
                "Bretter bleiben im Lager");
            b(
                s,
                row + 5,
                boards[i],
                null,
                "Bretter verkaufen · +" + plankValue + " $",
                p.planks[i] > 0 ? "forest:sellplanks:" + i : null,
                p.planks[i] + " × " + Forestry.PLANK_PRICES[i] + " $",
                "Stämme bleiben im Lager");
            b(
                s,
                row + 6,
                Material.EMERALD,
                "coin",
                "Beides verkaufen · +" + (logValue + plankValue) + " $",
                logValue + plankValue > 0 ? "forest:sell:" + i : null,
                "Stämme und Bretter von " + Forestry.WOODS[i],
                "Die anderen Holzarten bleiben im Lager");
          }
          b(
              s,
              26,
              Material.EMERALD_BLOCK,
              "coin",
              "Alles verkaufen · +" + value + " $",
              value > 0 ? "forest:sell" : null,
              "Alle Holzarten, Stämme und Bretter",
              "Holz für Aufträge vorher abgeben.");
          b(
              s,
              35,
              Material.CHARCOAL,
              "fuel",
              "10 Stämme → 20 Brennstoff",
              "forest:charcoal",
              "Verbraucht zuerst Eiche, dann Birke, dann Fichte.");
          b(
              s,
              44,
              Material.COAL,
              "fuel",
              "20 Brennstoff kaufen · 20 $",
              "fuel20",
              "Brennstoff: " + p.fuel + " · zum Sägen nötig");
        } else {
          forestUpgrade(
              s,
              p,
              20,
              "axe",
              "Forstaxt",
              p.axe,
              10,
              Material.IRON_AXE,
              "Abbaugeschwindigkeit "
                  + fmt(Forestry.speed(p))
                  + "× → "
                  + fmt(Forestry.speed(p) + .65)
                  + "×");
          forestUpgrade(
              s,
              p,
              24,
              "woodLuck",
              "Holzglück",
              p.woodLuck,
              10,
              Material.EMERALD,
              fmt(OreYield.multiplier(p.woodLuck))
                  + "× → "
                  + fmt(OreYield.multiplier(p.woodLuck + 1))
                  + "×",
              "Doppelte Ernte: "
                  + p.woodLuck * 10
                  + " % → "
                  + Math.min(100, (p.woodLuck + 1) * 10)
                  + " %");
          forestUpgrade(
              s,
              p,
              29,
              "woodStorage",
              "Holzlager",
              p.woodStorage,
              10,
              Material.BARREL,
              Forestry.capacity(p) + " → " + (Forestry.capacity(p) + 200) + " Plätze");
          forestUpgrade(
              s,
              p,
              33,
              "sawmill",
              "Sägewerk",
              p.sawmill,
              3,
              Material.STONECUTTER,
              (2 + p.sawmill) + " → " + (3 + p.sawmill) + " Bretter je Stamm");
        }
      }
      case "gear" -> {
        b(
            s,
            38,
            Material.EMERALD,
            "relic",
            String.format(
                Locale.GERMAN,
                "Erzglück %.1f× → %.1f×",
                OreYield.multiplier(p.oreLuck),
                OreYield.multiplier(p.oreLuck + 1)),
            p.oreLuck < 10 && p.money >= Economy.upgradeCost(p, "oreLuck") ? "buy:oreLuck" : null,
            "Aktuell " + p.oreLuck * 10 + " % Chance auf doppelte Beute",
            "Zusätzlich zu Modul- und Ausrüstungsboni",
            p.oreLuck >= 10
                ? "Maximum 2,0× erreicht"
                : "Kosten: " + Economy.upgradeCost(p, "oreLuck") + " $",
            p.oreLuck >= 10 ? "100 % Doppelbeute" : "Dein Geld: " + p.money + " $");
        b(s, 42, Material.IRON_AXE, null, "Holz-Upgrades", "open:woodupgrades");
        upgrade(s, p, 19, "tool", "Bohrer", p.tool, Material.IRON_PICKAXE, "drill");
        upgrade(s, p, 21, "sword", "Grubenklinge", p.sword, Material.IRON_SWORD, "blade");
        upgrade(s, p, 23, "armor", "Schutztraining", p.armor, Material.IRON_CHESTPLATE, "shield");
        upgrade(s, p, 25, "bag", "Rucksack", p.bagLevel, Material.BUNDLE, "crate");
        b(
            s,
            30,
            Material.IRON_INGOT,
            "ore_iron",
            "Ertragsmodul" + (p.module == 0 ? " · Aktiv" : ""),
            "module:0",
            "Chance auf zusätzliche Erze");
        b(
            s,
            31,
            Material.REDSTONE,
            "drill",
            "Tempomodul" + (p.module == 1 ? " · Aktiv" : ""),
            "module:1",
            "35 % schneller, mehr Hitze");
        b(
            s,
            32,
            Material.AMETHYST_SHARD,
            "relic",
            "Suchermodul" + (p.module == 2 ? " · Aktiv" : ""),
            "module:2",
            "Höhere Chance auf Relikte");
        b(
            s,
            40,
            Material.SPYGLASS,
            "scanner",
            "Scanner / Überladung",
            null,
            "Sneak + Rechtsklick mit Bohrer: Scanner",
            "Rechtsklick: 8 Sek. Überladung, 45 Sek. Abklingzeit");
      }
      case "crew" -> {
        b(
            s,
            13,
            Material.BELL,
            "worker",
            "Mannschaft · " + p.workers.size() + " / " + p.workerSlots(),
            null,
            "Arbeiter anklicken: Auftrag, Ausbildung und Schicht.",
            "Brennstoff: " + p.fuel + " · Lohnbudget: " + p.budget + " $",
            "Neue Einstellung: " + 1500L * (p.workers.size() + 1) + " $");
        b(s, 44, Material.COAL, "fuel", "Brennstoff & Lohnbudget auffüllen", "open:factory");
        for (int i = 0; i < p.workers.size(); i++) {
          Profile.Worker w = p.workers.get(i);
          b(
              s,
              19 + i,
              Material.PLAYER_HEAD,
              "worker",
              w.name + " · Stufe " + w.level,
              "open:worker/" + i,
              jobName(w.job),
              workplace(p, w),
              "Arbeit: " + w.workMinutes + " Minuten",
              Industry.unitsPerMinute(p, w)
                  + " Waren/Min. · ~"
                  + Industry.hourlyValue(p, w)
                  + " $ Warenwert/h · Lohn "
                  + Industry.wage(w) * 60
                  + " $/h",
              Industry.nextFind(w));
          var item = s.inv.getItem(19 + i);
          var meta = item.getItemMeta();
          var lore = new ArrayList<>(meta.lore());
          lore.add(
              Component.text(
                  (player == null ? "Bereit" : plugin.workerStatus(player, i)),
                  NamedTextColor.AQUA));
          meta.lore(lore);
          item.setItemMeta(meta);
        }
        b(
            s,
            37,
            Material.IRON_PICKAXE,
            "drill",
            "Bergarbeiter einstellen",
            "hire:MINER",
            "Kosten: " + 1500L * (p.workers.size() + 1) + " $",
            "Voraussetzung: Steinwächter besiegt");
        b(
            s,
            39,
            Material.BLAST_FURNACE,
            "machine_furnace",
            "Schmelzer einstellen",
            "hire:SMELTER",
            "Benötigt eine Schmelze");
        b(
            s,
            41,
            Material.EMERALD,
            "coin",
            "Händler einstellen",
            "hire:TRADER",
            "Benötigt Gebiet 2; verkauft zugewiesene Ware");
        b(
            s,
            43,
            Material.IRON_AXE,
            null,
            "Holzfäller einstellen",
            "hire:LUMBERJACK",
            "Fällt Bäume einer Holzart ins Holzlager",
            "Braucht keinen Brennstoff · findet ab und zu Harz");
      }
      case "factory" -> {
        b(
            s,
            37,
            Material.GOLD_NUGGET,
            "coin",
            "100 $ Betriebsbudget bereitstellen",
            "budget100",
            "Kleine Versorgung für den Anfang");
        b(s, 38, Material.COAL, "fuel", "20 Brennstoff für 20 $", "fuel20");
        b(s, 42, Material.ENCHANTED_BOOK, "relic", "Betriebsforschung", "open:research");
        upgrade(s, p, 19, "warehouse", "Lager", p.warehouse, Material.BARREL, "crate");
        upgrade(
            s, p, 21, "furnace", "Schmelze", p.furnace, Material.BLAST_FURNACE, "machine_furnace");
        upgrade(s, p, 23, "housing", "Unterkunft", p.housing, Material.BELL, "worker");
        b(
            s,
            29,
            Material.COAL,
            "fuel",
            "Brennstoff: " + p.fuel,
            "fuel",
            "+120 Einheiten für 120 $",
            "1 Einheit je arbeitendem Förderer/Schmelzer pro Minute");
        b(
            s,
            31,
            Material.GOLD_INGOT,
            "coin",
            "Betriebsbudget: " + p.budget + " $",
            "budget",
            "1.000 $ aus deinem Geld bereitstellen",
            "Löhne werden nur bei tatsächlicher Arbeit berechnet");
        b(
            s,
            33,
            Material.CLOCK,
            "clock",
            "Offline-Produktion: bis " + p.offlineHours() + " Stunden",
            null,
            "Stoppt bei fehlender Versorgung oder vollem Lager",
            "Händler benötigen keinen Brennstoff");
        b(s, 40, Material.PAPER, "handbook", "Letzte Abrechnung", "report");
      }
      case "storage" -> {
        for (int z = 0; z < 7; z++)
          b(
              s,
              19 + z,
              Material.IRON_INGOT,
              "ore_" + Zone.at(z).key,
              Zone.at(z).oreName,
              z <= p.zone ? "open:smelt" : null,
              "Rucksack: " + p.bag[z],
              "Lager: " + p.stock[z],
              Industry.barName(z) + ": " + p.bars[z],
              z <= p.zone ? "Klick: Schmelzen öffnen" : "Gebiet noch gesperrt");
        b(s, 30, Material.HOPPER, "crate", "Rucksack einlagern", "deposit");
        b(
            s,
            34,
            Material.RAW_IRON,
            "coin",
            "Nur Erze verkaufen",
            "sellore",
            "Verkauft Rucksack und Lagererz",
            "Barren bleiben für Forschung und Aufträge");
        b(
            s,
            32,
            Material.GOLD_INGOT,
            "coin",
            "Alle Waren verkaufen",
            "sell",
            "Verkauft Rucksack, Lager und Barren",
            "Auftragsmaterial vorher abgeben!");
        b(
            s,
            42,
            Material.GOLD_INGOT,
            "coin",
            "Nur Barren verkaufen",
            "sellbars",
            "Erze bleiben im Lager",
            "Barren für Forschung und Barrenauftrag bleiben liegen");
        b(
            s,
            40,
            Material.FURNACE,
            "machine_furnace",
            "Schmelzen · Erzart wählen",
            "open:smelt",
            "Je Barren: 2 eingelagerte Erze + 1 Brennstoff",
            "Brennstoff: " + p.fuel + (p.furnace == 0 ? " · Schmelze fehlt!" : ""),
            "Forschung braucht " + Industry.barName(0) + " (" + p.bars[0] + " vorhanden)");
      }
      case "smelt" -> {
        for (int z = 0; z < 7; z++) {
          boolean open = z <= p.zone;
          long possible = Math.min(p.stock[z] / 2, p.fuel);
          b(
              s,
              19 + z,
              Material.IRON_INGOT,
              "ore_" + Zone.at(z).key,
              open ? "Bis 32 " + Industry.barName(z) : Zone.at(z).oreName + " · gesperrt",
              open ? "smelt:" + z + ":32" : null,
              "Lager: " + p.stock[z] + " " + Zone.at(z).oreName,
              "Vorhanden: " + p.bars[z] + " " + Industry.barName(z),
              open
                  ? possible > 0
                      ? "Möglich jetzt: " + possible + " Barren"
                      : p.stock[z] < 2 ? "Zu wenig Erz im Lager" : "Kein Brennstoff"
                  : "Gebiet noch nicht freigeschaltet");
          if (open)
            b(
                s,
                28 + z,
                Material.BLAST_FURNACE,
                "machine_furnace",
                "Alles schmelzen: " + Zone.at(z).oreName,
                "smelt:" + z + ":all",
                "Bis Erz oder Brennstoff aufgebraucht sind",
                "Möglich jetzt: " + possible + " Barren");
        }
        b(
            s,
            40,
            Material.COAL,
            "fuel",
            "Brennstoff: " + p.fuel + (p.furnace == 0 ? " · Schmelze fehlt!" : ""),
            "open:factory",
            "Je Barren: 2 eingelagerte Erze + 1 Brennstoff",
            "Schmelze und Brennstoff im Betrieb besorgen");
        b(
            s,
            37,
            Material.BLAST_FURNACE,
            "machine_furnace",
            "Schmelze & Brennstoff besorgen",
            "open:factory");
        long bars = 0, worth = 0;
        for (int z = 0; z < 7; z++) {
          long n = Industry.sellableBars(p, z);
          bars += n;
          worth += n * Zone.at(z).barPrice;
        }
        b(
            s,
            43,
            Material.GOLD_INGOT,
            "coin",
            "Nur Barren verkaufen · +" + worth + " $",
            bars > 0 ? "sellbars" : null,
            bars + " Barren · Erze bleiben im Lager",
            "Barren für Forschung und Barrenauftrag bleiben liegen");
      }
      case "trade" -> {
        b(s, 39, Material.PAPER, "handbook", "Große Auftragstafel", "open:contracts");
        b(s, 41, Material.BOOK, "relic", "Forschung und Funde", "open:research");
        int count = 80 + (p.orders % 4) * 40;
        b(
            s,
            20,
            Material.PAPER,
            "handbook",
            "Lieferauftrag #" + (p.orders + 1),
            "order",
            count + " " + Zone.at(p.zone).oreName,
            "Vergütung: " + count * Zone.at(p.zone).orePrice * 3 / 2 + " $",
            "Jeder fünfte Auftrag: +1 Relikt");
        b(s, 22, Material.BOOK, "relic", "Meilenstein", "quest", Economy.questText(p.quest));
        b(s, 24, Material.GOLD_INGOT, "coin", "Alle Waren verkaufen", "sell");
        b(
            s,
            31,
            Material.AMETHYST_SHARD,
            "relic",
            "Sammlung: " + Zone.at(p.zone).oreName,
            "collection",
            "Selbst gesammelt: " + p.collected[p.zone] + " / 500",
            "Einmalige Belohnung: 3 Relikte");
      }
      case "travel" -> {
        for (int z = 0; z < 7; z++)
          b(
              s,
              19 + z,
              z <= p.zone ? Material.MINECART : Material.BARRIER,
              "ore_" + Zone.at(z).key,
              Zone.at(z).title,
              z <= p.zone ? "mine:" + z : null,
              z <= p.zone ? "Erschlossen" : "Noch gesperrt",
              "Werkzeugstufe " + Zone.at(z).toolRequired);
        b(
            s,
            31,
            Material.TRIPWIRE_HOOK,
            "scanner",
            "Nächstes Gebiet erschließen",
            "unlock",
            p.zone == 6 ? "Alle Gebiete offen" : Zone.at(p.zone + 1).unlockCost + " $",
            "Aktuellen Boss besiegen und Werkzeug verbessern");
        b(s, 40, Material.OAK_DOOR, "handbook", "Zurück zum Betrieb", "home");
      }
      default -> {
        if (page.startsWith("worker/")) {
          int i = Integer.parseInt(page.substring(7));
          if (i < 0 || i >= p.workers.size()) return create(player, p, "crew");
          Profile.Worker w = p.workers.get(i);
          b(
              s,
              13,
              Material.PLAYER_HEAD,
              "worker",
              w.name + " · " + (player == null ? "Bereit" : plugin.workerStatus(player, i)),
              null,
              "Auftrag: " + workplace(p, w),
              "Leistung: "
                  + (w.level + 1 + (w.specialization == 1 ? 1 : 0) + p.research[2])
                  + " Einheiten/Minute vor Produktionsgrenzen",
              "Lohn: " + Industry.wage(w) + " $ je produktiver Minute",
              "Brennstoff und Budget: im Betriebsmenü");
          if (w.job == Profile.Job.LUMBERJACK)
            b(s, 30, Material.OAK_SAPLING, null, "Wald & Holzlager öffnen", "open:forestry");
          else
            b(s, 30, Material.MINECART, "scanner", "Zugewiesene Mine besuchen", "mine:" + w.zone);
          b(
              s,
              32,
              w.paused ? Material.LIME_DYE : Material.RED_DYE,
              "clock",
              w.paused ? "Schicht fortsetzen" : "Schicht pausieren",
              "pause:" + i,
              "Pausierte Arbeiter verbrauchen keine Löhne/Brennstoff");
          b(s, 34, Material.COAL, "fuel", "Versorgung öffnen", "open:factory");
          b(
              s,
              20,
              Material.EXPERIENCE_BOTTLE,
              "worker",
              w.name + " ausbilden",
              "train:" + i,
              "Stufe " + w.level + " / 5",
              "Kosten: " + 1000L * w.level * w.level + " $",
              "Erfahrung: " + w.workMinutes + " / " + w.level * 30 + " Arbeitsminuten");
          b(
              s,
              22,
              Material.MINECART,
              "scanner",
              w.job == Profile.Job.LUMBERJACK ? "Holzart wechseln" : "Gebiet wechseln",
              "open:assignment/" + i,
              "Aktuell: " + workplace(p, w),
              w.job == Profile.Job.LUMBERJACK
                  ? "Klick: Eiche, Birke oder Fichte wählen"
                  : "Klick: gewünschtes Gebiet direkt auswählen");
          b(
              s,
              24,
              Material.BOOK,
              "handbook",
              "Spezialisierung wechseln",
              "open:specialty/" + i,
              "Aktuell: "
                  + switch (w.specialization) {
                    case 1 -> "Ertrag";
                    case 2 -> "Sparsam";
                    default -> "Allrounder";
                  },
              "Ab Stufe 2 frei wechselbar");
          b(s, 40, Material.ARROW, "back", "Zur Mannschaft", "open:crew");
          b(
              s,
              44,
              Material.BARRIER,
              "close",
              w.name + " entlassen",
              "open:fire/" + i,
              "Gibt den Arbeiterplatz frei",
              "Mit Bestätigung – Stufe und Erfahrung gehen verloren");
        }
        if (page.startsWith("fire/")) {
          int i = Integer.parseInt(page.substring(5));
          if (i < 0 || i >= p.workers.size()) return create(player, p, "crew");
          Profile.Worker w = p.workers.get(i);
          b(
              s,
              13,
              Material.PLAYER_HEAD,
              "worker",
              w.name + " wirklich entlassen?",
              null,
              Menus.jobName(w.job) + " · Stufe " + w.level + " · " + w.workMinutes + " Arbeitsminuten",
              "Stufe, Spezialisierung und Erfahrung gehen verloren.",
              "Kein Geld zurück. Der Platz wird sofort frei.");
          b(s, 29, Material.RED_CONCRETE, "close", "Ja, " + w.name + " entlassen", "fire:" + w.id);
          b(s, 33, Material.LIME_CONCRETE, "back", "Nein, behalten", "open:worker/" + i);
        }
      }
    }
    return s;
  }

  private static String parent(String page) {
    if (page.startsWith("assignment/") || page.startsWith("specialty/"))
      return "worker/" + page.substring(page.indexOf('/') + 1);
    if (page.startsWith("worker/")) return "crew";
    if (page.startsWith("fire/")) return "worker/" + page.substring(5);
    if (page.startsWith("item/") || page.startsWith("loot/"))
      return page.startsWith("item/") ? "loot/0" : "combat";
    if (page.startsWith("confirm/")) return "item/" + page.split("/")[2];
    return switch (page) {
      case "woodwork", "woodupgrades" -> "forestry";
      case "crew", "factory" -> "business";
      case "storage", "gear", "travel", "expeditions" -> "mining";
      case "smelt" -> "storage";
      case "character", "codex", "boss" -> "combat";
      case "milestones" -> "character";
      case "research", "contracts", "trade", "daily", "top" -> "goals";
      case "reward" -> "combat";
      case "drone" -> "main";
      default -> "main";
    };
  }

  private static String[] help(String page) {
    return switch (page) {
      case "storage" ->
          new String[] {
            "1. Rucksack einlagern.",
            "2. Schmelze und Brennstoff im Betrieb besorgen.",
            "3. Unter Schmelzen die Erzart wählen und Barren herstellen.",
            "4. Auftragsmaterial abgeben oder Waren verkaufen."
          };
      case "crew" ->
          new String[] {
            "Arbeiter anklicken, um ihren Auftrag zu ändern.",
            "Arbeit benötigt Lagerplatz, Brennstoff und Lohnbudget.",
            "Versorgung unter Arbeiter & Betrieb → Betrieb."
          };
      case "gear" ->
          new String[] {
            "Hier kaufst du dauerhafte Grund-Upgrades.",
            "Gefundene Waffen verwaltest du unter Kampf → Beute.",
            "Ein Modul ist aktiv; Wechsel ist kostenlos."
          };
      case "forestry", "woodwork", "woodupgrades" ->
          new String[] {
            "Obere Reihe: Wald / Verarbeitung / Upgrades.",
            "Wald: vom Dorf nach Osten laufen.",
            "Holzlager ist getrennt vom Erzlager.",
            "Glück 1,1× bedeutet 10 % Chance auf Doppelernte."
          };
      default ->
          new String[] {
            "Goldene Einträge: anklickbare Aktionen.",
            "Graue Einträge: Informationen oder gesperrte Aktionen.",
            "Maus über ein Symbol: Wirkung und Kosten lesen.",
            "Unten: Zurück / Hauptmenü / Schließen / Hilfe."
          };
    };
  }

  private void forestUpgrade(
      Screen s,
      Profile p,
      int slot,
      String key,
      String name,
      int level,
      int max,
      Material icon,
      String... effects) {
    List<String> lore = new ArrayList<>();
    long price = Forestry.cost(p, key);
    boolean resin = key.equals("axe") && level >= 5;
    if (level < max) {
      lore.addAll(Arrays.asList(effects));
      lore.add("Kosten: " + price + " $" + (resin ? " + 1 Harz" : ""));
      lore.add(
          p.money < price
              ? "Es fehlen " + (price - p.money) + " $"
              : resin && p.resin < 1 ? "Es fehlt 1 Harz" : "Bereit zum Verbessern");
    } else lore.add("Maximale Stufe erreicht");
    b(
        s,
        slot,
        icon,
        null,
        name + " · " + level + " / " + max,
        level < max && p.money >= price && (!resin || p.resin > 0) ? "forest:" + key : null,
        lore.toArray(String[]::new));
  }

  private void upgrade(
      Screen s,
      Profile p,
      int slot,
      String key,
      String title,
      int level,
      Material base,
      String model) {
    int max =
        switch (key) {
          case "housing", "furnace" -> 5;
          case "warehouse" -> 8;
          default -> 20;
        };
    long cost = Economy.upgradeCost(p, key);
    boolean relic = (key.equals("tool") || key.equals("sword")) && level >= 4;
    String effect =
        switch (key) {
          case "bag" -> p.bagCapacity() + " → " + (p.bagCapacity() + 150) + " Rucksackplätze";
          case "warehouse" ->
              p.stockCapacity() + " → " + (p.stockCapacity() + 960) + " Lagerplätze";
          case "housing" -> p.workerSlots() + " → " + (p.workerSlots() + 1) + " Arbeiterplätze";
          case "furnace" -> "Schmelze freischalten / automatische Verarbeitung verbessern";
          case "tool" -> "Schneller abbauen und härtere Erzvorkommen erschließen";
          case "sword" -> "Grundschaden deiner Nahkampfwaffe erhöhen";
          default -> "Mehr Leben und Schutz im Kampf";
        };
    b(
        s,
        slot,
        base,
        model,
        title + " · Stufe " + level + " / " + max,
        level < max && p.money >= cost && (!relic || p.relics > 0) ? "buy:" + key : null,
        level >= max ? "Maximale Stufe erreicht" : effect,
        level >= max
            ? "Vollständig ausgebaut"
            : "Kosten: " + cost + " $" + (relic ? " + 1 Relikt" : ""),
        level >= max
            ? ""
            : p.money < cost
                ? "Es fehlen " + (cost - p.money) + " $"
                : relic && p.relics < 1 ? "Es fehlt 1 Relikt" : "Bereit zum Verbessern");
  }

  /** Builds real Bukkit inventories without opening a player's screen or mutating a profile. */
  public String verify() {
    Profile p = new Profile();
    p.id = UUID.randomUUID().toString();
    p.name = "Menu diagnostic";
    p.workers.add(new Profile.Worker("Borin", Profile.Job.MINER, 0));
    Set<String> visited = new HashSet<>();
    ArrayDeque<String> pending = new ArrayDeque<>();
    pending.add("main");
    while (!pending.isEmpty()) {
      String page = pending.remove();
      if (!visited.add(page)) continue;
      Screen s = create(null, p, page);
      if (!"open:main".equals(s.actions.get(47))
          || !"close".equals(s.actions.get(49))
          || s.inv.getItem(53) == null)
        throw new IllegalStateException("Navigation missing: " + page);
      for (var e : s.actions.entrySet()) {
        if (s.inv.getItem(e.getKey()) == null)
          throw new IllegalStateException("Empty action: " + page);
        if (e.getValue().startsWith("open:")) pending.add(e.getValue().substring(5));
      }
    }
    if (!visited.containsAll(
        List.of(
            "woodwork",
            "woodupgrades",
            "crew",
            "worker/0",
            "storage",
            "gear",
            "contracts",
            "research",
            "loot/0",
            "character",
            "codex",
            "travel",
            "trade",
            "expeditions"))) throw new IllegalStateException("Unreachable page: " + visited);
    if (create(null, p, "woodwork").actions.containsKey(20))
      throw new IllegalStateException("Empty saw enabled");
    p.money = 1000000;
    p.fuel = 20;
    p.wood[0] = 20;
    if (!"forest:saw:0".equals(create(null, p, "woodwork").actions.get(20)))
      throw new IllegalStateException("Loaded saw disabled");
    if (!"forest:axe".equals(create(null, p, "woodupgrades").actions.get(20)))
      throw new IllegalStateException("Affordable upgrade disabled");
    p.axe = 10;
    if (create(null, p, "woodupgrades").actions.containsKey(20))
      throw new IllegalStateException("Max upgrade enabled");
    return "OK: "
        + visited.size()
        + " reachable menu pages, fixed navigation, empty/ready saw, affordable/max upgrades; no"
        + " player changes";
  }

  private static String fmt(double n) {
    return String.format(java.util.Locale.GERMAN, "%.1f", n);
  }

  private String[] gearLore(Profile p, Gear.Item item) {
    Gear.Item old = Gear.equipped(p, item.slot);
    String compare = GearCompare.diff(item, old);
    return new String[] {
      item.rarity.title + " · " + Gear.slotName(item.slot) + " · Qualität " + item.quality + " %",
      item.dungeonRank > 0
          ? "Dungeon-Beutestufe " + item.dungeonRank + " · Stärke bereits in Werten enthalten"
          : "Ausrüstung aus der Mine",
      "Schaden " + fmt(item.damage * (1 + item.level * .08)),
      "Leben +"
          + fmt(item.health * (1 + item.level * .08))
          + " | Rüstung +"
          + fmt(item.defense * (1 + item.level * .08)),
      "Krit +"
          + fmt(item.crit * 100)
          + " % | Krit-Schaden "
          + (item.slot == Gear.Slot.WEAPON
              ? fmt((Gear.baseCritDamage(item) + item.critDamage) * 100) + " %"
              : "+" + fmt(item.critDamage * 100) + " %")
          + " | Tempo +"
          + fmt(item.haste)
          + " | Haltung +"
          + fmt(item.stagger),
      "Abbau +" + fmt(item.mining * 100) + " % | Extra-Erz +" + fmt(item.yield * 100) + " %",
      "Brennstoff sparen +" + fmt(item.efficiency * 100) + " %",
      Gear.effect(item.signature),
      AdventureGear.lore(item),
      compare == null ? "" : "Gegenüber ausgerüstet:",
      compare == null ? "" : compare,
      p.equipped.containsValue(item.id)
          ? "AUSGERÜSTET"
          : item.favorite ? "FAVORIT" : "Klicken zum Verwalten"
    };
  }

  /** Where a worker works: the mine zone, or the wood type for lumberjacks. */
  static String workplace(Profile p, Profile.Worker w) {
    return w.job == Profile.Job.LUMBERJACK
        ? "Wald · " + Forestry.WOODS[Industry.woodType(p, w)]
        : Zone.at(w.zone).title;
  }

  public static String jobName(Profile.Job job) {
    return switch (job) {
      case MINER -> "Bergarbeiter";
      case SMELTER -> "Schmelzer";
      case TRADER -> "Händler";
      case LUMBERJACK -> "Holzfäller";
    };
  }

  private String title(String page) {
    if (page.startsWith("assignment/")) return "Arbeitsgebiet wählen";
    if (page.startsWith("specialty/")) return "Arbeitsweise wählen";
    if (page.startsWith("loot/")) return "Beutebeutel";
    if (page.startsWith("item/")) return "Gegenstand";
    if (page.startsWith("confirm/")) return "Bestätigung";
    if (page.startsWith("fire/")) return "Arbeiter entlassen";
    return switch (page) {
      case "main" -> "Hauptmenü";
      case "mining" -> "Bergbau";
      case "combat" -> "Kampf & Ausrüstung";
      case "business" -> "Arbeiter & Betrieb";
      case "goals" -> "Aufträge & Abenteuer";
      case "woodwork" -> "Holz verarbeiten";
      case "woodupgrades" -> "Holz-Upgrades";
      case "character" -> "Charakter";
      case "milestones" -> "Meilensteine";
      case "daily" -> "Tagesaufträge";
      case "reward" -> "Dungeon-Beute";
      case "drone" -> "Funke";
      case "top" -> "Rangliste";
      case "codex" -> "Beutebuch";
      case "boss" -> "Bosskampf";
      case "gear" -> "Grund-Upgrades";
      case "forestry" -> "Holzfäller & Sägewerk";
      case "crew" -> "Mannschaft";
      case "factory" -> "Betrieb";
      case "storage" -> "Lager";
      case "smelt" -> "Schmelzen";
      case "travel" -> "Aufzug";
      case "trade" -> "Handel";
      case "research" -> "Forschung";
      case "contracts" -> "Auftragstafel";
      case "expeditions" -> "Erkundung";
      default -> "Arbeiter";
    };
  }

  @EventHandler
  public void click(InventoryClickEvent e) {
    if (!(e.getView().getTopInventory().getHolder() instanceof Screen s)) return;
    e.setCancelled(true);
    if (!(e.getWhoClicked() instanceof Player player)
        || !player.getUniqueId().equals(s.owner)
        || !plugin.playing(player)) return;
    String a = s.actions.get(e.getRawSlot());
    if (a == null || e.getClick() == ClickType.DOUBLE_CLICK) return;
    // A double click also sends a normal click first; never buy or reroll twice by accident.
    long now = System.currentTimeMillis();
    Long last = lastClick.get(player.getUniqueId());
    if (last != null && now - last < 250) return;
    lastClick.put(player.getUniqueId(), now);
    // Inventory changes and teleports are deferred until after the inventory event.
    Bukkit.getScheduler()
        .runTask(
            plugin,
            () -> {
              if (player.isOnline() && plugin.playing(player)) act(player, s, a);
            });
  }

  @EventHandler
  public void closed(InventoryCloseEvent e) {
    if (e.getInventory().getHolder() instanceof Screen) lastClick.remove(e.getPlayer().getUniqueId());
  }

  @EventHandler
  public void drag(InventoryDragEvent e) {
    if (e.getView().getTopInventory().getHolder() instanceof Screen) e.setCancelled(true);
  }

  private void act(Player player, Screen screen, String action) {
    if (action.startsWith("adventure:")) {
      plugin.adventure().open(player, action.substring(10));
      return;
    }
    if (action.equals("heal")) {
      player.closeInventory();
      plugin.healing().use(player);
      return;
    }
    if (action.equals("dungeon")) {
      plugin.dungeons().command(player, new String[] {"dungeon"});
      return;
    }
    if (action.startsWith("open:")) {
      open(player, action.substring(5));
      return;
    }
    if (action.equals("close")) {
      player.closeInventory();
      return;
    }
    if (action.equals("home")) {
      player.closeInventory();
      plugin.goHome(player);
      return;
    }
    if (action.startsWith("mine:")) {
      player.closeInventory();
      plugin.travel(player, Integer.parseInt(action.substring(5)));
      return;
    }
    if (action.startsWith("fight:")) {
      plugin.combat().start(player, Integer.parseInt(action.substring(6)));
      return;
    }
    if (plugin.combat().fighting(player) && !action.startsWith("open:")) {
      plugin.tell(player, "Ausrüstung und Betrieb nach dem Kampf verwalten.");
      return;
    }
    if (action.equals("report")) {
      plugin.report(player);
      return;
    }
    if (action.startsWith("hire:") && !plugin.workersAvailable()) {
      plugin.tell(
          player,
          "Für sichtbare Arbeiter fehlt eine kompatible Citizens-Version. Details in README.");
      return;
    }
    Gear.Item rerolled =
        action.startsWith("reroll:")
            ? Gear.find(plugin.profile(player), action.substring(7))
            : null;
    double critBefore = rerolled == null ? 0 : rerolled.crit;
    long dustBefore = plugin.profile(player).dust;
    String result =
        plugin.change(
        player,
        p -> {
          if (action.startsWith("forest:")) return Forestry.act(p, action.substring(7));
          if (action.startsWith("milestone:"))
            return Milestones.claim(p, action.substring(10));
          if (action.equals("chest:buy")) return LootChests.buy(p);
          if (action.equals("drone:build")) return DroneRules.build(p);
          if (action.equals("drone:up")) return DroneRules.upgrade(p);
          if (action.equals("drone:toggle")) return DroneRules.toggle(p);
          if (action.startsWith("drone:module:"))
            return DroneRules.module(p, Integer.parseInt(action.substring(13)));
          if (action.startsWith("drone:skin:"))
            return DroneRules.skin(p, Integer.parseInt(action.substring(11)));
          if (action.startsWith("daily:"))
            return Dailies.claim(p, Integer.parseInt(action.substring(6)), plugin.today());
          if (action.startsWith("research:"))
            return Industry.research(p, Integer.parseInt(action.substring(9)));
          if (action.startsWith("contract:")) {
            String[] a = action.split(":");
            return Industry.fulfill(p, Integer.parseInt(a[1]), Integer.parseInt(a[2]));
          }
          if (action.startsWith("collect:"))
            return Industry.collection(p, Integer.parseInt(action.substring(8)));
          if (action.startsWith("fire:")) return Economy.dismiss(p, action.substring(5));
          if (action.startsWith("pause:")) {
            int i = Integer.parseInt(action.substring(6));
            if (i >= p.workers.size()) return "Arbeiter fehlt.";
            p.workers.get(i).paused = !p.workers.get(i).paused;
            return p.workers.get(i).paused ? "Schicht pausiert." : "Schicht fortgesetzt.";
          }
          if (action.equals("budget100")) {
            if (p.money < 100) return "Benötigt 100 $.";
            p.money -= 100;
            p.budget += 100;
            return "100 $ im Betriebsbudget.";
          }
          if (action.equals("fuel20")) {
            if (p.money < 20) return "Benötigt 20 $.";
            p.money -= 20;
            p.fuel += 20;
            return "20 Brennstoff gekauft.";
          }
          if (action.startsWith("equip:")) return Gear.equip(p, action.substring(6));
          if (action.startsWith("favorite:")) {
            Gear.Item i = Gear.find(p, action.substring(9));
            if (i == null) return "Nicht gefunden.";
            i.favorite = !i.favorite;
            return "Favoritenschutz aktualisiert.";
          }
          if (action.startsWith("enhance:")) return Gear.upgrade(p, action.substring(8));
          if (action.startsWith("rerollcd:"))
            return Gear.rerollCritDamage(
                p, action.substring(9), java.util.concurrent.ThreadLocalRandom.current());
          if (action.startsWith("reroll:"))
            return Gear.reroll(
                p, action.substring(7), java.util.concurrent.ThreadLocalRandom.current());
          if (action.startsWith("dust:")) return Gear.sell(p, action.substring(5), true);
          if (action.startsWith("sell:")) return Gear.sell(p, action.substring(5), false);
          if (action.startsWith("craft:"))
            return Gear.craft(p, Integer.parseInt(action.substring(6)));
          if (action.startsWith("hunt:"))
            return Gear.claimHunt(p, Integer.parseInt(action.substring(5)));
          if (action.startsWith("buy:")) return Economy.buy(p, action.substring(4));
          if (action.startsWith("module:")) {
            p.module = Integer.parseInt(action.substring(7));
            return "Modul gewechselt.";
          }
          if (action.startsWith("hire:"))
            return Economy.hire(p, Profile.Job.valueOf(action.substring(5)));
          if (action.equals("sell")) return "+" + Economy.sell(p) + " $ durch Verkauf.";
          if (action.equals("sellbars")) {
            long[] kept = new long[1];
            long money = Economy.sellBars(p, kept);
            return money == 0
                ? "Keine Barren zum Verkaufen" + (kept[0] > 0 ? " (" + kept[0] + " für Forschung/Aufträge reserviert)." : ".")
                : "+" + money + " $ durch Barrenverkauf. Erze behalten"
                    + (kept[0] > 0 ? ", " + kept[0] + " Barren für Forschung/Aufträge reserviert." : ".");
          }
          if (action.equals("sellore"))
            return "+" + Economy.sell(p, false) + " $ durch Erzverkauf. Barren behalten.";
          if (action.equals("deposit")) return Economy.deposit(p) + " Erze eingelagert.";
          if (action.equals("order")) return Economy.order(p);
          if (action.equals("quest")) return Economy.quest(p);
          if (action.equals("unlock")) return Economy.nextZone(p);
          if (action.equals("fuel")) {
            if (p.money < 120) return "Benötigt 120 $.";
            p.money -= 120;
            p.fuel += 120;
            return "120 Brennstoff gekauft.";
          }
          if (action.equals("budget")) {
            if (p.money < 1000) return "Benötigt 1.000 $.";
            p.money -= 1000;
            p.budget += 1000;
            return "1.000 $ Betriebsbudget bereitgestellt.";
          }
          if (action.startsWith("smelt:")) {
            String[] parts = action.split(":");
            return Industry.smelt(
                p,
                Integer.parseInt(parts[1]),
                parts[2].equals("all") ? Long.MAX_VALUE : Long.parseLong(parts[2]),
                Math::random);
          }
          if (action.equals("collection")) {
            if (p.collectionClaimed[p.zone]) return "Sammlungsbelohnung bereits abgeholt.";
            if (p.collected[p.zone] < 500) return "Sammle selbst 500 Erze dieses Gebiets.";
            p.collectionClaimed[p.zone] = true;
            p.relics += 3;
            return "Sammlung vollständig: +3 Relikte!";
          }
          if (action.startsWith("train:")
              || action.startsWith("assign:")
              || action.startsWith("spec:")) {
            String[] parts = action.split(":");
            int index = Integer.parseInt(parts[1]);
            if (index >= p.workers.size()) return "Arbeiter nicht gefunden.";
            Profile.Worker w = p.workers.get(index);
            if (parts[0].equals("assign")) {
              int chosen = Integer.parseInt(parts[2]);
              if (w.job == Profile.Job.LUMBERJACK) {
                if (chosen < 0 || chosen > p.forestTier || chosen >= Forestry.WOODS.length)
                  return "Diese Holzart ist noch nicht freigeschaltet.";
                w.zone = chosen;
                return w.name + " fällt jetzt " + Forestry.WOODS[chosen] + ".";
              }
              if (chosen < 0 || chosen > p.zone) return "Gebiet noch nicht freigeschaltet.";
              w.zone = chosen;
              return "Arbeiter neu zugewiesen.";
            }
            if (parts[0].equals("spec")) {
              if (w.level < 2) return "Spezialisierung ab Stufe 2.";
              int chosen = Integer.parseInt(parts[2]);
              if (chosen < 0 || chosen > 2) return "Unbekannte Spezialisierung.";
              w.specialization = chosen;
              return "Spezialisierung geändert.";
            }
            if (w.level >= 5) return "Maximale Arbeiterstufe erreicht.";
            long cost = 1000L * w.level * w.level;
            if (p.money < cost || w.workMinutes < w.level * 30L)
              return "Noch nicht genug Geld oder Arbeitserfahrung.";
            p.money -= cost;
            w.level++;
            return "Arbeiter ausgebildet.";
          }
          return "Unbekannte Aktion.";
        });
    if (!plugin.isEnabled()) return;
    plugin.items().refresh(player, plugin.profile(player));
    if (action.startsWith("hire:")
        || action.startsWith("train:")
        || action.startsWith("assign:")
        || action.startsWith("fire:")) plugin.refreshWorkers(player);
    if (action.startsWith("buy:") || action.startsWith("hire:"))
      plugin.mines().decorate(plugin.profile(player));
    plugin.combat().applyStats(player);
    if (rerolled != null && plugin.profile(player).dust < dustBefore)
      showReroll(player, rerolled, critBefore);
    else if (action.equals("chest:buy") && result != null && result.startsWith("Gewölbekiste geöffnet")) {
      Profile after = plugin.profile(player);
      Gear.Item opened = after.gear.getLast();
      player.showTitle(
          net.kyori.adventure.title.Title.title(
              Component.text("KISTE GEÖFFNET", NamedTextColor.GOLD),
              Component.text(opened.rarity.title + " · " + Gear.slotName(opened.slot), NamedTextColor.YELLOW)));
      player.playSound(player.getLocation(), Sound.BLOCK_CHEST_OPEN, 1, 1);
      player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, .6f, 1.4f);
    } else if (failed(result)) {
      // Requirements are otherwise only in chat, where they are easy to miss behind the menu.
      player.showTitle(
          net.kyori.adventure.title.Title.title(
              Component.text("NICHT MÖGLICH", NamedTextColor.RED),
              Component.text(result, NamedTextColor.GOLD),
              net.kyori.adventure.title.Title.Times.times(
                  java.time.Duration.ofMillis(100),
                  java.time.Duration.ofMillis(2600),
                  java.time.Duration.ofMillis(400))));
      player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, .8f, 1);
    } else if (result != null && action.startsWith("research:"))
      player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, .8f, 1.2f);
    open(
        player,
        action.startsWith("dust:") || action.startsWith("sell:")
            ? "loot/0"
            : action.startsWith("fire:") ? "crew" : screen.page);
  }

  static boolean failed(String message) {
    if (message == null) return false;
    for (String start :
        List.of(
            "Benötigt",
            "Es fehlen",
            "Es fehlt",
            "Zu wenig",
            "Kein ",
            "Keine ",
            "Baue zuerst",
            "Besiege zuerst",
            "Dieses Gebiet",
            "Gebiet gesperrt",
            "Gebiet noch",
            "Nicht gefunden",
            "Gegenstand nicht gefunden",
            "Maximale",
            "Unbekannt",
            "Arbeiter nicht gefunden",
            "Arbeiter fehlt",
            "Beutebeutel voll",
            "Favorisierte",
            "Forschung abgeschlossen",
            "Sammle selbst",
            "Sammlungsbelohnung bereits",
            "Gewölbekisten gibt es",
            "Für diesen Lauf",
            "Die Kiste kostet"))
      if (message.startsWith(start)) return true;
    return false;
  }

  private void showReroll(Player player, Gear.Item item, double before) {
    double after = item.crit;
    boolean better = after > before;
    Profile profile = plugin.profile(player);
    boolean equipped = profile.equipped.containsValue(item.id);
    player.showTitle(
        net.kyori.adventure.title.Title.title(
            Component.text(
                better ? "KRIT VERBESSERT" : "KRIT NEU GESCHMIEDET",
                better ? NamedTextColor.GREEN : NamedTextColor.RED),
            Component.text(
                String.format(
                    Locale.GERMAN,
                    "%.1f %% → %.1f %%  (%+.1f)  ·  %s",
                    before * 100,
                    after * 100,
                    (after - before) * 100,
                    equipped
                        ? String.format(
                            Locale.GERMAN,
                            "Gesamt-Krit %.1f %%",
                            Gear.stats(profile).crit() * 100)
                        : "wirkt erst ausgerüstet"),
                NamedTextColor.GOLD),
            net.kyori.adventure.title.Title.Times.times(
                java.time.Duration.ofMillis(150),
                java.time.Duration.ofMillis(2000),
                java.time.Duration.ofMillis(400))));
    player.playSound(
        player.getLocation(),
        better ? Sound.BLOCK_ANVIL_USE : Sound.BLOCK_ANVIL_LAND,
        .8f,
        better ? 1.4f : .7f);
    player
        .getWorld()
        .spawnParticle(
            better ? Particle.HAPPY_VILLAGER : Particle.SMOKE,
            player.getLocation().add(0, 1.2, 0),
            12,
            .4,
            .4,
            .4,
            0);
  }
}
