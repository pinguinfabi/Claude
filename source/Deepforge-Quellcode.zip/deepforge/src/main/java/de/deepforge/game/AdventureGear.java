package de.deepforge.game;

import java.util.*;
import java.util.random.RandomGenerator;

public final class AdventureGear {
  private AdventureGear() {}

  public static final String[] NAMES = {"Donnerklinge", "Blutstahl", "Runenhammer", "Aderbohrer"};
  public static final String[] SETS = {"Sturmrufer", "Blutwächter", "Tiefenschürfer"};
  public static final String[] EFFECTS = {
    "8 Treffer laden einen Blitz auf bis zu 3 nahe Gegner (2 s Pause).",
    "Besiegte Gegner lassen eine persönliche Heilkugel fallen (4 LP).",
    "6 Treffer brechen den Panzer für 4 Sekunden (6 s Pause).",
    "Zusammenhängende Erzadern: 25% Chance auf ein zusätzliches Erz."
  };

  public static int setCount(Profile p, int set) {
    return (int)
        p.gear.stream()
            .filter(i -> i.adventureSet == set && p.equipped.containsValue(i.id))
            .count();
  }

  public static boolean has(Profile p, int archetype) {
    return p.gear.stream()
        .anyMatch(i -> i.archetype == archetype && p.equipped.containsValue(i.id));
  }

  public static Gear.Item artifact(int type, int zone, RandomGenerator r) {
    Gear.Item i = Gear.roll(zone, Gear.Rarity.LEGENDARY, r);
    i.archetype = type;
    i.signature = -1;
    i.adventureSet = -1;
    i.name = NAMES[type];
    i.slot = type == 3 ? Gear.Slot.TOOL : Gear.Slot.WEAPON;
    i.style = type == 2 ? "hammer" : "sword";
    i.damage = type == 3 ? 0 : (type == 2 ? 7 : 5) * (1 + zone * .5);
    i.stagger = type == 2 ? 18 : 5;
    if (type == 3) {
      i.mining = .15;
      i.yield = .12;
    }
    return i;
  }

  public static Gear.Item drop(int zone, RandomGenerator r, double artifactChance) {
    if (r.nextDouble() < artifactChance) return artifact(zone % 4, zone, r);
    Gear.Item i = Gear.roll(zone, Gear.Rarity.RARE, r);
    i.slot =
        new Gear.Slot[] {Gear.Slot.HELMET, Gear.Slot.CHEST, Gear.Slot.LEGS, Gear.Slot.BOOTS}
            [r.nextInt(4)];
    i.damage = 0;
    i.adventureSet = r.nextInt(3);
    i.name = SETS[i.adventureSet] + " · " + Gear.slotName(i.slot);
    i.defense += 3 + zone;
    i.health += 1 + zone * .3;
    return i;
  }

  public static void grant(Profile p, Gear.Item item) {
    if (item.archetype >= 0) p.artifactCollection.add(item.archetype);
    if (item.adventureSet >= 0)
      p.discovered.add("set/" + item.adventureSet + "/" + item.slot.name());
    if (p.gear.size() < 120) p.gear.add(item);
    else p.dust += 40;
  }

  public static String craft(Profile p, int type) {
    if (type < 0 || type > 3 || p.zone < type)
      return "Dieses Rezept gehört zu Gebiet " + (type + 1) + ".";
    if (!p.bosses[type] && p.dungeonWins[type * 3] == 0)
      return "Bauplan: zuerst den Boss oder Dungeon in diesem Gebiet besiegen.";
    long cost = 2000L * (type + 1);
    if (p.bossTokens[type] < 40 || p.monsterParts[type] < 30 || p.money < cost)
      return "Benötigt 40 Gebiets-Bossfragmente, 30 Monsterteile und " + cost + " $.";
    if (p.gear.size() >= 120) return "Beutebeutel voll. Vor dem Herstellen Platz schaffen.";
    p.bossTokens[type] -= 40;
    p.monsterParts[type] -= 30;
    p.money -= cost;
    grant(p, artifact(type, type, java.util.concurrent.ThreadLocalRandom.current()));
    return "Hergestellt: " + NAMES[type];
  }

  public static String lore(Gear.Item i) {
    return i.archetype >= 0
        ? EFFECTS[i.archetype]
        : i.adventureSet >= 0 ? "Set " + SETS[i.adventureSet] + " · Boni ab 2 und 4 Teilen" : "";
  }
}
