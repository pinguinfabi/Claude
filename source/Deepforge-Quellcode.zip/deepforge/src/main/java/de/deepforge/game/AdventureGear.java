package de.deepforge.game;

import java.util.*;
import java.util.random.RandomGenerator;

public final class AdventureGear {
  private AdventureGear() {}

  public static final String[] NAMES = {"Donnerklinge", "Blutstahl", "Runenhammer", "Aderbohrer"};
  public static final String[] SETS = {"Sturmrufer", "Blutwächter", "Tiefenschürfer"};
  public static final String[] SET_TWO = {
    "2 Teile: Blitz nach 6 statt 8 Treffern",
    "2 Teile: Blutstahl-Kugeln heilen +2 LP",
    "2 Teile: +10% Extra-Erz"
  };
  public static final String[] SET_FOUR = {
    "4 Teile: +25% Blitzschaden",
    "4 Teile: Heilkugeln auch ohne Blutstahl",
    "4 Teile: +15% Abbaubonus"
  };
  public static final String[] EFFECTS = {
    "8 Treffer laden einen Blitz auf bis zu 3 nahe Gegner (2 s Pause).",
    "Besiegte Gegner lassen eine persönliche Heilkugel fallen (4 LP).",
    "6 Treffer brechen den Panzer für 4 Sekunden (6 s Pause).",
    "Zusammenhängende Erzadern: 25% Chance auf ein zusätzliches Erz."
  };

  public static int setCount(Profile p, int set) {
    return (int)
        p.gear.stream()
            .filter(i -> i.adventureSet == set && p.equipped.containsValue(i.id))
            .count();
  }

  public static boolean has(Profile p, int archetype) {
    return p.gear.stream()
        .anyMatch(i -> i.archetype == archetype && p.equipped.containsValue(i.id));
  }

  public static Gear.Item artifact(int type, int zone, RandomGenerator r) {
    Gear.Item i = Gear.roll(zone, Gear.Rarity.LEGENDARY, r);
    i.archetype = type;
    i.signature = -1;
    i.adventureSet = -1;
    i.name = NAMES[type];
    i.slot = type == 3 ? Gear.Slot.TOOL : Gear.Slot.WEAPON;
    i.style = type == 2 ? "hammer" : "sword";
    i.damage = type == 3 ? 0 : (type == 2 ? 7 : 5) * (1 + zone * .5);
    i.stagger = type == 2 ? 18 : 5;
    if (type == 3) {
      i.mining = .15;
      i.yield = .12;
    }
    return i;
  }

  public static Gear.Item drop(int zone, RandomGenerator r, double artifactChance) {
    if (r.nextDouble() < artifactChance) return artifact(zone % 4, zone, r);
    Gear.Item i = Gear.roll(zone, Gear.Rarity.RARE, r);
    Gear.Slot slot = SET_SLOTS[r.nextInt(4)];
    return shapeSetPiece(i, r.nextInt(3), slot, zone);
  }

  public static final Gear.Slot[] SET_SLOTS = {
    Gear.Slot.HELMET, Gear.Slot.CHEST, Gear.Slot.LEGS, Gear.Slot.BOOTS
  };

  private static Gear.Item shapeSetPiece(Gear.Item i, int set, Gear.Slot slot, int zone) {
    i.slot = slot;
    i.damage = 0;
    i.critDamage = 0;
    i.stagger = 0;
    if (i.defense == 0) {
      // A weapon or tool roll carries no armour values yet.
      double power = (1 + zone * .5) * i.rarity.factor * i.quality / 100.;
      i.defense = power * 3;
      i.health = power * .65;
      i.mining = 0;
      i.yield = 0;
    }
    i.adventureSet = set;
    i.name = SETS[set] + " · " + Gear.slotName(slot);
    i.defense += 3 + zone;
    i.health += 1 + zone * .3;
    return i;
  }

  // ---- Set-Schmiede: two duplicate set pieces become one piece of your choice ----

  public static final long REFORGE_DUST = 40;

  public static long reforgeMoney(int zone) {
    return 1500L * (zone + 1);
  }

  private static double power(Gear.Item i) {
    return i.defense + i.health * 3;
  }

  /**
   * Set pieces you can give up: for every set and slot the equipped copy (or else the strongest
   * one) stays, every further unequipped, non-favourite copy is spare. Weakest first.
   */
  public static List<Gear.Item> spares(Profile p) {
    Map<String, List<Gear.Item>> groups = new HashMap<>();
    for (Gear.Item i : p.gear)
      if (i.adventureSet >= 0 && i.archetype < 0)
        groups.computeIfAbsent(i.adventureSet + "/" + i.slot, k -> new ArrayList<>()).add(i);
    List<Gear.Item> out = new ArrayList<>();
    for (List<Gear.Item> copies : groups.values()) {
      if (copies.size() < 2) continue;
      Gear.Item keep =
          copies.stream()
              .filter(i -> p.equipped.containsValue(i.id))
              .findFirst()
              .orElse(copies.stream().max(Comparator.comparingDouble(AdventureGear::power)).get());
      for (Gear.Item i : copies)
        if (i != keep && !i.favorite && !p.equipped.containsValue(i.id)) out.add(i);
    }
    out.sort(Comparator.comparingDouble(AdventureGear::power));
    return out;
  }

  public static int owned(Profile p, int set, Gear.Slot slot) {
    return (int)
        p.gear.stream()
            .filter(i -> i.adventureSet == set && i.archetype < 0 && i.slot == slot)
            .count();
  }

  public static String reforge(Profile p, int set, Gear.Slot slot, RandomGenerator r) {
    if (set < 0 || set >= SETS.length || !Arrays.asList(SET_SLOTS).contains(slot))
      return "Unbekanntes Set-Teil.";
    List<Gear.Item> spare = spares(p);
    if (spare.size() < 2)
      return "Die Set-Schmiede braucht 2 doppelte Set-Teile (gleiches Set, gleicher Platz). Du hast "
          + spare.size()
          + ".";
    Gear.Item a = spare.get(0), b = spare.get(1);
    int zone = Math.max(a.zone, b.zone);
    int rank = Math.max(a.dungeonRank, b.dungeonRank);
    long money = reforgeMoney(zone);
    if (p.dust < REFORGE_DUST || p.money < money)
      return "Die Set-Schmiede kostet "
          + REFORGE_DUST
          + " Schmiedestaub und "
          + money
          + " $ (plus 2 doppelte Teile).";
    p.dust -= REFORGE_DUST;
    p.money -= money;
    p.gear.remove(a);
    p.gear.remove(b);
    p.seenGear.remove(a.id);
    p.seenGear.remove(b.id);
    Gear.Item piece = shapeSetPiece(Gear.roll(zone, Gear.Rarity.RARE, r), set, slot, zone);
    if (rank > 0) {
      piece.dungeonRank = rank;
      double growth = 1 + .075 * (rank - 1);
      piece.health *= growth;
      piece.defense *= growth;
      piece.name = "Gewölbe L" + rank + ": " + piece.name;
    }
    grant(p, piece);
    return "Set-Schmiede: "
        + piece.name
        + " geschmiedet – eingeschmolzen: "
        + a.name
        + " und "
        + b.name
        + ".";
  }

  public static void grant(Profile p, Gear.Item item) {
    if (item.archetype >= 0) p.artifactCollection.add(item.archetype);
    if (item.adventureSet >= 0)
      p.discovered.add("set/" + item.adventureSet + "/" + item.slot.name());
    if (p.gear.size() < 120) p.gear.add(item);
    else p.dust += 40;
  }

  public static String craft(Profile p, int type) {
    if (type < 0 || type > 3 || p.zone < type)
      return "Dieses Rezept gehört zu Gebiet " + (type + 1) + ".";
    if (!p.bosses[type] && p.dungeonWins[type * 3] == 0)
      return "Bauplan: zuerst den Boss oder Dungeon in diesem Gebiet besiegen.";
    long cost = 2000L * (type + 1);
    if (p.bossTokens[type] < 40 || p.monsterParts[type] < 30 || p.money < cost)
      return "Benötigt 40 Gebiets-Bossfragmente, 30 Monsterteile und " + cost + " $.";
    if (p.gear.size() >= 120) return "Beutebeutel voll. Vor dem Herstellen Platz schaffen.";
    p.bossTokens[type] -= 40;
    p.monsterParts[type] -= 30;
    p.money -= cost;
    grant(p, artifact(type, type, java.util.concurrent.ThreadLocalRandom.current()));
    return "Hergestellt: " + NAMES[type];
  }

  public static String lore(Gear.Item i) {
    return i.archetype >= 0
        ? EFFECTS[i.archetype]
        : i.adventureSet >= 0 ? "Set " + SETS[i.adventureSet] + " · Boni ab 2 und 4 Teilen" : "";
  }
}
