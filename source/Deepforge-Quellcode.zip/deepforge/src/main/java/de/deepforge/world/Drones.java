package de.deepforge.world;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.*;
import java.util.*;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/** The steam drone "Funke": follows its owner, collects ore, shoots, heals and warns. */
public final class Drones implements AutoCloseable {
  private final DeepforgePlugin plugin;
  private final NamespacedKey key;
  private final Map<UUID, ItemDisplay> displays = new HashMap<>();
  private final Map<UUID, String> shownModel = new HashMap<>();
  private final Map<UUID, Long> nextAction = new HashMap<>(), nextWarn = new HashMap<>(), nextPing = new HashMap<>();
  private final BukkitTask task;
  private long tick;

  public Drones(DeepforgePlugin plugin) {
    this.plugin = plugin;
    key = new NamespacedKey(plugin, "drone");
    for (Entity e : plugin.mines().world().getEntities())
      if (e.getPersistentDataContainer().has(key)) e.remove();
    task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20, 2);
  }

  private void tick() {
    tick += 2;
    Set<UUID> active = new HashSet<>();
    for (Player player : Bukkit.getOnlinePlayers()) {
      if (!plugin.playing(player) || player.isDead()) continue;
      Profile p = plugin.profile(player);
      if (p.droneLevel <= 0 || p.droneHidden) continue;
      active.add(player.getUniqueId());
      ItemDisplay drone = display(player, p);
      follow(player, drone);
      if (tick % 10 == 0) behave(player, p, drone);
    }
    for (UUID id : new ArrayList<>(displays.keySet())) if (!active.contains(id)) remove(id);
  }

  private ItemStack item(Player player, Profile p) {
    return plugin
        .items()
        .forViewer(plugin.items().model(Material.LANTERN, "drone_" + p.droneSkin, "Funke"), player);
  }

  private ItemDisplay display(Player player, Profile p) {
    UUID id = player.getUniqueId();
    ItemDisplay d = displays.get(id);
    String model = p.droneSkin + ":" + plugin.packApplied(player);
    if (d != null && d.isValid() && d.getWorld().equals(player.getWorld())) {
      if (!model.equals(shownModel.get(id))) {
        d.setItemStack(item(player, p));
        shownModel.put(id, model);
      }
      return d;
    }
    remove(id);
    d =
        player
            .getWorld()
            .spawn(
                spot(player),
                ItemDisplay.class,
                e -> {
                  e.setItemStack(item(player, p));
                  e.setPersistent(false);
                  e.setVisibleByDefault(false);
                  e.setBrightness(new Display.Brightness(15, 15));
                  e.setTeleportDuration(3);
                  e.setTransformation(
                      new Transformation(
                          new Vector3f(), new Quaternionf(), new Vector3f(.55f), new Quaternionf()));
                  e.getPersistentDataContainer().set(key, PersistentDataType.STRING, id.toString());
                });
    player.showEntity(plugin, d);
    displays.put(id, d);
    shownModel.put(id, model);
    return d;
  }

  /** Over the right shoulder, slightly behind, gently bobbing. */
  private Location spot(Player player) {
    Location eye = player.getEyeLocation();
    double yaw = Math.toRadians(eye.getYaw());
    Vector forward = new Vector(-Math.sin(yaw), 0, Math.cos(yaw));
    Vector right = new Vector(-Math.cos(yaw), 0, -Math.sin(yaw));
    Location at =
        eye.clone()
            .add(right.multiply(.85))
            .add(forward.multiply(-.55))
            .add(0, .3 + Math.sin(tick / 9.0) * .08, 0);
    at.setYaw(eye.getYaw());
    at.setPitch(0);
    return at;
  }

  private void follow(Player player, ItemDisplay drone) {
    Location to = spot(player);
    if (drone.getLocation().distanceSquared(to) > 100) drone.setTeleportDuration(0);
    else drone.setTeleportDuration(3);
    drone.teleport(to);
  }

  private boolean due(UUID id, long ticks) {
    long now = tick;
    if (nextAction.getOrDefault(id, 0L) > now) return false;
    nextAction.put(id, now + ticks);
    return true;
  }

  private void behave(Player player, Profile p, ItemDisplay drone) {
    UUID id = player.getUniqueId();
    Location from = drone.getLocation();
    switch (p.droneModule) {
      case 0 -> {
        int zone = plugin.mines().zoneAt(p, player.getLocation());
        if (zone < 0 || plugin.dungeons().active(player)) break;
        if (!due(id, DroneRules.collectorSeconds(p.droneLevel) * 20L)) break;
        long free = p.bagCapacity() - p.bagUsed();
        long found = Math.min(free, DroneRules.collectorOre(p.droneLevel));
        if (found <= 0) break;
        p.bag[zone] += found;
        p.droneOre += found;
        if (!plugin.commit(player, p)) break;
        from.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, from, 6, .2, .2, .2, 0);
        player.playSound(from, Sound.BLOCK_AMETHYST_BLOCK_CHIME, .5f, 1.6f);
        plugin.notice(
            player, "Funke hat +" + found + " " + Zone.at(zone).oreName + " gefunden", NamedTextColor.GREEN);
      }
      case 1 -> {
        if (nextAction.getOrDefault(id, 0L) > tick) break;
        double damage =
            RapidCombat.damage(Gear.stats(p)) * DroneRules.turretShare(p.droneLevel);
        Location target =
            plugin.dungeons().active(player)
                ? plugin.dungeons().droneShot(player, damage)
                : plugin.combat().droneShot(player, damage);
        if (target == null) break;
        nextAction.put(id, tick + DroneRules.turretTicks(p.droneLevel));
        p.droneShots++;
        Vector step = target.toVector().subtract(from.toVector());
        double length = step.length();
        step.normalize().multiply(.5);
        Location l = from.clone();
        for (double d = 0; d < length; d += .5) {
          l.add(step);
          l.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, l, 1, 0, 0, 0, 0);
        }
        player.playSound(from, Sound.BLOCK_PISTON_EXTEND, .35f, 1.9f);
      }
      default -> {
        double max = Gear.stats(p).health();
        if (player.getHealth() >= max * .7) break;
        if (!due(id, DroneRules.medicSeconds(p.droneLevel) * 20L)) break;
        player.setHealth(Math.min(max, player.getHealth() + DroneRules.medicHeal(p.droneLevel)));
        p.droneHealed++;
        player.getWorld().spawnParticle(Particle.HEART, player.getLocation().add(0, 2, 0), 3, .3, .2, .3, 0);
        player.playSound(from, Sound.BLOCK_BREWING_STAND_BREW, .5f, 1.6f);
      }
    }
    // Rich vein on this level: a ping and a short trail pointing at it.
    Location vein = plugin.gameplay().veinTarget(player);
    if (vein != null && nextPing.getOrDefault(id, 0L) <= tick) {
      nextPing.put(id, tick + 100);
      Vector dir = vein.toVector().subtract(from.toVector()).normalize().multiply(.4);
      Location l = from.clone();
      for (int i = 0; i < 8; i++) {
        l.add(dir);
        l.getWorld().spawnParticle(Particle.WAX_ON, l, 1, 0, 0, 0, 0);
      }
      player.playSound(from, Sound.BLOCK_NOTE_BLOCK_BIT, .6f, 1.8f);
    }
  }

  /** A boss attack is about to land where the player stands. */
  public void danger(Player player, String attack) {
    Profile p = plugin.profile(player);
    ItemDisplay drone = displays.get(player.getUniqueId());
    if (p.droneLevel <= 0 || drone == null) return;
    if (nextWarn.getOrDefault(player.getUniqueId(), 0L) > tick) return;
    nextWarn.put(player.getUniqueId(), tick + 20);
    player.playSound(drone.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1, 2);
    drone
        .getWorld()
        .spawnParticle(
            Particle.DUST, drone.getLocation(), 8, .2, .2, .2, 0, new Particle.DustOptions(Color.RED, 1.2f));
    plugin.notice(player, "⚠ Funke: Ausweichen – " + attack + "!", NamedTextColor.RED);
  }

  public boolean has(Player player) {
    return displays.containsKey(player.getUniqueId());
  }

  public void remove(Player player) {
    remove(player.getUniqueId());
  }

  private void remove(UUID id) {
    ItemDisplay d = displays.remove(id);
    shownModel.remove(id);
    if (d != null) d.remove();
  }

  @Override
  public void close() {
    task.cancel();
    for (UUID id : new ArrayList<>(displays.keySet())) remove(id);
  }
}
