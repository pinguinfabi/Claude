package de.deepforge.world;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import de.deepforge.DeepforgePlugin;
import de.deepforge.game.Profile;
import de.deepforge.game.RoomAnchor;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Bisected;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Bed;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

/**
 * 0.23.0 build mode for admins: creative mode in the Deepforge world, and every change is kept.
 *
 * <p>Village, forest and mines are rebuilt from blueprints (updates, migrations), dungeon rooms
 * are generated fresh for every run. So changes are stored as an overlay and put back on top:
 *
 * <ul>
 *   <li>World: block positions relative to the plot origin, applied after every camp, mine or
 *       forest build of every plot.
 *   <li>Dungeons: per room type (dungeon kind × room shape × role), anchored to the room centre or
 *       the nearest wall ({@link RoomAnchor}), applied to every generated room of that type.
 * </ul>
 */
public final class BuildMode implements Listener {
  private static final NamespacedKey RETURN = new NamespacedKey("deepforge", "build_return");
  private static final int HISTORY = 2000, SELECTION_LIMIT = 250_000, APPLY_PER_TICK = 4000;

  private final DeepforgePlugin plugin;
  private final File file;
  private final Gson gson = new Gson();
  private final Set<UUID> builders = new HashSet<>();
  /** "x,y,z" relative to the plot origin → block data. */
  private final Map<String, String> world = new LinkedHashMap<>();
  /** Room type → anchor → block data. */
  private final Map<String, Map<String, String>> rooms = new TreeMap<>();
  private final Map<UUID, Deque<Change>> history = new HashMap<>();
  private final Map<UUID, Location[]> selection = new HashMap<>();
  private final Map<UUID, Long> warned = new HashMap<>();
  private boolean dirty;

  /** One recorded block: overlay entry and world block before the change, for undo. */
  private record Change(String room, String key, String overlayBefore, Location at, String blockBefore) {}

  /** Where a dungeon position belongs: room type, anchor and the room's index in its run. */
  public record RoomRef(String type, String anchor, int index, String title) {}

  public BuildMode(DeepforgePlugin plugin) {
    this.plugin = plugin;
    file = new File(plugin.getDataFolder(), "bauplan.json");
    load();
    Bukkit.getPluginManager().registerEvents(this, plugin);
    Bukkit.getScheduler().runTaskTimer(plugin, () -> {
      if (dirty) save();
    }, 200, 200);
  }

  // ---- state ----

  public boolean active(Player p) {
    return p != null && builders.contains(p.getUniqueId());
  }

  public int worldSize() {
    return world.size();
  }

  public Map<String, Integer> roomSizes() {
    Map<String, Integer> out = new TreeMap<>();
    rooms.forEach((k, v) -> out.put(k, v.size()));
    return out;
  }

  public String toggle(Player p) {
    if (active(p)) {
      leave(p);
      return "Bau-Modus aus. Alle Änderungen sind gespeichert (" + world.size() + " Welt-Blöcke, "
          + rooms.values().stream().mapToInt(Map::size).sum() + " Dungeon-Blöcke).";
    }
    if (plugin.admin() != null && plugin.admin().inMode(p)) return "Zuerst den Admin-Modus beenden (/df admin mode).";
    if (plugin.dungeons().active(p)) return "Nicht während eines eigenen Dungeon-Laufs – nutze /df admin bau dungeon.";
    if (!p.getPersistentDataContainer().has(RETURN, PersistentDataType.STRING))
      p.getPersistentDataContainer().set(RETURN, PersistentDataType.STRING, p.getGameMode().name());
    builders.add(p.getUniqueId());
    p.setGameMode(GameMode.CREATIVE);
    p.setAllowFlight(true);
    return "Bau-Modus AN (Kreativ). Alles, was du baust oder abbaust, wird gespeichert und nach"
        + " Umbauten und in neuen Dungeons wieder eingesetzt. Befehle: /df admin bau hilfe";
  }

  private void leave(Player p) {
    builders.remove(p.getUniqueId());
    String mode = p.getPersistentDataContainer().get(RETURN, PersistentDataType.STRING);
    p.getPersistentDataContainer().remove(RETURN);
    GameMode back = GameMode.ADVENTURE;
    try {
      if (mode != null) back = GameMode.valueOf(mode);
    } catch (IllegalArgumentException ignored) {
      // keep adventure
    }
    p.setGameMode(back == GameMode.CREATIVE || back == GameMode.SPECTATOR ? GameMode.ADVENTURE : back);
    // Creative blocks never leave the build mode; the Deepforge tools come back.
    for (int slot = 0; slot < p.getInventory().getSize(); slot++) {
      ItemStack item = p.getInventory().getItem(slot);
      if (item != null && plugin.items().kind(item).isEmpty()) p.getInventory().setItem(slot, null);
    }
    if (plugin.playing(p)) plugin.items().refresh(p, plugin.profile(p));
    save();
  }

  public void close() {
    for (UUID id : new ArrayList<>(builders)) {
      Player p = Bukkit.getPlayer(id);
      if (p != null) leave(p);
    }
    save();
  }

  @EventHandler
  public void join(PlayerJoinEvent e) {
    // A crash in build mode must not leave anyone in creative mode.
    Player p = e.getPlayer();
    if (p.getPersistentDataContainer().has(RETURN, PersistentDataType.STRING)) {
      builders.add(p.getUniqueId());
      leave(p);
    }
  }

  @EventHandler
  public void quit(PlayerQuitEvent e) {
    if (active(e.getPlayer())) leave(e.getPlayer());
  }

  // ---- recording ----

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void place(BlockPlaceEvent e) {
    // The block is already placed here; what was there before comes from the replaced state.
    if (active(e.getPlayer()))
      record(e.getPlayer(), e.getBlock(), e.getBlockReplacedState().getBlockData().getAsString());
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void breaks(BlockBreakEvent e) {
    if (active(e.getPlayer())) record(e.getPlayer(), e.getBlock(), null);
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void bucket(PlayerBucketEmptyEvent e) {
    if (active(e.getPlayer())) record(e.getPlayer(), e.getBlock(), null);
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void fill(PlayerBucketFillEvent e) {
    if (active(e.getPlayer())) record(e.getPlayer(), e.getBlock(), null);
  }

  /**
   * Snapshots the block and everything that may change with it (door/bed halves, torches and
   * plants on neighbours), and one tick later stores what really changed.
   */
  private void record(Player p, Block block, String replaced) {
    Map<Block, String> before = new LinkedHashMap<>();
    before.put(block, replaced != null ? replaced : block.getBlockData().getAsString());
    for (BlockFace f : new BlockFace[] {BlockFace.UP, BlockFace.DOWN, BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST}) {
      Block n = block.getRelative(f);
      before.putIfAbsent(n, n.getBlockData().getAsString());
    }
    Bukkit.getScheduler().runTask(plugin, () -> {
      Set<Block> changed = new LinkedHashSet<>();
      changed.add(block);
      BlockData now = block.getBlockData();
      if (now instanceof Bisected) {
        changed.add(block.getRelative(BlockFace.UP));
        changed.add(block.getRelative(BlockFace.DOWN));
      }
      if (now instanceof Bed bed)
        changed.add(block.getRelative(bed.getPart() == Bed.Part.HEAD ? bed.getFacing().getOppositeFace() : bed.getFacing()));
      before.forEach((b, data) -> {
        if (!b.getBlockData().getAsString().equals(data)) changed.add(b);
      });
      for (Block b : changed) store(p, b, before.getOrDefault(b, b.getBlockData().getAsString()), true);
    });
  }

  /** Puts the block's current state into the overlay it belongs to; false when it has none. */
  private boolean store(Player p, Block b, String blockBefore, boolean tell) {
    String data = b.getBlockData().getAsString();
    RoomRef room = plugin.dungeons().roomAt(b.getLocation());
    String scope, key;
    if (room != null) {
      scope = room.type();
      key = room.anchor();
    } else if (plugin.dungeons().inDungeonArea(b.getLocation())) {
      if (tell) warn(p, "Zwischen Dungeon-Räumen wird nichts gespeichert – nur in Räumen.");
      return false;
    } else {
      Profile owner = plugin.profile(p);
      if (owner == null) return false;
      int lx = b.getX() - plugin.mines().ox(owner), lz = b.getZ() - plugin.mines().oz(owner);
      if (Math.abs(lx) > 300 || Math.abs(lz) > 300) {
        if (tell) warn(p, "Außerhalb des Deepforge-Geländes wird nichts gespeichert.");
        return false;
      }
      scope = null;
      key = lx + "," + b.getY() + "," + lz;
    }
    Map<String, String> target = scope == null ? world : rooms.computeIfAbsent(scope, k -> new LinkedHashMap<>());
    String old = target.put(key, data);
    Deque<Change> h = history.computeIfAbsent(p.getUniqueId(), k -> new ArrayDeque<>());
    h.push(new Change(scope, key, old, b.getLocation(), blockBefore));
    while (h.size() > HISTORY) h.removeLast();
    dirty = true;
    return true;
  }

  private void warn(Player p, String text) {
    long now = System.currentTimeMillis();
    if (now - warned.getOrDefault(p.getUniqueId(), 0L) < 5000) return;
    warned.put(p.getUniqueId(), now);
    plugin.notice(p, text, NamedTextColor.RED);
  }

  // ---- commands ----

  public String command(Player p, String[] args) {
    if (args.length < 3) return toggle(p);
    String op = args[2].toLowerCase(Locale.ROOT);
    switch (op) {
      case "hilfe", "help" -> {
        return "Bau-Modus: /df admin bau (an/aus) · info · zurück [n] · pos1 · pos2 · übernehmen"
            + " (Auswahl, z. B. nach WorldEdit) · löschen hier [radius] · löschen raum · anwenden"
            + " · dungeon <gewölbe|glutschmiede|frostkrypta> [mine] · dungeon neu · dungeon ende · raum <nr>";
      }
      case "info" -> {
        StringBuilder sb = new StringBuilder("Bauplan: " + world.size() + " Welt-Blöcke (Dorf, Wald, Minen)");
        roomSizes().forEach((k, v) -> sb.append(" · ").append(k).append(": ").append(v));
        RoomRef here = plugin.dungeons().roomAt(p.getLocation());
        if (here != null) sb.append(" · Du stehst in: ").append(here.title()).append(" [").append(here.type()).append("]");
        return sb.toString();
      }
      case "zurück", "zurueck", "undo" -> {
        int n = args.length > 3 ? Math.clamp(Integer.parseInt(args[3]), 1, HISTORY) : 1;
        return undo(p, n);
      }
      case "pos1", "pos2" -> {
        Location[] sel = selection.computeIfAbsent(p.getUniqueId(), k -> new Location[2]);
        Block target = p.getTargetBlockExact(8);
        Location at = target != null ? target.getLocation() : p.getLocation().getBlock().getLocation();
        sel[op.equals("pos1") ? 0 : 1] = at;
        return (op.equals("pos1") ? "Ecke 1" : "Ecke 2") + " gesetzt: " + at.getBlockX() + ", " + at.getBlockY() + ", " + at.getBlockZ()
            + (target != null ? " (angeschauter Block)" : " (deine Position)");
      }
      case "übernehmen", "uebernehmen", "speichern" -> {
        return capture(p);
      }
      case "löschen", "loeschen" -> {
        return delete(p, args);
      }
      case "anwenden" -> {
        Profile owner = plugin.profile(p);
        if (owner == null) return "Kein Gelände.";
        applyWorld(owner);
        return "Welt-Bauplan wird neu eingesetzt (" + world.size() + " Blöcke).";
      }
      case "dungeon" -> {
        return plugin.dungeons().editorCommand(p, args);
      }
      case "raum" -> {
        if (args.length < 4) return "Nutzung: /df admin bau raum <nr>";
        return plugin.dungeons().editorRoom(p, Integer.parseInt(args[3]) - 1);
      }
      default -> {
        return "Unbekannt. /df admin bau hilfe";
      }
    }
  }

  private String undo(Player p, int n) {
    Deque<Change> h = history.getOrDefault(p.getUniqueId(), new ArrayDeque<>());
    int done = 0;
    while (done < n && !h.isEmpty()) {
      Change c = h.pop();
      Map<String, String> target = c.room() == null ? world : rooms.computeIfAbsent(c.room(), k -> new LinkedHashMap<>());
      if (c.overlayBefore() == null) target.remove(c.key());
      else target.put(c.key(), c.overlayBefore());
      try {
        c.at().getBlock().setBlockData(Bukkit.createBlockData(c.blockBefore()), false);
      } catch (IllegalArgumentException ignored) {
        // unknown state: keep the block
      }
      done++;
    }
    dirty = true;
    return done == 0 ? "Nichts rückgängig zu machen." : done + " Änderung(en) rückgängig gemacht.";
  }

  private String capture(Player p) {
    Location[] sel = selection.get(p.getUniqueId());
    if (sel == null || sel[0] == null || sel[1] == null) return "Zuerst /df admin bau pos1 und pos2 setzen.";
    if (sel[0].getWorld() != sel[1].getWorld()) return "Beide Ecken müssen in derselben Welt liegen.";
    int x0 = Math.min(sel[0].getBlockX(), sel[1].getBlockX()), x1 = Math.max(sel[0].getBlockX(), sel[1].getBlockX());
    int y0 = Math.min(sel[0].getBlockY(), sel[1].getBlockY()), y1 = Math.max(sel[0].getBlockY(), sel[1].getBlockY());
    int z0 = Math.min(sel[0].getBlockZ(), sel[1].getBlockZ()), z1 = Math.max(sel[0].getBlockZ(), sel[1].getBlockZ());
    long volume = (long) (x1 - x0 + 1) * (y1 - y0 + 1) * (z1 - z0 + 1);
    if (volume > SELECTION_LIMIT) return "Auswahl zu groß (" + volume + " Blöcke, höchstens " + SELECTION_LIMIT + ").";
    int stored = 0;
    World w = sel[0].getWorld();
    for (int x = x0; x <= x1; x++)
      for (int y = y0; y <= y1; y++)
        for (int z = z0; z <= z1; z++) {
          Block b = w.getBlockAt(x, y, z);
          if (store(p, b, b.getBlockData().getAsString(), false)) stored++;
        }
    return stored + " von " + volume + " Blöcken in den Bauplan übernommen (z. B. nach WorldEdit).";
  }

  private String delete(Player p, String[] args) {
    if (args.length < 4) return "Nutzung: /df admin bau löschen hier [radius] | raum";
    if (args[3].equalsIgnoreCase("raum")) {
      RoomRef here = plugin.dungeons().roomAt(p.getLocation());
      if (here == null) return "Du stehst in keinem Dungeon-Raum.";
      Map<String, String> removed = rooms.remove(here.type());
      dirty = true;
      return "Bauplan für alle Räume vom Typ " + here.type() + " gelöscht (" + (removed == null ? 0 : removed.size())
          + " Blöcke). Ab dem nächsten Lauf sehen sie wieder original aus.";
    }
    int radius = args.length > 4 ? Math.clamp(Integer.parseInt(args[4]), 1, 64) : 5;
    Location c = p.getLocation();
    int removed = 0;
    Profile owner = plugin.profile(p);
    if (owner != null) {
      int ox = plugin.mines().ox(owner), oz = plugin.mines().oz(owner);
      for (Iterator<String> it = world.keySet().iterator(); it.hasNext(); ) {
        String[] v = it.next().split(",");
        int x = Integer.parseInt(v[0]) + ox, y = Integer.parseInt(v[1]), z = Integer.parseInt(v[2]) + oz;
        if (Math.abs(x - c.getBlockX()) <= radius && Math.abs(y - c.getBlockY()) <= radius && Math.abs(z - c.getBlockZ()) <= radius) {
          it.remove();
          removed++;
        }
      }
    }
    dirty = true;
    return removed + " Welt-Blöcke im Umkreis " + radius + " aus dem Bauplan entfernt. Sie bleiben stehen,"
        + " bis das Gelände das nächste Mal neu gebaut wird.";
  }

  // ---- applying ----

  /** Puts the world overlay back on top of a plot (after a camp, mine or forest build). */
  public void applyWorld(Profile plot) {
    if (world.isEmpty()) return;
    World w = plugin.mines().world();
    int ox = plugin.mines().ox(plot), oz = plugin.mines().oz(plot);
    List<Map.Entry<String, String>> entries = new ArrayList<>(world.entrySet());
    Map<String, BlockData> cache = new HashMap<>();
    new org.bukkit.scheduler.BukkitRunnable() {
      int i;

      @Override
      public void run() {
        for (int n = 0; n < APPLY_PER_TICK && i < entries.size(); n++, i++) {
          var e = entries.get(i);
          String[] v = e.getKey().split(",");
          BlockData data = cache.computeIfAbsent(e.getValue(), BuildMode::parse);
          if (data == null) continue;
          w.getBlockAt(Integer.parseInt(v[0]) + ox, Integer.parseInt(v[1]), Integer.parseInt(v[2]) + oz).setBlockData(data, false);
        }
        if (i >= entries.size()) cancel();
      }
    }.runTaskTimer(plugin, 1, 1);
  }

  /** Overlay blocks of one room type for a room of this size: offset → block data. */
  public Map<int[], BlockData> roomBlocks(String type, int hw, int hd, int height) {
    Map<String, String> overlay = rooms.get(type);
    if (overlay == null || overlay.isEmpty()) return Map.of();
    Map<int[], BlockData> out = new LinkedHashMap<>();
    for (var e : overlay.entrySet()) {
      int[] at = RoomAnchor.decode(e.getKey(), hw, hd, height);
      BlockData data = parse(e.getValue());
      if (at != null && data != null) out.put(at, data);
    }
    return out;
  }

  private static BlockData parse(String s) {
    try {
      return Bukkit.createBlockData(s);
    } catch (IllegalArgumentException ex) {
      return null;
    }
  }

  // ---- storage ----

  private static final class Saved {
    Map<String, String> world = new LinkedHashMap<>();
    Map<String, Map<String, String>> rooms = new TreeMap<>();
  }

  private void load() {
    if (!file.isFile()) return;
    try {
      Saved s = gson.fromJson(Files.readString(file.toPath(), StandardCharsets.UTF_8), new TypeToken<Saved>() {}.getType());
      if (s == null) return;
      if (s.world != null) world.putAll(s.world);
      if (s.rooms != null) rooms.putAll(s.rooms);
      plugin.getLogger().info("Bauplan geladen: " + world.size() + " Welt-Blöcke, " + rooms.size() + " Dungeon-Raumtypen.");
    } catch (Exception ex) {
      plugin.getLogger().severe("bauplan.json konnte nicht gelesen werden: " + ex.getMessage());
    }
  }

  private void save() {
    dirty = false;
    try {
      Saved s = new Saved();
      s.world = world;
      s.rooms = rooms;
      file.getParentFile().mkdirs();
      File tmp = new File(file.getParentFile(), "bauplan.json.tmp");
      Files.writeString(tmp.toPath(), gson.toJson(s), StandardCharsets.UTF_8);
      Files.move(tmp.toPath(), file.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE);
    } catch (Exception ex) {
      dirty = true;
      plugin.getLogger().severe("bauplan.json konnte nicht gespeichert werden: " + ex.getMessage());
    }
  }
}
