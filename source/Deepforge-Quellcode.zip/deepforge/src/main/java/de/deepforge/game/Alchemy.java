package de.deepforge.game;

import java.util.*;

/**
 * Alchemie (0.13.0): three ingredients from the three kinds of work – Schattenessenz from monsters,
 * Glutmoos from mining, Waldkraut from the forest – are brewed into potions that buff one thing for
 * a few minutes. Brewing raises the Braumeister level: stronger potions and more at once.
 */
public final class Alchemy {
  private Alchemy() {}

  public enum Ingredient {
    ESSENZ("Schattenessenz", "Monster (10 %), Champions (3), Bosse (5), Dungeon-Siege", "ing_essence", "ECHO_SHARD"),
    MOOS("Glutmoos", "Beim Erzabbau (2 % pro Erzblock)", "ing_moss", "GLOW_LICHEN"),
    KRAUT("Waldkraut", "Beim Baumfällen (20 % pro Baum)", "ing_herb", "FERN");

    public final String title, source, model, material;

    Ingredient(String title, String source, String model, String material) {
      this.title = title;
      this.source = source;
      this.model = model;
      this.material = material;
    }
  }

  public enum Potion {
    STAERKE("Trank der Stärke", "Schaden", .15, 10, 3, 0, 2, "potion_strength"),
    ZAEH("Trank der Zähigkeit", "Leben", .15, 10, 2, 0, 3, "potion_tough"),
    BERGMANN("Bergmannstrank", "Abbaukraft", .20, 15, 0, 3, 2, "potion_miner"),
    GOLD("Goldtrank", "Erz- und Barrenwert", .20, 15, 1, 4, 1, "potion_gold"),
    FLINK("Flinktrank", "Angriffstempo", .30, 10, 3, 1, 1, "potion_swift"),
    SCHUTZ("Tiefenschutz", "weniger erlittener Schaden", .20, 8, 4, 2, 2, "potion_guard");

    public final String title, stat, model;
    /** Base effect (fraction, Flinktrank: attacks per second) and minutes it lasts. */
    public final double effect;
    public final int minutes;
    public final int[] recipe;

    Potion(String title, String stat, double effect, int minutes, int essence, int moss, int herb, String model) {
      this.title = title;
      this.stat = stat;
      this.effect = effect;
      this.minutes = minutes;
      this.recipe = new int[] {essence, moss, herb};
      this.model = model;
    }
  }

  public static final double ESSENCE_CHANCE = .10, MOSS_CHANCE = .02, HERB_CHANCE = .20;
  public static final int MAX_LEVEL = 20, XP_PER_BREW = 10;

  // ---- Braumeister ----

  public static int level(Profile p) {
    return (int) Math.min(MAX_LEVEL, Math.floor(Math.sqrt(p.alchemyXp / 40.0)));
  }

  /** XP needed for the next level (total). */
  public static long nextXp(Profile p) {
    int l = level(p);
    return l >= MAX_LEVEL ? p.alchemyXp : 40L * (l + 1) * (l + 1);
  }

  /** +2 % potion strength per Braumeister level. */
  public static double strength(Profile p) {
    return 1 + .02 * level(p);
  }

  /** Potions active at once: 2, +1 at level 5, 10, 15 and 20. */
  public static int slots(Profile p) {
    return 2 + level(p) / 5;
  }

  /** From level 10 one brew gives two potions. */
  public static int batch(Profile p) {
    return level(p) >= 10 ? 2 : 1;
  }

  public static long price(Profile p, Potion k) {
    // 0.22.0: potions boost a share of the income, so they follow the mine's ore price.
    return Math.max(300L * (Math.min(p.zone, Zone.LAST) + 1), Math.round(60 * Economy.scale(p.zone)))
        * (k.ordinal() / 2 + 1);
  }

  // ---- stock ----

  public static long stock(Profile p, Potion k) {
    return p.potions == null ? 0 : p.potions.getOrDefault(k.name(), 0L);
  }

  public static long ingredient(Profile p, Ingredient i) {
    return p.ingredients == null || p.ingredients.length <= i.ordinal() ? 0 : p.ingredients[i.ordinal()];
  }

  public static void gain(Profile p, Ingredient i, long n) {
    if (p.ingredients == null || p.ingredients.length < Ingredient.values().length) {
      long[] grown = new long[Ingredient.values().length];
      if (p.ingredients != null) System.arraycopy(p.ingredients, 0, grown, 0, p.ingredients.length);
      p.ingredients = grown;
    }
    p.ingredients[i.ordinal()] += n;
  }

  public static String brew(Profile p, Potion k) {
    List<String> missing = new ArrayList<>();
    for (Ingredient i : Ingredient.values())
      if (ingredient(p, i) < k.recipe[i.ordinal()])
        missing.add((k.recipe[i.ordinal()] - ingredient(p, i)) + " " + i.title);
    long cost = price(p, k);
    if (p.money < cost) missing.add(n(cost - p.money) + " $");
    if (!missing.isEmpty()) return "Es fehlt: " + String.join(", ", missing) + ".";
    for (Ingredient i : Ingredient.values()) p.ingredients[i.ordinal()] -= k.recipe[i.ordinal()];
    p.money -= cost;
    int made = batch(p);
    if (p.potions == null) p.potions = new HashMap<>();
    p.potions.merge(k.name(), (long) made, Long::sum);
    int before = level(p);
    p.alchemyXp += XP_PER_BREW;
    String up = level(p) > before ? " BRAUMEISTER STUFE " + level(p) + "!" : "";
    return (made > 1 ? made + "× " : "") + k.title + " gebraut." + up;
  }

  // ---- effects ----

  public static long remaining(Profile p, Potion k, long now) {
    if (p.activePotions == null) return 0;
    return Math.max(0, p.activePotions.getOrDefault(k.name(), 0L) - now);
  }

  public static int activeCount(Profile p, long now) {
    int n = 0;
    for (Potion k : Potion.values()) if (remaining(p, k, now) > 0) n++;
    return n;
  }

  public static String drink(Profile p, Potion k, long now) {
    if (stock(p, k) <= 0) return "Kein " + k.title + " vorrätig – erst brauen.";
    boolean running = remaining(p, k, now) > 0;
    if (!running && activeCount(p, now) >= slots(p))
      return "Schon " + slots(p) + " Tränke aktiv (Braumeister-Stufe erhöht das Limit).";
    long duration = k.minutes * 60_000L;
    if (running && remaining(p, k, now) + duration > 2 * duration)
      return k.title + " wirkt noch lange genug (max. " + 2 * k.minutes + " Min.).";
    if (p.activePotions == null) p.activePotions = new HashMap<>();
    p.activePotions.put(k.name(), now + remaining(p, k, now) + duration);
    p.potions.merge(k.name(), -1L, Long::sum);
    return k.title + " getrunken: +" + describe(p, k) + " für " + (remaining(p, k, now) / 60_000) + " Min.";
  }

  /** Current effect of a potion kind (0 when not active). */
  public static double bonus(Profile p, Potion k, long now) {
    return remaining(p, k, now) > 0 ? k.effect * strength(p) : 0;
  }

  public static double bonus(Profile p, Potion k) {
    return p.activePotions == null || p.activePotions.isEmpty() ? 0 : bonus(p, k, System.currentTimeMillis());
  }

  public static String describe(Profile p, Potion k) {
    double v = k.effect * strength(p);
    return k == Potion.FLINK
        ? String.format(Locale.GERMAN, "%.2f %s", v, k.stat)
        : Math.round(v * 100) + " % " + k.stat;
  }

  /** Clears expired potions and returns their names (for a short notice). */
  public static List<String> expire(Profile p, long now) {
    List<String> out = new ArrayList<>();
    if (p.activePotions == null) return out;
    for (Potion k : Potion.values()) {
      Long until = p.activePotions.get(k.name());
      if (until != null && until <= now) {
        p.activePotions.remove(k.name());
        out.add(k.title);
      }
    }
    return out;
  }

  static String n(long v) {
    return String.format(Locale.GERMAN, "%,d", v);
  }
}
