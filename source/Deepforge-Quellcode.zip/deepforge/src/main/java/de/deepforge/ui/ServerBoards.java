package de.deepforge.ui;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.Profile;
import java.util.*;
import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

/** Only real players are listed; each sidebar contains its owner's private progress. */
public final class ServerBoards implements AutoCloseable {
  private final DeepforgePlugin plugin;
  private final Map<UUID, State> states = new HashMap<>();

  private static final class State {
    Scoreboard previous, board;
    Component oldName, oldHeader, oldFooter, name, header, footer;
    boolean tab;
    int oldOrder, order;
    List<Component> lines = List.of();
  }

  public ServerBoards(DeepforgePlugin plugin) {
    this.plugin = plugin;
  }

  public void update(Player player, Profile profile, boolean ready) {
    boolean tab = plugin.getConfig().getBoolean("display.tab-list", true);
    boolean sidebar = plugin.getConfig().getBoolean("display.sidebar", true);
    if (!tab && !sidebar) {
      remove(player);
      return;
    }
    State state = states.computeIfAbsent(player.getUniqueId(), id -> new State());
    if (tab) {
      if (!state.tab) {
        state.oldName = player.playerListName();
        state.oldHeader = player.playerListHeader();
        state.oldFooter = player.playerListFooter();
        state.oldOrder = player.getPlayerListOrder();
        state.tab = true;
      }
      int online = (int) Bukkit.getOnlinePlayers().stream().filter(player::canSee).count();
      boolean hoster =
          plugin.getConfig().getStringList("display.hosters").stream()
              .anyMatch(
                  id ->
                      id.equalsIgnoreCase(player.getName())
                          || id.equalsIgnoreCase(player.getUniqueId().toString()));
      PlayerRank rank = PlayerRank.resolve(hoster, player::hasPermission);
      Component name = rank.playerName(player.getName());
      if (state.order != rank.order) {
        player.setPlayerListOrder(rank.order);
        state.order = rank.order;
      }
      Component
          header =
              BoardView.header(
                  plugin.getConfig().getString("display.network-name", "Pinguin Netzwerk")),
          footer =
              BoardView.footer(
                  profile,
                  player.getPing(),
                  online,
                  ready,
                  plugin.getConfig().getString("display.social", "twitch.tv/fabiderpinguin"));
      if (!name.equals(state.name)) {
        player.playerListName(name);
        state.name = name;
      }
      if (!header.equals(state.header) || !footer.equals(state.footer)) {
        player.sendPlayerListHeaderAndFooter(header, footer);
        state.header = header;
        state.footer = footer;
      }
    }
    if (sidebar) {
      if (state.board == null) {
        state.previous = player.getScoreboard();
        state.board =
            newBoard(plugin.getConfig().getString("display.network-name", "Pinguin Netzwerk"));
        player.setScoreboard(state.board);
      }
      List<Component> lines = BoardView.lines(profile, ready, plugin.packApplied(player));
      for (int n = 0; n < lines.size(); n++)
        if (n >= state.lines.size() || !lines.get(n).equals(state.lines.get(n)))
          state.board.getTeam("line" + n).prefix(lines.get(n));
      state.lines = lines;
    }
  }

  private static Scoreboard newBoard(String network) {
    Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
    Objective objective =
        board.registerNewObjective(
            "deepforge", Criteria.DUMMY, NetworkTheme.brandTitle(network, "Deepforge"));
    objective.setDisplaySlot(DisplaySlot.SIDEBAR);
    objective.numberFormat(io.papermc.paper.scoreboard.numbers.NumberFormat.blank());
    for (int n = 0; n < BoardView.LINES; n++) {
      String entry = "§" + Integer.toHexString(n);
      Team team = board.registerNewTeam("line" + n);
      team.addEntry(entry);
      objective.getScore(entry).setScore(BoardView.LINES - n);
    }
    return board;
  }

  public void remove(Player p) {
    State s = states.remove(p.getUniqueId());
    if (s == null) return;
    if (s.board != null && p.getScoreboard() == s.board) p.setScoreboard(s.previous);
    if (s.tab) {
      if (Objects.equals(p.playerListName(), s.name)) p.playerListName(s.oldName);
      if (p.getPlayerListOrder() == s.order) p.setPlayerListOrder(s.oldOrder);
      if (Objects.equals(p.playerListHeader(), s.header)
          && Objects.equals(p.playerListFooter(), s.footer))
        p.sendPlayerListHeaderAndFooter(
            s.oldHeader == null ? Component.empty() : s.oldHeader,
            s.oldFooter == null ? Component.empty() : s.oldFooter);
    }
  }

  public String verify() {
    Scoreboard board = newBoard("Pinguin Netzwerk");
    Profile p = new Profile();
    var lines = BoardView.lines(p, true);
    for (int n = 0; n < lines.size(); n++) board.getTeam("line" + n).prefix(lines.get(n));
    if (board.getEntries().size() != BoardView.LINES || board.getObjective(DisplaySlot.SIDEBAR) == null)
      throw new IllegalStateException("Sidebar incomplete");
    for (var team : new ArrayList<>(board.getTeams())) team.unregister();
    board.getObjective("deepforge").unregister();
    return "OK: " + BoardView.LINES + " sidebar lines, unique entries, hidden score numbers, TAB components and cleanup;"
        + " no player data";
  }

  @Override
  public void close() {
    for (UUID id : new ArrayList<>(states.keySet())) {
      Player p = Bukkit.getPlayer(id);
      if (p != null) remove(p);
      else states.remove(id);
    }
  }
}
