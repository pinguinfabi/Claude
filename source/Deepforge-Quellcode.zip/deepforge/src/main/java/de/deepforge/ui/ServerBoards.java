package de.deepforge.ui;

import de.deepforge.DeepforgePlugin;
import de.deepforge.game.Profile;
import java.util.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

/**
 * Tab list, sidebar and name tags in the Axxin.de network style. Players with the verified pack
 * see the network glyphs (DEEPFORGE logo, panel header, rank and status tags, icons); everyone
 * else gets the same information as styled text. Name tags and tab names come from teams on each
 * viewer's own scoreboard, so every viewer gets the variant that fits their client.
 */
public final class ServerBoards implements AutoCloseable {
  private static final String TEAM = "df_";
  private final DeepforgePlugin plugin;
  private final Map<UUID, State> states = new HashMap<>();

  private static final class State {
    Scoreboard previous, board;
    Component oldName, oldHeader, oldFooter, name, header, footer, title;
    boolean tab;
    int oldOrder, order;
    List<Component> lines = List.of();
  }

  public ServerBoards(DeepforgePlugin plugin) {
    this.plugin = plugin;
  }

  // Snapshots for the async chat renderer: rank per player and who sees pack glyphs.
  private final Map<UUID, PlayerRank> ranks = new java.util.concurrent.ConcurrentHashMap<>();
  private final Set<UUID> glyphViewers = java.util.concurrent.ConcurrentHashMap.newKeySet();
  private final Map<UUID, Integer> prestige = new java.util.concurrent.ConcurrentHashMap<>();

  /** Last known prestige; safe to call from the chat thread. */
  public int knownPrestige(UUID id) {
    return prestige.getOrDefault(id, 0);
  }

  /** Last known rank; safe to call from the chat thread. */
  public PlayerRank knownRank(UUID id) {
    return ranks.getOrDefault(id, PlayerRank.NONE);
  }

  public boolean glyphs(UUID viewer) {
    return glyphViewers.contains(viewer);
  }

  /** Refreshes the chat snapshot for every online player (main thread, once per second). */
  public void snapshot(Player player) {
    ranks.put(player.getUniqueId(), rank(player));
    if (plugin.playing(player)) prestige.put(player.getUniqueId(), plugin.profile(player).prestige);
    if (plugin.playing(player) && plugin.gameHud(player)) glyphViewers.add(player.getUniqueId());
    else glyphViewers.remove(player.getUniqueId());
  }

  public void forget(UUID id) {
    ranks.remove(id);
    glyphViewers.remove(id);
    prestige.remove(id);
  }

  private PlayerRank rank(Player player) {
    boolean hoster =
        plugin.getConfig().getStringList("display.hosters").stream()
            .anyMatch(
                id ->
                    id.equalsIgnoreCase(player.getName())
                        || id.equalsIgnoreCase(player.getUniqueId().toString()));
    return PlayerRank.resolve(hoster, player::hasPermission);
  }

  public void update(Player player, Profile profile, boolean ready) {
    boolean tab = plugin.getConfig().getBoolean("display.tab-list", true);
    boolean sidebar = plugin.getConfig().getBoolean("display.sidebar", true);
    if (!tab && !sidebar) {
      remove(player);
      return;
    }
    boolean glyphs = plugin.gameHud(player);
    String network = plugin.getConfig().getString("display.network-name", "Axxin.de");
    State state = states.computeIfAbsent(player.getUniqueId(), id -> new State());
    if (tab) {
      if (!state.tab) {
        state.oldName = player.playerListName();
        state.oldHeader = player.playerListHeader();
        state.oldFooter = player.playerListFooter();
        state.oldOrder = player.getPlayerListOrder();
        state.tab = true;
      }
      int online = (int) Bukkit.getOnlinePlayers().stream().filter(player::canSee).count();
      PlayerRank rank = rank(player);
      if (state.order != rank.order) {
        player.setPlayerListOrder(rank.order);
        state.order = rank.order;
      }
      // With a sidebar the name comes from the viewer's team (tag glyph or text); without one the
      // plain text name is set for everyone.
      Component name = sidebar ? null : rank.playerName(player.getName());
      if (!Objects.equals(name, state.name)) {
        player.playerListName(name);
        state.name = name;
      }
      String social = plugin.getConfig().getString("display.social", DeepforgePlugin.SOCIAL);
      Component header = glyphs ? BoardView.netzHeader(network) : BoardView.header(network);
      Component footer =
          glyphs
              ? BoardView.netzFooter(profile, player.getPing(), online, ready, social)
              : BoardView.footer(profile, player.getPing(), online, ready, social);
      if (!header.equals(state.header) || !footer.equals(state.footer)) {
        player.sendPlayerListHeaderAndFooter(header, footer);
        state.header = header;
        state.footer = footer;
      }
    }
    if (sidebar) {
      if (state.board == null) {
        state.previous = player.getScoreboard();
        state.board = newBoard(network);
        player.setScoreboard(state.board);
      }
      Component title = glyphs ? NetzFont.header() : NetworkTheme.networkTitle(network);
      if (!title.equals(state.title)) {
        state.board.getObjective("deepforge").displayName(title);
        state.title = title;
      }
      // 0.23.0: inside a dungeon the sidebar shows the run's rooms instead.
      List<Component> lines =
          plugin.dungeons() == null ? null : plugin.dungeons().sidebar(player, glyphs);
      if (lines == null) lines = BoardView.lines(profile, ready, glyphs);
      for (int n = 0; n < lines.size(); n++)
        if (n >= state.lines.size() || !lines.get(n).equals(state.lines.get(n)))
          state.board.getTeam("line" + n).prefix(lines.get(n));
      state.lines = lines;
      nametags(player, state.board, glyphs);
    }
  }

  /** Rank tag before and status tag after every name, on this viewer's scoreboard. */
  private void nametags(Player viewer, Scoreboard board, boolean glyphs) {
    Set<String> wanted = new HashSet<>();
    for (Player target : Bukkit.getOnlinePlayers()) {
      String id = TEAM + target.getUniqueId().toString().replace("-", "").substring(0, 13);
      wanted.add(id);
      Team team = board.getTeam(id);
      if (team == null) team = board.registerNewTeam(id);
      PlayerRank rank = rank(target);
      Component prefix =
          rank == PlayerRank.NONE
              ? Component.empty()
              : glyphs
                  ? Component.text().append(NetzFont.rank(rank)).append(Component.text(" ")).build()
                  : Component.text(rank.name() + " ", rank.color).decorate(TextDecoration.BOLD);
      Component suffix = status(target, glyphs);
      if (!prefix.equals(team.prefix())) team.prefix(prefix);
      if (!suffix.equals(team.suffix())) team.suffix(suffix);
      if (!team.hasColor() || team.color() != rank.color) team.color(rank.color);
      if (!team.hasEntry(target.getName())) team.addEntry(target.getName());
    }
    for (Team team : new ArrayList<>(board.getTeams()))
      if (team.getName().startsWith(TEAM) && !wanted.contains(team.getName())) team.unregister();
  }

  private Component status(Player target, boolean glyphs) {
    String tag = plugin.guilds() == null ? null : plugin.guilds().tag(target.getUniqueId());
    Component guild =
        tag == null
            ? Component.empty()
            : Component.text(" [" + tag + "]", plugin.guilds().color(target.getUniqueId()));
    String badge = de.deepforge.game.Prestige.badge(knownPrestige(target.getUniqueId()));
    Component stars =
        badge.isEmpty() ? Component.empty() : Component.text(" " + badge, NamedTextColor.GOLD);
    return stars.append(guild).append(activity(target, glyphs));
  }

  private Component activity(Player target, boolean glyphs) {
    boolean spec = plugin.dungeons().watching(target) || plugin.admin().inMode(target);
    boolean dungeon = plugin.dungeons().active(target);
    if (!spec && !dungeon) return Component.empty();
    if (glyphs)
      return Component.text(" ").append(NetzFont.tag(spec ? NetzFont.Tag.SPEC : NetzFont.Tag.INGAME));
    return Component.text(spec ? " [Zuschauer]" : " [Dungeon]", NamedTextColor.DARK_GRAY);
  }

  private static Scoreboard newBoard(String network) {
    Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
    Objective objective =
        board.registerNewObjective(
            "deepforge", Criteria.DUMMY, NetworkTheme.networkTitle(network));
    objective.setDisplaySlot(DisplaySlot.SIDEBAR);
    objective.numberFormat(io.papermc.paper.scoreboard.numbers.NumberFormat.blank());
    for (int n = 0; n < BoardView.LINES; n++) {
      String entry = "§" + Integer.toHexString(n);
      Team team = board.registerNewTeam("line" + n);
      team.addEntry(entry);
      objective.getScore(entry).setScore(BoardView.LINES - n);
    }
    return board;
  }

  public void remove(Player p) {
    State s = states.remove(p.getUniqueId());
    if (s == null) return;
    if (s.board != null && p.getScoreboard() == s.board) p.setScoreboard(s.previous);
    if (s.tab) {
      if (Objects.equals(p.playerListName(), s.name)) p.playerListName(s.oldName);
      if (p.getPlayerListOrder() == s.order) p.setPlayerListOrder(s.oldOrder);
      if (Objects.equals(p.playerListHeader(), s.header)
          && Objects.equals(p.playerListFooter(), s.footer))
        p.sendPlayerListHeaderAndFooter(
            s.oldHeader == null ? Component.empty() : s.oldHeader,
            s.oldFooter == null ? Component.empty() : s.oldFooter);
    }
  }

  public String verify() {
    Scoreboard board = newBoard("Axxin.de");
    Profile p = new Profile();
    var lines = BoardView.lines(p, true);
    for (int n = 0; n < lines.size(); n++) board.getTeam("line" + n).prefix(lines.get(n));
    if (board.getEntries().size() != BoardView.LINES || board.getObjective(DisplaySlot.SIDEBAR) == null)
      throw new IllegalStateException("Sidebar incomplete");
    for (var team : new ArrayList<>(board.getTeams())) team.unregister();
    board.getObjective("deepforge").unregister();
    return "OK: " + BoardView.LINES + " sidebar lines, unique entries, hidden score numbers, TAB components and cleanup;"
        + " no player data";
  }

  @Override
  public void close() {
    for (UUID id : new ArrayList<>(states.keySet())) {
      Player p = Bukkit.getPlayer(id);
      if (p != null) remove(p);
      else states.remove(id);
    }
  }
}
