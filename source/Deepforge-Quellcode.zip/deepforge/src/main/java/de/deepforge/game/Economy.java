package de.deepforge.game;

public final class Economy {
  /**
   * 0.22.0 price scale: the ore price of a mine relative to the Eisenmine (1 → ~10.000). Income
   * grows with it, so prices that follow it cost the same share of play time in every mine.
   */
  public static double scale(int zone) {
    return (double) Zone.at(Math.max(0, zone)).orePrice / Zone.IRON.orePrice;
  }

  /** Scale for prices that stay low at the start: 1 up to the third mine, then like the ore price. */
  public static double lateScale(int zone) {
    return Math.max(1, scale(zone) / 4);
  }

  /** Worker hire: 1.500 $ for the first, then ×2 per worker (1,5k · 6k · 18k · 48k · 120k · 288k). */
  public static long hireCost(int workers) {
    return 1500L * (workers + 1) * (1L << Math.min(20, workers));
  }

  /** Worker training: grows with the level and with the mine the worker works in. */
  public static long trainCost(Profile.Worker w) {
    return Math.round(1000L * w.level * w.level * lateScale(w.zone));
  }

  public static String buy(Profile p, String action) {
    long cost;
    int level;
    switch (action) {
      case "oreLuck" -> {
        level = p.oreLuck;
        cost = grown(500, level, 1.5);
      }
      case "tool" -> {
        level = p.tool;
        cost = toolCost(level);
      }
      case "sword" -> {
        level = p.sword;
        cost = steep(250, level);
      }
      case "armor" -> {
        level = p.armor;
        cost = steep(300, level);
      }
      case "bag" -> {
        level = p.bagLevel;
        cost = Math.max(500L * (level + 1) * (level + 1), Math.round(1000 * Math.pow(1.45, level)));
      }
      case "potion" -> {
        level = p.healStock;
        cost = 600L * (level + 1) * (level + 1);
      }
      case "warehouse" -> {
        level = p.warehouse;
        cost = grown(1200, level, 1.5);
      }
      case "furnace" -> {
        level = p.furnace;
        cost = grown(1500, level, 1.5);
      }
      case "housing" -> {
        level = p.housing;
        cost = grown(3000, level, 2);
      }
      default -> {
        return "Unbekanntes Upgrade.";
      }
    }
    int max = max(action);
    cost = Math.round(cost * Talents.upgradeCost(p));
    if (level >= max) return "Maximale Stufe erreicht.";
    if (p.money < cost) return "Benötigt " + cost + " $.";
    if ((action.equals("tool") || action.equals("sword")) && level >= 4 && p.relics < 1)
      return "Ab Stufe 5 benötigst du außerdem ein Relikt.";
    p.money -= cost;
    if ((action.equals("tool") || action.equals("sword")) && level >= 4) p.relics--;
    switch (action) {
      case "oreLuck" -> p.oreLuck++;
      case "tool" -> p.tool++;
      case "sword" -> p.sword++;
      case "armor" -> p.armor++;
      case "bag" -> p.bagLevel++;
      case "potion" -> p.healStock++;
      case "warehouse" -> p.warehouse++;
      case "furnace" -> p.furnace++;
      case "housing" -> p.housing++;
    }
    return "Verbessert! Kosten: " + cost + " $.";
  }

  public static long upgradeCost(Profile p, String action) {
    int level =
        switch (action) {
          case "oreLuck" -> p.oreLuck;
          case "tool" -> p.tool;
          case "sword" -> p.sword;
          case "armor" -> p.armor;
          case "bag" -> p.bagLevel;
          case "potion" -> p.healStock;
          case "warehouse" -> p.warehouse;
          case "furnace" -> p.furnace;
          case "housing" -> p.housing;
          default -> 0;
        };
    long base =
        switch (action) {
          case "oreLuck" -> 500;
          case "tool" -> 200;
          case "sword" -> 250;
          case "armor" -> 300;
          case "bag" -> 500;
          case "potion" -> 600;
          case "warehouse" -> 1200;
          case "furnace" -> 1500;
          case "housing" -> 3000;
          default -> 0;
        };
    if (action.equals("tool")) return Math.round(toolCost(level) * Talents.upgradeCost(p));
    if (action.equals("sword") || action.equals("armor"))
      return Math.round(steep(base, level) * Talents.upgradeCost(p));
    long cost =
        switch (action) {
          case "oreLuck", "warehouse", "furnace" -> grown(base, level, 1.5);
          case "housing" -> grown(base, level, 2);
          case "bag" -> Math.max(base * (level + 1) * (level + 1), Math.round(1000 * Math.pow(1.45, level)));
          default -> base * (level + 1) * (level + 1);
        };
    return Math.round(cost * Talents.upgradeCost(p));
  }

  /** Quadratic curve with an extra factor per level (0.22.0: the old one was far too flat). */
  static long grown(long base, int level, double factor) {
    return Math.round(base * (level + 1) * (level + 1) * Math.pow(factor, level));
  }

  /**
   * 0.9.0/0.9.3: drill, blade and protection go to level 30 for the deep mines; each level above
   * 20 costs 2,5× more than the usual curve.
   */
  public static final int MAX_TOOL = 30, MAX_COMBAT = 30;

  public static int max(String action) {
    return switch (action) {
      case "oreLuck" -> 10;
      case "housing" -> 5;
      case "warehouse" -> 8;
      case "furnace" -> 5;
      case "potion" -> Healing.CAPACITY - Healing.START;
      case "tool" -> MAX_TOOL;
      case "sword", "armor" -> MAX_COMBAT;
      default -> 20;
    };
  }

  static long toolCost(int level) {
    return steep(200, level);
  }

  /**
   * 0.22.0: the old curve grew only quadratically up to level 19, so drill, blade and protection
   * were almost free in the middle mines (level 14 cost 45.000 $ next to a 2,4 Mio. $ mine). Now
   * every level costs at least ×1,6 the last, so each upgrade stays a real decision.
   */
  static long steep(long base, int level) {
    long old = Math.round(base * (level + 1) * (level + 1) * Math.pow(2.5, Math.max(0, level - 19)));
    return Math.max(old, Math.round(2 * base * Math.pow(1.6, level)));
  }

  public static long sell(Profile p) {
    return sell(p, true);
  }

  /** Bars are needed for research and bar contracts, so they can be kept. */
  public static long sell(Profile p, boolean bars) {
    return sell(p, bars, 1);
  }

  /** {@code boost} is the Goldrausch world-event multiplier (1 = normal prices). */
  public static long sell(Profile p, boolean bars, double boost) {
    long total = 0;
    for (int z = 0; z < Zone.COUNT; z++) {
      total += (p.bag[z] + p.stock[z]) * Zone.at(z).orePrice;
      p.bag[z] = p.stock[z] = 0;
      if (!bars) continue;
      p.soldBars += p.bars[z];
      total += p.bars[z] * Zone.at(z).barPrice;
      p.bars[z] = 0;
    }
    total = Math.round(total * boost * Prestige.income(p) * (1 + Alchemy.bonus(p, Alchemy.Potion.GOLD))
                * (1 + Archaeology.bonus(p)));
    p.money += total;
    p.lifetimeRevenue += total;
    return total;
  }

  /**
   * Sells only bars; what the next research step and the open bar contract need stays in storage.
   * Returns the money and fills {@code kept} with the bars held back.
   */
  public static long sellBars(Profile p, long[] kept) {
    return sellBars(p, kept, 1);
  }

  public static long sellBars(Profile p, long[] kept, double boost) {
    long total = 0;
    for (int z = 0; z < Zone.COUNT; z++) {
      long n = Industry.sellableBars(p, z);
      kept[0] += p.bars[z] - n;
      p.bars[z] -= n;
      p.soldBars += n;
      total += n * Zone.at(z).barPrice;
    }
    total = Math.round(total * boost * Prestige.income(p) * (1 + Alchemy.bonus(p, Alchemy.Potion.GOLD))
                * (1 + Archaeology.bonus(p)));
    p.money += total;
    p.lifetimeRevenue += total;
    return total;
  }

  public static long deposit(Profile p) {
    long moved = 0, space = p.stockCapacity() - p.stockUsed();
    for (int z = 0; z < Zone.COUNT; z++) {
      long n = Math.min(space, p.bag[z]);
      p.bag[z] -= n;
      p.stock[z] += n;
      space -= n;
      moved += n;
    }
    p.depositedOre += moved;
    return moved;
  }

  /**
   * Dismisses a worker, identified by id so a shifted list can never hit the wrong person. The
   * slot becomes free for a new hire; training and experience are lost.
   */
  public static String dismiss(Profile p, String workerId) {
    for (int i = 0; i < p.workers.size(); i++) {
      Profile.Worker w = p.workers.get(i);
      if (!w.id.equals(workerId)) continue;
      p.workers.remove(i);
      return w.name + " wurde entlassen. Der Platz ist frei für eine neue Einstellung.";
    }
    return "Arbeiter nicht gefunden.";
  }

  public static String hire(Profile p, Profile.Job job) {
    if (!p.bosses[0]) return "Besiege zuerst den Steinwächter in der Eisenmine.";
    if (p.workers.size() >= p.workerSlots()) return "Baue zuerst die Unterkunft aus.";
    if (job == Profile.Job.SMELTER && p.furnace == 0) return "Baue zuerst eine Schmelze.";
    if (job == Profile.Job.TRADER && p.zone < 1)
      return "Händler benötigen Zugang zur Kristallhöhle.";
    long cost = hireCost(p.workers.size());
    if (p.money < cost) return "Benötigt " + cost + " $.";
    String[] names = {"Borin", "Mira", "Tarek", "Nora", "Finn", "Yara"};
    p.money -= cost;
    // Lumberjacks start on oak; everyone else in the newest zone.
    p.workers.add(
        new Profile.Worker(
            names[(p.workerSerial++) % names.length],
            job,
            job == Profile.Job.LUMBERJACK ? 0 : p.zone));
    Production.staggerShifts(p);
    return "Arbeiter eingestellt. Brennstoff und Betriebsbudget bereitstellen!";
  }

  public static String nextZone(Profile p) {
    if (p.zone >= Zone.LAST) return "Alle Gebiete erschlossen.";
    Zone next = Zone.at(p.zone + 1);
    if (!p.bosses[p.zone]) return "Besiege zuerst den Gebiets-Boss.";
    if (p.tool < next.toolRequired) return "Benötigt Werkzeugstufe " + next.toolRequired + ".";
    if (p.money < next.unlockCost) return "Benötigt " + next.unlockCost + " $.";
    p.money -= next.unlockCost;
    p.zone++;
    return next.title + " freigeschaltet!";
  }

  public static String order(Profile p) {
    int z = p.zone;
    long required = 80 + (p.orders % 4) * 40L;
    if (p.bag[z] + p.stock[z] < required)
      return "Benötigt " + required + " " + Zone.at(z).oreName + " im Rucksack/Lager.";
    long fromBag = Math.min(required, p.bag[z]);
    p.bag[z] -= fromBag;
    p.stock[z] -= required - fromBag;
    long reward = required * Zone.at(z).orePrice * 3 / 2;
    p.money += reward;
    p.lifetimeRevenue += reward;
    p.orders++;
    if (p.orders % 5 == 0) p.relics++;
    return "Lieferung abgeschlossen: +" + reward + " $. Jeder fünfte Auftrag gibt ein Relikt.";
  }

  public static String quest(Profile p) {
    boolean ready =
        switch (p.quest) {
          case 0 -> p.mined >= 32;
          case 1 -> p.tool >= 1;
          case 2 -> p.mined >= 100;
          case 3 -> p.bosses[0];
          case 4 -> !p.workers.isEmpty();
          case 5 -> p.zone >= 1;
          case 6 -> p.furnace >= 1;
          case 7 -> p.orders >= 5;
          case 8 -> p.zone >= 6;
          case 9 -> p.bosses[6];
          case 10 -> albtraumDungeon(p);
          case 11 -> p.champions >= 25;
          case 12 -> Talents.level(p) >= 15;
          case 13 -> DungeonRules.bestLevel(p) >= 30;
          case 14 -> p.bossWins[6 * 3 + 2] > 0;
          case 15 -> p.zone >= 7;
          case 16 -> p.zone >= 11;
          case 17 -> p.zone >= Zone.LAST;
          case 18 -> p.bosses[Zone.LAST];
          case 19 -> p.bossWins[Zone.LAST * 3 + 2] > 0;
          case 20 -> p.gear.stream().anyMatch(i -> i.level >= StarStones.LEVEL);
          case 21 -> p.urbossKills > 0;
          default -> false;
        };
    if (p.quest >= QUESTS) return "Alle Ziele erreicht. Jage weiter den Urboss!";
    if (!ready) return "Ziel noch nicht erreicht: " + questText(p.quest);
    // Endgame goals (from 9 on) pay far more; the deep-shaft goals (from 16 on) pay millions.
    long reward =
        p.quest >= 15
            ? 1_000_000L * (p.quest - 14) * (p.quest - 14)
            : p.quest >= 8 ? 10_000L * (p.quest - 7) : 500L * (p.quest + 1);
    p.money += reward;
    p.lifetimeRevenue += reward;
    p.relics += p.quest >= 3 ? 1 : 0;
    if (p.quest >= 8) p.dust += 20L * (p.quest - 7);
    p.quest++;
    return "Meilenstein erreicht: +" + reward + " $" + (p.quest > 8 ? " und Schmiedestaub" : "") + ".";
  }

  public static String questText(int q) {
    return switch (q) {
      case 0 -> "Baue 32 Erze selbst ab";
      case 1 -> "Verbessere dein Werkzeug";
      case 2 -> "Baue insgesamt 100 Erze ab";
      case 3 -> "Besiege den Steinwächter";
      case 4 -> "Stelle deinen ersten Arbeiter ein";
      case 5 -> "Erschließe die Kristallhöhle";
      case 6 -> "Baue eine Schmelze";
      case 7 -> "Erfülle fünf Lieferaufträge";
      case 8 -> "Erschließe alle sieben Gebiete";
      case 9 -> "Besiege den Boss im Leerenbruch";
      case 10 -> "Gewinne einen Dungeon auf Albtraum";
      case 11 -> "Besiege 25 Champions";
      case 12 -> "Erreiche Meisterschaft 15";
      case 13 -> "Erreiche Dungeon-Level 30 in einem Gebiet";
      case 14 -> "Besiege den Leerenbruch-Boss auf Albtraum";
      case 15 -> "Erschließe die Kernschmelze (Gebiet 8)";
      case 16 -> "Erschließe den Knochengrund (Gebiet 12)";
      case 17 -> "Erschließe den Weltenkern (Gebiet 17)";
      case 18 -> "Besiege den Weltenschlinger im Weltenkern";
      case 19 -> "Besiege den Weltenkern-Boss auf Albtraum";
      case 20 -> "Schmiede einen Gegenstand über das Maximum (Sternenstein)";
      case 21 -> "Besiege den Urboss (1 % im Weltenkern auf Albtraum)";
      default -> "Alle Ziele erreicht – jage weiter den Urboss!";
    };
  }

  public static final int QUESTS = 22;

  private static boolean albtraumDungeon(Profile p) {
    for (int z = 0; z < Zone.COUNT; z++) if (p.dungeonWins[z * 3 + 2] > 0) return true;
    return false;
  }

  private Economy() {}
}
