package de.deepforge.game;

public final class Economy {
  public static String buy(Profile p, String action) {
    long cost;
    int level;
    switch (action) {
      case "oreLuck" -> {
        level = p.oreLuck;
        cost = 500L * (level + 1) * (level + 1);
      }
      case "tool" -> {
        level = p.tool;
        cost = 200L * (level + 1) * (level + 1);
      }
      case "sword" -> {
        level = p.sword;
        cost = 250L * (level + 1) * (level + 1);
      }
      case "armor" -> {
        level = p.armor;
        cost = 300L * (level + 1) * (level + 1);
      }
      case "bag" -> {
        level = p.bagLevel;
        cost = 500L * (level + 1) * (level + 1);
      }
      case "warehouse" -> {
        level = p.warehouse;
        cost = 1200L * (level + 1) * (level + 1);
      }
      case "furnace" -> {
        level = p.furnace;
        cost = 1500L * (level + 1) * (level + 1);
      }
      case "housing" -> {
        level = p.housing;
        cost = 3000L * (level + 1) * (level + 1);
      }
      default -> {
        return "Unbekanntes Upgrade.";
      }
    }
    int max =
        switch (action) {
          case "oreLuck" -> 10;
          case "housing" -> 5;
          case "warehouse" -> 8;
          case "furnace" -> 5;
          default -> 20;
        };
    if (level >= max) return "Maximale Stufe erreicht.";
    if (p.money < cost) return "Benötigt " + cost + " $.";
    if ((action.equals("tool") || action.equals("sword")) && level >= 4 && p.relics < 1)
      return "Ab Stufe 5 benötigst du außerdem ein Relikt.";
    p.money -= cost;
    if ((action.equals("tool") || action.equals("sword")) && level >= 4) p.relics--;
    switch (action) {
      case "oreLuck" -> p.oreLuck++;
      case "tool" -> p.tool++;
      case "sword" -> p.sword++;
      case "armor" -> p.armor++;
      case "bag" -> p.bagLevel++;
      case "warehouse" -> p.warehouse++;
      case "furnace" -> p.furnace++;
      case "housing" -> p.housing++;
    }
    return "Verbessert! Kosten: " + cost + " $.";
  }

  public static long upgradeCost(Profile p, String action) {
    int level =
        switch (action) {
          case "oreLuck" -> p.oreLuck;
          case "tool" -> p.tool;
          case "sword" -> p.sword;
          case "armor" -> p.armor;
          case "bag" -> p.bagLevel;
          case "warehouse" -> p.warehouse;
          case "furnace" -> p.furnace;
          case "housing" -> p.housing;
          default -> 0;
        };
    long base =
        switch (action) {
          case "oreLuck" -> 500;
          case "tool" -> 200;
          case "sword" -> 250;
          case "armor" -> 300;
          case "bag" -> 500;
          case "warehouse" -> 1200;
          case "furnace" -> 1500;
          case "housing" -> 3000;
          default -> 0;
        };
    return base * (level + 1) * (level + 1);
  }

  public static long sell(Profile p) {
    return sell(p, true);
  }

  /** Bars are needed for research and bar contracts, so they can be kept. */
  public static long sell(Profile p, boolean bars) {
    long total = 0;
    for (int z = 0; z < 7; z++) {
      total += (p.bag[z] + p.stock[z]) * Zone.at(z).orePrice;
      p.bag[z] = p.stock[z] = 0;
      if (!bars) continue;
      p.soldBars += p.bars[z];
      total += p.bars[z] * Zone.at(z).barPrice;
      p.bars[z] = 0;
    }
    p.money += total;
    p.lifetimeRevenue += total;
    return total;
  }

  public static long deposit(Profile p) {
    long moved = 0, space = p.stockCapacity() - p.stockUsed();
    for (int z = 0; z < 7; z++) {
      long n = Math.min(space, p.bag[z]);
      p.bag[z] -= n;
      p.stock[z] += n;
      space -= n;
      moved += n;
    }
    p.depositedOre += moved;
    return moved;
  }

  public static String hire(Profile p, Profile.Job job) {
    if (!p.bosses[0]) return "Besiege zuerst den Steinwächter in der Eisenmine.";
    if (p.workers.size() >= p.workerSlots()) return "Baue zuerst die Unterkunft aus.";
    if (job == Profile.Job.SMELTER && p.furnace == 0) return "Baue zuerst eine Schmelze.";
    if (job == Profile.Job.TRADER && p.zone < 1)
      return "Händler benötigen Zugang zur Kristallhöhle.";
    long cost = 1500L * (p.workers.size() + 1);
    if (p.money < cost) return "Benötigt " + cost + " $.";
    String[] names = {"Borin", "Mira", "Tarek", "Nora", "Finn", "Yara"};
    p.money -= cost;
    p.workers.add(new Profile.Worker(names[(p.workerSerial++) % names.length], job, p.zone));
    return "Arbeiter eingestellt. Brennstoff und Betriebsbudget bereitstellen!";
  }

  public static String nextZone(Profile p) {
    if (p.zone >= 6) return "Alle Gebiete erschlossen.";
    Zone next = Zone.at(p.zone + 1);
    if (!p.bosses[p.zone]) return "Besiege zuerst den Gebiets-Boss.";
    if (p.tool < next.toolRequired) return "Benötigt Werkzeugstufe " + next.toolRequired + ".";
    if (p.money < next.unlockCost) return "Benötigt " + next.unlockCost + " $.";
    p.money -= next.unlockCost;
    p.zone++;
    return next.title + " freigeschaltet!";
  }

  public static String order(Profile p) {
    int z = p.zone;
    long required = 80 + (p.orders % 4) * 40L;
    if (p.bag[z] + p.stock[z] < required)
      return "Benötigt " + required + " " + Zone.at(z).oreName + " im Rucksack/Lager.";
    long fromBag = Math.min(required, p.bag[z]);
    p.bag[z] -= fromBag;
    p.stock[z] -= required - fromBag;
    long reward = required * Zone.at(z).orePrice * 3 / 2;
    p.money += reward;
    p.lifetimeRevenue += reward;
    p.orders++;
    if (p.orders % 5 == 0) p.relics++;
    return "Lieferung abgeschlossen: +" + reward + " $. Jeder fünfte Auftrag gibt ein Relikt.";
  }

  public static String quest(Profile p) {
    boolean ready =
        switch (p.quest) {
          case 0 -> p.mined >= 32;
          case 1 -> p.tool >= 1;
          case 2 -> p.mined >= 100;
          case 3 -> p.bosses[0];
          case 4 -> !p.workers.isEmpty();
          case 5 -> p.zone >= 1;
          case 6 -> p.furnace >= 1;
          case 7 -> p.orders >= 5;
          default -> false;
        };
    if (!ready) return "Ziel noch nicht erreicht: " + questText(p.quest);
    long reward = 500L * (p.quest + 1);
    p.money += reward;
    p.relics += p.quest >= 3 ? 1 : 0;
    p.quest++;
    return "Meilenstein erreicht: +" + reward + " $.";
  }

  public static String questText(int q) {
    return switch (q) {
      case 0 -> "Baue 32 Erze selbst ab";
      case 1 -> "Verbessere dein Werkzeug";
      case 2 -> "Baue insgesamt 100 Erze ab";
      case 3 -> "Besiege den Steinwächter";
      case 4 -> "Stelle deinen ersten Arbeiter ein";
      case 5 -> "Erschließe die Kristallhöhle";
      case 6 -> "Baue eine Schmelze";
      case 7 -> "Erfülle fünf Lieferaufträge";
      default -> "Erschließe alle sieben Gebiete";
    };
  }

  private Economy() {}
}
