package de.deepforge.game;

import java.util.*;
import java.util.random.RandomGenerator;

/**
 * Begleiter: very rare eggs (rarity like gear) hatch at the camp's brooding place, the rarer the
 * longer. A hatched companion follows its owner and gives one bonus that grows with rarity and level.
 */
public final class Companions {
  public static final int INCUBATORS = 2, MAX_EGGS = 20, MAX_LEVEL = 10;
  public static final long MINUTE = 60_000L;

  public enum Species {
    PANZERKAEFER("Panzerkäfer", "Rüstung"),
    FLINKLING("Flinkling", "Angriffstempo"),
    BLUTEGEL("Blutegel", "heilt dich bei jedem Sieg"),
    GLUTLING("Glutling", "Schaden"),
    FROSTLING("Frostling", "Krit-Chance"),
    FELSRIESE("Felsriese", "Leben"),
    ERZSCHNUEFFLER("Erzschnüffler", "Abbautempo und Doppel-Erz");
    public final String title, bonus;

    Species(String title, String bonus) {
      this.title = title;
      this.bonus = bonus;
    }
  }

  public static final class Egg {
    public String id = UUID.randomUUID().toString();
    public Gear.Rarity rarity = Gear.Rarity.UNCOMMON;
    public long foundAt;
    // 0 = not brooding; otherwise the moment it may hatch.
    public long hatchAt;
    public int incubator = -1;
  }

  public static final class Companion {
    public String id = UUID.randomUUID().toString();
    public Species species = Species.PANZERKAEFER;
    public Gear.Rarity rarity = Gear.Rarity.UNCOMMON;
    public int level = 1;
  }

  private Companions() {}

  static List<Egg> eggs(Profile p) {
    if (p.eggs == null) p.eggs = new ArrayList<>();
    return p.eggs;
  }

  static List<Companion> pets(Profile p) {
    if (p.companions == null) p.companions = new ArrayList<>();
    return p.companions;
  }

  // --- drops ---
  public static final double CHAMPION = .01, BOSS = .03, DUNGEON = .015, MONSTER = .0002;

  /** Egg rarity: 55 % ungewöhnlich, 28 % selten, 12 % episch, 4,5 % legendär, 0,5 % mythisch. */
  public static Gear.Rarity rollRarity(RandomGenerator r) {
    double x = r.nextDouble();
    if (x < .005) return Gear.Rarity.MYTHIC;
    if (x < .05) return Gear.Rarity.LEGENDARY;
    if (x < .17) return Gear.Rarity.EPIC;
    if (x < .45) return Gear.Rarity.RARE;
    return Gear.Rarity.UNCOMMON;
  }

  /** Rolls a drop with the given chance; returns the new egg or null (also when the nest is full). */
  public static Egg maybeDrop(Profile p, double chance, RandomGenerator r, long now) {
    if (r.nextDouble() >= chance || eggs(p).size() >= MAX_EGGS) return null;
    Egg egg = new Egg();
    egg.rarity = rollRarity(r);
    egg.foundAt = now;
    eggs(p).add(egg);
    return egg;
  }

  /** Brooding time: 30 min, 1 h, 3 h, 6 h, 12 h from ungewöhnlich to mythisch. */
  public static long hatchMinutes(Gear.Rarity rarity) {
    return switch (rarity) {
      case UNCOMMON -> 30;
      case RARE -> 60;
      case EPIC -> 180;
      case LEGENDARY -> 360;
      case MYTHIC -> 720;
    };
  }

  public static Egg egg(Profile p, String id) {
    return eggs(p).stream().filter(e -> e.id.equals(id)).findFirst().orElse(null);
  }

  public static Egg brooding(Profile p, int incubator) {
    return eggs(p).stream().filter(e -> e.incubator == incubator).findFirst().orElse(null);
  }

  public static String brood(Profile p, String eggId, long now) {
    Egg egg = egg(p, eggId);
    if (egg == null) return "Ei nicht gefunden.";
    if (egg.incubator >= 0) return "Dieses Ei wird schon ausgebrütet.";
    for (int i = 0; i < INCUBATORS; i++)
      if (brooding(p, i) == null) {
        egg.incubator = i;
        egg.hatchAt = now + hatchMinutes(egg.rarity) * MINUTE;
        return egg.rarity.title + "es Ei liegt im Brutnest " + (i + 1) + " · schlüpft in "
            + time(hatchMinutes(egg.rarity) * MINUTE) + ".";
      }
    return "Beide Brutnester sind belegt.";
  }

  public static boolean ready(Egg egg, long now) {
    return egg.incubator >= 0 && now >= egg.hatchAt;
  }

  /** The species is decided by the egg itself, so it cannot be re-rolled. */
  public static String hatch(Profile p, int incubator, long now) {
    Egg egg = brooding(p, incubator);
    if (egg == null) return "Das Brutnest ist leer.";
    if (!ready(egg, now)) return "Noch " + time(egg.hatchAt - now) + " bis es schlüpft.";
    Species[] all = Species.values();
    Companion c = new Companion();
    c.species = all[Math.floorMod(UUID.fromString(egg.id).getLeastSignificantBits(), all.length)];
    c.rarity = egg.rarity;
    eggs(p).remove(egg);
    pets(p).add(c);
    if (p.activeCompanion == null) p.activeCompanion = c.id;
    return "Geschlüpft: " + name(c) + "! Bonus: " + describe(c);
  }

  public static Companion companion(Profile p, String id) {
    return pets(p).stream().filter(c -> c.id.equals(id)).findFirst().orElse(null);
  }

  public static Companion active(Profile p) {
    return p.activeCompanion == null ? null : companion(p, p.activeCompanion);
  }

  public static String activate(Profile p, String id) {
    Companion c = companion(p, id);
    if (c == null) return "Begleiter nicht gefunden.";
    if (id.equals(p.activeCompanion)) {
      p.activeCompanion = null;
      return name(c) + " ruht sich aus.";
    }
    p.activeCompanion = id;
    return name(c) + " begleitet dich jetzt.";
  }

  public static long feedParts(Companion c) {
    return 4L * c.level;
  }

  public static long feedMoney(Companion c) {
    return 500L * c.level * c.level * (c.rarity.ordinal() + 1);
  }

  /** 0.22.0: feeding grows with the player's mine – the bonus is a share of a bigger income. */
  public static long feedMoney(Profile p, Companion c) {
    return Math.round(feedMoney(c) * Economy.lateScale(p.zone));
  }

  /** Feeding: monster parts (from any mine) and money raise the level up to 10. */
  public static String feed(Profile p, String id) {
    Companion c = companion(p, id);
    if (c == null) return "Begleiter nicht gefunden.";
    if (c.level >= MAX_LEVEL) return name(c) + " ist schon auf Stufe " + MAX_LEVEL + ".";
    long parts = feedParts(c), money = feedMoney(p, c);
    long have = Arrays.stream(p.monsterParts).sum();
    if (have < parts || p.money < money)
      return "Füttern braucht " + parts + " Monsterteile und " + money + " $ (du hast " + have + " Teile).";
    long left = parts;
    for (int z = 0; z < p.monsterParts.length && left > 0; z++) {
      long take = Math.min(left, p.monsterParts[z]);
      p.monsterParts[z] -= take;
      left -= take;
    }
    p.money -= money;
    c.level++;
    return name(c) + " ist jetzt Stufe " + c.level + ": " + describe(c) + ".";
  }

  public static String release(Profile p, String id) {
    Companion c = companion(p, id);
    if (c == null) return "Begleiter nicht gefunden.";
    pets(p).remove(c);
    if (id.equals(p.activeCompanion)) p.activeCompanion = null;
    long dust = 10L * (c.rarity.ordinal() + 1) * c.level;
    p.dust += dust;
    return name(c) + " ist frei. Zum Abschied: +" + dust + " Schmiedestaub.";
  }

  public static String name(Companion c) {
    return c.rarity.title + "er " + c.species.title;
  }

  /** Rarity factor 1–2,2 and +10 % per level above 1. */
  public static double power(Companion c) {
    return c.rarity.factor * (1 + .1 * (c.level - 1));
  }

  public static double value(Companion c) {
    double f = power(c);
    return switch (c.species) {
      case PANZERKAEFER -> 6 * f;
      case FLINKLING -> .08 * f;
      case BLUTEGEL -> .02 * f;
      case GLUTLING -> .04 * f;
      case FROSTLING -> .02 * f;
      case FELSRIESE -> 8 * f;
      case ERZSCHNUEFFLER -> .05 * f;
    };
  }

  public static String describe(Companion c) {
    double v = value(c);
    return switch (c.species) {
      case PANZERKAEFER -> String.format(Locale.GERMAN, "+%.1f Rüstung", v);
      case FLINKLING -> String.format(Locale.GERMAN, "+%.1f %% Angriffstempo", v / 1.6 * 100);
      case BLUTEGEL -> String.format(Locale.GERMAN, "heilt %.1f %% Leben bei jedem Sieg", v * 100);
      case GLUTLING -> String.format(Locale.GERMAN, "+%.1f %% Schaden", v * 100);
      case FROSTLING -> String.format(Locale.GERMAN, "+%.1f %% Krit-Chance", v * 100);
      case FELSRIESE -> String.format(Locale.GERMAN, "+%.1f Leben", v);
      case ERZSCHNUEFFLER ->
          String.format(Locale.GERMAN, "+%.1f %% Abbautempo, +%.1f %% Doppel-Erz", v * 100, v * 60);
    };
  }

  /** Bonus of the active companion if it is of this species, else 0. */
  public static double bonus(Profile p, Species species) {
    Companion c = active(p);
    return c == null || c.species != species ? 0 : value(c);
  }

  public static String time(long ms) {
    long min = Math.max(0, (ms + MINUTE - 1) / MINUTE);
    return min >= 60 ? min / 60 + " h " + min % 60 + " min" : min + " min";
  }
}
