package de.deepforge.game;

/** Login routing is shared by first joins, returning players and server restarts. */
public final class JoinFlow {
  private JoinFlow() {}

  public enum Route {
    NONE,
    RESUME,
    START
  }

  public static Route route(
      boolean permitted, boolean active, boolean enrolled, boolean inWorld, boolean autoJoin) {
    if (!permitted || active) return Route.NONE;
    if (enrolled && inWorld) return Route.RESUME;
    return autoJoin ? Route.START : Route.NONE;
  }
}
