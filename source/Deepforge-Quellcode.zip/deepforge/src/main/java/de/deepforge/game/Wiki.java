package de.deepforge.game;

import java.util.*;

/**
 * In-game wiki (0.10.0): every system, item and chance, generated from the game's own numbers
 * so it can never drift from the rules. The UI shows each page as a dialog window: an intro, a
 * list of entries with an icon each, and buttons to the sub-pages.
 */
public final class Wiki {
  private Wiki() {}

  /** One explained thing: an icon (item model key + vanilla fallback), a title and the facts. */
  public record Entry(String model, String material, String title, List<String> lines) {}

  public record Page(
      String id, String title, String model, String material, String parent, List<String> intro,
      List<Entry> entries, List<String> children) {}

  private static final Map<String, Page> PAGES = new LinkedHashMap<>();

  public static Page page(String id) {
    if (PAGES.isEmpty()) build();
    return PAGES.getOrDefault(id, PAGES.get("home"));
  }

  public static Collection<Page> all() {
    if (PAGES.isEmpty()) build();
    return PAGES.values();
  }

  // ---- building helpers ----

  private static final class B {
    final String id, title, model, material, parent;
    final List<String> intro = new ArrayList<>();
    final List<Entry> entries = new ArrayList<>();
    final List<String> children = new ArrayList<>();

    B(String id, String title, String model, String material, String parent) {
      this.id = id;
      this.title = title;
      this.model = model;
      this.material = material;
      this.parent = parent;
    }

    B intro(String... lines) {
      intro.addAll(List.of(lines));
      return this;
    }

    B e(String model, String material, String title, String... lines) {
      entries.add(new Entry(model, material, title, List.of(lines)));
      return this;
    }

    void done() {
      PAGES.put(id, new Page(id, title, model, material, parent, List.copyOf(intro), List.copyOf(entries), children));
      if (parent != null && PAGES.containsKey(parent)) PAGES.get(parent).children().add(id);
    }
  }

  private static B page(String id, String title, String model, String material, String parent) {
    return new B(id, title, model, material, parent);
  }

  static String n(double v) {
    if (Math.abs(v - Math.rint(v)) < 1e-9 && Math.abs(v) < 1e15)
      return String.format(Locale.GERMAN, "%,d", (long) Math.rint(v));
    return String.format(Locale.GERMAN, "%,.1f", v);
  }

  static String pct(double fraction) {
    return n(Math.round(fraction * 1000) / 10.0) + " %";
  }

  // ---- content ----

  private static void build() {
    home();
    start();
    mines();
    mining();
    combat();
    gear();
    runes();
    star();
    dungeons();
    deep();
    bosses();
    pets();
    mastery();
    prestige();
    alchemy();
    museum();
    progress();
    business();
    forest();
    guilds();
    upgrades();
    events();
    commands();
  }

  private static void home() {
    page("home", "Deepforge-Wiki", "wiki", "KNOWLEDGE_BOOK", null)
        .intro(
            "Willkommen im Bergwerk! Hier steht alles, was es in Deepforge gibt: jedes Gebiet, jeder Gegenstand, jede Chance.",
            "Wähle unten ein Thema. Jede Seite hat ihre Einträge mit Symbol; ◀ Zurück bringt dich eine Ebene hoch.",
            "Tipp: Der Hilfe-Knopf (Buch unten rechts) in jedem Menü öffnet direkt die passende Wiki-Seite.")
        .done();
  }

  private static void start() {
    page("start", "Erste Schritte", "handbook", "BOOK", "home")
        .intro("Deepforge ist ein Bergwerk-Abenteuer: abbauen, verbessern, kämpfen, tiefer vordringen.")
        .e("drill", "IRON_PICKAXE", "1 · Erz abbauen",
            "Nimm den Dampfbohrer (Slot 1) und bau die leuchtenden Erzadern in der Mine ab.",
            "Erz landet im Rucksack. Ist er voll, lagere am Grubendepot oder im Dorf ein.")
        .e("coin", "GOLD_INGOT", "2 · Verkaufen & verbessern",
            "Im Handel verkaufst du Erz und Barren. Mit dem Geld verbesserst du Bohrer, Klinge und Schutz.",
            "Ab Stufe 5 brauchen Bohrer und Klinge pro Stufe zusätzlich ein Relikt.")
        .e("weapon_sword", "IRON_SWORD", "3 · Kämpfen",
            "Minenmonster greifen dich an. Linksklick schlägt, Rechtsklick nutzt die Waffenfähigkeit,",
            "Sneak + Rechtsklick ist eine Ausweichrolle. Besiege den Gebietsboss am Altar.")
        .e("scanner", "MINECART", "4 · Tiefer vordringen",
            "Nach dem Gebietsboss schaltest du im Aufzug das nächste Gebiet frei (Geld + Bohrerstufe).",
            "Es gibt " + Zone.COUNT + " Gebiete, das letzte ist der Weltenkern.")
        .e("handbook", "MAP", "Dein roter Faden",
            "„Nächstes Ziel“ im Hauptmenü zeigt immer, was als Nächstes sinnvoll ist, und belohnt dich.",
            "Das Tutorial (/df tutorial) führt Schritt für Schritt mit Belohnungen durch die Grundlagen.")
        .done();
  }

  private static void mines() {
    B b = page("mines", "Minen & Gebiete", "ore_iron", "RAW_IRON", "home")
        .intro(
            "17 Minen, jede mit eigenem Erz, eigener Höhlenform, eigenen Monstern und Boss.",
            "Gebiete 1–7 liegen im ersten Schacht, 8–17 im Tiefen Schacht daneben. Klicke ein Gebiet für Details.");
    for (Zone z : Zone.values())
      b.e("ore_" + z.key, "RAW_IRON", (z.ordinal() + 1) + " · " + z.title,
          z.oreName + " · " + n(z.orePrice) + " $ / Barren " + n(z.barPrice) + " $",
          "Bohrer ab Stufe " + z.toolRequired + (z.unlockCost > 0 ? " · Freischalten " + n(z.unlockCost) + " $" : " · Startgebiet"),
          "Boss: " + BossRules.NAMES[z.ordinal()]);
    b.done();
    for (Zone z : Zone.values()) {
      int i = z.ordinal();
      B p = page("mine/" + i, (i + 1) + " · " + z.title, "ore_" + z.key, "RAW_IRON", "mines")
          .intro(
              z.title + (i >= Zone.FIRST_DEEP ? " liegt im Tiefen Schacht." : " liegt im ersten Schacht."),
              "Höhlenform: " + new String[] {"Hauptkaverne", "Zwillingshallen", "Kammerlabyrinth", "Große Kluft"}[i % 4]
                  + ((i / 4) % 2 == 1 ? " (gespiegelt)" : ""));
      p.e("ore_" + z.key, "RAW_IRON", z.oreName,
          "Verkauf: " + n(z.orePrice) + " $ pro Erz · " + n(z.barPrice) + " $ pro Barren (2 Erze + 1 Brennstoff)",
          "Bohrer-Mindeststufe: " + z.toolRequired + " · Freischalten: " + (z.unlockCost == 0 ? "frei" : n(z.unlockCost) + " $"));
      p.e("mob_" + i + "_head", "ZOMBIE_HEAD", "Monster",
          "Leben: " + n(Math.round(MonsterScaling.health(i, 0))) + " (Brute ×1,8)",
          "Angriff: " + n(Math.round(MonsterScaling.attack(false, i, 0) * 10) / 10.0)
              + " · Berührung: " + n(Math.round(MonsterScaling.touch(i) * 10) / 10.0),
          "Bis zu " + MonsterScaling.MAX_MONSTERS + " gleichzeitig pro Spieler, alle " + MonsterScaling.SPAWN_TICKS / 20 + " s neue.");
      p.e("relic", "NETHER_STAR", "Boss · " + BossRules.NAMES[i],
          "Leben: normal " + n(Math.round(RapidCombat.bossHealth(i, 0)))
              + " · Veteran " + n(Math.round(RapidCombat.bossHealth(i, 1)))
              + " · Albtraum " + n(Math.round(RapidCombat.bossHealth(i, 2))),
          "Angriffe: " + n(Math.round(MonsterScaling.attack(true, i, 0) * 10) / 10.0) + " Schaden (normal), +30 % je Schwierigkeit.",
          "Zeitlimit " + RapidCombat.BOSS_TIME_MINUTES + " Minuten. Veteran und Albtraum erst nach dem Sieg davor.",
          i == Zone.LAST ? "Nach einem Albtraum-Sieg erwacht mit 1 % der Urboss (siehe Sternenstein)." : "");
      if (Zone.hazardArmor(i) > 0)
        p.e("shield", "SHIELD", "Gefahr",
            z.hazard() + ": alle 5 s Schaden, außer mit Schutztraining Stufe " + Zone.hazardArmor(i) + ".");
      if (i == 4 || i == 7)
        p.e("fuel", "MAGMA_BLOCK", "Hitze", "Der Bohrer überhitzt hier schneller. Kühlsystem-Talent und Forschung helfen.");
      p.e("unique_" + (i % 7), "DIAMOND_SWORD", "Benannter Gegenstand · " + Gear.UNIQUE[i],
          Gear.effect(i % 7),
          "Herstellen: 40 Bossfragmente + 30 " + Gear.MATERIALS[i] + " + " + n(Gear.craftCost(i)) + " $ (Beutebuch).",
          "Oder 2 % pro Bosssieg (Albtraum zusätzlich 0,2 % mythisch).");
      p.done();
    }
  }

  private static void mining() {
    page("mining", "Bergbau & Bohrer", "drill", "IRON_PICKAXE", "home")
        .intro("Alles rund ums Abbauen, den Dampfbohrer und dein Erz.")
        .e("drill", "IRON_PICKAXE", "Dampfbohrer",
            "Jede Stufe +12 % Tempo und läuft kühler. Stufe " + Economy.MAX_TOOL + " ist das Maximum.",
            "Kosten: 200 $ × (Stufe+1)², ab Stufe 20 jede Stufe ×2,5. Ab Stufe 5 zusätzlich 1 Relikt.",
            "Jede Mine fühlt sich auf ihrer Mindeststufe gleich schnell an.")
        .e("fuel", "BLAZE_POWDER", "Hitze & Überladung",
            "Beim Abbauen steigt die Hitze. Bei 100 % überhitzt der Bohrer kurz.",
            "Rechtsklick mit dem Bohrer: Überladung – doppeltes Tempo, aber viel mehr Hitze.")
        .e("ore_crystal", "RAW_GOLD", "Doppel-Erz & Glück",
            "Erzglück (Upgrade) und Ausrüstung mit Extra-Erz geben Chancen auf doppeltes Erz.",
            "Talent Erzflut: 5 % Chance, dass ein Block dreifach gibt.")
        .e("crate", "CHEST", "Rucksack & Lager",
            "Rucksack: +150 Plätze pro Stufe. Grubendepot in jeder Mine bringt Erz ins Betriebslager.",
            "Lager: +960 Plätze pro Stufe. Bei Tod verlierst du 10 % des Rucksack-Erzes, Lager und Geld nie.")
        .e("relic", "AMETHYST_SHARD", "Reiche Adern & Sammlung",
            "Reiche Ader: Lichtsäule in der Mine, der Erste bekommt 4× Erz und Staub.",
            "Erzsammlung je Gebiet: 500 / 2.000 / 10.000 selbst abgebaute Erze geben Relikte.")
        .e("crate", "CHEST", "Versteckte Fundkisten",
            "3 Kisten in seitlichen Stollen jeder Mine. Je Fund Geld, Unterlagen, Staub; alle drei: +1 Relikt.")
        .done();
  }

  private static void combat() {
    page("combat", "Kampf & Werte", "weapon_sword", "IRON_SWORD", "home")
        .intro("So funktioniert der Kampf und was jeder Wert bedeutet.")
        .e("weapon_sword", "IRON_SWORD", "Treffer & Kombo",
            "Jeder Klick trifft. Schneller klicken hält die Kombo: +3 % Schaden pro Treffer, max. +30 %.",
            "Waffentempo erhöht den Schaden pro Treffer statt Wartezeit.")
        .e("weapon_hammer", "IRON_AXE", "Waffenarten",
            "Schwert: ausgewogen · Hammer: viel Haltungsschaden · Dolch: Rückenstich-Bonus",
            "Speer: 4 Blöcke Reichweite · Armbrust: Fernkampf. Jede Waffe hat eine feste Rechtsklick-Fähigkeit.")
        .e("star_stone", "NETHER_STAR", "Krit-Chance & Krit-Schaden",
            "Basis 5 % Krit. Jeder Gegenstand kann Krit-Chance haben (pro Teil je nach Rarität bis ~15 %).",
            "Alles wird addiert, keine Obergrenze: ab 100 % trifft jeder Schlag kritisch (Überschuss wird Krit-Schaden).",
            "Nur die Glücksrunen zusammen geben höchstens +10 %.")
        .e("shield", "SHIELD", "Rüstung & Leben",
            "Schadensreduktion = Rüstung ÷ (Rüstung + 100), höchstens 60 %.",
            "Leben: 20 Basis + Ausrüstung, gedeckelt durch deinen besten Dungeon-Rang (60 + 2 pro Rang); Runen, Talente, Gilde, Begleiter kommen oben drauf.")
        .e("clock", "CLOCK", "Ausweichen & Ausdauer",
            "Sneak + Rechtsklick: Rolle mit kurzer Unverwundbarkeit. Fähigkeiten kosten 35 Ausdauer.")
        .e("healing_crystal", "AMETHYST_SHARD", "Lebenssplitter (Heilen)",
            "Heilt 4 + 35 % deines Lebens, 20 s Pause. Start: " + Healing.START + " Plätze, mit Heiltasche bis " + Healing.CAPACITY + ".",
            "Kauf " + Healing.PRICE + " $ (Rechtsklick), nicht im Dungeon/Tiefengang. Monster lassen ab und zu welche fallen.")
        .e("weapon_spear", "TRIDENT", "Waffenfähigkeiten (Rechtsklick)",
            abilityLines())
        .done();
  }

  private static String[] abilityLines() {
    List<String> out = new ArrayList<>();
    for (WeaponAbilities.Ability a : WeaponAbilities.Ability.values())
      out.add(a.title + " (" + CharacterSheet.styleName(a.style) + "): " + a.effect);
    out.add("Episch+: heilt pro Treffer · Legendär+: 25 % kürzere Abklingzeit · Mythisch: Echo-Schlag.");
    return out.toArray(String[]::new);
  }

  private static void gear() {
    page("gear", "Ausrüstung & Beute", "gear_chest", "IRON_CHESTPLATE", "home")
        .intro("Beute kommt aus Bossen, Dungeons, Monstern, Kisten und dem Tiefengang. Alles liegt im Beutel (/df loot).")
        .e("gear_chest", "IRON_CHESTPLATE", "Raritäten",
            "Ungewöhnlich ×1 · Selten ×1,3 · Episch ×1,65 (1 Sockel) · Legendär ×2 (2 Sockel) · Mythisch ×2,2 (2 Sockel)",
            "Qualität 80–100 % multipliziert zusätzlich. Tiefere Gebiete geben stärkere Grundwerte.")
        .e("relic", "NETHER_STAR", "Boss-Beute",
            "Pro Bosssieg: 60 % ungewöhnlich · 30 % selten · 9 % episch · 1 % legendär.",
            "Spätestens der 10. erfolglose Wurf wird episch. Dazu 2 % benannter Gegenstand, Albtraum 0,2 % mythisch.")
        .e("crate", "CHEST", "Dungeon-Beute",
            "Garantiert selten oder besser. Episch ab 30 %, Legendär ab 5 %, Mythisch ab 0,5 % – steigt mit Schwierigkeit und Level.",
            "Stärke: +6 % pro Dungeon-Level bis 31, danach +2 %.")
        .e("coin", "GOLD_INGOT", "Aufwerten (+1 bis +10)",
            "+8 % Grundwerte pro Stufe. Kosten: 250 $ × (Gebiet+1) × (Stufe+1) und Staub.",
            "+11 nur mit Sternenstein.")
        .e("relic", "AMETHYST_SHARD", "Krit neu schmieden",
            "3 günstige Versuche pro Wert (×1, ×3, ×9 Kosten), danach unbezahlbar.")
        .e("preset", "ARMOR_STAND", "Sets",
            "Speichere Ausrüstung als Set (z. B. Mining, Dungeon) und wechsle mit einem Klick.")
        .e("sort", "COMPARATOR", "Beutel",
            "Sortieren: Neueste, nach Art, nach Rarität. Shift-Klick wählt mehrere zum Verkaufen/Zerlegen.",
            "Zerlegen gibt Schmiedestaub. Favoriten, angelegte und Set-Teile sind geschützt. Max. 120 Teile.")
        .done();
  }

  private static void runes() {
    B b = page("runes", "Runen", "rune_bag", "AMETHYST_CLUSTER", "home")
        .intro(
            "Runen kommen in Ausrüstungs-Sockel und zählen direkt zu deinen Grundwerten.",
            "3 gleiche Runen + Staub ergeben eine Stufe höher (bis V). Pro Art zählen die 6 stärksten.");
    String[] keys = {"rune_kraft", "rune_stein", "rune_leben", "rune_wind", "rune_glueck", "rune_tiefe"};
    for (Runes.Kind k : Runes.Kind.values())
      b.e(keys[k.ordinal()], "AMETHYST_SHARD", k.title + " · " + k.stat,
          "Stufe I: " + Runes.effect(Runes.code(k, 1), 0) + " · Stufe V: " + Runes.effect(Runes.code(k, 5), 0),
          switch (k) {
            case KRAFT, STEIN, LEBEN -> "Wächst mit dem Gebiet des Gegenstands: Weltenkern-Teile ×3,4.";
            default -> "Obergrenze: " + pct(Runes.cap(k)) + (k == Runes.Kind.WIND ? " Tempo (÷1,6 = Prozent)" : "");
          });
    b.e("relic", "NETHER_STAR", "Fundchancen",
        "Minenmonster " + pct(Runes.MONSTER) + " · Champion " + pct(Runes.CHAMPION) + " · Minenboss " + pct(Runes.BOSS),
        "Dungeon-Sieg " + pct(Runes.DUNGEON) + " · Tiefengang-Boss-Ebene " + pct(Runes.DEEP_BOSS) + " · Urboss 2 sicher",
        "Tiefere Gebiete geben höhere Stufen (Gebiet 1: I–II, Leerenbruch: IV–V).")
        .e("drill", "IRON_PICKAXE", "Sockel bohren",
            "Episch 1, Legendär/Mythisch 2 Sockel ab Werk. Selten/Ungewöhnlich: 1 Sockel bohrbar.",
            "Herauslösen kostet 3 Staub pro Stufe, die Rune kommt zurück.");
    b.done();
  }

  private static void star() {
    page("star", "Sternenstein & Urboss", "star_stone", "NETHER_STAR", "home")
        .intro("Das seltenste Endgame: Gegenstände über das Maximum schmieden.")
        .e("relic", "NETHER_STAR", "Der Urboss",
            "Erwacht mit " + pct(StarStones.URBOSS_CHANCE) + " nach einem Albtraum-Sieg über den " + BossRules.NAMES[Zone.LAST] + " (Weltenkern).",
            "Dreifaches Leben, +50 % Schaden. Beute: doppelte Bossbeute, legendäres Teil (20 % mythisch), 2 Runen, 150 Staub, 250.000 $.")
        .e("star_stone", "NETHER_STAR", "Sternenstein",
            "Nur der Urboss lässt ihn fallen: " + pct(StarStones.DROP) + ".",
            "Anwenden: Gegenstand öffnen → Shift-Klick. " + pct(StarStones.SUCCESS) + " wird er +11, sonst zerbricht er.")
        .e("weapon_sword", "NETHERITE_SWORD", "Sternengeschmiedet (+11)",
            "Doppelte Grundwerte. Waffe: Fähigkeit ×1,5 und Sternenschlag (12 % der Treffer, Flächenschaden).",
            "Rüstung/Schmuck: Sternenschild, jedes Teil blockt 4 % aller Treffer (max. 20 %). Lichtaura für alle sichtbar.")
        .done();
  }

  private static void dungeons() {
    B b = page("dungeons", "Dungeons", "crate", "CHISELED_STONE_BRICKS", "home")
        .intro(
            "Zufällig erzeugte Gewölbe mit Wellen, Rätseln, Nebenräumen und Endboss. Solo oder bis 4 Spieler.",
            "Start: Hauptmenü → Dungeons oder /df dungeon. Heilsplitter vorher auffüllen – drinnen kein Nachkauf!");
    for (DungeonVariant v : DungeonVariant.values())
      b.e(v == DungeonVariant.GEWOELBE ? "crate" : v == DungeonVariant.GLUTSCHMIEDE ? "machine_furnace" : "shield",
          v == DungeonVariant.GEWOELBE ? "CHISELED_STONE_BRICKS" : v == DungeonVariant.GLUTSCHMIEDE ? "MAGMA_BLOCK" : "PACKED_ICE",
          v.title, v.flavor, v.hazard, v.loot, v.requirement().isEmpty() ? "Von Anfang an offen." : v.requirement() + ".");
    b.e("clock", "CLOCK", "Level & Schwierigkeit",
            "Jedes Gebiet hat ein eigenes Dungeon-Level: +1 pro Sieg auf deinem Höchstlevel.",
            "Du kannst jedes niedrigere Level wählen (◀ ▶ im Menü): leichter, weniger Beute, kein Aufstieg.",
            "Gegner: +10 % Leben und +2,5 % Schaden pro Level. Normal / Veteran / Albtraum: +55 % Leben je Stufe.")
        .e("coin", "GOLD_INGOT", "Belohnung",
            "Geld: etwa 90 Erze des Gebiets × Schwierigkeit (1/2/3), +12 % pro Level. Staub, Unterlagen, Monsterteile, 2 Lebenssplitter.",
            "Tagesbonus: der erste Sieg des Tages zahlt das Geld doppelt und +30 Staub.",
            "Rune " + pct(Runes.DUNGEON) + " · Ei " + pct(Companions.DUNGEON) + " · Makellos (kein großer Bosstreffer): +25 % Geld.")
        .e("crate", "CHEST", "Siegeshalle & Gewölbekisten",
            "Nach dem Sieg: Kamerafahrt, MVP, Statistik. Bis zu 3 Gewölbekisten kaufen (2×, 4×, 8× Dungeon-Geld).",
            "Du gehst, wann du willst (Seelenanker oder /df dungeon leave). Halle schließt nach 3 Minuten.")
        .e("relic", "LODESTONE", "Rätsel & Nebenräume",
            "Runenwand, Siegel, Spiegel, Druckplatten, Fallengang. Nebenräume: Elite-Prüfung, Fluch, Gefangenen retten, Schatzkammer mit Schlüssel.",
            "Segensschreine: wähle Kraft, Schutz oder Quelle für den Rest des Laufs.",
            "Veteran: Zeitlimit " + DungeonPuzzles.timeLimit(1) / 20 + " s, längere Folgen, Fehler kosten Leben und rufen Gegner.",
            "Albtraum: nur " + DungeonPuzzles.timeLimit(2) / 20 + " s, KEINE Erklärung an der Wand, kein Hinweis – ihr müsst das Rätsel erkennen.")
        .done();
    guardians();
    dungeonBoss();
  }

  private static void guardians() {
    B b = page("guardians", "Wächter (Minibosse)", "guard_shield", "SHIELD", "dungeons")
        .intro(
            "Wächter bewachen " + Minibosses.count(0) + " Raum (Normal) bzw. " + Minibosses.count(1)
                + " Räume (Veteran/Albtraum). Sie kommen mit der letzten Welle des Raums.",
            "Jeder hat eine Regel – reiner Schaden reicht nicht. Auf Albtraum wird sie nicht angesagt.");
    for (Minibosses.Kind k : Minibosses.Kind.values())
      b.e("guard_" + switch (k) {
            case SHIELD -> "shield";
            case CALLER -> "caller";
            case TWINS -> "twins";
            case MIRROR -> "mirror";
            case CHAIN -> "chain";
            case ROOT -> "root";
          },
          switch (k) {
            case SHIELD -> "SHIELD";
            case CALLER -> "SOUL_LANTERN";
            case TWINS -> "ZOMBIE_HEAD";
            case MIRROR -> "GLASS";
            case CHAIN -> "CHAIN";
            case ROOT -> "MANGROVE_ROOTS";
          },
          k.title, k.wiki);
    b.e("guard_chest", "CHEST", "Wächtertruhe",
            "Jeder Spieler: ¼ des Dungeon-Geldes, 10 + 5 × Schwierigkeit + Gebiet Staub und ein Ausrüstungsteil (mindestens selten).",
            "Wächter haben " + pct(Minibosses.HEALTH) + " des Bosslebens (Zwillinge je " + pct(Minibosses.TWIN_HEALTH) + ") und treffen ×" + n(Minibosses.DAMAGE) + ".")
        .done();
  }

  private static void dungeonBoss() {
    B b = page("dboss", "Endboss & Schwierigkeit", "relic", "WITHER_SKELETON_SKULL", "dungeons")
        .intro("Jeder Angriff wird vorher angezeigt. Alle Angriffe mit Warnung:");
    for (BossPatterns.Attack a : BossPatterns.Attack.values())
      b.e("relic", "NETHER_STAR", a.title + (a.big ? " (groß)" : ""), a.hint);
    b.e("clock", "CLOCK", "Normal · Veteran · Albtraum",
            "Schaden ×1 / ×" + n(BossPatterns.modeDamage(1)) + " / ×" + n(BossPatterns.modeDamage(2))
                + " · Kombos: keine / " + pct(BossPatterns.comboChance(1)) + " (bis 2) / " + pct(BossPatterns.comboChance(2)) + " (bis 3)",
            "Wut nach " + BossPatterns.enrageAfter(0) / 1200 + " / " + BossPatterns.enrageAfter(1) / 1200 + " / " + BossPatterns.enrageAfter(2) / 1200
                + " Min. Auf Albtraum wächst der Wutschaden alle 30 s um 20 %.",
            "Veteran/Albtraum, letzte Phase: der Arenarand brennt und zieht sich zusammen.",
            "Albtraum, letzte Phase: keine Heilung mit Lebenssplittern!",
            "Neue Angriffe: Normal sieht den Meteoritenhagel in Phase 3, Veteran zusätzlich Erdspalten und Blitzkette, Albtraum alle inkl. Todesmarke und Schildphase.")
        .done();
  }

  private static void museum() {
    B b = page("museum", "Archäologie & Museum", "museum", "CHISELED_BOOKSHELF", "home")
        .intro(
            "Jede Mine versteckt 4 Fundstücke – 3 gewöhnliche und 1 seltenes (★). " + Archaeology.ALL.size() + " insgesamt.",
            "Öffnen: Hauptmenü → Museum (unten) oder /df museum. Das Sammlungsbuch zeigt, was noch fehlt (???).");
    b.e("find_tool", "BRUSH", "Finden",
            pct(Archaeology.CHANCE) + " pro abgebautem Erzblock, davon " + pct(Archaeology.RARE_SHARE) + " das seltene Stück der Mine.",
            "Also etwa jedes 125. Erz ein Fund, jedes 1.000. ein seltener. Titel und Chat-Nachricht bei jedem Fund.")
        .e("museum", "CHISELED_BOOKSHELF", "Stiften",
            "Linksklick im Sammlungsbuch: ins Museum. Belohnung: 40 Erze der Mine in Geld (selten ×5) und 5 Staub (selten 25).",
            "Doppelte verkaufen (Rechtsklick): 10 Erze der Mine pro Stück (selten ×5).")
        .e("find_rare", "NETHER_STAR", "Museumsbonus",
            "Jede vollständige Mine (alle 4 gestiftet): dauerhaft +1 % Schaden und +1 % Erz- und Barrenwert.",
            "Alle 17 Minen vollständig: noch einmal +5 % – zusammen +22 %. Bleibt auch nach einem Prestige.");
    for (int z = 0; z < Zone.COUNT; z++) {
      Archaeology.Find rare = Archaeology.find(z, 3);
      b.e("collection_book", "BOOK", (z + 1) + " · " + Zone.at(z).title,
          Archaeology.find(z, 0).name() + " · " + Archaeology.find(z, 1).name() + " · " + Archaeology.find(z, 2).name(),
          "★ " + rare.name() + " – " + rare.story());
    }
    b.done();
  }

  private static void alchemy() {
    B b = page("alchemy", "Alchemie & Tränke", "alchemy_table", "BREWING_STAND", "home")
        .intro(
            "Zutaten sammeln, Tränke brauen, kurz stärker werden. Öffnen: Hauptmenü → Braustand (oben links) oder /df alchemie.",
            "Linksklick auf einen Trank: brauen · Rechtsklick: trinken. Wirkung läuft auch offline weiter ab.");
    for (Alchemy.Ingredient i : Alchemy.Ingredient.values()) b.e(i.model, i.material, i.title, "Quelle: " + i.source + ".");
    for (Alchemy.Potion k : Alchemy.Potion.values())
      b.e(k.model, "POTION", k.title,
          "+" + (k == Alchemy.Potion.FLINK ? n(k.effect) + " " : Math.round(k.effect * 100) + " % ") + k.stat + " für " + k.minutes + " Min. (nachtrinken verlängert, max. " + 2 * k.minutes + " Min.)",
          "Rezept: " + k.recipe[0] + " Schattenessenz, " + k.recipe[1] + " Glutmoos, " + k.recipe[2] + " Waldkraut + Geld (steigt mit dem Gebiet).");
    b.e("alchemy_table", "BREWING_STAND", "Braumeister",
            "Jedes Brauen: +" + Alchemy.XP_PER_BREW + " XP. Stufe n braucht 40 × n² XP, bis Stufe " + Alchemy.MAX_LEVEL + ".",
            "Pro Stufe +2 % Trankstärke · 2 Tränke gleichzeitig, +1 bei Stufe 5, 10, 15, 20 · ab Stufe 10 zwei Tränke pro Brauen.")
        .done();
  }

  private static void prestige() {
    B b = page("prestige", "Prestige & Tiefenglut", "prestige_star", "NETHER_STAR", "home")
        .intro(
            "Nach dem Boss im " + Zone.at(Zone.LAST).title + " kannst du neu beginnen – mit deiner Ausrüstung, aber in einer härteren Welt.",
            "Öffnen: Hauptmenü → Prestige (Stern oben) oder /df prestige. Bestätigen mit SHIFT + Klick.");
    b.e("close", "BARRIER", "Wird zurückgesetzt",
            "Gebiet → Eisenmine, Geld → Startgeld, Erz, Barren, Betriebsbudget, besiegte Gebietsbosse.",
            "Upgrades: Bohrer, Klinge, Schutz, Erzglück, Rucksack, Lager.")
        .e("preset", "CHEST", "Bleibt",
            "Alle Ausrüstung, Runen, Sternensteine, Begleiter, Funke, Meisterschaft, Tiefenpass, Gilde, Dungeon-Level.",
            "Unterkunft, Schmelze, Heiltasche, Forschung, Wald & Holz. Arbeiter ziehen mit in die Eisenmine.")
        .e("prestige_star", "NETHER_STAR", "Pro Prestige",
            "Alle Gegner (Minen, Bosse, Dungeons, Tiefengang): ×" + n(Prestige.HEALTH) + " Leben, ×" + n(Prestige.DAMAGE) + " Schaden – multipliziert.",
            "Neue Beute: ×" + n(Prestige.LOOT) + " Werte (ab dem Fund) · Erz und Barren: +" + Math.round(Prestige.INCOME * 100) + " % Wert.",
            "Prestige 5: Gegner ×" + Prestige.fmt(Prestige.health(5)) + " Leben · Beute ×" + Prestige.fmt(Prestige.loot(5)) + ". Prestige 10: ×" + Prestige.fmt(Prestige.health(10)) + " gegen ×" + Prestige.fmt(Prestige.loot(10)) + ".",
            "Keine Obergrenze: die Gegner wachsen schneller als die Beute – irgendwann schaffst du die Bosse nicht mehr. Wie weit kommst du?")
        .e("coin", "GOLD_BLOCK", "Dungeons in der Gruppe",
            "Es zählt das höchste Prestige der Gruppe – Mitspieler mit weniger Prestige kämpfen mit.",
            "Sterne im Namen (★3, ab 10: ✪10) in Chat, Tabliste und über dem Kopf · Rangliste „Prestige“.");
    for (Prestige.Node node : Prestige.Node.values())
      b.e(node.model, node.material, "Tiefenglut: " + node.title,
          node.effect + (node == Prestige.Node.KAPITAL ? "" : " pro Rang") + " · bis Rang " + Prestige.MAX_RANK + ".",
          "Tiefenglut: 1 pro Prestige, jedes 5. Prestige 2.");
    b.done();
  }

  private static void deep() {
    page("deep", "Tiefengang", "deep_descent", "SCULK_CATALYST", "home")
        .intro("Der endlose Modus: eine Arena, Ebene um Ebene hinab. Freischalten: einen Dungeon gewinnen.")
        .e("deep_descent", "SCULK_CATALYST", "Ablauf",
            "Jede Ebene 2 Wellen (ab Ebene 10: 3). Jede 5. Ebene endet mit einem Boss.",
            "Alle starten in der Eisenmine; alle 5 Ebenen eine Mine tiefer – auch das Gestein der Arena wechselt.")
        .e("mob_6_head", "ZOMBIE_HEAD", "Es wird nie leichter",
            "Gegner-Level +2 pro Ebene, dazu +6 % Leben und +4 % Schaden pro Ebene.",
            "Ebene 20: ×" + n(Math.round(DeepDescent.health(20) * 10) / 10.0) + " Leben · Ebene 40: ×" + n(Math.round(DeepDescent.health(40) * 10) / 10.0))
        .e("coin", "GOLD_INGOT", "Belohnungen",
            "Nach jeder Ebene sofort: Geld und Staub. Boss-Ebenen: 3× Geld, ein Ausrüstungsteil, " + pct(Runes.DEEP_BOSS) + " Rune.",
            "Ende: wenn alle gefallen sind oder mit /df dungeon leave – alles Verdiente bleibt.")
        .e("coin", "GOLD_BLOCK", "Wochen-Rangliste",
            "/df top: tiefste Ebene dieser Woche (Montag 0 Uhr neu) und Allzeit-Rekord.")
        .done();
  }

  private static void bosses() {
    page("bosses", "Bosse & Champions", "relic", "NETHER_STAR", "home")
        .intro("Die großen Gegner und wie man sie schafft.")
        .e("relic", "NETHER_STAR", "Gebietsbosse",
            "Am Altar jeder Mine. Drei Phasen, rote Kreise und orange Strahlen warnen vor Angriffen.",
            "Rückenangriffe provozieren einen Rundumschlag. Haltung brechen (Hammer!) öffnet ein Schwachstellen-Fenster.",
            "Beute: Ausrüstung, Bossfragmente, Monsterteile, Relikte, Geld, " + pct(Runes.BOSS) + " Rune, " + pct(Companions.BOSS) + " Ei.")
        .e("weapon_dagger", "IRON_SWORD", "Champions (✦)",
            "Seltene Elite-Monster in den Minen (" + pct(Champions.CHANCE) + " der Spawns, Championjagd ×4) mit 1–2 Eigenschaften:",
            "Gepanzert (−40 % Schaden) · Rasend · Vampir · Brennend · Frostig · Riese (doppeltes Leben)",
            "Beute: viel Geld, " + pct(Runes.CHAMPION) + " Rune, " + pct(Companions.CHAMPION) + " Ei, 50 % Ausrüstung.")
        .e("weapon_dagger", "IRON_SWORD", "Jagdaufträge",
            "Pro Gebiet: " + Gear.HUNT_TARGET + " normale Monster besiegen, dann abholen: Geld, 3 Staub, 6 Monsterteile.")
        .done();
  }

  private static void pets() {
    B b = page("pets", "Begleiter & Eier", "egg_epic", "SNIFFER_EGG", "home")
        .intro("Sehr seltene Eier ausbrüten – der Begleiter folgt dir und gibt einen Bonus.");
    b.e("egg_uncommon", "EGG", "Wo gibt es Eier?",
        "Minenboss " + pct(Companions.BOSS) + " · Urboss " + pct(Companions.BOSS * 3) + " · Dungeon-Sieg " + pct(Companions.DUNGEON),
        "Champion " + pct(Companions.CHAMPION) + " · normales Minenmonster " + pct(Companions.MONSTER) + " (1 zu 5.000)",
        "Du kannst bis zu " + Companions.MAX_EGGS + " Eier aufbewahren.");
    for (Gear.Rarity r : Gear.Rarity.values())
      b.e("egg_" + r.name().toLowerCase(Locale.ROOT), "EGG", r.title + "es Ei",
          "Chance: " + switch (r) {
                case UNCOMMON -> "55 %";
                case RARE -> "28 %";
                case EPIC -> "12 %";
                case LEGENDARY -> "4,5 %";
                case MYTHIC -> "0,5 %";
              } + " · Brutzeit " + (Companions.hatchMinutes(r) < 60 ? Companions.hatchMinutes(r) + " Min." : Companions.hatchMinutes(r) / 60 + " h"),
          "Stärke ×" + n(r.factor) + " (Begleiter-Bonus).");
    for (Companions.Species s : Companions.Species.values()) {
      Companions.Companion c = new Companions.Companion();
      c.species = s;
      c.rarity = Gear.Rarity.UNCOMMON;
      c.level = 1;
      String low = Companions.describe(c);
      c.rarity = Gear.Rarity.MYTHIC;
      c.level = Companions.MAX_LEVEL;
      b.e("pet_" + s.name().toLowerCase(Locale.ROOT), "SNIFFER_EGG", s.title,
          "Bonus: " + s.bonus, "Ungewöhnlich St. 1: " + low + " · Mythisch St. " + Companions.MAX_LEVEL + ": " + Companions.describe(c));
    }
    b.e("egg_epic", "HAY_BLOCK", "Brüten & Füttern",
        Companions.INCUBATORS + " Brutnester am Camp. Die Brutzeit läuft auch offline.",
        "Füttern mit Monsterteilen und Geld: +10 % Bonus pro Stufe bis Stufe " + Companions.MAX_LEVEL + ". Ein Begleiter ist aktiv.");
    b.done();
  }

  private static void mastery() {
    B b = page("mastery", "Meisterschaft & Talente", "mastery", "EXPERIENCE_BOTTLE", "home")
        .intro("Eigene, dauerhafte Meisterschafts-XP für alles, was du tust. Jede Stufe = 1 Talentpunkt.",
            "Schlüsseltalente (★) brauchen 8 Punkte im Baum. Zurücksetzen: 1.000 $ pro Punkt.");
    for (Talents.Tree t : Talents.Tree.values()) {
      List<String> lines = new ArrayList<>();
      for (Talents.Node node : Talents.Node.values())
        if (node.tree == t) lines.add((node.key() ? "★ " : "") + node.title + ": " + node.perRank + (node.max > 1 ? " (×" + node.max + ")" : ""));
      b.e(t == Talents.Tree.KRIEGER ? "talent_warrior" : t == Talents.Tree.BERGMANN ? "talent_miner" : "talent_trader",
          "BOOK", t.title, lines.toArray(String[]::new));
    }
    b.done();
  }

  private static void progress() {
    page("progress", "Tiefenpass, Aufträge & Ziele", "pass", "PAPER", "home")
        .intro("Täglicher und saisonaler Fortschritt mit Belohnungen.")
        .e("pass", "PAPER", "Tiefenpass",
            DeepPass.TIERS + " Stufen pro Saison (" + DeepPass.SEASON_DAYS + " Tage), danach Bonusstufen alle " + n(DeepPass.BONUS_XP) + " XP.",
            "XP: Erz " + DeepPass.XP_ORE + " · Baum " + DeepPass.XP_TREE + " · Monster " + DeepPass.XP_KILL + " · Rätsel " + DeepPass.XP_PUZZLE
                + " · Champion " + DeepPass.XP_CHAMPION + " · Auftrag " + DeepPass.XP_CONTRACT + " · Boss " + DeepPass.XP_BOSS
                + " · Tagesauftrag " + DeepPass.XP_DAILY + " · Dungeon " + DeepPass.XP_DUNGEON)
        .e("clock", "CLOCK", "Tagesaufträge",
            Dailies.COUNT + " neue Aufgaben jeden Tag (Erz, Monster, Bäume, Schmelzen, Dungeons …). Serien geben Extra-Belohnung.")
        .e("handbook", "MAP", "Nächstes Ziel",
            Economy.QUESTS + " Meilensteine vom ersten Erz bis zum Urboss. Späte Ziele zahlen Millionen.")
        .e("handbook", "WRITABLE_BOOK", "Lieferaufträge & Forschung",
            "Auftragstafel: Erz, Barren oder Monsterteile liefern gegen Geld und Unterlagen.",
            "Forschung (je 5 Stufen): " + String.join(", ", Industry.RESEARCH) + ".")
        .done();
  }

  private static void business() {
    page("business", "Arbeiter & Betrieb", "worker", "PLAYER_HEAD", "home")
        .intro("Arbeiter bauen für dich ab, schmelzen, handeln oder fällen Holz – auch offline.")
        .e("worker", "PLAYER_HEAD", "Arbeiter",
            "Grundleistung 0,5 Waren/Min., steigt mit Stufe, Spezialisierung und Forschung.",
            "Nach " + Industry.SHIFT_MINUTES + " Min. Arbeit " + Industry.BREAK_MINUTES + " Min. Pause. Lohn: Grundlohn + " + pct(Industry.WAGE_SHARE) + " vom Warenwert.")
        .e("fuel", "COAL", "Brennstoff & Budget",
            "Schmelzer brauchen Brennstoff, alle Arbeiter Betriebsbudget. Ohne beides stehen sie still.")
        .e("machine_furnace", "BLAST_FURNACE", "Schmelze",
            "Barren = 2 Erze + 1 Brennstoff. Barren sind viel mehr wert und für Forschung/Aufträge nötig.")
        .e("clock", "CLOCK", "Offline",
            "6 h Offline-Arbeit (+1 h pro Lagerstufe und Logistik-Forschung), höchstens 12 h.")
        .e("drone_0", "LANTERN", "Funke (Dampfdrohne)",
            "Module: Sammler (findet Erz) · Geschütz (schießt) · Sanitäter (heilt unter 70 %). Bis Stufe " + DroneRules.MAX_LEVEL + ".")
        .done();
  }

  private static void forest() {
    page("forest", "Wald & Holz", "handbook", "OAK_LOG", "home")
        .intro("Neben dem Dorf liegt der Wald mit Sägewerk.")
        .e("handbook", "OAK_LOG", "Holzarten",
            "Eiche " + Forestry.PRICES[0] + " $ · Birke " + Forestry.PRICES[1] + " $ · Fichte " + Forestry.PRICES[2] + " $ pro Stamm.",
            "Bretter: " + Forestry.PLANK_PRICES[0] + " / " + Forestry.PLANK_PRICES[1] + " / " + Forestry.PLANK_PRICES[2] + " $. Sägen macht aus einem Stamm mehrere Bretter.")
        .e("handbook", "IRON_AXE", "Axt & Glück",
            "Axt-Upgrades beschleunigen das Fällen, Holzglück gibt doppelte Ernte. Holzfäller-Arbeiter fällen automatisch.")
        .done();
  }

  private static void guilds() {
    B b = page("guilds", "Gilden", "guild_banner", "CYAN_BANNER", "home")
        .intro("Gründen: /df gilde gründen <Kürzel> <Name> (" + n(Guilds.FOUND_COST) + " $). " + Guilds.BASE_MEMBERS + " Mitglieder, mit Gildenhalle mehr.");
    for (Guilds.Building bld : Guilds.Building.values())
      b.e(new String[] {"building_kaserne", "building_lazarett", "building_werkstatt", "building_schatzkammer", "building_gildenhalle"}[bld.ordinal()],
          "BRICKS", bld.title, bld.perLevel + " pro Stufe (max. " + Guilds.MAX_BUILDING + ") für alle Mitglieder.",
          "Kosten: 20.000 $ × Stufe² aus der Gildenkasse.");
    b.e("guild_task", "PAPER", "Wochenaufträge",
            "Jeden Montag 3 Aufträge für alle zusammen: 600 Gilden-XP und 10.000 $ × Mitglieder in die Kasse.")
        .e("rank_leader", "GOLDEN_HELMET", "Ränge & Chat",
            "Anführer, Offizier, Mitglied. Gildenchat: /df gc <Text>. Das Kürzel steht im Chat, in der Tab-Liste und über dem Kopf.");
    b.done();
  }

  private static void upgrades() {
    page("upgrades", "Upgrades & Kosten", "coin", "GOLD_INGOT", "home")
        .intro("Alle Grund-Upgrades mit Preisen. Talent Sparfuchs senkt die Kosten.")
        .e("drill", "IRON_PICKAXE", "Dampfbohrer (bis " + Economy.MAX_TOOL + ")",
            "200 $ × (Stufe+1)², ab 20 ×2,5 pro Stufe. Stufe 20→21: " + n(Economy.toolCost(20)) + " $, 29→30: " + n(Economy.toolCost(29)) + " $.")
        .e("blade", "IRON_SWORD", "Grubenklinge (bis " + Economy.MAX_COMBAT + ")",
            "+0,7 Grundschaden und +4 % Nahkampfschaden pro Stufe (Stufe 30: ×2,2).",
            "250 $ × (Stufe+1)², ab 20 ×2,5 pro Stufe. Ab Stufe 5 zusätzlich 1 Relikt.")
        .e("shield", "SHIELD", "Schutztraining (bis " + Economy.MAX_COMBAT + ")",
            "+3 Rüstung pro Stufe, schützt vor Gebietsgefahren. 300 $ × (Stufe+1)², ab 20 ×2,5.")
        .e("crate", "CHEST", "Rucksack, Lager, Unterkunft, Schmelze",
            "Rucksack 500 $ × (Stufe+1)² · Lager 1.200 $ · Unterkunft 3.000 $ (Arbeiterplätze) · Schmelze 1.500 $.")
        .e("healing_crystal", "AMETHYST_SHARD", "Heiltasche",
            "+1 Lebenssplitter-Platz pro Stufe (von " + Healing.START + " bis " + Healing.CAPACITY + "), 600 $ × (Stufe+1)².")
        .e("relic", "EMERALD", "Erzglück (bis 10)",
            "Mehr Chance auf doppeltes Erz. 500 $ × (Stufe+1)².")
        .done();
  }

  private static void events() {
    B b = page("events", "Weltereignisse", "clock", "BEACON", "home")
        .intro("Zufällige Ereignisse für alle Spieler gleichzeitig; die Bossleiste zeigt Restzeit.");
    b.e("coin", "GOLD_INGOT", "Goldrausch", "Erz und Barren verkaufen sich für +50 %.")
        .e("ore_crystal", "RAW_GOLD", "Erzrausch", "50 % Chance auf ein Extra-Erz pro Block.")
        .e("mob_4_head", "ZOMBIE_HEAD", "Monsterflut", "Minenmonster: doppelte Beute- und Heilsplitter-Chance.")
        .e("pass", "PAPER", "Tiefenfieber", "Doppelte Tiefenpass-XP für alles.")
        .e("weapon_dagger", "IRON_SWORD", "Championjagd", "Viermal so viele Champions in den Minen.");
    b.done();
  }

  private static void commands() {
    page("commands", "Befehle", "handbook", "COMMAND_BLOCK", "home")
        .intro("Alles geht auch über das Menü (/df). Die wichtigsten Befehle:")
        .e("handbook", "BOOK", "Allgemein",
            "/df – Hauptmenü · /df wiki – dieses Wiki · /df loot – Beutel · /df runen · /df talente",
            "/df pass · /df daily · /df top · /df begleiter · /df heal · /df heal kaufen <n|voll>")
        .e("crate", "CHEST", "Dungeon & Tiefengang",
            "/df dungeon · /df dungeon leave · /df dungeon zuschauen [Name] · /df tiefengang",
            "/df party create · invite <Name> · accept · ready · leave")
        .e("guild_banner", "CYAN_BANNER", "Gilde",
            "/df gilde · gründen · einladen · annehmen · einzahlen · befördern · degradieren · entfernen · verlassen · /df gc <Text>")
        .done();
  }
}
