package de.deepforge.game;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

/** Formatting uses the plugin's actual HP, not the vanilla carrier entity's health. */
public final class MonsterHealth {
  private MonsterHealth() {}

  public static final int SEGMENTS = 12;

  public static double ratio(double hp, double max) {
    if (!Double.isFinite(hp) || !Double.isFinite(max) || max <= 0) return 0;
    return Math.clamp(hp / max, 0, 1);
  }

  public static int filled(double hp, double max) {
    return (int) Math.ceil(ratio(hp, max) * SEGMENTS);
  }

  public static NamedTextColor color(double hp, double max) {
    double r = ratio(hp, max);
    return r > .5 ? NamedTextColor.GREEN : r > .25 ? NamedTextColor.YELLOW : NamedTextColor.RED;
  }

  public static Component text(String name, double hp, double max, boolean boss) {
    long maximum = Double.isFinite(max) ? (long) Math.ceil(Math.max(0, max)) : 0;
    long current = (long) Math.ceil(ratio(hp, max) * Math.max(0, Double.isFinite(max) ? max : 0));
    int fill = filled(hp, max);
    return Component.text(name, boss ? NamedTextColor.GOLD : NamedTextColor.WHITE)
        .append(Component.newline())
        .append(Component.text("■".repeat(fill), color(hp, max)))
        .append(Component.text("■".repeat(SEGMENTS - fill), NamedTextColor.DARK_GRAY))
        .append(Component.text("  " + current + " / " + maximum + " LP", NamedTextColor.WHITE));
  }
}
