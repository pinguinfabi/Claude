package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class DungeonVariantTest {
  private static Profile player(long n) {
    Profile p = new Profile();
    p.id = new UUID(n + 1, n * 31L).toString();
    p.dungeonLevel = 5;
    return p;
  }

  private static Gear.Item loot(Profile p) {
    return p.gear.stream().filter(i -> i.name.startsWith("Gewölbe L5")).findFirst().orElseThrow();
  }

  @Test
  void unlocksFollowTheChain() {
    Profile p = player(1);
    assertTrue(DungeonVariant.GEWOELBE.unlocked(p));
    assertFalse(DungeonVariant.GLUTSCHMIEDE.unlocked(p));
    assertFalse(DungeonVariant.FROSTKRYPTA.unlocked(p));
    assertTrue(DungeonRules.reward(p, UUID.randomUUID(), 0, 0, 100, 5));
    assertTrue(DungeonVariant.GLUTSCHMIEDE.unlocked(p));
    assertFalse(DungeonVariant.FROSTKRYPTA.unlocked(p), "a Runengewölbe win is not enough");
    assertTrue(
        DungeonRules.reward(
            p,
            UUID.randomUUID(),
            0,
            0,
            100,
            5,
            0,
            EnumSet.noneOf(Gear.Slot.class),
            DungeonVariant.GLUTSCHMIEDE));
    assertTrue(DungeonVariant.FROSTKRYPTA.unlocked(p));
    assertArrayEquals(new int[] {1, 1, 0}, p.variantWins);
  }

  @Test
  void oldSavesWithoutVariantWinsStillWork() {
    Profile p = player(2);
    p.variantWins = null;
    assertEquals(0, DungeonVariant.wins(p, DungeonVariant.FROSTKRYPTA));
    assertTrue(
        DungeonRules.reward(
            p, UUID.randomUUID(), 1, 0, 100, 5, 0, EnumSet.noneOf(Gear.Slot.class),
            DungeonVariant.FROSTKRYPTA));
    assertEquals(1, DungeonVariant.wins(p, DungeonVariant.FROSTKRYPTA));
  }

  @Test
  void lootFocusPrefersTheDungeonsSlotsAndStaysDistinct() {
    for (int run = 0; run < 20; run++) {
      UUID receipt = new UUID(run * 7919L, run * 104729L);
      Set<Gear.Slot> taken = EnumSet.noneOf(Gear.Slot.class);
      Set<Gear.Slot> slots = new HashSet<>();
      for (int member = 0; member < 3; member++) {
        Profile p = player(member + run * 10L);
        assertTrue(
            DungeonRules.reward(p, receipt, 2, 1, 6000, 5, 0, taken, DungeonVariant.FROSTKRYPTA));
        Gear.Slot slot = loot(p).slot;
        assertTrue(DungeonVariant.FROSTKRYPTA.focus(slot), "run " + run + ": armour, got " + slot);
        slots.add(slot);
      }
      assertEquals(3, slots.size());
      Profile smith = player(99 + run);
      assertTrue(
          DungeonRules.reward(
              smith, receipt, 2, 1, 6000, 5, 0, EnumSet.noneOf(Gear.Slot.class),
              DungeonVariant.GLUTSCHMIEDE));
      assertTrue(DungeonVariant.GLUTSCHMIEDE.focus(loot(smith).slot));
    }
  }

  @Test
  void focusRunsOutGracefullyInBigParties() {
    UUID receipt = new UUID(5, 6);
    Set<Gear.Slot> taken = EnumSet.noneOf(Gear.Slot.class);
    Set<Gear.Slot> slots = new HashSet<>();
    for (int member = 0; member < 4; member++) {
      Profile p = player(member);
      assertTrue(
          DungeonRules.reward(p, receipt, 0, 0, 100, 5, 0, taken, DungeonVariant.GLUTSCHMIEDE));
      slots.add(loot(p).slot);
    }
    assertEquals(4, slots.size(), "two focus slots, then any other free slot");
    assertTrue(slots.containsAll(Set.of(Gear.Slot.WEAPON, Gear.Slot.OFFHAND)));
  }

  @Test
  void extrasDifferPerDungeon() {
    UUID run = UUID.randomUUID();
    Profile plain = player(7), forge = player(7), crypt = player(7);
    Set<Gear.Slot> none = EnumSet.noneOf(Gear.Slot.class);
    DungeonRules.reward(plain, run, 3, 1, 100, 5, 0, EnumSet.copyOf(none), DungeonVariant.GEWOELBE);
    DungeonRules.reward(
        forge, run, 3, 1, 100, 5, 0, EnumSet.noneOf(Gear.Slot.class), DungeonVariant.GLUTSCHMIEDE);
    DungeonRules.reward(
        crypt, run, 3, 1, 100, 5, 0, EnumSet.noneOf(Gear.Slot.class), DungeonVariant.FROSTKRYPTA);
    long coins = DungeonRules.coins(3, 1, 5);
    assertEquals(Math.round(coins * 1.15) - coins, forge.money - plain.money);
    assertEquals(25, forge.dust - plain.dust);
    assertEquals(plain.money, crypt.money);
    assertEquals(plain.healingCharges + 1, crypt.healingCharges);
    assertEquals(plain.researchNotes + 3, crypt.researchNotes);
  }

  @Test
  void eruptionsAndFrostAreFairButGetHarder() {
    assertTrue(DungeonVariant.eruptionInterval(0, 1) > DungeonVariant.eruptionInterval(2, 40));
    assertEquals(100, DungeonVariant.eruptionInterval(2, 400), "never faster than every 5 s");
    assertEquals(3, DungeonVariant.eruptions(1, 1));
    assertTrue(DungeonVariant.inEruption(1.5, 1.5));
    assertFalse(DungeonVariant.inEruption(2.0, 2.0), "a short step out of the circle is enough");

    int stacks = 0, checks = 0;
    while (!DungeonVariant.frozen(stacks)) {
      stacks = DungeonVariant.frost(stacks, false);
      checks++;
    }
    assertEquals(DungeonVariant.FROST_MAX, checks, "about 20 s on Normal before freezing");
    assertEquals(6, DungeonVariant.frost(10, true));
    assertEquals(0, DungeonVariant.frost(2, true));
    assertTrue(DungeonVariant.frostInterval(2) < DungeonVariant.frostInterval(0));
    assertTrue(DungeonVariant.FROST_MAX * 13 < 140, "freeze overlay stays below vanilla damage");
  }

  @Test
  void eachDungeonHasItsOwnBossesAndAttackMix() {
    for (int zone = 0; zone < 7; zone++) {
      Set<String> names = new HashSet<>();
      Set<List<BossPatterns.Attack>> kits = new HashSet<>();
      for (DungeonVariant v : DungeonVariant.values()) {
        names.add(v.boss(zone));
        kits.add(BossPatterns.kit(BossPatterns.kitIndex(zone, v.ordinal()), 2));
      }
      assertEquals(3, names.size());
      assertEquals(3, kits.size(), "zone " + zone);
    }
    assertEquals("Eisenkoloss", DungeonVariant.GEWOELBE.boss(0));
    assertEquals(0, BossPatterns.kitIndex(0, 0));
  }
}
