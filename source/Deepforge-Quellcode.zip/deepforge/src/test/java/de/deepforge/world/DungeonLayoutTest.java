package de.deepforge.world;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.bukkit.Material;
import org.junit.jupiter.api.Test;

class DungeonLayoutTest {
  record Point(int x, int z) {}

  private boolean clear(int zone, int x, int y, int z, boolean gatesOpen) {
    Material m = DungeonLayout.material(zone, x, y, z);
    return m == Material.AIR || gatesOpen && m == Material.IRON_BARS;
  }

  private Set<Point> reachable(int zone, boolean gatesOpen) {
    Set<Point> seen = new HashSet<>();
    ArrayDeque<Point> queue = new ArrayDeque<>();
    Point start = new Point(0, 12);
    queue.add(start);
    seen.add(start);
    while (!queue.isEmpty()) {
      Point p = queue.remove();
      for (int[] d : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
        int x = p.x + d[0], z = p.z + d[1];
        if (x <= -48
            || x >= 20
            || z <= -124
            || z >= 20
            || !clear(zone, x, 0, z, gatesOpen)
            || !clear(zone, x, 1, z, gatesOpen)
            || DungeonLayout.material(zone, x, -1, z) == Material.AIR) continue;
        Point next = new Point(x, z);
        if (seen.add(next)) queue.add(next);
      }
    }
    return seen;
  }

  @Test
  void allZonePalettesConnectAllChambersAndPuzzleApproachesWithoutTeleporting() {
    for (int zone = 0; zone < 7; zone++) {
      Set<Point> seen = reachable(zone, true);
      for (int room = 0; room < 3; room++) {
        int z = DungeonLayout.roomZ(room);
        assertTrue(seen.contains(new Point(0, z + 12)), "chamber " + room);
        for (int x : new int[] {-9, -3, 3, 9})
          assertTrue(seen.contains(new Point(x, z - 15)), "rune approach");
        for (int x : new int[] {-6, 0, 6})
          assertTrue(seen.contains(new Point(x, z)), "seal approach");
        assertFalse(seen.contains(new Point(17, z + 2)), "protected waiting alcove");
        assertTrue(seen.contains(new Point(-37, z - 3)), "optional objective reachable");
        assertTrue(seen.contains(new Point(-21, z)), "side corridor reachable");
      }
    }
  }

  @Test
  void closedGatesPreventSkippingPuzzlesAndEnteringLaterRooms() {
    Set<Point> seen = reachable(0, false);
    assertTrue(seen.contains(new Point(0, -18)));
    assertFalse(seen.contains(new Point(0, -21)));
    assertFalse(seen.contains(new Point(0, -40)));
    assertFalse(seen.contains(new Point(0, -92)));
    assertFalse(seen.contains(new Point(-37, -3)), "optional room starts locked");
  }

  @Test
  void groupMustActuallyEnterNextChamberBeforeGateCloses() {
    assertFalse(DungeonLayout.arrived(1, 0, -20));
    assertFalse(DungeonLayout.arrived(1, 0, -33));
    assertTrue(DungeonLayout.arrived(1, 0, -40));
    assertFalse(DungeonLayout.arrived(1, 17, -40));
    assertEquals(1, DungeonLayout.nextRoom(2));
    assertEquals(2, DungeonLayout.nextRoom(4));
    assertTrue(DungeonLayout.contains(0, 0, -110));
    assertFalse(DungeonLayout.contains(0, 0, -125));
    assertFalse(DungeonLayout.accessible(0, false, -40));
    assertTrue(DungeonLayout.accessible(0, true, -40));
    assertFalse(DungeonLayout.accessible(0, true, -90));
  }

  @Test
  void entranceMigrationOnlyTouchesItsSurfacePatch() {
    var patch = CampBlueprint.dungeonEntrance();
    for (int key : patch.blocks().keySet()) {
      assertTrue(CampBlueprint.y(key) >= 200);
      assertTrue(Math.abs(CampBlueprint.x(key)) <= 13);
      assertTrue(CampBlueprint.z(key) <= -33 && CampBlueprint.z(key) >= -67);
    }
    for (var station : CampBlueprint.STATIONS)
      if (!station.id().equals("dungeon"))
        assertFalse(patch.blocks().containsKey(CampBlueprint.key(station.x(), 201, station.z())));
  }
}
