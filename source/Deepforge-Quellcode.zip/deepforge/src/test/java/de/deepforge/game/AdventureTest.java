package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class AdventureTest {
  @Test
  void preUpdateGearDoesNotAcquireArtifactOrSetEffects() {
    Gear.Item old =
        new com.google.gson.Gson()
            .fromJson("{\"id\":\"old-item\",\"name\":\"Altes Schwert\"}", Gear.Item.class);
    assertEquals(-1, old.archetype);
    assertEquals(-1, old.adventureSet);
    Profile p = new com.google.gson.Gson().fromJson("{\"money\":1234}", Profile.class);
    assertEquals(0, p.tutorialStep);
    assertNotNull(p.artifactCollection);
    assertEquals(1234, p.money);
  }

  @Test
  void artifactEffectsAndSetProgressAppearOnHeldItemTooltips() {
    Profile p = new Profile();
    Gear.Item sword = AdventureGear.artifact(0, 0, new Random(1));
    p.gear.add(sword);
    p.equipped.put(Gear.Slot.WEAPON.name(), sword.id);
    assertTrue(String.join(" ", EquipmentLore.lines("sword", p, 0)).contains("8 Treffer"));
    Gear.Item drill = AdventureGear.artifact(3, 3, new Random(2));
    p.gear.add(drill);
    p.equipped.put(Gear.Slot.TOOL.name(), drill.id);
    assertTrue(String.join(" ", EquipmentLore.lines("tool", p, 0)).contains("25% Chance"));
  }

  @Test
  void tutorialFundsFurnaceOnceAndCanPauseOrSkip() {
    Profile p = new Profile();
    p.mined = 15;
    p.depositedOre = 10;
    assertEquals(2, Tutorial.advance(p));
    assertEquals(1550, p.money);
    assertEquals(0, Tutorial.advance(p));
    assertEquals(1550, p.money);
    p.tutorialPaused = true;
    p.furnace = 1;
    assertEquals(0, Tutorial.advance(p));
    p.tutorialPaused = false;
    assertEquals(1, Tutorial.advance(p));
    assertEquals(10, p.fuel);
    long balance = p.money;
    Tutorial.skip(p);
    assertEquals(4, p.tutorialStep);
    assertEquals(balance, p.money);
  }

  @Test
  void tutorialHealGrantAndFinalDungeonGoalWork() {
    Profile p = new Profile();
    p.tutorialStep = 6;
    p.dodges = 1;
    p.healingCharges = 0;
    assertEquals(1, Tutorial.advance(p));
    assertEquals(1, p.healingCharges);
    p.healsUsed = 1;
    assertEquals(1, Tutorial.advance(p));
    p.id = UUID.randomUUID().toString();
    p.tutorialStep = 11;
    DungeonRules.reward(p, UUID.randomUUID(), 0, 0, 1000, 1, 0);
    assertEquals(12, p.tutorialStep);
    assertEquals(0, Tutorial.advance(p));
  }

  @Test
  void artifactCraftHasNoPartialDeductionsAndCollectionSurvivesSalvage() {
    Profile p = new Profile();
    p.bosses[0] = true;
    p.money = 2000;
    p.bossTokens[0] = 40;
    p.monsterParts[0] = 29;
    AdventureGear.craft(p, 0);
    assertEquals(2000, p.money);
    assertEquals(40, p.bossTokens[0]);
    assertTrue(p.gear.isEmpty());
    p.monsterParts[0] = 30;
    AdventureGear.craft(p, 0);
    assertEquals(0, p.money);
    assertEquals(0, p.bossTokens[0]);
    assertEquals(0, p.monsterParts[0]);
    Gear.Item i = p.gear.getFirst();
    assertEquals(0, i.archetype);
    assertEquals("unique_1", i.model());
    Gear.sell(p, i.id, true);
    assertTrue(p.artifactCollection.contains(0));
  }

  @Test
  void fullBagCannotConsumeCraftingIngredients() {
    Profile p = new Profile();
    p.bosses[0] = true;
    p.money = 2000;
    p.bossTokens[0] = 40;
    p.monsterParts[0] = 30;
    for (int n = 0; n < 120; n++) p.gear.add(Gear.roll(0, Gear.Rarity.RARE, new Random(n)));
    AdventureGear.craft(p, 0);
    assertEquals(2000, p.money);
    assertEquals(40, p.bossTokens[0]);
    assertEquals(120, p.gear.size());
    AdventureGear.grant(p, AdventureGear.artifact(3, 3, new Random(1)));
    assertEquals(120, p.gear.size());
    assertEquals(40, p.dust);
    assertTrue(p.artifactCollection.contains(3));
  }

  @Test
  void minerSetOnlyCountsEquippedPiecesAndAddsRealStats() {
    Profile p = new Profile();
    double base = Gear.stats(p).yield();
    for (int n = 0; n < 4; n++) {
      Gear.Item i = AdventureGear.drop(0, new Random(n), 0);
      i.adventureSet = 2;
      i.slot =
          new Gear.Slot[] {Gear.Slot.HELMET, Gear.Slot.CHEST, Gear.Slot.LEGS, Gear.Slot.BOOTS}[n];
      i.yield = 0;
      i.mining = 0;
      p.gear.add(i);
      p.equipped.put(i.slot.name(), i.id);
    }
    assertEquals(4, AdventureGear.setCount(p, 2));
    assertEquals(base + .1, Gear.stats(p).yield(), .0001);
    assertTrue(Gear.stats(p).mining() >= .15);
    p.equipped.clear();
    assertEquals(0, AdventureGear.setCount(p, 2));
    assertEquals(base, Gear.stats(p).yield(), .0001);
  }

  @Test
  void procChargesIgnoreRapidExtraClicksAndRespectCooldown() {
    ArtifactCombat c = new ArtifactCombat();
    UUID p = UUID.randomUUID(), t = UUID.randomUUID();
    for (int n = 0; n < 7; n++) {
      assertFalse(c.hit(p, t, 0, n * 4, 0).lightning());
      assertFalse(c.hit(p, t, 0, n * 4 + 1, 0).lightning());
    }
    assertTrue(c.hit(p, t, 0, 28, 0).lightning());
    for (int n = 29; n < 68; n++) assertFalse(c.hit(p, t, 0, n, 0).lightning());
    for (int n = 0; n < 7; n++) assertFalse(c.hit(p, t, 0, 68 + n * 4, 0).lightning());
    assertTrue(c.hit(p, t, 0, 96, 0).lightning());
  }

  @Test
  void stormSetAcceleratesProcAndHammerFractureExpires() {
    ArtifactCombat c = new ArtifactCombat();
    UUID p = UUID.randomUUID(), t = UUID.randomUUID();
    for (int n = 0; n < 5; n++) assertFalse(c.hit(p, t, 0, n * 4, 2).lightning());
    assertTrue(c.hit(p, t, 0, 20, 2).lightning());
    c.clear(p);
    for (int n = 0; n < 5; n++) assertFalse(c.hit(p, t, 2, 100 + n * 4, 0).fracture());
    assertTrue(c.hit(p, t, 2, 120, 0).fracture());
    assertTrue(c.fractured(t, 199));
    assertFalse(c.fractured(t, 200));
  }

  @Test
  void optionalRewardsAreOnceOnlyAndInvalidChoicesCannotMutate() {
    Profile p = new Profile();
    p.id = UUID.randomUUID().toString();
    UUID run = UUID.randomUUID();
    assertThrows(
        IllegalArgumentException.class, () -> DungeonRules.reward(p, run, 0, 0, 1000, 1, 3));
    assertEquals(250, p.money);
    assertTrue(p.gear.isEmpty());
    assertTrue(DungeonRules.reward(p, run, 0, 0, 1000, 1, 14));
    assertEquals(6, p.gear.size());
    assertEquals(1850, p.money);
    assertEquals(1, p.adventureChallenges);
    assertEquals(1, p.adventureRescues);
    assertEquals(1, p.adventureTreasures);
    assertEquals(2, p.bossTokens[0]);
    assertFalse(DungeonRules.reward(p, run, 0, 0, 1000, 1, 14));
    assertEquals(1850, p.money);
    assertEquals(6, p.gear.size());
  }
}
