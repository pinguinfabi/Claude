package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class WeaponRulesTest {
  @Test
  void facingUsesTargetDirectionAndHandlesCoincidentLocations() {
    assertEquals(1, WeaponRules.facing(0, 3, 0, 1));
    assertEquals(-1, WeaponRules.facing(0, -3, 0, 1));
    assertEquals(0, WeaponRules.facing(3, 0, 0, 1));
    assertEquals(0, WeaponRules.facing(0, 0, 0, 1));
  }

  @Test
  void daggerRewardsRearConeOnly() {
    assertEquals(1.65, WeaponRules.multiplier("dagger", .65, false, false, -.5));
    assertEquals(1, WeaponRules.multiplier("dagger", .65, false, false, -.49));
    assertEquals(1, WeaponRules.multiplier("sword", .65, false, false, -1));
  }

  @Test
  void daggerRearBonusGrowsWithRarity() {
    Gear.Item dagger = new Gear.Item();
    dagger.style = "dagger";
    dagger.rarity = Gear.Rarity.UNCOMMON;
    assertEquals(1.2, WeaponRules.multiplier("dagger", WeaponRules.rearBonus(dagger), false, false, -1), 1e-9);
    dagger.rarity = Gear.Rarity.LEGENDARY;
    assertEquals(1.65, WeaponRules.multiplier("dagger", WeaponRules.rearBonus(dagger), false, false, -1), 1e-9);
    dagger.rarity = Gear.Rarity.MYTHIC;
    assertEquals(.75, WeaponRules.rearBonus(dagger), 1e-9);
    assertEquals(0, WeaponRules.rearBonus(null));
  }

  @Test
  void armoredGuardCanBeFlankedAndDoesNotApplyWhileExposed() {
    assertEquals(.45, WeaponRules.multiplier("hammer", 0, true, false, 1));
    assertEquals(1, WeaponRules.multiplier("hammer", 0, true, false, 0));
    assertEquals(1, WeaponRules.multiplier("hammer", 0, true, true, 1));
    assertEquals(1.65, WeaponRules.multiplier("dagger", .65, true, false, -1));
  }

  @Test
  void huntCannotPayBeforeCompletionOrTwice() {
    Profile p = new Profile();
    p.huntKills[0] = 14;
    Gear.claimHunt(p, 0);
    assertEquals(250, p.money);
    assertEquals(14, p.huntKills[0]);
    p.huntKills[0]++;
    Gear.claimHunt(p, 0);
    assertEquals(700, p.money);
    assertEquals(3, p.dust);
    assertEquals(6, p.monsterParts[0]);
    assertEquals(1, p.huntsCompleted[0]);
    Gear.claimHunt(p, 0);
    assertEquals(700, p.money);
    assertEquals(1, p.huntsCompleted[0]);
  }

  @Test
  void huntsPreserveExcessProgressAndRejectLockedZone() {
    Profile p = new Profile();
    p.huntKills[0] = 32;
    Gear.claimHunt(p, 0);
    assertEquals(17, p.huntKills[0]);
    Gear.claimHunt(p, 0);
    assertEquals(2, p.huntKills[0]);
    p.huntKills[1] = 15;
    Gear.claimHunt(p, 1);
    assertEquals(15, p.huntKills[1]);
    assertEquals(0, p.huntsCompleted[1]);
    Gear.claimHunt(p, -1);
    Gear.claimHunt(p, 7);
    assertEquals(1150, p.money);
  }
}
