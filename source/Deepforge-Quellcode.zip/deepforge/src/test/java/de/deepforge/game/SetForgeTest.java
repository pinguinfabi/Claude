package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class SetForgeTest {
  private static Gear.Item piece(int set, Gear.Slot slot, int zone, double defense) {
    Gear.Item i = new Gear.Item();
    i.adventureSet = set;
    i.slot = slot;
    i.zone = zone;
    i.defense = defense;
    i.name = AdventureGear.SETS[set] + " · " + slot;
    return i;
  }

  private static Profile rich() {
    Profile p = new Profile();
    p.id = UUID.randomUUID().toString();
    p.money = 100_000;
    p.dust = 500;
    return p;
  }

  @Test
  void onlyExtraCopiesAreSpare() {
    Profile p = rich();
    Gear.Item worn = piece(0, Gear.Slot.HELMET, 1, 5);
    Gear.Item better = piece(0, Gear.Slot.HELMET, 1, 50);
    Gear.Item weak = piece(0, Gear.Slot.HELMET, 0, 1);
    Gear.Item lonely = piece(1, Gear.Slot.BOOTS, 2, 9);
    Gear.Item fav = piece(2, Gear.Slot.LEGS, 0, 1);
    fav.favorite = true;
    Gear.Item legs = piece(2, Gear.Slot.LEGS, 0, 3);
    p.gear.addAll(List.of(worn, better, weak, lonely, fav, legs));
    p.equipped.put("HELMET", worn.id);
    List<Gear.Item> spare = AdventureGear.spares(p);
    // The worn helmet stays even though a better copy exists; favourites never melt.
    assertEquals(List.of(weak, better), spare);
  }

  @Test
  void reforgeTurnsTwoDuplicatesIntoTheChosenPiece() {
    Profile p = rich();
    Gear.Item a = piece(0, Gear.Slot.CHEST, 2, 4), b = piece(0, Gear.Slot.CHEST, 3, 6);
    b.dungeonRank = 5;
    Gear.Item c = piece(0, Gear.Slot.CHEST, 1, 9);
    p.gear.addAll(List.of(a, b, c));
    String msg = AdventureGear.reforge(p, 1, Gear.Slot.BOOTS, new Random(3));
    assertTrue(msg.startsWith("Set-Schmiede"), msg);
    assertEquals(2, p.gear.size());
    assertTrue(p.gear.contains(c), "the strongest copy stays");
    Gear.Item made = p.gear.stream().filter(i -> i.slot == Gear.Slot.BOOTS).findFirst().orElseThrow();
    assertEquals(1, made.adventureSet);
    assertEquals(3, made.zone, "zone of the best melted piece");
    assertEquals(5, made.dungeonRank);
    assertEquals(0, made.damage);
    assertTrue(made.defense > 0 && made.health > 0);
    assertEquals(500 - AdventureGear.REFORGE_DUST, p.dust);
    assertEquals(100_000 - AdventureGear.reforgeMoney(3), p.money);
    assertTrue(p.discovered.contains("set/1/BOOTS"));
  }

  @Test
  void refusesWithoutDuplicatesOrMoney() {
    Profile p = rich();
    p.gear.add(piece(0, Gear.Slot.CHEST, 0, 1));
    p.gear.add(piece(0, Gear.Slot.LEGS, 0, 1));
    assertTrue(AdventureGear.reforge(p, 0, Gear.Slot.HELMET, new Random()).contains("2 doppelte"));
    p.gear.add(piece(0, Gear.Slot.CHEST, 0, 1));
    p.gear.add(piece(0, Gear.Slot.LEGS, 0, 1));
    p.money = 10;
    assertTrue(AdventureGear.reforge(p, 0, Gear.Slot.HELMET, new Random()).contains("kostet"));
    assertEquals(4, p.gear.size());
    assertTrue(AdventureGear.reforge(p, 0, Gear.Slot.WEAPON, new Random()).contains("Unbekannt"));
  }

  @Test
  void setDropsAreRealArmour() {
    Random r = new Random(11);
    for (int n = 0; n < 200; n++) {
      Gear.Item i = AdventureGear.drop(2, r, 0);
      assertTrue(Arrays.asList(AdventureGear.SET_SLOTS).contains(i.slot));
      assertTrue(i.defense > 5 && i.health > 0, "armour stats even from a weapon roll");
      assertEquals(0, i.damage);
      assertEquals(0, i.mining);
    }
  }
}
