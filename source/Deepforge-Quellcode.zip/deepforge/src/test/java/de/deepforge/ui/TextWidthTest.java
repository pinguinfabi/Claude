package de.deepforge.ui;

import static org.junit.jupiter.api.Assertions.*;

import de.deepforge.game.Wiki;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.junit.jupiter.api.Test;

class TextWidthTest {
  @Test
  void widthsComeFromTheVanillaFont() {
    assertEquals(6, TextWidth.of("a"));
    assertEquals(2, TextWidth.of("i"));
    assertEquals(4, TextWidth.of(" "));
    assertEquals(6, TextWidth.of("ä"));
    assertEquals(6 + 2 + 3, TextWidth.of("ail"));
  }

  @Test
  void wrapNeverExceedsTheWidth() {
    for (Wiki.Page p : Wiki.all())
      for (Wiki.Entry e : p.entries())
        for (String line : e.lines())
          for (String part : TextWidth.wrap(line, WikiDialog.ENTRY_WIDTH))
            assertTrue(TextWidth.of(part) <= WikiDialog.ENTRY_WIDTH, p.id() + ": " + part);
    List<String> lines = TextWidth.wrap("Ein Wort", 1000);
    assertEquals(List.of("Ein Wort"), lines);
    assertEquals(3, TextWidth.wrap("aaaaaaaaaaaaaaa", 30).size(), "long words are split");
  }

  @Test
  void everyWikiLineIsPaddedToTheSameWidth() {
    Component c = WikiDialog.block(Component.empty(), "Stufe I: +2 Schaden · Stufe V: +10 Schaden und noch viel mehr Text, damit er umbricht.", NamedTextColor.WHITE, 297);
    // Each line = visible text + padding; the padding makes it exactly 297 px.
    int lines = 0, width = 0;
    for (Component child : c.children()) {
      String t = ((TextComponent) child).content();
      if (t.equals("\n")) {
        assertEquals(297, width);
        width = 0;
        continue;
      }
      if (child.font() != null) width += HudFontTest.spaceWidth(t);
      else if (!t.isEmpty()) {
        width += TextWidth.of(t);
        lines++;
      }
    }
    assertEquals(297, width);
    assertTrue(lines >= 2);
  }
}
