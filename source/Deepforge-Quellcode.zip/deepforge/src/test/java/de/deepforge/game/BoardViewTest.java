package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import de.deepforge.ui.*;
import java.util.*;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.junit.jupiter.api.Test;

class BoardViewTest {
  private static final PlainTextComponentSerializer TEXT = PlainTextComponentSerializer.plainText();

  @Test
  void luckPermsNetworkAndVaroPermissionsMatchRankHierarchy() {
    assertEquals(
        PlayerRank.ADMIN,
        PlayerRank.resolve(false, Set.of("network.rank.admin", "network.rank.vip")::contains));
    assertEquals(PlayerRank.MOD, PlayerRank.resolve(false, Set.of("varo.mod")::contains));
    assertEquals(
        PlayerRank.BUILDER, PlayerRank.resolve(false, Set.of("deepforge.rank.builder")::contains));
    assertEquals(PlayerRank.NONE, PlayerRank.resolve(false, node -> false));
  }

  @Test
  void wildcardsNeverGiveHosterButExplicitHosterWins() {
    assertEquals(PlayerRank.ADMIN, PlayerRank.resolve(false, node -> true));
    assertEquals(PlayerRank.HOSTER, PlayerRank.resolve(true, node -> true));
    assertTrue(PlayerRank.ADMIN.order > PlayerRank.VIP.order);
    assertEquals("ADMIN Alex", TEXT.serialize(PlayerRank.ADMIN.playerName("Alex")));
    assertEquals("Alex", TEXT.serialize(PlayerRank.NONE.playerName("Alex")));
  }

  @Test
  void brandingUsesVaroThemeAndDataBelongsToItsOwner() {
    Profile p = new Profile();
    p.money = 123456;
    p.dungeonLevel = 12;
    p.zoneLevels[0] = 12;
    p.wood[0] = 10;
    assertTrue(
        TEXT.serialize(BoardView.header("Pinguin Netzwerk"))
            .contains("Pinguin Netzwerk ● Deepforge"));
    String footer = TEXT.serialize(BoardView.footer(p, 42, 3, true, "twitch.tv/fabiderpinguin"));
    assertTrue(footer.contains("Spieler ▸ 3"));
    assertTrue(footer.contains("123.456 $"));
    assertTrue(footer.contains("Level 12 · Gebiet 1"));
    assertTrue(footer.contains("Treffer ▸ 3,9 LP"));
    assertTrue(footer.contains("Krit ▸ 5,0 %"));
    assertEquals(BoardView.LINES, BoardView.lines(p, true).size());
    assertTrue(TEXT.serialize(BoardView.lines(p, true).get(7)).contains("10 / 400"));
    assertTrue(TEXT.serialize(BoardView.lines(p, true).get(0)).contains("Geld ▸ 123.456 $"));
    assertTrue(
        BoardView.lines(p, true).stream().noneMatch(l -> TEXT.serialize(l).contains("FORTSCHRITT")),
        "no heading line in the sidebar");
    p.dust = 17;
    assertTrue(TEXT.serialize(BoardView.lines(p, true).get(1)).contains("Schmiedestaub ▸ 17"));
    assertFalse(
        TEXT.serialize(BoardView.footer(new Profile(), 0, 1, false, "")).contains("123.456"));
  }
}
