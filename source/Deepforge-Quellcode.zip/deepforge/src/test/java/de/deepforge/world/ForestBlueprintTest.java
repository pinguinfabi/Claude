package de.deepforge.world;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class ForestBlueprintTest {
  record Pos(int x, int z) {}

  @Test
  void woodlandOnlyTouchesSurfaceAndPreservesExistingStations() {
    var b = ForestBlueprint.create().blocks();
    for (var p : b.keySet()) {
      assertTrue(p.y() >= 196);
      assertTrue(p.x() >= 36 && p.x() <= 124);
      assertTrue(p.z() >= -37 && p.z() <= 36);
    }
    for (var s : CampBlueprint.STATIONS)
      assertFalse(b.containsKey(new ForestBlueprint.Point(s.x(), 201, s.z())));
    assertEquals(36, ForestBlueprint.TREES.size());
    assertEquals(
        3, ForestBlueprint.TREES.stream().map(ForestBlueprint.Tree::species).distinct().count());
  }

  @Test
  void allTreesAndSawmillAreReachableOnFoot() {
    var b = ForestBlueprint.create().blocks();
    Set<Pos> seen = new HashSet<>();
    ArrayDeque<Pos> queue = new ArrayDeque<>();
    seen.add(new Pos(36, 0));
    queue.add(new Pos(36, 0));
    while (!queue.isEmpty()) {
      Pos p = queue.remove();
      for (int[] d : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
        Pos n = new Pos(p.x + d[0], p.z + d[1]);
        if (n.x < 36 || n.x > 124 || n.z < -37 || n.z > 36 || seen.contains(n)) continue;
        if (!b.getOrDefault(new ForestBlueprint.Point(n.x, 201, n.z), "air").equals("air")
            || !b.getOrDefault(new ForestBlueprint.Point(n.x, 202, n.z), "air").equals("air"))
          continue;
        if (!b.containsKey(new ForestBlueprint.Point(n.x, 200, n.z))) continue;
        seen.add(n);
        queue.add(n);
      }
    }
    for (var t : ForestBlueprint.TREES)
      assertTrue(seen.contains(new Pos(t.x() - 1, t.z())), "tree " + t.id());
    assertTrue(seen.contains(new Pos(71, 9)));
    assertTrue(seen.contains(new Pos(70, 18)));
  }

  @Test
  void everyHarvestCrownIsDisjointAndLeavesPersist() {
    Set<ForestBlueprint.Point> occupied = new HashSet<>();
    for (var t : ForestBlueprint.TREES)
      for (var e : ForestBlueprint.crown(t).entrySet()) {
        assertTrue(occupied.add(e.getKey()));
        if (e.getValue().contains("leaves")) assertTrue(e.getValue().contains("persistent=true"));
      }
  }

  @Test
  void grovesAreSealedByThicketExceptAtTheArch() {
    var b = ForestBlueprint.create().blocks();
    for (int gate : new int[] {92, 107})
      for (int z = -36; z <= 35; z++) {
        boolean open = true;
        for (int x = gate - 1; x <= gate; x++) {
          String low = b.getOrDefault(new ForestBlueprint.Point(x, 201, z), "air");
          String high = b.getOrDefault(new ForestBlueprint.Point(x, 202, z), "air");
          if (!low.equals("air") && !high.equals("air")) open = false;
        }
        if (Math.abs(z) <= 4) assertTrue(open, "arch must be open at z " + z);
        else assertFalse(open, "hedge gap at x " + gate + " z " + z);
      }
    assertEquals(0, ForestBlueprint.grove(70, 0));
    assertEquals(1, ForestBlueprint.grove(95, 10));
    assertEquals(2, ForestBlueprint.grove(110, -20));
    assertEquals(-1, ForestBlueprint.grove(30, 0));
  }
}
