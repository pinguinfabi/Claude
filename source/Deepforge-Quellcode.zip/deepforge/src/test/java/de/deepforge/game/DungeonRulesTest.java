package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class DungeonRulesTest {
  @Test
  void bossesSurviveLevelFourRearSpamAndPartyHealthNearlyTracksGroupDamage() {
    Profile p = new Profile();
    p.sword = 4;
    Gear.Item weapon = new Gear.Item();
    weapon.slot = Gear.Slot.WEAPON;
    weapon.style = "dagger";
    weapon.damage = 2.457;
    weapon.haste = .132525;
    weapon.crit = .050596;
    p.gear.add(weapon);
    Gear.equip(p, weapon.id);
    Gear.Stats stats = Gear.stats(p);
    double expectedHit =
        RapidCombat.damage(stats) * 1.65 * (1 + stats.crit() * (stats.critDamage() - 1));
    double spamDps = expectedHit * 10;
    // Even uninterrupted rear attacks at 10 clicks/s must last beyond a short burst.
    assertTrue(DungeonRules.health(0, 0, 1, 5, true, 1) / spamDps > 25);
    assertTrue(RapidCombat.bossHealth(0, 0) / (spamDps * 1.35) > 30);
    assertEquals(6900, DungeonRules.health(0, 0, 1, 5, true, 1), .001);
    assertEquals(128.8, DungeonRules.health(0, 0, 1, 1, false, 1), .001);
    assertEquals(24495, DungeonRules.health(0, 0, 4, 5, true, 1), .001);
    assertEquals(97980, DungeonRules.health(0, 0, 4, 8, true, 31), .001);
    assertTrue(
        DungeonRules.health(0, 0, 4, 5, true, 1) / (spamDps * 4)
            >= DungeonRules.health(0, 0, 1, 5, true, 1) / spamDps * .85);
  }

  @Test
  void migratesPriorWinsAndRaisesEachMemberExactlyOnce() {
    Profile p = new Profile();
    p.id = UUID.randomUUID().toString();
    p.dungeonWins[0] = 3;
    p.dungeonWins[7] = 2;
    assertEquals(6, DungeonRules.level(p));
    UUID receipt = UUID.randomUUID();
    assertTrue(DungeonRules.reward(p, receipt, 0, 0, 1234, 12));
    assertEquals(7, p.dungeonLevel);
    assertEquals(12, p.gear.getFirst().dungeonRank);
    assertFalse(DungeonRules.reward(p, receipt, 0, 0, 1234, 12));
    assertEquals(7, p.dungeonLevel);
    assertEquals(3, p.healingCharges);
  }

  @Test
  void partyUsesHighestProgressRegardlessOfLeadershipOrOrder() {
    Profile a = new Profile(), b = new Profile();
    a.dungeonLevel = 2;
    b.dungeonLevel = 30;
    assertEquals(30, DungeonRules.groupLevel(List.of(a, b)));
    assertEquals(30, DungeonRules.groupLevel(List.of(b, a)));
    assertEquals(2, a.dungeonLevel);
    assertEquals(30, b.dungeonLevel);
  }

  @Test
  void increasingLevelAndPartySizeScaleCombatAndKeepEntityCountBounded() {
    for (int level : new int[] {1, 3, 4, 6, 11, 21, 31, 100, 10000, 1_000_000}) {
      assertTrue(DungeonRules.waves(level) >= 5 && DungeonRules.waves(level) <= 8);
      for (int players = 1; players <= 4; players++) {
        assertTrue(DungeonRules.activeLimit(players) <= 14);
        for (int wave = 1; wave <= DungeonRules.waves(level); wave++)
          assertTrue(DungeonRules.count(wave, players, level) <= 40);
        double hp = DungeonRules.health(0, 0, players, 1, false, level);
        assertTrue(Double.isFinite(hp));
        assertTrue(hp >= DungeonRules.health(0, 0, 1, 1, false, 1));
        assertTrue(DungeonRules.warning(level, true) >= 22);
        assertTrue(DungeonRules.recovery(level, true) >= 26);
      }
    }
    assertTrue(DungeonRules.damage(0, 0, true, 20, 4) > DungeonRules.damage(0, 0, true, 20, 1));
    assertTrue(
        DungeonRules.health(0, 0, 4, 5, true, 20) > DungeonRules.health(0, 0, 1, 5, true, 20));
    assertTrue(DungeonRules.coins(0, 0, 20) > DungeonRules.coins(0, 0, 1));
  }

  @Test
  void levelUnlocksElitesAndNewEnemyTypesAndConditionsRotate() {
    assertFalse(DungeonRules.elite(2, 0));
    assertTrue(DungeonRules.elite(3, 0));
    for (int i = 0; i < 40; i++) assertNotEquals(3, DungeonRules.kind(3, 1, i, 0));
    Set<Integer> kinds = new HashSet<>();
    for (int i = 0; i < 40; i++) kinds.add(DungeonRules.kind(4, 1, i, 0));
    assertEquals(Set.of(0, 1, 2, 3), kinds);
    Set<String> conditions = new HashSet<>();
    for (int l = 2; l <= 5; l++) conditions.add(DungeonRules.conditionName(l));
    assertEquals(4, conditions.size());
  }

  @Test
  void higherRankLootActuallyImprovesStatsAndRarityThresholdsStayOrdered() {
    Profile low = new Profile(), high = new Profile();
    low.id = high.id = UUID.randomUUID().toString();
    UUID receipt = UUID.randomUUID();
    DungeonRules.reward(low, receipt, 0, 0, 1000, 1);
    DungeonRules.reward(high, receipt, 0, 0, 1000, 40);
    Gear.Item a = low.gear.getFirst(), b = high.gear.getFirst();
    assertEquals(40, b.dungeonRank);
    assertTrue(b.damage + b.health + b.defense >= a.damage + a.health + a.defense);
    for (int mode = 0; mode < 3; mode++)
      for (int level : new int[] {1, 50, 10000, Integer.MAX_VALUE - 1}) {
        assertTrue(
            DungeonRules.mythicThreshold(mode, level)
                < DungeonRules.legendaryThreshold(mode, level));
        assertTrue(
            DungeonRules.legendaryThreshold(mode, level) < DungeonRules.epicThreshold(mode, level));
        assertTrue(DungeonRules.epicThreshold(mode, level) < 1000);
      }
  }

  @Test
  void allTiersScaleForPartiesWithoutMultiplyingPersonalLoot() {
    for (int zone = 0; zone < 7; zone++)
      for (int mode = 0; mode < 3; mode++) {
        double solo = DungeonRules.health(zone, mode, 1, 5, true);
        assertTrue(DungeonRules.health(zone, mode, 4, 5, true) > solo);
        assertTrue(DungeonRules.health(zone, mode, 4, 5, true) < solo * 4);
        for (int wave = 1; wave <= 5; wave++) assertTrue(DungeonRules.count(wave, 4) <= 10);
        assertTrue(DungeonRules.damage(zone, mode, true) > DungeonRules.damage(zone, mode, false));
      }
  }

  @Test
  void puzzleSequenceIsStableDistinctAndVariesAcrossRuns() {
    Set<List<Integer>> seen = new HashSet<>();
    for (int i = 1; i < 100; i++) {
      UUID run = new UUID(i * 999, i * 91);
      List<Integer> s = DungeonRules.sequence(run, 0);
      // 0.11.0: 5 / 7 / 9 runes, never the same rune twice in a row.
      assertEquals(5, s.size());
      assertEquals(9, DungeonRules.sequence(run, 0, 2).size());
      for (int k = 1; k < s.size(); k++) assertNotEquals(s.get(k - 1), s.get(k));
      assertEquals(s, DungeonRules.sequence(run, 0));
      seen.add(s);
    }
    assertTrue(seen.size() > 10);
  }

  @Test
  void personalRewardIsIdempotentDoesNotUnlockMineBossesAndTracksBestTime() {
    Profile p = new Profile();
    p.id = UUID.randomUUID().toString();
    UUID run = UUID.randomUUID();
    assertTrue(DungeonRules.reward(p, run, 2, 1, 8000));
    long money = p.money;
    assertFalse(DungeonRules.reward(p, run, 2, 1, 8000));
    assertEquals(money, p.money);
    assertEquals(2, p.gear.size());
    assertEquals(1, p.dungeonWins[7]);
    assertEquals(8000, p.dungeonBestTicks[7]);
    assertEquals(0, p.bossWins[7]);
    assertFalse(p.bosses[2]);
    DungeonRules.reward(p, UUID.randomUUID(), 2, 1, 9000);
    assertEquals(8000, p.dungeonBestTicks[7]);
    DungeonRules.reward(p, UUID.randomUUID(), 2, 1, 7000);
    assertEquals(7000, p.dungeonBestTicks[7]);
  }

  @Test
  void fullLootBagConvertsNewDropToDustWithoutDeletingExistingGear() {
    Profile p = new Profile();
    p.id = UUID.randomUUID().toString();
    for (int i = 0; i < 120; i++) p.gear.add(Gear.roll(0, Gear.Rarity.RARE, new Random(i)));
    var original = List.copyOf(p.gear);
    DungeonRules.reward(p, UUID.randomUUID(), 0, 0, 3000);
    assertEquals(original, p.gear);
    assertTrue(p.dust > 20);
  }
}
