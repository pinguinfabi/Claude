package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class DungeonStatsTest {
  @Test
  void rankingSharesAndAwardsFollowTheNumbers() {
    UUID a = UUID.randomUUID(), b = UUID.randomUUID(), c = UUID.randomUUID();
    DungeonStats s = new DungeonStats();
    s.hit(a, 600, false, true, 12, true);
    s.hit(a, 400, true, false, 30, false);
    s.hit(b, 500, true, false, 5, true);
    s.hit(b, 10, false, false, 6, true);
    s.of(c).taken = 900;
    s.of(c).healed = 120;
    s.of(b).taken = 100;
    List<UUID> all = List.of(a, b, c);
    assertEquals(List.of(a, b, c), s.ranking(all));
    assertEquals(a, s.mvp(all));
    assertEquals(1000 / 1510.0, s.share(a), 1e-9);
    Map<String, UUID> awards = new HashMap<>();
    for (DungeonStats.Award award : s.awards(all)) awards.put(award.title(), award.player());
    assertEquals(a, awards.get("Schadenskönig"));
    assertEquals(b, awards.get("Schlächter"));
    assertEquals(b, awards.get("Bossbrecher"));
    assertEquals(a, awards.get("Kombo-Meister"));
    assertEquals(c, awards.get("Zäh wie Leder"));
    assertEquals(c, awards.get("Fels in der Brandung"));
    assertEquals(2, s.of(a).hits);
    assertEquals(1, s.of(a).crits);
  }

  @Test
  void soloRunsGetNoTankAwardAndEmptyGroupsNone() {
    UUID a = UUID.randomUUID();
    DungeonStats s = new DungeonStats();
    s.hit(a, 50, false, false, 1, true);
    s.of(a).taken = 40;
    assertTrue(s.awards(List.of(a)).stream().noneMatch(x -> x.title().equals("Fels in der Brandung")));
    assertTrue(new DungeonStats().awards(List.of()).isEmpty());
    assertEquals("1,2 Mio.", DungeonStats.fmt(1_234_567));
    assertEquals("12.345", DungeonStats.fmt(12_345));
  }
}
