package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class RoomAnchorTest {
  @Test
  void sameRoomGivesBackTheSameSpot() {
    for (int dx = -9; dx <= 9; dx++)
      for (int dz = -7; dz <= 7; dz++)
        for (int dy = -1; dy <= 8; dy++) {
          String key = RoomAnchor.encode(dx, dy, dz, 9, 7, 8);
          assertArrayEquals(new int[] {dx, dy, dz}, RoomAnchor.decode(key, 9, 7, 8), key);
        }
  }

  @Test
  void wallDecorationFollowsTheWallInABiggerRoom() {
    // a banner one block inside the east wall of a 9-wide room …
    String banner = RoomAnchor.encode(8, 2, 0, 9, 7, 8);
    assertEquals("E1|y2|z0", banner);
    // … hangs one block inside the east wall of a 13-wide room
    assertArrayEquals(new int[] {12, 2, 0}, RoomAnchor.decode(banner, 13, 7, 8));
    // a lantern under the ceiling stays under the ceiling of a taller room
    String lantern = RoomAnchor.encode(0, 7, 0, 9, 7, 8);
    assertArrayEquals(new int[] {0, 9, 0}, RoomAnchor.decode(lantern, 9, 7, 10));
    // a pillar near the centre keeps its offset
    assertArrayEquals(new int[] {2, 0, -1}, RoomAnchor.decode(RoomAnchor.encode(2, 0, -1, 9, 7, 8), 13, 11, 8));
  }

  @Test
  void centreBlocksThatDoNotFitASmallerRoomAreSkipped() {
    String far = RoomAnchor.encode(5, 0, 0, 12, 12, 8);
    assertEquals("x5|y0|z0", far);
    assertNull(RoomAnchor.decode(far, 5, 5, 8));
    assertNull(RoomAnchor.decode("garbage", 5, 5, 8));
    assertNull(RoomAnchor.decode("Q1|y0|z0", 5, 5, 8));
  }
}
