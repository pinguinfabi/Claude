package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class DeepDescentTest {
  @Test
  void ebenenGetHarderForeverWithABossEveryFifth() {
    assertFalse(DeepDescent.bossFloor(4));
    assertTrue(DeepDescent.bossFloor(5));
    assertTrue(DeepDescent.bossFloor(50));
    assertEquals(2, DeepDescent.waves(9));
    assertEquals(3, DeepDescent.waves(10));
    for (int f = 2; f < 200; f++) {
      assertTrue(DeepDescent.level(f) > DeepDescent.level(f - 1));
      assertTrue(DeepDescent.health(f) > DeepDescent.health(f - 1));
      assertTrue(DeepDescent.damage(f) > DeepDescent.damage(f - 1));
    }
    assertEquals(0, DeepDescent.band(1));
    assertEquals(0, DeepDescent.band(5));
    assertEquals(1, DeepDescent.band(6));
    assertEquals(0, DeepDescent.band(5 * Zone.COUNT + 1), "the bands cycle through all mines");
  }

  @Test
  void bossEbenenPayGearAndRunesAndRecordsFollowTheWeek() {
    Profile p = new Profile();
    p.dungeonWins[0] = 1;
    assertTrue(DeepDescent.unlocked(p));
    long money = p.money;
    DeepDescent.reward(p, 3, 4, new Random(1));
    assertTrue(p.money > money);
    assertTrue(p.gear.isEmpty());
    List<String> lines = DeepDescent.reward(p, 3, 5, new Random(1));
    assertEquals(1, p.gear.size());
    assertTrue(p.gear.getFirst().name.startsWith("Tiefengang E5"));
    assertEquals(Runes.total(p) == 1 ? 3 : 2, lines.size());
    assertTrue(DeepDescent.record(p, 7, 202640));
    assertFalse(DeepDescent.record(p, 5, 202640));
    assertEquals(7, DeepDescent.weekBest(p, 202640));
    assertEquals(0, DeepDescent.weekBest(p, 202641), "a new week starts at zero");
    assertTrue(DeepDescent.record(p, 3, 202641));
    assertEquals(3, p.deepWeekBest);
    assertEquals(7, p.deepBest, "the all-time record stays");
  }

  @Test
  void weeksAreIsoWeeksInBerlin() {
    // Monday 2026-09-28 00:30 in Berlin is already week 40.
    long monday = java.time.ZonedDateTime.of(2026, 9, 28, 0, 30, 0, 0, java.time.ZoneId.of("Europe/Berlin")).toInstant().toEpochMilli();
    assertEquals(202640, DeepDescent.week(monday));
    assertEquals(202639, DeepDescent.week(monday - 3_600_000));
  }
}
