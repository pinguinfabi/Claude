package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class ShiniesTest {
  @Test
  void rewardFillsTheGlanzbuch() {
    Profile p = new Profile();
    long money = p.money;
    Shinies.Loot first = Shinies.reward(p, 3, 1, new Random(1));
    assertTrue(first.firstOfKind());
    assertEquals(3, p.glanz);
    assertEquals(1, Shinies.dex(p));
    assertTrue(Shinies.caught(p, 3, 1));
    assertEquals(money + Zone.at(3).orePrice * 60, p.money);
    assertTrue(p.gear.contains(first.item()));
    assertTrue(first.item().rarity.ordinal() >= Gear.Rarity.RARE.ordinal());
    assertEquals(3, Alchemy.ingredient(p, Alchemy.Ingredient.ESSENZ));
    Shinies.Loot again = Shinies.reward(p, 3, 1, new Random(2));
    assertFalse(again.firstOfKind());
    assertEquals(4, p.glanz);
    assertEquals(2, p.shinyKills);
    assertEquals(1, Shinies.dex(p));
  }

  @Test
  void rareButBetterWithTheBook() {
    Profile p = new Profile();
    assertEquals(1 / 500.0, Shinies.chance(p), 1e-12);
    for (int i = 0; i < 10; i++) p.shinyDex.add(Shinies.id(i, 0));
    assertEquals(1.5, Shinies.multiplier(p));
    for (int z = 0; z < Zone.COUNT; z++) for (int k = 0; k < 3; k++) p.shinyDex.add(Shinies.id(z, k));
    assertEquals(51, Shinies.dexSize());
    assertEquals(3, Shinies.multiplier(p));
  }

  @Test
  void itemDropsAreAtLeastRareAndSometimesLegendary() {
    Profile p = new Profile();
    Map<Gear.Rarity, Integer> seen = new EnumMap<>(Gear.Rarity.class);
    Random r = new Random(9);
    for (int i = 0; i < 2000; i++) {
      p.gear.clear();
      seen.merge(Shinies.reward(p, 0, 0, r).item().rarity, 1, Integer::sum);
    }
    assertNull(seen.get(Gear.Rarity.UNCOMMON));
    assertEquals(100, seen.getOrDefault(Gear.Rarity.LEGENDARY, 0), 40);
    assertEquals(500, seen.getOrDefault(Gear.Rarity.EPIC, 0), 80);
  }

  @Test
  void polishOncePerItem() {
    Profile p = new Profile();
    Gear.Item i = Gear.roll(2, Gear.Rarity.EPIC, new Random(5));
    p.gear.add(i);
    double damage = i.damage;
    assertTrue(Shinies.polish(p, i.id).startsWith("Benötigt"));
    p.glanz = 12;
    assertTrue(Shinies.polish(p, i.id).contains("veredelt"));
    assertEquals(damage * 1.1, i.damage, 1e-9);
    assertTrue(i.name.startsWith("✧ "));
    assertEquals(7, p.glanz);
    assertTrue(Shinies.polish(p, i.id).contains("glänzt schon"));
    assertEquals(7, p.glanz);
    assertTrue(Shinies.polish(p, "nope").contains("nicht gefunden"));
  }

  @Test
  void wikiAndLeaderboard() {
    assertTrue(Wiki.page("home").children().contains("shiny"));
    assertTrue(Leaderboard.BOARDS.stream().anyMatch(b -> b.id().equals("shiny")));
  }
}
