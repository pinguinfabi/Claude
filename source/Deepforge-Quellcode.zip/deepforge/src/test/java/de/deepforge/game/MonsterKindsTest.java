package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class MonsterKindsTest {
  private static int[] histogram(int zone) {
    Random r = new Random(7);
    int[] seen = new int[MonsterKinds.COUNT];
    for (int n = 0; n < 20_000; n++) seen[MonsterKinds.roll(zone, r)]++;
    return seen;
  }

  @Test
  void firstMineKeepsTheThreeClassicTypes() {
    int[] seen = histogram(0);
    assertEquals(0, seen[3] + seen[4]);
    for (int k = 0; k < 3; k++) assertTrue(seen[k] > 6000);
  }

  @Test
  void newTypesJoinInLaterMinesButClassicsStayCommon() {
    int[] two = histogram(1);
    assertTrue(two[3] > 0 && two[4] == 0, "bomber from mine 2");
    int[] deep = histogram(10);
    for (int k = 0; k < MonsterKinds.COUNT; k++) assertTrue(deep[k] > 2000, "kind " + k);
    assertTrue(deep[0] > deep[3], "classic types are more common");
  }

  @Test
  void everyTypeHasNamesShapeAndStats() {
    Set<String> names = new HashSet<>();
    for (int k = 0; k < MonsterKinds.COUNT; k++) {
      assertTrue(names.add(MonsterKinds.name(k, false)));
      assertTrue(names.add(MonsterKinds.name(k, true)));
      assertEquals(3, MonsterKinds.shape(k).length);
      assertTrue(MonsterKinds.health(k) > 0 && MonsterKinds.speed(k) > 0 && MonsterKinds.parts(k) > 0);
      assertFalse(MonsterKinds.TIP[k].isBlank());
    }
    assertEquals(1.8, MonsterScaling.health(0, 1) / MonsterScaling.health(0, 0), 1e-9);
    assertTrue(MonsterScaling.health(3, 3) < MonsterScaling.health(3, 0), "the bomber is fragile");
  }

  @Test
  void burstAndPounceHaveClearEdges() {
    assertTrue(MonsterKinds.burstHits(0, MonsterKinds.BURST_RADIUS));
    assertFalse(MonsterKinds.burstHits(0, MonsterKinds.BURST_RADIUS + .01));
    assertTrue(MonsterKinds.BURST_RADIUS > MonsterKinds.BURST_TRIGGER, "you have to step away, not just stand");
    // 1.5 s fuse, walking speed ≈ 4.3 blocks/s: escaping the circle is possible
    assertTrue(MonsterKinds.BURST_FUSE / 20.0 * 4.3 > MonsterKinds.BURST_RADIUS);
    assertTrue(MonsterKinds.pounceHits(1.5, 1.5));
    assertFalse(MonsterKinds.pounceHits(2, 2));
    assertFalse(MonsterKinds.canPounce(2));
    assertTrue(MonsterKinds.canPounce(6));
    assertFalse(MonsterKinds.canPounce(12));
  }
}
