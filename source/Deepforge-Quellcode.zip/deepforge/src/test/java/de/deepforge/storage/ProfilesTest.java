package de.deepforge.storage;

import static org.junit.jupiter.api.Assertions.*;

import de.deepforge.game.*;
import java.nio.file.Path;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class ProfilesTest {
  @TempDir Path dir;

  @Test
  void forestryAndLuckPersistAndInvalidLevelsAreRejected() throws Exception {
    Path file = dir.resolve("forestry.db");
    UUID id = UUID.randomUUID();
    try (Profiles db = new Profiles(file)) {
      Profile p = db.get(id, "Lumberjack", 250);
      p.oreLuck = 3;
      p.axe = 5;
      p.woodLuck = 2;
      p.woodStorage = 1;
      p.sawmill = 2;
      p.forestTier = 1;
      p.resin = 4;
      p.woodOrders = 7;
      p.woodTrees = 5;
      p.woodChopped = 64;
      p.wood[1] = 20;
      p.planks[0] = 15;
      db.save(p);
    }
    try (Profiles db = new Profiles(file)) {
      Profile p = db.get(id, "Lumberjack", 250);
      assertEquals(3, p.oreLuck);
      assertEquals(5, p.axe);
      assertEquals(2, p.woodLuck);
      assertEquals(1, p.woodStorage);
      assertEquals(2, p.sawmill);
      assertEquals(1, p.forestTier);
      assertEquals(4, p.resin);
      assertEquals(7, p.woodOrders);
      assertEquals(5, p.woodTrees);
      assertEquals(64, p.woodChopped);
      assertEquals(20, p.wood[1]);
      assertEquals(15, p.planks[0]);
      p.oreLuck = 11;
      assertThrows(IllegalStateException.class, () -> db.save(p));
    }
  }

  @Test
  void adventureStateAndOptionalPartyLootSurviveRestart() throws Exception {
    Path file = dir.resolve("adventure.db");
    UUID a = UUID.randomUUID(), b = UUID.randomUUID(), receipt = UUID.randomUUID();
    try (Profiles db = new Profiles(file)) {
      Profile p = db.get(a, "A", 250);
      db.get(b, "B", 250);
      p.tutorialStep = 7;
      p.tutorialPaused = true;
      p.manualSmelted = 12;
      p.soldBars = 10;
      p.depositedOre = 30;
      p.dodges = 3;
      p.healsUsed = 2;
      AdventureGear.grant(p, AdventureGear.artifact(0, 0, new java.util.Random(1)));
      db.save(p);
      var gains = db.rewardDungeon(java.util.List.of(a, b), receipt, 0, 0, 4000, 1, 14);
      assertEquals(2, gains.size(), "both players get a reward summary");
      assertTrue(gains.get(a.toString()).money > 0);
      assertFalse(gains.get(a.toString()).lines().isEmpty());
    }
    try (Profiles db = new Profiles(file)) {
      assertTrue(
          db.rewardDungeon(java.util.List.of(a, b), receipt, 0, 0, 4000, 1, 14).isEmpty(),
          "a repeated receipt pays nothing and reports nothing");
      Profile p = db.get(a, "A", 250);
      assertEquals(7, p.tutorialStep);
      assertTrue(p.tutorialPaused);
      assertEquals(12, p.manualSmelted);
      assertEquals(10, p.soldBars);
      assertEquals(30, p.depositedOre);
      assertEquals(3, p.dodges);
      assertEquals(2, p.healsUsed);
      assertEquals(0, p.gear.getFirst().archetype);
      assertTrue(p.artifactCollection.contains(0));
      assertEquals(7, p.gear.size());
      assertEquals(6, db.get(b, "B", 250).gear.size());
      for (UUID id : java.util.List.of(a, b)) {
        Profile saved = db.get(id, "member", 250);
        assertEquals(1850, saved.money);
        assertEquals(1, saved.adventureRescues);
        assertEquals(1, saved.adventureChallenges);
        assertEquals(1, saved.adventureTreasures);
      }
    }
  }

  @Test
  void healingCooldownAndProgressSurviveRestartAndReceiptReplay() throws Exception {
    Path file = dir.resolve("progress-heal.db");
    UUID id = UUID.randomUUID(), receipt = UUID.randomUUID();
    try (Profiles db = new Profiles(file)) {
      Profile p = db.get(id, "Miner", 250);
      p.dungeonLevel = 17;
      p.healingCharges = 5;
      assertEquals(11, Healing.consume(p, 4, 20, 100_000));
      db.save(p);
      db.rewardDungeon(java.util.List.of(id), receipt, 0, 0, 4000, 17);
      assertEquals(18, db.get(id, "Miner", 250).dungeonLevel);
    }
    try (Profiles db = new Profiles(file)) {
      Profile p = db.get(id, "Miner", 250);
      assertEquals(18, p.dungeonLevel);
      assertEquals(6, p.healingCharges);
      assertEquals(120_000, p.healingReadyAt);
      assertEquals(0, Healing.consume(p, 2, 20, 119_999));
      assertEquals(6, p.healingCharges);
      long cash = p.money;
      db.rewardDungeon(java.util.List.of(id), receipt, 0, 0, 4000, 17);
      assertEquals(cash, db.get(id, "Miner", 250).money);
      assertEquals(18, db.get(id, "Miner", 250).dungeonLevel);
      assertEquals(17, p.gear.getFirst().dungeonRank);
      assertEquals(11, Healing.consume(p, 2, 20, 120_000));
    }
  }

  @Test
  void legacyDungeonVictoriesMigrateWithoutResettingMoneyOrRegrantingHealing() throws Exception {
    Path file = dir.resolve("legacy-dungeon.db");
    UUID id = UUID.randomUUID();
    try (Profiles db = new Profiles(file)) {
      Profile p = db.get(id, "Miner", 9876);
      p.dungeonWins[0] = 2;
      p.dungeonWins[1] = 1;
      db.save(p);
    }
    try (var connection =
            java.sql.DriverManager.getConnection("jdbc:sqlite:" + file.toAbsolutePath());
        var st = connection.createStatement()) {
      com.google.gson.JsonObject json;
      try (var result = st.executeQuery("SELECT data FROM profiles")) {
        result.next();
        json = com.google.gson.JsonParser.parseString(result.getString(1)).getAsJsonObject();
      }
      json.remove("dungeonLevel");
      json.remove("healingCharges");
      json.remove("healingReadyAt");
      try (var update = connection.prepareStatement("UPDATE profiles SET data=?")) {
        update.setString(1, json.toString());
        update.executeUpdate();
      }
    }
    try (Profiles db = new Profiles(file)) {
      Profile p = db.get(id, "Miner", 250);
      assertEquals(4, p.dungeonLevel);
      assertEquals(9876, p.money);
      assertEquals(1, p.healingCharges);
      Healing.consume(p, 1, 20, 0);
      db.save(p);
    }
    try (Profiles db = new Profiles(file)) {
      assertEquals(0, db.get(id, "Miner", 250).healingCharges);
      assertEquals(4, db.get(id, "Miner", 250).dungeonLevel);
    }
  }

  @Test
  void partyRewardsCommitTogetherAndSurviveRestartWithoutDuplication() throws Exception {
    UUID a = UUID.randomUUID(), b = UUID.randomUUID(), run = UUID.randomUUID();
    Path file = dir.resolve("dungeon.db");
    try (Profiles db = new Profiles(file)) {
      db.get(a, "A", 250);
      db.get(b, "B", 250);
      db.evict(b);
      db.rewardDungeon(java.util.List.of(a, b), run, 0, 0, 4000);
      assertEquals(850, db.get(a, "A", 250).money);
      assertEquals(850, db.get(b, "B", 250).money);
    }
    try (Profiles db = new Profiles(file)) {
      db.rewardDungeon(java.util.List.of(a, b), run, 0, 0, 4000);
      for (UUID id : java.util.List.of(a, b)) {
        Profile p = db.get(id, "Member", 250);
        assertEquals(850, p.money);
        assertEquals(2, p.gear.size());
        assertEquals(1, p.dungeonWins[0]);
        assertEquals(4000, p.dungeonBestTicks[0]);
      }
    }
  }

  @Test
  void failedSecondPartyRewardRollsBackFirstAndLeavesCacheUnchanged() throws Exception {
    UUID a = UUID.randomUUID(), b = UUID.randomUUID();
    Path file = dir.resolve("rollback.db");
    try (Profiles db = new Profiles(file)) {
      db.get(a, "A", 250);
      db.get(b, "B", 250);
      try (var connection =
              java.sql.DriverManager.getConnection("jdbc:sqlite:" + file.toAbsolutePath());
          var st = connection.createStatement()) {
        st.execute(
            "CREATE TRIGGER fail_reward BEFORE UPDATE ON profiles WHEN NEW.id='"
                + b
                + "' BEGIN SELECT RAISE(ABORT,'test transaction failure'); END");
      }
      assertThrows(
          IllegalStateException.class,
          () -> db.rewardDungeon(java.util.List.of(a, b), UUID.randomUUID(), 0, 0, 4000, 1, 14));
      assertEquals(250, db.get(a, "A", 250).money);
      assertEquals(1, db.get(a, "A", 250).dungeonLevel);
      assertEquals(1, db.get(a, "A", 250).healingCharges);
      assertTrue(db.get(a, "A", 250).gear.isEmpty());
      assertEquals(0, db.get(a, "A", 250).adventureRescues);
      assertEquals(0, db.get(a, "A", 250).bossTokens[0]);
      assertEquals(250, db.get(b, "B", 250).money);
      db.evict(a);
      assertEquals(250, db.get(a, "A", 250).money);
    }
  }

  @Test
  void industryAndWorkerPauseSurviveRestartWithoutReclaimingDiscoveries() throws Exception {
    UUID id = UUID.randomUUID();
    Path file = dir.resolve("industry.db");
    try (Profiles db = new Profiles(file)) {
      Profile p = db.get(id, "Miner", 10000);
      p.researchNotes = 10;
      p.bars[0] = 4;
      Industry.research(p, 0);
      Industry.discover(p, 0);
      p.workers.add(new Profile.Worker("Borin", Profile.Job.MINER, 0));
      p.workers.getFirst().paused = true;
      p.collected[0] = 2000;
      Industry.collection(p, 0);
      Industry.collection(p, 0);
      db.save(p);
    }
    try (Profiles db = new Profiles(file)) {
      Profile p = db.get(id, "Miner", 250);
      assertEquals(1, p.research[0]);
      assertEquals(2, p.collectionTiers[0]);
      assertTrue(p.workers.getFirst().paused);
      assertTrue(p.expeditions[0]);
      long money = p.money, notes = p.researchNotes;
      Industry.discover(p, 0);
      assertEquals(money, p.money);
      assertEquals(notes, p.researchNotes);
    }
  }

  @Test
  void stateAndSettlementTimestampSurviveRestart() throws Exception {
    UUID id = UUID.randomUUID();
    long now = System.currentTimeMillis();
    try (Profiles db = new Profiles(dir.resolve("test.db"))) {
      Profile p = db.get(id, "Miner", 250);
      p.lastSettled = now - 3600000;
      p.budget = 10000;
      p.fuel = 1000;
      p.workers.add(new Profile.Worker("Borin", Profile.Job.MINER, 0));
      Production.settle(p, now);
      db.save(p);
    }
    try (Profiles db = new Profiles(dir.resolve("test.db"))) {
      Profile p = db.get(id, "Miner", 250);
      assertEquals(120, p.stock[0]);
      assertEquals(0, Production.settle(p, now).minutes());
      assertEquals(120, p.stock[0]);
      assertEquals(1, p.workers.size());
    }
  }

  @Test
  void playerPlotsAreUniqueAndPersistent() throws Exception {
    UUID a = UUID.randomUUID(), b = UUID.randomUUID();
    try (Profiles db = new Profiles(dir.resolve("plots.db"))) {
      assertEquals(0, db.get(a, "A", 250).plot);
      assertEquals(1, db.get(b, "B", 250).plot);
    }
    try (Profiles db = new Profiles(dir.resolve("plots.db"))) {
      assertEquals(0, db.get(a, "A", 250).plot);
      assertEquals(2, db.get(UUID.randomUUID(), "C", 250).plot);
    }
  }

  @Test
  void equipmentAndRewardReceiptSurviveRestartTogether() throws Exception {
    UUID id = UUID.randomUUID();
    String itemId;
    try (Profiles db = new Profiles(dir.resolve("gear.db"))) {
      Profile p = db.get(id, "Miner", 250);
      var item = Gear.bossLoot(p, "persistent-fight", 0, 0, new java.util.Random(42)).getFirst();
      item.favorite = true;
      p.huntKills[0] = 19;
      Gear.claimHunt(p, 0);
      Gear.equip(p, item.id);
      itemId = item.id;
      db.save(p);
    }
    try (Profiles db = new Profiles(dir.resolve("gear.db"))) {
      Profile p = db.get(id, "Miner", 250);
      assertEquals(1200, p.money);
      assertEquals(4, p.huntKills[0]);
      assertEquals(1, p.huntsCompleted[0]);
      assertEquals(3, p.dust);
      assertEquals(2, p.schema);
      assertNotNull(Gear.find(p, itemId));
      assertTrue(Gear.find(p, itemId).favorite);
      assertTrue(p.equipped.containsValue(itemId));
      int size = p.gear.size();
      assertTrue(Gear.bossLoot(p, "persistent-fight", 0, 0, new java.util.Random()).isEmpty());
      assertEquals(size, p.gear.size());
      assertEquals(1200, p.money);
      assertEquals(2, p.bossTokens[0]);
      assertEquals(1, p.bossWins[0]);
    }
  }

  @Test
  void legacyProfileMigratesWithoutChangingMoneyWorkersOrSettlement() throws Exception {
    UUID id = UUID.randomUUID();
    Path file = dir.resolve("legacy.db");
    try (Profiles db = new Profiles(file)) {
      Profile p = db.get(id, "Veteran", 12345);
      p.zone = 3;
      p.lastSettled = 123456789;
      p.stock[3] = 81;
      p.furnace = 2;
      p.workers.add(new Profile.Worker("Borin", Profile.Job.MINER, 3));
      db.save(p);
    }
    try (var db = java.sql.DriverManager.getConnection("jdbc:sqlite:" + file.toAbsolutePath());
        var statement = db.createStatement()) {
      String json;
      try (var result = statement.executeQuery("SELECT data FROM profiles")) {
        result.next();
        json = result.getString(1);
      }
      var object = com.google.gson.JsonParser.parseString(json).getAsJsonObject();
      object.addProperty("schema", 1);
      for (String key :
          java.util.List.of(
              "gear",
              "equipped",
              "dust",
              "bossTokens",
              "monsterParts",
              "bossWins",
              "dryStreak",
              "rewardReceipts",
              "discovered")) object.remove(key);
      try (var update = db.prepareStatement("UPDATE profiles SET data=?")) {
        update.setString(1, object.toString());
        update.executeUpdate();
      }
    }
    try (Profiles db = new Profiles(file)) {
      Profile p = db.get(id, "Veteran", 250);
      assertEquals(2, p.schema);
      assertTrue(p.gear.isEmpty());
      assertEquals(7, p.bossTokens.length);
      assertEquals(21, p.bossWins.length);
      assertEquals(12345, p.money);
      assertEquals(3, p.zone);
      assertEquals(123456789, p.lastSettled);
      assertEquals(81, p.stock[3]);
      assertEquals(2, p.furnace);
      assertEquals("Borin", p.workers.getFirst().name);
      db.save(p);
    }
  }

  @Test
  void duplicateEquipmentAndBrokenSlotReferencesCannotBeSaved() throws Exception {
    try (Profiles db = new Profiles(dir.resolve("invalid.db"))) {
      Profile p = db.get(UUID.randomUUID(), "Miner", 250);
      var item = Gear.roll(0, Gear.Rarity.RARE, new java.util.Random(1));
      p.gear.add(item);
      p.gear.add(item);
      assertThrows(IllegalStateException.class, () -> db.save(p));
      p.gear.removeLast();
      p.equipped.put("WEAPON", "missing");
      assertThrows(IllegalStateException.class, () -> db.save(p));
      p.equipped.clear();
      item.damage = Double.NaN;
      assertThrows(IllegalStateException.class, () -> db.save(p));
    }
  }
}
