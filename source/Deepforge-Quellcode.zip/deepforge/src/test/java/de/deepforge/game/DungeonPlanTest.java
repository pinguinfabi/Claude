package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import de.deepforge.game.DungeonPlan.*;
import java.util.*;
import org.junit.jupiter.api.Test;

class DungeonPlanTest {
  private static final int SEEDS = 1500;

  @Test
  void layoutsAreVariedButAlwaysValid() {
    Set<String> shapes = new HashSet<>();
    Set<Integer> sizes = new HashSet<>();
    for (long seed = 0; seed < SEEDS; seed++) {
      int waves = DungeonRules.waves((int) (seed % 40) + 1);
      DungeonPlan plan = DungeonPlan.generate(seed * 7919, waves, (int) (seed % 40) + 1);
      String where = "seed " + seed;
      assertTrue(plan.mainRooms >= 5 && plan.mainRooms <= 8, where);
      sizes.add(plan.mainRooms);
      // Instances are 128 blocks apart in x.
      assertTrue(plan.minX >= -62 && plan.maxX <= 62, where + " x " + plan.minX + ".." + plan.maxX);
      List<Room> rooms = plan.rooms;
      for (int i = 0; i < rooms.size(); i++)
        for (int j = i + 1; j < rooms.size(); j++) {
          Room a = rooms.get(i), b = rooms.get(j);
          boolean apart =
              Math.abs(a.cx - b.cx) > a.hw + b.hw + 1 || Math.abs(a.cz - b.cz) > a.hd + b.hd + 1;
          assertTrue(apart, where + ": rooms " + i + " and " + j + " overlap");
        }
      StringBuilder layout = new StringBuilder();
      for (int i = 0; i < plan.mainRooms; i++) layout.append(rooms.get(i).gx).append(rooms.get(i).gz);
      shapes.add(layout.toString());
      // Waves, puzzles and roles.
      assertEquals(waves, rooms.subList(0, plan.mainRooms).stream().mapToInt(r -> r.waves).sum(), where);
      assertEquals(Role.BOSS, plan.boss().role);
      assertEquals(Shape.ARENA, plan.boss().shape);
      assertTrue(plan.boss().waves >= 1);
      List<Puzzle> puzzles =
          rooms.stream().map(r -> r.puzzle).filter(Objects::nonNull).toList();
      assertTrue(puzzles.size() >= 2 && puzzles.size() <= 3, where + " puzzles " + puzzles);
      assertEquals(puzzles.size(), new HashSet<>(puzzles).size(), where + " repeated puzzle");
      for (Room r : rooms) {
        if (r.puzzle == Puzzle.TRAPS) {
          assertEquals(Shape.GAUNTLET, r.shape, where);
          assertEquals(r.in, r.out.opposite(), where + " gauntlet must be straight");
        }
        if (r.puzzle != null) assertNotEquals(Shape.BRIDGE, r.shape);
        if (r.role == Role.SIDE) {
          Room parent = rooms.get(r.parent);
          assertEquals(r.index, parent.sideRoom);
          assertNotNull(plan.corridor(parent.index, r.index), where);
          if (r.side == Side.TREASURE)
            assertTrue(
                rooms.subList(0, r.parent).stream().anyMatch(m -> m.keyBarrel),
                where + " key before treasure");
        }
      }
      // Corridors: connected steps, gentle stairs, doors at the right floors, no clashes.
      Map<Long, Integer> owner = new HashMap<>();
      for (Corridor c : plan.corridors) {
        Room from = rooms.get(c.from), to = rooms.get(c.to);
        Tile first = c.tiles.getFirst(), last = c.tiles.getLast();
        assertEquals(from.floor, first.floor(), where);
        assertEquals(to.floor, last.floor(), where);
        for (int t = 1; t < c.tiles.size(); t++) {
          Tile a = c.tiles.get(t - 1), b = c.tiles.get(t);
          assertEquals(1, Math.abs(a.x() - b.x()) + Math.abs(a.z() - b.z()), where + " gap");
          assertTrue(Math.abs(a.floor() - b.floor()) <= 1, where + " step too high");
          if (b.floor() > a.floor()) assertTrue(b.stair(), where + " missing stair up");
          if (b.floor() < a.floor()) assertTrue(a.stair(), where + " missing stair down");
        }
        for (Tile t : c.tiles) {
          long k = ((long) t.x() << 32) ^ (t.z() & 0xffffffffL);
          Integer other = owner.put(k, c.index);
          assertTrue(other == null || other == c.index, where + " corridors cross");
          Room in = plan.roomAt(t.x(), t.z());
          assertTrue(in == null || in == from || in == to, where + " corridor through a room");
        }
      }
      // Every main room is reachable in order, doors open into the corridor.
      for (int i = 0; i + 1 < plan.mainRooms; i++) {
        Corridor c = plan.corridor(i, i + 1);
        assertNotNull(c, where);
        Room a = rooms.get(i);
        Tile door = c.tiles.getFirst();
        assertEquals(DungeonPlan.Paint.AIR, plan.paint(door.x(), a.floor, door.z()), where);
        assertEquals(DungeonPlan.Paint.AIR, plan.paint(door.x(), a.floor + 1, door.z()), where);
      }
    }
    assertTrue(shapes.size() > 100, "many different layouts: " + shapes.size());
    assertEquals(Set.of(5, 6, 7, 8), sizes);
  }

  @Test
  void corridorsAreWalkable() {
    for (long seed = 0; seed < 300; seed++) {
      DungeonPlan plan = DungeonPlan.generate(seed, 6, 10);
      for (Corridor c : plan.corridors)
        for (Tile t : c.tiles) {
          Paint floor = plan.paint(t.x(), t.floor() - 1, t.z());
          assertTrue(
              floor == Paint.PATH || floor.name().startsWith("STAIR") || floor == Paint.FLOOR
                  || floor == Paint.ACCENT,
              "seed " + seed + " floor " + floor + " at " + t);
          for (int y = 0; y < 2; y++)
            assertEquals(Paint.AIR, plan.paint(t.x(), t.floor() + y, t.z()), "seed " + seed + " head at " + t);
        }
    }
  }

  @Test
  void sameSeedSameDungeon() {
    DungeonPlan a = DungeonPlan.generate(42, 6, 5), b = DungeonPlan.generate(42, 6, 5);
    assertEquals(a.rooms.size(), b.rooms.size());
    for (int i = 0; i < a.rooms.size(); i++) {
      assertEquals(a.rooms.get(i).cx, b.rooms.get(i).cx);
      assertEquals(a.rooms.get(i).puzzle, b.rooms.get(i).puzzle);
    }
    assertTrue(a.minutes() >= 50, "longer runs for more rooms");
    assertTrue(a.volume() < 400_000, "buildable in a few seconds: " + a.volume());
  }
}
