package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class WeaponAbilitiesTest {
  @Test
  void everyWeaponTypeHasSeveralAbilitiesAndAWeaponKeepsItsOwn() {
    for (String style : Gear.WEAPONS) assertTrue(WeaponAbilities.of(style).size() >= 2, style);
    Random r = new Random(3);
    Set<WeaponAbilities.Ability> seen = EnumSet.noneOf(WeaponAbilities.Ability.class);
    for (int n = 0; n < 400; n++) {
      Gear.Item w = Gear.roll(2, Gear.Rarity.RARE, r);
      w.slot = Gear.Slot.WEAPON;
      WeaponAbilities.Ability a = WeaponAbilities.of(w);
      assertEquals(w.style, a.style);
      assertEquals(a, WeaponAbilities.of(w), "stable per weapon");
      seen.add(a);
    }
    assertEquals(WeaponAbilities.Ability.values().length, seen.size());
    assertEquals(WeaponAbilities.Ability.WIRBEL, WeaponAbilities.of((Gear.Item) null));
  }

  @Test
  void rarityAndQualityScaleThePowerAndUnlockExtras() {
    Gear.Item w = new Gear.Item();
    w.quality = 100;
    w.rarity = Gear.Rarity.UNCOMMON;
    assertEquals(.8, WeaponAbilities.power(w), 1e-9);
    assertEquals(0, WeaponAbilities.healPerHit(w));
    w.rarity = Gear.Rarity.MYTHIC;
    assertEquals(1.6, WeaponAbilities.power(w), 1e-9);
    assertTrue(WeaponAbilities.echo(w));
    assertTrue(WeaponAbilities.healPerHit(w) > 0);
    int slow = WeaponAbilities.of(w).cooldown;
    assertEquals(Math.round(slow * .75), WeaponAbilities.cooldown(w));
    w.quality = 80;
    assertEquals(1.28, WeaponAbilities.power(w), 1e-9);
    assertTrue(WeaponAbilities.lore(w).startsWith("Rechtsklick: "));
  }
}
