package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class RapidCombatTest {
  @Test
  void tempoEquipmentStillImprovesEveryHitWithoutGatingClicks() {
    Profile p = new Profile();
    Gear.Stats base = Gear.stats(p);
    Gear.Item ring = new Gear.Item();
    ring.name = "Tempo";
    ring.slot = Gear.Slot.RING;
    ring.haste = .3;
    p.gear.add(ring);
    Gear.equip(p, ring.id);
    assertTrue(RapidCombat.damage(Gear.stats(p)) > RapidCombat.damage(base));
    assertEquals(base.damage() * .65, RapidCombat.damage(base), .0001);
  }

  @Test
  void rapidPostureCannotBreakGuardsAsFastAsOldFullStrengthSpam() {
    Gear.Stats stats = Gear.stats(new Profile());
    assertEquals(stats.stagger() * .45, RapidCombat.posture(stats), .0001);
    assertEquals(8960, RapidCombat.bossHealth(0, 0));
    assertTrue(RapidCombat.bossHealth(6, 2) > RapidCombat.bossHealth(6, 1));
  }

  @Test
  void partyBossesScaleLikeDungeons() {
    assertEquals(1, RapidCombat.partyHealth(1));
    assertEquals(1, RapidCombat.partyHealth(0));
    assertEquals(3.55, RapidCombat.partyHealth(4), 1e-9);
    assertEquals(1.18, RapidCombat.partyDamage(4), 1e-9);
    // A four-player party has more total damage than the extra boss health.
    assertTrue(RapidCombat.partyHealth(4) < 4);
  }

  @Test
  void guardCannotBeChainBrokenBeforeBossGetsSixSecondsToAct() {
    assertTrue(RapidCombat.canBuildPosture(0, 0));
    assertFalse(RapidCombat.canBuildPosture(150, 190));
    assertFalse(RapidCombat.canBuildPosture(190, 190));
    assertFalse(RapidCombat.canBuildPosture(309, 190));
    assertTrue(RapidCombat.canBuildPosture(310, 190));
  }
}
