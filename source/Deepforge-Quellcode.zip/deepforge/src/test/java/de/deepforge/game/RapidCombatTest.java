package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class RapidCombatTest {
  @Test
  void tempoEquipmentStillImprovesEveryHitWithoutGatingClicks() {
    Profile p = new Profile();
    Gear.Stats base = Gear.stats(p);
    Gear.Item ring = new Gear.Item();
    ring.name = "Tempo";
    ring.slot = Gear.Slot.RING;
    ring.haste = .3;
    p.gear.add(ring);
    Gear.equip(p, ring.id);
    assertTrue(RapidCombat.damage(Gear.stats(p)) > RapidCombat.damage(base));
    assertEquals(base.damage() * .65, RapidCombat.damage(base), .0001);
  }

  @Test
  void rapidPostureCannotBreakGuardsAsFastAsOldFullStrengthSpam() {
    Gear.Stats stats = Gear.stats(new Profile());
    assertEquals(stats.stagger() * .45, RapidCombat.posture(stats), .0001);
    assertEquals(8960, RapidCombat.bossHealth(0, 0));
    assertTrue(RapidCombat.bossHealth(6, 2) > RapidCombat.bossHealth(6, 1));
  }

  @Test
  void dungeonGroupFactorMatchesDungeonHealth() {
    assertEquals(1, RapidCombat.partyHealth(1));
    assertEquals(1, RapidCombat.partyHealth(0));
    assertEquals(3.55, RapidCombat.partyHealth(4), 1e-9);
    for (int players = 1; players <= 4; players++)
      assertEquals(
          DungeonRules.health(0, 0, 1, 1, false) * RapidCombat.partyHealth(players),
          DungeonRules.health(0, 0, players, 1, false),
          1e-9);
  }

  @Test
  void guardCannotBeChainBrokenBeforeBossGetsSixSecondsToAct() {
    assertTrue(RapidCombat.canBuildPosture(0, 0));
    assertFalse(RapidCombat.canBuildPosture(150, 190));
    assertFalse(RapidCombat.canBuildPosture(190, 190));
    assertFalse(RapidCombat.canBuildPosture(309, 190));
    assertTrue(RapidCombat.canBuildPosture(310, 190));
  }

  @Test
  void comboChainsWithinTheWindowAndCapsAtThirtyPercent() {
    assertEquals(1, RapidCombat.nextCombo(0, 0, 100));
    assertEquals(2, RapidCombat.nextCombo(1, 100, 100 + RapidCombat.COMBO_WINDOW_TICKS));
    assertEquals(1, RapidCombat.nextCombo(7, 100, 101 + RapidCombat.COMBO_WINDOW_TICKS));
    assertEquals(1.0, RapidCombat.comboMultiplier(1), 1e-9);
    assertEquals(1.12, RapidCombat.comboMultiplier(5), 1e-9);
    assertEquals(1.30, RapidCombat.comboMultiplier(11), 1e-9);
    assertEquals(1.30, RapidCombat.comboMultiplier(80), 1e-9);
  }
}
