package de.deepforge.world;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class CampBlueprintTest {
  private static final CampBlueprint CAMP = CampBlueprint.create();
  private static final Set<String> WALK_THROUGH =
      Set.of("air", "short_grass", "fern", "poppy", "azure_bluet");

  private boolean open(int x, int z) {
    return WALK_THROUGH.contains(CAMP.at(x, 201, z))
        && WALK_THROUGH.contains(CAMP.at(x, 202, z))
        && !Set.of("air", "water[level=0]").contains(CAMP.at(x, 200, z));
  }

  private Set<Integer> reachable() {
    Set<Integer> seen = new HashSet<>();
    ArrayDeque<int[]> queue = new ArrayDeque<>();
    queue.add(new int[] {0, -6});
    seen.add(CampBlueprint.key(0, 201, -6));
    while (!queue.isEmpty()) {
      int[] p = queue.remove();
      for (int[] d : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
        int x = p[0] + d[0], z = p[1] + d[1];
        if (Math.abs(x) > 55 || z < -68 || z > 51 || !open(x, z)) continue;
        if (seen.add(CampBlueprint.key(x, 201, z))) queue.add(new int[] {x, z});
      }
    }
    return seen;
  }

  @Test
  void allSevenStationsHaveWalkableApproaches() {
    Set<Integer> seen = reachable();
    for (var station : CampBlueprint.STATIONS) {
      boolean accessible = false;
      for (int[] d : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}})
        accessible |= seen.contains(CampBlueprint.key(station.x() + d[0], 201, station.z() + d[1]));
      assertTrue(accessible, station.id() + " is blocked");
    }
  }

  @Test
  void allBuildingsAndWorkerDestinationsAreReachable() {
    Set<Integer> seen = reachable();
    for (int[] p :
        new int[][] {
          {-23, -13},
          {23, -13},
          {-24, 13},
          {23, 14},
          {-23, -19},
          {22, -20},
          {-23, 19},
          {24, 18},
          {22, -6},
          {-22, 10},
          {0, -24},
          {-7, 21},
          {-12, 21},
          {0, 35},
          {-53, -13}
        })
      assertTrue(
          seen.contains(CampBlueprint.key(p[0], 201, p[1])), Arrays.toString(p) + " unreachable");
  }

  @Test
  void redesignCannotTouchUndergroundRooms() {
    assertTrue(CAMP.blocks().keySet().stream().allMatch(k -> CampBlueprint.y(k) > 184));
  }

  @Test
  void blueprintStaysWithinItsOwnersPlot() {
    for (int k : CAMP.blocks().keySet()) {
      assertTrue(Math.abs(CampBlueprint.x(k)) <= 86);
      assertTrue(CampBlueprint.z(k) >= -80 && CampBlueprint.z(k) <= 102);
      assertEquals(
          k, CampBlueprint.key(CampBlueprint.x(k), CampBlueprint.y(k), CampBlueprint.z(k)));
    }
  }

  @Test
  void spawnHasGroundAndHeadroom() {
    assertTrue(open(0, -6));
    assertFalse(CAMP.at(0, 200, -6).equals("air"));
  }

  @Test
  void decorativeLeavesWillNotDecay() {
    assertTrue(
        CAMP.blocks().values().stream()
            .filter(s -> s.contains("leaves"))
            .allMatch(s -> s.contains("persistent=true")));
  }
}
