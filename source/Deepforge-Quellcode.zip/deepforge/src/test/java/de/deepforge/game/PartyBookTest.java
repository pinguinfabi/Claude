package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class PartyBookTest {
  @Test
  void invitationsRequireAcceptanceExpireAndCannotExceedFour() {
    PartyBook book = new PartyBook();
    UUID leader = UUID.randomUUID();
    book.create(leader);
    UUID expired = UUID.randomUUID();
    book.invite(leader, expired, 0);
    assertThrows(IllegalArgumentException.class, () -> book.accept(expired, 60_000));
    for (int i = 0; i < 3; i++) {
      UUID guest = UUID.randomUUID();
      book.invite(leader, guest, 0);
      assertNull(book.get(guest));
      book.accept(guest, 100);
    }
    assertThrows(IllegalArgumentException.class, () -> book.invite(leader, UUID.randomUUID(), 0));
    assertEquals(4, book.get(leader).members.size());
  }

  @Test
  void rosterChangesClearReadinessAndLeaderDeparturePromotesMember() {
    PartyBook book = new PartyBook();
    UUID a = UUID.randomUUID(), b = UUID.randomUUID();
    book.create(a);
    book.ready(a);
    book.invite(a, b, 0);
    book.accept(b, 1);
    assertTrue(book.get(a).ready.isEmpty());
    assertThrows(IllegalArgumentException.class, () -> book.roster(a));
    book.ready(a);
    book.ready(b);
    assertEquals(List.of(a, b), book.roster(a));
    assertThrows(IllegalArgumentException.class, () -> book.roster(b));
    book.leave(a);
    assertEquals(b, book.get(b).leader);
    assertTrue(book.get(b).ready.isEmpty());
    assertNull(book.get(a));
    book.ready(b);
    assertEquals(List.of(b), book.roster(b));
  }

  @Test
  void concurrentInvitationsCannotMoveAnAlreadyJoinedPlayer() {
    PartyBook book = new PartyBook();
    UUID a = UUID.randomUUID(), b = UUID.randomUUID(), guest = UUID.randomUUID();
    book.create(a);
    book.create(b);
    book.invite(a, guest, 0);
    book.invite(b, guest, 1);
    book.accept(guest, 2);
    assertSame(book.get(b), book.get(guest));
    assertThrows(IllegalArgumentException.class, () -> book.invite(a, guest, 3));
    assertThrows(IllegalArgumentException.class, () -> book.accept(guest, 4));
  }

  @Test
  void disbandedOrTransferredLeadersCannotLeaveValidInvitations() {
    PartyBook book = new PartyBook();
    UUID a = UUID.randomUUID(), b = UUID.randomUUID();
    book.create(a);
    book.invite(a, b, 0);
    book.leave(a);
    assertThrows(IllegalArgumentException.class, () -> book.accept(b, 1));
  }
}
