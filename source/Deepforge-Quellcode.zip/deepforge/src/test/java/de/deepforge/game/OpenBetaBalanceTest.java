package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/** 0.22.0: dungeons keep up with the mines, progression between mines takes longer. */
class OpenBetaBalanceTest {
  @Test
  void dungeonEnemiesGrowLikeMineMonsters() {
    for (int z = 1; z < Zone.COUNT; z++) {
      double dungeon = DungeonRules.health(z, 0, 1, 1, false) / DungeonRules.health(0, 0, 1, 1, false);
      double mine = MonsterScaling.health(z, 0) / MonsterScaling.health(0, 0);
      assertTrue(dungeon >= mine * .5, "zone " + z + ": " + dungeon + " vs " + mine);
      assertTrue(dungeon <= mine, "never tougher per head than the mine itself");
    }
    // the first mine stays as it was for new players
    assertEquals((22 + 6) * 4, DungeonRules.health(0, 0, 1, 1, false), 1e-9);
  }

  @Test
  void difficultiesAreFarApart() {
    for (int z = 0; z < Zone.COUNT; z++) {
      double n = DungeonRules.health(z, 0, 1, 1, false), v = DungeonRules.health(z, 1, 1, 1, false),
          a = DungeonRules.health(z, 2, 1, 1, false);
      assertEquals(1.8, v / n, 1e-9);
      assertEquals(2.8, a / n, 1e-9);
      assertTrue(DungeonRules.damage(z, 2, true) / DungeonRules.damage(z, 0, true) >= 2);
    }
  }

  @Test
  void deepMinesCostMoreAndStayInOrder() {
    assertEquals(6_000_000, Zone.at(7).unlockCost, "Leerenbruch → Kernschmelze");
    assertEquals(3000, Zone.at(1).unlockCost, "the start stays quick");
    for (int z = 2; z < Zone.COUNT; z++)
      assertTrue(Zone.at(z).unlockCost > Zone.at(z - 1).unlockCost * 1.7, "mine " + (z + 1));
  }

  @Test
  void bladeAndProtectionFollowTheSameSteeperCurve() {
    Profile p = new Profile();
    p.sword = p.armor = 14;
    assertTrue(Economy.upgradeCost(p, "sword") >= 250_000);
    assertTrue(Economy.upgradeCost(p, "armor") >= 300_000);
    p.sword = p.armor = 2;
    assertEquals(250L * 9, Economy.upgradeCost(p, "sword"), "early levels unchanged");
  }
}
