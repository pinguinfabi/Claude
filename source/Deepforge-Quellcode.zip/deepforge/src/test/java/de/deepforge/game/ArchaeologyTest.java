package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class ArchaeologyTest {
  @Test
  void fourFindsPerMineOneRare() {
    assertEquals(Zone.COUNT * 4, Archaeology.ALL.size());
    Set<String> names = new HashSet<>();
    for (Archaeology.Find f : Archaeology.ALL) {
      assertTrue(names.add(f.name()), "unique name " + f.name());
      assertFalse(f.story().isBlank());
      assertEquals(f.index() == 3, f.rare());
      assertEquals(f, Archaeology.byId(f.id()));
      assertEquals(f.rare(), f.model().equals("find_rare"));
    }
  }

  @Test
  void diggingFindsRoughlyAtTheStatedRate() {
    Profile p = new Profile();
    Random r = new Random(7);
    int finds = 0, rare = 0;
    for (int i = 0; i < 200_000; i++) {
      Archaeology.Find f = Archaeology.dig(p, 4, r);
      if (f == null) continue;
      finds++;
      if (f.rare()) rare++;
      assertEquals(4, f.zone());
    }
    assertEquals(200_000 * Archaeology.CHANCE, finds, 200);
    assertEquals(finds * Archaeology.RARE_SHARE, rare, 60);
    assertEquals(finds, p.finds.values().stream().mapToInt(Integer::intValue).sum());
  }

  @Test
  void donateSellAndCompleteAMine() {
    Profile p = new Profile();
    Archaeology.Find helmet = Archaeology.find(0, 3);
    assertTrue(Archaeology.donate(p, helmet).contains("noch nicht gefunden"));
    p.finds.put(helmet.id(), 1);
    assertTrue(Archaeology.sell(p, helmet).contains("gehört ins Museum"), "the only copy is kept for the museum");
    for (int i = 0; i < 4; i++) p.finds.put(Archaeology.find(0, i).id(), 2);
    long money = p.money;
    for (int i = 0; i < 3; i++) Archaeology.donate(p, Archaeology.find(0, i));
    assertEquals(0, Archaeology.bonus(p));
    String last = Archaeology.donate(p, helmet);
    assertTrue(last.contains("VOLLSTÄNDIG"), last);
    assertEquals(.01, Archaeology.bonus(p), 1e-9);
    assertEquals(money + 3 * Archaeology.donationReward(Archaeology.find(0, 0)) + Archaeology.donationReward(helmet), p.money);
    assertTrue(Archaeology.donate(p, helmet).contains("schon im Museum"));
    long before = p.money;
    assertTrue(Archaeology.sell(p, helmet).startsWith("1× "));
    assertEquals(before + Archaeology.saleValue(helmet), p.money);
    assertEquals(0, Archaeology.owned(p, helmet));
  }

  @Test
  void fullMuseumBonusReachesStatsAndPrices() {
    Profile p = new Profile();
    for (Archaeology.Find f : Archaeology.ALL) p.museum.add(f.id());
    assertEquals(Zone.COUNT, Archaeology.completeZones(p));
    assertEquals(.22, Archaeology.bonus(p), 1e-9);
    Profile plain = new Profile();
    assertEquals(Gear.stats(plain).damage() * 1.22, Gear.stats(p).damage(), 1e-6);
    plain.bag[0] = p.bag[0] = 1000;
    assertEquals(Math.round(Economy.sell(plain) * 1.22), Economy.sell(p));
  }

  @Test
  void wikiListsEveryMine() {
    assertTrue(Wiki.page("home").children().contains("museum"));
    assertEquals(3 + Zone.COUNT, Wiki.page("museum").entries().size());
  }
}
