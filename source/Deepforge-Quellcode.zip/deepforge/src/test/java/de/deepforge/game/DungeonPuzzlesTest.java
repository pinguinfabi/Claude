package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import de.deepforge.game.DungeonPuzzles.*;
import java.util.*;
import org.junit.jupiter.api.Test;

class DungeonPuzzlesTest {
  @Test
  void leversStartUnsolvedAndCanBeSolved() {
    for (int seed = 0; seed < 500; seed++) {
      Levers l = new Levers(new Random(seed));
      assertFalse(l.solved());
      // Brute force over all 32 pull sets: one of them lights every lamp.
      boolean solvable = false;
      for (int mask = 0; mask < 32 && !solvable; mask++) {
        Levers copy = new Levers(new Random(seed));
        for (int i = 0; i < 5; i++) if ((mask >> i & 1) == 1) copy.pull(i);
        solvable = copy.solved();
      }
      assertTrue(solvable, "seed " + seed);
    }
  }

  @Test
  void lightBeamHasASolutionAndStartsWrong() {
    for (int seed = 0; seed < 500; seed++) {
      Light l = new Light(new Random(seed));
      assertFalse(l.solved(), "seed " + seed);
      assertTrue(l.mirrors.size() >= 2);
      for (var e : l.solution().entrySet()) if (l.mirrors.get(e.getKey()) != e.getValue()) l.rotate(e.getKey());
      assertTrue(l.solved(), "seed " + seed);
      int[] exit = l.beam().getLast();
      assertTrue(exit[0] < 0 || exit[0] >= Light.N || exit[1] < 0 || exit[1] >= Light.N);
    }
  }

  @Test
  void platesBellsMimicsAndTraps() {
    Plates p = new Plates(new Random(3), 1);
    assertEquals(5, p.order.length);
    for (int i = 1; i < p.order.length; i++) assertNotEquals(p.order[i - 1], p.order[i]);
    assertFalse(p.stepOn((p.current() + 1) % 9));
    for (int i = 0; i < p.order.length - 1; i++) assertFalse(p.stepOn(p.current()));
    assertTrue(p.stepOn(p.current()));
    assertTrue(new Plates(new Random(3), 40).window < p.window);

    Bells b = new Bells(new Random(4), 1);
    assertEquals(0, b.ring((b.melody[0] + 1) % 4));
    for (int i = 0; i < b.melody.length - 1; i++) assertEquals(1, b.ring(b.melody[b.step]));
    assertEquals(2, b.ring(b.melody[b.step]));

    Mimics m = new Mimics(new Random(5));
    assertTrue(m.key >= 0 && m.key < Mimics.COUNT);

    for (long t = 0; t < 200; t++)
      assertFalse(
          Traps.state(0, t) == 2 && Traps.state(1, t) == 2, "neighbouring stripes never both burn");
    assertTrue(Traps.stripes(32) >= 5);
  }
}
