package de.deepforge.world;

import static org.junit.jupiter.api.Assertions.*;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.junit.jupiter.api.Test;

class MonsterRigTest {
  private static Vector3f point(Matrix4f m, float x, float y, float z) {
    return m.transformPosition(new Vector3f(x, y, z));
  }

  private static MonsterRig.Pose pose(float lean, float roll, float head, float arm) {
    return new MonsterRig.Pose(lean, roll, head, 0, arm, arm, .4f, -.4f, .03f, 1);
  }

  @Test
  void headAndArmsStayOnTheBodyInEveryPose() {
    Vector3f size = new Vector3f(.6f, .55f, .52f);
    for (float lean : new float[] {-.36f, 0, .32f, .6f})
      for (float roll : new float[] {0, .08f})
        for (float arm : new float[] {0, 1.2f, 2.75f}) {
          Matrix4f[] b = MonsterRig.skeleton(pose(lean, roll, 0, arm), size, .52f, 1.2f);
          Matrix4f[] rest = MonsterRig.skeleton(pose(0, 0, 0, 0), size, .52f, 1.2f);
          // Neck: bottom centre of the head vs. top centre of the body keep their distance.
          float gap = point(rest[1], 0, -.5f, 0).distance(point(rest[0], 0, .5f, 0));
          assertEquals(gap, point(b[1], 0, -.5f, 0).distance(point(b[0], 0, .5f, 0)), 1e-4, "neck " + lean + " " + arm);
          // Shoulder joint (model y 13 of the arm) moves exactly with the body.
          for (int i = 2; i <= 3; i++) {
            Vector3f shoulderOnArm = point(b[i], 0, 5 / 16f, 0);
            Vector3f restShoulder = point(rest[i], 0, 5 / 16f, 0);
            Matrix4f lean0 = new Matrix4f(b[0]).mul(new Matrix4f(rest[0]).invert());
            assertTrue(shoulderOnArm.distance(lean0.transformPosition(restShoulder)) < 1e-4, "shoulder " + lean + " " + arm);
          }
        }
  }

  @Test
  void legsSwingFromTheHipAndStayOnTheGround() {
    Vector3f size = new Vector3f(.5f, .5f, .5f);
    Matrix4f[] b = MonsterRig.skeleton(new MonsterRig.Pose(.3f, 0, 0, 0, 0, 0, .6f, -.6f, .05f, 1), size, .5f, 1);
    Matrix4f[] rest = MonsterRig.skeleton(new MonsterRig.Pose(0, 0, 0, 0, 0, 0, 0, 0, 0, 1), size, .5f, 1);
    for (int i = 4; i <= 5; i++)
      assertTrue(point(b[i], 0, 6 / 16f, 0).distance(point(rest[i], 0, 6 / 16f, 0)) < 1e-4, "hip joint fixed");
  }

  @Test
  void aStrikeRearsUpThenSlamsForward() {
    MonsterRig.Pose windup = MonsterRig.pose(10, true, false, false, false, 99);
    MonsterRig.Pose slam = MonsterRig.pose(11, false, false, false, false, 2);
    MonsterRig.Pose done = MonsterRig.pose(20, false, false, false, false, 30);
    assertTrue(windup.armL() > 2.5f && windup.bodyLean() < 0, "arms high, leaning back");
    assertTrue(slam.armL() < windup.armL() && slam.bodyLean() > .1f, "arms come down, body throws forward");
    assertTrue(Math.abs(done.armL()) < .1f && Math.abs(done.bodyLean()) < .05f, "back to rest");
  }
}
