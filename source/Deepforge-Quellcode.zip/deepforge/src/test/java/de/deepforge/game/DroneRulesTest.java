package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DroneRulesTest {
  @Test
  void buildUpgradeModulesAndSkins() {
    Profile p = new Profile();
    p.money = 100;
    assertTrue(DroneRules.build(p).startsWith("Dir fehlen"));
    p.money = DroneRules.BUILD_MONEY + 50_000;
    DroneRules.build(p);
    assertEquals(1, p.droneLevel);
    assertEquals(50_000, p.money);
    assertTrue(DroneRules.upgrade(p).contains("Schmiedestaub"), "dust is missing");
    p.dust = 1000;
    p.relics = 50;
    DroneRules.upgrade(p);
    DroneRules.upgrade(p);
    assertEquals(3, p.droneLevel);
    assertTrue(DroneRules.skin(p, 2).contains("ab Funke-Stufe 6"));
    assertTrue(DroneRules.skin(p, 1).contains("Kupfer"));
    assertEquals(1, p.droneSkin);
    DroneRules.module(p, 2);
    assertEquals(2, p.droneModule);
    assertEquals("Unbekanntes Modul.", DroneRules.module(p, 7));
    DroneRules.toggle(p);
    assertTrue(p.droneHidden);
  }

  @Test
  void strongerWithEveryLevel() {
    assertTrue(DroneRules.collectorSeconds(10) < DroneRules.collectorSeconds(1));
    assertTrue(DroneRules.collectorOre(9) > DroneRules.collectorOre(1));
    assertTrue(DroneRules.turretShare(10) > DroneRules.turretShare(1));
    assertTrue(DroneRules.turretTicks(10) >= 16);
    assertTrue(DroneRules.medicHeal(10) > DroneRules.medicHeal(1));
    assertEquals(0, DroneRules.upgradeRelics(4));
    assertTrue(DroneRules.upgradeRelics(9) > 0);
    for (int l = 1; l <= 10; l++) assertFalse(DroneRules.effect(l % 3, l).isBlank());
  }
}
