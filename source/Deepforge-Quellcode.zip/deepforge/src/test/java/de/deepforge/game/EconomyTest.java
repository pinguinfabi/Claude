package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class EconomyTest {
  @Test
  void saleCannotBeRepeated() {
    Profile p = new Profile();
    p.money = 0;
    p.bag[0] = 10;
    p.stock[1] = 2;
    p.bars[0] = 3;
    assertEquals(272, Economy.sell(p));
    assertEquals(0, Economy.sell(p));
    assertEquals(272, p.money);
  }

  @Test
  void upgradeCannotOverdraw() {
    Profile p = new Profile();
    p.money = 199;
    Economy.buy(p, "tool");
    assertEquals(0, p.tool);
    assertEquals(199, p.money);
  }

  @Test
  void advancedToolNeedsRelic() {
    Profile p = new Profile();
    p.money = 100000;
    p.tool = 4;
    Economy.buy(p, "tool");
    assertEquals(4, p.tool);
    assertEquals(100000, p.money);
    p.relics = 1;
    Economy.buy(p, "tool");
    assertEquals(5, p.tool);
    assertEquals(0, p.relics);
  }

  @Test
  void workersRequireDefeatedBoss() {
    Profile p = new Profile();
    p.money = 10000;
    Economy.hire(p, Profile.Job.MINER);
    assertTrue(p.workers.isEmpty());
    p.bosses[0] = true;
    Economy.hire(p, Profile.Job.MINER);
    assertEquals(1, p.workers.size());
    assertEquals(8500, p.money);
    Economy.hire(p, Profile.Job.MINER);
    assertEquals(1, p.workers.size());
  }

  @Test
  void depositIsCapacityBounded() {
    Profile p = new Profile();
    p.stock[0] = 950;
    p.bag[0] = 40;
    assertEquals(10, Economy.deposit(p));
    assertEquals(30, p.bag[0]);
    assertEquals(960, p.stockUsed());
  }

  @Test
  void zoneRequiresBossMoneyAndTool() {
    Profile p = new Profile();
    p.money = 10000;
    Economy.nextZone(p);
    assertEquals(0, p.zone);
    p.bosses[0] = true;
    Economy.nextZone(p);
    assertEquals(0, p.zone);
    p.tool = 2;
    Economy.nextZone(p);
    assertEquals(1, p.zone);
    assertEquals(7000, p.money);
  }

  @Test
  void ordersConsumeStockBeforeReward() {
    Profile p = new Profile();
    p.money = 0;
    p.bag[0] = 30;
    p.stock[0] = 50;
    Economy.order(p);
    assertEquals(1440, p.money);
    assertEquals(0, p.bagUsed() + p.stockUsed());
    assertEquals(1, p.orders);
    Economy.order(p);
    assertEquals(1440, p.money);
  }

  @Test
  void questRewardOnlyOncePerCompletedObjective() {
    Profile p = new Profile();
    p.money = 0;
    p.mined = 32;
    Economy.quest(p);
    assertEquals(500, p.money);
    assertEquals(1, p.quest);
    Economy.quest(p);
    assertEquals(500, p.money);
  }
}
