package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class PrestigeTest {
  private static Profile finished() {
    Profile p = new Profile();
    p.zone = Zone.LAST;
    Arrays.fill(p.bosses, true);
    p.money = 9_000_000_000L;
    p.tool = 30;
    p.sword = 25;
    p.armor = 20;
    p.bagLevel = 10;
    p.warehouse = 8;
    p.housing = 5;
    p.furnace = 4;
    p.bag[3] = 100;
    p.stock[16] = 500;
    p.bars[5] = 40;
    p.dust = 777;
    p.workers.add(new Profile.Worker("Borin", Profile.Job.MINER, 16));
    p.workers.add(new Profile.Worker("Holz", Profile.Job.LUMBERJACK, 2));
    return p;
  }

  @Test
  void onlyAfterTheLastBoss() {
    Profile p = new Profile();
    assertFalse(Prestige.ready(p));
    assertTrue(Prestige.perform(p).startsWith("Noch nicht bereit"));
    assertEquals(0, p.prestige);
    p.zone = Zone.LAST;
    assertFalse(Prestige.ready(p));
    p.bosses[Zone.LAST] = true;
    assertTrue(Prestige.ready(p));
  }

  @Test
  void resetsTheRunButKeepsGear() {
    Profile p = finished();
    Gear.Item sword = Gear.roll(16, Gear.Rarity.MYTHIC, new Random(1));
    p.gear.add(sword);
    double damage = sword.damage;
    String msg = Prestige.perform(p);
    assertTrue(msg.startsWith("PRESTIGE 1"), msg);
    assertEquals(1, p.prestige);
    assertEquals(1, p.glut);
    assertEquals(0, p.zone);
    assertEquals(250, p.money);
    assertEquals(0, p.tool + p.sword + p.armor + p.bagLevel + p.warehouse);
    assertEquals(5, p.housing, "housing stays so workers keep their beds");
    assertEquals(0, Arrays.stream(p.bag).sum() + Arrays.stream(p.stock).sum() + Arrays.stream(p.bars).sum());
    for (boolean b : p.bosses) assertFalse(b);
    assertEquals(777, p.dust);
    assertTrue(p.gear.contains(sword));
    assertEquals(damage, sword.damage, 1e-9, "old gear is stamped at prestige 0 and unchanged");
    assertEquals(0, sword.prestige);
    assertEquals(0, p.workers.getFirst().zone);
    assertEquals(2, p.workers.getLast().zone, "lumberjacks keep their wood");
    assertFalse(Prestige.ready(p));
  }

  @Test
  void newLootIsStampedStronger() {
    Profile p = finished();
    Prestige.perform(p);
    Gear.Item found = Gear.roll(0, Gear.Rarity.RARE, new Random(3));
    double base = found.damage;
    p.gear.add(found);
    Prestige.stamp(p);
    assertEquals(base * Prestige.LOOT, found.damage, 1e-9);
    Prestige.stamp(p);
    assertEquals(base * Prestige.LOOT, found.damage, 1e-9, "stamping twice changes nothing");
  }

  @Test
  void enemiesOutgrowLootSoThereIsASoftWall() {
    assertEquals(1, Prestige.health(0));
    for (int n = 1; n <= 30; n++) {
      assertTrue(Prestige.health(n) > Prestige.health(n - 1));
      assertTrue(Prestige.health(n) / Prestige.loot(n) > Prestige.health(n - 1) / Prestige.loot(n - 1));
    }
    assertTrue(Prestige.health(10) / Prestige.loot(10) > 4);
  }

  @Test
  void glutTalents() {
    Profile p = finished();
    assertTrue(Prestige.learn(p, Prestige.Node.ADER).startsWith("Keine Tiefenglut"));
    p.glut = 7;
    for (int i = 0; i < 6; i++) Prestige.learn(p, Prestige.Node.ADER);
    assertEquals(Prestige.MAX_RANK, Prestige.rank(p, Prestige.Node.ADER));
    assertEquals(2, p.glut);
    assertEquals(1.5, Prestige.income(p), 1e-9);
    p.prestige = 2;
    assertEquals(1.5 * 1.5, Prestige.income(p), 1e-9);
    Prestige.learn(p, Prestige.Node.KAPITAL);
    Prestige.learn(p, Prestige.Node.KAPITAL);
    assertEquals(20_000, Prestige.startMoney(p));
    assertEquals(2, Prestige.glutFor(5));
    assertEquals(1, Prestige.glutFor(4));
    Profile q = new Profile();
    q.tool = 10;
    long before = q.power();
    q.prestigeNodes.put("BOHRER", 3);
    assertEquals(Math.round(before * 1.3), q.power());
  }

  @Test
  void sellingPaysMoreAfterPrestige() {
    Profile a = new Profile(), b = new Profile();
    a.bag[2] = b.bag[2] = 100;
    b.prestige = 2;
    long normal = Economy.sell(a), boosted = Economy.sell(b);
    assertEquals(Math.round(normal * 1.5), boosted);
  }

  @Test
  void badgesAndWiki() {
    assertEquals("", Prestige.badge(0));
    assertEquals("★3", Prestige.badge(3));
    assertEquals("✪12", Prestige.badge(12));
    assertTrue(Wiki.page("home").children().contains("prestige"));
    assertEquals(4 + Prestige.Node.values().length, Wiki.page("prestige").entries().size());
    assertTrue(Leaderboard.BOARDS.stream().anyMatch(x -> x.id().equals("prestige")));
  }
}
