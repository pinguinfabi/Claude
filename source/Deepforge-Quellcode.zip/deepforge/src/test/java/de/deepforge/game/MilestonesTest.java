package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MilestonesTest {
  @Test
  void tiersPayOnceInOrderAndOnlyWhenReached() {
    Profile p = new Profile();
    p.money = 0;
    p.mined = 99;
    assertTrue(Milestones.claim(p, "ore").startsWith("Es fehlen 1"));
    assertEquals(0, p.money);
    p.mined = 1000;
    Milestones.claim(p, "ore");
    assertEquals(Milestones.MONEY[0], p.money);
    assertEquals(Milestones.DUST[0], p.dust);
    assertEquals(1, Milestones.claimed(p, "ore"));
    Milestones.claim(p, "ore");
    assertEquals(2, Milestones.claimed(p, "ore"));
    assertEquals(Milestones.MONEY[0] + Milestones.MONEY[1], p.money);
    assertEquals(Milestones.RELICS[1], p.relics);
    assertTrue(Milestones.claim(p, "ore").startsWith("Es fehlen 9000"));
    p.mined = 10000;
    Milestones.claim(p, "ore");
    assertTrue(Milestones.claim(p, "ore").contains("bereits vollständig"));
    assertEquals(3, p.milestones.size());
  }

  @Test
  void progressReadsExistingCounters() {
    Profile p = new Profile();
    p.bosses[0] = p.bosses[2] = true;
    p.dungeonWins[4] = 3;
    p.research[1] = 2;
    p.research[3] = 1;
    Profile.Worker w = new Profile.Worker("Borin", Profile.Job.MINER, 0);
    w.workMinutes = 700;
    p.workers.add(w);
    assertEquals(2, Milestones.progress(p, "bosses"));
    assertEquals(3, Milestones.progress(p, "dungeons"));
    assertEquals(3, Milestones.progress(p, "research"));
    assertEquals(700, Milestones.progress(p, "crew"));
    assertEquals(4, Milestones.claimableCount(p));
    assertEquals("Unbekannter Meilenstein.", Milestones.claim(p, "nope"));
  }
}
