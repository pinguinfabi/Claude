package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class HuntTest {
  @Test
  void huntsCannotBeStockpiled() {
    Profile p = new Profile();
    for (int i = 0; i < 300; i++) Gear.huntKill(p, 0);
    assertEquals(Gear.HUNT_TARGET, p.huntKills[0], "progress stops at the target");
    long before = p.money;
    assertTrue(Gear.claimHunt(p, 0).startsWith("Jagdauftrag erfüllt"));
    assertEquals(0, p.huntKills[0], "a new hunt starts at zero");
    assertTrue(Gear.claimHunt(p, 0).startsWith("Besiege 15"), "no second claim from banked kills");
    assertEquals(before + 450, p.money);
  }

  @Test
  void oldBankedKillsAreTrimmedOnLoad() {
    Profile p = new Profile();
    p.huntKills[3] = 500;
    Gear.migrate(p);
    assertEquals(Gear.HUNT_TARGET, p.huntKills[3]);
  }
}
