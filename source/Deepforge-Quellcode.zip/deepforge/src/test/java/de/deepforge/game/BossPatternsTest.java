package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import de.deepforge.game.BossPatterns.Attack;
import java.util.*;
import org.junit.jupiter.api.Test;

class BossPatternsTest {
  @Test
  void phasesUnlockMoreSignatureAttacks() {
    assertEquals(0, BossPatterns.phase(100, 100));
    assertEquals(1, BossPatterns.phase(60, 100));
    assertEquals(2, BossPatterns.phase(30, 100));
    for (int zone = 0; zone < 7; zone++) {
      assertEquals(3, BossPatterns.kit(zone, 0).size());
      assertEquals(5, BossPatterns.kit(zone, 2).size());
      assertTrue(BossPatterns.kit(zone, 2).containsAll(BossPatterns.kit(zone, 1)));
    }
    // Every zone ends up with a different signature set.
    Set<Set<Attack>> sets = new HashSet<>();
    for (int zone = 0; zone < 7; zone++) sets.add(new HashSet<>(BossPatterns.kit(zone, 2)));
    assertTrue(sets.size() >= 6);
  }

  @Test
  void rotationUsesEveryAttackOncePerCycle() {
    List<Attack> kit = BossPatterns.kit(4, 2);
    Set<Attack> cycle = new HashSet<>();
    for (int n = 0; n < kit.size(); n++) cycle.add(BossPatterns.next(4, 2, n, 42));
    assertEquals(new HashSet<>(kit), cycle);
  }

  @Test
  void warningsGetShorterButStayDodgeable() {
    for (Attack a : Attack.values()) {
      assertTrue(BossPatterns.warning(a, 2, 99, true) >= 20, a.name());
      assertTrue(BossPatterns.warning(a, 0, 1, false) >= BossPatterns.warning(a, 2, 1, false));
    }
    assertTrue(BossPatterns.warning(Attack.SAFE, 0, 1, false) > BossPatterns.warning(Attack.SLAM, 0, 1, false));
  }

  @Test
  void shockwaveHasAGapAndCanBeJumped() {
    int t = 20;
    double r = BossPatterns.waveRadius(t);
    assertTrue(BossPatterns.shockwave(r, 0, t, Math.PI / 2, false), "on the ring");
    assertFalse(BossPatterns.shockwave(r, 0, t, 0, false), "inside the gap");
    assertFalse(BossPatterns.shockwave(r, 0, t, Math.PI / 2, true), "jumped over");
    assertFalse(BossPatterns.shockwave(r + 2, 0, t, Math.PI / 2, false), "ring not there yet");
  }

  @Test
  void spinBeamSweepsOnceAround() {
    assertEquals(0, BossPatterns.spinAngle(0, 0, 1), 1e-9);
    assertEquals(2 * Math.PI, BossPatterns.spinAngle(0, BossPatterns.active(Attack.SPIN), 1), 1e-9);
    assertTrue(BossPatterns.spin(5, 0, 0));
    assertFalse(BossPatterns.spin(0, 5, 0));
    assertTrue(BossPatterns.spin(0, 5, Math.PI / 2));
    assertFalse(BossPatterns.spin(-5, 0, 0), "not behind the boss");
  }

  @Test
  void beamAndSafeZoneGeometry() {
    assertTrue(BossPatterns.beam(10, .5, 1, 0, 18, 1.2));
    assertFalse(BossPatterns.beam(10, 2, 1, 0, 18, 1.2));
    double[] safe = BossPatterns.safeSpot(3, 0, 0);
    assertTrue(safe[0] < 0, "safe spot is away from the boss");
    assertFalse(BossPatterns.safeZoneHit(safe[0], safe[1], safe[0], safe[1], 1));
    assertTrue(BossPatterns.safeZoneHit(safe[0] + 4, safe[1], safe[0], safe[1], 1));
    assertFalse(
        BossPatterns.safeZoneHit(safe[0] + 3.5, safe[1], safe[0], safe[1], 4), "bigger with 4 players");
  }

  @Test
  void shardsTargetPlayersAndStayInsideTheArena() {
    List<double[]> shards = BossPatterns.shards(List.of(new double[] {20, 0}, new double[] {1, 1}), 8, 7);
    assertEquals(8, shards.size());
    for (double[] s : shards) assertTrue(Math.hypot(s[0], s[1]) <= BossPatterns.ARENA);
    assertTrue(BossPatterns.shard(0, 1.5));
    assertFalse(BossPatterns.shard(0, 2));
  }

  @Test
  void vortexPullIsEscapableByWalking() {
    assertTrue(BossPatterns.VORTEX_PULL < .2, "walking speed must beat the pull");
    assertTrue(BossPatterns.vortexBlast(3, 3));
    assertFalse(BossPatterns.vortexBlast(5, 5));
  }
}
