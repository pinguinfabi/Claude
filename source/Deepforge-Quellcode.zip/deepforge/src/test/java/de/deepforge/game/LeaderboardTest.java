package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import org.junit.jupiter.api.Test;

class LeaderboardTest {
  private static Profile named(String id, String name, long mined) {
    Profile p = new Profile();
    p.id = id;
    p.name = name;
    p.mined = mined;
    return p;
  }

  @Test
  void ranksByScoreAndSkipsEmptyEntries() {
    List<Profile> all =
        List.of(named("a", "Anna", 50), named("b", "Ben", 900), named("c", "Cem", 0), named("d", "Dora", 300));
    Leaderboard.Board ore = Leaderboard.BOARDS.stream().filter(b -> b.id().equals("ore")).findFirst().orElseThrow();
    List<Leaderboard.Entry> top = Leaderboard.top(all, ore, 2);
    assertEquals(List.of("Ben", "Dora"), top.stream().map(Leaderboard.Entry::name).toList());
    assertEquals(3, Leaderboard.rank(all, ore, "a"));
    assertEquals(0, Leaderboard.rank(all, ore, "c"), "no score, no rank");
  }
}
