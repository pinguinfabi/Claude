package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class DungeonBalanceTest {
  private static Profile fresh() {
    Profile p = new Profile();
    p.id = UUID.randomUUID().toString();
    Gear.migrate(p);
    return p;
  }

  @Test
  void onlyWinsAtYourOwnLevelRaiseIt() {
    Profile p = fresh();
    p.zoneLevels[2] = 10;
    DungeonRules.reward(p, UUID.randomUUID(), 2, 0, 100, 4, 0, EnumSet.noneOf(Gear.Slot.class), DungeonVariant.GEWOELBE);
    assertEquals(10, DungeonRules.level(p, 2), "farming level 4 keeps level 10");
    DungeonRules.reward(p, UUID.randomUUID(), 2, 0, 100, 10, 0, EnumSet.noneOf(Gear.Slot.class), DungeonVariant.GEWOELBE);
    assertEquals(11, DungeonRules.level(p, 2));
  }

  @Test
  void firstWinOfTheDayPaysTwice() {
    Profile p = fresh();
    long before = p.money;
    assertNotNull(DungeonRules.dailyBonus(p, 20_000, 6, 1, 5));
    assertEquals(before + DungeonRules.coins(6, 1, 5), p.money);
    assertNull(DungeonRules.dailyBonus(p, 20_000, 6, 1, 5), "once per day");
    assertNotNull(DungeonRules.dailyBonus(p, 20_001, 6, 1, 5));
  }

  @Test
  void dungeonCoinsFollowTheZonesOrePrice() {
    assertEquals(1080, DungeonRules.coins(0, 0));
    assertEquals(54_000, DungeonRules.coins(6, 0));
    for (int z = 1; z < Zone.COUNT; z++) assertTrue(DungeonRules.coins(z, 0) > DungeonRules.coins(z - 1, 0));
  }
}
