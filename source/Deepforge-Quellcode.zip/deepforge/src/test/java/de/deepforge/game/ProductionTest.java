package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ProductionTest {
  static final long START = 1_000_000_000L;

  Profile mine() {
    Profile p = new Profile();
    p.lastSettled = START;
    p.money = 0;
    p.budget = 1_000_000;
    p.fuel = 100_000;
    p.workers.add(new Profile.Worker("Borin", Profile.Job.MINER, 0));
    return p;
  }

  /** Rate 2 ore per minute for a level-1 worker, as before 0.8.1 (research 6 × 0.25 + 0.5). */
  static Profile fast(Profile p) {
    p.research[2] = 6;
    return p;
  }

  @Test
  void sixHoursOfMiningProduces180OreAndChargesOnlyWorkedMinutes() {
    Profile p = mine();
    var r = Production.settle(p, START + 6 * 3600000L);
    // Fresh worker: half an ore per minute, every second minute is a working minute.
    assertEquals(180, p.stock[0]);
    // Wage per ore: 3 $ base + 20 % of the 12 $ ore value (rounded 2).
    assertEquals(180 * 5, r.costs());
    assertEquals(100_000 - 180, p.fuel);
    assertEquals(0, p.money);
  }

  @Test
  void wagesGrowWithTheValueOfTheGoods() {
    Profile iron = fast(mine()), voidMine = fast(mine());
    voidMine.zone = 6;
    voidMine.workers.getFirst().zone = 6;
    var a = Production.settle(iron, START + 60 * 60000L);
    var b = Production.settle(voidMine, START + 60 * 60000L);
    assertEquals(120, iron.stock[0]);
    assertEquals(120, voidMine.stock[6]);
    // A fifth of the ore value goes to wages: deep ore is worth more, so it also costs more.
    assertTrue(b.costs() > 10 * a.costs());
    assertTrue(b.costs() >= Math.round(120 * Zone.at(6).orePrice * .2));
  }

  @Test
  void repeatingSettlementCannotAwardAgain() {
    Profile p = mine();
    long now = START + 3600000;
    Production.settle(p, now);
    long stock = p.stock[0], budget = p.budget;
    var r = Production.settle(p, now);
    assertEquals(stock, p.stock[0]);
    assertEquals(budget, p.budget);
    assertEquals(0, r.minutes());
  }

  @Test
  void offlineCapDiscardsExcessTime() {
    Profile p = mine();
    p.workers.add(new Profile.Worker("Mira", Profile.Job.TRADER, 0));
    Production.settle(p, START + 48 * 3600000L);
    // Offline cap: 6 hours without upgrades (was 8); half an ore per minute.
    assertEquals(180, p.workers.getFirst().workMinutes);
    long cash = p.money;
    Production.settle(p, START + 48 * 3600000L);
    assertEquals(cash, p.money);
  }

  @Test
  void fullStorageStopsCostsAndFuel() {
    Profile p = mine();
    p.stock[0] = p.stockCapacity();
    long fuel = p.fuel, budget = p.budget;
    Production.settle(p, START + 3600000);
    assertEquals(fuel, p.fuel);
    assertEquals(budget, p.budget);
  }

  @Test
  void remainingOneSlotIsFilledWithoutOverflow() {
    Profile p = mine();
    p.stock[0] = 959;
    Production.settle(p, START + 120000);
    assertEquals(960, p.stockUsed());
    assertEquals(1, p.workers.getFirst().workMinutes);
  }

  @Test
  void noBudgetMeansNoProduction() {
    Profile p = mine();
    p.budget = 2;
    Production.settle(p, START + 3600000);
    assertEquals(0, p.stock[0]);
    assertEquals(100000, p.fuel);
    assertEquals(2, p.budget);
  }

  @Test
  void finiteFuelStopsAtExactBoundary() {
    Profile p = mine();
    p.fuel = 5;
    Production.settle(p, START + 3600000);
    assertEquals(5, p.stock[0]);
    assertEquals(0, p.fuel);
    assertEquals(1_000_000 - 5 * 5, p.budget);
  }

  @Test
  void traderNeedsNoFuel() {
    Profile p = mine();
    p.workers.clear();
    p.workers.add(new Profile.Worker("Yara", Profile.Job.TRADER, 0));
    p.stock[0] = 10;
    p.fuel = 0;
    fast(p);
    Production.settle(p, START + 60000);
    assertEquals(24, p.money);
    assertEquals(8, p.stock[0]);
  }

  @Test
  void chainRunsInJobOrderNotHiringOrder() {
    Profile p = fast(mine());
    p.furnace = 1;
    p.workers.addFirst(new Profile.Worker("Yara", Profile.Job.TRADER, 0));
    p.workers.addFirst(new Profile.Worker("Mira", Profile.Job.SMELTER, 0));
    // Bars reserved for research and the bar contract stay; the fresh bar is surplus.
    long reserve = Industry.barReserve(p, 0);
    p.bars[0] = reserve;
    Production.settle(p, START + 60000);
    assertEquals(reserve, p.stockUsed());
    assertEquals(reserve, p.bars[0]);
    assertEquals(32, p.money);
    // Miner 3 + 5 (2 ore), smelter 3 + 2 (1 bar), trader 3 + 3 (10 % of 32 $).
    assertEquals(1_000_000 - 19, p.budget);
    assertEquals(99998, p.fuel);
  }

  @Test
  void backwardsClockNeverProducesOrMovesTimestampBack() {
    Profile p = mine();
    Production.settle(p, START - 60000);
    assertEquals(START, p.lastSettled);
    assertEquals(0, p.stock[0]);
  }

  @Test
  void partialMinuteCarriesAcrossSessions() {
    Profile p = fast(mine());
    Production.settle(p, START + 59000);
    assertEquals(START, p.lastSettled);
    Production.settle(p, START + 61000);
    assertEquals(2, p.stock[0]);
    assertEquals(START + 60000, p.lastSettled);
  }

  @Test
  void batchingHasSameResultAsMinuteSteps() {
    Profile a = mine(), b = mine();
    a.furnace = b.furnace = 1;
    a.workers.add(new Profile.Worker("Mira", Profile.Job.SMELTER, 0));
    b.workers.add(new Profile.Worker("Mira", Profile.Job.SMELTER, 0));
    Production.settle(a, START + 120 * 60000L);
    for (int i = 1; i <= 120; i++) Production.settle(b, START + i * 60000L);
    assertArrayEquals(a.stock, b.stock);
    assertArrayEquals(a.bars, b.bars);
    assertEquals(a.fuel, b.fuel);
    assertEquals(a.budget, b.budget);
  }

  @Test
  void switchingAssignmentDoesNotRetroactivelyChangePreviousProduction() {
    Profile p = fast(mine());
    p.zone = 1;
    Production.settle(p, START + 60000);
    p.workers.getFirst().zone = 1;
    Production.settle(p, START + 120000);
    assertEquals(2, p.stock[0]);
    assertEquals(2, p.stock[1]);
  }

  @Test
  void traderKeepsBarsNeededForResearchAndBarContract() {
    Profile p = mine();
    p.workers.clear();
    p.workers.add(new Profile.Worker("Yara", Profile.Job.TRADER, 0));
    // Next iron research needs 4 bars; the first bar contract (zone 0) needs 16.
    assertEquals(4 + Industry.contract(p, 1).amount(), Industry.barReserve(p, 0));
    p.bars[0] = Industry.barReserve(p, 0);
    Production.settle(p, START + 60000);
    assertEquals(Industry.barReserve(p, 0), p.bars[0]);
    assertEquals("Wartet auf Ware", Industry.stopped(p, p.workers.getFirst()));
    p.bars[0] += 1;
    assertEquals(1, Industry.sellableBars(p, 0));
    assertEquals(0, Industry.barReserve(p, 3));
  }

  @Test
  void workersBringDeterministicFinds() {
    Profile p = fast(mine());
    var r = Production.settle(p, START + 240 * 60000L);
    // Minutes 45..225 give dust (5), minute 240 a relic instead of dust.
    assertEquals(5, r.dust());
    assertEquals(1, r.relics());
    assertEquals(5, p.dust);
    assertEquals(1, p.relics);
    assertEquals(0, r.notes());
    assertTrue(Industry.nextFind(p.workers.getFirst()).contains("Staub in 30 Min."));
  }

  @Test
  void smelterFindsNotesAndTraderEarnsBonus() {
    Profile p = fast(mine());
    p.workers.clear();
    p.furnace = 1;
    p.zone = 1;
    p.stock[0] = 10_000;
    p.bars[0] = Industry.barReserve(p, 0);
    p.workers.add(new Profile.Worker("Mira", Profile.Job.SMELTER, 0));
    p.workers.add(new Profile.Worker("Yara", Profile.Job.TRADER, 0));
    var r = Production.settle(p, START + 60 * 60000L);
    assertEquals(1, r.notes());
    assertEquals(1, p.researchNotes);
    assertTrue(p.money >= 10 * Zone.at(0).barPrice);
    assertTrue(Industry.hourlyValue(p, p.workers.getFirst()) > 0);
  }
}
