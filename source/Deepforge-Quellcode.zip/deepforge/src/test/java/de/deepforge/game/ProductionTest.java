package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ProductionTest {
  static final long START = 1_000_000_000L;

  Profile mine() {
    Profile p = new Profile();
    p.lastSettled = START;
    p.money = 0;
    p.budget = 1_000_000;
    p.fuel = 100_000;
    p.workers.add(new Profile.Worker("Borin", Profile.Job.MINER, 0));
    return p;
  }

  @Test
  void sixHoursOfMiningProduces720OreAndChargesOnlyWorkedMinutes() {
    Profile p = mine();
    var r = Production.settle(p, START + 6 * 3600000L);
    assertEquals(720, p.stock[0]);
    assertEquals(1080, r.costs());
    assertEquals(99640, p.fuel);
    assertEquals(0, p.money);
  }

  @Test
  void repeatingSettlementCannotAwardAgain() {
    Profile p = mine();
    long now = START + 3600000;
    Production.settle(p, now);
    long stock = p.stock[0], budget = p.budget;
    var r = Production.settle(p, now);
    assertEquals(stock, p.stock[0]);
    assertEquals(budget, p.budget);
    assertEquals(0, r.minutes());
  }

  @Test
  void offlineCapDiscardsExcessTime() {
    Profile p = mine();
    p.workers.add(new Profile.Worker("Mira", Profile.Job.TRADER, 0));
    Production.settle(p, START + 48 * 3600000L);
    assertEquals(480, p.workers.getFirst().workMinutes);
    long cash = p.money;
    Production.settle(p, START + 48 * 3600000L);
    assertEquals(cash, p.money);
  }

  @Test
  void fullStorageStopsCostsAndFuel() {
    Profile p = mine();
    p.stock[0] = p.stockCapacity();
    long fuel = p.fuel, budget = p.budget;
    Production.settle(p, START + 3600000);
    assertEquals(fuel, p.fuel);
    assertEquals(budget, p.budget);
  }

  @Test
  void remainingOneSlotIsFilledWithoutOverflow() {
    Profile p = mine();
    p.stock[0] = 959;
    Production.settle(p, START + 120000);
    assertEquals(960, p.stockUsed());
    assertEquals(1, p.workers.getFirst().workMinutes);
  }

  @Test
  void noBudgetMeansNoProduction() {
    Profile p = mine();
    p.budget = 2;
    Production.settle(p, START + 3600000);
    assertEquals(0, p.stock[0]);
    assertEquals(100000, p.fuel);
    assertEquals(2, p.budget);
  }

  @Test
  void finiteFuelStopsAtExactBoundary() {
    Profile p = mine();
    p.fuel = 5;
    Production.settle(p, START + 3600000);
    assertEquals(10, p.stock[0]);
    assertEquals(0, p.fuel);
    assertEquals(999985, p.budget);
  }

  @Test
  void traderNeedsNoFuel() {
    Profile p = mine();
    p.workers.clear();
    p.workers.add(new Profile.Worker("Yara", Profile.Job.TRADER, 0));
    p.stock[0] = 10;
    p.fuel = 0;
    Production.settle(p, START + 60000);
    assertEquals(24, p.money);
    assertEquals(8, p.stock[0]);
  }

  @Test
  void chainRunsInJobOrderNotHiringOrder() {
    Profile p = mine();
    p.furnace = 1;
    p.workers.addFirst(new Profile.Worker("Yara", Profile.Job.TRADER, 0));
    p.workers.addFirst(new Profile.Worker("Mira", Profile.Job.SMELTER, 0));
    // Bars reserved for research and the bar contract stay; the fresh bar is surplus.
    long reserve = Industry.barReserve(p, 0);
    p.bars[0] = reserve;
    Production.settle(p, START + 60000);
    assertEquals(reserve, p.stockUsed());
    assertEquals(reserve, p.bars[0]);
    assertEquals(32, p.money);
    assertEquals(999991, p.budget);
    assertEquals(99998, p.fuel);
  }

  @Test
  void backwardsClockNeverProducesOrMovesTimestampBack() {
    Profile p = mine();
    Production.settle(p, START - 60000);
    assertEquals(START, p.lastSettled);
    assertEquals(0, p.stock[0]);
  }

  @Test
  void partialMinuteCarriesAcrossSessions() {
    Profile p = mine();
    Production.settle(p, START + 59000);
    assertEquals(START, p.lastSettled);
    Production.settle(p, START + 61000);
    assertEquals(2, p.stock[0]);
    assertEquals(START + 60000, p.lastSettled);
  }

  @Test
  void batchingHasSameResultAsMinuteSteps() {
    Profile a = mine(), b = mine();
    a.furnace = b.furnace = 1;
    a.workers.add(new Profile.Worker("Mira", Profile.Job.SMELTER, 0));
    b.workers.add(new Profile.Worker("Mira", Profile.Job.SMELTER, 0));
    Production.settle(a, START + 120 * 60000L);
    for (int i = 1; i <= 120; i++) Production.settle(b, START + i * 60000L);
    assertArrayEquals(a.stock, b.stock);
    assertArrayEquals(a.bars, b.bars);
    assertEquals(a.fuel, b.fuel);
    assertEquals(a.budget, b.budget);
  }

  @Test
  void switchingAssignmentDoesNotRetroactivelyChangePreviousProduction() {
    Profile p = mine();
    p.zone = 1;
    Production.settle(p, START + 60000);
    p.workers.getFirst().zone = 1;
    Production.settle(p, START + 120000);
    assertEquals(2, p.stock[0]);
    assertEquals(2, p.stock[1]);
  }

  @Test
  void traderKeepsBarsNeededForResearchAndBarContract() {
    Profile p = mine();
    p.workers.clear();
    p.workers.add(new Profile.Worker("Yara", Profile.Job.TRADER, 0));
    // Next iron research needs 4 bars; the first bar contract (zone 0) needs 16.
    assertEquals(4 + Industry.contract(p, 1).amount(), Industry.barReserve(p, 0));
    p.bars[0] = Industry.barReserve(p, 0);
    Production.settle(p, START + 60000);
    assertEquals(Industry.barReserve(p, 0), p.bars[0]);
    assertEquals("Wartet auf Ware", Industry.stopped(p, p.workers.getFirst()));
    p.bars[0] += 1;
    assertEquals(1, Industry.sellableBars(p, 0));
    assertEquals(0, Industry.barReserve(p, 3));
  }
}
