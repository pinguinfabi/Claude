package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MonsterScalingTest {
  @Test
  void deeperMinesHaveFarMoreLifeAndHitFarHarder() {
    assertEquals(65, MonsterScaling.health(0, 0), 1e-9);
    for (int z = 1; z < 7; z++) {
      assertEquals(1.55, MonsterScaling.health(z, 0) / MonsterScaling.health(z - 1, 0), 1e-9);
      assertEquals(1.4, MonsterScaling.touch(z) / MonsterScaling.touch(z - 1), 1e-9);
      assertTrue(MonsterScaling.attack(true, z, 0) > MonsterScaling.attack(true, z - 1, 0) * 1.29);
    }
    // Every zone clearly above the old linear values: (22 + 15z) * 2 life, 2 + 0.7z touch damage.
    for (int z = 0; z < 7; z++) {
      assertTrue(MonsterScaling.health(z, 0) >= (22 + 15 * z) * 2 * 1.3, "zone " + z);
      assertTrue(MonsterScaling.touch(z) > 2 + .7 * z, "zone " + z);
    }
    assertTrue(MonsterScaling.health(6, 0) > 3.5 * (22 + 15 * 6) * 2);
    assertTrue(MonsterScaling.touch(6) > 2.5 * (2 + .7 * 6));
  }
}
