package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class LumberjackTest {
  static final long START = 1_000_000_000L;

  private static Profile forest(int species) {
    Profile p = new Profile();
    p.lastSettled = START;
    p.budget = 1_000_000;
    p.fuel = 0;
    p.forestTier = 1;
    p.workers.add(new Profile.Worker("Finn", Profile.Job.LUMBERJACK, species));
    return p;
  }

  @Test
  void chopsIntoWoodStorageWithoutFuel() {
    Profile p = forest(1);
    var r = Production.settle(p, START + 60 * 60_000L);
    assertEquals(30, p.wood[1], "level 1: half a log per minute");
    assertEquals(30, r.chopped());
    assertEquals(0, p.fuel);
    assertEquals(30, p.woodChopped);
    assertTrue(r.costs() > 0);
  }

  @Test
  void lockedWoodTypeFallsBackAndFullStorageStops() {
    Profile p = forest(2);
    assertEquals(1, Industry.woodType(p, p.workers.getFirst()), "spruce locked, birch unlocked");
    p.wood[0] = Forestry.capacity(p);
    long budget = p.budget;
    var r = Production.settle(p, START + 30 * 60_000L);
    assertEquals(0, r.chopped());
    assertEquals("Holzlager voll", r.stopped());
    assertEquals(budget, p.budget, "no wages without work");
    assertEquals("Holzlager voll", Industry.stopped(p, p.workers.getFirst()));
  }

  @Test
  void findsResinAndHiresOnOak() {
    Profile p = forest(0);
    p.research[2] = 2;
    Production.settle(p, START + Industry.RESIN_EVERY * 60_000L);
    assertEquals(1, p.resin);
    Profile q = new Profile();
    q.bosses[0] = true;
    q.money = 10_000;
    q.zone = 3;
    Economy.hire(q, Profile.Job.LUMBERJACK);
    assertEquals(0, q.workers.getFirst().zone, "lumberjacks start on oak");
    assertFalse(Industry.usesFuel(Profile.Job.LUMBERJACK));
  }
}
