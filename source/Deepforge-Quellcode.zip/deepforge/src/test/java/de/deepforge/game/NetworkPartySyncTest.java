package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import de.deepforge.world.NetworkParties;
import java.io.*;
import java.util.*;
import org.junit.jupiter.api.Test;

class NetworkPartySyncTest {
  private final UUID a = UUID.randomUUID(), b = UUID.randomUUID(), c = UUID.randomUUID(), d = UUID.randomUUID();

  @Test
  void networkPartiesBecomeTheParties() {
    PartyBook book = new PartyBook();
    book.create(d);
    book.create(c);
    book.invite(c, a, 0);
    book.sync(List.of(List.of(a, b, c)), id -> true);
    assertTrue(book.networkMode());
    PartyBook.Party p = book.get(a);
    assertSame(p, book.get(b));
    assertSame(p, book.get(c));
    assertEquals(a, p.leader);
    assertTrue(p.network);
    assertEquals(List.of(a, b, c), List.copyOf(p.members));
    assertNotNull(book.get(d), "a solo group outside the network party stays");
  }

  @Test
  void onlyPlayersOnThisServerAreMembersAndPlotStays() {
    PartyBook book = new PartyBook();
    book.sync(List.of(List.of(a, b, c)), id -> !id.equals(a));
    PartyBook.Party p = book.get(b);
    assertNull(book.get(a));
    assertEquals(b, p.leader, "absent leader: the first present member leads here");
    p.plot = 7;
    p.ready.add(b);
    book.sync(List.of(List.of(a, b, c)), id -> !id.equals(a));
    assertSame(p, book.get(b));
    assertEquals(7, p.plot);
    assertTrue(p.ready.contains(b), "unchanged party keeps ready marks");
    book.sync(List.of(List.of(a, b, c, d)), id -> !id.equals(a));
    assertTrue(p.ready.isEmpty(), "new member: everyone confirms again");
    book.sync(List.of(), id -> true);
    assertNull(book.get(b), "disbanded on the network: gone here too");
  }

  @Test
  void decodesTheProxyFormat() throws IOException {
    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
    DataOutputStream out = new DataOutputStream(bytes);
    out.writeUTF("SNAPSHOT");
    out.writeInt(2);
    out.writeInt(2);
    out.writeUTF(a.toString());
    out.writeUTF(b.toString());
    out.writeInt(1);
    out.writeUTF(c.toString());
    assertEquals(List.of(List.of(a, b), List.of(c)), NetworkParties.decode(bytes.toByteArray()));
    assertThrows(IOException.class, () -> NetworkParties.decode(new byte[] {0, 3, 'B', 'A', 'D'}));
  }
}
