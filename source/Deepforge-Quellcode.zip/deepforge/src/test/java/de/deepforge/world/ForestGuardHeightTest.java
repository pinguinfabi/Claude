package de.deepforge.world;

import static org.junit.jupiter.api.Assertions.*;

import de.deepforge.game.Zone;
import org.junit.jupiter.api.Test;

/** 0.22.1: the grove guard must never fire in the mines below the woodland. */
class ForestGuardHeightTest {
  @Test
  void minesAreBelowTheWoodland() {
    assertTrue(ForestryWorld.forestHeight(201), "woodland floor");
    for (int z = 0; z < Zone.COUNT; z++) {
      int floor = 168 - (z >= Zone.FIRST_DEEP ? z - Zone.FIRST_DEEP : z) * 24;
      // a miner stands at most a few blocks above the mine floor
      assertFalse(ForestryWorld.forestHeight(floor + 1), "mine " + (z + 1));
      assertFalse(ForestryWorld.forestHeight(floor + 20), "mine " + (z + 1) + " roof");
    }
    // the deep shaft sits right under the birch and spruce groves
    assertTrue(MineWorld.DEEP_X > 64 && MineWorld.DEEP_X < 124);
  }
}
