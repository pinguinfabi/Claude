package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class CharacterSheetTest {
  private static Profile equippedDagger(Gear.Rarity rarity) {
    Profile p = new Profile();
    p.sword = 4;
    Gear.Item dagger = new Gear.Item();
    dagger.name = "Testdolch";
    dagger.style = "dagger";
    dagger.rarity = rarity;
    dagger.damage = 3;
    dagger.crit = .04;
    dagger.stagger = 5;
    p.gear.add(dagger);
    Gear.equip(p, dagger.id);
    return p;
  }

  @Test
  void combatValuesMatchTheCombatFormulas() {
    Profile p = equippedDagger(Gear.Rarity.RARE);
    Gear.Stats s = Gear.stats(p);
    String text = String.join("\n", CharacterSheet.combat(p));
    assertTrue(text.contains("Trefferschaden: " + CharacterSheet.f(RapidCombat.damage(s)) + " LP"), text);
    assertTrue(text.contains("Grundschaden " + CharacterSheet.f(s.damage())), text);
    assertTrue(text.contains("Krit-Chance: " + CharacterSheet.f(s.crit() * 100) + " %"), text);
    assertTrue(text.contains("Haltungsschaden: " + CharacterSheet.f(RapidCombat.posture(s))), text);
    assertTrue(text.contains("Rückenbonus: +35 %"), text);
    assertEquals(
        RapidCombat.damage(s) * 4 * (1 + s.crit() * (s.critDamage() - 1)),
        CharacterSheet.averageDps(p),
        1e-9);
    assertFalse(
        String.join("\n", CharacterSheet.combat(new Profile())).contains("Rückenbonus"),
        "only daggers have a rear bonus");
  }

  @Test
  void miningAndResourcesShowTheRealValues() {
    Profile p = new Profile();
    p.tool = 3;
    p.dust = 12;
    p.relics = 4;
    p.researchNotes = 9;
    ToolStats t = ToolStats.of(p, 0, false);
    String mining = String.join("\n", CharacterSheet.mining(p));
    assertTrue(mining.contains(CharacterSheet.f(t.speed()) + "×"), mining);
    assertTrue(mining.contains("Rucksack: 0 / " + p.bagCapacity()), mining);
    String res = String.join("\n", CharacterSheet.resources(p));
    assertTrue(res.contains("Schmiedestaub: 12"), res);
    assertTrue(res.contains("Relikte: 4"), res);
    assertTrue(res.contains("Forschungsunterlagen: 9"), res);
  }

  @Test
  void progressCountsMilestones() {
    Profile p = new Profile();
    p.kills = 30;
    String before = String.join("\n", CharacterSheet.progress(p));
    assertTrue(before.contains("1 abholbar"), before);
    Milestones.claim(p, "kills");
    String after = String.join("\n", CharacterSheet.progress(p));
    assertTrue(after.contains("Meilensteine: 1 / 27"), after);
    assertFalse(after.contains("abholbar"), after);
  }
}
