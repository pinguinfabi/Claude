package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class RunesTest {
  @Test
  void codesNamesAndDropTiersFollowTheZone() {
    int code = Runes.code(Runes.Kind.GLUECK, 3);
    assertEquals(Runes.Kind.GLUECK, Runes.kind(code));
    assertEquals(3, Runes.tier(code));
    assertEquals("Glücksrune III", Runes.name(code));
    assertEquals("+4,5 % Krit-Chance", Runes.effect(code));
    Random r = new Random(7);
    for (int i = 0; i < 200; i++) {
      assertTrue(Runes.dropTier(0, r) <= 2);
      int deep = Runes.dropTier(6, r);
      assertTrue(deep >= 4 && deep <= 5);
    }
  }

  @Test
  void threeEqualRunesForgeTheNextTier() {
    Profile p = new Profile();
    int code = Runes.code(Runes.Kind.KRAFT, 1);
    p.runes[code] = 4;
    p.dust = 5;
    assertTrue(Runes.combine(p, code).startsWith("Runenschmiede"));
    assertEquals(1, p.runes[code]);
    assertEquals(1, p.runes[code + 1]);
    assertEquals(0, p.dust);
    assertTrue(Runes.combine(p, code).startsWith("Benötigt 3×"));
    p.runes[Runes.code(Runes.Kind.KRAFT, 5)] = 9;
    assertEquals("Stufe V ist die höchste Rune.", Runes.combine(p, Runes.code(Runes.Kind.KRAFT, 5)));
  }

  @Test
  void socketsAreDrilledFilledAndEmptiedAndChangeTheStats() {
    Profile p = new Profile();
    Gear.Item sword = Gear.roll(0, Gear.Rarity.RARE, new Random(1));
    sword.slot = Gear.Slot.WEAPON;
    p.gear.add(sword);
    p.equipped.put("WEAPON", sword.id);
    assertEquals(0, Runes.sockets(sword).length);
    p.money = 100_000;
    p.dust = 100;
    assertTrue(Runes.drill(p, sword.id).startsWith("Sockel gebohrt"));
    assertTrue(Runes.drill(p, sword.id).startsWith("Maximal 1"), "rare items get one socket");
    double before = Gear.stats(p).damage(), health = Gear.stats(p).health();
    int kraft = Runes.code(Runes.Kind.KRAFT, 5);
    assertEquals("Diese Rune hast du nicht.", Runes.insert(p, sword.id, 0, kraft));
    p.runes[kraft] = 1;
    assertTrue(Runes.insert(p, sword.id, 0, kraft).startsWith("Kraftrune V eingesetzt"));
    assertEquals(0, p.runes[kraft]);
    assertEquals(before * 1.15, Gear.stats(p).damage(), 1e-9);
    assertTrue(Runes.insert(p, sword.id, 0, kraft).startsWith("Der Sockel ist schon belegt"));
    assertTrue(Runes.remove(p, sword.id, 0).contains("herausgelöst"));
    assertEquals(1, p.runes[kraft]);
    assertEquals(before, Gear.stats(p).damage(), 1e-9);
    int leben = Runes.code(Runes.Kind.LEBEN, 4);
    p.runes[leben] = 1;
    Runes.insert(p, sword.id, 0, leben);
    assertEquals(health + 16, Gear.stats(p).health(), 1e-9);
  }

  @Test
  void epicAndBetterLootComesWithEmptySockets() {
    Random r = new Random(2);
    assertEquals(0, Gear.roll(1, Gear.Rarity.RARE, r).runeSockets.length);
    assertArrayEquals(new int[] {-1}, Gear.roll(1, Gear.Rarity.EPIC, r).runeSockets);
    assertArrayEquals(new int[] {-1, -1}, Gear.roll(1, Gear.Rarity.LEGENDARY, r).runeSockets);
    Gear.Item old = new Gear.Item();
    old.runeSockets = null;
    assertEquals(0, Runes.sockets(old).length, "items from before 0.8.0 have no sockets");
  }

  @Test
  void dungeonWinsDropOneRune() {
    Profile p = new Profile();
    p.id = UUID.randomUUID().toString();
    p.zone = 3;
    DungeonRules.reward(p, UUID.randomUUID(), 3, 1, 100, 5, 0, EnumSet.noneOf(Gear.Slot.class), DungeonVariant.GEWOELBE);
    assertEquals(1, Runes.total(p));
  }
}
