package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import org.junit.jupiter.api.Test;

class DailiesTest {
  private static final LocalDate DAY = LocalDate.of(2026, 9, 28);

  private static Profile player() {
    Profile p = new Profile();
    p.id = "00000000-0000-0000-0000-000000000001";
    p.zone = 1;
    return p;
  }

  @Test
  void threeTasksPerDayCountOnlyNewProgress() {
    Profile p = player();
    p.mined = 5000;
    assertTrue(Dailies.ensure(p, DAY));
    assertFalse(Dailies.ensure(p, DAY), "same day keeps its tasks");
    assertEquals(3, p.dailyTasks.size());
    assertEquals(3, p.dailyTasks.stream().distinct().count());
    assertTrue(p.dailyTasks.contains("ore") || p.dailyTasks.contains("kills"));
    for (int i = 0; i < 3; i++) assertEquals(0, Dailies.progress(p, i), "old progress must not count");
    // Tasks that need locked systems are never handed out.
    assertFalse(p.dailyTasks.contains("smelt"));
    assertFalse(p.dailyTasks.contains("dungeon"));
  }

  @Test
  void claimingAllThreeBuildsTheStreak() {
    Profile p = player();
    p.furnace = 1;
    p.kills = 20;
    p.axe = 1;
    Dailies.ensure(p, DAY);
    assertTrue(Dailies.claim(p, 0, DAY).startsWith("Es fehlen"));
    finishAll(p);
    long before = p.money;
    for (int i = 0; i < 3; i++) Dailies.claim(p, i, DAY);
    assertEquals(1, p.dailyStreak);
    assertEquals(1, p.relics);
    assertEquals(3 + 2, p.dust);
    assertEquals(before + 3 * Dailies.money(p) + Dailies.bonusMoney(p, 1), p.money);
    assertTrue(Dailies.claim(p, 0, DAY).contains("schon"));

    LocalDate next = DAY.plusDays(1);
    assertTrue(Dailies.ensure(p, next));
    assertEquals(0, Dailies.claimedCount(p));
    finishAll(p);
    for (int i = 0; i < 3; i++) Dailies.claim(p, i, next);
    assertEquals(2, p.dailyStreak);
    assertEquals(2, p.dailyBestStreak);

    // Skipping a day resets the streak.
    LocalDate later = next.plusDays(2);
    assertEquals(0, Dailies.liveStreak(p, later));
    Dailies.ensure(p, later);
    finishAll(p);
    for (int i = 0; i < 3; i++) Dailies.claim(p, i, later);
    assertEquals(1, p.dailyStreak);
    assertEquals(2, p.dailyBestStreak);
  }

  @Test
  void brokenSavedStateIsReplaced() {
    Profile p = player();
    p.dailyDate = DAY.toString();
    p.dailyTasks = new java.util.ArrayList<>(java.util.List.of("ore", "gone", "kills"));
    assertTrue(Dailies.ensure(p, DAY));
    assertTrue(p.dailyTasks.stream().allMatch(id -> Dailies.task(id) != null));
  }

  private static void finishAll(Profile p) {
    p.mined += 10_000;
    p.kills += 10_000;
    p.woodTrees += 10_000;
    p.depositedOre += 10_000;
    p.manualSmelted += 10_000;
    p.soldBars += 10_000;
    p.dodges += 10_000;
    p.dungeonWins[0] += 10_000;
  }
}
