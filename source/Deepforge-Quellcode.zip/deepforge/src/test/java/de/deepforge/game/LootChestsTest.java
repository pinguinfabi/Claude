package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.UUID;
import org.junit.jupiter.api.Test;

class LootChestsTest {
  @Test
  void onlyAfterAWinThreeChestsWithDoublingPrices() {
    Profile p = new Profile();
    p.id = UUID.randomUUID().toString();
    assertFalse(LootChests.available(p));
    assertTrue(LootChests.buy(p).startsWith("Gewölbekisten gibt es nur"));

    UUID run = UUID.randomUUID();
    assertTrue(DungeonRules.reward(p, run, 2, 0, 5000, 3));
    assertTrue(LootChests.available(p));
    long coins = DungeonRules.coins(2, 0, 3);
    assertEquals(coins * 2, LootChests.price(p), "first chest costs twice the run's coins");

    long start = p.money;
    assertTrue(LootChests.buy(p).startsWith("Die Kiste kostet"), "not enough money");
    assertEquals(start, p.money);

    p.money = 100 * coins;
    int items = p.gear.size();
    long[] paid = new long[3];
    for (int i = 0; i < 3; i++) {
      long before = p.money;
      assertTrue(LootChests.buy(p).startsWith("Gewölbekiste geöffnet"));
      paid[i] = before - p.money;
    }
    assertArrayEquals(new long[] {2 * coins, 4 * coins, 8 * coins}, paid);
    assertEquals(items + 3, p.gear.size());
    assertFalse(LootChests.available(p));
    assertTrue(LootChests.buy(p).startsWith("Für diesen Lauf"));

    // A new win offers new chests at the start price again.
    DungeonRules.reward(p, UUID.randomUUID(), 2, 0, 5000, 4);
    assertTrue(LootChests.available(p));
    assertEquals(0, p.chestBought);
  }
}
