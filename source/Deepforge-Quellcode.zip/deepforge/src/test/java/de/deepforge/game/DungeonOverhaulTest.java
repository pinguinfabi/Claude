package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

/** 0.11.0: harder boss fights, Wächter and the hit statistics. */
class DungeonOverhaulTest {
  @Test
  void harderModesBringNewAttacks() {
    for (int zone = 0; zone < Zone.COUNT; zone++) {
      assertFalse(BossPatterns.kit(zone, 0, 0).contains(BossPatterns.Attack.METEOR));
      assertTrue(BossPatterns.kit(zone, 2, 0).contains(BossPatterns.Attack.METEOR));
      assertTrue(BossPatterns.kit(zone, 1, 1).contains(BossPatterns.Attack.RIFT));
      assertTrue(BossPatterns.kit(zone, 2, 2).containsAll(List.of(
          BossPatterns.Attack.METEOR, BossPatterns.Attack.RIFT, BossPatterns.Attack.MARK,
          BossPatterns.Attack.CHAIN, BossPatterns.Attack.SUMMON)));
      assertFalse(BossPatterns.kit(zone, 1, 2).contains(BossPatterns.Attack.SUMMON));
      for (int n = 0; n < 40; n++)
        assertTrue(BossPatterns.kit(zone, 2, 2).contains(BossPatterns.next(zone, 2, 2, n, 99)));
    }
  }

  @Test
  void difficultyScalesDamageWarningsAndEnrage() {
    assertTrue(BossPatterns.modeDamage(2) > BossPatterns.modeDamage(1));
    assertTrue(BossPatterns.modeDamage(1) > BossPatterns.modeDamage(0));
    for (BossPatterns.Attack a : BossPatterns.Attack.values())
      assertTrue(BossPatterns.warning(a, 1, 10, false, 2) < BossPatterns.warning(a, 1, 10, false, 0), a.name());
    assertTrue(BossPatterns.enrageAfter(2) < BossPatterns.enrageAfter(0));
    assertEquals(1, BossPatterns.enrageStacks(1, 6000));
    assertEquals(1.4, BossPatterns.enrageStacks(2, 1200), 1e-9);
    assertEquals(0, BossPatterns.comboChance(0));
    assertEquals(3, BossPatterns.maxCombo(2));
    assertTrue(BossPatterns.shrinkRadius(0, 100_000) > BossPatterns.ARENA);
    assertEquals(7, BossPatterns.shrinkRadius(2, 100_000), 1e-9);
    assertTrue(BossPatterns.healLock(2));
    assertFalse(BossPatterns.healLock(1));
  }

  @Test
  void lightningChainsOnlyThroughClosePlayers() {
    List<double[]> players = List.of(new double[] {0, 0}, new double[] {3, 0}, new double[] {6, 0}, new double[] {20, 0});
    assertEquals(Set.of(0, 1, 2), BossPatterns.chain(players, 0));
    assertEquals(Set.of(3), BossPatterns.chain(players, 3));
    assertTrue(BossPatterns.chain(players, 9).isEmpty());
  }

  @Test
  void riftsAreLinesThroughTheCentre() {
    assertTrue(BossPatterns.rift(5, 0, 0));
    assertTrue(BossPatterns.rift(-5, .5, 0));
    assertFalse(BossPatterns.rift(0, 5, 0));
    assertTrue(BossPatterns.rift(0, 5, Math.PI / 2));
  }

  @Test
  void guardianRoomsAvoidWarmUpAndBoss() {
    List<Integer> fight = List.of(0, 1, 2, 3, 4, 5);
    for (long seed = 0; seed < 50; seed++) {
      List<Integer> normal = Minibosses.rooms(fight, 5, 0, seed);
      List<Integer> nightmare = Minibosses.rooms(fight, 5, 2, seed);
      assertEquals(1, normal.size());
      assertEquals(2, nightmare.size());
      assertFalse(nightmare.contains(0));
      assertFalse(nightmare.contains(5));
      assertEquals(nightmare, Minibosses.rooms(fight, 5, 2, seed), "deterministic");
      assertNotEquals(Minibosses.kind(seed, 0), Minibosses.kind(seed, 1));
    }
    assertTrue(Minibosses.rooms(List.of(0, 3), 3, 2, 1).isEmpty(), "tiny dungeon: no room left");
  }

  @Test
  void guardianRules() {
    assertTrue(Minibosses.behind(-1));
    assertFalse(Minibosses.behind(0));
    assertFalse(Minibosses.behind(1));
    assertFalse(Minibosses.mirrored(10, 0), "grace period after the spawn");
    assertTrue(Minibosses.mirrored(80, 0));
    assertFalse(Minibosses.mirrored(80 + Minibosses.mirrorTime(0), 0));
    assertTrue(Minibosses.mirrorTime(2) > Minibosses.mirrorTime(0));
    assertTrue(Minibosses.tethered(7.5));
    assertFalse(Minibosses.tethered(6));
    assertTrue(Minibosses.onIsland(1, 1, List.of(new double[] {0, 0})));
    assertFalse(Minibosses.onIsland(3, 3, List.of(new double[] {0, 0})));
    assertTrue(Minibosses.islands(1, 2) >= 1);
    assertTrue(Minibosses.islands(4, 2) >= 2, "a full group still fits");
    assertFalse(Minibosses.revive(-1, 1000));
    assertFalse(Minibosses.revive(100, 150));
    assertTrue(Minibosses.revive(100, 100 + Minibosses.TWIN_WINDOW));
    assertTrue(Minibosses.minions(2, 4) > Minibosses.minions(0, 1));
  }

  @Test
  void guardianChestPaysCoinsDustAndAnItem() {
    Profile p = new Profile();
    long before = p.money;
    int items = p.gear.size();
    List<String> lines = Minibosses.chest(p, 3, 1, 5, Minibosses.Kind.MIRROR, new Random(4));
    assertEquals(DungeonRules.coins(3, 1, 5) / 4, p.money - before);
    assertEquals(items + 1, p.gear.size());
    assertTrue(p.gear.getLast().rarity.ordinal() >= Gear.Rarity.RARE.ordinal());
    assertTrue(p.gear.getLast().name.startsWith("Spiegelritter"));
    assertTrue(p.dust >= 10);
    assertEquals(3, lines.size());
  }

  @Test
  void statisticsNameTheDeadliestAttack() {
    DungeonStats s = new DungeonStats();
    UUID a = UUID.randomUUID(), b = UUID.randomUUID();
    assertNull(s.nemesis());
    s.hitBy(a, "Blitzkette");
    s.hitBy(a, "Meteoritenhagel");
    s.hitBy(b, "Meteoritenhagel");
    s.hitBy(a, "Meteoritenhagel");
    assertEquals("Meteoritenhagel", s.nemesis().getKey());
    assertEquals(3, s.nemesis().getValue());
    assertEquals("Meteoritenhagel 2× · Blitzkette 1×", s.hitsOf(a));
    assertEquals("", s.hitsOf(UUID.randomUUID()));
  }

  @Test
  void wikiExplainsGuardiansAndEveryAttack() {
    assertTrue(Wiki.page("dungeons").children().containsAll(List.of("guardians", "dboss")));
    assertEquals(Minibosses.Kind.values().length + 1, Wiki.page("guardians").entries().size());
    assertEquals(BossPatterns.Attack.values().length + 1, Wiki.page("dboss").entries().size());
  }
}
