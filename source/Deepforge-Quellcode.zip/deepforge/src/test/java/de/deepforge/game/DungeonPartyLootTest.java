package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class DungeonPartyLootTest {
  @Test
  void everyPartyMemberGetsADifferentKindOfItem() {
    for (int run = 0; run < 25; run++) {
      UUID receipt = new UUID(run * 7919L, run * 104729L);
      Set<Gear.Slot> taken = EnumSet.noneOf(Gear.Slot.class);
      Set<Gear.Slot> slots = new HashSet<>();
      for (int member = 0; member < 4; member++) {
        Profile p = new Profile();
        p.id = new UUID(member + 1, member * 31L + run).toString();
        p.dungeonLevel = 5;
        assertTrue(DungeonRules.reward(p, receipt, 2, 1, 6000, 5, 0, taken));
        Gear.Item loot =
            p.gear.stream().filter(i -> i.name.startsWith("Gewölbe L5")).findFirst().orElseThrow();
        slots.add(loot.slot);
      }
      assertEquals(4, slots.size(), "run " + run + ": all four members differ");
    }
  }
}
