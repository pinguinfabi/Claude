package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Random;
import org.junit.jupiter.api.Test;

class DeepPassTest {
  private static final LocalDate DAY = LocalDate.of(2026, 9, 29);

  @Test
  void seasonsLastFourWeeksAndResetProgress() {
    assertEquals(1, DeepPass.season(DAY));
    assertEquals(DeepPass.season(DAY) + 1, DeepPass.season(DAY.plusDays(DeepPass.daysLeft(DAY))));
    assertEquals(DeepPass.season(DAY), DeepPass.season(DAY.plusDays(DeepPass.daysLeft(DAY) - 1)));
    Profile p = new Profile();
    DeepPass.add(p, 5000, DAY);
    DeepPass.claim(p, 1, new Random(1));
    assertTrue(DeepPass.tier(p) > 5);
    DeepPass.add(p, 1, DAY.plusDays(40));
    assertEquals(1, p.passXp);
    assertTrue(p.passClaimed.isEmpty());
  }

  @Test
  void tiersRiseWithXpAndEachRewardIsClaimedOnce() {
    Profile p = new Profile();
    assertEquals(0, DeepPass.add(p, DeepPass.need(1) - 1, DAY));
    assertEquals(0, DeepPass.tier(p));
    assertEquals(1, DeepPass.add(p, 1, DAY));
    assertEquals(1, DeepPass.tier(p));
    long money = p.money;
    assertTrue(DeepPass.claim(p, 1, new Random(1)).startsWith("Tiefenpass Stufe 1"));
    assertEquals(money + DeepPass.money(p, 1), p.money);
    assertEquals("Schon abgeholt.", DeepPass.claim(p, 1, new Random(1)));
    assertTrue(DeepPass.claim(p, 2, new Random(1)).startsWith("Benötigt"));
  }

  @Test
  void fullSeasonGivesThreeGearPiecesAndBonusTiersAfterwards() {
    Profile p = new Profile();
    DeepPass.add(p, DeepPass.total(DeepPass.TIERS) + 2 * DeepPass.BONUS_XP + 10, DAY);
    assertEquals(DeepPass.TIERS, DeepPass.tier(p));
    assertEquals(2, DeepPass.bonusEarned(p));
    assertEquals(DeepPass.TIERS + 2, DeepPass.claimableCount(p));
    p.healingCharges = Healing.CAPACITY;
    long relics = p.relics;
    DeepPass.claimAll(p, new Random(3));
    assertEquals(0, DeepPass.claimableCount(p));
    assertEquals(3, p.gear.size());
    assertEquals(Gear.Rarity.LEGENDARY, p.gear.get(2).rarity);
    assertEquals(relics + 4, p.relics);
    assertTrue(p.dust > 100, "full healing stock turns shards into dust");
    assertTrue(DeepPass.total(DeepPass.TIERS) > 20_000 && DeepPass.total(DeepPass.TIERS) < 30_000);
  }
}
