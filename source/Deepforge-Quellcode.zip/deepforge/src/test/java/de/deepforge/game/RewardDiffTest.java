package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class RewardDiffTest {
  @Test
  void listsExactlyWhatWasGained() {
    Profile before = new Profile();
    before.money = 1000;
    before.dungeonLevel = 3;
    Gear.Item kept = new Gear.Item();
    kept.name = "Alt";
    before.gear.add(kept);
    Profile after = new Profile();
    after.money = 2500;
    after.dust = 4;
    after.monsterParts[2] = 6;
    after.healingCharges = before.healingCharges + 2;
    after.dungeonLevel = 4;
    after.gear.add(kept);
    Gear.Item fresh = new Gear.Item();
    fresh.name = "Runenklinge";
    fresh.rarity = Gear.Rarity.EPIC;
    fresh.level = 2;
    after.gear.add(fresh);

    RewardDiff d = RewardDiff.between(before, after);
    assertEquals(1, d.items.size());
    assertEquals(
        java.util.List.of(
            "+1.500 $",
            "+4 Schmiedestaub",
            "+6 Monsterteile",
            "+2 Lebenssplitter",
            "Dungeonlevel 3 → 4",
            Gear.Rarity.EPIC.title + " · Runenklinge +2"),
        d.lines());
    assertEquals("+1.500 $ · 1 neuer Gegenstand · Level 4", d.headline());
    assertTrue(RewardDiff.between(before, before).empty());
  }
}
