package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class ChampionsTest {
  @Test
  void upperMinesRollOneTraitDeeperOnesOftenTwoAndNeverTwiceTheSame() {
    Random r = new Random(5);
    int doubles = 0;
    for (int i = 0; i < 500; i++) {
      assertEquals(1, Champions.roll(0, r).size());
      List<Champions.Affix> deep = Champions.roll(6, r);
      assertEquals(deep.size(), new HashSet<>(deep).size());
      if (deep.size() == 2) doubles++;
    }
    assertTrue(doubles > 300, "about 80 % of champions in the last mine have two traits");
  }

  @Test
  void traitsChangeTheNumbers() {
    List<Champions.Affix> tank = List.of(Champions.Affix.GEPANZERT, Champions.Affix.RIESE);
    assertEquals(5, Champions.health(tank), 1e-9);
    assertEquals(.6, Champions.damageTaken(tank), 1e-9);
    assertEquals(28, Champions.touchCooldown(tank));
    List<Champions.Affix> fast = List.of(Champions.Affix.RASEND, Champions.Affix.BRENNEND);
    assertEquals(16, Champions.touchCooldown(fast));
    assertEquals(1.35 * 1.5, Champions.damage(fast), 1e-9);
    assertEquals(2.5, Champions.health(fast), 1e-9);
    assertEquals("✦ Rasend Brennend Erzkrabbler", Champions.name(fast, "Erzkrabbler"));
    assertTrue(Champions.lifesteal(List.of(Champions.Affix.VAMPIR)) > 0);
  }
}
