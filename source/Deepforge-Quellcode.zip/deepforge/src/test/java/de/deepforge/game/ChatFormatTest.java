package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import de.deepforge.ui.ChatFormat;
import de.deepforge.ui.PlayerRank;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.junit.jupiter.api.Test;

class ChatFormatTest {
  private static final PlainTextComponentSerializer TEXT = PlainTextComponentSerializer.plainText();

  @Test
  void rankNameArrowMessage() {
    assertEquals(
        "ADMIN Tom » hallo",
        TEXT.serialize(ChatFormat.line(PlayerRank.ADMIN, "Tom", Component.text("hallo"), false)));
    assertEquals(
        "Tom » hallo",
        TEXT.serialize(ChatFormat.line(PlayerRank.NONE, "Tom", Component.text("hallo"), false)));
    String glyph =
        TEXT.serialize(ChatFormat.line(PlayerRank.VIP, "Tom", Component.text("hallo"), true));
    assertTrue(glyph.endsWith(" Tom » hallo"));
    assertFalse(glyph.contains("VIP"), "pack users get the tag glyph instead of text");
  }
}
