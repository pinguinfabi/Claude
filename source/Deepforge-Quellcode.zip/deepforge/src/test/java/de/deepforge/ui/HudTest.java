package de.deepforge.ui;

import static org.junit.jupiter.api.Assertions.*;

import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.junit.jupiter.api.Test;

class HudTest {
  @Test
  void gaugeAndColoursFollowTheHeat() {
    assertEquals("▯▯▯▯▯▯▯▯▯▯", Hud.gauge(0));
    assertEquals("▮▮▮▮▮▯▯▯▯▯", Hud.gauge(49.6));
    assertEquals("▮▮▮▮▮▮▮▮▮▮", Hud.gauge(140));
    assertEquals(NamedTextColor.GREEN, Hud.heatColor(10));
    assertEquals(NamedTextColor.GOLD, Hud.heatColor(70));
    assertEquals(NamedTextColor.RED, Hud.heatColor(90));
  }

  @Test
  void miningLineShowsMoneyBagAndFullWarning() {
    String line = PlainTextComponentSerializer.plainText().serialize(Hud.mining(1234567, 40, 40, 12));
    assertTrue(line.startsWith("1.234.567 $"), line);
    assertTrue(line.contains("Rucksack 40/40 VOLL"), line);
    assertTrue(line.contains("Hitze ▮▯▯▯▯▯▯▯▯▯ 12 %"), line);
  }

  @Test
  void arrowPointsRelativeToTheView() {
    // Minecraft yaw 0 looks south (+z); west (-x) is then on the right.
    assertEquals("↑", Hud.arrow(0, 0, 10));
    assertEquals("→", Hud.arrow(0, -10, 0));
    assertEquals("←", Hud.arrow(0, 10, 0));
    assertEquals("↓", Hud.arrow(0, 0, -10));
    assertEquals("↑", Hud.arrow(180, 0, -10));
    assertEquals("↗", Hud.arrow(0, -10, 10));
  }
}
