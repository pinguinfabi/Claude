package de.deepforge.world;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class WorkerRoutesTest {
  @Test
  void allWorkerPathsLeadFromLiftToRealOreWithoutWallsOrArena() {
    for (int zone = 0; zone < de.deepforge.game.Zone.COUNT; zone++) {
      var plan = MineBlueprint.create(zone);
      var sites = WorkerRoutes.sites(plan);
      assertTrue(sites.size() > 6);
      for (var site : sites) {
        assertTrue(plan.isOre(site.ore().x(), site.ore().h(), site.ore().z()));
        assertEquals(new MineBlueprint.Point(0, 1, 35), site.path().getFirst());
        MineBlueprint.Point previous = null;
        for (var at : site.path()) {
          assertTrue(at.z() < 76);
          assertTrue(
              plan.at(at.x(), at.h(), at.z()).equals("air")
                  || plan.at(at.x(), at.h(), at.z()).startsWith("rail[")
                  || plan.at(at.x(), at.h(), at.z()).startsWith("cave_vines"));
          if (previous != null)
            assertEquals(1, Math.abs(at.x() - previous.x()) + Math.abs(at.z() - previous.z()));
          previous = at;
        }
        assertEquals(
            1,
            Math.abs(site.ore().x() - site.stand().x())
                + Math.abs(site.ore().z() - site.stand().z()));
      }
      var caches = Expeditions.locations(plan);
      assertEquals(3, caches.size());
      for (int a = 0; a < 3; a++)
        for (int b = a + 1; b < 3; b++)
          assertTrue(
              Math.hypot(
                      caches.get(a).stand().x() - caches.get(b).stand().x(),
                      caches.get(a).stand().z() - caches.get(b).stand().z())
                  >= 6);
    }
  }
}
