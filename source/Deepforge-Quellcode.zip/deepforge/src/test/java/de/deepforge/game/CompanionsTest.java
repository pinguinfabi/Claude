package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class CompanionsTest {
  @Test
  void eggsAreVeryRareAndRarityFollowsTheOdds() {
    Random r = new Random(9);
    Profile p = new Profile();
    int found = 0;
    for (int i = 0; i < 10_000; i++)
      if (Companions.maybeDrop(p, Companions.CHAMPION, r, 0) != null) {
        found++;
        p.eggs.clear();
      }
    assertTrue(found > 60 && found < 140, "about 1 % from champions: " + found);
    for (int i = 0; i < 30; i++) Companions.maybeDrop(p, 1.1, r, 0);
    assertEquals(Companions.MAX_EGGS, p.eggs.size(), "the nest holds at most 20 eggs");
    Map<Gear.Rarity, Integer> counts = new EnumMap<>(Gear.Rarity.class);
    for (int i = 0; i < 100_000; i++) counts.merge(Companions.rollRarity(r), 1, Integer::sum);
    assertTrue(counts.get(Gear.Rarity.UNCOMMON) > 50_000);
    assertTrue(counts.get(Gear.Rarity.MYTHIC) < 1_000 && counts.get(Gear.Rarity.MYTHIC) > 200);
  }

  @Test
  void rarerEggsBroodLongerAndHatchIntoACompanion() {
    Profile p = new Profile();
    assertEquals(30, Companions.hatchMinutes(Gear.Rarity.UNCOMMON));
    assertEquals(720, Companions.hatchMinutes(Gear.Rarity.MYTHIC));
    Companions.Egg a = Companions.maybeDrop(p, 1.1, new Random(1), 0);
    Companions.Egg b = Companions.maybeDrop(p, 1.1, new Random(2), 0);
    Companions.Egg c = Companions.maybeDrop(p, 1.1, new Random(3), 0);
    a.rarity = Gear.Rarity.LEGENDARY;
    assertTrue(Companions.brood(p, a.id, 1000).contains("6 h"));
    Companions.brood(p, b.id, 1000);
    assertEquals("Beide Brutnester sind belegt.", Companions.brood(p, c.id, 1000));
    assertTrue(Companions.hatch(p, 0, 1000 + 60 * Companions.MINUTE).startsWith("Noch 5 h"));
    assertTrue(Companions.hatch(p, 0, 1000 + 360 * Companions.MINUTE).startsWith("Geschlüpft"));
    assertEquals(1, p.companions.size());
    assertEquals(Gear.Rarity.LEGENDARY, p.companions.getFirst().rarity);
    assertEquals(p.companions.getFirst().id, p.activeCompanion, "first companion follows right away");
    assertEquals(2, p.eggs.size());
  }

  @Test
  void companionsBoostStatsGrowByFeedingAndGiveDustWhenReleased() {
    Profile p = new Profile();
    Companions.Companion glut = new Companions.Companion();
    glut.species = Companions.Species.GLUTLING;
    glut.rarity = Gear.Rarity.EPIC;
    p.companions.add(glut);
    double base = Gear.stats(p).damage();
    Companions.activate(p, glut.id);
    assertEquals(base * (1 + .04 * 1.65), Gear.stats(p).damage(), 1e-9);
    p.monsterParts[0] = 100;
    p.money = 1_000_000;
    assertTrue(Companions.feed(p, glut.id).contains("Stufe 2"));
    assertEquals(96, p.monsterParts[0]);
    assertEquals(base * (1 + .04 * 1.65 * 1.1), Gear.stats(p).damage(), 1e-9);
    Companions.activate(p, glut.id);
    assertNull(p.activeCompanion);
    assertTrue(Companions.release(p, glut.id).contains("+60 Schmiedestaub"));
    assertTrue(p.companions.isEmpty());
  }
}
