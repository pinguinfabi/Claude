package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Locale;
import org.junit.jupiter.api.Test;

class EquipmentLoreTest {
  @Test
  void miningModesTradeYieldSpeedAndRelics() {
    Profile p = new Profile();
    ToolStats yield = ToolStats.of(p, 0, false);
    assertEquals(.35, yield.extraOre());
    assertEquals(5, yield.heatPerOre());
    p.module = 1;
    ToolStats speed = ToolStats.of(p, 0, false);
    assertEquals(yield.speed() * 1.35, speed.speed(), .00001);
    assertEquals(9, speed.heatPerOre());
    p.module = 2;
    assertEquals(.015, ToolStats.of(p, 0, false).relicChance());
  }

  @Test
  void deeperZonesSlowMiningAndOverloadDoublesActualSpeed() {
    Profile p = new Profile();
    double speed = ToolStats.of(p, 3, false).speed();
    assertEquals(speed * 2, ToolStats.of(p, 3, true).speed());
    assertTrue(speed < ToolStats.of(p, 0, false).speed());
    p.tool++;
    assertTrue(ToolStats.of(p, 3, false).speed() > speed);
  }

  @Test
  void tooltipUsesActualCombatStatsAndTracksUpgrades() {
    Profile p = new Profile();
    String old = String.join("\n", EquipmentLore.lines("sword", p, 0));
    assertTrue(
        old.contains(
            String.format(Locale.GERMAN, "Schaden: %.2f LP", RapidCombat.damage(Gear.stats(p)))));
    p.sword += 3;
    String upgraded = String.join("\n", EquipmentLore.lines("sword", p, 0));
    assertNotEquals(old, upgraded);
    assertTrue(upgraded.contains("Rückstoß:"));
    assertTrue(upgraded.contains("Fähigkeitsschaden:"));
  }

  @Test
  void toolTooltipDisplaysRealModeAndZoneValuesWithoutStaleBagContents() {
    Profile p = new Profile();
    p.module = 1;
    String text = String.join("\n", EquipmentLore.lines("tool", p, 3));
    assertTrue(
        text.contains(
            String.format(
                Locale.GERMAN, "Abbaumultiplikator: %.2f×", ToolStats.of(p, 3, false).speed())));
    assertTrue(text.contains("Modus: Tempo"));
    assertTrue(text.contains("Rucksackkapazität:"));
    assertTrue(text.contains("Hitze pro Erzblock: 9,00"));
  }
}
