package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import org.junit.jupiter.api.Test;

class LootSortTest {
  private static Gear.Item item(Gear.Slot slot, Gear.Rarity rarity, int level) {
    Gear.Item i = new Gear.Item();
    i.slot = slot;
    i.rarity = rarity;
    i.level = level;
    return i;
  }

  @Test
  void bagSortsByNewestKindOrRarity() {
    Profile p = new Profile();
    Gear.Item ring = item(Gear.Slot.RING, Gear.Rarity.MYTHIC, 0),
        sword = item(Gear.Slot.WEAPON, Gear.Rarity.UNCOMMON, 3),
        epicSword = item(Gear.Slot.WEAPON, Gear.Rarity.EPIC, 0),
        helmet = item(Gear.Slot.HELMET, Gear.Rarity.RARE, 5);
    p.gear.addAll(List.of(ring, sword, epicSword, helmet));
    assertEquals(List.of(helmet, epicSword, sword, ring), Gear.sorted(p), "newest first");
    p.lootSort = 1;
    assertEquals(List.of(epicSword, sword, helmet, ring), Gear.sorted(p), "by kind");
    p.lootSort = 2;
    assertEquals(List.of(ring, epicSword, helmet, sword), Gear.sorted(p), "by rarity");
    assertEquals(4, p.gear.size());
    assertSame(ring, p.gear.getFirst(), "sorting never reorders the saved bag");
  }
}
