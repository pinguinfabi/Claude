package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.UUID;
import org.junit.jupiter.api.*;

class GuildsTest {
  @BeforeEach
  void reset() {
    Guilds.clear();
  }

  private static Profile player(String name) {
    Profile p = new Profile();
    p.id = UUID.randomUUID().toString();
    p.name = name;
    p.money = 1_000_000;
    return p;
  }

  @Test
  void foundInviteJoinLeaveAndLeadershipPasses() {
    Profile a = player("Anna"), b = player("Ben"), c = player("Cem");
    assertTrue(Guilds.found(a, "Pinguin Minenbund", "ping", 0).contains("[PING]"));
    assertEquals(1_000_000 - Guilds.FOUND_COST, a.money);
    assertTrue(Guilds.found(b, "Andere", "PING", 0).contains("vergeben"));
    Guilds.Guild g = Guilds.of(a);
    assertTrue(Guilds.join(b, g).startsWith("Du hast keine Einladung"));
    Guilds.invite(g, a.id, b.id);
    assertTrue(Guilds.join(b, g).startsWith("Willkommen"));
    assertEquals("Nur Anführer und Offiziere können einladen.", Guilds.invite(g, b.id, c.id));
    Guilds.promote(g, a.id, b.id, true);
    assertEquals(Guilds.Rank.OFFIZIER, g.members.get(b.id));
    assertTrue(Guilds.leave(a).contains("Neue Leitung: Ben"));
    assertEquals(b.id, g.owner);
    assertNull(Guilds.of(a));
    assertTrue(Guilds.leave(b).contains("aufgelöst"));
    assertTrue(Guilds.all().isEmpty());
  }

  @Test
  void bankBuildsBuildingsThatBoostEveryMember() {
    Profile a = player("Anna"), b = player("Ben");
    Guilds.found(a, "Bund", "BND", 0);
    Guilds.Guild g = Guilds.of(a);
    Guilds.invite(g, a.id, b.id);
    Guilds.join(b, g);
    double before = Gear.stats(b).damage();
    assertTrue(Guilds.build(g, a.id, Guilds.Building.KASERNE).startsWith("Die Kasse braucht 20000"));
    Guilds.deposit(b, 100_000);
    assertEquals(100_000, g.bank);
    assertEquals(100_000, b.guildContributed);
    assertTrue(Guilds.build(g, b.id, Guilds.Building.KASERNE).startsWith("Nur Anführer"));
    assertTrue(Guilds.build(g, a.id, Guilds.Building.KASERNE).contains("Stufe 1"));
    assertEquals(before * 1.02, Gear.stats(b).damage(), 1e-9);
    assertTrue(Guilds.build(g, a.id, Guilds.Building.KASERNE).startsWith("Benötigt Gildenlevel 2"));
    Guilds.build(g, a.id, Guilds.Building.HALLE);
    assertEquals(7, Guilds.maxMembers(g));
  }

  @Test
  void weeklyTasksScaleWithMembersAndPayTheGuild() {
    Profile a = player("Anna");
    Guilds.found(a, "Bund", "BND", 0);
    Guilds.Guild g = Guilds.of(a);
    LocalDate monday = LocalDate.of(2026, 9, 28);
    Guilds.ensureWeek(g, monday);
    assertEquals(3, g.tasks.size());
    Guilds.Task first = Guilds.Task.valueOf(g.tasks.get(0));
    assertEquals(first.perMember, g.target[0]);
    assertEquals(0, Guilds.progress(g, first, first.perMember, monday));
    assertEquals(1, Guilds.level(g) == 1 ? 1 : 0);
    assertEquals(600, g.xp);
    assertEquals(10_000, g.bank);
    assertEquals(-1, Guilds.progress(g, first, 5, monday), "done tasks do not pay twice");
    assertFalse(Guilds.ensureWeek(g, monday.plusDays(3)));
    assertTrue(Guilds.ensureWeek(g, monday.plusDays(7)));
    assertFalse(g.done[0]);
  }
}
