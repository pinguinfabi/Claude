package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class EconomyDismissTest {
  @Test
  void dismissesExactlyTheChosenWorker() {
    Profile p = new Profile();
    Profile.Worker a = new Profile.Worker("Borin", Profile.Job.MINER, 0);
    Profile.Worker b = new Profile.Worker("Hilde", Profile.Job.SMELTER, 0);
    p.workers.add(a);
    p.workers.add(b);
    assertTrue(Economy.dismiss(p, a.id).startsWith("Borin wurde entlassen"));
    assertEquals(1, p.workers.size());
    assertSame(b, p.workers.getFirst());
    assertEquals("Arbeiter nicht gefunden.", Economy.dismiss(p, a.id), "a second click does nothing");
  }
}
