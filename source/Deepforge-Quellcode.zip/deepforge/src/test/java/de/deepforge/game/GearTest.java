package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class GearTest {
  private Random fixed(int rarity) {
    return new Random(7) {
      @Override
      public int nextInt(int bound) {
        return bound == 10000 ? rarity : 0;
      }

      @Override
      public double nextDouble() {
        return .99;
      }
    };
  }

  @Test
  void rarityBoundariesAndGuaranteedEquipment() {
    int[] rolls = {0, 5999, 6000, 8999, 9000, 9899, 9900, 9999};
    Gear.Rarity[] rarities = {
      Gear.Rarity.UNCOMMON,
      Gear.Rarity.UNCOMMON,
      Gear.Rarity.RARE,
      Gear.Rarity.RARE,
      Gear.Rarity.EPIC,
      Gear.Rarity.EPIC,
      Gear.Rarity.LEGENDARY,
      Gear.Rarity.LEGENDARY
    };
    for (int n = 0; n < rolls.length; n++) {
      Profile p = new Profile();
      var loot = Gear.bossLoot(p, "fight", 0, 0, fixed(rolls[n]));
      assertEquals(1, loot.size());
      assertEquals(rarities[n], loot.getFirst().rarity);
      assertEquals(2, p.bossTokens[0]);
      assertEquals(1, p.bossWins[0]);
      assertEquals(750, p.money);
    }
  }

  @Test
  void tenthDryKillGuaranteesEpicAndResetsPity() {
    Profile p = new Profile();
    for (int n = 0; n < 9; n++)
      assertEquals(
          Gear.Rarity.UNCOMMON, Gear.bossLoot(p, "f" + n, 0, 0, fixed(0)).getFirst().rarity);
    assertEquals(9, p.dryStreak[0]);
    assertEquals(Gear.Rarity.EPIC, Gear.bossLoot(p, "tenth", 0, 0, fixed(0)).getFirst().rarity);
    assertEquals(0, p.dryStreak[0]);
    assertEquals(0, p.dryStreak[1]);
  }

  @Test
  void sameFightCannotRewardTwice() {
    Profile p = new Profile();
    Gear.bossLoot(p, "fight", 3, 2, fixed(0));
    long money = p.money;
    assertTrue(Gear.bossLoot(p, "fight", 3, 2, fixed(9999)).isEmpty());
    assertEquals(money, p.money);
    assertEquals(1, p.gear.size());
    assertEquals(4, p.bossTokens[3]);
    assertEquals(1, p.kills);
  }

  @Test
  void mythicOnlyDropsOnNightmare() {
    Random drops =
        new Random(1) {
          @Override
          public double nextDouble() {
            return 0;
          }
        };
    Profile p = new Profile();
    var normal = Gear.bossLoot(p, "normal", 0, 0, drops);
    assertEquals(3, normal.size());
    assertEquals(1, normal.stream().filter(i -> i.archetype >= 0).count());
    assertTrue(normal.stream().noneMatch(i -> i.rarity == Gear.Rarity.MYTHIC));
    var nightmare = Gear.bossLoot(p, "nightmare", 0, 2, drops);
    assertEquals(4, nightmare.size());
    assertEquals(1, nightmare.stream().filter(i -> i.rarity == Gear.Rarity.MYTHIC).count());
  }

  @Test
  void favoriteAndEquippedItemsCannotBeSoldOrSalvaged() {
    Profile p = new Profile();
    Gear.Item item = Gear.roll(0, Gear.Rarity.EPIC, new Random(1));
    p.gear.add(item);
    item.favorite = true;
    Gear.sell(p, item.id, false);
    assertEquals(1, p.gear.size());
    assertEquals(250, p.money);
    item.favorite = false;
    Gear.equip(p, item.id);
    Gear.sell(p, item.id, true);
    assertEquals(1, p.gear.size());
    assertEquals(0, p.dust);
    Gear.equip(p, item.id);
    Gear.sell(p, item.id, true);
    assertTrue(p.gear.isEmpty());
    assertEquals(5, p.dust);
    Gear.sell(p, item.id, true);
    assertEquals(5, p.dust);
  }

  @Test
  void upgradesAreAtomicAndCapped() {
    Profile p = new Profile();
    Gear.Item item = Gear.roll(0, Gear.Rarity.RARE, new Random(2));
    p.gear.add(item);
    Gear.upgrade(p, item.id);
    assertEquals(250, p.money);
    assertEquals(0, item.level);
    p.dust = 2;
    Gear.upgrade(p, item.id);
    assertEquals(0, p.money);
    assertEquals(0, p.dust);
    assertEquals(1, item.level);
    p.money = 100000;
    p.dust = 1000;
    item.level = 10;
    Gear.upgrade(p, item.id);
    assertEquals(100000, p.money);
    assertEquals(1000, p.dust);
  }

  @Test
  void craftingHasNoPartialDeductionAndProducesCorrectUnique() {
    Profile p = new Profile();
    p.zone = 3;
    p.bossTokens[3] = 40;
    p.monsterParts[3] = 29;
    p.money = Gear.craftCost(3);
    Gear.craft(p, 3);
    assertEquals(40, p.bossTokens[3]);
    assertEquals(Gear.craftCost(3), p.money);
    assertTrue(p.gear.isEmpty());
    p.monsterParts[3] = 30;
    Gear.craft(p, 3);
    assertEquals(0, p.money);
    assertEquals(0, p.bossTokens[3]);
    assertEquals(0, p.monsterParts[3]);
    assertEquals("Gezeitenspeer", p.gear.getFirst().name);
    assertEquals(Gear.Slot.WEAPON, p.gear.getFirst().slot);
    assertEquals(3, p.gear.getFirst().signature);
    Gear.craft(p, 7);
    assertEquals(1, p.gear.size());
  }

  @Test
  void rerollChangesOnlyCritAndPayment() {
    Profile p = new Profile();
    var item = Gear.unique(0, Gear.Rarity.LEGENDARY, new Random(4));
    p.gear.add(item);
    p.money = 500;
    p.dust = 5;
    double damage = item.damage, health = item.health;
    String id = item.id;
    Gear.reroll(p, id, fixed(0));
    assertEquals(damage, item.damage);
    assertEquals(health, item.health);
    assertEquals(id, item.id);
    assertEquals(0, item.signature);
    // Legendary 4–12 %, quality 95 => 3,8–11,4 %; roll .99 lands near the top.
    assertEquals(.038 + .99 * (.114 - .038), item.crit, 1e-9);
    assertEquals(0, p.money);
    assertEquals(0, p.dust);
  }

  @Test
  void independentRingsAndOriginSetBonus() {
    Profile p = new Profile();
    for (Gear.Slot slot :
        List.of(Gear.Slot.RING, Gear.Slot.RING2, Gear.Slot.HELMET, Gear.Slot.BOOTS)) {
      Gear.Item item = new Gear.Item();
      item.name = "Test";
      item.slot = slot;
      p.gear.add(item);
      Gear.equip(p, item.id);
    }
    assertEquals(4, p.equipped.size());
    var stats = Gear.stats(p);
    assertEquals(9, stats.damage());
    assertEquals(22, stats.health());
    assertEquals(6, stats.defense());
  }

  @Test
  void statCapsAndUniqueEffectsRequireEquipping() {
    Profile p = new Profile();
    p.zone = 6;
    var item = Gear.unique(1, Gear.Rarity.LEGENDARY, new Random(5));
    p.gear.add(item);
    assertFalse(Gear.hasEffect(p, 1));
    item.health = 1000;
    item.defense = 1000;
    item.haste = 100;
    item.crit = 100;
    item.critDamage = 0;
    item.mining = 100;
    item.yield = 100;
    item.efficiency = 100;
    Gear.equip(p, item.id);
    var s = Gear.stats(p);
    assertTrue(Gear.hasEffect(p, 1));
    // Crit above 100 % (every hit crits) turns into crit damage, at most +100 %.
    assertEquals(3.1, s.critDamage(), 1e-9);
    assertEquals(60, s.health());
    assertEquals(.6, s.reduction());
    assertEquals(1.0, s.crit());
    assertEquals(3.2, s.speed());
    assertEquals(.65, s.mining());
    assertEquals(.5, s.yield());
    assertEquals(.5, s.efficiency());
  }

  @Test
  void futureZoneEquipmentCannotBeEquipped() {
    Profile p = new Profile();
    Gear.Item item = Gear.roll(4, Gear.Rarity.MYTHIC, new Random(6));
    p.gear.add(item);
    Gear.equip(p, item.id);
    assertTrue(p.equipped.isEmpty());
  }
}
