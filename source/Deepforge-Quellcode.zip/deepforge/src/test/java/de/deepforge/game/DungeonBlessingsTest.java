package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.UUID;
import org.junit.jupiter.api.Test;

class DungeonBlessingsTest {
  @Test
  void choiceIsPersonalOncePerHallAndDoesNotSurviveAnotherRun() {
    UUID a = UUID.randomUUID(), b = UUID.randomUUID();
    DungeonBlessings run = new DungeonBlessings();
    assertTrue(run.choose(a, 0, 0));
    assertFalse(run.choose(a, 0, 1));
    assertTrue(run.choose(b, 0, 1));
    assertEquals(1.08, run.damage(a), .0001);
    assertEquals(1, run.incoming(a));
    assertEquals(.92, run.incoming(b), .0001);
    assertEquals(1, new DungeonBlessings().damage(a));
  }

  @Test
  void twoChoicesStayBoundedAndHealingCannotBeReclaimed() {
    UUID id = UUID.randomUUID();
    DungeonBlessings run = new DungeonBlessings();
    assertFalse(run.choose(id, 2, 0));
    assertFalse(run.choose(id, 0, 3));
    assertTrue(run.choose(id, 0, 0));
    assertTrue(run.choose(id, 1, 0));
    assertEquals(1.16, run.damage(id), .0001);
    DungeonBlessings healing = new DungeonBlessings();
    assertTrue(healing.choose(id, 0, 2));
    assertFalse(healing.choose(id, 0, 2));
    assertEquals(1, healing.damage(id));
  }
}
