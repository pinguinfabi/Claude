package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.UUID;
import org.junit.jupiter.api.Test;

class DungeonBlessingsTest {
  @Test
  void choiceIsPersonalOncePerHallAndDoesNotSurviveAnotherRun() {
    UUID a = UUID.randomUUID(), b = UUID.randomUUID();
    DungeonBlessings run = new DungeonBlessings();
    assertTrue(run.choose(a, 0, 0));
    assertFalse(run.choose(a, 0, 1));
    assertTrue(run.chosen(a, 0));
    assertTrue(run.choose(b, 0, 1));
    assertEquals(1.08, run.damage(a), .0001);
    assertEquals(1, run.incoming(a));
    assertEquals(.92, run.incoming(b), .0001);
    assertEquals(1, new DungeonBlessings().damage(a));
  }

  @Test
  void everyRoomOfAGeneratedDungeonOffersABlessingWithBoundedStacking() {
    UUID id = UUID.randomUUID();
    DungeonBlessings run = new DungeonBlessings();
    assertFalse(run.choose(id, 0, 3));
    assertFalse(run.choose(id, -1, 0));
    for (int room = 1; room <= 7; room++) assertTrue(run.choose(id, room, 0), "room " + room);
    assertEquals(1.24, run.damage(id), .0001);
    DungeonBlessings healing = new DungeonBlessings();
    assertTrue(healing.choose(id, 5, 2));
    assertFalse(healing.choose(id, 5, 2));
    assertEquals(1, healing.damage(id));
  }
}
