package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.random.RandomGenerator;
import org.junit.jupiter.api.Test;

class GearPresetsTest {
  private static Gear.Item item(Profile p, Gear.Slot slot) {
    Gear.Item i = new Gear.Item();
    i.slot = slot;
    i.name = slot.name();
    p.gear.add(i);
    return i;
  }

  @Test
  void savesAndSwapsWholeLoadouts() {
    Profile p = new Profile();
    Gear.Item sword = item(p, Gear.Slot.WEAPON), helmet = item(p, Gear.Slot.HELMET);
    Gear.Item drill = item(p, Gear.Slot.TOOL);
    p.equipped.put("WEAPON", sword.id);
    p.equipped.put("HELMET", helmet.id);
    GearPresets.save(p, 0);
    assertEquals(0, GearPresets.active(p));
    p.equipped.clear();
    p.equipped.put("TOOL", drill.id);
    GearPresets.save(p, 1);
    assertEquals(1, GearPresets.active(p));
    GearPresets.apply(p, 0);
    assertEquals(2, p.equipped.size());
    assertEquals(sword.id, p.equipped.get("WEAPON"));
    assertNull(p.equipped.get("TOOL"));
    assertEquals(0, GearPresets.active(p));
  }

  @Test
  void presetItemsAreProtectedAndMissingOnesAreReported() {
    Profile p = new Profile();
    Gear.Item sword = item(p, Gear.Slot.WEAPON), ring = item(p, Gear.Slot.RING);
    p.equipped.put("WEAPON", sword.id);
    p.equipped.put("RING", ring.id);
    GearPresets.save(p, 2);
    p.equipped.clear();
    assertTrue(Gear.sell(p, sword.id, false).startsWith("Teil des Sets"));
    assertEquals(2, p.gear.size());
    p.gear.remove(ring);
    String msg = GearPresets.apply(p, 2);
    assertTrue(msg.contains("1 fehlen"), msg);
    assertEquals(1, p.equipped.size());
  }

  @Test
  void namesAreCleanedAndFoundByNumberOrName() {
    Profile p = new Profile();
    Gear.Item sword = item(p, Gear.Slot.WEAPON);
    p.equipped.put("WEAPON", sword.id);
    GearPresets.save(p, 0);
    GearPresets.save(p, 3);
    GearPresets.rename(p, 1, "  Bossjagd<§c>!!  ");
    assertEquals("Bossjagdc", GearPresets.of(p).get(1).name);
    assertEquals(1, GearPresets.find(p, "BOSSJAGDC"));
    assertEquals(2, GearPresets.find(p, "3"));
    assertEquals(-1, GearPresets.find(p, "9"));
    assertTrue(GearPresets.apply(p, 2).contains("leer"));
  }

  @Test
  void setForgeNeverEatsPresetPieces() {
    Profile p = new Profile();
    RandomGenerator r = new java.util.Random(4);
    for (int n = 0; n < 3; n++) {
      Gear.Item i = AdventureGear.shapeSetPiece(Gear.roll(1, Gear.Rarity.RARE, r), 0, Gear.Slot.HELMET, 1);
      p.gear.add(i);
    }
    assertEquals(2, AdventureGear.spares(p).size());
    p.equipped.put("HELMET", AdventureGear.spares(p).get(0).id);
    GearPresets.save(p, 0);
    p.equipped.clear();
    assertEquals(1, AdventureGear.spares(p).size());
  }
}
