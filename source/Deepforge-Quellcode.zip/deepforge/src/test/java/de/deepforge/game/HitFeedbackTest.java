package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class HitFeedbackTest {
  @Test
  void damageNumbersShowHealthLostNotOverkill() {
    assertEquals(4, HitFeedback.applied(4, 800));
    assertEquals(3.5, HitFeedback.applied(10, 3.5));
    assertEquals(0, HitFeedback.applied(-2, 10));
    assertEquals(0, HitFeedback.applied(10, -2));
  }

  @Test
  void heavyWeaponsPushHarderAndBossesResistUntilStaggered() {
    assertTrue(
        HitFeedback.knockback("hammer", false, false)
            > HitFeedback.knockback("sword", false, false));
    for (String style : new String[] {"sword", "hammer", "dagger", "spear", "crossbow"}) {
      double normal = HitFeedback.knockback(style, false, false),
          boss = HitFeedback.knockback(style, true, false),
          broken = HitFeedback.knockback(style, true, true);
      assertTrue(boss > 0 && boss < broken && broken < normal);
    }
  }

  @Test
  void labelsDistinguishCriticalRearAndGuardedHits() {
    assertEquals("−12,5 ✦ KRIT RÜCKEN", HitFeedback.text(12.5, true, true, false));
    assertEquals("−3,0 BLOCK", HitFeedback.text(3, false, false, true));
    assertEquals("−7,0", HitFeedback.text(7, false, false, false));
  }
}
