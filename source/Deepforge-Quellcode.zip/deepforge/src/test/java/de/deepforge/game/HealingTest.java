package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class HealingTest {
  @Test
  void restoresHealthOnceAndDoesNotConsumeOnFullHealthOrCooldown() {
    Profile p = new Profile();
    p.healingCharges = 4;
    assertEquals(0, Healing.consume(p, 20, 20, 1));
    assertEquals(4, p.healingCharges);
    assertEquals(11, Healing.consume(p, 3, 20, 1));
    assertEquals(3, p.healingCharges);
    assertEquals(0, Healing.consume(p, 3, 20, 20_000));
    assertEquals(3, p.healingCharges);
    assertEquals(2, Healing.consume(p, 18, 20, 20_001));
    assertEquals(2, p.healingCharges);
  }

  @Test
  void scaledHealingNeverRevivesTheDeadOrExceedsMaximum() {
    Profile p = new Profile();
    p.healingCharges = 3;
    assertEquals(0, Healing.consume(p, 0, 100, 0));
    assertEquals(3, p.healingCharges);
    assertEquals(39, Healing.consume(p, 10, 100, 0));
    assertEquals(1, Healing.consume(p, 99, 100, 20_000));
    assertEquals(0, Healing.consume(p, Double.NaN, 100, 50_000));
  }

  @Test
  void inventoryCapAndEmptyStockAreAuthoritative() {
    Profile p = new Profile();
    p.healStock = 9;
    p.healingCharges = 11;
    assertEquals(1, Healing.grant(p, 5));
    assertEquals(12, p.healingCharges);
    assertEquals(0, Healing.grant(p, 1));
    p.healingCharges = 0;
    assertEquals(0, Healing.consume(p, 2, 20, 100));
    assertEquals(0, p.healingReadyAt);
  }

  @Test
  void quickBuyIsCappedBySpaceAndMoneyAndUsesTheRescueDiscount() {
    Profile p = new Profile();
    p.healStock = 9;
    p.healingCharges = 9;
    p.money = 10_000;
    assertEquals(3, Healing.buy(p, Healing.CAPACITY));
    assertEquals(12, p.healingCharges);
    assertEquals(10_000 - 3 * 250, p.money);
    assertEquals(0, Healing.buy(p, 1));
    p.healingCharges = 0;
    p.money = 620;
    assertEquals(2, Healing.buy(p, 5));
    assertEquals(120, p.money);
    assertEquals(0, Healing.buy(p, 1));
    assertEquals(0, Healing.buy(p, -3));
    p.adventureRescues = 1;
    p.money = 400;
    assertEquals(200, Healing.price(p));
    assertEquals(2, Healing.buy(p, 12));
    assertEquals(0, p.money);
    assertEquals(4, p.healingCharges);
  }

  @Test
  void stockStartsAtThreeAndGrowsWithTheHeiltascheUpgradeToTwelve() {
    Profile p = new Profile();
    p.healingCharges = 0;
    assertEquals(3, Healing.capacity(p));
    assertEquals(3, Healing.grant(p, 10));
    p.money = 1_000_000;
    for (int level = 0; level < 9; level++)
      assertTrue(Economy.buy(p, "potion").startsWith("Verbessert"), "level " + level);
    assertEquals("Maximale Stufe erreicht.", Economy.buy(p, "potion"));
    assertEquals(12, Healing.capacity(p));
    assertEquals(9, Healing.grant(p, 20));
    // Old saves above the new limit keep their shards but gain none until below it.
    Profile old = new Profile();
    old.healingCharges = 12;
    assertEquals(0, Healing.grant(old, 2));
    assertEquals(12, old.healingCharges);
  }
}
