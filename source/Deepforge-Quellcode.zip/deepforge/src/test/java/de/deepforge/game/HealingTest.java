package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class HealingTest {
  @Test
  void restoresHealthOnceAndDoesNotConsumeOnFullHealthOrCooldown() {
    Profile p = new Profile();
    p.healingCharges = 4;
    assertEquals(0, Healing.consume(p, 20, 20, 1));
    assertEquals(4, p.healingCharges);
    assertEquals(11, Healing.consume(p, 3, 20, 1));
    assertEquals(3, p.healingCharges);
    assertEquals(0, Healing.consume(p, 3, 20, 20_000));
    assertEquals(3, p.healingCharges);
    assertEquals(2, Healing.consume(p, 18, 20, 20_001));
    assertEquals(2, p.healingCharges);
  }

  @Test
  void scaledHealingNeverRevivesTheDeadOrExceedsMaximum() {
    Profile p = new Profile();
    p.healingCharges = 3;
    assertEquals(0, Healing.consume(p, 0, 100, 0));
    assertEquals(3, p.healingCharges);
    assertEquals(39, Healing.consume(p, 10, 100, 0));
    assertEquals(1, Healing.consume(p, 99, 100, 20_000));
    assertEquals(0, Healing.consume(p, Double.NaN, 100, 50_000));
  }

  @Test
  void inventoryCapAndEmptyStockAreAuthoritative() {
    Profile p = new Profile();
    p.healingCharges = 11;
    assertEquals(1, Healing.grant(p, 5));
    assertEquals(12, p.healingCharges);
    assertEquals(0, Healing.grant(p, 1));
    p.healingCharges = 0;
    assertEquals(0, Healing.consume(p, 2, 20, 100));
    assertEquals(0, p.healingReadyAt);
  }
}
