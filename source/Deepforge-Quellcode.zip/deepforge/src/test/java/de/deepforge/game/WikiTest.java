package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class WikiTest {
  @Test
  void everyPageIsReachableAndHasContent() {
    assertEquals("Deepforge-Wiki", Wiki.page("home").title());
    assertTrue(Wiki.page("home").children().size() >= 15);
    for (Wiki.Page p : Wiki.all()) {
      assertFalse(p.entries().isEmpty() && p.children().isEmpty(), p.id());
      if (p.parent() != null) assertTrue(Wiki.page(p.parent()).children().contains(p.id()), p.id());
      for (String child : p.children()) assertEquals(child, Wiki.page(child).id());
      for (Wiki.Entry e : p.entries()) assertFalse(e.lines().isEmpty(), p.id() + " " + e.title());
    }
    for (int z = 0; z < Zone.COUNT; z++) assertEquals("mine/" + z, Wiki.page("mine/" + z).id());
    assertEquals("home", Wiki.page("gibt-es-nicht").id(), "unknown pages fall back to the start");
  }

  @Test
  void numbersComeFromTheRules() {
    String eggs = String.join(" ", Wiki.page("pets").entries().getFirst().lines());
    assertTrue(eggs.contains("3 %") && eggs.contains("1,5 %"), eggs);
    String runes = String.join(" ", Wiki.page("runes").entries().getLast().lines());
    assertTrue(Wiki.page("runes").entries().stream().anyMatch(e -> String.join(" ", e.lines()).contains("0,3 %")));
    assertNotNull(runes);
  }
}
