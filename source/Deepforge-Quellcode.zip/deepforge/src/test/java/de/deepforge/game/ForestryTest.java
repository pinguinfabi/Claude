package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ForestryTest {
  @Test
  void luckLevelsHaveExactMeanMultipliersAndStackWithExistingYield() {
    Profile p = new Profile();
    for (int level = 0; level <= 10; level++) {
      p.oreLuck = level;
      double total = 0;
      for (int a = 0; a < 100; a++)
        for (int b = 0; b < 100; b++)
          total += OreYield.roll(p, .35, (a + .5) / 100, (b + .5) / 100);
      assertEquals(1.35 * (1 + level * .1), total / 10000, .00001);
      assertEquals(1 + level * .1, OreYield.multiplier(level), .00001);
    }
    p.oreLuck = 10;
    assertEquals(4, OreYield.roll(p, .35, 0, 0));
    assertEquals(2, OreYield.roll(p, .35, .8, .8));
  }

  @Test
  void luckUpgradeHasDisplayedPriceAndCannotExceedCap() {
    Profile p = new Profile();
    assertEquals(500, Economy.upgradeCost(p, "oreLuck"));
    Economy.buy(p, "oreLuck");
    assertEquals(0, p.oreLuck);
    assertEquals(250, p.money);
    p.money = 1000000;
    for (int n = 0; n < 10; n++) {
      long cost = Economy.upgradeCost(p, "oreLuck"), old = p.money;
      Economy.buy(p, "oreLuck");
      assertEquals(old - cost, p.money);
    }
    long old = p.money;
    Economy.buy(p, "oreLuck");
    assertEquals(old, p.money);
    assertEquals(10, p.oreLuck);
  }

  @Test
  void woodHarvestRequiresUnlockAndSpaceAndDoublesWholeTree() {
    Profile p = new Profile();
    assertEquals(0, Forestry.harvest(p, 1, 0, 0));
    assertEquals(0, p.resin);
    p.woodLuck = 2;
    assertEquals(12, Forestry.harvest(p, 0, .19, .01));
    assertEquals(1, p.resin);
    assertEquals(12, p.woodChopped);
    assertEquals(6, Forestry.harvest(p, 0, .2, .9));
    p.wood[0] = Forestry.capacity(p) - 5;
    long old = p.woodChopped;
    assertEquals(0, Forestry.harvest(p, 0, 0, 0));
    assertEquals(old, p.woodChopped);
    assertEquals(1, p.resin);
  }

  @Test
  void sawUsesFuelAndCapacityWithoutLosingWood() {
    Profile p = new Profile();
    p.wood[0] = 20;
    Forestry.saw(p, 0);
    assertEquals(20, p.wood[0]);
    p.fuel = 10;
    p.sawmill = 3;
    Forestry.saw(p, 0);
    assertEquals(10, p.wood[0]);
    assertEquals(50, p.planks[0]);
    assertEquals(0, p.fuel);
    p.fuel = 10;
    p.planks[0] = 389;
    Forestry.saw(p, 0);
    assertEquals(10, p.wood[0]);
    assertEquals(389, p.planks[0]);
  }

  @Test
  void forestrySalesDoNotConsumeOreAndContractsCannotReplay() {
    Profile p = new Profile();
    p.bag[0] = 50;
    p.wood[0] = 24;
    Forestry.contract(p, 0);
    assertEquals(466, p.money);
    assertEquals(1, p.woodOrders);
    p.wood[0] = 24;
    Forestry.contract(p, 0);
    assertEquals(24, p.wood[0]);
    assertEquals(466, p.money);
    p.planks[0] = 5;
    assertEquals(164, Forestry.sell(p));
    assertEquals(50, p.bag[0]);
    assertEquals(0, Forestry.used(p));
    assertEquals(0, Forestry.sell(p));
  }

  @Test
  void groveAndAxeUnlocksCannotPartiallyCharge() {
    Profile p = new Profile();
    p.money = 5000;
    Forestry.unlock(p);
    assertEquals(5000, p.money);
    p.axe = 2;
    p.woodChopped = 64;
    Forestry.unlock(p);
    assertEquals(1, p.forestTier);
    assertEquals(4000, p.money);
    p.axe = 5;
    p.money = 100000;
    Forestry.upgrade(p, "axe");
    assertEquals(5, p.axe);
    assertEquals(100000, p.money);
    p.resin = 1;
    Forestry.upgrade(p, "axe");
    assertEquals(6, p.axe);
    assertEquals(0, p.resin);
    assertEquals(91000, p.money);
  }

  @Test
  void charcoalIsAtomicAcrossWoodTypes() {
    Profile p = new Profile();
    p.wood[0] = 4;
    p.wood[1] = 5;
    Forestry.charcoal(p);
    assertEquals(9, Forestry.used(p));
    assertEquals(0, p.fuel);
    p.wood[2] = 4;
    Forestry.charcoal(p);
    assertEquals(3, Forestry.used(p));
    assertEquals(20, p.fuel);
  }
}
