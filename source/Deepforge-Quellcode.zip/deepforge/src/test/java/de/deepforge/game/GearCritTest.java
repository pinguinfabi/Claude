package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Random;
import org.junit.jupiter.api.Test;

class GearCritTest {
  private static Gear.Item weapon(String style, Gear.Rarity rarity) {
    Gear.Item i = new Gear.Item();
    i.style = style;
    i.rarity = rarity;
    i.quality = 100;
    return i;
  }

  @Test
  void critDamageDependsOnWeaponTypeAndRoll() {
    assertEquals(2.0, Gear.baseCritDamage(weapon("dagger", Gear.Rarity.RARE)));
    assertEquals(1.5, Gear.baseCritDamage(weapon("hammer", Gear.Rarity.RARE)));
    assertEquals(1.75, Gear.baseCritDamage(null));
    Profile p = new Profile();
    Gear.Item dagger = weapon("dagger", Gear.Rarity.MYTHIC);
    dagger.critDamage = .40;
    dagger.crit = .20;
    p.gear.add(dagger);
    Gear.equip(p, dagger.id);
    assertEquals(2.4, Gear.stats(p).critDamage(), 1e-9);
    // Crit chance is no longer capped at 50 %.
    dagger.crit = .70;
    assertEquals(.75, Gear.stats(p).crit(), 1e-9);
  }

  @Test
  void rolledWeaponsGetCritDamageInTheirRange() {
    Random r = new Random(3);
    for (int n = 0; n < 200; n++) {
      Gear.Item i = Gear.roll(3, Gear.Rarity.EPIC, r);
      if (i.slot != Gear.Slot.WEAPON) continue;
      double[] range = Gear.critDamageRange(i);
      assertTrue(i.critDamage >= range[0] - 1e-9, "at least the minimum");
    }
  }

  @Test
  void oldWeaponsGetTheMiddleOfTheirRangeOnceAndCanBeRerolled() {
    Profile p = new Profile();
    Gear.Item old = weapon("spear", Gear.Rarity.LEGENDARY);
    p.gear.add(old);
    Gear.migrate(p);
    double[] range = Gear.critDamageRange(old);
    assertEquals((range[0] + range[1]) / 2, old.critDamage, 1e-9);
    Gear.migrate(p);
    assertEquals((range[0] + range[1]) / 2, old.critDamage, 1e-9, "only once");
    p.money = 10_000;
    p.dust = 10;
    assertTrue(Gear.rerollCritDamage(p, old.id, new Random(1)).startsWith("Krit-Schaden neu geschmiedet"));
    assertTrue(old.critDamage >= range[0] && old.critDamage <= range[1]);
    assertEquals(5, p.dust);
  }
}
