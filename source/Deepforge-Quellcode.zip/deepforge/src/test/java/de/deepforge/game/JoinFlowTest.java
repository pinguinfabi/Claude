package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class JoinFlowTest {
  @Test
  void firstJoinAndReturnFromAnotherWorldEnterAutomatically() {
    assertEquals(JoinFlow.Route.START, JoinFlow.route(true, false, false, false, true));
    assertEquals(JoinFlow.Route.START, JoinFlow.route(true, false, true, false, true));
  }

  @Test
  void existingSessionResumesWithoutStartingTwice() {
    assertEquals(JoinFlow.Route.RESUME, JoinFlow.route(true, false, true, true, true));
    assertEquals(JoinFlow.Route.NONE, JoinFlow.route(true, true, true, true, true));
  }

  @Test
  void permissionAndOptionalManualModeAreRespected() {
    assertEquals(JoinFlow.Route.NONE, JoinFlow.route(false, false, false, false, true));
    assertEquals(JoinFlow.Route.NONE, JoinFlow.route(true, false, false, false, false));
    assertEquals(JoinFlow.Route.RESUME, JoinFlow.route(true, false, true, true, false));
  }
}
