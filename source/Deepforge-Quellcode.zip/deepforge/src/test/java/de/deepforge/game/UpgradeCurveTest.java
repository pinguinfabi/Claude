package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class UpgradeCurveTest {
  @Test
  void everyDrillLevelIsClearlyFasterAndRunsCooler() {
    Profile p = new Profile();
    double previous = ToolStats.of(p, 0, false).speed(), heat = ToolStats.of(p, 0, false).heatPerOre();
    for (int level = 1; level <= 20; level++) {
      p.tool = level;
      ToolStats t = ToolStats.of(p, 0, false);
      assertTrue(t.speed() >= previous * 1.11, "level " + level);
      assertTrue(t.heatPerOre() < heat);
      previous = t.speed();
      heat = t.heatPerOre();
    }
    p.tool = 10;
    assertTrue(ToolStats.of(p, 0, false).speed() > 3 * ToolStats.drillPower(0) - .01);
  }

  @Test
  void eachMineFeelsTheSameAtItsRequiredDrillLevel() {
    Profile p = new Profile();
    for (Zone z : Zone.values()) {
      p.tool = z.toolRequired;
      double seconds = ToolStats.seconds(ToolStats.of(p, z.ordinal(), false).speed());
      assertTrue(seconds <= 2.3 && seconds >= 1.2, z + " " + seconds);
    }
  }

  @Test
  void bladeTrainingScalesAllMeleeDamage() {
    Profile p = new Profile();
    double base = Gear.stats(p).damage();
    p.sword = 5;
    assertTrue(Gear.stats(p).damage() >= base * 1.2 + 3.4);
    p.sword = 20;
    assertEquals((6 + 14) * 1.8, Gear.stats(p).damage(), 1e-9);
    assertEquals(1.8, Gear.swordMultiplier(40), 1e-9);
  }
}
