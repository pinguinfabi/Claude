package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BossPressureTest {
  @Test
  void rearSpamQueuesCounterWithFullWarningAndCannotExtendIt() {
    BossPressure p = new BossPressure();
    for (int t = 0; t < 3; t++) p.hit(t, -1, 4);
    assertEquals(BossPressure.Step.NONE, p.step(2, false));
    assertEquals(BossPressure.Step.START, p.step(10, true));
    for (int t = 11; t < 38; t++) {
      p.hit(t, -1, 4);
      assertEquals(BossPressure.Step.WARNING, p.step(t, false));
    }
    assertEquals(BossPressure.Step.STRIKE, p.step(38, false));
    assertEquals(BossPressure.Step.NONE, p.step(39, true));
    for (int t = 40; t < 178; t++) p.hit(t, -1, 4);
    assertEquals(BossPressure.Step.NONE, p.step(178, true));
    for (int t = 178; t < 181; t++) p.hit(t, -1, 4);
    assertEquals(BossPressure.Step.START, p.step(180, true));
  }

  @Test
  void frontalRangedAndOldHitsDoNotProvokeCounter() {
    BossPressure p = new BossPressure();
    for (int t = 0; t < 20; t++) {
      p.hit(t, 1, 4);
      p.hit(t, -1, 100);
    }
    assertEquals(BossPressure.Step.NONE, p.step(20, true));
    p.hit(21, -1, 4);
    p.hit(22, -1, 4);
    p.hit(90, -1, 4);
    assertEquals(BossPressure.Step.NONE, p.step(90, true));
    p.hit(91, -1, 4);
    p.hit(92, -1, 4);
    assertEquals(BossPressure.Step.NONE, p.step(153, true));
  }

  @Test
  void sweepCoversRearAndJumpingButHasAnEscapeBoundary() {
    assertTrue(BossPressure.inSweep(0, 0, -4));
    assertTrue(BossPressure.inSweep(0, 1.3, -4));
    assertTrue(BossPressure.inSweep(4.5, 0, 0));
    assertFalse(BossPressure.inSweep(4.51, 0, 0));
    assertFalse(BossPressure.inSweep(0, 3.1, 0));
  }
}
