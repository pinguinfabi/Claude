package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.junit.jupiter.api.Test;

class MonsterHealthTest {
  @Test
  void barTracksHealthAndHealingWithReadableThresholds() {
    assertEquals(12, MonsterHealth.filled(100, 100));
    assertEquals(6, MonsterHealth.filled(50, 100));
    assertEquals(3, MonsterHealth.filled(25, 100));
    assertEquals(1, MonsterHealth.filled(.01, 100));
    assertEquals(0, MonsterHealth.filled(0, 100));
    assertEquals(NamedTextColor.GREEN, MonsterHealth.color(51, 100));
    assertEquals(NamedTextColor.YELLOW, MonsterHealth.color(50, 100));
    assertEquals(NamedTextColor.RED, MonsterHealth.color(25, 100));
    assertEquals(NamedTextColor.GREEN, MonsterHealth.color(70, 100));
  }

  @Test
  void textUsesRealMaximumAndKeepsFractionalSurvivorsAboveZero() {
    String text =
        PlainTextComponentSerializer.plainText()
            .serialize(MonsterHealth.text("Wächter", .2, 8960, true));
    assertTrue(text.contains("1 / 8960 LP"));
    assertTrue(text.startsWith("Wächter\n"));
    assertEquals(12, text.chars().filter(c -> c == '■').count());
    assertEquals(NamedTextColor.GOLD, MonsterHealth.text("Boss", 100, 100, true).color());
  }

  @Test
  void invalidAndOverhealedValuesStayWithinBarBounds() {
    assertEquals(12, MonsterHealth.filled(150, 100));
    assertEquals(0, MonsterHealth.filled(-2, 100));
    assertEquals(0, MonsterHealth.filled(Double.NaN, 100));
    assertEquals(0, MonsterHealth.filled(10, 0));
    String text =
        PlainTextComponentSerializer.plainText()
            .serialize(MonsterHealth.text("Test", 150, 100, false));
    assertTrue(text.contains("100 / 100 LP"));
    assertNotEquals(
        MonsterHealth.text("Test", 25, 100, false), MonsterHealth.text("Test", 70, 100, false));
  }
}
