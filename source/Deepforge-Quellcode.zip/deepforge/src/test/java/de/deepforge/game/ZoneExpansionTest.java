package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ZoneExpansionTest {
  @Test
  void oldSevenZoneSavesAreWidenedWithoutLosingProgress() {
    Profile p = new Profile();
    p.bag = new long[] {1, 2, 3, 4, 5, 6, 7};
    p.bossWins = new int[21];
    p.bossWins[20] = 4;
    p.bosses = new boolean[] {true, true, true, true, true, true, true};
    Gear.migrate(p);
    assertEquals(Zone.COUNT, p.bag.length);
    assertEquals(7, p.bag[6]);
    assertEquals(0, p.bag[16]);
    assertEquals(Zone.COUNT * 3, p.bossWins.length);
    assertEquals(4, p.bossWins[20]);
    assertTrue(p.bosses[6]);
    assertFalse(p.bosses[7]);
  }

  @Test
  void deepMinesAreSteadilyHarderAndWorthMore() {
    for (int z = 1; z < Zone.COUNT; z++) {
      Zone a = Zone.at(z - 1), b = Zone.at(z);
      assertTrue(b.orePrice > a.orePrice && b.barPrice > a.barPrice, b.name());
      assertTrue(b.unlockCost > a.unlockCost && b.toolRequired > a.toolRequired, b.name());
      assertTrue(MonsterScaling.health(z, 0) > MonsterScaling.health(z - 1, 0));
      assertTrue(MonsterScaling.monsterDamage(z) > MonsterScaling.monsterDamage(z - 1));
      assertTrue(RapidCombat.bossHealth(z, 0) > RapidCombat.bossHealth(z - 1, 0));
      assertTrue(Gear.power(z) > Gear.power(z - 1));
    }
    // The deep shaft grows slower than the first seven mines, so gear can keep up.
    double shallow = MonsterScaling.health(6, 0) / MonsterScaling.health(5, 0);
    double deep = MonsterScaling.health(16, 0) / MonsterScaling.health(15, 0);
    assertTrue(deep < shallow);
    assertEquals(Zone.LAST, StarStones.BOSS_ZONE);
    assertTrue(StarStones.urbossPossible(Zone.LAST, 2));
    assertFalse(StarStones.urbossPossible(6, 2));
  }

  @Test
  void drillGoesToThirtyAndGetsExpensive() {
    Profile p = new Profile();
    p.money = Long.MAX_VALUE / 4;
    p.relics = 100;
    p.tool = 20;
    assertTrue(Economy.buy(p, "tool").startsWith("Verbessert"));
    assertEquals(21, p.tool);
    p.tool = Economy.MAX_TOOL;
    assertEquals("Maximale Stufe erreicht.", Economy.buy(p, "tool"));
    assertTrue(Economy.toolCost(25) > Economy.toolCost(19) * 10);
    // 0.22.0: from level 10 every level costs at least ×1,6 the last (the start stays quick) …
    for (int l = 10; l < Economy.MAX_TOOL; l++)
      assertTrue(Economy.toolCost(l) >= Economy.toolCost(l - 1) * 1.55, "level " + l);
    // … so the two drill levels a deep mine asks for are a real part of its price.
    for (int z = 4; z < Zone.COUNT; z++) {
      int need = Zone.at(z).toolRequired;
      assertTrue(
          Economy.toolCost(need - 1) + Economy.toolCost(need - 2) >= Zone.at(z).unlockCost / 40,
          "mine " + (z + 1));
    }
    p.tool = 0;
    assertEquals(Economy.toolCost(0), Economy.upgradeCost(p, "tool"));
  }

  @Test
  void allSeventeenMinesCanBeUnlockedInOrder() {
    Profile p = new Profile();
    Gear.migrate(p);
    p.money = Long.MAX_VALUE / 4;
    p.tool = Economy.MAX_TOOL;
    for (int z = 0; z < Zone.LAST; z++) {
      p.bosses[z] = true;
      assertTrue(Economy.nextZone(p).endsWith("freigeschaltet!"), "zone " + (z + 1));
    }
    assertEquals(Zone.LAST, p.zone);
    assertEquals("Alle Gebiete erschlossen.", Economy.nextZone(p));
  }
}
