package de.deepforge.world;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class MineBlueprintTest {
  private static final List<MineBlueprint> MINES =
      java.util.stream.IntStream.range(0, de.deepforge.game.Zone.COUNT).mapToObj(MineBlueprint::create).toList();

  private static boolean clear(String s) {
    return s.equals("air") || s.startsWith("rail[") || s.startsWith("cave_vines");
  }

  private static boolean stand(MineBlueprint b, int x, int h, int z) {
    if (!MineBlueprint.inside(x, h + 1, z) || !clear(b.at(x, h, z)) || !clear(b.at(x, h + 1, z)))
      return false;
    String floor = b.at(x, h - 1, z);
    return !clear(floor)
        && !floor.startsWith("water")
        && !floor.startsWith("lava")
        && !floor.equals("outside")
        && !floor.contains("fence")
        && !floor.contains("wall[")
        && !floor.contains("pointed_dripstone")
        && !floor.contains("chain[");
  }

  private static Set<Integer> reachable(MineBlueprint b) {
    Set<Integer> seen = new HashSet<>();
    ArrayDeque<MineBlueprint.Point> q = new ArrayDeque<>();
    var start = new MineBlueprint.Point(0, 1, 35);
    q.add(start);
    seen.add(MineBlueprint.index(0, 1, 35));
    while (!q.isEmpty()) {
      var p = q.remove();
      for (int[] d : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}})
        for (int dh : new int[] {0, 1, -1}) {
          int x = p.x() + d[0], h = p.h() + dh, z = p.z() + d[1];
          if (stand(b, x, h, z) && seen.add(MineBlueprint.index(x, h, z)))
            q.add(new MineBlueprint.Point(x, h, z));
        }
    }
    return seen;
  }

  @Test
  void everyZoneConnectsLiftToBossAndAllServiceRoutes() {
    for (int zone = 0; zone < MINES.size(); zone++) {
      var b = MINES.get(zone);
      var seen = reachable(b);
      assertTrue(seen.contains(MineBlueprint.index(0, 1, 33)), "lift " + zone);
      assertTrue(seen.contains(MineBlueprint.index(2, 1, 85)), "boss spawn " + zone);
      assertTrue(seen.contains(MineBlueprint.index(2, 1, 91)), "boss altar " + zone);
      for (var p : b.route())
        assertTrue(
            seen.contains(MineBlueprint.index(p.x(), p.h(), p.z())),
            "rail route " + zone + " " + p);
      for (var c : b.chambers()) {
        boolean found = false;
        for (int dx = -3; dx <= 3; dx++)
          for (int dz = -3; dz <= 3; dz++)
            for (int h = 0; h <= 4; h++)
              found |= seen.contains(MineBlueprint.index(c.x() + dx, h, c.z() + dz));
        assertTrue(found, "chamber " + zone + " " + c);
      }
    }
  }

  @Test
  void everyOreHasAReachableMiningPosition() {
    for (int zone = 0; zone < MINES.size(); zone++) {
      var b = MINES.get(zone);
      var seen = reachable(b);
      int blocked = 0;
      for (var p : b.ores()) {
        boolean accessible = false;
        for (int[] d : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}})
          for (int h = p.h() - 2; h <= p.h(); h++)
            accessible |= seen.contains(MineBlueprint.index(p.x() + d[0], h, p.z() + d[1]));
        if (!accessible) blocked++;
        assertTrue(b.isOre(p.x(), p.h(), p.z()));
        assertTrue(b.at(p.x(), p.h(), p.z()).contains("note=" + zone + ","));
      }
      assertEquals(0, blocked, "unreachable ores in zone " + zone);
      assertTrue(b.ores().size() >= 100, "too little ore " + zone);
    }
  }

  @Test
  void exteriorShellIsClosedAndDoesNotTouchVillage() {
    for (int zone = 0; zone < MINES.size(); zone++) {
      var b = MINES.get(zone);
      for (int i = 0; i < b.size(); i++) {
        var p = MineBlueprint.point(i);
        assertNotNull(b.state(i));
        assertEquals(i, MineBlueprint.index(p.x(), p.h(), p.z()));
        int y = 168 - (zone >= 7 ? zone - 7 : zone) * 24 + p.h();
        assertTrue(y > -64 && y < 188);
        if (p.x() == -48
            || p.x() == 48
            || p.z() == 24
            || p.z() == 100
            || p.h() == -4
            || p.h() == 19) assertFalse(clear(b.state(i)), "open outer shell: " + p);
      }
    }
  }

  @Test
  void irregularChambersHaveVariableWidthsAndCeilings() {
    for (var b : MINES) {
      Set<Integer> widths = new HashSet<>(), tops = new HashSet<>();
      for (int z = 30; z < 96; z++) {
        int width = 0;
        for (int x = -42; x <= 42; x++) {
          if (clear(b.at(x, 3, z))) width++;
          for (int h = 18; h >= 3; h--)
            if (clear(b.at(x, h, z))) {
              tops.add(h);
              break;
            }
        }
        widths.add(width);
      }
      assertTrue(widths.size() > 15, "rectangular cross section");
      assertTrue(tops.size() > 8, "flat roof");
    }
  }

  @Test
  void themesContainTheirDistinctLandmarks() {
    String[] markers = {
      "raw_copper_block",
      "amethyst_cluster[facing=up]",
      "mushroom_stem",
      "water[level=0]",
      "lava[level=0]",
      "decorated_pot",
      "pearlescent_froglight",
      "magma_block",
      "tinted_glass",
      "slime_block",
      "lightning_rod[facing=up]",
      "bone_block[axis=x]",
      "purpur_pillar[axis=y]",
      "soul_lantern",
      "large_amethyst_bud[facing=up]",
      "sniffer_egg[hatch=0]",
      "beacon"
    };
    for (int z = 0; z < MINES.size(); z++)
      assertTrue(MINES.get(z).palette().contains(markers[z]), "theme " + z);
  }

  @Test
  void layoutsDifferBetweenNeighbouringMines() {
    for (int z = 1; z < MINES.size(); z++) {
      int differ = 0;
      for (int i = 0; i < MINES.get(z).size(); i += 7)
        if (clear(MINES.get(z).state(i)) != clear(MINES.get(z - 1).state(i))) differ++;
      assertTrue(differ > 2000, "mine " + z + " looks like mine " + (z - 1) + ": " + differ);
    }
  }

  @Test
  void upperViewingGalleryCanBeReachedOnFoot() {
    for (int z = 0; z < MINES.size(); z++)
      assertTrue(reachable(MINES.get(z)).contains(MineBlueprint.index(-10, 5, 57)), "gallery " + z);
  }

  @Test
  void stationsAreNotOreAndSpawnsHaveHeadroom() {
    for (var b : MINES) {
      assertEquals("lectern[facing=south]", b.at(0, 1, 32));
      assertEquals("lodestone", b.at(2, 1, 92));
      assertFalse(b.isOre(0, 1, 32));
      assertFalse(b.isOre(2, 1, 92));
      assertTrue(stand(b, 0, 1, 35));
      assertTrue(stand(b, 2, 1, 85));
    }
  }
}
