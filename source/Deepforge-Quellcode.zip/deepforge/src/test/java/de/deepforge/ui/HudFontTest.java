package de.deepforge.ui;

import static org.junit.jupiter.api.Assertions.*;

import java.nio.file.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.gson.GsonComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.junit.jupiter.api.Test;

class HudFontTest {
  @Test
  void spacesAddUpToTheRequestedWidth() {
    for (int px : new int[] {-300, -129, -37, -1, 1, 5, 64, 127, 200}) {
      int sum = 0;
      for (char c : HudFont.space(px).toCharArray())
        sum += c < 0xE388 ? -(1 << (c - 0xE380)) : 1 << (c - 0xE388);
      assertEquals(px, sum, "space " + px);
    }
  }

  @Test
  void chipsAreExactlyAsWideAsTheirContent() {
    HudFont.Line line = new HudFont.Line();
    line.chip(l -> l.text("AB", HudFont.GOLD));
    // 2 letters (12) + padding 2*4 - 1 visible, advance +1, gap 3.
    assertEquals(12 + 8 - 1 + 3, line.width());
    HudFont.Line bar = new HudFont.Line().bar(.5, 10, HudFont.GREEN);
    assertEquals(40, bar.width());
    assertEquals("".repeat(5) + "".repeat(5), plain(bar.build()));
    assertEquals(1, plain(new HudFont.Line().bar(.01, 10, HudFont.GREEN).build()).chars().filter(c -> c == 0xE360).count(), "any value shows one segment");
  }

  @Test
  void lettersMapToTheirGlyphs() {
    assertEquals((char) 0xE300, HudFont.letter('0'));
    assertEquals(HudFont.letter('A'), HudFont.letter('a'));
    assertEquals(0, HudFont.letter('ä'));
    assertEquals("1.234$", HudFont.compact(1234) + "$");
    assertEquals("250K", HudFont.compact(250_000));
    assertEquals("12M", HudFont.compact(12_000_000));
    assertEquals("1.23M", HudFont.compact(1_234_567));
  }

  @Test
  void writesPreviewLines() throws Exception {
    Path out = Paths.get("target", "hud-preview.json");
    Component mining = HudFont.mining(1_234_567, 120, 200, 72, "23M", HudFont.Icon.UP_RIGHT);
    Component full = HudFont.mining(980, 200, 200, 12, null, null);
    Component combat = HudFont.combat(14, 24, 60, 0, 3, 0, 7);
    Component hurt = HudFont.combat(5, 24, 20, 4, 0, 12, 12);
    var gson = GsonComponentSerializer.gson();
    Files.writeString(
        out,
        "[" + gson.serialize(mining) + "," + gson.serialize(full) + "," + gson.serialize(combat) + "," + gson.serialize(hurt) + "]");
    assertTrue(Files.size(out) > 100);
    de.deepforge.game.Profile p = new de.deepforge.game.Profile();
    p.money = 48_250;
    p.dust = 17;
    p.zone = 2;
    p.kills = 312;
    p.bag[0] = 120;
    p.healingCharges = 3;
    StringBuilder side = new StringBuilder("[");
    for (Component c : BoardView.lines(p, true, true))
      side.append(side.length() > 1 ? "," : "").append(gson.serialize(c));
    Files.writeString(Paths.get("target", "sidebar-preview.json"), side.append("]").toString());
  }

  private static String plain(Component c) {
    return PlainTextComponentSerializer.plainText().serialize(c);
  }
}
