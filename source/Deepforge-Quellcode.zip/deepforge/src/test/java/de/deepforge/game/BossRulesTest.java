package de.deepforge.game;

import static de.deepforge.game.BossRules.Attack.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BossRulesTest {
  @Test
  void phasesSwitchAtHealthThresholds() {
    assertEquals(1, BossRules.phase(701, 1000));
    assertEquals(2, BossRules.phase(700, 1000));
    assertEquals(2, BossRules.phase(351, 1000));
    assertEquals(3, BossRules.phase(350, 1000));
  }

  @Test
  void modesRequirePreviousVictoryInSameZone() {
    Profile p = new Profile();
    assertTrue(BossRules.unlocked(p, 0, 0));
    assertFalse(BossRules.unlocked(p, 0, 1));
    assertFalse(BossRules.unlocked(p, -1, 0));
    assertFalse(BossRules.unlocked(p, 1, 0));
    p.bossWins[0] = 1;
    assertTrue(BossRules.unlocked(p, 0, 1));
    assertFalse(BossRules.unlocked(p, 0, 2));
    p.bossWins[1] = 1;
    assertTrue(BossRules.unlocked(p, 0, 2));
    assertFalse(BossRules.unlocked(p, 0, 3));
  }

  @Test
  void ringCanBeJumpedOrAvoidedInsideAndOutside() {
    assertTrue(BossRules.hit(RING, 0, 4, 0, 1, false));
    assertFalse(BossRules.hit(RING, 0, 4, 0, 1, true));
    assertFalse(BossRules.hit(RING, 0, 1.9, 0, 1, false));
    assertFalse(BossRules.hit(RING, 0, 6.1, 0, 1, false));
  }

  @Test
  void beamHasSafeSidesAndBack() {
    assertTrue(BossRules.hit(BEAM, 1.2, 13, 0, 1, false));
    assertFalse(BossRules.hit(BEAM, 1.21, 5, 0, 1, false));
    assertFalse(BossRules.hit(BEAM, 0, -.1, 0, 1, false));
    assertFalse(BossRules.hit(BEAM, 0, 13.1, 0, 1, false));
  }

  @Test
  void coneRespectsFacingAndDistance() {
    assertTrue(BossRules.hit(CONE, 0, 5, 0, 1, false));
    assertFalse(BossRules.hit(CONE, 0, -2, 0, 1, false));
    assertFalse(BossRules.hit(CONE, 5, 0, 0, 1, false));
    assertFalse(BossRules.hit(CONE, 0, 6.1, 0, 1, false));
  }

  @Test
  void runesLeaveSafeLaneInBothDirections() {
    assertFalse(BossRules.hit(RUNES, 1.8, 5, 0, 1, false));
    assertFalse(BossRules.hit(RUNES, 1.8, -5, 0, 1, false));
    assertTrue(BossRules.hit(RUNES, 1.81, -5, 0, 1, false));
    assertFalse(BossRules.hit(RUNES, 11, 0, 0, 1, false));
  }

  @Test
  void circlesAndAllZonePatternsAreBounded() {
    for (var type : new BossRules.Attack[] {IMPACT, SPORES}) {
      assertTrue(BossRules.hit(type, 2.8, 0, 0, 1, false));
      assertFalse(BossRules.hit(type, 2.81, 0, 0, 1, false));
    }
    for (int z = 0; z < 7; z++)
      for (int step = 0; step < 3; step++)
        assertEquals(BossRules.attack(z, step), BossRules.attack(z, step + 3));
  }
}
