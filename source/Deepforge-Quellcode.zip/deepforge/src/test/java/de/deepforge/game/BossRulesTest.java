package de.deepforge.game;

import static de.deepforge.game.BossRules.Attack.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class BossRulesTest {
  @Test
  void phasesSwitchAtHealthThresholds() {
    assertEquals(1, BossRules.phase(701, 1000));
    assertEquals(2, BossRules.phase(700, 1000));
    assertEquals(2, BossRules.phase(351, 1000));
    assertEquals(3, BossRules.phase(350, 1000));
  }

  @Test
  void modesRequirePreviousVictoryInSameZone() {
    Profile p = new Profile();
    assertTrue(BossRules.unlocked(p, 0, 0));
    assertFalse(BossRules.unlocked(p, 0, 1));
    assertFalse(BossRules.unlocked(p, -1, 0));
    assertFalse(BossRules.unlocked(p, 1, 0));
    p.bossWins[0] = 1;
    assertTrue(BossRules.unlocked(p, 0, 1));
    assertFalse(BossRules.unlocked(p, 0, 2));
    p.bossWins[1] = 1;
    assertTrue(BossRules.unlocked(p, 0, 2));
    assertFalse(BossRules.unlocked(p, 0, 3));
  }

  @Test
  void ringCanBeJumpedOrAvoidedInsideAndOutside() {
    assertTrue(BossRules.hit(RING, 0, 4, 0, 1, false));
    assertFalse(BossRules.hit(RING, 0, 4, 0, 1, true));
    assertFalse(BossRules.hit(RING, 0, 1.9, 0, 1, false));
    assertFalse(BossRules.hit(RING, 0, 6.1, 0, 1, false));
  }

  @Test
  void beamHasSafeSidesAndBack() {
    assertTrue(BossRules.hit(BEAM, 1.2, 13, 0, 1, false));
    assertFalse(BossRules.hit(BEAM, 1.21, 5, 0, 1, false));
    assertFalse(BossRules.hit(BEAM, 0, -.1, 0, 1, false));
    assertFalse(BossRules.hit(BEAM, 0, 13.1, 0, 1, false));
  }

  @Test
  void coneRespectsFacingAndDistance() {
    assertTrue(BossRules.hit(CONE, 0, 5, 0, 1, false));
    assertFalse(BossRules.hit(CONE, 0, -2, 0, 1, false));
    assertFalse(BossRules.hit(CONE, 5, 0, 0, 1, false));
    assertFalse(BossRules.hit(CONE, 0, 6.1, 0, 1, false));
  }

  @Test
  void runesLeaveSafeLaneInBothDirections() {
    assertFalse(BossRules.hit(RUNES, 1.8, 5, 0, 1, false));
    assertFalse(BossRules.hit(RUNES, 1.8, -5, 0, 1, false));
    assertTrue(BossRules.hit(RUNES, 1.81, -5, 0, 1, false));
    assertFalse(BossRules.hit(RUNES, 11, 0, 0, 1, false));
  }

  @Test
  void circlesAndAllZonePatternsAreBounded() {
    for (var type : new BossRules.Attack[] {IMPACT, SPORES}) {
      assertTrue(BossRules.hit(type, 2.8, 0, 0, 1, false));
      assertFalse(BossRules.hit(type, 2.81, 0, 0, 1, false));
    }
    for (int z = 0; z < 7; z++)
      for (int step = 0; step < 3; step++)
        assertEquals(BossRules.attack(z, step), BossRules.attack(z, step + 3));
  }

  @Test
  void kitsGrowWithEveryPhaseForAllSeventeenBosses() {
    for (int z = 0; z < Zone.COUNT; z++) {
      List<BossRules.Attack> one = BossRules.kit(z, 1, 0), two = BossRules.kit(z, 2, 0), three = BossRules.kit(z, 3, 0);
      assertEquals(2, one.size());
      assertTrue(two.containsAll(one) && two.size() == 4, "zone " + z + ": " + two);
      assertTrue(three.containsAll(two) && three.size() == 5, "zone " + z + ": " + three);
      assertTrue(three.stream().anyMatch(a -> a.ordinal() >= CHARGE.ordinal()), "a new move by phase 3");
      assertFalse(BossRules.kit(z, 2, 1).contains(FALL) && !two.contains(FALL), "Veteran: Felsregen only in phase 3");
      assertTrue(BossRules.kit(z, 3, 1).contains(FALL));
      assertTrue(BossRules.kit(z, 2, 2).contains(FALL));
    }
  }

  @Test
  void attacksAreShuffledButNeverRepeatBackToBack() {
    for (int z = 0; z < Zone.COUNT; z++)
      for (int phase = 1; phase <= 3; phase++) {
        Set<BossRules.Attack> seen = new HashSet<>();
        BossRules.Attack last = null;
        for (int n = 0; n < 60; n++) {
          BossRules.Attack a = BossRules.next(z, phase, 2, n, 42);
          assertNotEquals(last, a, "zone " + z + " phase " + phase + " step " + n);
          assertTrue(BossRules.kit(z, phase, 2).contains(a));
          seen.add(a);
          last = a;
        }
        assertEquals(new HashSet<>(BossRules.kit(z, phase, 2)), seen);
      }
  }

  @Test
  void newAttackGeometry() {
    // Sturmangriff: a lane in front, the sides and the back are safe.
    assertTrue(BossRules.hit(CHARGE, 1.4, 11, 0, 1, false));
    assertFalse(BossRules.hit(CHARGE, 1.6, 5, 0, 1, false));
    assertFalse(BossRules.hit(CHARGE, 0, -1, 0, 1, false));
    // Kreuzstrahl: four arms, the diagonals are safe.
    assertTrue(BossRules.hit(CROSS, 0, -9, 0, 1, false));
    assertTrue(BossRules.hit(CROSS, 9, 0, 0, 1, false));
    assertFalse(BossRules.hit(CROSS, 4, 4, 0, 1, false));
    // Nova: only right next to the boss is safe.
    assertFalse(BossRules.hit(NOVA, 2, 2, 0, 1, false));
    assertTrue(BossRules.hit(NOVA, 6, 0, 0, 1, false));
    assertFalse(BossRules.hit(NOVA, 14, 0, 0, 1, false));
    // Felsregen: one rock on every player plus scattered ones.
    List<double[]> rocks = BossRules.rocks(List.of(new double[] {3, 4}, new double[] {-2, 1}), 9);
    assertEquals(BossRules.FALL_ROCKS + 1, rocks.size());
    assertArrayEquals(new double[] {3, 4}, rocks.get(0));
    for (BossRules.Attack a : BossRules.Attack.values()) assertFalse(BossRules.title(a).isBlank());
  }
}
