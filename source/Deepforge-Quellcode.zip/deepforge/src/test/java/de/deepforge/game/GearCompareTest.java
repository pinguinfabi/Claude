package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class GearCompareTest {
  @Test
  void listsEveryChangedStatWithDirection() {
    Gear.Item a = new Gear.Item(), b = new Gear.Item();
    a.damage = 10;
    a.crit = .05;
    b.damage = 8;
    b.health = 4;
    b.crit = .05;
    assertEquals("▲ Schaden +2 · ▼ Leben −4", GearCompare.diff(a, b));
    assertNull(GearCompare.diff(a, a));
    assertTrue(GearCompare.diff(a, null).startsWith("▲ Slot ist leer"));
    Gear.Item c = new Gear.Item();
    c.id = a.id + "x";
    c.damage = 10;
    c.crit = .05;
    assertEquals("= gleiche Werte wie ausgerüstet", GearCompare.diff(c, a));
  }

  @Test
  void runesAreShownApartFromTheItemsOwnValues() {
    Gear.Item a = new Gear.Item(), b = new Gear.Item();
    a.damage = 10;
    b.damage = 10;
    b.id = a.id + "b";
    // the equipped item carries a strength rune, the new one does not
    b.runeSockets = new int[] {Runes.code(Runes.Kind.KRAFT, 0)};
    double rune = Runes.itemBonus(b, Runes.Kind.KRAFT);
    assertTrue(rune > 0);
    String diff = GearCompare.diff(a, b);
    assertTrue(diff.startsWith("▼ Schaden ±0 (−"), diff);
    a.damage = 15;
    diff = GearCompare.diff(a, b);
    assertTrue(diff.contains("Schaden +5 (−"), diff);
  }
}
