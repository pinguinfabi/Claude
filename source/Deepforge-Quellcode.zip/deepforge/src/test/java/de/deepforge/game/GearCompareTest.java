package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class GearCompareTest {
  @Test
  void listsEveryChangedStatWithDirection() {
    Gear.Item a = new Gear.Item(), b = new Gear.Item();
    a.damage = 10;
    a.crit = .05;
    b.damage = 8;
    b.health = 4;
    b.crit = .05;
    assertEquals("▲ Schaden +2 · ▼ Leben −4", GearCompare.diff(a, b));
    assertNull(GearCompare.diff(a, a));
    assertTrue(GearCompare.diff(a, null).startsWith("▲ Slot ist leer"));
    Gear.Item c = new Gear.Item();
    c.id = a.id + "x";
    c.damage = 10;
    c.crit = .05;
    assertEquals("= gleiche Werte wie ausgerüstet", GearCompare.diff(c, a));
  }
}
