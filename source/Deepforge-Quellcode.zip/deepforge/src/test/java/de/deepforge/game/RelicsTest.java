package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Random;
import org.junit.jupiter.api.Test;

class RelicsTest {
  private static Profile rich(Relics.Relic relic) {
    Profile p = new Profile();
    p.zone = 5;
    p.money = Relics.MONEY;
    p.dust = Relics.DUST;
    for (int i = 0; i < relic.recipe.length; i++) Relics.parts(p)[i] = relic.recipe[i];
    return p;
  }

  @Test
  void everyRelicNeedsSeveralDifferentRareParts() {
    for (Relics.Relic relic : Relics.Relic.values()) {
      int kinds = 0, total = 0;
      for (int n : relic.recipe) {
        if (n > 0) kinds++;
        total += n;
      }
      assertTrue(kinds >= 3, relic.title + " needs at least three kinds of parts");
      assertTrue(total >= 10, relic.title + " needs at least ten parts");
      assertEquals(relic, Relics.Relic.of(relic.signature));
      assertEquals("relic_" + (relic.signature - 7), modelOf(relic));
    }
  }

  private static String modelOf(Relics.Relic relic) {
    Gear.Item i = new Gear.Item();
    i.signature = relic.signature;
    i.slot = relic.slot;
    return i.model();
  }

  @Test
  void partsAreRareAndHarderModesDropMore() {
    for (Relics.Part part : Relics.Part.values()) {
      assertTrue(Relics.chance(part, 0) <= Relics.chance(part, 2));
      assertTrue(Relics.chance(part, 2) <= .35, part + " stays rare");
    }
    assertEquals(.04, Relics.chance(Relics.Part.ERZKERN, 0), 1e-9);
    assertEquals(.12, Relics.chance(Relics.Part.SIEGEL, 2), 1e-9);
    assertEquals(.12, Relics.chance(Relics.Part.SIEGEL, 9), 1e-9, "mode is clamped");
    // On average a whole relic takes far more than a hundred boss kills.
    double kills = 0;
    Relics.Relic relic = Relics.Relic.ERZFUERST;
    for (int i = 0; i < relic.recipe.length; i++)
      kills += relic.recipe[i] / Relics.chance(Relics.Part.values()[i], 0);
    assertTrue(kills > 200, "expected grind, got " + kills);
  }

  @Test
  void rollAddsThePartOnlyWhenItDrops() {
    Profile p = new Profile();
    Random r = new Random(1);
    int drops = 0;
    for (int n = 0; n < 10_000; n++) if (Relics.roll(p, Relics.Part.WALDHERZ, 0, r)) drops++;
    assertEquals(drops, Relics.parts(p)[Relics.Part.WALDHERZ.ordinal()]);
    assertTrue(drops > 200 && drops < 400, "about 3 % – got " + drops);
  }

  @Test
  void forgingNeedsEverythingAndConsumesIt() {
    Relics.Relic relic = Relics.Relic.GEWOELBESCHWUR;
    Profile p = rich(relic);
    p.relicParts[Relics.Part.SIEGEL.ordinal()]--;
    assertFalse(Relics.canForge(p, relic));
    int before = p.gear.size();
    assertTrue(Relics.forge(p, relic, new Random(1)).startsWith("Es fehlen"));
    assertEquals(before, p.gear.size());

    p = rich(relic);
    p.dust--;
    assertFalse(Relics.canForge(p, relic), "dust is part of the price");
    p = rich(relic);
    p.money--;
    assertFalse(Relics.canForge(p, relic), "money is part of the price");

    p = rich(relic);
    String msg = Relics.forge(p, relic, new Random(1));
    assertTrue(msg.startsWith("RELIKT GESCHMIEDET"), msg);
    assertEquals(0, p.money);
    assertEquals(0, p.dust);
    for (int n : p.relicParts) assertEquals(0, n);
    assertEquals(1, p.relicsForged);
    Gear.Item i = p.gear.get(p.gear.size() - 1);
    assertEquals(Gear.Rarity.MYTHIC, i.rarity);
    assertEquals(relic.signature, i.signature);
    assertEquals("sword", i.style);
    assertEquals(5, i.zone);
    assertTrue(p.discovered.contains(relic.title));
  }

  @Test
  void relicBeatsAMythicOfTheSameZone() {
    Relics.Relic relic = Relics.Relic.TIEFENSEUFZER;
    Profile p = rich(relic);
    Relics.forge(p, relic, new Random(2));
    Gear.Item forged = p.gear.get(p.gear.size() - 1);
    Random r = new Random(4);
    for (int n = 0; n < 200; n++) {
      Gear.Item mythic = Gear.roll(5, Gear.Rarity.MYTHIC, r);
      if (mythic.slot == Gear.Slot.WEAPON) assertTrue(forged.damage > mythic.damage);
    }
  }

  @Test
  void shieldIsAnOffhandWithDefense() {
    Relics.Relic relic = Relics.Relic.WELTENSCHILD;
    Profile p = rich(relic);
    Relics.forge(p, relic, new Random(3));
    Gear.Item shield = p.gear.get(p.gear.size() - 1);
    assertEquals(Gear.Slot.OFFHAND, shield.slot);
    assertEquals(0, shield.damage);
    assertTrue(shield.defense > 0 && shield.health > 0);
  }

  @Test
  void effectsOnlyWorkWhileEquipped() {
    for (Relics.Relic relic : Relics.Relic.values()) {
      Profile p = rich(relic);
      Relics.forge(p, relic, new Random(5));
      Gear.Item i = p.gear.get(p.gear.size() - 1);
      assertEquals(1, Relics.posture(p) * Relics.bossDamage(p) * Relics.damageTaken(p), 1e-9);
      assertEquals(0, Relics.lifesteal(p) + Relics.doubleShot(p), 1e-9);
      Gear.equip(p, i.id);
      switch (relic) {
        case ERZFUERST -> {
          assertEquals(1.6, Relics.posture(p), 1e-9);
          assertEquals(1.5, Relics.hammerAbility(p), 1e-9);
        }
        case GEWOELBESCHWUR -> assertEquals(.04, Relics.lifesteal(p), 1e-9);
        case TIEFENSEUFZER -> assertEquals(1.3, Relics.bossDamage(p), 1e-9);
        case WALDLAEUFER -> assertEquals(.25, Relics.doubleShot(p), 1e-9);
        case SCHATTENZAHN -> assertEquals(2.6, Gear.baseCritDamage(i), 1e-9);
        case WELTENSCHILD -> assertEquals(.8, Relics.damageTaken(p), 1e-9);
      }
    }
  }

  @Test
  void oldProfilesGetEmptyPartSlots() {
    Profile p = new Profile();
    p.relicParts = new int[] {2};
    Gear.migrate(p);
    assertEquals(Relics.Part.values().length, Relics.parts(p).length);
    assertEquals(2, Relics.parts(p)[0]);
  }
}
