package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class RerollPriceTest {
  @Test
  void threeFairReforgesThenPricedOut() {
    Gear.Item item = Gear.roll(0, Gear.Rarity.EPIC, new Random(3));
    assertEquals(500, Gear.rerollCost(item, 0));
    assertEquals(1500, Gear.rerollCost(item, 1));
    assertEquals(4500, Gear.rerollCost(item, 2));
    assertTrue(Gear.rerollLocked(3));
    assertFalse(Gear.rerollLocked(2));
    assertEquals(5, Gear.rerollDust(0));
    assertEquals(20, Gear.rerollDust(2));
    item.zone = 2;
    assertEquals(1500, Gear.rerollCost(item, 0), "deeper zones cost more");
  }

  @Test
  void eachReforgeRaisesThePriceAndChanceAndDamageCountSeparately() {
    Profile p = new Profile();
    Gear.Item item = Gear.roll(0, Gear.Rarity.EPIC, new Random(3));
    item.slot = Gear.Slot.WEAPON;
    p.gear.add(item);
    p.money = 6500;
    p.dust = 35;
    Random r = new Random(1);
    for (int n = 0; n < 3; n++) assertTrue(Gear.reroll(p, item.id, r).startsWith("Krit neu"));
    assertEquals(0, p.money);
    assertEquals(0, p.dust);
    assertEquals(3, item.critRerolls);
    String refused = Gear.reroll(p, item.id, r);
    assertTrue(refused.startsWith("Unbezahlbar"), refused);
    p.money = Long.MAX_VALUE / 2;
    p.dust = Long.MAX_VALUE / 2;
    assertTrue(Gear.reroll(p, item.id, r).startsWith("Unbezahlbar"), "not even for all the money");
    p.money = 0;
    p.dust = 0;
    assertEquals(3, item.critRerolls, "refused tries are not counted");
    p.money = 500;
    p.dust = 5;
    assertTrue(Gear.rerollCritDamage(p, item.id, r).startsWith("Krit-Schaden"));
    assertEquals(1, item.critDamageRerolls);
    assertTrue(Gear.rerollPrice(item, item.critDamageRerolls).contains("1.500 $"));
    assertTrue(Gear.rerollPrice(item, 3).contains("UNBEZAHLBAR"));
    assertFalse(Gear.rerollPrice(item, 3).contains("$"));
  }
}
