package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SellChoiceTest {
  @Test
  void oneWoodTypeAtATime() {
    Profile p = new Profile();
    p.money = 0;
    p.wood = new long[] {10, 5, 2};
    p.planks = new long[] {4, 0, 1};
    String msg = Forestry.act(p, "sell:1");
    assertTrue(msg.startsWith("Birke"), msg);
    assertEquals(5 * Forestry.PRICES[1], p.money);
    assertArrayEquals(new long[] {10, 0, 2}, p.wood);
    assertArrayEquals(new long[] {4, 0, 1}, p.planks);
    assertTrue(Forestry.act(p, "sell:1").contains("kein"));
    assertEquals("Unbekannte Holzart.", Forestry.act(p, "sell:7"));
  }

  @Test
  void barsOnlyKeepOreAndReserve() {
    Profile p = new Profile();
    p.money = 0;
    p.stock[1] = 50;
    p.bars[1] = 30;
    p.bars[2] = 10;
    long[] kept = new long[1];
    long money = Economy.sellBars(p, kept);
    assertEquals(50, p.stock[1], "ore stays");
    assertEquals(
        (30 - Industry.barReserve(p, 1)) * Zone.at(1).barPrice
            + (10 - Industry.barReserve(p, 2)) * Zone.at(2).barPrice,
        money);
    assertEquals(money, p.money);
    p.bars[0] = 3;
    long[] reserved = new long[1];
    Economy.sellBars(p, reserved);
    assertEquals(3, p.bars[0], "zone 1 bars kept for the next research step");
    assertEquals(3, reserved[0]);
  }
}
