package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TalentsTest {
  @Test
  void masteryLevelsGiveOnePointEachAndAreSeparateFromThePass() {
    Profile p = new Profile();
    assertEquals(0, Talents.level(p));
    assertEquals(1, Talents.addXp(p, Talents.need(0)));
    assertEquals(1, Talents.free(p));
    assertEquals(0, p.passXp, "mastery XP does not touch the Tiefenpass");
    assertEquals(39, Talents.MAX_LEVEL);
    Talents.addXp(p, 10_000_000);
    assertEquals(Talents.MAX_LEVEL, Talents.level(p));
  }

  @Test
  void ranksCapKeysNeedEightPointsAndResetCostsMoney() {
    Profile p = new Profile();
    Talents.addXp(p, 10_000_000);
    for (int i = 0; i < 3; i++) assertTrue(Talents.learn(p, Talents.Node.KLINGE).contains("Rang"));
    assertTrue(Talents.learn(p, Talents.Node.KLINGE).contains("voll ausgebaut"));
    assertTrue(Talents.learn(p, Talents.Node.BLUTRAUSCH).startsWith("Benötigt 8"));
    for (int i = 0; i < 3; i++) Talents.learn(p, Talents.Node.ZAEHIGKEIT);
    Talents.learn(p, Talents.Node.BOLLWERK);
    Talents.learn(p, Talents.Node.BOLLWERK);
    assertTrue(Talents.learn(p, Talents.Node.BLUTRAUSCH).contains("Rang 1/1"));
    assertTrue(Talents.bloodrush(p));
    assertEquals(1.09, Talents.damage(p), 1e-9);
    assertEquals(15, Talents.health(p), 1e-9);
    assertEquals(.94, Talents.damageTaken(p), 1e-9);
    double base = Gear.stats(new Profile()).damage();
    assertEquals(base * 1.09, Gear.stats(p).damage(), 1e-9);
    p.money = 5000;
    assertTrue(Talents.reset(p).startsWith("Benötigt 9000"));
    p.money = 9000;
    assertTrue(Talents.reset(p).startsWith("Talente zurückgesetzt"));
    assertEquals(0, p.money);
    assertEquals(Talents.MAX_LEVEL, Talents.free(p));
  }

  @Test
  void economyTalentsChangePricesAndMining() {
    Profile p = new Profile();
    Talents.addXp(p, 10_000_000);
    long before = Economy.upgradeCost(p, "tool");
    double speed = ToolStats.of(p, 0, false).speed();
    for (int i = 0; i < 3; i++) {
      Talents.learn(p, Talents.Node.SPARFUCHS);
      Talents.learn(p, Talents.Node.BOHRER);
    }
    assertEquals(Math.round(before * .88), Economy.upgradeCost(p, "tool"));
    assertEquals(speed * 1.12, ToolStats.of(p, 0, false).speed(), 1e-9);
    for (int i = 0; i < 3; i++) Talents.learn(p, Talents.Node.HANDEL);
    assertEquals(1.09, Talents.sale(p), 1e-9);
  }
}
