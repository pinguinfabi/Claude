package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.Test;

class AlchemyTest {
  private static Profile stocked() {
    Profile p = new Profile();
    p.money = 1_000_000;
    for (Alchemy.Ingredient i : Alchemy.Ingredient.values()) Alchemy.gain(p, i, 50);
    return p;
  }

  @Test
  void brewingNeedsIngredientsAndMoney() {
    Profile p = new Profile();
    String r = Alchemy.brew(p, Alchemy.Potion.STAERKE);
    assertTrue(r.startsWith("Es fehlt") && r.contains("Schattenessenz") && r.contains("Waldkraut"), r);
    p = stocked();
    long money = p.money;
    assertTrue(Alchemy.brew(p, Alchemy.Potion.STAERKE).contains("gebraut"));
    assertEquals(47, Alchemy.ingredient(p, Alchemy.Ingredient.ESSENZ));
    assertEquals(48, Alchemy.ingredient(p, Alchemy.Ingredient.KRAUT));
    assertEquals(money - Alchemy.price(p, Alchemy.Potion.STAERKE), p.money);
    assertEquals(1, Alchemy.stock(p, Alchemy.Potion.STAERKE));
    assertEquals(Alchemy.XP_PER_BREW, p.alchemyXp);
  }

  @Test
  void drinkingBuffsForAWhile() {
    Profile p = stocked();
    Alchemy.brew(p, Alchemy.Potion.STAERKE);
    Alchemy.brew(p, Alchemy.Potion.STAERKE);
    long now = 1_000_000;
    assertEquals(0, Alchemy.bonus(p, Alchemy.Potion.STAERKE, now));
    assertTrue(Alchemy.drink(p, Alchemy.Potion.STAERKE, now).contains("getrunken"));
    assertEquals(.15, Alchemy.bonus(p, Alchemy.Potion.STAERKE, now + 1000), 1e-9);
    assertEquals(0, Alchemy.bonus(p, Alchemy.Potion.STAERKE, now + 10 * 60_000L));
    assertTrue(Alchemy.drink(p, Alchemy.Potion.STAERKE, now + 1000).contains("getrunken"), "refill while running");
    assertEquals(20 * 60_000L, Alchemy.remaining(p, Alchemy.Potion.STAERKE, now));
    assertTrue(Alchemy.drink(p, Alchemy.Potion.STAERKE, now).startsWith("Kein"));
    assertEquals(List.of("Trank der Stärke"), Alchemy.expire(p, now + 21 * 60_000L));
    assertTrue(Alchemy.expire(p, now + 22 * 60_000L).isEmpty());
  }

  @Test
  void onlyAFewAtOnce() {
    Profile p = stocked();
    for (Alchemy.Potion k : List.of(Alchemy.Potion.STAERKE, Alchemy.Potion.ZAEH, Alchemy.Potion.GOLD))
      Alchemy.brew(p, k);
    long now = 5;
    Alchemy.drink(p, Alchemy.Potion.STAERKE, now);
    Alchemy.drink(p, Alchemy.Potion.ZAEH, now);
    assertTrue(Alchemy.drink(p, Alchemy.Potion.GOLD, now).startsWith("Schon 2"));
    assertEquals(1, Alchemy.stock(p, Alchemy.Potion.GOLD), "nothing consumed");
  }

  @Test
  void braumeisterLevels() {
    Profile p = new Profile();
    assertEquals(0, Alchemy.level(p));
    assertEquals(2, Alchemy.slots(p));
    p.alchemyXp = 40L * 10 * 10;
    assertEquals(10, Alchemy.level(p));
    assertEquals(4, Alchemy.slots(p));
    assertEquals(2, Alchemy.batch(p));
    assertEquals(1.2, Alchemy.strength(p), 1e-9);
    p.alchemyXp = Long.MAX_VALUE / 2;
    assertEquals(Alchemy.MAX_LEVEL, Alchemy.level(p));
    assertEquals(6, Alchemy.slots(p));
  }

  @Test
  void potionsReachTheStats() {
    Profile p = stocked();
    double base = Gear.stats(p).damage();
    long ore = p.power();
    p.activePotions.put("STAERKE", System.currentTimeMillis() + 60_000);
    p.activePotions.put("BERGMANN", System.currentTimeMillis() + 60_000);
    assertEquals(base * 1.15, Gear.stats(p).damage(), 1e-6);
    assertEquals(Math.round(ore * 1.2), p.power());
    Profile a = new Profile(), b = new Profile();
    a.bag[1] = b.bag[1] = 100;
    b.activePotions.put("GOLD", System.currentTimeMillis() + 60_000);
    assertEquals(Math.round(Economy.sell(a) * 1.2), Economy.sell(b));
  }

  @Test
  void herbsFromTreesAndWiki() {
    Profile p = new Profile();
    Forestry.harvest(p, 0, .99, .5);
    assertEquals(0, Alchemy.ingredient(p, Alchemy.Ingredient.KRAUT));
    Forestry.harvest(p, 0, .99, .9);
    assertEquals(1, Alchemy.ingredient(p, Alchemy.Ingredient.KRAUT));
    assertTrue(Wiki.page("home").children().contains("alchemy"));
    assertEquals(3 + 6 + 1, Wiki.page("alchemy").entries().size());
  }
}
