package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class IndustryTest {
  @Test
  void incompleteContractsConsumeNothing() {
    Profile p = new Profile();
    p.bag[0] = 4;
    p.stock[0] = 5;
    Industry.fulfill(p, 0, 0);
    assertEquals(4, p.bag[0]);
    assertEquals(5, p.stock[0]);
    assertEquals(250, p.money);
    assertEquals(0, p.researchNotes);
  }

  @Test
  void contractConsumesBagAndWarehouseExactlyAndRejectsDuplicateClick() {
    Profile p = new Profile();
    var c = Industry.contract(p, 0);
    p.bag[0] = 10;
    p.stock[0] = 100;
    Industry.fulfill(p, 0, 0);
    assertEquals(0, p.bag[0]);
    assertEquals(110 - c.amount(), p.stock[0]);
    assertEquals(250 + c.money(), p.money);
    assertEquals(c.notes(), p.researchNotes);
    long money = p.money;
    Industry.fulfill(p, 0, 0);
    assertEquals(money, p.money);
    assertEquals(1, p.contracts[0]);
  }

  @Test
  void barsAndPartsContractsUseTheirOwnInputs() {
    Profile p = new Profile();
    p.bars[0] = 100;
    p.monsterParts[0] = 100;
    p.stock[0] = 100;
    Industry.fulfill(p, 1, 0);
    Industry.fulfill(p, 2, 0);
    assertEquals(84, p.bars[0]);
    assertEquals(92, p.monsterParts[0]);
    assertEquals(100, p.stock[0]);
    assertEquals(2, p.orders);
  }

  @Test
  void discoveriesAreSingleClaimAndLockedZonesCannotPay() {
    Profile p = new Profile();
    Industry.discover(p, 3);
    assertEquals(250, p.money);
    Industry.discover(p, 0);
    Industry.discover(p, 0);
    assertEquals(500, p.money);
    assertEquals(3, p.researchNotes);
    Industry.discover(p, 1);
    Industry.discover(p, 2);
    assertEquals(1, p.relics);
    assertEquals(9, p.researchNotes);
  }

  @Test
  void researchRequiresAllResourcesAndAppliesOneLevel() {
    Profile p = new Profile();
    p.money = 5000;
    p.researchNotes = 10;
    Industry.research(p, 0);
    assertEquals(5000, p.money);
    assertEquals(0, p.research[0]);
    p.bars[0] = 4;
    double speed = ToolStats.of(p, 0, false).speed();
    Industry.research(p, 0);
    assertEquals(3500, p.money);
    assertEquals(7, p.researchNotes);
    assertEquals(0, p.bars[0]);
    assertEquals(speed * 1.08, ToolStats.of(p, 0, false).speed(), .00001);
  }

  @Test
  void legacyCollectionRewardCannotBeClaimedAgain() {
    Profile p = new Profile();
    p.collectionClaimed[0] = true;
    p.collected[0] = 500;
    Industry.collection(p, 0);
    assertEquals(0, p.relics);
    p.collected[0] = 2000;
    Industry.collection(p, 0);
    assertEquals(5, p.relics);
    assertEquals(2, p.collectionTiers[0]);
    Industry.collection(p, 0);
    assertEquals(5, p.relics);
  }

  @Test
  void pausedWorkerHasNoCostsOrOfflineProduction() {
    Profile p = new Profile();
    p.lastSettled = 1;
    p.budget = 1000;
    p.fuel = 100;
    var w = new Profile.Worker("Borin", Profile.Job.MINER, 0);
    w.paused = true;
    p.workers.add(w);
    Production.settle(p, 60001);
    assertEquals(0, p.stock[0]);
    assertEquals(1000, p.budget);
    assertEquals(100, p.fuel);
    w.paused = false;
    p.research[2] = 2;
    Production.settle(p, 120001);
    assertEquals(4, p.stock[0]);
    assertEquals(997, p.budget);
  }

  @Test
  void coolingAndLogisticsAffectRealLimits() {
    Profile p = new Profile();
    p.research[1] = 5;
    p.research[4] = 5;
    assertEquals(12, ToolStats.of(p, 0, false).cooling());
    assertEquals(3, ToolStats.of(p, 0, false).heatPerOre());
    assertEquals(2160, p.stockCapacity());
    assertEquals(13, p.offlineHours());
  }

  @Test
  void researchedProductionIsIdenticalAcrossOnlineOfflineSettlement() {
    Profile a = new Profile(), b = new Profile();
    for (Profile p : new Profile[] {a, b}) {
      p.lastSettled = 1;
      p.budget = 10000;
      p.fuel = 1000;
      p.furnace = 2;
      p.research[2] = 2;
      p.research[3] = 3;
      for (var job : Profile.Job.values()) p.workers.add(new Profile.Worker(job.name(), job, 0));
    }
    Production.settle(a, 3600001);
    for (int i = 1; i <= 60; i++) Production.settle(b, 1 + i * 60000L);
    assertEquals(a.money, b.money);
    assertEquals(a.budget, b.budget);
    assertEquals(a.fuel, b.fuel);
    assertArrayEquals(a.stock, b.stock);
    assertArrayEquals(a.bars, b.bars);
  }
}
