package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class IndustryTest {
  @Test
  void incompleteContractsConsumeNothing() {
    Profile p = new Profile();
    p.bag[0] = 4;
    p.stock[0] = 5;
    Industry.fulfill(p, 0, 0);
    assertEquals(4, p.bag[0]);
    assertEquals(5, p.stock[0]);
    assertEquals(250, p.money);
    assertEquals(0, p.researchNotes);
  }

  @Test
  void contractConsumesBagAndWarehouseExactlyAndRejectsDuplicateClick() {
    Profile p = new Profile();
    var c = Industry.contract(p, 0);
    p.bag[0] = 10;
    p.stock[0] = 100;
    Industry.fulfill(p, 0, 0);
    assertEquals(0, p.bag[0]);
    assertEquals(110 - c.amount(), p.stock[0]);
    assertEquals(250 + c.money(), p.money);
    assertEquals(c.notes(), p.researchNotes);
    long money = p.money;
    Industry.fulfill(p, 0, 0);
    assertEquals(money, p.money);
    assertEquals(1, p.contracts[0]);
  }

  @Test
  void barsAndPartsContractsUseTheirOwnInputs() {
    Profile p = new Profile();
    p.bars[0] = 100;
    p.monsterParts[0] = 100;
    p.stock[0] = 100;
    Industry.fulfill(p, 1, 0);
    Industry.fulfill(p, 2, 0);
    assertEquals(84, p.bars[0]);
    assertEquals(92, p.monsterParts[0]);
    assertEquals(100, p.stock[0]);
    assertEquals(2, p.orders);
  }

  @Test
  void discoveriesAreSingleClaimAndLockedZonesCannotPay() {
    Profile p = new Profile();
    Industry.discover(p, 3);
    assertEquals(250, p.money);
    Industry.discover(p, 0);
    Industry.discover(p, 0);
    assertEquals(500, p.money);
    assertEquals(3, p.researchNotes);
    Industry.discover(p, 1);
    Industry.discover(p, 2);
    assertEquals(1, p.relics);
    assertEquals(9, p.researchNotes);
  }

  @Test
  void researchRequiresAllResourcesAndAppliesOneLevel() {
    Profile p = new Profile();
    p.money = 5000;
    p.researchNotes = 10;
    Industry.research(p, 0);
    assertEquals(5000, p.money);
    assertEquals(0, p.research[0]);
    p.bars[0] = 4;
    double speed = ToolStats.of(p, 0, false).speed();
    Industry.research(p, 0);
    assertEquals(3500, p.money);
    assertEquals(7, p.researchNotes);
    assertEquals(0, p.bars[0]);
    assertEquals(speed * 1.08, ToolStats.of(p, 0, false).speed(), .00001);
  }

  @Test
  void legacyCollectionRewardCannotBeClaimedAgain() {
    Profile p = new Profile();
    p.collectionClaimed[0] = true;
    p.collected[0] = 500;
    Industry.collection(p, 0);
    assertEquals(0, p.relics);
    p.collected[0] = 2000;
    Industry.collection(p, 0);
    assertEquals(5, p.relics);
    assertEquals(2, p.collectionTiers[0]);
    Industry.collection(p, 0);
    assertEquals(5, p.relics);
  }

  @Test
  void pausedWorkerHasNoCostsOrOfflineProduction() {
    Profile p = new Profile();
    p.lastSettled = 1;
    p.budget = 1000;
    p.fuel = 100;
    var w = new Profile.Worker("Borin", Profile.Job.MINER, 0);
    w.paused = true;
    p.workers.add(w);
    Production.settle(p, 60001);
    assertEquals(0, p.stock[0]);
    assertEquals(1000, p.budget);
    assertEquals(100, p.fuel);
    w.paused = false;
    p.research[2] = 2;
    Production.settle(p, 120001);
    // Rate 0.5 + 2 × 0.25 = 1 ore; wage 3 base + 20 % of 12 $ ore value.
    assertEquals(1, p.stock[0]);
    assertEquals(995, p.budget);
  }

  @Test
  void coolingAndLogisticsAffectRealLimits() {
    Profile p = new Profile();
    p.research[1] = 5;
    p.research[4] = 5;
    assertEquals(12, ToolStats.of(p, 0, false).cooling());
    assertEquals(3, ToolStats.of(p, 0, false).heatPerOre());
    assertEquals(2160, p.stockCapacity());
    assertEquals(11, p.offlineHours());
  }

  @Test
  void researchedProductionIsIdenticalAcrossOnlineOfflineSettlement() {
    Profile a = new Profile(), b = new Profile();
    for (Profile p : new Profile[] {a, b}) {
      p.lastSettled = 1;
      p.budget = 10000;
      p.fuel = 1000;
      p.furnace = 2;
      p.research[2] = 2;
      p.research[3] = 3;
      for (var job : Profile.Job.values()) p.workers.add(new Profile.Worker(job.name(), job, 0));
    }
    Production.settle(a, 3600001);
    for (int i = 1; i <= 60; i++) Production.settle(b, 1 + i * 60000L);
    assertEquals(a.money, b.money);
    assertEquals(a.budget, b.budget);
    assertEquals(a.fuel, b.fuel);
    assertArrayEquals(a.stock, b.stock);
    assertArrayEquals(a.bars, b.bars);
  }

  @Test
  void ironCanStillBeSmeltedAfterUnlockingDeeperZones() {
    Profile p = new Profile();
    p.zone = 2;
    p.furnace = 1;
    p.fuel = 100;
    p.stock[0] = 10;
    String message = Industry.smelt(p, 0, 32, () -> 1);
    assertEquals(5, p.bars[0]);
    assertEquals(0, p.stock[0]);
    assertEquals(95, p.fuel);
    assertEquals(0, p.bars[2]);
    assertTrue(message.startsWith("5 Eisenbarren geschmolzen"), message);
  }

  @Test
  void smeltingIsLimitedByChoiceOreAndFuelAndExplainsBlocks() {
    Profile p = new Profile();
    p.zone = 1;
    p.stock[1] = 100;
    assertTrue(Industry.smelt(p, 1, 32, () -> 1).contains("Schmelze"));
    p.furnace = 1;
    assertTrue(Industry.smelt(p, 1, 32, () -> 1).contains("Brennstoff"));
    p.fuel = 40;
    Industry.smelt(p, 1, 32, () -> 1);
    assertEquals(32, p.bars[1]);
    Industry.smelt(p, 1, Long.MAX_VALUE, () -> 1);
    assertEquals(40, p.bars[1]);
    assertEquals(0, p.fuel);
    assertEquals(20, p.stock[1]);
    assertTrue(Industry.smelt(p, 2, 32, () -> 1).contains("gesperrt"));
    assertTrue(Industry.smelt(p, 0, 32, () -> 1).contains("Zu wenig Eisenerz"));
    assertEquals(40, p.manualSmelted);
  }

  @Test
  void fuelSavingsAndBarNames() {
    Profile p = new Profile();
    p.furnace = 1;
    p.fuel = 10;
    p.stock[0] = 20;
    Gear.Item ring = new Gear.Item();
    ring.slot = Gear.Slot.RING;
    ring.efficiency = .5;
    p.gear.add(ring);
    Gear.equip(p, ring.id);
    Industry.smelt(p, 0, 10, () -> 0);
    assertEquals(10, p.bars[0]);
    assertEquals(10, p.fuel);
    assertEquals("Eisenbarren", Industry.barName(0));
    assertEquals("Leerenbarren", Industry.barName(6));
  }

  @Test
  void oreOnlySaleKeepsBars() {
    Profile p = new Profile();
    long before = p.money;
    p.stock[0] = 10;
    p.bag[0] = 5;
    p.bars[0] = 7;
    long earned = Economy.sell(p, false);
    assertEquals(15 * Zone.at(0).orePrice, earned);
    assertEquals(before + earned, p.money);
    assertEquals(7, p.bars[0]);
    assertEquals(0, p.stock[0] + p.bag[0]);
    assertEquals(0, p.soldBars);
    assertEquals(7 * Zone.at(0).barPrice, Economy.sell(p));
    assertEquals(0, p.bars[0]);
  }

  @Test
  void researchReportsItsTotalEffect() {
    Profile p = new Profile();
    p.money = 100_000;
    p.researchNotes = 10;
    p.bars[0] = 12;
    String first = Industry.research(p, 0);
    assertTrue(first.endsWith("jetzt +8 % Abbautempo."), first);
    p.tool = 1;
    Industry.research(p, 0);
    assertEquals("+16 % Abbautempo", Industry.researchTotal(p, 0));
    assertEquals("+240 Lagerplätze, +1 Offline-Stunden", totalAfterOne(4));
  }

  private static String totalAfterOne(int track) {
    Profile p = new Profile();
    p.research[track] = 1;
    return Industry.researchTotal(p, track);
  }
}
