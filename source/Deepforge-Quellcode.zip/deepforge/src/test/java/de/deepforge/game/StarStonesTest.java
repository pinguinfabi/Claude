package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Random;
import org.junit.jupiter.api.Test;

class StarStonesTest {
  @Test
  void tenPercentPlusTwelveNinetyPercentBroken() {
    Random r = new Random(11);
    int won = 0, broken = 0;
    for (int n = 0; n < 5000; n++) {
      Profile p = new Profile();
      Gear.Item i = Gear.roll(1, Gear.Rarity.EPIC, r);
      p.gear.add(i);
      p.equipped.put(i.slot.name(), i.id);
      GearPresets.save(p, 0);
      p.starStones = 1;
      String msg = StarStones.use(p, i.id, r);
      assertEquals(0, p.starStones);
      if (msg.startsWith("✦")) {
        won++;
        assertEquals(12, i.level);
      } else {
        broken++;
        assertTrue(p.gear.isEmpty());
        assertFalse(p.equipped.containsValue(i.id));
        assertNull(GearPresets.usedBy(p, i.id));
      }
    }
    assertTrue(won > 400 && won < 600, "about 10 %: " + won);
    assertEquals(5000, won + broken);
  }

  @Test
  void needsAStoneAndStopsAtTwelve() {
    Profile p = new Profile();
    Gear.Item i = Gear.roll(0, Gear.Rarity.RARE, new Random(1));
    p.gear.add(i);
    assertTrue(StarStones.use(p, i.id, new Random(1)).startsWith("Kein Sternenstein"));
    i.level = 12;
    p.starStones = 1;
    assertTrue(StarStones.use(p, i.id, new Random(1)).contains("schon +12"));
    assertEquals(1, p.starStones);
    int drops = 0;
    Random r = new Random(4);
    for (int n = 0; n < 10_000; n++) if (StarStones.maybeDrop(p, r)) drops++;
    assertTrue(drops > 150 && drops < 250, "2 % drop: " + drops);
  }
}
