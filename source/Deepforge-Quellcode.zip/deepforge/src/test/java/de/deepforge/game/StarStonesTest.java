package de.deepforge.game;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Random;
import org.junit.jupiter.api.Test;

class StarStonesTest {
  @Test
  void tenPercentPlusTwelveNinetyPercentBroken() {
    Random r = new Random(11);
    int won = 0, broken = 0;
    for (int n = 0; n < 5000; n++) {
      Profile p = new Profile();
      Gear.Item i = Gear.roll(1, Gear.Rarity.EPIC, r);
      p.gear.add(i);
      p.equipped.put(i.slot.name(), i.id);
      GearPresets.save(p, 0);
      p.starStones = 1;
      String msg = StarStones.use(p, i.id, r);
      assertEquals(0, p.starStones);
      if (msg.startsWith("✦")) {
        won++;
        assertEquals(StarStones.LEVEL, i.level);
      } else {
        broken++;
        assertTrue(p.gear.isEmpty());
        assertFalse(p.equipped.containsValue(i.id));
        assertNull(GearPresets.usedBy(p, i.id));
      }
    }
    assertTrue(won > 400 && won < 600, "about 10 %: " + won);
    assertEquals(5000, won + broken);
  }

  @Test
  void needsAStoneAndStopsAtTwelve() {
    Profile p = new Profile();
    Gear.Item i = Gear.roll(0, Gear.Rarity.RARE, new Random(1));
    p.gear.add(i);
    assertTrue(StarStones.use(p, i.id, new Random(1)).startsWith("Kein Sternenstein"));
    i.level = StarStones.LEVEL;
    p.starStones = 1;
    assertTrue(StarStones.use(p, i.id, new Random(1)).contains("schon +" + StarStones.LEVEL));
    assertEquals(1, p.starStones);
    int drops = 0;
    Random r = new Random(4);
    for (int n = 0; n < 10_000; n++) if (StarStones.maybeDrop(p, r)) drops++;
    assertTrue(drops > 150 && drops < 250, "2 % drop: " + drops);
  }

  @Test
  void starForgedGearCountsDoubleAndAbilitiesHitHarder() {
    Profile p = new Profile();
    Gear.Item w = Gear.roll(3, Gear.Rarity.EPIC, new Random(2));
    w.slot = Gear.Slot.WEAPON;
    w.damage = 20;
    p.gear.add(w);
    p.equipped.put("WEAPON", w.id);
    w.level = 10;
    double ten = Gear.stats(p).damage() - Gear.stats(new Profile()).damage();
    double power = WeaponAbilities.power(w);
    w.level = StarStones.LEVEL;
    double twelve = Gear.stats(p).damage() - Gear.stats(new Profile()).damage();
    assertTrue(twelve > ten * 2, "+11 more than doubles the item's damage: " + ten + " → " + twelve);
    assertEquals(power * 1.5, WeaponAbilities.power(w), 1e-9);
  }

  @Test
  void theEndgameGoalChainContinuesAfterAllMines() {
    Profile p = new Profile();
    p.quest = 8;
    p.zone = 6;
    assertTrue(Economy.quest(p).startsWith("Meilenstein"));
    assertEquals(9, p.quest);
    assertEquals("Besiege den Boss im Leerenbruch", Economy.questText(p.quest));
    assertTrue(Economy.quest(p).startsWith("Ziel noch nicht erreicht"));
    p.quest = Economy.QUESTS;
    assertTrue(Economy.quest(p).startsWith("Alle Ziele erreicht"));
    assertTrue(Economy.questText(Economy.QUESTS - 1).contains("Urboss"));
    assertTrue(Economy.questText(Economy.QUESTS - 1).contains("Weltenkern"));
  }

  @Test
  void starForgedArmourShieldsAndWeaponsStrike() {
    Profile p = new Profile();
    for (Gear.Slot slot : new Gear.Slot[] {Gear.Slot.HELMET, Gear.Slot.CHEST, Gear.Slot.LEGS, Gear.Slot.BOOTS, Gear.Slot.RING, Gear.Slot.RING2}) {
      Gear.Item i = new Gear.Item();
      i.slot = slot;
      i.level = StarStones.LEVEL;
      p.gear.add(i);
      p.equipped.put(slot.name(), i.id);
    }
    assertEquals(.2, StarStones.shieldChance(p), 1e-9, "six pieces, capped at 20 %");
    assertFalse(StarStones.starWeapon(p));
    Gear.Item w = new Gear.Item();
    w.level = StarStones.LEVEL;
    p.gear.add(w);
    p.equipped.put("WEAPON", w.id);
    assertTrue(StarStones.starWeapon(p));
    assertEquals(11, StarStones.LEVEL, "one step above the normal maximum of +10");
  }
}
