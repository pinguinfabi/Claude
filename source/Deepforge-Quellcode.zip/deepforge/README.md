# Deepforge 0.1.0 — Entwicklungsfassung für Paper 1.21.8

Ein Minecraft-Mining-RPG mit eigener Welt, echten abbaubaren Blöcken, sieben Gebietsstufen, Wirtschaft, Upgrades, Kämpfen und einer separat berechneten Arbeiterproduktion. Kein Browser-Spiel und keine Client-Mod.

**Status:** kompilierter Entwicklungsstand mit automatisierten Tests für Wirtschaft, Offline-Produktion, Ausrüstung, Bossregeln und SQLite-Persistenz. Die Kampf- und Beuteerweiterung ist implementiert; Bedienung und genaue Regeln stehen in KAMPF-UPDATE.md. Der Start auf Paper 1.21.8 Build 60 mit Citizens Build 3887 wurde inzwischen geprüft; die Abnahme mit einem Minecraft-Client steht noch aus. Diese Version ist eine technische Grundlage und ein erster zusammenhängender Spielablauf; sie ist nicht das fertig ausbalancierte gesamte Langzeitspiel aus dem Konzept.

## Installation

**Neu: TAB & Auto-Einstieg.** Spieler betreten Deepforge beim Login automatisch. TAB-Liste und rechte Infotafel verwenden das Varo-Netzwerkdesign mit LuckPerms-Rangrechten, Farben und Sortierung. Bestehende Konfigurationen müssen für die Aktivierung nicht ersetzt werden. Details: [TAB-UND-AUTOLOGIN.md](TAB-UND-AUTOLOGIN.md).

**Neu: Wald & Menüführung.** Teich mit Steg, Waldsaum, Eingangstor und Holzkran ergänzen den Forst. Das Hauptmenü ist in sechs Bereiche aufgeteilt. Holzverarbeitung und Upgrades haben eigene Seiten mit Mengen, Kosten und Voraussetzungen; Arbeitsgebiete lassen sich direkt auswählen. Details: [WALD-UND-MENUES.md](WALD-UND-MENUES.md).

**Neu: Glück & Holzfäller.** Erz- und Holzglück steigen von 1,0× in 0,1×-Schritten bis 2,0×. Östlich des Dorfes stehen zwölf nachwachsende Forstbäume und ein Sägewerk. Eigene Forstaxt, Holz-/Brettverkauf, Harz, Axt-/Lagerupgrades und Lieferaufträge: `/df forestry`. Einzelheiten: [HOLZ-UND-GLUECK.md](HOLZ-UND-GLUECK.md).

**Neu: Abenteuer-Update.** Zwölf spielbare Lernziele bei Vorarbeiter Jorin (`/df tutorial`), vier Artefakte mit Kampfeffekten/Bergbaubonus, drei Rüstungssets, freiwillige Dungeonprüfungen, Gefangenenrettung und eine Schlüsselschatzkammer. Das Abenteuerbuch (`/df journal`) zeigt Fundorte und Herstellungsrezepte. Erkämpfte Trophäen, Werkstattränge und Händlerin Mira machen den Fortschritt im Dorf sichtbar. Details: [ABENTEUER-UPDATE.md](ABENTEUER-UPDATE.md).

**Neu: Gewölbe in der Welt.** Ein Portalhaus hinter dem Markt öffnet das gestaltete Dungeonmenü. Drei verbundene Hallen, zwei Tore und persönliche Runensegen ersetzen den Ablauf in einer einzelnen Arena. Überlebende bleiben nach jeder Welle an ihrer Position. Details: [DUNGEON-WELT.md](DUNGEON-WELT.md).

**Neues Bossbalancing:** deutlich mehr Gegnerleben, stärkere Gruppenskalierung, angekündigter Rundumschlag gegen Rücken-Spam und Standfestigkeit nach Haltungsbrüchen. Details: [BOSS-BALANCE.md](BOSS-BALANCE.md).

**Neu: dauerhafte Dungeonlevel und Heilung.** Jeder abgeschlossene Lauf gibt +1 Level; höhere Level verändern Wellen, Eliten, Angriffsmuster und Beutestärke. Lebenssplitter heilen auch im Bosskampf (`/df heal`). Details: [DUNGEON-PROGRESSION.md](DUNGEON-PROGRESSION.md).

Aktueller Ausbau: **Party-Dungeons für 1–4 Spieler**, fünf bis acht Wellen je nach Level, zwei Runenrätsel, drei Schwierigkeiten, persönliche Abschlussbeute und schneller Nahkampf ohne Schlagaufladung. Einstieg: `/df dungeon` oder Handbuch. Gruppen: `/df party create`, `invite <Name>`, `accept`, `ready`. Details und Grenzen: [PARTY-DUNGEONS.md](PARTY-DUNGEONS.md).

1. Einen separaten **Paper-1.21.8-Testserver mit Java 21** vorbereiten. Download: https://papermc.io/downloads/paper . Andere Minecraft-Versionen werden von dieser Pluginversion ausdrücklich abgelehnt.
2. `deepforge-0.1.0.jar` in dessen `plugins`-Ordner kopieren.
3. Für Spieler-NPCs zusätzlich eine vollständige **Citizens-Distribution mit expliziter 1.21.8-Unterstützung** installieren. Die Integration wurde gegen Citizens API 2.0.39 entwickelt; eine API-/Maven-main-JAR allein enthält nicht die benötigten Serveradapter. Offizielle Downloads: https://wiki.citizensnpcs.co/Downloads . Historische Kompatibilität: https://wiki.citizensnpcs.co/Versions . Citizens ist nicht in diesem Download enthalten. Ohne Citizens laufen die übrigen Systeme; neue Arbeiter können dann nicht eingestellt werden. Bereits gespeicherte Produktion wird weiter abgerechnet.
4. `Deepforge-ResourcePack.zip` im Minecraft-Client unter Ressourcenpakete aktivieren. Anschließend `/df pack local` verwenden, um den eigenen Menürahmen einzuschalten. Der Befehl installiert das Paket nicht.
5. Server starten, mit Minecraft Java **1.21.8** verbinden und `/df start` ausführen. Vier freie Inventarplätze werden für das Grundwerkzeug benötigt; Lebenssplitter brauchen gegebenenfalls einen weiteren. Das persönliche Minengelände wird beim ersten Besuch schrittweise aufgebaut.

Für öffentliche Server: Die ZIP auf einer eigenen direkten HTTPS-Download-Adresse bereitstellen. In `plugins/Deepforge/config.yml` `resource-pack.url` und den Inhalt von `pack.sha1` eintragen. Anschließend den Server regulär neu starten. Das Plugin bietet das Paket beim Eintritt an; `required: true` setzt die Annahme voraus. Bestehende Ressourcenpakete müssen manuell zusammengeführt werden.

Für lokale Tests sind zusätzlich HTTP-Adressen auf `localhost`, `127.0.0.1` und `[::1]` zulässig. Der eingerichtete lokale Testserver liefert das Paket unter `http://127.0.0.1:8765/Deepforge-ResourcePack.zip` aus.

`deepforge` ist eine eigene Welt. Existiert unter diesem Namen bereits eine Welt ohne Eigentumsmarkierung, verweigert das Plugin deren Verwendung; in diesem Fall einen anderen Namen konfigurieren.

## Aktuelles Korrektur- und Jagdupdate

Monstertexturen für den Minecraft-Atlas korrigiert, Handmodelle für beide Hände neu ausgerichtet und Schienenübergänge für Monster freigegeben. Neu: Dolch-Rückenangriffe, gerichtete Panzerabwehr und sieben wiederholbare Jagdaufträge im Beutebuch. Details: TEXTUR-UND-KAMPF-FIX.md.

## Spielen

| Aktion | Bedienung |
|---|---|
| Beginnen | `/df start` |
| Zum eigenen Betrieb | `/df home` |
| Handbuch | Rechtsklick mit Handbuch oder `/df menu` |
| Mining | Am Aufzug Gebiet betreten; Erzadern in den Stollen mit dem Bohrer abbauen |
| Überladung | Rechtsklick mit Bohrer, 8 Sekunden Bonus, 45 Sekunden Abklingzeit |
| Scanner | Sneak + Rechtsklick mit Bohrer |
| Boss | Altar der hinteren Bosskammer rechtsklicken; Normal/Veteran/Alptraum wählen |
| Charakter | `/df stats` |
| Beutebeutel | `/df loot` |
| Waffenfähigkeit | Rechtsklick mit Waffe |
| Ausweichen | Sneak + Rechtsklick mit Waffe |
| Verwalten | Arbeitsstation oder eigenen Arbeiter rechtsklicken |
| Verlassen | `/df leave`, Rückkehr zum gespeicherten Ausgangspunkt |
| Hilfe | `/df help` |
| Testgeld, nur OP/Administrator | `/df admin money 10000` |

Die Werkbank liegt nordwestlich, das Lager nordöstlich, die Schmelze südwestlich, die Mannschaftsstation südöstlich. Aufzug im Süden und Handelsstation im Norden. Normale Inventargegenstände werden beim Eintritt nicht gelöscht; die drei markierten Spielwerkzeuge werden bei regulärem Austritt wieder entfernt.

## Enthalten

- Persönliches generiertes Minengelände je Spieler, vier Gebäude, Arbeitsstationen und sieben übereinanderliegende Höhlennetze.
- Sieben eigene Erzblöcke mit 32-Pixel-Texturen; Kristall-, Glut- und Leerenerz sind animiert.
- Eigenständige 3D-JSON-Modelle für Bohrer, Klinge, Brecher, Schmelzofen und Kiste; eigene Menü- und Gegenstandssymbole.
- Minecrafts natives Gedrückthalten zum Abbauen. Werkzeug, Gebiet, Modul und Überladung beeinflussen die Geschwindigkeit.
- Virtueller Rucksack, endliche Lagerkapazität, Erzwiederkehr, Hitze, Scanner, seltene Reliktfunde und drei Werkzeugmodule.
- Verbesserungen für Werkzeug, Waffe, Schutztraining, Rucksack, Lager, Schmelze und Unterkunft. Lager- und Schmelzausbau ergänzen sichtbare Modelle.
- Drei normale Gegnertypen und sieben thematische Monstermodelle aus animierten ItemDisplay-Teilen über Husk-Trefferboxen. Bosse mit drei Phasen, sechs Angriffstypen, Haltungsbruch, Beschwörungen und drei Schwierigkeitsstufen.
- Dauerhafter Beutebeutel, zehn Ausrüstungsplätze, fünf Waffentypen, zufällige Zusatzwerte, Herkunftssets, sieben benannte Gegenstände, legendäre und mythische Zusatzdrops.
- Favoritenschutz, Gegenstandsvergleich, Aufwertung bis +10, Krit-Neuschmieden, Zerlegen und gezielte Bossrezepte. Garantierte Aufwertung nach neun Bossabschlüssen ohne epischen Hauptwurf.
- Gebietszugänge benötigen Bossfortschritt, Werkzeugstufe und Geld. Pilz-/Tiefengebiet haben Schutzanforderungen, Magma beeinflusst Hitze.
- Drei Arbeiterberufe: Bergarbeiter, Schmelzer, Händler. Anstellung, fünf Stufen, Arbeitserfahrung, Gebietszuweisung und Spezialisierung.
- Mit Citizens: sichtbare Spieler-NPCs mit Ausrüstung, Arbeitsbewegungen, Laufwegen und anklickbarer Verwaltung. Skins per Citizens-Namensauflösung oder konfigurierbaren signierten Texturen. Die beigelegten Modelle sind keine fertig hochgeladenen NPC-Skins.
- Online-/Offline-Produktion mit Brennstoff, Löhnen, Budget, endlichen Lagern und freigeschaltetem automatischem Verkauf.
- Manuelles Verarbeiten und Verkaufen, wiederholbare Lieferaufträge, acht Startmeilensteine und Sammlungsbelohnungen.
- Actionbar-HUD mit Kampfwerten, Charakter-/Beute-/Bossmenüs und optionaler Ressourcenpaket-Menürahmen. Der HUD ersetzt keine vorhandene Server-Scoreboard-Anzeige.
- SQLite mit WAL und FULL-Synchronisierung. Währung, virtuelle Materialien und Abrechnungszeitpunkt werden zusammen gespeichert.
- Besitz-/Gebietsschutz in der Spielwelt, unterbundene Blockzerstörung außerhalb der Erzflächen, keine normalen Mob-Drops und kein PvP.

## Offline-Produktion im Detail

Produktion läuft in diskreten 60-Sekunden-Schritten. Pro Schritt werden zuerst Förderer, dann Schmelzer, dann Händler ausgewertet. Ihre Anstellungsreihenfolge ändert die Kette nicht. Online erfolgt die Abrechnung periodisch und vor Verwaltungsaktionen; beim Login wird die vergangene Zeit nachgetragen.

Ein Bergarbeiter auf Stufe 1 produziert 2 Erze pro Arbeitsminute. Eine erfolgreiche Arbeitsminute kostet 3 Dollar Betriebsbudget und 1 Brennstoff. Ein Schmelzer wandelt jeweils 2 Erze in 1 Barren um, ebenfalls gegen Brennstoff und Lohn. Händler verkaufen höchstens ihre Durchsatzmenge, bevorzugen Barren und brauchen nur ihren Lohn. Die Raten sind erste Balancewerte.

Beispiel: Ein einzelner Stufe-1-Förderer produziert in sechs ausreichend versorgten Stunden 720 Erze, verbraucht 360 Brennstoff und 1.080 Dollar Lohn. **Das ist Material, kein automatisch ausgezahltes Geld.** Ohne Händler verbleibt es im Lager.

Die maximale nachberechnete Abwesenheit beträgt anfangs 8 Stunden. Jede Lagerstufe ergänzt 2 Stunden, maximal 24. Tatsächliche Produktion endet früher bei fehlendem Budget, Brennstoff oder Lagerplatz. Stopps verursachen keine laufenden Kosten. Nicht genutzte Zeit oberhalb des Limits verfällt und kann nicht durch erneutes Einloggen beansprucht werden.

Der Abrechnungszeitpunkt wird zusammen mit dem Ergebnis in einer SQLite-Zeile geschrieben. Damit bringt ein wiederholter Login für denselben Zeitraum keinen zweiten Ertrag. Es handelt sich um ein Einzelserver-System; dieselbe Datenbank darf nicht von mehreren Minecraft-Servern gleichzeitig verwaltet werden.

Arbeiteranimation und wirtschaftliche Berechnung sind getrennt. Die NPCs müssen nicht offline geladene Chunks belegen. Aktuell sind Figuren nur während der Sitzung ihres Besitzers gespawnt; ein dauerhafter Besuchermodus für Offline-Betriebe ist noch nicht enthalten.

## Technische Grenzen und nächste Ausbaustufen

Die Oberfläche ist ein detailliert generiertes Bergbaudorf: vier begehbare Hauptgebäude mit Fachwerk, steilen Dächern, Gauben, Werkhöfen und Einrichtung; dazu Marktstände, Brunnen, Lagerkran, Förderturm, Bachbrücke, gemischte Pflasterwege und bewaldete Hügel. Der Untergrund wurde im Minen-Update ebenfalls ersetzt: gewundene Stollen, seitliche Abbaukammern, Rundwege, variable Felsdecken, erreichbare Wandadern und eine erhöhte Holzgalerie. Die sieben Gebiete besitzen eigene Material- und Dekorationsmotive. Details: MINEN-UPDATE.md. Eine Abenteuerwelt mit natürlichen Höhlen, Rätseln, frei platzierbaren Gebäuden und großen öffentlichen Begegnungsgebieten ist noch nicht enthalten.

Das Dorf-Update migriert bereits gebaute alte Grundstücke beim Serverstart. Es ersetzt ausschließlich die Oberfläche; Erzräume und gespeicherte Wirtschaftsdaten werden dabei nicht neu angelegt. Vor dem Update Welt und `plugins/Deepforge` bei gestopptem Server sichern. Der Bau erfolgt über mehrere Ticks; die Versionsmarkierung wird erst nach erfolgreichem Aufbau geschrieben. Währenddessen warten einloggende Spieler auf der Startplattform.

Das HUD verwendet nur normalen Text. Eigene GUI-Zeichen werden vor der Vanilla-Schrift aufgelöst, damit fremde Ressourcenpakete dort keine Rezeptgrafiken einsetzen. Die Darstellung des gehaltenen Werkzeugs wurde verkleinert.

Weitere Konzeptpunkte stehen aus: Spieler-Marktplatz, gemeinsame Expeditionen, zusätzliche Standorte, echte Transportketten/Förderbandlogistik, Transporteur/Raffineriearbeiter/Schmied/Vorarbeiter als eigene Berufe, Rettungs-Questketten, Sprengstoffsystem, Fossilien, weitere individuelle Bossrätsel, sichtbare Rüstungsmodelle sowie dauerhafte Besucherrechte. Dafür sind neue Inhalte und weitere Spieltests nötig.

Custom-Blöcke nutzen reservierte Notenblockzustände (`instrument=bass`, Noten 0 bis 6, `powered=false`). Das ist ein Ressourcenpaket-Verfahren und keine Registrierung neuer nativer Block-IDs. Diese sieben Zustände sehen mit dem Paket auch außerhalb der Spielwelt anders aus; ein anderer Custom-Block-Anbieter darf dieselben Zustände nicht gleichzeitig verwenden. Alle übrigen Notenblockzustände behalten ihr Vanilla-Modell. Maschinenmodelle sind ItemDisplay-Darstellungen; ihre Bedienung erfolgt an den zugehörigen Stationen.

GUI-Ausrichtung und NPC-Navigation müssen auf einem echten Client geprüft werden. Zum Abschalten des texturierten Rahmens `resource-pack.textured-menus: false` setzen. Native Inventarmenüs funktionieren weiterhin.

Schutztraining und die neuen Rüstungsslots liefern Profilwerte; die Slots verändern noch nicht die sichtbare Kleidung des Spielers. Eigene Monsterangriffe verwenden die berechnete RPG-Reduktion. Fremde Survival-Gegenstände und Tränke können andere Teile der Spielbalance beeinflussen; für einen öffentlichen RPG-Server sollte später eine eigene Spielinventar-Isolation ergänzt werden.

## Bauen

Java-21-JDK, Maven 3.9+ und Python 3.10+:

```text
mvn verify
python resourcepack/build_pack.py
python resourcepack/validate_pack.py
```

Windows: `./build.ps1 -JavaHome C:/Pfad/zum/jdk21` lädt bei Bedarf Maven mit Prüfsummenprüfung in `.tools`. Die Python-Skripte benötigen nur die Standardbibliothek.

Ergebnisse: `target/deepforge-0.1.0.jar`, `resourcepack/build/Deepforge-ResourcePack.zip`, `resourcepack/build/pack.sha1`.

Der Pack-Generator ist deterministisch. Alle enthaltenen Pixeltexturen und Modelle wurden für dieses Projekt programmatisch erstellt; externe Bilddownloads sind nicht nötig. Maschinen sind editierbare Minecraft-JSON-Modelle.

## Prüfungen und Abnahme

Automatisiert: 80 Tests insgesamt, darunter Ausrüstung, Beutegarantie, doppelte Kampfbelege, Herstellung, Angriffszonen, Schwierigkeitsfreischaltung und Schema-1-Migration sowie Prüfungen zu Verkäufen, Upgrades, Gebietssperren, Questbelohnungen, Kapazitätsgrenzen, Offline-Limits, Zeitrücklauf, gleichen Zeitstempeln, knappen Vorräten, Produktionsketten und Neustart-Persistenz. Zusätzlich prüft der Ressourcenpaket-Validator JSON-Referenzen, PNG-Header, Modellgrenzen, sämtliche 1.150 Notenblockzustände und die ZIP-Integrität.

Vor einem öffentlichen Einsatz auf einem Testserver prüfen:

1. Eintritt, einmalige Weltgenerierung, Ausgangsinventar und Rückkehr mit `/df leave`.
2. Paketdarstellung bei unterschiedlichen GUI-Skalierungen; normales Halten zum Abbauen, Wiederkehr und voller Rucksack.
3. Besitzschutz mit zwei Spielern, Kampfschaden, Tod, Bosswiederholung und Gebietsfreischaltung.
4. Passenden Citizens-Build laden, Arbeiter einstellen, anklicken, Bewegungen und Skins ansehen.
5. Brennstoff/Budget auffüllen, abmelden, Server stoppen/neustarten, später erneut anmelden. Bericht und Lagerbestand vergleichen; sofortiger zweiter Login darf nichts doppelt vergeben.
6. Gleichzeitige Spielerlast messen und Produktionsraten/Preise anhand echter Spielrunden abstimmen.

Sicherung: Server regulär stoppen und `plugins/Deepforge` sowie die komplette Welt `deepforge` gemeinsam sichern. Nicht nur die SQLite-Hauptdatei eines laufenden WAL-Betriebs kopieren. Kein `/reload` für Welt-/NPC-Plugins.

## Abhängigkeiten

- Paper API: bereitgestellt vom Server, https://docs.papermc.io/paper/
- Citizens API: nur Kompilierungsabhängigkeit; NPC-Laufzeit separat, https://github.com/CitizensDev/Citizens2
- SQLite JDBC 3.49.1.0: im Plugin gebündelt, Apache-2.0/BSD-Hinweise aus dem Originalartefakt.
- Gson 2.11.0: im Plugin gebündelt, Apache-2.0.
- JUnit 5: nur Tests, nicht im Laufzeit-Plugin.

Offizielle Versionsreferenz für Ressourcenpaketformat 64: https://www.minecraft.net/en-us/article/minecraft-java-edition-1-21-7

## Treffer- und Item-Update

Echter Rückstoß für Monster und Bosse, rote Trefferreaktion, schwebende Schadenszahlen mit Krit-/Rücken-/Blockkennzeichnung sowie ausführliche Werte direkt auf Schwert und Bohrer. Handtransformationen an die tatsächliche Minecraft-1.21.8-Renderpipeline angepasst. Änderungen und Prüfgrenzen: [TREFFER-UND-ITEM-UPDATE.md](TREFFER-UND-ITEM-UPDATE.md).

## Arbeiter, Forschung und Erkundung

Bergarbeiter laufen über den Aufzug zu Erzadern unter Tage und zurück zum Grubendepot. Neu: Schichtpausen, klare Arbeiterzustände, kleine Versorgungskäufe, fünf Forschungszweige, drei Auftragsreihen, 21 Fundkisten und drei Sammlungsränge pro Erz. Bedienung und Grenzen: [ARBEITER-UND-INDUSTRIE.md](ARBEITER-UND-INDUSTRIE.md). Befehle: `/df crew`, `/df research`, `/df contracts`, `/df expeditions`.
