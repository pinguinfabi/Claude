param([string]$JavaHome = $env:JAVA_HOME)
$ErrorActionPreference = 'Stop'
if (-not $JavaHome -or -not (Test-Path -LiteralPath (Join-Path $JavaHome 'bin/java.exe'))) {
    throw 'Set JAVA_HOME to a Java 21 JDK, or use ./build.ps1 -JavaHome C:/path/to/jdk21'
}
$env:JAVA_HOME = $JavaHome
$projectDir = $PSScriptRoot
$toolDir = Join-Path $projectDir '.tools'
$mavenDir = Join-Path $toolDir 'apache-maven-3.9.9'
if (-not (Test-Path -LiteralPath $mavenDir)) {
    New-Item -ItemType Directory -Force -Path $toolDir | Out-Null
    $zipPath = Join-Path $toolDir 'maven.zip'
    $baseUrl = 'https://repo.maven.apache.org/maven2/org/apache/maven/apache-maven/3.9.9/apache-maven-3.9.9-bin.zip'
    Invoke-WebRequest -Uri $baseUrl -OutFile $zipPath
    $expected = ((Invoke-WebRequest -Uri "$baseUrl.sha512").Content).Trim().Split(' ')[0]
    if ((Get-FileHash -LiteralPath $zipPath -Algorithm SHA512).Hash -ne $expected) { throw 'Maven checksum mismatch' }
    Expand-Archive -LiteralPath $zipPath -DestinationPath $toolDir -Force
}
Push-Location $projectDir
try {
    & (Join-Path $mavenDir 'bin/mvn.cmd') -B verify
    if ($LASTEXITCODE -ne 0) { throw 'Plugin build/tests failed' }
    python resourcepack/build_pack.py
    if ($LASTEXITCODE -ne 0) { throw 'Resource-pack build failed' }
    python resourcepack/validate_pack.py
    if ($LASTEXITCODE -ne 0) { throw 'Resource-pack validation failed' }
} finally { Pop-Location }
