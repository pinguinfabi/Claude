"""Reproducible original pixel textures and Java 1.21.8 models; Python stdlib only.
No downloaded art, client mods, image libraries or game assets required.
"""
from pathlib import Path
import hashlib, json, random, struct, zipfile, zlib, math

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / 'build'
PACK = BUILD / 'pack'
PACK.mkdir(parents=True, exist_ok=True)
# Remove only the obsolete generated textures; these were outside the vanilla model atlas.
for zone in range(7):
    for kind in ('skin','core'):
        (PACK/f'assets/deepforge/textures/entity/mob_{zone}_{kind}.png').unlink(missing_ok=True)

def js(path, data):
    target = PACK / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

class Pixels:
    def __init__(self, w, h, fill=(0, 0, 0, 0)):
        self.w, self.h = w, h
        self.data = [list(fill) for _ in range(w*h)]
    def set(self, x, y, color):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.data[y*self.w+x] = list(color) if len(color)==4 else [*color,255]
    def rect(self,x0,y0,x1,y1,color):
        for y in range(y0,y1):
            for x in range(x0,x1): self.set(x,y,color)
    def save(self,path):
        target=PACK/path; target.parent.mkdir(parents=True, exist_ok=True)
        raw=b''.join(b'\x00'+bytes(c for pixel in self.data[y*self.w:(y+1)*self.w] for c in pixel) for y in range(self.h))
        def chunk(kind,data): return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
        target.write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',self.w,self.h,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(raw,9))+chunk(b'IEND',b''))

PALETTES={
    'iron':((48,53,58),(206,145,100)), 'crystal':((62,56,73),(166,104,237)),
    'spore':((40,62,45),(125,213,93)), 'abyss':((30,56,70),(75,208,219)),
    'ember':((44,38,40),(251,133,52)), 'relic':((61,56,43),(239,204,100)),
    'void':((40,32,61),(227,110,236))}

def color_shift(c,n): return tuple(max(0,min(255,v+n)) for v in c)

for idx,(name,(stone,ore)) in enumerate(PALETTES.items()):
    im=Pixels(32,64 if name in ('crystal','ember','void') else 32)
    for frame in range(im.h//32):
        rng=random.Random(470+idx)
        for y in range(32):
            for x in range(32): im.set(x,y+frame*32,color_shift(stone,rng.randint(-13,13)))
        for vein in range(13):
            x,y=rng.randrange(2,27),rng.randrange(2,27)
            size=rng.randrange(2,5)
            im.rect(x-1,y-1+frame*32,x+size+1,y+size+1+frame*32,color_shift(stone,-22))
            im.rect(x,y+frame*32,x+size,y+size+frame*32,color_shift(ore,frame*15))
            im.rect(x,y+frame*32,x+size,y+1+frame*32,color_shift(ore,40+frame*8))
            im.set(x+size-1,y+size-1+frame*32,color_shift(ore,-45))
    im.save(Path(f'assets/deepforge/textures/block/{name}_ore.png'))
    if im.h>32: js(f'assets/deepforge/textures/block/{name}_ore.png.mcmeta',{'animation':{'frametime':12,'interpolate':True}})
    js(f'assets/deepforge/models/block/{name}_ore.json',{'parent':'minecraft:block/cube_all','textures':{'all':f'deepforge:block/{name}_ore'}})
    icon=Pixels(16,16)
    for y in range(2,14):
        for x in range(2,14):
            if abs(x-8)+abs(y-8)<8: icon.set(x,y,color_shift(ore,25 if x+y<15 else -30))
    icon.save(Path(f'assets/deepforge/textures/item/ore_{name}.png'))

instruments='harp basedrum snare hat bass flute bell guitar chime xylophone iron_xylophone cow_bell didgeridoo bit banjo pling zombie skeleton creeper dragon wither_skeleton piglin custom_head'.split()
variants={}
for instrument in instruments:
    for note in range(25):
        for powered in ('false','true'):
            model=f'deepforge:block/{list(PALETTES)[note]}_ore' if instrument=='bass' and note<7 and powered=='false' else 'minecraft:block/note_block'
            variants[f'instrument={instrument},note={note},powered={powered}']={'model':model}
js('assets/minecraft/blockstates/note_block.json',{'variants':variants})

metal=Pixels(16,16)
rng=random.Random(812)
for y in range(16):
    for x in range(16): metal.set(x,y,color_shift((67,79,88),rng.randint(-8,8)))
metal.rect(0,0,16,2,(127,141,151));metal.rect(0,14,16,16,(27,33,40))
for x,y in [(2,3),(12,3),(2,11),(12,11)]:metal.rect(x,y,x+2,y+2,(192,144,73))
metal.save(Path('assets/deepforge/textures/block/machine_metal.png'))
copper=Pixels(16,16,(169,103,55,255));copper.rect(0,0,16,2,(232,171,99));copper.rect(0,14,16,16,(84,50,35));copper.save(Path('assets/deepforge/textures/block/copper.png'))
glow=Pixels(16,16,(244,133,40,255));glow.rect(3,3,13,13,(255,211,107));glow.save(Path('assets/deepforge/textures/block/glow.png'))

def cube(a,b,texture='metal'):
    return {'from':a,'to':b,'faces':{d:{'uv':[0,0,16,16],'texture':'#'+texture} for d in ('north','south','east','west','up','down')}}
def model(name,elements):
    js(f'assets/deepforge/models/item/{name}.json',{'textures':{'metal':'deepforge:block/machine_metal','copper':'deepforge:block/copper','glow':'deepforge:block/glow','particle':'deepforge:block/machine_metal'},'elements':elements,'display':{'gui':{'rotation':[25,225,0],'translation':[0,0,0],'scale':[.75,.75,.75]},'thirdperson_righthand':{'rotation':[0,90,0],'translation':[0,2,0],'scale':[.65,.65,.65]},'firstperson_righthand':{'rotation':[0,-90,25],'translation':[0,1,0],'scale':[.44,.44,.44]},'ground':{'scale':[.5,.5,.5]},'fixed':{'scale':[1,1,1]}}})

def held_model(name, grip, scale=.65):
    """Account for ItemInHandLayer's -90 X / 180 Y and ItemTransform's automatic left mirroring."""
    path=PACK/f'assets/deepforge/models/item/{name}.json'
    data=json.loads(path.read_text(encoding='utf8'))
    for perspective in ('firstperson','thirdperson'):
        for hand,sign in [('righthand',1),('lefthand',-1)]:
            gun=name in ('drill','weapon_crossbow')
            rx,ry,rz=((0,25 if name=="drill" else 12,0) if gun else (-8,-12,12)) if perspective=='firstperson' else (90,0,0)
            size=scale if perspective=='firstperson' else min(.8,scale+.12)
            x,y,z=[(v-8)*size for v in grip]
            # Left-hand Y/Z rotations and translation X are mirrored by Minecraft, not the JSON.
            a,b,c=map(math.radians,(ry*sign,rz*sign,rx))
            x,y=x*math.cos(b)-y*math.sin(b),x*math.sin(b)+y*math.cos(b)
            x,z=x*math.cos(a)+z*math.sin(a),-x*math.sin(a)+z*math.cos(a)
            y,z=y*math.cos(c)-z*math.sin(c),y*math.sin(c)+z*math.cos(c)
            anchor=[-sign if gun else sign,2.2 if name=="drill" else 1.5 if gun else 1,-2 if gun else -3] if perspective=='firstperson' else [0,2,-1]
            data['display'][f'{perspective}_{hand}']={'rotation':[rx,ry,rz], 'translation':[round((anchor[0]-x)*sign,4),round(anchor[1]-y,4),round(anchor[2]-z,4)],'scale':[size]*3}
    js(f'assets/deepforge/models/item/{name}.json',data)

model('drill',[cube([5,4,5],[11,12,13]),cube([4,5,3],[12,11,6],'copper'),cube([5,6,0],[11,10,3]),cube([6,7,-2],[10,9,0],'copper'),cube([6,0,9],[9,5,12],'copper'),cube([7,12,7],[9,14,10],'glow')])
model('blade',[cube([7,1,7],[9,6,9],'copper'),cube([4,5,6],[12,7,10],'copper'),cube([6,7,7],[10,18,9]),cube([7,18,7],[9,21,9],'glow')])
held_model('drill',[7.5,2.5,10.5],.60)
held_model('blade',[8,3,8],.56)
model('machine_crusher',[cube([1,0,1],[15,3,15]),cube([3,3,3],[13,12,13]),cube([1,11,1],[15,14,15],'copper'),cube([4,14,4],[12,16,12]),cube([5,5,0],[11,9,3],'glow')])
model('machine_furnace',[cube([1,0,1],[15,2,15],'copper'),cube([2,2,2],[14,14,14]),cube([4,4,1],[12,10,2],'glow'),cube([10,14,9],[13,22,12]),cube([1,12,1],[15,14,15],'copper')])
model('crate',[cube([1,0,1],[15,14,15],'copper'),cube([0,2,0],[16,4,16]),cube([0,10,0],[16,12,16])])

icons={'coin':(232,185,79),'worker':(192,136,91),'shield':(134,170,198),'fuel':(77,86,100),'clock':(100,187,187),'handbook':(190,139,81),'relic':(193,124,238),'scanner':(85,202,175),'close':(209,95,87),'back':(170,185,201)}
for name,color in icons.items():
    im=Pixels(16,16)
    if name in ('coin','clock','scanner'):
        for y in range(16):
            for x in range(16):
                d=(x-7.5)**2+(y-7.5)**2
                if d<43:im.set(x,y,color_shift(color,-40 if d>26 else 0))
        im.rect(7,4,9,11,color_shift(color,65))
        if name=='clock':im.rect(8,8,12,10,color_shift(color,65))
    elif name=='worker':
        im.rect(4,2,12,10,color);im.rect(3,1,13,4,(226,177,68));im.rect(5,5,7,7,(35,42,51));im.rect(9,5,11,7,(35,42,51));im.rect(2,11,14,16,(69,101,125))
    elif name=='close':
        for i in range(3,13):im.rect(i,i,i+2,i+2,color);im.rect(14-i,i,16-i,i+2,color)
    elif name=='back':
        im.rect(4,7,14,10,color)
        for i in range(5):im.rect(2+i,7-i,4+i,10+i,color)
    else:
        im.rect(3,2,13,15,color_shift(color,-40));im.rect(4,2,12,13,color);im.rect(5,4,11,6,color_shift(color,55));im.rect(5,9,10,11,color_shift(color,-25))
    im.save(Path(f'assets/deepforge/textures/item/{name}.png'))

for name in [*icons,*(f'ore_{n}' for n in PALETTES)]:
    js(f'assets/deepforge/models/item/{name}.json',{'parent':'minecraft:item/generated','textures':{'layer0':f'deepforge:item/{name}'}})
for name in [*icons,*(f'ore_{n}' for n in PALETTES),'drill','blade','machine_crusher','machine_furnace','crate']:
    js(f'assets/deepforge/items/{name}.json',{'model':{'type':'minecraft:model','model':f'deepforge:item/{name}'}})

gui=Pixels(176,222,(28,34,42,255));gui.rect(0,0,176,3,(196,144,75));gui.rect(0,219,176,222,(196,144,75));gui.rect(0,0,3,222,(99,77,54));gui.rect(173,0,176,222,(99,77,54));gui.rect(6,5,170,16,(217,186,139))
for row in range(6):
    for col in range(9):
        x,y=7+col*18,17+row*18;gui.rect(x,y,x+18,y+18,(16,21,27));gui.rect(x+1,y+1,x+17,y+17,(52,63,75));gui.rect(x+2,y+2,x+16,y+3,(76,89,103))
for row in range(4):
    for col in range(9):
        x,y=7+col*18,(139+row*18 if row<3 else 197);gui.rect(x,y,x+18,y+18,(17,22,29));gui.rect(x+1,y+1,x+17,y+17,(57,66,78))
gui.save(Path('assets/deepforge/textures/gui/panel.png'))
js('assets/deepforge/font/ui.json',{'providers':[{'type':'space','advances':{'\ue0ff':-8,'\ue0fe':-169}},{'type':'bitmap','file':'deepforge:gui/panel.png','ascent':13,'height':222,'chars':['\ue100']},{'type':'bitmap','file':'deepforge:item/coin.png','ascent':8,'height':8,'chars':['\ue001']},{'type':'reference','id':'minecraft:default'}]})
js('pack.mcmeta',{'pack':{'pack_format':64,'description':'Deepforge · eigene Erze, Maschinen, Werkzeuge und GUI · 1.21.8'}})

icon=Pixels(64,64,(27,33,41,255));icon.rect(4,4,60,60,(178,122,61));icon.rect(8,8,56,56,(39,50,61));icon.rect(27,15,38,49,(199,208,211));icon.rect(16,16,48,26,(207,145,71));icon.save(Path('pack.png'))


# Original segmented monster meshes and five weapon silhouettes for the combat expansion.
def item_definition(name):
    js(f'assets/deepforge/items/{name}.json',{'model':{'type':'minecraft:model','model':f'deepforge:item/{name}'}})

weapons={
 'sword':[cube([7,0,7],[9,6,9],'copper'),cube([3,5,6],[13,7,10],'copper'),cube([6,7,7],[10,23,9]),cube([7,23,7],[9,26,9],'glow')],
 'hammer':[cube([7,0,7],[9,17,9],'copper'),cube([0,16,3],[16,24,13]),cube([-2,17,4],[0,23,12],'copper'),cube([16,17,4],[18,23,12],'copper'),cube([6,18,2],[10,22,3],'glow')],
 'dagger':[cube([7,0,7],[9,6,9],'copper'),cube([5,5,6],[11,7,10],'copper'),cube([6,7,7],[10,14,9]),cube([7,14,7],[9,18,9],'glow')],
 'spear':[cube([7,-8,7],[9,19,9],'copper'),cube([5,18,7],[11,23,9]),cube([6,23,7],[10,27,9]),cube([7,27,7],[9,30,9],'glow')],
 'crossbow':[cube([6,3,0],[10,7,16],'copper'),cube([-3,5,3],[19,8,6]),cube([-4,5,5],[-2,7,10],'copper'),cube([18,5,5],[20,7,10],'copper'),cube([-3,6,10],[19,7,11],'glow'),cube([7,0,12],[9,4,15],'copper')]
}
for style,elements in weapons.items():
    name='weapon_'+style;model(name,elements);item_definition(name)
    held_model(name,[8,2,13.5] if style=='crossbow' else [8,3,8],.42 if style=='spear' else .45 if style=='hammer' else .65 if style=='dagger' else .60 if style=='crossbow' else .56)

for name in ['offhand','helmet','chest','legs','boots','ring','ring2','amulet']:
    im=Pixels(16,16)
    if name.startswith('ring'):
        for y in range(3,13):
            for x in range(3,13):
                d=(x-7.5)**2+(y-7.5)**2
                if 10<d<27:im.set(x,y,(218,165,72))
        im.rect(6,2,10,6,(91,225,203))
    elif name=='helmet':
        im.rect(3,3,13,11,(146,165,173));im.rect(2,6,14,13,(90,110,125));im.rect(4,7,12,11,(31,43,54));im.rect(7,6,9,13,(195,152,83))
    elif name=='chest':
        im.rect(4,3,12,14,(110,139,154));im.rect(1,3,5,8,(177,187,183));im.rect(11,3,15,8,(177,187,183));im.rect(6,6,10,10,(231,174,75))
    elif name=='legs':
        im.rect(3,2,13,7,(151,173,179));im.rect(3,6,7,15,(91,119,139));im.rect(9,6,13,15,(91,119,139))
    elif name=='boots':
        im.rect(3,4,7,13,(129,158,171));im.rect(9,4,13,13,(129,158,171));im.rect(1,11,7,15,(203,152,75));im.rect(9,11,15,15,(203,152,75))
    else:
        im.rect(3,2,13,11,(128,153,165));im.rect(5,11,11,14,(100,130,151));im.rect(7,4,9,12,(228,168,78))
    im.save(Path(f'assets/deepforge/textures/item/gear_{name}.png'))
    js(f'assets/deepforge/models/item/gear_{name}.json',{'parent':'minecraft:item/generated','textures':{'layer0':f'deepforge:item/gear_{name}'}});item_definition('gear_'+name)

colors=[((89,99,102),(255,172,61)),((128,98,170),(148,245,240)),((104,125,73),(223,106,71)),((55,120,125),(96,231,243)),((63,49,46),(255,110,33)),((166,149,108),(251,220,105)),((55,43,78),(217,112,252))]
for zone,(stone,light) in enumerate(colors):
    for kind,base in [('skin',stone),('core',light)]:
        im=Pixels(32,32);rng=random.Random(713+zone)
        for y in range(32):
            for x in range(32):
                n=rng.randrange(-12,13)
                if x%11==0 or y%13==0:n-=20
                im.set(x,y,color_shift(base,n))
        im.save(Path(f'assets/deepforge/textures/item/mobs/mob_{zone}_{kind}.png'))
        # Preserve each creature's material detail during its brief red hit flash.
        for y in range(32):
            for x in range(32):
                im.set(x,y,color_shift((238,85,76) if kind=='skin' else (255,192,139),random.Random(zone*1024+y*32+x).randrange(-18,19)))
        im.save(Path(f'assets/deepforge/textures/item/mobs/mob_{zone}_{kind}_hit.png'))
    meshes={
      'body':[cube([1,0,2],[15,16,14]),cube([0,11,1],[16,15,15],'copper')],
      'head':[cube([2,0,2],[14,12,14]),cube([3,6,1],[6,8,2],'glow'),cube([10,6,1],[13,8,2],'glow')],
      'arm':[cube([3,-5,3],[13,14,13]),cube([1,-7,1],[15,-1,15],'copper')],
      'leg':[cube([3,0,4],[13,14,13]),cube([1,0,0],[15,4,14],'copper')],
      'core':[cube([5,4,6],[11,11,10],'glow')]
    }
    if zone==0:
        meshes['body'] += [cube([-3,10,4],[1,20,12]),cube([15,10,4],[19,20,12])]
        meshes['head'] += [cube([0,10,0],[16,15,16],'copper')]
    elif zone==1:
        meshes['head'] += [cube([0,10,5],[4,23,11],'glow'),cube([6,11,5],[10,27,11]),cube([12,10,5],[16,23,11],'glow')]
        meshes['body'] += [cube([-3,3,5],[1,20,11]),cube([15,3,5],[19,20,11])]
    elif zone==2:
        meshes['head'] += [cube([-5,10,-5],[21,15,21],'copper'),cube([-1,15,-1],[17,19,17]),cube([2,15,1],[6,20,5],'glow'),cube([10,15,9],[14,20,13],'glow')]
        meshes['body'] += [cube([-2,2,5],[2,11,11],'glow'),cube([14,6,5],[18,14,11],'glow')]
    elif zone==3:
        meshes['head'] += [cube([-5,3,6],[2,17,10],'copper'),cube([14,3,6],[21,17,10],'copper')]
        meshes['body'] += [cube([3,2,0],[13,4,2],'glow'),cube([3,7,0],[13,9,2],'glow')]
    elif zone==4:
        meshes['body'] += [cube([5,1,0],[11,15,2],'glow'),cube([-3,12,5],[2,24,11]),cube([14,12,5],[19,24,11])]
        meshes['arm'] += [cube([1,-1,0],[15,3,2],'glow')]
    elif zone==5:
        meshes['head'] += [cube([-1,10,-1],[17,15,17],'copper'),cube([6,15,5],[10,23,11],'glow')]
        meshes['body'] += [cube([3,2,0],[13,4,2],'glow'),cube([3,8,0],[13,10,2],'glow')]
    else:
        meshes['body']=[cube([3,1,4],[13,13,12]),cube([-4,13,5],[0,22,11],'copper'),cube([16,13,5],[20,22,11],'copper'),cube([4,-5,5],[12,-1,11],'glow')]
        meshes['head'] += [cube([-3,8,5],[1,22,11],'glow'),cube([15,8,5],[19,22,11],'glow')]
    for bone,elements in meshes.items():
        name=f'mob_{zone}_{bone}'
        js(f'assets/deepforge/models/item/{name}.json',{'textures':{'metal':f'deepforge:item/mobs/mob_{zone}_skin','copper':'deepforge:block/copper','glow':f'deepforge:item/mobs/mob_{zone}_core','particle':f'deepforge:item/mobs/mob_{zone}_skin'},'elements':elements})
        item_definition(name)
        js(f'assets/deepforge/models/item/{name}_hit.json',{'parent':f'deepforge:item/{name}','textures':{'metal':f'deepforge:item/mobs/mob_{zone}_skin_hit','copper':f'deepforge:item/mobs/mob_{zone}_skin_hit','glow':f'deepforge:item/mobs/mob_{zone}_core_hit','particle':f'deepforge:item/mobs/mob_{zone}_skin_hit'}})
        item_definition(name+'_hit')


for zone in range(7):
    name=f'unique_{zone}'
    if zone in (2,5):
        base,light=colors[zone]
        im=Pixels(16,16)
        im.rect(3,2,13,12,base);im.rect(1,3,5,8,base);im.rect(11,3,15,8,base)
        im.rect(5,11,11,15,base);im.rect(6,4,10,10,light);im.rect(4,12,12,14,light)
        im.save(Path(f'assets/deepforge/textures/item/{name}.png'))
        js(f'assets/deepforge/models/item/{name}.json',{'parent':'minecraft:item/generated','textures':{'layer0':f'deepforge:item/{name}'}})
    else:
        style='hammer' if zone in (0,4) else 'spear' if zone==3 else 'sword'
        js(f'assets/deepforge/models/item/{name}.json',{'parent':f'deepforge:item/weapon_{style}','textures':{'metal':f'deepforge:item/mobs/mob_{zone}_skin','glow':f'deepforge:item/mobs/mob_{zone}_core','copper':'deepforge:block/copper'}})
    item_definition(name)

healing=Pixels(16,16,(27,101,91,255))
healing.rect(2,2,14,14,(60,207,162));healing.rect(4,3,7,12,(173,255,216));healing.rect(7,5,11,9,(223,255,245))
healing.save(Path('assets/deepforge/textures/item/healing_crystal.png'))
model('healing_crystal',[cube([5,2,5],[11,12,11],'glow'),cube([6,0,6],[10,2,10],'copper'),cube([6,12,6],[10,15,10],'glow')])
healing_model=json.loads((PACK/'assets/deepforge/models/item/healing_crystal.json').read_text(encoding='utf8'))
healing_model['textures']['glow']='deepforge:item/healing_crystal'
healing_model['display']['firstperson_righthand']={'rotation':[0,0,12],'translation':[0,1,0],'scale':[.65]*3}
healing_model['display']['firstperson_lefthand']=healing_model['display']['firstperson_righthand']
healing_model['display']['thirdperson_lefthand']=healing_model['display']['thirdperson_righthand']
js('assets/deepforge/models/item/healing_crystal.json',healing_model)
item_definition('healing_crystal')

out=BUILD/'Deepforge-ResourcePack.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted(PACK.rglob('*')):
        if path.is_file():
            info=zipfile.ZipInfo(path.relative_to(PACK).as_posix(),date_time=(2026,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,path.read_bytes())
(BUILD/'pack.sha1').write_text(hashlib.sha1(out.read_bytes()).hexdigest()+'\n',encoding='ascii')
print(f'Created {out.name}: {out.stat().st_size:,} bytes; SHA-1 {(BUILD/"pack.sha1").read_text().strip()}')
