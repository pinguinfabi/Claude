"""Reproducible original pixel textures and Java 1.21.8 models; Python stdlib only.
No client mods, image libraries or game assets required. The only external art is the
Pinguin Netzwerk glyph set in resourcepack/netz (tab list, sidebar and name tag style).
"""
from pathlib import Path
import hashlib, json, random, struct, zipfile, zlib, math

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / 'build'
PACK = BUILD / 'pack'
PACK.mkdir(parents=True, exist_ok=True)
# Remove only the obsolete generated textures; these were outside the vanilla model atlas.
for zone in range(7):
    for kind in ('skin','core'):
        (PACK/f'assets/deepforge/textures/entity/mob_{zone}_{kind}.png').unlink(missing_ok=True)

def js(path, data):
    target = PACK / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

class Pixels:
    def __init__(self, w, h, fill=(0, 0, 0, 0)):
        self.w, self.h = w, h
        self.data = [list(fill) for _ in range(w*h)]
    def set(self, x, y, color):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.data[y*self.w+x] = list(color) if len(color)==4 else [*color,255]
    def rect(self,x0,y0,x1,y1,color):
        for y in range(y0,y1):
            for x in range(x0,x1): self.set(x,y,color)
    def disc(self,cx,cy,r,color):
        for y in range(self.h):
            for x in range(self.w):
                if (x+.5-cx)**2+(y+.5-cy)**2<=r*r:self.set(x,y,color)
    def ring(self,cx,cy,r,width,color):
        for y in range(self.h):
            for x in range(self.w):
                if abs(math.hypot(x+.5-cx,y+.5-cy)-r)<=width:self.set(x,y,color)
    def save(self,path):
        target=PACK/path; target.parent.mkdir(parents=True, exist_ok=True)
        raw=b''.join(b'\x00'+bytes(c for pixel in self.data[y*self.w:(y+1)*self.w] for c in pixel) for y in range(self.h))
        def chunk(kind,data): return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
        target.write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',self.w,self.h,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(raw,9))+chunk(b'IEND',b''))

def polish(im):
    """Pixel-art finish: light from the top left, shade at the bottom right, dark outline."""
    solid=lambda x,y:0<=x<im.w and 0<=y<im.h and src[y*im.w+x][3]>0
    src=[p[:] for p in im.data]
    for y in range(im.h):
        for x in range(im.w):
            c=src[y*im.w+x]
            if c[3]>0:
                if not solid(x,y-1) or not solid(x-1,y):im.set(x,y,color_shift(c[:3],28))
                elif not solid(x,y+1) or not solid(x+1,y):im.set(x,y,color_shift(c[:3],-30))
            else:
                near=[src[v*im.w+u] for u,v in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if solid(u,v)]
                if near:
                    d=min(near,key=lambda n:sum(n[:3]));im.set(x,y,tuple(int(v*.3) for v in d[:3]))

PALETTES={
    'iron':((48,53,58),(206,145,100)), 'crystal':((62,56,73),(166,104,237)),
    'spore':((40,62,45),(125,213,93)), 'abyss':((30,56,70),(75,208,219)),
    'ember':((44,38,40),(251,133,52)), 'relic':((61,56,43),(239,204,100)),
    'void':((40,32,61),(227,110,236)),
    # 0.9.0: the ten deep mines.
    'core':((52,26,22),(255,96,28)), 'mirror':((178,184,194),(128,214,255)),
    'toxic':((44,58,30),(168,255,58)), 'storm':((70,80,96),(116,196,255)),
    'fossil':((150,132,98),(246,236,206)), 'aether':((196,186,146),(226,150,255)),
    'shadow':((22,18,28),(128,74,214)), 'star':((36,32,84),(255,228,112)),
    'primal':((54,74,44),(242,168,58)), 'worldcore':((28,14,36),(255,58,158))}

def color_shift(c,n): return tuple(max(0,min(255,v+n)) for v in c)

for idx,(name,(stone,ore)) in enumerate(PALETTES.items()):
    im=Pixels(32,64 if name in ('crystal','ember','void','core','star','worldcore','aether') else 32)
    for frame in range(im.h//32):
        rng=random.Random(470+idx)
        for y in range(32):
            for x in range(32): im.set(x,y+frame*32,color_shift(stone,rng.randint(-13,13)))
        for vein in range(13):
            x,y=rng.randrange(2,27),rng.randrange(2,27)
            size=rng.randrange(2,5)
            im.rect(x-1,y-1+frame*32,x+size+1,y+size+1+frame*32,color_shift(stone,-22))
            im.rect(x,y+frame*32,x+size,y+size+frame*32,color_shift(ore,frame*15))
            im.rect(x,y+frame*32,x+size,y+1+frame*32,color_shift(ore,40+frame*8))
            im.set(x+size-1,y+size-1+frame*32,color_shift(ore,-45))
    im.save(Path(f'assets/deepforge/textures/block/{name}_ore.png'))
    if im.h>32: js(f'assets/deepforge/textures/block/{name}_ore.png.mcmeta',{'animation':{'frametime':12,'interpolate':True}})
    js(f'assets/deepforge/models/block/{name}_ore.json',{'parent':'minecraft:block/cube_all','textures':{'all':f'deepforge:block/{name}_ore'}})
    icon=Pixels(16,16)
    for y in range(2,14):
        for x in range(2,14):
            if abs(x-8)+abs(y-8)<8: icon.set(x,y,color_shift(ore,25 if x+y<15 else -30))
    polish(icon);icon.save(Path(f'assets/deepforge/textures/item/ore_{name}.png'))

instruments='harp basedrum snare hat bass flute bell guitar chime xylophone iron_xylophone cow_bell didgeridoo bit banjo pling zombie skeleton creeper dragon wither_skeleton piglin custom_head'.split()
variants={}
for instrument in instruments:
    for note in range(25):
        for powered in ('false','true'):
            model=f'deepforge:block/{list(PALETTES)[note]}_ore' if instrument=='bass' and note<len(PALETTES) and powered=='false' else 'minecraft:block/note_block'
            variants[f'instrument={instrument},note={note},powered={powered}']={'model':model}
js('assets/minecraft/blockstates/note_block.json',{'variants':variants})

metal=Pixels(16,16)
rng=random.Random(812)
for y in range(16):
    for x in range(16): metal.set(x,y,color_shift((67,79,88),rng.randint(-8,8)))
metal.rect(0,0,16,2,(127,141,151));metal.rect(0,14,16,16,(27,33,40))
for x,y in [(2,3),(12,3),(2,11),(12,11)]:metal.rect(x,y,x+2,y+2,(192,144,73))
metal.save(Path('assets/deepforge/textures/block/machine_metal.png'))
copper=Pixels(16,16)
for y in range(16):
    for x in range(16):copper.set(x,y,color_shift((176,108,58),rng.randint(-7,7)+(10 if (x+y)%9==0 else 0)))
copper.rect(0,0,16,2,(232,171,99));copper.rect(0,14,16,16,(96,58,38))
for x,y in [(2,4),(13,4),(2,11),(13,11)]:copper.rect(x,y,x+1,y+1,(240,190,120))
copper.save(Path('assets/deepforge/textures/block/copper.png'))
glow=Pixels(16,16)
for y in range(16):
    for x in range(16):glow.set(x,y,color_shift((255,160,52),int(52-math.hypot(x-7.5,y-7.5)*8)))
glow.save(Path('assets/deepforge/textures/block/glow.png'))

def cube(a,b,texture='metal'):
    return {'from':a,'to':b,'faces':{d:{'uv':[0,0,16,16],'texture':'#'+texture} for d in ('north','south','east','west','up','down')}}
def model(name,elements):
    js(f'assets/deepforge/models/item/{name}.json',{'textures':{'metal':'deepforge:block/machine_metal','copper':'deepforge:block/copper','glow':'deepforge:block/glow','particle':'deepforge:block/machine_metal'},'elements':elements,'display':{'gui':{'rotation':[25,225,0],'translation':[0,0,0],'scale':[.75,.75,.75]},'thirdperson_righthand':{'rotation':[0,90,0],'translation':[0,2,0],'scale':[.65,.65,.65]},'firstperson_righthand':{'rotation':[0,-90,25],'translation':[0,1,0],'scale':[.44,.44,.44]},'ground':{'scale':[.5,.5,.5]},'fixed':{'scale':[1,1,1]}}})

model('machine_crusher',[cube([1,0,1],[15,3,15]),cube([3,3,3],[13,12,13]),cube([1,11,1],[15,14,15],'copper'),cube([4,14,4],[12,16,12]),cube([5,5,0],[11,9,3],'glow')])
model('machine_furnace',[cube([1,0,1],[15,2,15],'copper'),cube([2,2,2],[14,14,14]),cube([4,4,1],[12,10,2],'glow'),cube([10,14,9],[13,22,12]),cube([1,12,1],[15,14,15],'copper')])
model('crate',[cube([1,0,1],[15,14,15],'copper'),cube([0,2,0],[16,4,16]),cube([0,10,0],[16,12,16])])

icons={'coin':(232,185,79),'worker':(192,136,91),'shield':(134,170,198),'fuel':(77,86,100),'clock':(100,187,187),'handbook':(190,139,81),'relic':(193,124,238),'scanner':(85,202,175),'close':(209,95,87),'back':(170,185,201),'next':(170,185,201)}
def draw_icon(name,color):
    im=Pixels(16,16)
    if name=='coin':
        im.disc(8,8,6.5,color_shift(color,-45));im.disc(8,8,5.5,color);im.ring(8,8,4.3,.5,color_shift(color,-30))
        im.rect(6,5,8,11,color_shift(color,-55));im.rect(8,5,9,6,color_shift(color,-55));im.rect(9,6,10,10,color_shift(color,-55));im.rect(8,10,9,11,color_shift(color,-55))
        im.rect(7,6,8,10,color_shift(color,20));im.set(4,5,(255,244,200));im.set(5,4,(255,244,200))
    elif name=='clock':
        im.disc(8,8,6.5,color_shift(color,-50));im.disc(8,8,5.2,(236,229,206))
        for x,y in [(7,3),(8,3),(12,7),(12,8),(7,12),(8,12),(3,7),(3,8)]:im.set(x,y,(70,80,88))
        im.rect(7,4,9,9,(44,52,60));im.rect(8,7,11,9,(44,52,60));im.set(7,7,color_shift(color,-20))
    elif name=='scanner':
        im.disc(8,8,6.5,(26,58,56));im.ring(8,8,4.6,.5,color_shift(color,-30));im.ring(8,8,2.4,.5,color_shift(color,-30))
        for i in range(5):im.set(8+i,7-i,color_shift(color,30-i*6));im.set(8+i,8-i,color_shift(color,-10-i*6))
        im.rect(10,4,12,6,(214,255,232));im.set(5,10,color)
    elif name=='worker':
        im.disc(8,6.5,5,(236,184,58));im.rect(0,6,16,16,(0,0,0,0))
        im.rect(2,5,14,7,(200,146,36));im.rect(7,2,9,4,(255,250,214));im.set(6,3,(255,236,150));im.set(9,3,(255,236,150))
        im.rect(5,7,11,12,(214,160,112));im.rect(4,8,5,10,(190,136,94));im.rect(11,8,12,10,(190,136,94))
        im.rect(6,8,7,9,(36,40,48));im.rect(9,8,10,9,(36,40,48));im.rect(6,10,10,11,(118,78,50))
        im.rect(3,12,13,16,(66,98,128));im.rect(4,13,12,14,(232,140,50));im.rect(7,12,9,16,(52,78,104))
    elif name=='shield':
        for y in range(2,15):
            half=6 if y<9 else max(1,6-(y-8))
            im.rect(8-half,y,8+half,y+1,(150,166,178))
            if half>1:im.rect(9-half,y,7+half,y+1,(56,92,150)) if 2<y<14 else None
        im.rect(7,3,9,13,(226,178,76));im.rect(4,6,12,8,(226,178,76))
    elif name=='fuel':
        im.disc(6,10,4,(52,54,60));im.disc(10.5,9,3.6,(62,64,72));im.disc(8,5.5,3.2,(46,48,54))
        for x,y in [(5,8),(9,7),(7,4),(11,8),(4,11)]:im.set(x,y,(104,108,120))
        for x,y in [(6,11),(10,10),(8,6)]:im.set(x,y,(255,146,46))
        im.set(7,11,(255,210,120))
    elif name=='handbook':
        im.rect(3,2,13,14,(126,78,44));im.rect(3,2,5,14,(92,54,30));im.rect(12,3,14,14,(238,226,196))
        for y in (5,8,11):im.rect(12,y,14,y+1,(196,180,150))
        im.rect(6,4,11,5,(220,170,74));im.rect(6,11,11,12,(220,170,74));im.rect(7,6,10,9,(220,170,74));im.rect(8,7,9,8,(126,78,44))
        im.rect(9,14,10,16,(196,56,52))
    elif name=='relic':
        im.rect(5,12,11,13,(212,160,68));im.rect(4,13,12,15,(176,128,52));im.rect(6,11,10,12,(176,128,52))
        im.disc(8,6.5,5,color_shift(color,-50));im.disc(8,6.5,4,color);im.disc(7,5.5,2,color_shift(color,45));im.set(6,4,(255,240,255))
    elif name=='close':
        for i in range(3,12):im.rect(i,i,i+2,i+2,color);im.rect(14-i,i,16-i,i+2,color)
    elif name=='back':
        im.rect(5,6,14,10,color)
        for i in range(5):im.rect(2+i,8-i,3+i,8+i,color)
    elif name=='next':
        # Mirror of 'back': points right.
        im.rect(2,6,11,10,color)
        for i in range(5):im.rect(13-i,8-i,14-i,8+i,color)
    polish(im)
    im.save(Path(f'assets/deepforge/textures/item/{name}.png'))
for name,color in icons.items():draw_icon(name,color)

for name in [*icons,*(f'ore_{n}' for n in PALETTES)]:
    js(f'assets/deepforge/models/item/{name}.json',{'parent':'minecraft:item/generated','textures':{'layer0':f'deepforge:item/{name}'}})
for name in [*icons,*(f'ore_{n}' for n in PALETTES),'drill','blade','machine_crusher','machine_furnace','crate']:
    js(f'assets/deepforge/items/{name}.json',{'model':{'type':'minecraft:model','model':f'deepforge:item/{name}'}})

gui=Pixels(176,222,(28,34,42,255));gui.rect(0,0,176,3,(196,144,75));gui.rect(0,219,176,222,(196,144,75));gui.rect(0,0,3,222,(99,77,54));gui.rect(173,0,176,222,(99,77,54));gui.rect(6,5,170,16,(217,186,139))
for row in range(6):
    for col in range(9):
        x,y=7+col*18,17+row*18;gui.rect(x,y,x+18,y+18,(16,21,27));gui.rect(x+1,y+1,x+17,y+17,(52,63,75));gui.rect(x+2,y+2,x+16,y+3,(76,89,103))
for row in range(4):
    for col in range(9):
        x,y=7+col*18,(139+row*18 if row<3 else 197);gui.rect(x,y,x+18,y+18,(17,22,29));gui.rect(x+1,y+1,x+17,y+17,(57,66,78))
gui.save(Path('assets/deepforge/textures/gui/panel.png'))
js('assets/deepforge/font/ui.json',{'providers':[{'type':'space','advances':{'\ue0ff':-8,'\ue0fe':-169}},{'type':'bitmap','file':'deepforge:gui/panel.png','ascent':13,'height':222,'chars':['\ue100']},{'type':'bitmap','file':'deepforge:item/coin.png','ascent':8,'height':8,'chars':['\ue001']},{'type':'reference','id':'minecraft:default'}]})
# Game HUD font (deepforge:hud): own pixel letters, icons, bar segments, panel pieces and
# positioning spaces. ui/HudFont.java uses the same code points and sizes.
HUD_TEXT='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ$%/.:+-!x ÄÖÜ'
FONT5x7={
 '0':'01110 10001 10011 10101 11001 10001 01110','1':'00100 01100 00100 00100 00100 00100 01110',
 '2':'01110 10001 00001 00010 00100 01000 11111','3':'11110 00001 00001 01110 00001 00001 11110',
 '4':'00010 00110 01010 10010 11111 00010 00010','5':'11111 10000 11110 00001 00001 10001 01110',
 '6':'00110 01000 10000 11110 10001 10001 01110','7':'11111 00001 00010 00100 01000 01000 01000',
 '8':'01110 10001 10001 01110 10001 10001 01110','9':'01110 10001 10001 01111 00001 00010 01100',
 'A':'01110 10001 10001 11111 10001 10001 10001','B':'11110 10001 10001 11110 10001 10001 11110',
 'C':'01110 10001 10000 10000 10000 10001 01110','D':'11100 10010 10001 10001 10001 10010 11100',
 'E':'11111 10000 10000 11110 10000 10000 11111','F':'11111 10000 10000 11110 10000 10000 10000',
 'G':'01110 10001 10000 10111 10001 10001 01111','H':'10001 10001 10001 11111 10001 10001 10001',
 'I':'01110 00100 00100 00100 00100 00100 01110','J':'00111 00010 00010 00010 00010 10010 01100',
 'K':'10001 10010 10100 11000 10100 10010 10001','L':'10000 10000 10000 10000 10000 10000 11111',
 'M':'10001 11011 10101 10101 10001 10001 10001','N':'10001 10001 11001 10101 10011 10001 10001',
 'O':'01110 10001 10001 10001 10001 10001 01110','P':'11110 10001 10001 11110 10000 10000 10000',
 'Q':'01110 10001 10001 10001 10101 10010 01101','R':'11110 10001 10001 11110 10100 10010 10001',
 'S':'01111 10000 10000 01110 00001 00001 11110','T':'11111 00100 00100 00100 00100 00100 00100',
 'U':'10001 10001 10001 10001 10001 10001 01110','V':'10001 10001 10001 10001 10001 01010 00100',
 'W':'10001 10001 10001 10101 10101 10101 01010','X':'10001 10001 01010 00100 01010 10001 10001',
 'Y':'10001 10001 01010 00100 00100 00100 00100','Z':'11111 00001 00010 00100 01000 10000 11111',
 '$':'00100 01111 10100 01110 00101 11110 00100','%':'11001 11010 00010 00100 01000 01011 10011',
 '/':'00001 00010 00010 00100 01000 01000 10000','.':'00000 00000 00000 00000 00000 01100 01100',
 ':':'00000 01100 01100 00000 01100 01100 00000','+':'00000 00100 00100 11111 00100 00100 00000',
 '-':'00000 00000 00000 11111 00000 00000 00000','!':'00100 00100 00100 00100 00100 00000 00100',
 'x':'00000 00000 10001 01010 00100 01010 10001',' ':'00000 00000 00000 00000 00000 00000 00000',
 'Ä':'01010 00000 01110 10001 11111 10001 10001','Ö':'01010 00000 01110 10001 10001 10001 01110',
 'Ü':'01010 00000 10001 10001 10001 10001 01110'}
MARK=(255,255,255,1)  # invisible pixel in the last column: every glyph keeps its full cell width
def hud_sheet(cells,w,h,cols,draw):
    rows=(len(cells)+cols-1)//cols
    im=Pixels(w*cols,h*rows)
    for i,cell in enumerate(cells):
        ox,oy=(i%cols)*w,(i//cols)*h
        draw(im,ox,oy,cell)
        im.set(ox+w-1,oy,MARK) if im.data[(oy)*im.w+ox+w-1][3]==0 else None
    return im,rows,cols
def draw_letter(im,ox,oy,ch):
    for y,row in enumerate(FONT5x7[ch].split()):
        for x,bit in enumerate(row):
            if bit=='1':im.set(ox+x,oy+y,(255,255,255) if y<3 else (232,232,232) if y<5 else (206,206,206))
text_im,text_rows,text_cols=hud_sheet(HUD_TEXT,5,7,16,draw_letter)
text_im.save(Path('assets/deepforge/textures/font/hud_text.png'))
def glyph_rows(start,count,cols):
    return [''.join(chr(start+r*cols+c) for c in range(cols) if r*cols+c<count) .ljust(cols,'\u0000') for r in range((count+cols-1)//cols)]

HUD_ICONS=['coin','bag','flame','heart','bolt','star','gem','sword','crystal','clock','up','up_right','right','down_right','down','down_left','left','up_left','pick','log','worker','castle','skull','scroll']
def draw_hud_icon(im,ox,oy,name):
    ic=Pixels(9,9)
    if name=='coin':ic.disc(4.5,4.5,3.6,(232,178,60));ic.disc(4.5,4.5,2.4,(255,214,96));ic.rect(4,3,5,6,(196,140,40))
    elif name=='bag':ic.rect(1,3,8,8,(150,98,58));ic.rect(3,1,6,3,(120,76,44));ic.rect(2,4,7,5,(186,130,80));ic.rect(4,5,5,7,(236,190,80))
    elif name=='flame':
        ic.disc(4.5,5.5,3,(236,96,36));ic.rect(4,1,5,4,(236,96,36));ic.rect(3,2,4,4,(236,96,36));ic.disc(4.5,6,1.6,(255,214,96))
    elif name=='heart':
        ic.disc(3,3.5,2.2,(214,40,52));ic.disc(6,3.5,2.2,(214,40,52))
        for y in range(4,8):ic.rect(y-3,y,9-(y-3),y+1,(214,40,52))
        ic.set(2,2,(255,150,150))
    elif name=='bolt':
        for x,y in [(5,0),(4,1),(5,1),(3,2),(4,2),(2,3),(3,3),(4,3),(5,3),(6,3),(4,4),(5,4),(3,5),(4,5),(2,6),(3,6),(2,7)]:ic.set(x,y,(90,210,255))
    elif name=='star':
        for x,y in [(4,0),(4,1),(3,2),(4,2),(5,2),(0,3),(1,3),(2,3),(3,3),(4,3),(5,3),(6,3),(7,3),(8,3),(2,4),(3,4),(4,4),(5,4),(6,4),(2,5),(3,5),(5,5),(6,5),(1,6),(2,6),(6,6),(7,6)]:ic.set(x,y,(255,214,64))
    elif name=='gem':
        ic.rect(2,1,7,3,(120,240,230));ic.rect(1,3,8,4,(60,200,200))
        for y in range(4,8):ic.rect(y-3,y,9-(y-3),y+1,(40,160,170))
        ic.set(3,2,(230,255,255))
    elif name=='sword':
        for i in range(6):ic.set(2+i,6-i,(222,230,238));ic.set(3+i,6-i,(170,182,194))
        ic.rect(1,5,4,6,(214,160,72));ic.rect(2,4,3,7,(214,160,72));ic.set(0,8,(120,80,50));ic.set(1,7,(120,80,50))
    elif name=='crystal':
        ic.rect(3,1,6,8,(80,220,170));ic.rect(2,3,7,6,(80,220,170));ic.rect(4,2,5,5,(200,255,236))
    elif name=='clock':
        ic.disc(4.5,4.5,3.8,(220,220,210));ic.rect(4,2,5,5,(40,44,52));ic.rect(4,4,7,5,(40,44,52))
    elif name=='pick':
        for i in range(6):ic.set(2+i,7-i,(150,104,64))
        ic.rect(2,1,7,2,(200,210,220));ic.set(1,2,(200,210,220));ic.set(7,2,(200,210,220));ic.set(0,3,(160,170,180));ic.set(8,3,(160,170,180))
    elif name=='log':
        ic.rect(1,2,8,7,(126,86,52));ic.disc(7,4.5,2.4,(206,170,110));ic.set(7,4,(150,110,70));ic.rect(1,2,8,3,(150,104,64))
    elif name=='worker':
        ic.disc(4.5,3.5,3,(236,184,58));ic.rect(0,3,9,9,(0,0,0,0));ic.rect(1,3,8,4,(200,146,36));ic.rect(2,4,7,7,(214,160,112));ic.set(3,5,(40,40,48));ic.set(5,5,(40,40,48));ic.rect(1,7,8,9,(66,98,128))
    elif name=='castle':
        ic.rect(1,3,8,8,(150,156,168));ic.set(1,2,(150,156,168));ic.set(3,2,(150,156,168));ic.set(5,2,(150,156,168));ic.set(7,2,(150,156,168));ic.rect(3,5,6,8,(50,40,60));ic.set(4,4,(50,40,60))
    elif name=='skull':
        ic.disc(4.5,4,3.4,(230,226,214));ic.rect(2,6,7,8,(230,226,214));ic.rect(2,3,4,5,(40,36,40));ic.rect(5,3,7,5,(40,36,40));ic.set(4,6,(40,36,40))
    elif name=='scroll':
        ic.rect(2,1,7,8,(236,220,176));ic.rect(1,1,8,2,(190,150,90));ic.rect(1,7,8,8,(190,150,90))
        for y in (3,5):ic.rect(3,y,6,y+1,(150,120,80))
    else:
        # Arrows: an up arrow rotated in 45° steps.
        steps=['up','up_right','right','down_right','down','down_left','left','up_left'].index(name)
        pts=[(0,-3),(-1,-2),(0,-2),(1,-2),(-2,-1),(0,-1),(2,-1),(0,0),(0,1),(0,2)]
        for x,y in pts:
            a=math.radians(45*steps);rx=x*math.cos(a)-y*math.sin(a);ry=x*math.sin(a)+y*math.cos(a)
            ic.set(int(round(4+rx)),int(round(4+ry)),(255,236,120))
    polish(ic)
    for y in range(9):
        for x in range(9):
            c=ic.data[y*9+x]
            if c[3]:im.set(ox+x,oy+y,c)
icon_im,icon_rows,icon_cols=hud_sheet(HUD_ICONS,9,9,8,draw_hud_icon)
icon_im.save(Path('assets/deepforge/textures/font/hud_icons.png'))

seg=Pixels(3,7)
for y in range(7):
    for x in range(3):seg.set(x,y,(255,255,255) if y<3 else (220,220,220) if y<5 else (180,180,180))
seg.save(Path('assets/deepforge/textures/font/hud_seg_full.png'))
seg=Pixels(3,7)
for y in range(7):
    for x in range(3):seg.set(x,y,(58,62,72,230) if 0<y<6 else (40,43,50,230))
seg.save(Path('assets/deepforge/textures/font/hud_seg_empty.png'))

PANEL_FILL=(22,25,32,200);PANEL_TOP=(214,164,76,255);PANEL_BOTTOM=(10,12,16,230);PANEL_EDGE=(70,76,90,230)
def panel_column(im,x,edge):
    for y in range(14):
        im.set(x,y,PANEL_TOP if y==0 else PANEL_BOTTOM if y==13 else PANEL_EDGE if edge else PANEL_FILL)
for width in (1,2,4,8,16,32):
    im=Pixels(width,14)
    for x in range(width):panel_column(im,x,False)
    im.save(Path(f'assets/deepforge/textures/font/hud_panel_{width}.png'))
for side in ('left','right'):
    im=Pixels(3,14)
    for x in range(3):panel_column(im,x,x==(0 if side=='left' else 2))
    for x,y in ([(0,0),(0,13)] if side=='left' else [(2,0),(2,13)]):im.set(x,y,(0,0,0,0))
    im.save(Path(f'assets/deepforge/textures/font/hud_panel_{side}.png'))

hud_providers=[{'type':'space','advances':{chr(0xE380+i):-(1<<i) for i in range(8)}|{chr(0xE388+i):(1<<i) for i in range(7)}},
 {'type':'bitmap','file':'deepforge:font/hud_text.png','ascent':7,'height':7,'chars':glyph_rows(0xE300,len(HUD_TEXT),text_cols)},
 {'type':'bitmap','file':'deepforge:font/hud_icons.png','ascent':8,'height':9,'chars':glyph_rows(0xE340,len(HUD_ICONS),icon_cols)},
 {'type':'bitmap','file':'deepforge:font/hud_seg_full.png','ascent':7,'height':7,'chars':['']},
 {'type':'bitmap','file':'deepforge:font/hud_seg_empty.png','ascent':7,'height':7,'chars':['']},
 {'type':'bitmap','file':'deepforge:font/hud_panel_left.png','ascent':10,'height':14,'chars':['']},
 {'type':'bitmap','file':'deepforge:font/hud_panel_right.png','ascent':10,'height':14,'chars':['']}]
for i,width in enumerate((1,2,4,8,16,32)):
    hud_providers.append({'type':'bitmap','file':f'deepforge:font/hud_panel_{width}.png','ascent':10,'height':14,'chars':[chr(0xE372+i)]})
# Wiki dialog: section bar drawn behind every entry title (0xE3C0, 296 px), and a thin divider.
bar=Pixels(296,12)
for x in range(296):
    fade=max(0.0,1-x/296)
    for y in range(12):
        bar.set(x,y,(34,28,36,int(150+60*fade)))
    bar.set(x,11,(255,138,0,int(40+200*fade)))
for y in range(12):
    for x in range(3): bar.set(x,y,(255,138,0) if x<2 else (255,181,71))
bar.save(Path('assets/deepforge/textures/font/wiki_bar.png'))
hud_providers.append({'type':'bitmap','file':'deepforge:font/wiki_bar.png','ascent':9,'height':12,'chars':['\ue3c0']})
js('assets/deepforge/font/hud.json',{'providers':hud_providers})
# The action-bar HUD sits lower (where the hidden hearts were), so messages fit above it.
HUD_DROP=28
js('assets/deepforge/font/hud_low.json',{'providers':[dict(p,ascent=p['ascent']-HUD_DROP) if p['type']=='bitmap' else p for p in hud_providers]})

js('pack.mcmeta',{'pack':{'pack_format':64,'description':'Deepforge · eigene Erze, Maschinen, Werkzeuge und GUI · 1.21.8'}})

icon=Pixels(64,64,(27,33,41,255));icon.rect(4,4,60,60,(178,122,61));icon.rect(8,8,56,56,(39,50,61));icon.rect(27,15,38,49,(199,208,211));icon.rect(16,16,48,26,(207,145,71));icon.save(Path('pack.png'))


# Original segmented monster meshes and five weapon silhouettes for the combat expansion.
def item_definition(name):
    js(f'assets/deepforge/items/{name}.json',{'model':{'type':'minecraft:model','model':f'deepforge:item/{name}'}})

# Held weapons and tools.
# Each one is built upright (grip at the bottom, tip at the top) and turned 45° onto the
# same diagonal as a vanilla sword sprite: pommel bottom left, tip top right. The vanilla
# handheld display values then place it in the hand exactly like a vanilla sword, both in
# first person (lower right corner, away from the crosshair) and in third person.
HANDHELD={
 'thirdperson_righthand':{'rotation':[0,-90,55],'translation':[0,4.0,0.5],'scale':[.85]*3},
 'thirdperson_lefthand':{'rotation':[0,90,-55],'translation':[0,4.0,0.5],'scale':[.85]*3},
 'firstperson_righthand':{'rotation':[0,-90,25],'translation':[1.13,3.2,1.13],'scale':[.68]*3},
 'firstperson_lefthand':{'rotation':[0,90,-25],'translation':[1.13,3.2,1.13],'scale':[.68]*3}}
# The crossbow follows the vanilla crossbow sprite (butt bottom right, front top left).
CROSSBOW_HELD={
 'thirdperson_righthand':{'rotation':[-90,0,-60],'translation':[2,0.1,-3],'scale':[.9]*3},
 'thirdperson_lefthand':{'rotation':[-90,0,30],'translation':[2,0.1,-3],'scale':[.9]*3},
 'firstperson_righthand':{'rotation':[-90,0,-55],'translation':[1.13,3.2,1.13],'scale':[.68]*3},
 'firstperson_lefthand':{'rotation':[-90,0,35],'translation':[1.13,3.2,1.13],'scale':[.68]*3}}

def texture(name,base,noise,seed,paint=None):
    im=Pixels(16,16);rng=random.Random(seed)
    for y in range(16):
        for x in range(16):im.set(x,y,color_shift(base,rng.randint(-noise,noise)))
    if paint:paint(im,rng)
    im.save(Path(f'assets/deepforge/textures/item/weapon/{name}.png'))
def _steel(im,rng):
    for x in range(16):
        for y in range(16):
            c=im.data[y*16+x];im.set(x,y,color_shift(c[:3],12 if (x+y)%11==0 else -6 if (x+2*y)%13==0 else 0))
    for _ in range(5):
        x,y=rng.randrange(16),rng.randrange(14);im.set(x,y,(226,234,240));im.set(x,y+1,(200,210,218))
def _edge(im,rng):
    for y in range(16):im.set(rng.randrange(16),y,(250,252,255))
def _brass(im,rng):
    for y in range(16):
        for x in range(16):
            c=im.data[y*16+x];im.set(x,y,color_shift(c[:3],18 if y%4==0 else -14 if y%4==3 else 0))
def _grip(im,rng):
    for y in range(16):
        for x in range(16):
            band=(y+x//4)%3
            c=im.data[y*16+x];im.set(x,y,color_shift(c[:3],-26 if band==0 else 14 if band==1 else 0))
def _wood(im,rng):
    for x in range(16):
        shade=rng.choice((-14,-6,0,6,10))
        for y in range(16):
            c=im.data[y*16+x];im.set(x,y,color_shift(c[:3],shade))
    for _ in range(3):
        x,y=rng.randrange(16),rng.randrange(15);im.set(x,y,(74,48,30));im.set(x,y+1,(84,55,34))
def _dark(im,rng):
    for y in range(16):
        for x in range(16):
            if (x in (0,15) or y in (0,15)):im.set(x,y,color_shift(im.data[y*16+x][:3],16))
    for x,y in [(2,2),(13,2),(2,13),(13,13)]:im.set(x,y,(196,150,74))
def _gem(im,rng):
    for y in range(16):
        for x in range(16):
            d=abs(x-7.5)+abs(y-7.5)
            im.set(x,y,color_shift((255,168,58),int(70-d*9)))
    for x,y in [(5,5),(6,5),(5,6),(9,4),(4,9)]:im.set(x,y,(255,248,214))

texture('steel',(166,176,186),5,901,_steel)
texture('edge',(214,224,232),4,902,_edge)
texture('brass',(208,154,66),6,903,_brass)
texture('grip',(104,66,42),5,904,_grip)
texture('wood',(128,88,54),4,905,_wood)
texture('dark',(66,71,80),5,906,_dark)
texture('gem',(0,0,0),0,907,_gem)
texture('string',(226,220,204),6,908)

WEAPON_TEXTURES={'metal':'deepforge:item/weapon/steel','edge':'deepforge:item/weapon/edge','copper':'deepforge:item/weapon/brass',
 'grip':'deepforge:item/weapon/grip','wood':'deepforge:item/weapon/wood','dark':'deepforge:item/weapon/dark',
 'glow':'deepforge:item/weapon/gem','string':'deepforge:item/weapon/string','particle':'deepforge:item/weapon/steel'}

def part(a,b,texture='metal',angle=-45):
    """One element with one texel per model pixel, kept inside its 16×16 sprite."""
    axes={'north':(0,1),'south':(0,1),'east':(2,1),'west':(2,1),'up':(0,2),'down':(0,2)}
    faces={}
    for face,(u,v) in axes.items():
        w=min(16,b[u]-a[u]);h=min(16,b[v]-a[v])
        u0=min(max(a[u]%16,0),16-w)
        v0=min(max((16-b[v] if v==1 else a[v])%16,0),16-h)
        faces[face]={'uv':[round(u0,3),round(v0,3),round(u0+w,3),round(v0+h,3)],'texture':'#'+texture}
    element={'from':a,'to':b,'faces':faces}
    if angle:element['rotation']={'angle':angle,'axis':'z','origin':[8,8,8]}
    return element

def bounds(elements):
    xs,ys=[],[]
    for e in elements:
        angle=math.radians(e.get('rotation',{}).get('angle',0))
        for x in (e['from'][0],e['to'][0]):
            for y in (e['from'][1],e['to'][1]):
                x0,y0=x-8,y-8
                xs.append(8+x0*math.cos(angle)-y0*math.sin(angle));ys.append(8+x0*math.sin(angle)+y0*math.cos(angle))
    return min(xs),min(ys),max(xs),max(ys)

def weapon_model(name,elements,held=HANDHELD):
    x0,y0,x1,y1=bounds(elements)
    size=max(x1-x0,y1-y0);fit=round(min(1.0,15.5/size),3)
    center=[-(x0+x1)/2+8,-(y0+y1)/2+8]
    gui={'rotation':[0,0,0],'translation':[round(center[0]*fit,3),round(center[1]*fit,3),0],'scale':[fit]*3}
    display={**held,'gui':gui,
     'fixed':{'rotation':[0,180,0],'translation':[round(-center[0]*fit,3),round(center[1]*fit,3),0],'scale':[fit]*3},
     'ground':{'rotation':[0,0,0],'translation':[0,2,0],'scale':[round(.5*fit,3)]*3},
     'head':{'rotation':[0,180,0],'translation':[0,13,7],'scale':[1,1,1]}}
    js(f'assets/deepforge/models/item/{name}.json',{'gui_light':'front','textures':WEAPON_TEXTURES,'elements':elements,'display':display})

held_items={
 'weapon_sword':[
  part([7,-2,7],[9,0,9],'copper'),part([7.5,-2.6,7.5],[8.5,-2,8.5],'glow'),
  part([7.25,0,7.25],[8.75,5,8.75],'grip'),
  part([4.5,5,6.75],[11.5,6.5,9.25],'copper'),part([4,4.25,7],[5,6,9],'copper'),part([11,4.25,7],[12,6,9],'copper'),
  part([7.4,5.2,6.5],[8.6,6.3,9.5],'glow'),
  part([6.5,6.5,7.5],[9.5,16.5,8.5]),part([6.25,6.5,7.65],[6.5,16,8.35],'edge'),part([9.5,6.5,7.65],[9.75,16,8.35],'edge'),
  part([7.7,6.5,7.35],[8.3,15.5,8.65],'dark'),
  part([7,16.5,7.6],[9,18,8.4]),part([7.5,18,7.7],[8.5,19.3,8.3],'edge')],
 'weapon_dagger':[
  part([7.1,0,7.1],[8.9,1.5,8.9],'copper'),part([7.3,1.5,7.3],[8.7,5,8.7],'grip'),
  part([5.5,5,7],[10.5,6,9],'copper'),part([7.5,5.1,6.8],[8.5,5.9,9.2],'glow'),
  part([6.75,6,7.55],[9.25,11.5,8.45]),part([6.5,6,7.7],[6.75,11,8.3],'edge'),part([9.25,6,7.7],[9.5,11,8.3],'edge'),
  part([7.25,11.5,7.65],[8.75,13,8.35]),part([7.65,13,7.75],[8.35,14.2,8.25],'edge')],
 'weapon_hammer':[
  part([7,-4,7],[9,-2.5,9],'copper'),part([7.2,-2.5,7.2],[8.8,2.5,8.8],'grip'),part([7.4,2.5,7.4],[8.6,11,8.6],'wood'),
  part([7.1,6,7.1],[8.9,7,8.9],'copper'),
  part([4.25,11,5.75],[11.75,16.5,10.25],'dark'),part([3.2,11.5,6.25],[4.25,16,9.75],'metal'),part([11.75,11.5,6.25],[12.8,16,9.75],'metal'),
  part([6.9,10.6,5.45],[9.1,16.9,10.55],'copper'),part([7.4,12.75,5.15],[8.6,14.75,10.85],'glow'),
  part([7.3,16.5,7.3],[8.7,18.5,8.7],'metal')],
 'weapon_spear':[
  part([7.1,-9.5,7.1],[8.9,-8,8.9],'copper'),part([7.4,-8,7.4],[8.6,0,8.6],'wood'),
  part([7.25,0,7.25],[8.75,4,8.75],'grip'),part([7.4,4,7.4],[8.6,16,8.6],'wood'),
  part([7.1,14.5,7.1],[8.9,15.5,8.9],'glow'),part([7,15.5,7],[9,18,9],'copper'),
  part([6.5,18,7.55],[9.5,21.5,8.45]),part([6.2,18.5,7.7],[6.5,21,8.3],'edge'),part([9.5,18.5,7.7],[9.8,21,8.3],'edge'),
  part([7,21.5,7.65],[9,23.5,8.35]),part([7.5,23.5,7.75],[8.5,25.2,8.25],'edge'),part([7.8,18,7.4],[8.2,23,8.6],'dark')],
 'weapon_crossbow':[
  part([6.5,-1.5,6.75],[9.5,2.5,9.25],'wood',45),part([7,2.5,7.1],[9,12,8.9],'wood',45),
  part([6.8,4,6.9],[9.2,5,9.1],'copper',45),part([6.8,10,6.9],[9.2,11,9.1],'copper',45),
  part([7.35,4.5,6.5],[8.65,9.5,7.1],'dark',45),part([7.5,6.2,8.9],[8.5,7.4,9.4],'glow',45),
  part([7,12,7],[9,14,9],'metal',45),
  part([5,12,7.25],[11,13.5,8.75],'dark',45),part([1.5,11,7.4],[5,12.5,8.6],'metal',45),part([11,11,7.4],[14.5,12.5,8.6],'metal',45),
  part([-0.5,10,7.5],[1.5,11.5,8.5],'copper',45),part([14.5,10,7.5],[16.5,11.5,8.5],'copper',45),
  part([0,9.6,7.9],[16,9.9,8.1],'string',45),part([7.6,7,6.7],[8.4,13,7.2],'metal',45)],
 'blade':[
  part([7.1,-1,7.1],[8.9,0.5,8.9],'copper'),part([7.3,0.5,7.3],[8.7,5,8.7],'grip'),
  part([5.5,5,7],[10.5,6,9],'dark'),
  part([6.4,6,7.6],[9.8,15,8.4]),part([9.8,6,7.7],[10.1,14.5,8.3],'edge'),part([6,6,7.4],[6.6,14.5,8.6],'dark'),
  part([6.8,15,7.65],[9.8,16.5,8.35]),part([8.2,16.5,7.75],[9.8,17.5,8.25],'edge'),part([6.9,8,7.35],[7.7,10,8.65],'glow')],
 'drill':[
  part([7.1,-1.5,7.1],[8.9,0,8.9],'copper'),part([7.25,0,7.25],[8.75,4,8.75],'grip'),
  part([6,4,6],[10,10,10],'dark'),part([5.75,5,5.75],[10.25,5.8,10.25],'copper'),part([5.75,8.2,5.75],[10.25,9,10.25],'copper'),
  part([6.75,6.2,5.8],[9.25,7.8,10.2],'glow'),part([10,6,7.3],[11.5,7,8.7],'copper'),part([11,6,7.3],[12,9,8.7],'copper'),
  part([6.25,10,6.25],[9.75,11.75,9.75],'edge'),part([6.75,11.75,6.75],[9.25,13.5,9.25]),part([7.2,13.5,7.2],[8.8,15.25,8.8],'edge'),part([7.6,15.25,7.6],[8.4,17,8.4])]
}
for name,elements in held_items.items():
    weapon_model(name,elements,CROSSBOW_HELD if name=='weapon_crossbow' else HANDHELD)
    item_definition(name)


# Steam drone "Funke": a round-ish body with a glowing eye, rotor, side thrusters and a claw.
# Built around the model centre so an ItemDisplay (no display transform) floats it centred.
def drone_elements():
    q=lambda a,b,t='metal':part(a,b,t,angle=0)
    return [
     q([4.5,5,4.5],[11.5,10,11.5]),q([5,4,5],[11,5,11],'dark'),q([5,10,5],[11,11,11],'copper'),
     q([6.5,6.3,11.5],[9.5,8.7,12.2],'glow'),q([7,6.8,12.2],[9,8.2,12.5],'edge'),
     q([7.5,11,7.5],[8.5,12.4,8.5],'dark'),q([1.5,12.4,7.4],[14.5,12.9,8.6]),q([7.4,12.4,1.5],[8.6,12.9,14.5]),
     q([2.6,6,6],[4.5,9.2,10],'copper'),q([11.5,6,6],[13.4,9.2,10],'copper'),
     q([2.9,5.4,6.6],[4.2,6,9.4],'glow'),q([11.8,5.4,6.6],[13.1,6,9.4],'glow'),
     q([7.2,2.6,7.2],[8.8,4,8.8],'dark'),q([6.4,2,7.6],[7.2,3,8.4],'metal'),q([8.8,2,7.6],[9.6,3,8.4],'metal')]
DRONE_SKINS=[
 {'metal':'deepforge:item/weapon/brass','copper':'deepforge:item/weapon/dark','glow':'deepforge:item/weapon/gem'},
 {'metal':'deepforge:block/copper','copper':'deepforge:item/weapon/dark','glow':'deepforge:item/weapon/gem'},
 {'metal':'deepforge:item/mobs/mob_1_skin','copper':'deepforge:item/weapon/steel','glow':'deepforge:item/mobs/mob_1_core'},
 {'metal':'deepforge:item/mobs/mob_4_skin','copper':'deepforge:item/weapon/brass','glow':'deepforge:item/mobs/mob_4_core'}]
for i,skin in enumerate(DRONE_SKINS):
    textures={**WEAPON_TEXTURES,**skin,'particle':skin['metal']}
    js(f'assets/deepforge/models/item/drone_{i}.json',{'textures':textures,'elements':drone_elements(),'display':{
      'gui':{'rotation':[25,-35,0],'translation':[0,0,0],'scale':[.9,.9,.9]},
      'fixed':{'rotation':[0,180,0],'scale':[.9,.9,.9]},
      'ground':{'translation':[0,2,0],'scale':[.5,.5,.5]},
      'thirdperson_righthand':{'rotation':[75,45,0],'translation':[0,2.5,0],'scale':[.4,.4,.4]},
      'firstperson_righthand':{'rotation':[0,45,0],'translation':[0,2,0],'scale':[.4,.4,.4]}}})
    item_definition(f'drone_{i}')

def mcube(a,b,texture='metal'):return part(a,b,texture,angle=0)
STEEL=(150,166,178);STEEL_DARK=(92,110,124);BRASS=(222,170,72)
def chestplate(im,plate,trim,gem):
    im.rect(1,3,5,7,color_shift(plate,25));im.rect(11,3,15,7,color_shift(plate,25))
    im.rect(4,3,12,14,plate);im.rect(6,3,10,5,(0,0,0,0));im.rect(7,5,9,6,(0,0,0,0))
    im.rect(5,6,11,7,color_shift(plate,20));im.rect(4,11,12,12,trim);im.rect(7,7,9,13,color_shift(plate,-18))
    im.rect(7,8,9,10,gem)
def draw_gear(name):
    im=Pixels(16,16)
    if name in ('ring','ring2'):
        band,gem=(BRASS,(84,226,204)) if name=='ring' else ((200,210,220),(232,64,72))
        im.ring(8,9.5,4.3,.8,band);im.disc(8,4.6,2.3,color_shift(gem,-40));im.disc(8,4.6,1.5,gem);im.set(7,4,(255,255,255))
    elif name=='helmet':
        im.disc(8,9,6.2,STEEL);im.rect(0,11,16,16,(0,0,0,0))
        im.rect(2,9,5,14,STEEL_DARK);im.rect(11,9,14,14,STEEL_DARK);im.rect(4,9,12,11,(30,38,48))
        im.rect(7,9,9,13,BRASS);im.rect(7,2,9,5,(206,64,58));im.rect(6,1,10,3,(226,88,70))
    elif name=='chest':
        chestplate(im,(118,144,160),BRASS,(84,226,204))
    elif name=='legs':
        im.rect(3,2,13,5,(160,120,74));im.rect(7,2,9,5,BRASS)
        im.rect(3,5,7,15,STEEL_DARK);im.rect(9,5,13,15,STEEL_DARK)
        im.rect(3,8,7,10,STEEL);im.rect(9,8,13,10,STEEL)
    elif name=='boots':
        for x0 in (1,9):
            im.rect(x0+1,4,x0+5,11,STEEL);im.rect(x0+1,4,x0+5,5,BRASS)
            im.rect(x0,11,x0+6,14,STEEL_DARK);im.rect(x0,14,x0+6,15,(52,40,32))
    elif name=='amulet':
        for i in range(6):im.set(3+i,1+i,BRASS if i%2==0 else color_shift(BRASS,-40));im.set(12-i,1+i,BRASS if i%2==0 else color_shift(BRASS,-40))
        im.disc(8,10.5,3.8,BRASS);im.disc(8,10.5,2.5,(160,86,220));im.set(7,9,(236,200,255))
    else:  # offhand buckler
        im.disc(8,8,6.5,(122,82,50));im.ring(8,8,6,.7,STEEL_DARK);im.disc(8,8,2.2,STEEL);im.set(7,7,(232,240,246))
        for x,y in [(8,3),(13,8),(8,13),(3,8)]:im.set(x,y,BRASS)
    polish(im)
    im.save(Path(f'assets/deepforge/textures/item/gear_{name}.png'))
for name in ['offhand','helmet','chest','legs','boots','ring','ring2','amulet']:
    draw_gear(name)
    js(f'assets/deepforge/models/item/gear_{name}.json',{'parent':'minecraft:item/generated','textures':{'layer0':f'deepforge:item/gear_{name}'}});item_definition('gear_'+name)

colors=[((89,99,102),(255,172,61)),((128,98,170),(148,245,240)),((104,125,73),(223,106,71)),((55,120,125),(96,231,243)),((63,49,46),(255,110,33)),((166,149,108),(251,220,105)),((55,43,78),(217,112,252)),
        ((70,30,24),(255,90,20)),((176,182,192),(140,220,255)),((52,70,34),(170,255,60)),((80,92,110),(120,200,255)),((170,150,110),(240,230,200)),
        ((196,186,150),(230,160,255)),((24,20,30),(140,80,220)),((40,36,90),(255,230,120)),((60,82,50),(240,170,60)),((30,16,40),(255,60,160))]
def plated(base,light,seed):
    """32×32 armoured hide: bevelled plates, seams, scratches and a few glowing cracks."""
    im=Pixels(32,32);rng=random.Random(seed)
    for y in range(32):
        for x in range(32):
            row=y//8;px=(x+(4 if row%2 else 0))%8;py=y%8
            n=rng.randint(-7,7)
            if py==0 or px==0:n=-34
            elif py==1 or px==1:n+=16
            elif py==7 or px==7:n-=16
            im.set(x,y,color_shift(base,n))
    for _ in range(4):
        x,y=rng.randrange(2,30),rng.randrange(2,28)
        for i in range(rng.randrange(3,6)):
            im.set(x,y+i,color_shift(light,-20 if i%2 else 10));x+=rng.choice((-1,0,1))
    return im
def glowing(light,seed):
    im=Pixels(32,32);rng=random.Random(seed)
    for y in range(32):
        for x in range(32):
            d=math.hypot((x%16)-7.5,(y%16)-7.5)
            im.set(x,y,color_shift(light,int(40-d*6)+rng.randint(-6,6)))
    for _ in range(10):im.set(rng.randrange(32),rng.randrange(32),(255,255,244))
    return im
def tinted(im,color,amount):
    out=Pixels(im.w,im.h)
    for i,c in enumerate(im.data):out.data[i]=[int(c[k]*(1-amount)+color[k]*amount) for k in range(3)]+[c[3]]
    return out
for zone,(stone,light) in enumerate(colors):
    for kind,im in [('skin',plated(stone,light,713+zone)),('core',glowing(light,913+zone))]:
        im.save(Path(f'assets/deepforge/textures/item/mobs/mob_{zone}_{kind}.png'))
        # Keep the material detail during the brief red hit flash.
        tinted(im,(238,85,76) if kind=='skin' else (255,192,139),.6).save(Path(f'assets/deepforge/textures/item/mobs/mob_{zone}_{kind}_hit.png'))
    meshes={
      'body':[mcube([1,0,2],[15,16,14]),mcube([0,11,1],[16,15,15],'copper')],
      'head':[mcube([2,0,2],[14,12,14]),mcube([3,6,1],[6,8,2],'glow'),mcube([10,6,1],[13,8,2],'glow')],
      'arm':[mcube([3,-5,3],[13,14,13]),mcube([1,-7,1],[15,-1,15],'copper')],
      'leg':[mcube([3,0,4],[13,14,13]),mcube([1,0,0],[15,4,14],'copper')],
      'core':[mcube([5,4,6],[11,11,10],'glow')]
    }
    shape=zone%7
    if zone>=7:
        # Deep-mine monsters: the old silhouettes, crowned with glowing horns and shoulder shards.
        meshes['head'] += [mcube([1,12,6],[4,20,9],'glow'),mcube([12,12,6],[15,20,9],'glow')]
        meshes['arm'] += [mcube([4,10,4],[12,16,12],'glow')]
    if shape==0:
        meshes['body'] += [mcube([-3,10,4],[1,20,12]),mcube([15,10,4],[19,20,12])]
        meshes['head'] += [mcube([0,10,0],[16,15,16],'copper')]
    elif shape==1:
        meshes['head'] += [mcube([0,10,5],[4,23,11],'glow'),mcube([6,11,5],[10,27,11]),mcube([12,10,5],[16,23,11],'glow')]
        meshes['body'] += [mcube([-3,3,5],[1,20,11]),mcube([15,3,5],[19,20,11])]
    elif shape==2:
        meshes['head'] += [mcube([-5,10,-5],[21,15,21],'copper'),mcube([-1,15,-1],[17,19,17]),mcube([2,15,1],[6,20,5],'glow'),mcube([10,15,9],[14,20,13],'glow')]
        meshes['body'] += [mcube([-2,2,5],[2,11,11],'glow'),mcube([14,6,5],[18,14,11],'glow')]
    elif shape==3:
        meshes['head'] += [mcube([-5,3,6],[2,17,10],'copper'),mcube([14,3,6],[21,17,10],'copper')]
        meshes['body'] += [mcube([3,2,0],[13,4,2],'glow'),mcube([3,7,0],[13,9,2],'glow')]
    elif shape==4:
        meshes['body'] += [mcube([5,1,0],[11,15,2],'glow'),mcube([-3,12,5],[2,24,11]),mcube([14,12,5],[19,24,11])]
        meshes['arm'] += [mcube([1,-1,0],[15,3,2],'glow')]
    elif shape==5:
        meshes['head'] += [mcube([-1,10,-1],[17,15,17],'copper'),mcube([6,15,5],[10,23,11],'glow')]
        meshes['body'] += [mcube([3,2,0],[13,4,2],'glow'),mcube([3,8,0],[13,10,2],'glow')]
    else:
        meshes['body']=[mcube([3,1,4],[13,13,12]),mcube([-4,13,5],[0,22,11],'copper'),mcube([16,13,5],[20,22,11],'copper'),mcube([4,-5,5],[12,-1,11],'glow')]
        meshes['head'] += [mcube([-3,8,5],[1,22,11],'glow'),mcube([15,8,5],[19,22,11],'glow')]
    for bone,elements in meshes.items():
        name=f'mob_{zone}_{bone}'
        js(f'assets/deepforge/models/item/{name}.json',{'textures':{'metal':f'deepforge:item/mobs/mob_{zone}_skin','copper':'deepforge:block/copper','glow':f'deepforge:item/mobs/mob_{zone}_core','particle':f'deepforge:item/mobs/mob_{zone}_skin'},'elements':elements})
        item_definition(name)
        js(f'assets/deepforge/models/item/{name}_hit.json',{'parent':f'deepforge:item/{name}','textures':{'metal':f'deepforge:item/mobs/mob_{zone}_skin_hit','copper':f'deepforge:item/mobs/mob_{zone}_skin_hit','glow':f'deepforge:item/mobs/mob_{zone}_core_hit','particle':f'deepforge:item/mobs/mob_{zone}_skin_hit'}})
        item_definition(name+'_hit')


for zone in range(7):
    name=f'unique_{zone}'
    if zone in (2,5):
        base,light=colors[zone]
        im=Pixels(16,16);chestplate(im,color_shift(base,20),light,light);polish(im)
        im.save(Path(f'assets/deepforge/textures/item/{name}.png'))
        js(f'assets/deepforge/models/item/{name}.json',{'parent':'minecraft:item/generated','textures':{'layer0':f'deepforge:item/{name}'}})
    else:
        style='hammer' if zone in (0,4) else 'spear' if zone==3 else 'sword'
        js(f'assets/deepforge/models/item/{name}.json',{'parent':f'deepforge:item/weapon_{style}','textures':{'metal':f'deepforge:item/mobs/mob_{zone}_skin','glow':f'deepforge:item/mobs/mob_{zone}_core','particle':f'deepforge:item/mobs/mob_{zone}_skin'}})
    item_definition(name)

healing=Pixels(16,16)
for y in range(16):
    for x in range(16):
        facet=(x//4+y//5)%3
        healing.set(x,y,color_shift((64,210,166),(26,0,-24)[facet]+int(20-abs(x-7.5)*3)))
for i in range(16):healing.set(i,(i*5)%16,(214,255,236))
healing.save(Path('assets/deepforge/textures/item/healing_crystal.png'))
model('healing_crystal',[cube([5,2,5],[11,12,11],'glow'),cube([6,0,6],[10,2,10],'copper'),cube([6,12,6],[10,15,10],'glow')])
healing_model=json.loads((PACK/'assets/deepforge/models/item/healing_crystal.json').read_text(encoding='utf8'))
healing_model['textures']['glow']='deepforge:item/healing_crystal'
healing_model['display']['firstperson_righthand']={'rotation':[0,0,12],'translation':[0,1,0],'scale':[.65]*3}
healing_model['display']['firstperson_lefthand']=healing_model['display']['firstperson_righthand']
healing_model['display']['thirdperson_lefthand']=healing_model['display']['thirdperson_righthand']
js('assets/deepforge/models/item/healing_crystal.json',healing_model)
item_definition('healing_crystal')

# ---- Pinguin Netzwerk style (deepforge:netz) ----
# Tab list, sidebar and name tags use the glyphs of the network pack (resourcepack/netz, taken
# unchanged from the Pinguin Netzwerk pack) plus a DEEPFORGE logo and panel header drawn here in
# the same pixel style. Own namespace, so it never clashes with the network pack itself.
NETZ = ROOT/'netz'

def read_png(path):
    """Minimal stdlib PNG reader for 8-bit RGBA, non-interlaced images."""
    data=path.read_bytes(); pos=8; w=h=0; idat=b''
    while pos<len(data):
        n=struct.unpack('>I',data[pos:pos+4])[0]; kind=data[pos+4:pos+8]; body=data[pos+8:pos+8+n]; pos+=12+n
        if kind==b'IHDR':
            w,h,depth,ctype=struct.unpack('>IIBB',body[:10])
            assert depth==8 and ctype==6, path
        elif kind==b'IDAT': idat+=body
    raw=zlib.decompress(idat); stride=w*4; out=[]; prev=bytearray(stride); i=0
    for _ in range(h):
        f=raw[i]; line=bytearray(raw[i+1:i+1+stride]); i+=1+stride
        for x in range(stride):
            a=line[x-4] if x>=4 else 0; b=prev[x]; c=prev[x-4] if x>=4 else 0
            if f==1: line[x]=(line[x]+a)&255
            elif f==2: line[x]=(line[x]+b)&255
            elif f==3: line[x]=(line[x]+(a+b)//2)&255
            elif f==4:
                pa,pb,pc=abs(b-c),abs(a-c),abs(a+b-2*c)
                line[x]=(line[x]+(a if pa<=pb and pa<=pc else b if pb<=pc else c))&255
        out.append(line); prev=line
    im=Pixels(w,h)
    for y in range(h):
        for x in range(w): im.set(x,y,tuple(out[y][x*4:x*4+4]))
    return im

# 5x7 letters; the network logos are exactly these, doubled and outlined.
FONT5={
 'D':['XXXX.','X...X','X...X','X...X','X...X','X...X','XXXX.'],
 'E':['XXXXX','X....','X....','XXXX.','X....','X....','XXXXX'],
 'P':['XXXX.','X...X','X...X','XXXX.','X....','X....','X....'],
 'F':['XXXXX','X....','X....','XXXX.','X....','X....','X....'],
 'O':['.XXX.','X...X','X...X','X...X','X...X','X...X','.XXX.'],
 'R':['XXXX.','X...X','X...X','XXXX.','X.X..','X..X.','X...X'],
 'G':['.XXX.','X...X','X....','X.XXX','X...X','X...X','.XXXX'],
}
NETZ_DARK,NETZ_LIGHT,NETZ_ORANGE=(58,28,0,255),(255,181,71,255),(255,138,0,255)

def netz_logo(text):
    im=Pixels(12*len(text)+2,18); fill={}
    for i,ch in enumerate(text):
        ox=2+12*i
        for r,row in enumerate(FONT5[ch]):
            for c,bit in enumerate(row):
                if bit=='X':
                    for dy in (0,1):
                        for dx in (0,1): fill[(ox+2*c+dx,2+2*r+dy)]=NETZ_LIGHT if r==0 else NETZ_ORANGE
    for y in range(im.h):
        for x in range(im.w):
            if (x,y) in fill: im.set(x,y,fill[(x,y)])
            elif any((x+dx,y+dy) in fill for dx in (-1,0,1) for dy in (-1,0,1)): im.set(x,y,NETZ_DARK)
    return im

def netz_header(text):
    # Keep the frame and the small "PINGUIN NETZWERK" line of the network header, redraw the band.
    im=read_png(NETZ/'panel_header_lobby.png')
    im.rect(0,1,im.w,11,NETZ_ORANGE)
    width=6*len(text)-1; x0=(im.w-width)//2
    def diamond(cx):
        for dy,half in ((-2,0),(-1,1),(0,2),(1,1),(2,0)):
            for dx in range(-half,half+1): im.set(cx+dx,5+dy,NETZ_DARK)
    diamond(x0-7); diamond(x0+width+6)
    for i,ch in enumerate(text):
        for r,row in enumerate(FONT5[ch]):
            for c,bit in enumerate(row):
                if bit=='X': im.set(x0+6*i+c+1,2+r+1,(179,89,0,255))
    for i,ch in enumerate(text):
        for r,row in enumerate(FONT5[ch]):
            for c,bit in enumerate(row):
                if bit=='X': im.set(x0+6*i+c,2+r,(255,255,255,255))
    return im

netz_logo('DEEPFORGE').save(Path('assets/deepforge/textures/font/netz/tab_logo_deepforge.png'))
netz_header('DEEPFORGE').save(Path('assets/deepforge/textures/font/netz/panel_header_deepforge.png'))
netz_providers=[]
for provider in json.loads((NETZ/'network-font.json').read_text(encoding='utf-8'))['providers']:
    if provider['type']=='space':
        netz_providers.append(provider); continue
    name=provider['file'].split('/')[-1]
    (PACK/'assets/deepforge/textures/font/netz').mkdir(parents=True,exist_ok=True)
    (PACK/'assets/deepforge/textures/font/netz'/name).write_bytes((NETZ/name).read_bytes())
    netz_providers.append({**provider,'file':'deepforge:font/netz/'+name})
netz_providers.append({'type':'bitmap','file':'deepforge:font/netz/tab_logo_deepforge.png','ascent':7,'height':18,'chars':['']})
netz_providers.append({'type':'bitmap','file':'deepforge:font/netz/panel_header_deepforge.png','ascent':22,'height':24,'chars':['']})
js('assets/deepforge/font/netz.json',{'providers':netz_providers})

# Vanilla hearts and hunger are hidden; the Deepforge HUD shows life at all times instead.
# Mount hearts (vehicle_*) stay so horses still show their health.
blank=Pixels(9,9)

# ---- 0.9.3: icons for runes, eggs, companions, star stone, guilds, mastery, pass, sets, Tiefengang ----
def new_icon():
    return Pixels(16,16)
def shade(c,n): return color_shift(c,n)
def line(im,x0,y0,x1,y1,c):
    n=max(abs(x1-x0),abs(y1-y0),1)
    for i in range(n+1):im.set(round(x0+(x1-x0)*i/n),round(y0+(y1-y0)*i/n),c)
def finish_icon(name,im):
    polish(im);im.save(Path(f'assets/deepforge/textures/item/{name}.png'))
    js(f'assets/deepforge/models/item/{name}.json',{'parent':'minecraft:item/generated','textures':{'layer0':f'deepforge:item/{name}'}})
    item_definition(name)

# Runes: a weathered stone tablet with a glowing glyph in the rune's colour.
RUNE_COLORS={'kraft':(236,70,58),'stein':(176,184,196),'leben':(104,226,98),'wind':(120,226,236),'glueck':(96,236,148),'tiefe':(92,128,246)}
RUNE_GLYPH={
 'kraft':[(8,4,8,11),(5,6,8,4),(11,6,8,4),(6,11,10,11)],
 'stein':[(5,5,11,5),(5,5,5,11),(11,5,11,11),(5,11,11,11),(8,7,8,9)],
 'leben':[(8,5,8,12),(5,8,11,8),(6,6,6,6),(10,6,10,6)],
 'wind':[(4,6,11,6),(11,6,12,5),(5,9,12,9),(12,9,11,11),(6,12,9,12)],
 'glueck':[(8,4,4,8),(4,8,8,12),(8,12,12,8),(12,8,8,4)],
 'tiefe':[(8,4,8,12),(5,9,8,12),(11,9,8,12),(5,5,11,5)]}
for kind,glow_c in RUNE_COLORS.items():
    im=new_icon();stone=(86,88,98) if kind!='stein' else (70,74,84)
    for y in range(2,15):
        w=5 if 3<y<13 else 4
        im.rect(8-w,y,8+w,y+1,shade(stone,((y*7)%5)-2))
    im.rect(4,3,12,4,shade(stone,14));im.set(3,6,shade(stone,-20));im.set(12,11,shade(stone,-24))
    for x0,y0,x1,y1 in RUNE_GLYPH[kind]:
        line(im,x0,y0,x1,y1,glow_c)
    for x0,y0,x1,y1 in RUNE_GLYPH[kind]:
        im.set(x0,y0,shade(glow_c,50))
    finish_icon(f'rune_{kind}',im)
im=new_icon()
im.rect(4,6,12,15,(128,86,52));im.rect(5,7,11,14,(150,104,64));im.rect(3,5,13,7,(104,68,40));im.rect(6,3,10,5,(128,86,52))
im.rect(7,2,9,3,(200,160,90));im.rect(6,9,10,13,(92,94,106));line(im,8,9,8,12,RUNE_COLORS['glueck']);line(im,7,10,9,10,RUNE_COLORS['glueck'])
im.set(5,8,(255,230,160))
finish_icon('rune_bag',im)

# Eggs by rarity: speckled shell, rarer eggs glow.
EGG={'uncommon':((222,232,206),(98,168,72)),'rare':((208,224,244),(66,120,214)),'epic':((226,206,244),(150,74,220)),'legendary':((250,232,178),(226,160,36)),'mythic':((252,206,214),(222,52,96))}
for rarity,(shell,spot) in EGG.items():
    im=new_icon()
    for y in range(1,16):
        for x in range(16):
            dy=(y+.5-9.2)/(6.8 if y+.5<9.2 else 5.8)
            if abs(dy)>=1: continue
            half=5.3*math.sqrt(1-dy*dy)*(0.78+0.22*(y/15))
            if abs(x+.5-8)<=half: im.set(x,y,shade(shell,-int(((y-1)/14)*26+max(0,(x-8))*2)))
    for x,y in [(6,5),(9,7),(5,9),(10,11),(7,12),(8,4),(11,9)]:im.set(x,y,spot)
    im.rect(6,4,7,6,shade(shell,30))
    if rarity in ('legendary','mythic','epic'):
        for x,y in [(2,3),(13,4),(14,12),(1,11)]:im.set(x,y,shade(spot,60))
    finish_icon(f'egg_{rarity}',im)

# Companions: small creature portraits.
def pet(name,body,accent,draw):
    im=new_icon();draw(im,body,accent);finish_icon(f'pet_{name}',im)
def beetle(im,b,a):
    im.disc(8,9,5.5,b);im.rect(8,4,9,15,shade(b,-40));im.disc(8,4,2.5,shade(b,-20))
    for y in (7,10,13):im.set(2,y,shade(b,-50));im.set(13,y,shade(b,-50))
    im.set(6,8,a);im.set(10,10,a);im.set(7,3,(255,255,255));im.set(9,3,(255,255,255))
def fox(im,b,a):
    im.disc(8,9,5,b);im.rect(3,3,6,7,b);im.rect(10,3,13,7,b);im.set(4,4,a);im.set(11,4,a)
    im.rect(6,11,10,14,(246,240,228));im.set(6,8,(30,30,34));im.set(9,8,(30,30,34));im.rect(7,11,9,12,(40,30,30))
def leech(im,b,a):
    for i in range(6):im.disc(4+i*1.6,11-math.sin(i*.9)*3,2.6,shade(b,i*6))
    im.disc(13,6,2.2,a);im.set(13,6,(250,250,250))
def ember(im,b,a):
    im.disc(8,10,5,b);im.disc(8,7,3.5,a);im.rect(7,1,9,5,a);im.set(5,4,a);im.set(11,3,a)
    im.set(6,10,(40,20,10));im.set(10,10,(40,20,10));im.disc(8,9,1.2,(255,250,200))
def frost(im,b,a):
    im.disc(8,9,5,b)
    for dx,dy in [(0,-6),(0,6),(-6,0),(6,0),(-4,-4),(4,4),(-4,4),(4,-4)]:line(im,8,9,8+dx,9+dy,a)
    im.set(6,8,(20,40,80));im.set(10,8,(20,40,80))
def golem(im,b,a):
    im.rect(3,4,13,15,b);im.rect(2,7,4,13,shade(b,-20));im.rect(12,7,14,13,shade(b,-20));im.rect(5,6,7,8,a);im.rect(9,6,11,8,a)
    im.rect(6,11,10,12,shade(b,-50));im.set(4,5,shade(b,25))
def mole(im,b,a):
    im.disc(8,9,5.5,b);im.disc(8,12,2.5,a);im.set(8,12,(60,30,30));im.set(6,8,(20,20,20));im.set(10,8,(20,20,20))
    for x in (3,5,11,13):im.set(x,14,(240,220,200))
pet('panzerkaefer',(62,92,120),(150,220,255),beetle)
pet('flinkling',(226,122,48),(40,30,30),fox)
pet('blutegel',(120,40,52),(230,70,80),leech)
pet('glutling',(200,70,30),(255,190,60),ember)
pet('frostling',(170,214,244),(236,250,255),frost)
pet('felsriese',(120,116,110),(120,240,255),golem)
pet('erzschnueffler',(92,72,60),(236,170,160),mole)

# Sternenstein: a faceted star gem with a halo.
im=new_icon()
for i in range(5):
    a=-math.pi/2+i*2*math.pi/5
    line(im,8,8,round(8+6.5*math.cos(a)),round(8+6.5*math.sin(a)),(255,226,120))
im.disc(8,8,3.4,(255,214,90));im.disc(8,8,2,(255,250,220));im.set(7,7,(255,255,255))
for x,y in [(2,2),(13,3),(3,13),(14,13)]:im.set(x,y,(200,170,255))
finish_icon('star_stone',im)

# Guild: banner, invitation, ranks, buildings, weekly task.
def banner(color,name,emblem=(236,196,90)):
    im=new_icon();im.rect(7,1,9,16,(116,80,48));im.rect(3,2,13,3,(150,110,70))
    im.rect(4,3,12,12,color);im.rect(4,12,6,14,color);im.rect(10,12,12,14,color);im.rect(7,12,9,13,color)
    im.disc(8,7,2.4,emblem);im.set(8,7,shade(color,-30));finish_icon(name,im)
banner((60,120,190),'guild_banner');banner((80,176,80),'guild_invite',(255,255,255))
def helmet(name,c,gem):
    im=new_icon();im.disc(8,9,5.5,c);im.rect(2,9,14,16,(0,0,0,0));im.rect(3,9,13,11,shade(c,-25));im.rect(7,5,9,11,shade(c,-40))
    im.rect(3,11,5,13,shade(c,-25));im.rect(11,11,13,13,shade(c,-25));im.set(8,4,gem)
    if name=='rank_leader':
        for x in (4,8,12):im.rect(x-1,1,x,4,(250,210,70))
    finish_icon(name,im)
helmet('rank_leader',(236,186,60),(230,40,60));helmet('rank_officer',(190,196,206),(80,140,240));helmet('rank_member',(150,100,64),(120,200,120))
def building(name,draw):
    im=new_icon();im.rect(2,8,14,15,(150,112,80));im.rect(1,6,15,8,(120,60,48));im.rect(3,5,13,6,(140,70,56));im.rect(6,11,10,15,(80,56,40))
    draw(im);finish_icon(name,im)
building('building_kaserne',lambda im:(line(im,4,2,11,9,(210,214,220)),line(im,5,9,3,11,(150,100,60))))
building('building_lazarett',lambda im:(im.rect(7,1,9,6,(230,60,60)),im.rect(5,3,11,5,(230,60,60))))
building('building_werkstatt',lambda im:(im.disc(8,3,2.6,(160,164,172)),im.disc(8,3,1,(90,90,96))))
building('building_schatzkammer',lambda im:(im.rect(5,1,11,5,(236,190,70)),im.rect(5,2,11,3,(160,110,40))))
building('building_gildenhalle',lambda im:(im.rect(7,0,9,5,(116,80,48)),im.rect(9,0,12,2,(60,120,190))))
im=new_icon();im.rect(3,3,13,14,(232,216,176));im.rect(2,2,14,4,(196,170,120));im.rect(2,13,14,15,(196,170,120))
for y in (6,8,10):im.rect(5,y,11,y+1,(120,96,70))
im.rect(10,10,13,13,(60,160,70));finish_icon('guild_task',im)

# Mastery & talents.
im=new_icon();im.rect(3,2,13,14,(52,68,120));im.rect(3,2,5,14,(36,46,86));im.rect(12,3,14,14,(238,226,196))
for i in range(5):
    a=-math.pi/2+i*2*math.pi/5;line(im,9,8,round(9+3.5*math.cos(a)),round(8+3.5*math.sin(a)),(255,214,90))
finish_icon('mastery',im)
im=new_icon();line(im,3,13,12,4,(210,214,224));line(im,4,13,13,4,(170,176,188));line(im,3,10,6,13,(150,100,60));im.rect(11,3,14,6,(210,214,224));finish_icon('talent_warrior',im)
im=new_icon();line(im,4,13,11,6,(150,100,60));line(im,5,13,12,6,(120,80,50))
for x in range(3,14):im.set(x,max(2,3+abs(x-8)//2),(170,176,190))
finish_icon('talent_miner',im)
im=new_icon();im.disc(8,10,5,(176,130,70));im.rect(6,3,10,6,(150,110,60));im.rect(5,5,11,6,(120,86,50));im.disc(8,10,2.2,(250,210,90));finish_icon('talent_trader',im)
im=new_icon();im.disc(8,8,5.5,(70,90,120));im.disc(8,8,3.5,(140,190,240));finish_icon('talent_node',im)
im=new_icon();im.disc(8,8,5.5,(60,150,70));line(im,5,8,7,10,(240,255,240));line(im,7,10,11,5,(240,255,240));finish_icon('talent_done',im)
im=new_icon();im.rect(4,7,12,14,(150,150,160));im.ring(8,6,3,.7,(120,120,130));im.rect(7,9,9,12,(60,60,70));finish_icon('locked',im)

# Tiefenpass & gear sets.
im=new_icon();im.rect(2,4,14,12,(60,110,170));im.rect(2,4,14,5,(120,170,230));im.rect(9,4,10,12,(230,210,120))
for y in (6,8,10):im.set(4,y,(230,240,255))
finish_icon('pass',im)
im=new_icon();im.rect(3,7,13,14,(200,60,60));im.rect(2,5,14,7,(230,80,80));im.rect(7,5,9,14,(250,210,80));im.rect(5,3,7,5,(250,210,80));im.rect(9,3,11,5,(250,210,80));finish_icon('pass_open',im)
im=new_icon();im.disc(8,8,5.5,(60,150,70));line(im,5,8,7,10,(240,255,240));line(im,7,10,11,5,(240,255,240));finish_icon('pass_claimed',im)
def chest_icon(check):
    im=new_icon();plate=(120,140,164)
    im.rect(3,3,6,6,plate);im.rect(10,3,13,6,plate);im.rect(2,5,14,8,plate);im.rect(4,8,12,14,shade(plate,-10))
    im.rect(6,3,10,5,(0,0,0,0));im.rect(7,6,9,13,shade(plate,25));im.rect(4,13,12,14,(200,160,80))
    if check:
        im.disc(12,12,3.2,(60,170,70));line(im,10,12,11,13,(255,255,255));line(im,11,13,13,11,(255,255,255))
    return im
finish_icon('preset',chest_icon(False))
finish_icon('preset_active',chest_icon(True))

# Loot bag helpers.
im=new_icon()
for i,(w,c) in enumerate([(10,(170,120,240)),(7,(96,160,236)),(4,(110,200,110))]):im.rect(3,3+i*4,3+w,5+i*4,c)
line(im,13,3,13,13,(230,230,230));line(im,11,11,13,13,(230,230,230));line(im,15,11,13,13,(230,230,230));finish_icon('sort',im)
im=new_icon();im.rect(2,2,14,14,(90,100,110));im.rect(3,3,13,13,(40,48,56));line(im,5,8,7,10,(120,240,120));line(im,7,10,11,5,(120,240,120));finish_icon('select_all',im)

# Tiefengang: a spiral shaft sinking into the dark.
im=new_icon();im.disc(8,8,7,(30,24,40))
for r,c in [(6,(90,70,120)),(4.4,(70,56,100)),(2.8,(50,40,80))]:im.ring(8,8,r,.6,c)
for i in range(18):
    a=i*.62;rr=6.5-i*.33;im.set(round(8+rr*math.cos(a)),round(8+rr*math.sin(a)),(120,230,240))
im.disc(8,8,1.2,(0,0,0));finish_icon('deep_descent',im)


# 0.10.0: wiki book – open tome with a glowing pickaxe emblem.
im=new_icon()
im.rect(1,3,8,14,(236,226,198));im.rect(8,3,15,14,(226,214,184));im.rect(7,2,9,15,(120,76,44))
im.rect(1,13,15,15,(96,60,36));im.rect(0,4,1,14,(120,76,44));im.rect(15,4,16,14,(120,76,44))
for y in (5,7,9,11):im.rect(2,y,7,y+1,(170,150,120))
line(im,10,11,13,5,(90,190,230));line(im,11,5,14,7,(250,210,90));line(im,9,5,11,4,(250,210,90))
im.set(12,4,(255,255,230))
finish_icon('wiki',im)

# 0.11.0: Wächter (dungeon minibosses) – one emblem each, plus the Wächtertruhe.
im=new_icon()  # Schildträger: kite shield with a gold boss
im.rect(3,2,13,9,(96,110,130));im.rect(4,9,12,12,(96,110,130));im.rect(6,12,10,14,(96,110,130));im.set(7,14,(96,110,130));im.set(8,14,(96,110,130))
im.rect(7,2,9,14,(160,40,40));im.rect(3,6,13,8,(160,40,40));im.disc(8,7,1.6,(240,200,80));finish_icon('guard_shield',im)
im=new_icon()  # Beschwörer: hooded skull with three soul flames
im.disc(8,9,4.5,(60,40,90));im.disc(8,9,3,(210,210,200));im.rect(6,9,8,10,(20,20,30));im.rect(9,9,11,10,(20,20,30));im.rect(7,11,10,12,(90,80,80))
for x in (2,8,14):im.rect(x-1,1,x,4,(90,220,240));im.set(x-1,0,(200,250,255))
finish_icon('guard_caller',im)
im=new_icon()  # Zwillinge: two linked masks, one red one blue
im.disc(5,8,3.6,(210,70,70));im.disc(11,8,3.6,(70,110,220))
for x,y in ((4,7),(6,7),(10,7),(12,7)):im.set(x,y,(20,20,20))
line(im,4,10,6,10,(40,20,20));line(im,10,10,12,10,(20,20,50));line(im,7,4,9,4,(200,120,240));line(im,7,12,9,12,(200,120,240))
finish_icon('guard_twins',im)
im=new_icon()  # Spiegelritter: shining mirror with a sword
im.disc(8,7,5,(150,150,165));im.disc(8,7,3.8,(210,236,250));line(im,6,5,8,3,(255,255,255));line(im,6,8,10,4,(255,255,255))
im.rect(7,12,9,16,(120,80,50));im.rect(5,12,11,13,(200,170,80))
finish_icon('guard_mirror',im)
im=new_icon()  # Kettenbrecher: broken chain links
for cx,cy in ((4,4),(8,8),(12,12)):im.ring(cx,cy,2.6,.6,(170,176,186))
im.rect(9,9,11,11,(0,0,0,0));im.set(10,6,(250,200,80));im.set(12,7,(250,200,80));im.set(7,12,(250,200,80));finish_icon('guard_chain',im)
im=new_icon()  # Wurzelhexe: thorny roots growing from the ground
im.rect(0,13,16,16,(90,60,40))
for x0,x1,top in ((3,5,5),(7,9,2),(11,13,6)):
    im.rect(x0,top,x1,13,(90,120,50));im.set(x0-1,top+2,(160,220,90));im.set(x1,top+4,(160,220,90))
im.disc(8,2,1.5,(220,60,120));finish_icon('guard_root',im)
im=new_icon()  # Wächtertruhe: dark chest with a red seal
im.rect(2,5,14,14,(90,60,40));im.rect(2,5,14,8,(120,80,50));im.rect(2,8,14,9,(60,40,30));im.disc(8,9,2,(200,40,40));im.set(8,9,(250,220,120))
im.rect(2,13,14,14,(200,170,80));finish_icon('guard_chest',im)

# 0.12.0: Prestige – a golden star on an ember core, and the five Glut talents.
im=new_icon();im.disc(8,8,6.5,(120,30,10));im.disc(8,8,4.5,(230,90,20))
pts=[(8,1),(10,6),(15,6),(11,9),(13,15),(8,11),(3,15),(5,9),(1,6),(6,6)]
for i in range(len(pts)):
    a,b=pts[i],pts[(i+1)%len(pts)];line(im,a[0],a[1],b[0],b[1],(255,215,70))
for y in range(5,12):
    for x in range(4,13):
        if abs(x-8)+abs(y-8)<=3:im.set(x,y,(255,225,110))
im.set(8,8,(255,255,230));finish_icon('prestige_star',im)
ember=(255,120,30)
im=new_icon();im.rect(1,10,15,15,(70,60,60))  # Glutader: glowing vein in rock
for x,y in ((2,12),(4,11),(6,12),(8,11),(10,12),(12,11),(14,12)):im.set(x,y,ember);im.set(x,y+1,(255,190,80))
im.disc(8,5,3.5,(255,150,40));im.disc(8,5,2,(255,230,140));finish_icon('glut_ader',im)
im=new_icon();line(im,3,13,12,4,(90,70,80));line(im,4,13,13,4,(60,50,60));line(im,4,12,12,4,ember)  # Glutklinge
im.rect(2,11,6,12,(200,160,80));im.rect(2,13,4,15,(120,80,50));im.set(13,3,(255,230,140));finish_icon('glut_klinge',im)
im=new_icon();im.rect(3,2,13,10,(70,60,70));im.rect(4,10,12,13,(70,60,70));im.rect(6,13,10,15,(70,60,70))  # Glutpanzer
im.rect(7,3,9,13,ember);im.rect(4,6,12,8,ember);im.disc(8,7,1.5,(255,230,140));finish_icon('glut_panzer',im)
im=new_icon();im.rect(6,1,10,4,(90,80,90));im.rect(5,4,11,8,(70,60,70))  # Glutbohrer
for y,w in ((8,3),(9,3),(10,2),(11,2),(12,1),(13,1),(14,0)):im.rect(8-w,y,8+w+1 if w else 9,y+1,ember if y%2 else (255,190,80))
finish_icon('glut_bohrer',im)
im=new_icon()  # Glutkapital: stacked gold coins with an ember
for i,y in enumerate((12,10,8,6)):im.rect(3+i%2,y,12+i%2,y+2,(230,180,60));im.rect(3+i%2,y,12+i%2,y+1,(255,220,110))
im.disc(12,4,2.6,ember);im.disc(12,4,1.2,(255,230,140));finish_icon('glut_kapital',im)

# 0.13.0: Alchemie – brewing stand, six potion flasks, three ingredients.
im=new_icon();im.rect(2,13,14,15,(90,70,50));im.rect(7,3,9,13,(120,100,80));im.disc(8,3,1.6,(200,170,90))
for x in (3,12):im.rect(x,9,x+2,13,(150,200,230));im.rect(x,11,x+2,13,(200,80,200))
im.rect(7,10,9,13,(230,120,40));finish_icon('alchemy_table',im)
def flask(name,liquid,glow):
    im=new_icon();im.rect(6,1,10,3,(150,110,70));im.rect(7,3,9,6,(210,225,235))
    im.disc(8,10.5,4.8,(210,225,235));im.disc(8,11,3.9,liquid)
    for x in range(4,13):
        for y in range(7,10):
            if (x+.5-8)**2+(y+.5-10.5)**2<=4.8**2:im.set(x,y,(200,220,235))
    im.set(6,10,glow);im.set(7,9,glow);im.set(10,13,shade(liquid,-30));finish_icon(name,im)
flask('potion_strength',(220,50,40),(255,190,170))
flask('potion_tough',(240,150,40),(255,230,160))
flask('potion_miner',(90,170,230),(210,240,255))
flask('potion_gold',(240,200,40),(255,250,190))
flask('potion_swift',(90,220,120),(210,255,220))
flask('potion_guard',(130,80,220),(220,200,255))
im=new_icon();im.disc(8,8,5,(40,20,60));im.disc(8,8,3.4,(110,60,170));im.disc(8,8,1.6,(210,170,255))  # Schattenessenz
for x,y in ((2,3),(13,4),(3,13),(13,12)):im.set(x,y,(170,120,230))
finish_icon('ing_essence',im)
im=new_icon();im.rect(1,11,15,15,(70,60,60))  # Glutmoos
for x0,h in ((2,3),(4,5),(6,4),(8,6),(10,4),(12,5),(14,3)):im.rect(x0,11-h,x0+1,11,(120,170,60));im.set(x0,11-h,(250,170,60))
finish_icon('ing_moss',im)
im=new_icon();line(im,8,15,8,4,(70,120,40))  # Waldkraut
for y in (5,8,11):line(im,8,y,4,y-2,(90,170,60));line(im,8,y,12,y-2,(90,170,60))
im.disc(8,3,1.5,(240,240,120));finish_icon('ing_herb',im)

# 0.14.0: Archäologie – museum shelf, collection book and four kinds of finds.
im=new_icon();im.rect(1,2,15,15,(110,80,50));im.rect(2,3,14,14,(60,40,25))  # museum: shelf with exhibits
im.rect(2,8,14,9,(110,80,50));im.disc(5,6,1.8,(230,210,170));im.rect(9,4,12,8,(90,170,220));im.rect(3,10,6,14,(200,160,60));im.disc(10,12,1.8,(170,90,200))
finish_icon('museum',im)
im=new_icon();im.rect(3,2,13,15,(120,60,40));im.rect(4,3,12,14,(150,80,50));im.rect(12,3,13,14,(230,220,190))  # collection book
im.disc(8,7,2.4,(230,190,80));im.set(8,7,(255,240,190));line(im,6,11,10,11,(230,190,80));finish_icon('collection_book',im)
im=new_icon();line(im,3,12,12,3,(225,215,190));line(im,4,12,12,4,(200,190,165))  # bone
for cx,cy in ((3,12),(12,3)):im.disc(cx,cy,1.8,(235,225,200))
finish_icon('find_bone',im)
im=new_icon()  # gem
for y in range(16):
    for x in range(16):
        if abs(x+.5-8)/5+abs(y+.5-7.5)/6.2<=1:im.set(x,y,(80,200,210) if x<8 else (50,150,170))
line(im,5,5,7,3,(220,255,255));finish_icon('find_gem',im)
im=new_icon();im.rect(3,4,13,12,(160,110,60));im.rect(4,5,12,11,(190,140,80))  # old tool/tablet with glyphs
for x in (5,8,11):line(im,x,6,x,9,(90,60,30))
im.rect(3,12,13,13,(110,70,40));finish_icon('find_tool',im)
im=new_icon();im.disc(8,8,6,(90,40,120));im.disc(8,8,4.5,(170,90,220))  # rare: violet relic with gold star
for x,y in ((8,4),(9,7),(12,7),(9.5,9),(10.5,12),(8,10.5),(5.5,12),(6.5,9),(4,7),(7,7)):im.set(int(x),int(y),(255,220,90))
im.disc(8,8,1.6,(255,230,120));finish_icon('find_rare',im)

# 0.15.0: Glänzende Monster – a golden shard and the Glanzbuch.
im=new_icon()
for y in range(16):
    for x in range(16):
        if abs(x+.5-8)/4.2+abs(y+.5-8)/7<=1:im.set(x,y,(250,205,60) if x<8 else (220,160,40))
line(im,6,4,7,3,(255,250,210));im.set(12,3,(255,255,230));im.set(13,2,(255,255,230));im.set(3,12,(255,250,200))
finish_icon('shiny_shard',im)
im=new_icon();im.rect(3,2,13,15,(200,150,40));im.rect(4,3,12,14,(240,195,70));im.rect(12,3,13,14,(250,240,210))
for x,y in ((8,5),(7,8),(9,8),(8,11),(6,8),(10,8),(8,7),(8,9)):im.set(x,y,(255,255,235))
im.set(5,4,(255,255,255));im.set(11,12,(255,255,255));finish_icon('shiny_book',im)

# 0.15.1: Deepforge look for vanilla widgets used by dialogs (wiki): dark slate buttons with an
# ember trim, orange highlight, dark tooltips with an ember frame, orange scroll bar.
GUI=Path('assets/minecraft/textures/gui/sprites')
def gui_meta(path,w,h,border,stretch=False):
    sc={'type':'nine_slice','width':w,'height':h,'border':border}
    if stretch: sc['stretch_inner']=True
    js(str(GUI/(path+'.png.mcmeta')),{'gui':{'scaling':sc}})
def mix(a,b,t): return tuple(int(a[i]+(b[i]-a[i])*t) for i in range(3))
def button(name,edge,inner,top,bottom,shadow,border):
    im=Pixels(200,20)
    for y in range(20):
        for x in range(200):
            if x in (0,199) or y in (0,19): c=edge
            elif x in (1,198) or y==1: c=inner
            elif y>=17: c=shadow
            else: c=mix(top,bottom,(y-2)/14)
            im.set(x,y,c)
    for x,y in ((0,0),(199,0),(0,19),(199,19)): im.set(x,y,(0,0,0,0))
    im.save(GUI/f'widget/{name}.png'); gui_meta(f'widget/{name}',200,20,border)
button('button',(14,12,18),(78,70,84),(52,47,58),(38,34,43),(29,26,33),3)
button('button_highlighted',(255,138,0),(255,190,90),(78,56,40),(58,42,32),(44,32,25),3)
button('button_disabled',(12,12,15),(30,29,34),(28,27,31),(26,25,29),(24,23,27),1)
tb=Pixels(100,100)
for y in range(8,92):
    for x in range(8,92): tb.set(x,y,(24,19,27,244))
tb.save(GUI/'tooltip/background.png'); gui_meta('tooltip/background',100,100,9)
tf=Pixels(100,100)
for i in range(9,91):
    t=(i-9)/81; c=mix((255,170,60),(170,70,0),t)
    tf.set(9,i,(*c,230)); tf.set(90,i,(*c,230))
    tf.set(i,9,(255,170,60,230)); tf.set(i,90,(170,70,0,230))
tf.save(GUI/'tooltip/frame.png'); gui_meta('tooltip/frame',100,100,10,True)
sc=Pixels(6,32)
for y in range(32):
    for x in range(6): sc.set(x,y,(255,181,71) if x==0 or y==0 else (179,89,0) if x==5 or y==31 else (255,138,0))
sc.save(GUI/'widget/scroller.png'); gui_meta('widget/scroller',6,32,1)
sb=Pixels(6,32)
for y in range(32):
    for x in range(6): sb.set(x,y,(12,10,14) if x in (0,5) or y in (0,31) else (30,26,34))
sb.save(GUI/'widget/scroller_background.png'); gui_meta('widget/scroller_background',6,32,1)

hearts=['container','container_blinking','container_hardcore','container_hardcore_blinking']
for kind in ('','poisoned_','withered_','absorbing_','frozen_'):
    for hardcore in ('','hardcore_'):
        for fill in ('full','half'):
            for blink in ('','_blinking'):
                hearts.append(f'{kind}{hardcore}{fill}{blink}')
for name in hearts:
    blank.save(Path(f'assets/minecraft/textures/gui/sprites/hud/heart/{name}.png'))
for name in ('food_empty','food_half','food_full','food_empty_hunger','food_half_hunger','food_full_hunger'):
    blank.save(Path(f'assets/minecraft/textures/gui/sprites/hud/{name}.png'))

out=BUILD/'Deepforge-ResourcePack.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted(PACK.rglob('*')):
        if path.is_file():
            info=zipfile.ZipInfo(path.relative_to(PACK).as_posix(),date_time=(2026,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,path.read_bytes())
(BUILD/'pack.sha1').write_text(hashlib.sha1(out.read_bytes()).hexdigest()+'\n',encoding='ascii')
print(f'Created {out.name}: {out.stat().st_size:,} bytes; SHA-1 {(BUILD/"pack.sha1").read_text().strip()}')
