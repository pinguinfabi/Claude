"""Validate generated references, JSON, PNG headers and the 1.21.8 pack contract."""
from pathlib import Path
import json,struct,zipfile,math
root=Path(__file__).resolve().parent/'build'/'pack'
count=0
for path in root.rglob('*.json'):
    data=json.loads(path.read_text(encoding='utf8'));count+=1
    if '/models/' in path.as_posix():
        for ref in data.get('textures',{}).values():
            if ref.startswith('deepforge:'):
                assert (root/'assets/deepforge/textures'/f'{ref.split(":",1)[1]}.png').is_file(),(path,ref)
                assert ref.split(':',1)[1].startswith(('block/','item/')), (path,ref,'Texture exists but is absent from Minecraft 1.21.8 blocks atlas')
        parent=data.get('parent','')
        if parent.startswith('deepforge:'):
            assert (root/'assets/deepforge/models'/f'{parent.split(":",1)[1]}.json').is_file(),(path,parent)
        for element in data.get('elements',[]):
            assert all(-16<=v<=32 for v in element['from']+element['to']),path
            assert all(a<=b for a,b in zip(element['from'],element['to'])),path
    if '/items/' in path.as_posix():
        ref=data['model']['model'];assert data['model']['type']=='minecraft:model'
        assert (root/'assets/deepforge/models'/f'{ref.split(":",1)[1]}.json').is_file(),(path,ref)
for path in root.rglob('*.png'):
    b=path.read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n',path
    w,h=struct.unpack('>II',b[16:24]);assert w>0 and h>0,path
states=json.loads((root/'assets/minecraft/blockstates/note_block.json').read_text())['variants']
assert len(states)==23*25*2
assert sum(v['model'].startswith('deepforge:') for v in states.values())==7
for entry in states.values():
    if entry['model'].startswith('deepforge:'):assert (root/'assets/deepforge/models'/f'{entry["model"].split(":",1)[1]}.json').is_file()
assert json.loads((root/'pack.mcmeta').read_text())['pack']['pack_format']==64
providers=json.loads((root/'assets/deepforge/font/ui.json').read_text(encoding='utf8'))['providers']
assert providers[-1]=={'type':'reference','id':'minecraft:default'}, 'Custom GUI glyphs must win over other packs default font'
assert all(p['type']!='reference' for p in providers[:-1])
def transform(point,pose,sign):
    x,y,z=[(g-8)*s for g,s in zip(point,pose['scale'])]
    c,a,b=map(math.radians,(pose['rotation'][0],pose['rotation'][1]*sign,pose['rotation'][2]*sign))
    x,y=x*math.cos(b)-y*math.sin(b),x*math.sin(b)+y*math.cos(b)
    x,z=x*math.cos(a)+z*math.sin(a),-x*math.sin(a)+z*math.cos(a)
    y,z=y*math.cos(c)-z*math.sin(c),y*math.sin(c)+z*math.cos(c)
    return [x+pose['translation'][0]*sign,y+pose['translation'][1],z+pose['translation'][2]]

def project(point,pose,sign):
    x,y,z=transform(point,pose,sign)
    x,y,z=x/16+.56*sign,y/16-.52,z/16-.72
    assert z<0,'Geometry behind camera'
    return x/(-z*math.tan(math.radians(35))*16/9),y/(-z*math.tan(math.radians(35)))

for name in ['drill','blade',*[f'weapon_{s}' for s in ('sword','hammer','dagger','spear','crossbow')]]:
    model=json.loads((root/f'assets/deepforge/models/item/{name}.json').read_text())
    grip=[7.5,2.5,10.5] if name=='drill' else [8,2,13.5] if name=='weapon_crossbow' else [8,3,8]
    for perspective in ('firstperson','thirdperson'):
        for hand in ('righthand','lefthand'):
            pose=model['display'][f'{perspective}_{hand}']
            sign=1 if hand=='righthand' else -1
            actual=transform(grip,pose,sign)
            gun=name in ('drill','weapon_crossbow')
            expected=[-sign if gun else sign,2.2 if name=='drill' else 1.5 if gun else 1,-2 if gun else -3] if perspective=='firstperson' else [0,2,-1]
            assert all(abs(a-b)<.001 for a,b in zip(actual,expected)), (name,perspective,hand,'Grip is detached from hand anchor')
            if perspective=='firstperson':
                import itertools
                corners=[p for e in model['elements'] for p in itertools.product(*zip(e['from'],e['to']))]
                screen=[project(p,pose,sign) for p in corners]
                assert sum(abs(x)<1 and abs(y)<1 for x,y in screen)/len(screen)>.85,(name,hand,'Model clipped from view')
                assert max(y for x,y in screen)-min(y for x,y in screen)>.18,(name,'Model too small to see')
                assert all(abs(x)>.12 or abs(y)>.12 for x,y in screen),(name,'Obstructs crosshair')
            else:
                # ItemInHandLayer applies X(-90), Y(180) before this transform.
                # Blade direction must be up; the drill barrel must face forward, never sideways.
                tip=[7.5,2.5,-2] if name=='drill' else [8,2,0] if name=='weapon_crossbow' else [8,20,8]
                x,y,z=[a-b for a,b in zip(transform(tip,pose,sign),actual)]
                # LivingEntityRenderer also flips X/Y for the entity model coordinate system.
                x,y,z=x,z,-y
                assert abs(x)<.001 and (z<0 if name in ('drill','weapon_crossbow') else y>0),(name,hand,'Third-person direction wrong')
for zone in range(7):
    for bone in ('body','head','arm','leg','core'):
        assert (root/f'assets/deepforge/items/mob_{zone}_{bone}_hit.json').exists()
with zipfile.ZipFile(root.parent/'Deepforge-ResourcePack.zip') as z:
    assert 'pack.mcmeta' in z.namelist();assert z.testzip() is None
print(f'OK: {count} JSON definitions, {len(list(root.rglob("*.png")))} PNG textures, 1,150 block states, ZIP integrity.')
