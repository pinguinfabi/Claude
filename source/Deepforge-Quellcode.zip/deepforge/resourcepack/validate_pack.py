"""Validate generated references, JSON, PNG headers and the 1.21.8 pack contract."""
from pathlib import Path
import json,struct,zipfile,math
root=Path(__file__).resolve().parent/'build'/'pack'
count=0
for path in root.rglob('*.json'):
    data=json.loads(path.read_text(encoding='utf8'));count+=1
    if '/models/' in path.as_posix():
        for ref in data.get('textures',{}).values():
            if ref.startswith('deepforge:'):
                assert (root/'assets/deepforge/textures'/f'{ref.split(":",1)[1]}.png').is_file(),(path,ref)
                assert ref.split(':',1)[1].startswith(('block/','item/')), (path,ref,'Texture exists but is absent from Minecraft 1.21.8 blocks atlas')
        parent=data.get('parent','')
        if parent.startswith('deepforge:'):
            assert (root/'assets/deepforge/models'/f'{parent.split(":",1)[1]}.json').is_file(),(path,parent)
        for element in data.get('elements',[]):
            assert all(-16<=v<=32 for v in element['from']+element['to']),path
            assert all(a<=b for a,b in zip(element['from'],element['to'])),path
    if '/items/' in path.as_posix():
        ref=data['model']['model'];assert data['model']['type']=='minecraft:model'
        ns,rel=ref.split(':',1)
        assert (root/'assets'/ns/'models'/f'{rel}.json').is_file(),(path,ref)
for path in root.rglob('*.png'):
    b=path.read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n',path
    w,h=struct.unpack('>II',b[16:24]);assert w>0 and h>0,path
states=json.loads((root/'assets/minecraft/blockstates/note_block.json').read_text())['variants']
assert len(states)==23*25*2
assert sum(v['model'].startswith('deepforge:') for v in states.values())==17
for entry in states.values():
    if entry['model'].startswith('deepforge:'):assert (root/'assets/deepforge/models'/f'{entry["model"].split(":",1)[1]}.json').is_file()
assert json.loads((root/'pack.mcmeta').read_text())['pack']['pack_format']==64
# The Axxin.de network pack is inside 1:1: every file byte for byte, nothing of ours on top.
axxin=Path(__file__).resolve().parent/'axxin'
for f in axxin.rglob('*'):
    if f.is_file(): assert (root/f.relative_to(axxin)).read_bytes()==f.read_bytes(),('Axxin file changed',f)
netz=json.loads((root/'assets/deepforge/font/netz.json').read_text(encoding='utf8'))['providers']
assert netz[-1]=={'type':'reference','id':'minecraft:default'}
providers=json.loads((root/'assets/deepforge/font/ui.json').read_text(encoding='utf8'))['providers']
assert providers[-1]=={'type':'reference','id':'minecraft:default'}, 'Custom GUI glyphs must win over other packs default font'
assert all(p['type']!='reference' for p in providers[:-1])
# Font glyphs must fit a 256x256 font atlas page, otherwise the client draws a missing-glyph box.
for font in root.rglob('font/*.json'):
    for p in json.loads(font.read_text(encoding='utf8'))['providers']:
        if p['type']!='bitmap': continue
        ns,rel=p['file'].split(':',1)
        b=(root/'assets'/ns/'textures'/rel).read_bytes()
        w,h=struct.unpack('>II',b[16:24])
        cw,ch=w//max(len(r) for r in p['chars']),h//len(p['chars'])
        assert cw<=256 and ch<=256,(font,p['file'],cw,ch,'glyph larger than a font atlas page')
HANDHELD={'rotation':[0,-90,25],'translation':[1.13,3.2,1.13],'scale':[.68]*3}
def rot(axis,deg,v):
    a=math.radians(deg);c,s=math.cos(a),math.sin(a);x,y,z=v
    return (x,y*c-z*s,y*s+z*c) if axis=='x' else (x*c+z*s,y,-x*s+z*c) if axis=='y' else (x*c-y*s,x*s+y*c,z)
def corners(element):
    import itertools
    r=element.get('rotation')
    for p in itertools.product(*zip(element['from'],element['to'])):
        if r:
            o=r['origin'];p=[a+b for a,b in zip(rot(r['axis'],r['angle'],[a-b for a,b in zip(p,o)]),o)]
        yield p
def first_person(point,pose,sign):
    """Same chain as the client: arm offset, ItemTransform (mirrored for the left hand), -0.5 centre."""
    v=[(c/16-.5)*s for c,s in zip(point,pose['scale'])]
    v=rot('z',pose['rotation'][2]*sign,v);v=rot('y',pose['rotation'][1]*sign,v);v=rot('x',pose['rotation'][0],v)
    x,y,z=[a+b/16*(sign if i==0 else 1) for i,(a,b) in enumerate(zip(v,pose['translation']))]
    x,y,z=x+.56*sign,y-.52,z-.72
    f=1/math.tan(math.radians(35))
    return f*x/-z,f*y/-z,z   # screen units: 1 = half the screen height

held=['drill','blade',*[f'weapon_{s}' for s in ('sword','hammer','dagger','spear','crossbow')]]
for name in held:
    model=json.loads((root/f'assets/deepforge/models/item/{name}.json').read_text())
    for e in model['elements']:
        r=e.get('rotation')
        assert not r or r['angle'] in (-45,-22.5,0,22.5,45),(name,'Element rotation not allowed in 1.21.8')
        for face in e['faces'].values():
            assert all(0<=v<=16 for v in face['uv']),(name,'UV leaves its sprite and bleeds into the atlas')
    for hand,sign in (('righthand',1),('lefthand',-1)):
        pose=model['display'][f'firstperson_{hand}']
        if name!='weapon_crossbow':
            expected=dict(HANDHELD,rotation=[0,90*-sign,25*sign])
            assert pose==expected and model['display'][f'thirdperson_{hand}']['rotation']==[0,-90*sign,55*sign],(name,hand,'Must use the vanilla handheld pose')
        screen=[first_person(p,pose,sign) for e in model['elements'] for p in corners(e)]
        assert all(z<-.05 for _,_,z in screen),(name,'Geometry behind the camera')
        assert all(x*sign>.35 for x,_,_ in screen),(name,hand,'Reaches the crosshair / centre of the screen')
        visible=[(x,y) for x,y,_ in screen if abs(x)<16/9 and abs(y)<1]
        assert visible and max(y for _,y in visible)>-.7,(name,'Hidden below the screen')
        xs=[min(16/9,max(-16/9,x)) for x,_,_ in screen];ys=[min(1,max(-1,y)) for _,y,_ in screen]
        area=(max(xs)-min(xs))*(max(ys)-min(ys))/(2*16/9*2)
        assert area<.3,(name,hand,f'Covers {area:.0%} of the screen')
for zone in range(17):
    for bone in ('body','head','arm','leg','core'):
        assert (root/f'assets/deepforge/items/mob_{zone}_{bone}_hit.json').exists()
with zipfile.ZipFile(root.parent/'Deepforge-ResourcePack.zip') as z:
    assert 'pack.mcmeta' in z.namelist();assert z.testzip() is None
print(f'OK: {count} JSON definitions, {len(list(root.rglob("*.png")))} PNG textures, 1,150 block states, ZIP integrity.')
