# Untergrund – Layout 3

Alle sieben alten Kastenräume wurden durch geschlossene Höhlennetze ersetzt. Der eigene Entwurf orientiert sich an den Bildern von [Mines | Caves v2](https://mcmodels.net/products/11392/mines-caves-v2) und [Amethyst Mines](https://www.breadbuilds.com/product/amethyst-mines): unregelmäßige Felskammern, Holzstützen, Höhenunterschiede, Stege und besondere Formationen. Externe Karten oder kostenpflichtige Bauvorlagen wurden nicht übernommen.

## Aufbau

Jedes Gebiet hat eine Aufzugnische, einen gewundenen Hauptstollen mit verbundenen Gleisen, eine große Abbauhalle, seitliche Kammern und zwei Rundwege zur hinteren Bosskammer. Unebene Felsränder und unterschiedlich hohe Decken ersetzen die geraden Wände. Holzrahmen, Querträger, Ketten, Laternen, Tropfsteine, Materialvorräte, Werkbänke und ein beladener Förderwagen geben den Schächten einen betrieblichen Charakter. Eine Treppe erschließt die erhöhte Holzgalerie in der Haupthalle.

Der bebaute Bereich pro Ebene umfasst 97 × 77 × 24 Blöcke einschließlich der geschlossenen Felshülle. Die sichtbaren Höhlen liegen innerhalb dieser Hülle und sind ausdrücklich nicht rechteckig. Jedes Gebiet verfügt über mehrere Hundert abbaubare Erzblöcke in unregelmäßigen Wandadern. Nicht jede dekorative Gesteinsformation ist abbaubar.

| Gebiet | Gestaltung |
|---|---|
| Eisenmine | Grauer Fels, Kupfer- und Kohlevorräte, klassische Holzkonstruktionen |
| Kristallhöhle | Helle Kalkadern, Amethystformationen, Kristallspitzen |
| Pilztiefen | Moos, große Pilze, leuchtende Beerenranken, feuchte Mulden |
| Versunkene Schächte | Prismarin, Wasserbecken, Wasserfall, trockene Versorgungswege |
| Magmaschlucht | Basalt, dunkler Fels, Lavabecken und Brücke über die Spalte |
| Vergessene Ruinen | Sandstein, beschädigtes Mauerwerk, Säulen und antike Gefäße |
| Leerenbruch | Obsidianformationen, Sculk, schwebend aufgehängte Leuchtelemente |

## Spielablauf

Im Dorf den Minenaufzug benutzen oder im Handbuch „Mine betreten“ wählen. Das Lesepult am Anfang jedes Schachtes bringt dich zurück ins Dorf. Die Gleise führen in Richtung Bosskammer; der Lodestone am hinteren Altar startet den vorhandenen Bosskampf.

Der Scanner markiert nun nahe tatsächliche Erzadern. Abbauprüfung und Erz-Nachwachsen verwenden dieselbe Liste der neuen Aderpositionen. Gegner erscheinen auf geprüften freien Abschnitten des Hauptweges. Die wirtschaftlichen Regeln, Gebietskosten, Beute und Freischaltungen wurden nicht verändert.

Laternen und thematische Lichtquellen bestimmen die Beleuchtung. Die zuvor ständig erneuerte Nachtsicht ist standardmäßig aus; bei Bedarf `mining.night-vision: true` konfigurieren und den Server neu starten.

## Update und Erhaltung

Vor dem Austausch wurde der lokale Server regulär gestoppt und Welt sowie Plugin-Daten gesichert. Eine eigene Untergrundmarkierung ermöglicht die automatische Migration und die Wiederaufnahme unterbrochener Bauten. Die Dorfmarkierung bleibt getrennt davon erhalten. Wirtschaftsdaten werden vom Umbau nicht verändert.

Die Minen liegen zwischen Y=20 und Y=187. Damit bleibt die Oberfläche des Dorfes oberhalb von Y=187 erhalten. Vorhandene Spieler werden während eines laufenden Umbaus auf der sicheren Startplattform geparkt und danach ins Dorf gebracht.

Die Bauplanprüfungen erfassen alle sieben Ebenen: Erreichbarkeit sämtlicher Erzadern, Wege vom Aufzug zum Boss, Seitenstollen, Holzgalerie, freie Spawns, geschlossene Außenhülle, variable Kammerbreiten/Deckenhöhen und die thematischen Formationen. Zusätzlich validiert Paper alle Blockzustände. Vereinfachte Grundriss- und Perspektivbilder wurden zur Geometriekontrolle erzeugt; sie sind keine Minecraft-Screenshots. Der abschließende Spieltest mit dem persönlichen Client und dessen Shadern bleibt erforderlich.
