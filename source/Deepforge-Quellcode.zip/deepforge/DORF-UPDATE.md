# Bergbaudorf – Layout 2

Das Update ist ein eigener, aus Minecraft-Blöcken gebauter Dorfentwurf. Keine heruntergeladene Welt und kein kostenpflichtiges Baupaket.

## Rundgang

- **Nordwesten:** Fachwerkschmiede mit Schieferdach, Dachgaube, gemauertem Kamin, überdachtem Außenofen, Amboss, Schleifstein, Löschkessel, Holzlager und Werkstatt. Innen führt eine Treppe ins Dachgeschoss.
- **Nordosten:** zweigeschossiger Speicher mit dunklem Holzdach, Fassregalen, Heuboden, Ladeplattform, Kran mit Kette und Wagen im Hof. Zusätzliche Kisten zeigen den Lagerausbau.
- **Südwesten:** Schmelzhalle mit patiniertem Kupferdach, zwei hohen Schornsteinen, glühenden Öfen, Kohlenvorrat, Arbeitsbank und eigenen Maschinenmodellen. Daneben liegt die sichtbare Erzfront der Arbeiter.
- **Südosten:** Mannschaftshaus mit hellem Putz, Fachwerk, Dachgaube, Balkon, Gemeinschaftstisch, Bücherregal, Küche und Betten im Obergeschoss.
- **Norden:** zwei Marktstände mit orange-weißen Stoffdächern, Waren und Handelsstation.
- **Süden:** hoher Förderturm mit Stahlbändern, Streben, Förderrad, Ketten, Liftplattform und steinernem Stolleneingang. Am Lesepult wählt man weiterhin die spielbaren Untergrundgebiete.
- **Dazwischen:** Pflasterplatz mit Brunnen und Bänken, unregelmäßig gemischte Wege, Laternen, Blumenkästen, Pflanzinseln, Bach mit Holzbrücke, Baumgruppen und felsige Hügel.

Alle sechs Stationen werden per Rechtsklick bedient. Eingänge sind offen, damit der vorhandene Weltenschutz die Gebäude nicht unzugänglich macht. Arbeiter laufen zwischen Lager, Markt, Schmelze und Erzfront; die wirtschaftliche Produktion bleibt unabhängig von der Animation.

## HUD und Ressourcenpaket

Das private Schriftzeichen vor dem Geldbetrag wurde aus dem HUD entfernt. Es konnte über die Standard-Schriftreferenz auf ein Motiv aus einem anderen Pack zeigen. Im eigenen GUI-Font stehen nun alle eigenen Glyphen vor der Standard-Schrift. Das Handmodell des Bohrers ist kleiner.

Beim erneuten Verbinden das neue Server-Ressourcenpaket akzeptieren. Falls nötig `/df pack`, anschließend `/df home`.

## Bestandsschutz und Prüfungen

Die automatische Migration verändert ausschließlich Blöcke oberhalb der Minenräume. Sie ändert weder Guthaben noch Upgrades oder die gespeicherten Arbeiter. Eine eigene Versionsmarkierung erlaubt die Wiederaufnahme eines unterbrochenen Umbaus.

Automatische Prüfungen kontrollieren die Erreichbarkeit aller Stationen, Gebäudeeingänge und Arbeiterziele, sicheren Spawn, Grundstücksgrenzen, Abstand zum Untergrund und dauerhafte Blätter. Paper validiert beim Laden alle verwendeten Blockzustände, bevor die ersten Blöcke gesetzt werden. Der visuelle Bauplan wurde zusätzlich als vereinfachtes 3D-Modell geprüft; die Darstellung mit individuellen Client-Packs und Shadern benötigt einen Spieltest.

## Gestaltungsvorbilder

Inspiration: klare Gebäudeformen und gegliederte Dächer aus dem offiziellen Minecraft-Beitrag [How to Structure your Build](https://www.minecraft.net/tr-tr/article/how-structure-your-build), ergänzt um die traditionelle Dorfgestaltung aus [Village](https://www.minecraft.net/en-us/article/village). Der konkrete Blockentwurf und die vorhandenen Deepforge-Texturen stammen aus diesem Projekt.
