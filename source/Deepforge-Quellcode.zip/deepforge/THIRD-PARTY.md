# Third-party notices

The plugin JAR embeds these libraries:

- **SQLite JDBC 3.49.1.0**, Xerial, https://github.com/xerial/sqlite-jdbc . Its Apache-2.0 and original Zentus license texts are retained inside the JAR under `META-INF/maven/org.xerial/sqlite-jdbc/LICENSE` and `LICENSE.zentus`.
- **Gson 2.11.0**, Google, https://github.com/google/gson . Copyright 2008 Google Inc. Licensed under the Apache License, Version 2.0. The full Apache-2.0 text is included in `licenses/APACHE-2.0.txt` in the distribution.
- **Error Prone annotations 2.27.0**, Google, https://github.com/google/error-prone . Apache-2.0.

Paper, SLF4J and Citizens are provided by the Minecraft server installation, not bundled in the plugin. JUnit and build/formatting tools are development-only. Minecraft game assets are not redistributed; resource-pack references to `minecraft:` resolve against the user's client installation.
