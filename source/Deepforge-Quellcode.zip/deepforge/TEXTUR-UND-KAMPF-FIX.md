# Texturen, Handmodelle, Schienen und Jagdaufträge

Update für den bestehenden lokalen Paper-1.21.8-Server, 27. September 2026.

## Korrekturen

- **Schwarz-pinke Monster:** Die PNGs existierten, lagen aber unter `textures/entity/`. Minecraft lädt diesen eigenen Ordner nicht automatisch in den Atlas für ItemDisplay-Modelle. Die Monster- und Kerntexturen liegen jetzt unter `textures/item/mobs/`; alle Modellreferenzen und benannten Waffen wurden angepasst. Alte generierte Dateien werden gezielt entfernt. Der Validator prüft jetzt zusätzlich die Atlas-Zugehörigkeit und nicht nur die Existenz der Datei. Referenz: [Mojangs Erklärung der Ressourcenpaket-Atlanten](https://www.minecraft.net/fr-fr/article/minecraft-java-edition-1-19-3). Zusätzlich wurden die tatsächlichen Atlasquellen der lokal installierten Minecraft-Version 1.21.8 gelesen.
- **Waffen in der Hand:** Bohrer, Klinge und alle fünf Waffenformen erhalten getrennte Transformationen für erste/dritte Person und rechte/linke Hand. Der Griff wird an einem gemeinsamen Handpunkt ausgerichtet; Schwert, Hammer, Dolch und Speer verwenden passende Größen. Die Klingenfläche ist zur Kamera gedreht. Modelle im Menü und stationäre Maschinen behalten ihre eigene Darstellung. Benannte Waffen erben die Korrekturen.
- **Monster vor Schienen:** Die native Wegfindung der Husk-Träger darf jetzt sowohl Schienen als auch den zuvor negativ bewerteten Schienenübergang nutzen. Die Anpassung gilt nur für Deepforge-Monster. Wände und andere Kollisionen bleiben in der Minecraft-Wegfindung berücksichtigt. Der Adapter ist ausdrücklich auf die unterstützte Paper-Version 1.21.8 begrenzt.
- **Treffer durch Deckung:** Reguläre Nahkämpfer benötigen Sichtkontakt für ihren Nahbereichsschaden.

## Weitergeführtes Konzept

**Dolch-Rückenangriffe:** Treffer im hinteren 120-Grad-Bereich des Gegners verursachen 65 % mehr Schaden. Die Prüfung verwendet dessen Blickrichtung. Andere Waffen erhalten diesen Bonus nicht. Ein eigener kritischer Angriffston bestätigt den Dolchbonus.

**Panzerwächter mit gerichteter Deckung:** Angriffe gegen die Vorderseite verursachen nur 45 % Schaden. Seiten und Rücken nehmen den vollen Schaden. Ein Dolch-Rückenangriff kann deshalb besonders effektiv sein. Das Boss-Haltungssystem bleibt separat bestehen.

**Wiederholbare Jagdaufträge:** Im Beutebuch steht für jedes der sieben Gebiete ein Auftrag. Je 15 reguläre Gegner geben 450 × Gebietsstufe Dollar, drei Schmiedestaub und sechs passende Monsterteile. Fortschritt über 15 bleibt beim Abholen erhalten. Beschworene Bosshelfer zählen nicht. Fortschritt und abgeschlossene Aufträge werden zusammen mit Geld und Materialien gespeichert; ein erneuter Klick bezahlt denselben Fortschritt nicht doppelt.

## Prüfen im Spiel

1. Neu mit `localhost:25565` verbinden und das aktualisierte Serverpaket laden. Bei alter Anzeige `/df pack` ausführen. Eine separat manuell installierte alte Deepforge-ZIP durch die neue Ausgabe ersetzen.
2. Bohrer und Waffe auswählen; bei Bedarf in den Minecraft-Einstellungen zwischen rechter und linker Haupthand wechseln. Die tatsächliche Bildschirmposition bleibt mit dem verwendeten Client und dessen Mods zu prüfen.
3. In der Mine auf die andere Seite der Schienen gehen und normale Gegner verfolgen lassen.
4. Über `/df loot` → **Beutebuch & Rezepte** den Jagdfortschritt ansehen und Belohnungen abholen.

Die Modell-/Atlasprüfung und ein serverseitiger Test mit tatsächlich laufenden Monstern ergänzen die automatisierten Spielregeltests. Der Server-Laufzeittest verwendet temporäre, geschlossene Schienenstrecken und stellt deren ursprüngliche Blöcke danach wieder her. Er vergibt keine Spielerbeute.
